# Project Onboarding Guide

* Request access to the `trilogy-sales` and `trilogy-sales--full` Salesforce instances (from team members)
* Request access to the AWS group `RAM-AWS-Prod-DevFactory-SalesInfrastructure-Admin` (via an [IT Operations ticket](https://supportportal-df.atlassian.net/servicedesk/customer/portal/6/group/76/create/367))
* Request access to the NetSuite sandbox instance (from team members)

## Overview

NetSuite-related:
* The index confluence page is accessible [here](https://ws-lambda.atlassian.net/wiki/spaces/SI/pages/1626341383/NetSuite)
* [NetSuite Core Patterns](https://docs.google.com/document/d/1Sn5jc5LB17aCmv2X3ZGAgw4JghdhZh5_f7vk0EBljAc/edit#)

Self-Serve-related:
* The index confluence pages are accessible [here](https://ws-lambda.atlassian.net/wiki/spaces/SI/pages/1546911745/Self-Serve) and [here](https://ws-lambda.atlassian.net/wiki/spaces/SI/pages/1906278405/TSI+API). They contain summarised information that is detailed much more in the documents below
* [Sales Infrastructure - Self-Serve API](https://docs.google.com/document/d/1G3fhOD6SiBUhIkqFXeMiNpCgGtqLpT_1hWwOi_PJMh0/)
* [Sales Infrastructure - Self-Serve Widget & Portal](https://docs.google.com/document/d/1gmA7texETJiTy_dwqpGuiQDekJVsrhZLG-PwVMilXQA/)

## Self-Serve Widget
Read the details in the [app/portal](app/portal/README.md) file.

Try to run the widget app and see that it connects properly to the already deployed test URL.

## Self-Serve API
Read the details in the [app/server](app/server/README.md) file.

Try to run the server locally, and configure the self-serve widget to use the local URL (e.g., `http://localhost:3000/api/v1`). The application should work as before.

## NS-SF sync
