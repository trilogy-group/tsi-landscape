# TSI Subscription Management repository

## Description
This repository contains implementations on top of NetSuite/SuiteBilling that enables easy manipulation of subscription and customer data and the creation/sending of customer quotes tied to subscriptions.

## App: NetSuite
A customization is implemented through custom scripts and objects.

### Component: NetSuite Customization
* Documentation: [README.md](netsuite/README.md)
* Source: [/netsuite](netsuite/)

#### Deployment
There are some GitHub workflows for deploying the customization.
* [Deploy main to production](https://github.com/trilogy-group/si-billing-api/blob/main/.github/workflows/deploy-ns-production.yml): deploy 'main' package from 'main' branch in production instance.
* [Deploy test to sandbox](https://github.com/trilogy-group/si-billing-api/blob/main/.github/workflows/deploy-ns-sandbox.yml): deploy 'main' package from 'test' branch in SB2 instance.
* [Deploy package for QC](https://github.com/trilogy-group/si-billing-api/blob/main/.github/workflows/deploy-qc.yml): deploy 'qc' package from target branch in SB2 instance, manual run only.

There is a GitHub worflow for syncing branches.
* [Synchronize main and test branches](https://github.com/trilogy-group/si-billing-api/blob/main/.github/workflows/sync-main-and-test.yml): sync 'test' branch from 'main' branch.

#### NetSuite resources
* [Production instance](https://4914352.app.netsuite.com)
* [SB2 instance](https://4914352-sb2.app.netsuite.com/)

## App: Self-Serve Portal
The Self-Serve Portal is an app enabling the automation of the low-value renewals. It is composed by:
* a Proxy API for targeting the custom scripts implemented in NetSuite;
* a Portal API, managing the customer login;
* a Portal UI, including a Self-Serve widget that can be embedded in third-party Web application. 

### Component: Proxy API
* Documentation: [README.md](app/server/README.md) - [Confluence page](https://ws-lambda.atlassian.net/wiki/spaces/SI/pages/2526183452/NetSuite+Billing+Self-Serve+API)
* Source: [/app/server](app/server/)

#### Deployment
There are some GitHub workflows for deploying the Proxy API. The target stacks are 'api-proxy' and 'portal-api'.
* [Deploy cdk production](https://github.com/trilogy-group/si-billing-api/actions/workflows/cdk-deploy-prod.yml): deploy any updated stacks as prod instance in AWS Prod account.
* [Deploy cdk environment](https://github.com/trilogy-group/si-billing-api/actions/workflows/cdk-deploy.yml): deploy any updated stacks as given instance in AWS Dev account.
    * The default instance is test. 
    * PR instances are automatically deployed then destroyed when the PR is closed.

There is a GitHub workflow for running E2E tests.
* [Run E2E tests](https://github.com/trilogy-group/si-billing-api/actions/workflows/e2e-tests.yml): run E2E tests against the target branch and NetSuite package, scheduled daily run. 

#### AWS resources
* The deployment is done using CDK Toolkit with [AWS CloudFormation > Stacks](https://us-east-1.console.aws.amazon.com/cloudformation/home).
* The application is listed in [AWS Systems Manager > Application Manager](https://us-east-1.console.aws.amazon.com/systems-manager/appmanager/applications).
* The Proxy API is deployed as a load balanced container with AWS Fargate in [Amazon Elastic Container Service (ECS) > Clusters](https://us-east-1.console.aws.amazon.com/ecs/v2/clusters?region=us-east-1).

##### Prod account
* Endpoints: [Proxy API](https://api.si.trilogy.com/api/v1/) - [Swagger UI](https://api.si.trilogy.com/api-explorer)
* Stack [tsi-prod-api-proxy](https://us-east-1.console.aws.amazon.com/cloudformation/home?region=us-east-1#/stacks/stackinfo?filteringText=tsi-prod&filteringStatus=active&viewNested=true&stackId=arn%3Aaws%3Acloudformation%3Aus-east-1%3A524963845153%3Astack%2Ftsi-prod-api-proxy%2F9c462210-b9d4-11ec-ab79-0aa449d8e3e7)
* Application [tsi-prod-api-proxy](https://us-east-1.console.aws.amazon.com/systems-manager/appmanager/application/AppManager-CFN-tsi-prod-api-proxy?region=us-east-1)
* Cluster [tsi-api-cluster](https://us-east-1.console.aws.amazon.com/ecs/v2/clusters/tsi-api-cluster/services?region=us-east-1), Service [tsi-prod-api-proxy-tsiprodapiproxyServiceA425010C-V2M4YY4pIu2X](https://us-east-1.console.aws.amazon.com/ecs/v2/clusters/tsi-api-cluster/services/tsi-prod-api-proxy-tsiprodapiproxyServiceA425010C-V2M4YY4pIu2X/health?region=us-east-1)

##### Dev account
* Endpoints: [Proxy API](https://test.api.dev.si.trilogy.com/api/v1) - [Swagger UI](https://test.api.dev.si.trilogy.com/api-explorer)
* Stack [tsi-test-api-proxy](https://us-east-1.console.aws.amazon.com/cloudformation/home?region=us-east-1#/stacks/stackinfo?filteringText=tsi-test&filteringStatus=active&viewNested=true&stackId=arn%3Aaws%3Acloudformation%3Aus-east-1%3A941633908494%3Astack%2Ftsi-test-api-proxy%2F7df6a3f0-3b12-11ee-8937-0e58a0b267a9)
* Application [tsi-test-api-proxy](https://us-east-1.console.aws.amazon.com/systems-manager/appmanager/application/AppManager-CFN-tsi-test-api-proxy?region=us-east-1)
* Cluster [tsi-api-cluster-dev](https://us-east-1.console.aws.amazon.com/ecs/v2/clusters/tsi-api-cluster-dev/services?region=us-east-1), Service [tsi-test-api-proxy-tsitestapiproxyServiceC0FB26CB-orEs6XWFKQQQ](https://us-east-1.console.aws.amazon.com/ecs/v2/clusters/tsi-api-cluster-dev/services/tsi-test-api-proxy-tsitestapiproxyServiceC0FB26CB-orEs6XWFKQQQ/health?region=us-east-1)

### Component: Portal API
* Documentation: [Confluence page](https://ws-lambda.atlassian.net/wiki/spaces/SI/pages/2526183452/NetSuite+Billing+Self-Serve+API)
* Source: [/app/portal](app/portal/)

#### Deployment
The GitHub workflows for deploying the Portal API are the same than the Proxy API.

#### AWS resources
* The deployment is done using CDK Toolkit with [AWS CloudFormation > Stacks](https://us-east-1.console.aws.amazon.com/cloudformation/home).
    * Common resources are deployed via [/deploy.common](deploy.common/). There is no GitHub workflow handling it.
    * Specific resources are deployed via [/deploy](deploy/).
* The application is listed in [AWS Systems Manager > Application Manager](https://us-east-1.console.aws.amazon.com/systems-manager/appmanager/applications).
* The Portal API is deployed as Lambda functions called via an [API Gateway > APIs](https://us-east-1.console.aws.amazon.com/apigateway/main/apis).
* The user authentication service is AWS Cognito. A user pool is defined per instance. The user attributes are defined in a DynamoDB table.

##### Prod account
* Endpoints: [Portal API](https://portal.si.trilogy.com/api) - [Swagger UI](https://api-explorer.portal.si.trilogy.com/)
* Stacks [tsi-prod-portal-api](https://us-east-1.console.aws.amazon.com/cloudformation/home?region=us-east-1#/stacks/stackinfo?filteringText=tsi-prod&filteringStatus=active&viewNested=true&stackId=arn%3Aaws%3Acloudformation%3Aus-east-1%3A524963845153%3Astack%2Ftsi-prod-portal-api%2F8032d3f0-8ad3-11ec-80de-0a1d283c3179), [tsi-common-prod-common-resources](https://us-east-1.console.aws.amazon.com/cloudformation/home?region=us-east-1#/stacks/stackinfo?filteringText=tsi-common&filteringStatus=active&viewNested=true&stackId=arn%3Aaws%3Acloudformation%3Aus-east-1%3A524963845153%3Astack%2Ftsi-common-prod-common-resources%2F11ba86d0-eae5-11ec-9f00-0acc1b8a7a61)
* Applications [tsi-prod-portal-api](https://us-east-1.console.aws.amazon.com/systems-manager/appmanager/application/AppManager-CFN-tsi-prod-portal-api?region=us-east-1), [tsi-common-prod-common-resources](https://us-east-1.console.aws.amazon.com/systems-manager/appmanager/application/AppManager-CFN-tsi-common-prod-common-resources?region=us-east-1)
* API Gateway [tsi-prod-portal-api-restapi](https://us-east-1.console.aws.amazon.com/apigateway/home?region=us-east-1#/apis/wk11duyk3g/resources/040l6mzsx8)
* Cognito User Pool [selfserveportal-prod-passwordless](https://us-east-1.console.aws.amazon.com/cognito/v2/idp/user-pools/us-east-1_6C4T4qDOU/users?region=us-east-1)
* DynamoDB Table [portal-prod-ui-storage](https://us-east-1.console.aws.amazon.com/dynamodbv2/home?region=us-east-1#table?name=portal-prod-ui-storage)
* KMS key [selfserveportal-prod-auth-key](https://us-east-1.console.aws.amazon.com/kms/home?region=us-east-1#/kms/keys/19de9e9a-3dc5-46ac-afd5-20030ba16943)

##### Dev account
* Endpoints: [Portal API](https://test.portal.dev.si.trilogy.com/api) - [Swagger UI](https://api-explorer.test.portal.dev.si.trilogy.com)
* Stacks [tsi-test-portal-api](https://us-east-1.console.aws.amazon.com/cloudformation/home?region=us-east-1#/stacks/stackinfo?filteringText=tsi-test&filteringStatus=active&viewNested=true&stackId=arn%3Aaws%3Acloudformation%3Aus-east-1%3A941633908494%3Astack%2Ftsi-test-portal-api%2Fba34b1d0-3b1d-11ee-8b95-0a0d40ced13b), [tsi-common-test-common-resources](https://us-east-1.console.aws.amazon.com/cloudformation/home?region=us-east-1#/stacks/stackinfo?filteringText=tsi-common&filteringStatus=active&viewNested=true&stackId=arn%3Aaws%3Acloudformation%3Aus-east-1%3A941633908494%3Astack%2Ftsi-common-test-common-resources%2F56e0ac30-8cd9-11ed-b3e1-0ab5a2dc8eed)
* Applications [tsi-test-portal-api](https://us-east-1.console.aws.amazon.com/systems-manager/appmanager/application/AppManager-CFN-tsi-test-portal-api?region=us-east-1), [tsi-common-test-common-resources](https://us-east-1.console.aws.amazon.com/systems-manager/appmanager/application/AppManager-CFN-tsi-common-test-common-resources?region=us-east-1)
* API Gateway [tsi-test-portal-api-restapi](https://us-east-1.console.aws.amazon.com/apigateway/home?region=us-east-1#/apis/2bajs6mdyd/resources/ouxp2ryvn2)
* Cognito User Pool [selfserveportal-test-passwordless](https://us-east-1.console.aws.amazon.com/cognito/v2/idp/user-pools/us-east-1_hgQK2Ooa9/users?region=us-east-1)
* DynamoDB Table [portal-test-ui-storage](https://us-east-1.console.aws.amazon.com/dynamodbv2/home?region=us-east-1#table?name=portal-test-ui-storage)
* KMS key [selfserveportal-test-auth-key](https://us-east-1.console.aws.amazon.com/kms/home?region=us-east-1#/kms/keys/f33c8a4d-a1ff-4d7b-bfc6-33a5a282e3ef)

### Component: Portal UI
* Documentation: [README.md](https://github.com/trilogy-group/ws-trilogy-tsi-self-serve/blob/master/README.md) - [Confluence page](https://ws-lambda.atlassian.net/wiki/spaces/SI/pages/2526117889/Self-Serve+Widget+and+Portal)
* Source: [ws-trilogy-tsi-self-serve](https://github.com/trilogy-group/ws-trilogy-tsi-self-serve)

#### Deployment
There is no GitHub workflow for deploying the Portal UI. 

#### AWS resources
* The deployment is handled by [AWS Amplify > All apps](https://us-east-1.console.aws.amazon.com/amplify/home) directly from the GitHub repo.

##### Prod account
* Endpoint: [Portal UI](https://tsi.trilogy.com/)
* App [ws-trilogy-tsi-self-serve](https://us-east-1.console.aws.amazon.com/amplify/home?region=us-east-1#/d1l9q9hskxlmpz)

##### Dev account
* Endpoint: [Portal UI](https://dev.tsi.trilogy.com/)
* App [ws-trilogy-tsi-self-serve](https://us-east-1.console.aws.amazon.com/amplify/home?region=us-east-1#/drwsdie9hpwze)

