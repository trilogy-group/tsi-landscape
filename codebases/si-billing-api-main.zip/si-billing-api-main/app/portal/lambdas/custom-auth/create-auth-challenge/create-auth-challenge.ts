import {
    CreateAuthChallengeTriggerHandler,
    CreateAuthChallengeTriggerEvent,
} from "aws-lambda";

/**
 * Create Auth Challenge AWS Lambda function.
 * @param {CreateAuthChallengeTriggerEvent} event
 * @returns {CreateAuthChallengeTriggerEvent}
 */
export const handler: CreateAuthChallengeTriggerHandler = async (event: CreateAuthChallengeTriggerEvent) => {
  
  // Set the email.
  event.response.publicChallengeParameters = {
    email: event.request.userAttributes.email,
  };

  // Set the challenge.
  event.response.privateChallengeParameters = {
    challenge: event.request.userAttributes['custom:authChallenge'],
  };

  return event;
};
