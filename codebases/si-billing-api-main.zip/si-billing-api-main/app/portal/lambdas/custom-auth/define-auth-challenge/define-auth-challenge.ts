import {
    DefineAuthChallengeTriggerHandler,
    DefineAuthChallengeTriggerEvent,
} from "aws-lambda";

/**
 * Define Auth Challenge AWS Lambda function.
 * @param {DefineAuthChallengeTriggerEvent} event
 * @returns {DefineAuthChallengeTriggerEvent}
 */
export const handler: DefineAuthChallengeTriggerHandler = async (event: DefineAuthChallengeTriggerEvent) => {

    // If the user is not found, deny the sign-in attempt.
    if (event.request.userNotFound) {
        return deny(event);
    }

    // If the authentication flow started, send a custom challenge.
    if (!event.request.session.length) {
        return sendCustomChallenge(event);
    }

    // If the custom challenge was passed, allow the user to sign in.
    const lastAttempt = event.request.session.slice(-1)[0];
    if (lastAttempt.challengeName === "CUSTOM_CHALLENGE" && lastAttempt.challengeResult === true) {
        return allow(event);
    }

    // By default, deny the sign-in attempt.
    return deny(event);
};

/**
 * Denies the sign-in attempt.
 * @param {DefineAuthChallengeTriggerEvent} event
 * @returns {DefineAuthChallengeTriggerEvent}
 */
function deny(event: DefineAuthChallengeTriggerEvent): DefineAuthChallengeTriggerEvent {
  event.response.issueTokens = false;
  event.response.failAuthentication = true;
  return event;
}

/**
 * Allows the sign-in attempt.
 * @param {DefineAuthChallengeTriggerEvent} event
 * @returns {DefineAuthChallengeTriggerEvent}
 */
function allow(event: DefineAuthChallengeTriggerEvent): DefineAuthChallengeTriggerEvent {
  event.response.issueTokens = true;
  event.response.failAuthentication = false;
  return event;
}

/**
 * Sends the custom challenge.
 * @param {DefineAuthChallengeTriggerEvent} event
 * @returns {DefineAuthChallengeTriggerEvent}
 */
function sendCustomChallenge(event: DefineAuthChallengeTriggerEvent): DefineAuthChallengeTriggerEvent {
    event.response.issueTokens = false;
    event.response.failAuthentication = false;
    event.response.challengeName = "CUSTOM_CHALLENGE";
    return event;
}
