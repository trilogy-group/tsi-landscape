import {
    PreSignUpTriggerHandler,
    PreSignUpTriggerEvent,
} from "aws-lambda";

/**
 * Pre sign-up AWS Lambda function.
 * @param {PreSignUpTriggerEvent} event
 * @returns {PreSignUpTriggerEvent}
 */
export const handler: PreSignUpTriggerHandler = async (event: PreSignUpTriggerEvent) => {

    // Skip the registration with a verification code.
    event.response.autoConfirmUser = true;

    return event;
};
