import {
    VerifyAuthChallengeResponseTriggerHandler,
    VerifyAuthChallengeResponseTriggerEvent,
} from "aws-lambda";
import { KMS } from 'aws-sdk';

const AUTH_KEY_ID = process.env.AUTH_KEY_ID ?? '';

const _kms = new KMS();

/**
 * Verify Auth Challenge Response AWS Lambda function.
 * @param {VerifyAuthChallengeResponseTriggerEvent} event
 * @returns {VerifyAuthChallengeResponseTriggerEvent}
 */
export const handler: VerifyAuthChallengeResponseTriggerHandler = async (event: VerifyAuthChallengeResponseTriggerEvent) => {
  
  // If the token doesn't match the stored token, the answer is incorrect.
  const expectedToken = event.request.privateChallengeParameters.challenge;
  if (event.request.challengeAnswer !== expectedToken) {
    event.response.answerCorrect = false;
    return event;
  }

  // Decrypt and deserialize the token to retrieve the payload.
  const json = await decrypt(event.request.challengeAnswer);
  const payload = JSON.parse(json);
  
  // Validate the payload:
  // - The current user email must match the token email.
  // - The token hasn't expired.
  const expectedEmail = event.request.userAttributes.email;
  const isExpired = new Date().toJSON() > payload.expiration;
  event.response.answerCorrect = payload.email === expectedEmail && !isExpired;
  return event
};

/**
 * Decrypts a given encrypted text.
 * @param cipherText The encrypted text to decrypt.
 * @returns {string} The decrypted text.
 */
async function decrypt(cipherText: string): Promise<string> {

  // Decrypt the given encrypted text.
  const decryptResponse = await _kms.decrypt({
      KeyId: AUTH_KEY_ID,
      CiphertextBlob: Buffer.from(cipherText, 'base64'),
  }).promise();

  // Return the text.
  if (decryptResponse.Plaintext) {
      return decryptResponse.Plaintext as string;
  } else {
      throw new Error('Decryption failed.');
  }
};
