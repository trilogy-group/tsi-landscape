import config from './config';
import * as crypto from 'crypto';
import OAuth from 'oauth-1.0a';
import axios, { AxiosResponse } from 'axios';
import sqlescape from "sql-escape";
import pino from "pino";
const logger = pino();

function logNsCall(url: string, authHeader: string): void {
  logger.debug('Executing call on "' + url + '"');
  logger.debug('AuthHeader: ' + authHeader);
}

const CONTENT_TYPE_JSON = 'application/json';

export default class NetsuiteClient {
  static generateHeader(url: string, method: string, data?: unknown): string {
    const oauth = new OAuth({
      consumer: {
        key: config.nsClientConsumerKey,
        secret: config.nsClientConsumerSecret,
      },
      realm: config.nsClientRealm,
      nonce_length: 11,
      signature_method: 'HMAC-SHA256',
      hash_function: (base_string:string, key:string) => {
        return crypto //
          .createHmac('sha256', key)
          .update(base_string)
          .digest('base64');
      },
    });
    const header = oauth.toHeader(
      oauth.authorize(
        { url: url, method: method, data: data },
        { key: config.nsClientTokenKey, secret: config.nsClientTokenSecret }
      )
    );

    return header.Authorization;
  }

  static get(url: string): Promise<AxiosResponse> {
    const authHeader = this.generateHeader(url, 'GET', null);
    logNsCall(url, authHeader);
    return axios.get(url, {
      headers: {
        Authorization: authHeader,
        'Content-Type': CONTENT_TYPE_JSON,
      },
    });
  }

  static post(url: string, data: any): Promise<any> { //NOSONAR
    const authHeader = this.generateHeader(url, 'POST', null);
    return axios.post(url, data, {
      headers: {
        Authorization: authHeader,
        'Content-Type': CONTENT_TYPE_JSON,
        prefer: 'transient',
      },
    });
  }

  static put(url: string, data: any): Promise<any> { //NOSONAR
    const authHeader = this.generateHeader(url, 'PUT', data);
    logNsCall(url, authHeader);
    return axios.put(url, data, {
      headers: {
        Authorization: authHeader,
        'Content-Type': CONTENT_TYPE_JSON,
      },
    });
  }

  /**
   * Retrieves the contact details for the given email address and customers.
   * @param {string} email The email address.
   * @param {string[]} customerEntityIds An array of customer entity IDs.
   * @returns The contact details, or undefined if there is no contact details.
   */
  static async getContactDetails(email: string, customerEntityIds: string[]): Promise<{
    firstName?: string;
  } | undefined> {
    // Build the query to retrieve the first name of the contact based on the email and for the related customers.
    // Take the first not null.
    const query = `
      SELECT TOP 1 co.firstname
      FROM customer cu
      JOIN contact co ON co.company = cu.id
      WHERE cu.entityid in ('${customerEntityIds.map(v => sqlescape(v)).join("','")}')
        AND LOWER(co.email) = '${sqlescape(email.toLowerCase())}'
        AND co.firstname IS NOT null
    `;

    // Run the query and return the result.
    const result = await NetsuiteClient.runSuiteQl(query);
    const contactDetails = result.data.items[0];
    return {
      firstName: contactDetails?.firstname,
    };
  }

  /**
   * Retrieves the customer details for the given filter.
   * @param {string} id The customer ID, i.e. the entity ID.
   * @param {number} internalId The customer internal ID.
   * @returns The customer details, or undefined if there is no customer details.
   */
  static async getCustomer(id?: string, internalId?: number): Promise<{
    id: string;
    internalId: number;
  } | undefined> {

    // Define the conditions for the given filter.
    const conditions: string[] = [];
    if (id) {
      conditions.push(`cu.entityid = '${sqlescape(id)}'`);
    }
    if (internalId) {
      conditions.push(`cu.id = ${internalId}`);
    }

    // Build the query to retrieve the customer details for the given filter.
    const query = `
      SELECT TOP 1 cu.id, cu.entityid
      FROM customer cu
      WHERE ${conditions.join(' AND ')}
    `;

    // Execute the query and return the result.
    const result = await NetsuiteClient.runSuiteQl(query);
    const customerDetails = result.data.items[0];
    if (customerDetails) {
      return {
        id: customerDetails.entityid,
        internalId: customerDetails.id,
      };
    }
    return undefined;
  }

  /**
   * Returns integration records for the customer id.
   * If the subscription ID is provided and one of the integration record is related to this subscription, put it as first element.
   * @param cid Customer Id
   * @param {string} [subscriptionId] The subscription ID.
   * @returns List of integration records
   */
   static async getCustomerIntegrations(cid: string, subscriptionId?: string) {
    
    // Build the query to retrieve the integration records for which there is an active subscription for this customer.
    // Apply an ascending ordered on any matched subscription, before the default descending order.
    const queryStr =
      `SELECT
        pi.id,
        class.fullname,
        pi.custrecordproductfamilycode,
        pi.custrecordproductvariantcode,
        pi.custrecordproductfamilytitle,
        pi.custrecordproductvarianttitle,
        pi.custrecordsecret,
        SUM(s.subscriptioncount) AS subscriptiontotalcount
      FROM (
        SELECT s.pricebook,
          COUNT(CASE WHEN s.id = ${sqlescape((subscriptionId ?? 0).toString())} THEN s.id END) AS subscriptioncount
        FROM subscription s
        JOIN customer c ON c.id = s.customer
        JOIN customer ceu ON ceu.id = s.custrecord_subs_end_user
        WHERE (c.entityid = '${sqlescape(cid)}' OR ceu.entityid = '${sqlescape(cid)}')
          AND s.billingsubscriptionstatus IN ('PENDING_ACTIVATION', 'ACTIVE')
        GROUP BY s.pricebook
      ) s
      JOIN pricebook pb on s.pricebook = pb.id
      JOIN subscriptionPlan sp on sp.id = pb.subscriptionplan
      LEFT JOIN subscriptionPlan rp on rp.id = sp.defaultrenewalplan
      JOIN classification class on class.id = COALESCE(rp.class, sp.class)
      JOIN customrecordproductintegration pi on class.id = pi.custrecordclass
        AND UPPER(pi.custrecordproductvariantcode) = UPPER(REGEXP_REPLACE(
          COALESCE(rp.displayname, sp.displayname),
            '[^-]+-([^-]+-[^-]+)-.+',
            '\\1'
        ))
      WHERE pi.isinactive = 'F'
      GROUP BY
        pi.id,
        class.fullname,
        pi.custrecordproductfamilycode,
        pi.custrecordproductvariantcode,
        pi.custrecordproductfamilytitle,
        pi.custrecordproductvarianttitle,
        pi.custrecordsecret
      ORDER BY subscriptiontotalcount DESC, custrecordproductvarianttitle, custrecordproductvariantcode`;
    return (await NetsuiteClient.runSuiteQl(queryStr)).data;
  }

  /**
   * Returns customers related to an email address, ordered descending by customer (technical) IDs.
   * If the subscription ID is provided and one of the customer is related to this subscription, put it as first element.
   * @param {string} email The email address.
   * @param {string} subscriptionId The subscription ID (optional).
   * @returns {{ id: string }[]} An array of customers.
   */
  static async getCustomers(email: string, subscriptionId?: string): Promise<{ entityid: string }[]> {

    // Build the query to retrieve the active customers related to the contact having the given email address.
    // Apply an ascending ordered on any matched subscription, before the default descending order on customer (technical) IDs.
    const queryStr = `
      SELECT DISTINCT sub.id AS subscription, cu.id, cu.entityid
      FROM contact co
      INNER JOIN customer cu ON cu.id = co.company
      LEFT JOIN subscription sub ON sub.customer = cu.id AND sub.id = ${sqlescape((subscriptionId ?? 0).toString())}
      WHERE LOWER(co.email) = '${sqlescape(email.toLowerCase())}'
        AND cu.isinactive = 'F'
      ORDER BY sub.id ASC, cu.id DESC
    `;

    // Run the query and return the result.
    const result = await NetsuiteClient.runSuiteQl(queryStr);
    return result.data.items.map((i: { entityid: string }) => ({ entityid: i.entityid }));
  }

  /**
   * Returns integration records by the id.
   * @param integrationId Integration Id
   * @returns Integration
   */
   static async getIntegrationById(integrationId: string) {
    const queryStr = `SELECT 
    pi.id,
    pi.custrecordproductfamilycode,
    pi.custrecordproductvariantcode,
    pi.custrecordproductfamilytitle,
    pi.custrecordproductvarianttitle,
    pi.custrecordsecret
  FROM
    customrecordproductintegration pi
  WHERE
  pi.id = '${sqlescape(integrationId)}'`;
    const nsResult = (await NetsuiteClient.runSuiteQl(queryStr)).data;
    return nsResult.items[0];
  }

  /**
   * Returns True if the email is related to an employee with the Self-Serve Portal Administrator role.
   * @param {string} email The email address of the user.
   * @returns True if the user is a super admin; oterhwise, False.
   */
  static async isSuperAdmin(email: string) {

    // Build the query checking the email.
    const query = `
      SELECT COUNT(*) as count
      FROM role r
      INNER JOIN EmployeeRolesForSearch er ON er.role = r.id
      INNER JOIN employee e ON e.id = er.entity
      WHERE r.scriptid = 'customrole_portal_admin'
        AND e.email = '${sqlescape(email)}'
    `;

    // Run the query, and return True only if there is at least one matching employee.
    const result = await NetsuiteClient.runSuiteQl(query);
    return result.data.items[0].count > 0;
  }

  static async runSuiteQl(queryStr: string) {
    return await NetsuiteClient.post(
      config.nsClientRestApiBaseUrl + "/query/v1/suiteql",
      {
        /* SELECT FROM SELECT is needed as a workaround for NetSuite errors */
        q: queryStr,
      }
    );
  }

}
