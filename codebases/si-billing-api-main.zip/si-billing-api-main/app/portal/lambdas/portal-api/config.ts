import {
  SSM,
} from "aws-sdk";
import { log } from "./log";

export interface PortalAuthConfig {
  sender: string;
  replyTo: string;
  subject: string;
}

/**
 * Portal API configuration parameters
 */
class Config {
  nsClientConsumerKey = process.env.NS_CONSUMER_KEY || "";
  nsClientConsumerSecret = process.env.NS_CONSUMER_SECRET || "";
  nsClientTokenKey = process.env.NS_TOKEN_KEY || "";
  nsClientTokenSecret = process.env.NS_TOKEN_SECRET || "";
  nsClientRealm = process.env.NS_CLIENT_REALM || "";
  nsClientRestApiBaseUrl = process.env.NS_CLIENT_REST_API_BASE_URL || "";
  nsCustomVersionAllowed = process.env.NS_CUSTOM_VERSION_ALLOWED !== "false";

  // Identifier of the Cognito User Pool
  userPoolId: string = "";
  // Name of the User table
  usersTableName: string = "";
  // AWS environment name
  awsEnvironment: string = "";
  // NetSuite environment name
  netSuiteEnvironment: string = "";

  // Keys for the cdk-user
  awsAccessKeyId: string = "";
  awsSecretAccessKey: string = "";

  // Free-form configuration object
  portalConfig: string = "{}";
  // SSM client for accessing the Parameters Store
  ssm = new SSM();

  /**
   * Load values from SSM parameter store
   */
  async loadParameters(): Promise<void> {
    log("process.env", process.env);
    this.userPoolId = process.env.USER_POOL_ID as string;

    this.usersTableName = process.env.TABLE_NAME ?? "";
    this.netSuiteEnvironment = process.env.NETSUITE_ENV_NAME ?? "";
    this.awsEnvironment = process.env.AWS_ENV_NAME ?? "";

    this.awsAccessKeyId =
      (
        await this.ssm
          .getParameter({
            Name: this.awsEnvironment + "-aws-access-key-id",
          })
          .promise()
      ).Parameter?.Value ?? "";
    this.awsSecretAccessKey =
      (
        await this.ssm
          .getParameter({
            Name: this.awsEnvironment + "-aws-secret-access-key",
            WithDecryption: true,
          })
          .promise()
      ).Parameter?.Value ?? "";

    process.env.NS_CONSUMER_KEY =
      (
        await this.ssm
          .getParameter({
            Name: "ns-" + this.netSuiteEnvironment + "-consumer-key",
          })
          .promise()
      ).Parameter?.Value ?? "";
    process.env.NS_CONSUMER_SECRET =
      (
        await this.ssm
          .getParameter({
            Name: "ns-" + this.netSuiteEnvironment + "-consumer-secret",
            WithDecryption: true,
          })
          .promise()
      ).Parameter?.Value ?? "";
    process.env.NS_TOKEN_KEY =
      (
        await this.ssm
          .getParameter({
            Name: "ns-" + this.netSuiteEnvironment + "-token-key",
          })
          .promise()
      ).Parameter?.Value ?? "";
    process.env.NS_TOKEN_SECRET =
      (
        await this.ssm
          .getParameter({
            Name: "ns-" + this.netSuiteEnvironment + "-token-secret",
            WithDecryption: true,
          })
          .promise()
      ).Parameter?.Value ?? "";
    process.env.NS_CLIENT_REALM =
      (
        await this.ssm
          .getParameter({
            Name: "ns-" + this.netSuiteEnvironment + "-realm",
          })
          .promise()
      ).Parameter?.Value ?? "";
    process.env.NS_CLIENT_REST_API_BASE_URL =
      (
        await this.ssm
          .getParameter({
            Name: "ns-" + this.netSuiteEnvironment + "-rest-api-base-url",
          })
          .promise()
      ).Parameter?.Value ?? "";

    this.nsClientConsumerKey = process.env.NS_CONSUMER_KEY || "";
    this.nsClientConsumerSecret = process.env.NS_CONSUMER_SECRET || "";
    this.nsClientTokenKey = process.env.NS_TOKEN_KEY || "";
    this.nsClientTokenSecret = process.env.NS_TOKEN_SECRET || "";
    this.nsClientRealm = process.env.NS_CLIENT_REALM || "";
    this.nsClientRestApiBaseUrl = process.env.NS_CLIENT_REST_API_BASE_URL || "";
    this.nsCustomVersionAllowed =
      process.env.NS_CUSTOM_VERSION_ALLOWED !== "false";

    this.portalConfig =
      (
        await this.ssm
          .getParameter({
            Name: "self-serve-portal-config",
          })
          .promise()
      ).Parameter?.Value ?? "";
  }

  async savePortalConfig(str: string): Promise<void> {
     await this.ssm
      .putParameter({
        Name: "self-serve-portal-config",
        Value: JSON.stringify(JSON.parse(str), null, 2), // Prettify the object (and check it's structure)
        Overwrite: true,
        Type: "String",
      })
      .promise();
  }

  /**
   * Returns the configuration for the authentication to the portal.
   * @returns The configuration for the authentication to the portal.
   */
  async getPortalAuthConfig(): Promise<PortalAuthConfig> {
    return await this.getSsmParameterValueAsJsonAsync('self-serve-portal-auth-config');
  }

  /**
   * Returns the value of the given parameter from the SSM parameter store.
   * @param {string} name The parameter name.
   * @returns {string} The parameter value.
   */
  private async getSsmParameterValueAsync(name: string): Promise<string> {

    // Retrieve the parameter.
    const response = await this.ssm.getParameter({
      Name: name,
    }).promise();

    // Validate the parameter is defined, then return the value.
    if (!response?.Parameter?.Value) {
      throw new Error(`Missing SSM parameter '${name}'.`);
    }
    return response.Parameter.Value;
  }

  /**
   * Returns the value of the given parameter from the SSM parameter store as a JSON.
   * @param {string} name The parameter name.
   * @returns {T} The parameter value as type T.
   */
  private async getSsmParameterValueAsJsonAsync<T>(name: string): Promise<T> {
    const value = await this.getSsmParameterValueAsync(name);
    try {
        return JSON.parse(value);
    } catch(e) {
        throw new Error('Invalid SSM parameter. Expect JSON.');
    }
  }
}

export default new Config();
