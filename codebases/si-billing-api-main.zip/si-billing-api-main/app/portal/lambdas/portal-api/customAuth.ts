import { AWSError, CognitoIdentityServiceProvider, KMS, SES } from "aws-sdk";
import qs from 'querystring';
import config from "./config";

const _cognito = new CognitoIdentityServiceProvider();
const _kms = new KMS();
const _ses = new SES({ region: process.env.AWS_REGION });

const AUTH_KEY_ID = process.env.AUTH_KEY_ID ?? '';
const USER_POOL_ID = process.env.USER_POOL_ID ?? '';
const USER_POOL_CLIENT_ID = process.env.USER_POOL_CLIENT_ID ?? '';
const DEFAULT_TIMEOUT = 15 * 60 * 1000;

export interface User {

    /**
     * The email of the user.
     */
    email: string;

    /**
     * The first name of the user.
     */
    firstName?: string;

    /**
     * Whether the user is a super administrator.
     */
    isSuperAdmin: boolean;

    /**
     * The list of customer IDs related to the user.
     */
    customerIds: string[];
  }

export interface SignupParams {

    /**
     * The base URL for generating the authentication link.
     */
    baseUrl: string;

    /**
     * The user details.
     */
    user: User;

    /**
     * The identifier of a specific subscription.
     */
    subscriptionId?: string;
}

/**
 * Signs up the user with the given email and authentication token.
 * - Generate an authentication token.
 * - Update the user attributes. If the user doesn't exist, create it.
 * - Generate an authentication link and send it.
 * @param {SignupParams} params The parameters for signing up.
 */
export const signup = async (params: SignupParams): Promise<void> => {
    const authToken = await createAuthToken(params);
    await upsertUser(params, authToken);  
    await sendAuthLink(params, authToken);
}

/**
 * Creates the authentication token based on the email.
 * @param {SignupParams} params The parameters for signing up.
 * @returns {string} The authentication token.
 */
async function createAuthToken(params: SignupParams): Promise<string> {
    
    // Create the payload.
    const expiration = new Date(new Date().getTime() + DEFAULT_TIMEOUT);
    const payload = {
        email: params.user.email,
        expiration: expiration.toJSON()
    };

    // Create the token by encrypting the payload.
    const token = await encrypt(JSON.stringify(payload));
    return token;
}

/**
 * Encrypts a given text.
 * @param {string} text The text to encrypt.
 * @returns {string} The encrypted text.
 */
async function encrypt(text: string): Promise<string> {
    
    // Encrypt the given text.
    const encryptResponse = await _kms.encrypt({
        KeyId: AUTH_KEY_ID,
        Plaintext: text,
    }).promise();

    // Return the encrypted text as base64 text.
    if (encryptResponse.CiphertextBlob) {
        const token = Buffer.from(encryptResponse.CiphertextBlob).toString('base64');
        return token;
    } else {
        throw new Error('Encryption failed.');
    }    
}

/**
 * Sends the authentication link to the user.
 * @param {SignupParams} params The parameters for signing up.
 * @param {string} authToken The authentication token.
 */
async function sendAuthLink(params: SignupParams, authToken: string): Promise<void> {
    const authConfig = await config.getPortalAuthConfig();
    
    // Create the magic link.
    const subscriptionIdParam = params.subscriptionId ? `&subscriptionId=${params.subscriptionId}` : '';
    const authLink = `${params.baseUrl}/signin?email=${qs.escape(params.user.email)}${subscriptionIdParam}&token=${qs.escape(authToken)}`;
    
    // Build the message.
    const messageText = `
        <p>Hi${params.user.firstName ? ' '+params.user.firstName : ''},</p>
        <p>This email will help you get started on your contract renewal.</p>
        <p>Our renewal portal will walk you through everything you need to know and all the decisions you must make, step by step.</p>
        <p>As you go through the steps of the software renewal wizard, we will make sure you are:</p>
        <p>
            <ul>
                <li>On the best version of the software.</li>
                <li>Benefiting from our Customer Success Program (called Platinum).</li>
                <li>Utilizing your “store credits” across our portfolio of products (called Prime).</li>
            </ul>
        </p>
        <p>Customers should complete their renewal process 30-60 days before that hard date to avoid last-minute stress.</p>
        <p><b>You can click the <a href="${authLink}" target="_blank">link</a> to sign into the Renewal Portal.</b></p>
        <p>If you have any questions or concerns, contact <a href="mailto:${authConfig.replyTo}">${authConfig.replyTo}</a>.</p>
    `;

    // Send an email with the magic link.
    await _ses.sendEmail({
        Source: authConfig.sender,
        ReplyToAddresses: [ authConfig.replyTo ],
        Destination: {
            ToAddresses: [ params.user.email ],
        },
        Message: {
            Subject: {
                Data: authConfig.subject,
            },
            Body: {
                Html: {
                    Data: messageText,
                },
            },
        },
    }).promise();
};

/**
 * Upserts a user in the user pool. If the user already exists, updates the user attributes.
 * @param {SignupParams} params The parameters for signing up.
 * @param {string} authToken The authentication token.
 */
async function upsertUser(params: SignupParams, authToken: string): Promise<void> {

    // Prepare params.
    const getUserParams = {
        UserPoolId: USER_POOL_ID,
        Username: params.user.email,
    };
    const updateUserParams = {...getUserParams,
        UserAttributes: [
            { Name: 'custom:authChallenge', Value: authToken },
            { Name: 'custom:customerIds', Value: JSON.stringify(params.user.customerIds) },
            { Name: 'custom:isSuperAdmin', Value: params.user.isSuperAdmin.toString()},
        ],
    };

    // Try to get the user from the user pool.
    // - If the user exists, update the user attributes.
    // - If the user does not exist, create it.
    // - If there is an unexpected error, throw it.
    try {        
        await _cognito.adminGetUser(getUserParams).promise();
        await _cognito.adminUpdateUserAttributes(updateUserParams).promise();
    } catch (error) {      
        const code = (error as AWSError)?.code; 
        if (code === 'UserNotFoundException') {
            const createUserParams = {
                ...getUserParams,
                DesiredDeliveryMediums: [],
                MessageAction: 'SUPPRESS',
                UserAttributes: [
                    ...updateUserParams.UserAttributes,
                    { Name: 'email', Value: params.user.email },
                    { Name: 'email_verified', Value: 'true' },
                ],
            };
            await _cognito.adminCreateUser(createUserParams).promise();
        } else {
            throw error;
        }
    }
};

/**
 * Signs in the user with the given email and authentication token.
 * @param {string} email The email of the user.
 * @param {string} authToken The authentication token.
 * @returns {CognitoIdentityServiceProvider.AuthenticationResultType | undefined} The authentication result. If undefined, the authentication failed.
 */
export const signin = async(email: string, authToken: string): Promise<CognitoIdentityServiceProvider.AuthenticationResultType | undefined> => {
    try {
        // Initiate the authentication flow.
        const signInResponse = await _cognito.initiateAuth({
            AuthFlow: 'CUSTOM_AUTH',
            ClientId: USER_POOL_CLIENT_ID,
            AuthParameters: {
                USERNAME: email,
            },
        }).promise();

        // Submit the challenge answer.
        const submitChallengeResponse = await _cognito.respondToAuthChallenge({
            ChallengeName: 'CUSTOM_CHALLENGE',
            ClientId: USER_POOL_CLIENT_ID,
            ChallengeResponses: {
                USERNAME: email,
                ANSWER: authToken,
            },
            Session: signInResponse.Session,
        }).promise();

        // Return the result.
        return submitChallengeResponse.AuthenticationResult;

    } catch(error) {

        // If the authentication flow is not authorized or failed, consider the authentication failed.
        return undefined;
    }
};
