import { APIGatewayProxyEvent, APIGatewayProxyResult } from "aws-lambda";
import config from "./config";
import * as jwt from "jsonwebtoken";
import { log } from "./log";
import NetsuiteClient from "./NetsuiteClient";
import { User, signin, signup } from "./customAuth";
import HttpStatus from "http-status-codes";

const MESSAGE_SUPER_ADMIN_ROLE_REQUIRED = "You need to have Super Admin rights to do the operation";

/**
 * Response headers (JSON, CORS enabled)
 */
const resHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "*",
  "Content-Type": "applicaton/json",
};

/**
 * Map resources to processing functions
 */
const paths = new Map<string, Function>([
  ["get_customer", getCustomerResponse],
  ["get_jwt", getJwtResponse],
  ["get_integrations", getProductIntegrationsResponse],
  ["get_user", getUserResponse],
  ["get_config", getPortalConfigResponse],
  ["put_config", putPortalConfigResponse],
  ["post_signup", postSignupResponse],
  ["post_signin", postSigninResponse],
]);

/**
 * Lambda entry point
 */
export async function handler(
  event: APIGatewayProxyEvent
): Promise<APIGatewayProxyResult> {

  // Load values from the Parameter Store
  await config.loadParameters();
  log("Portal API config", config);

  // Retrieve the method and invoke it.
  const method = `${event.httpMethod}_${event.resource.substring(1)}`.toLowerCase();
  if (paths.has(method)) {
    return (paths.get(method) as Function)(event);
  }

  // The method is not implemented.
  return badRequest(`The method {${method}} is not implemented.`);
}

/**
 * Processes GET /customer request.
 * @param {APIGatewayProxyEvent} event The request event.
 * @returns {APIGatewayProxyResult} The customer resource.
 */
export async function getCustomerResponse(event: APIGatewayProxyEvent) : Promise<APIGatewayProxyResult> {

  // The operation is allowed only for super admins.
  const isSuperAdmin = getIsSuperAdmin(event);
  if (!isSuperAdmin) {
    return forbidden(MESSAGE_SUPER_ADMIN_ROLE_REQUIRED);
  }

  // Retrieve the search criteria. At least one ID must be provided.
  const id = getQueryStringParameter(event, 'id');
  const internalId = getQueryStringParameter(event, 'internalId');
  if (!id && !internalId) {
    return badRequest('Missing ID or internal ID.');
  }
  if (internalId && isNaN(parseInt(internalId))) {
    return badRequest('Internal ID must be a number.');
  }

  // Load the customer details.
  const customer = await NetsuiteClient.getCustomer(id, parseInt(internalId));
  if (customer) {
    return success(JSON.stringify(customer));
  }
  return notFound();
}

/**
 * Process JWT request
 * @returns Jwt for Sales Infrastructure API
 */
async function getJwtResponse(
  event: APIGatewayProxyEvent
): Promise<APIGatewayProxyResult> {

  // Retrieve the customer ID and validate its value against the user context if needed.
  const customerIdResult = getCustomerId(event);
  if (customerIdResult.error) {
    return customerIdResult.error;
  }
  const customerId = customerIdResult.value as string;

  // Retrieve the integration and validate its value against the user context if needed.
  const integrationResult = await getIntegrationAsync(event, customerId);
  if (integrationResult.error) {
    return integrationResult.error;
  }
  const integration = integrationResult.value;

  // Build the token, and return it.
  const tokenPayload = {
    pfc: integration.custrecordproductfamilycode,
    pvc: integration.custrecordproductvariantcode,
    cid: customerId,
    sub: `portal-${event.requestContext.authorizer?.claims['cognito:username']}`,
    email: event.requestContext.authorizer?.claims['email'],
  };
  log("tokenPayload", tokenPayload);
  const token = jwt.sign(tokenPayload, integration.custrecordsecret);
  return success(JSON.stringify(token));
}

/**
 * Process Get User request
 */
async function getUserResponse(
  event: APIGatewayProxyEvent
): Promise<APIGatewayProxyResult> {
  try {
    // Try to retrieve the user attributes, then return them.    
    const attributes = getUserAttributes(event);
    log("attributes", attributes);
    return success(JSON.stringify(attributes));
  } catch (e) {
    // If an error occurs, return a generic error message.
    const message = "Error getting the user information";
    log(message, e);
    return error(message);
  }
}

/**
 * Returns the customer ID based on the request event.
 * @param {APIGatewayProxyEvent} event
 * @returns { value?: string, error?: HttpResponse } The customer ID value, or the error.
 */
function getCustomerId(event: APIGatewayProxyEvent): { value?: string, error?: HttpResponse } {

  // Retrieve the customer ID from the query string parameters.
  const customerId = getQueryStringParameter(event, "customerId");
  if (!customerId) {
    return { error: badRequest("customerId is required") };
  }

  // If the user is not a super admin, validate it against the authorized customer IDs for the current user.
  const isSuperAdmin = getIsSuperAdmin(event);
  if (!isSuperAdmin) {
    const customerIds = getCustomerIds(event);
    if (!customerIds.includes(customerId)) {
      return { error: unauthorized() };
    }
  }

  // Return the validated customer ID.
  return { value: customerId };
}

/**
 * Returns the authorized customer IDs for the current user. 
 * @param {APIGatewayProxyEvent} event
 * @returns The customer IDs.
 */
function getCustomerIds(event: APIGatewayProxyEvent): string[] {
  const customerIdsJson = event.requestContext.authorizer?.claims["custom:customerIds"].toString();
  return JSON.parse(customerIdsJson);
}

/**
 * Returns the integration based on the request event and the customer ID.
 * @param {APIGatewayProxyEvent} event
 * @param {string} customerId The customer ID.
 * @returns { value?: any, error?: HttpResponse } The integration value, or the error.
 */
async function getIntegrationAsync(event: APIGatewayProxyEvent, customerId: string): Promise<{ value?: any, error?: HttpResponse }> {

  // Retrieve the integration ID from the query string parameters.
  const integrationId = getQueryStringParameter(event, "integrationId");
  if (!integrationId) {
    return { error: notFound() };
  }

  // If the user is a super admin, load the integration with no validation.
  const isSuperAdmin = getIsSuperAdmin(event);
  if (isSuperAdmin) {
    return { value: await NetsuiteClient.getIntegrationById(integrationId) };
  }
  
  // Search from the integrations authorized for the current customer.
  const integrations = await NetsuiteClient.getCustomerIntegrations(customerId);
  const integration = integrations.items.find((i: any) => i.id === integrationId);
  if (integration) {
    return { value: integration };
  }
  return { error: notFound() };
}

/**
 * Returns true if the current user has the super admin role; otherwise, returns false.
 * @param event 
 * @returns 
 */
function getIsSuperAdmin(event: APIGatewayProxyEvent): boolean {
  const isSuperAdmin = event.requestContext.authorizer?.claims["custom:isSuperAdmin"];
  return isSuperAdmin?.toLowerCase() === 'true';
}

/**
 * Returns the user attributes for the current user.
 * @param {APIGatewayProxyEvent} event
 * @returns The user attributes.
 */
function getUserAttributes(event: APIGatewayProxyEvent): {
  isSuperAdmin: boolean,
  email: string,
  username: string,
  customerIds: string[]
} {
  const claims = event.requestContext.authorizer?.claims;
  return {
    isSuperAdmin: getIsSuperAdmin(event),
    email: claims['email'],
    username: claims['cognito:username'],
    customerIds: getCustomerIds(event),
  };
}

/**
 * Decode an URL parameter
 * @param str Encoded parameter
 * @returns Decoded parameter
 */
function decodeParam(str: string | undefined): string | undefined {
  if (str === undefined) {
    return undefined;
  }
  return decodeURIComponent(str);
}

/**
 * Return query parameter value with case insensitive name
 */
function getQueryStringParameter(event: any, paramName: string): string {
  const parameters = event["queryStringParameters"];
  if (!parameters) {
    // Return an empty string if the parameters are missing
    return (undefined as unknown) as string;
  }
  const paramExactName = Object.keys(parameters).find(
    (p) => p.toLowerCase() == paramName.toLowerCase()
  ) as string;
  log("getQueryStringParameter paramExactName", paramExactName);
  const paramValue = parameters[paramExactName];
  log("getQueryStringParameter paramValue", paramValue);
  return decodeParam(paramValue) as string;
}

/**
 * Process Get Products request
 */
async function getProductIntegrationsResponse(
  event: APIGatewayProxyEvent
): Promise<APIGatewayProxyResult> {

  // Retrieve input parameters.
  const customerIdResult = getCustomerId(event);
  if (customerIdResult.error) {
    return customerIdResult.error;
  }
  const customerId = customerIdResult.value as string;
  const subscriptionId = getQueryStringParameter(event, 'subscriptionId');

  // Retrieve the integrations for the given customer, then select subset of properties to expose.
  const integrations = await NetsuiteClient.getCustomerIntegrations(customerId, subscriptionId);
  log("getProductIntegrationsResponse integrations", integrations);
  const limitedFieldsList = integrations.items.map(
    (item: {
      id: any;
      custrecordproductfamilytitle: any;
      custrecordproductvarianttitle: any;
    }) => {
      return {
        id: item.id,
        custrecordproductfamilytitle: item.custrecordproductfamilytitle,
        custrecordproductvarianttitle: item.custrecordproductvarianttitle,
      };
    }
  );
  log("getProductIntegrationsResponse limitedFieldsList", limitedFieldsList);

  // Returns the integrations.
  return success(JSON.stringify(limitedFieldsList));
}

/**
 * Get Portal Config
 */
async function getPortalConfigResponse(): Promise<APIGatewayProxyResult> {
  return success(config.portalConfig);
}

/**
 * Save Portal Config
 */
async function putPortalConfigResponse(
  event: APIGatewayProxyEvent
): Promise<APIGatewayProxyResult> {

  // The operation is allowed only for super admins.
  const isSuperAdmin = getIsSuperAdmin(event);
  if (!isSuperAdmin) {
    return forbidden(MESSAGE_SUPER_ADMIN_ROLE_REQUIRED);
  }

  try {
    // Try to update the portal config.
    const portalConfig: string = event.body as string;
    await config.savePortalConfig(portalConfig);
    return noContent();
  } catch (e) {
    // If an error occurs, return a generic error message.
    const message = "Error saving the config";
    log(message, e);
    return error(message);
  }
}

/**
 * Processes POST /signup request.
 * @param {APIGatewayProxyEvent} event
 * @returns {APIGatewayProxyResult}
 */
async function postSignupResponse(
  event: APIGatewayProxyEvent
): Promise<APIGatewayProxyResult> {

  // Retrieve and validate input params.
  let params;
  try {
    params = JSON.parse(event.body ?? '{}');
  } catch(error) {
    return badRequest('The body is not a valid JSON.');
  }
  const baseUrl = params.baseUrl;
  if (!baseUrl) {    
    return badRequest('The "baseUrl" parameter is mandatory.');
  }
  const email = params.email;
  if (!email) {
    return badRequest('The "email" parameter is mandatory.');
  }
  const subscriptionId = params.subscriptionId;
  
  // Retrieve the customers and contact details based on the email address.
  // If the user is a super admin, skip this search.
  let user: User = {
    email,
    isSuperAdmin: await NetsuiteClient.isSuperAdmin(email),
    customerIds: [],
  };
  if (!user.isSuperAdmin) {
    const customers = await NetsuiteClient.getCustomers(email, subscriptionId);
    if (!customers.length) {
      // The user is unauthorized, but a success status code is returned on purpose.
      // This prevents an attacker to exploit the response for deducing which email addresses are defined in our system and which are not.
      return accepted();
    }
    user.customerIds = customers.map((c: { entityid: string }) => c.entityid);
    user = {
      ...user,
      ...await NetsuiteClient.getContactDetails(email, user.customerIds)
    };
  }

  // Signup the user.
  await signup({ baseUrl, user, subscriptionId });

  // Return Accepted response.
  return accepted();
}

/**
 * Processes POST /signin request.
 * @param {APIGatewayProxyEvent} event
 * @returns {APIGatewayProxyResult}
 */
async function postSigninResponse(
  event: APIGatewayProxyEvent
): Promise<APIGatewayProxyResult> {

  // Retrieve and validate input params.
  let params;
  try {
    params = JSON.parse(event.body ?? '{}');
  } catch(error) {
    return badRequest('The body is not a valid JSON.');
  }
  const email = params.email;
  if (!email) {
    return badRequest('The "email" parameter is mandatory.');
  }
  const token = params.token;
  if (!token) {
    return badRequest('The "token" parameter is mandatory.');
  }

  // Signin the user and return the challenge result if any; otherwise, return Unauthorized response.
  const challengeResult = await signin(email, token);
  return challengeResult ? success(JSON.stringify(challengeResult)) : unauthorized();
}

type HttpResponse = {
  statusCode: number,
  headers: {},
  body: string,
};

function response(statusCode: number, body?: string): HttpResponse {
  return {
    statusCode: statusCode,
    headers: resHeaders,
    body: body ?? '',
  };
}

function success(body?: string): HttpResponse {
  return response(HttpStatus.OK, body);
}

function accepted(): HttpResponse {
  return response(HttpStatus.ACCEPTED);
}

function noContent(): HttpResponse {
  return response(HttpStatus.NO_CONTENT);
}

function badRequest(message?: string): HttpResponse {
  return response(HttpStatus.BAD_REQUEST, JSON.stringify({
    success: false,
    message: message ?? 'Bad Request',
  }));
}

function unauthorized(): HttpResponse {
  return response(HttpStatus.UNAUTHORIZED);
}

function forbidden(message?: string): HttpResponse {
  return response(HttpStatus.FORBIDDEN, JSON.stringify({
    success: false,
    message: message ?? 'Forbidden',
  }));
}

function notFound(): HttpResponse {
  return response(HttpStatus.NOT_FOUND);
}

function error(message?: string): HttpResponse {
  return response(HttpStatus.INTERNAL_SERVER_ERROR, JSON.stringify({
    success: false,
    message: message ?? 'Internal Server Error',
  }));
}
