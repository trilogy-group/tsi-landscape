import pino from "pino";

const logger = pino();
/**
 * Insert a log entry
 * @param title Log entry title
 * @param message  Message containing details
 */
export function log(title: string, message: any) {
    logger.info({ title: title, message: message });
}

