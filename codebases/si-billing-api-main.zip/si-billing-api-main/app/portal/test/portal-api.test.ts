/// <reference path="../lambdas/portal-api/sql-escape.d.ts" />

import NetsuiteClient from "../lambdas/portal-api/NetsuiteClient";
import { getCustomerResponse } from "../lambdas/portal-api/index";

function mockEvent(claims: any, queryStringParameters: any = {}): any {
    return {
        queryStringParameters,
        requestContext: {
            authorizer: {
                claims,
            },
        },
    };
}

function isSuperAdminClaim(value: boolean): any {
    return {
        "custom:isSuperAdmin": `${value.toString()}`,
    };
}

describe("getCustomerResponse", () => {

    it("should return 401 Forbidden when the user is not a super admin", async () => {
        // Arrange
        const event = mockEvent(
            { ...isSuperAdminClaim(false) }
        );

        // Act
        const result = await getCustomerResponse(event);

        // Assert
        expect(result.statusCode).toEqual(403);
        expect(result.body).toEqual(JSON.stringify({ success: false, message: "You need to have Super Admin rights to do the operation" }));
    });

    it("should return 400 Bad Request when the ID and the internal ID are missing", async () => {
        // Arrange
        const event = mockEvent(
            { ...isSuperAdminClaim(true) },
            {}
        );

        // Act
        const result = await getCustomerResponse(event);

        // Assert
        expect(result.statusCode).toEqual(400);
        expect(result.body).toEqual(JSON.stringify({ success: false, message: "Missing ID or internal ID." }));
    });

    it("should return 400 Bad Request when the internal ID is not a number", async () => {
        // Arrange
        const event = mockEvent(
            { ...isSuperAdminClaim(true) },
            { internalId: "not a number" }
        );

        // Act
        const result = await getCustomerResponse(event);

        // Assert
        expect(result.statusCode).toEqual(400);
        expect(result.body).toEqual(JSON.stringify({ success: false, message: "Internal ID must be a number." }));
    });

    it("should return 404 Not Found when the customer is not found", async () => {
        // Arrange
        const event = mockEvent(
            { ...isSuperAdminClaim(true) },
            { internalId: "1" }
        );
        jest.spyOn(NetsuiteClient, "runSuiteQl").mockReturnValueOnce(Promise.resolve({
            data: {
                items: [],
            },
        }));

        // Act
        const result = await getCustomerResponse(event);

        // Assert
        expect(result.statusCode).toEqual(404);
    });

    it("should return the customer details when the customer is found by ID", async () => {
        // Arrange        
        const customer = { id: "101", internalId: "201" };
        const event = mockEvent(
            { ...isSuperAdminClaim(true) },
            { id: customer.id }
        );
        jest.spyOn(NetsuiteClient, "runSuiteQl").mockReturnValueOnce(Promise.resolve({
            data: {
                items: [ { entityid: customer.id, id: customer.internalId } ],
            },
        }));

        // Act
        const result = await getCustomerResponse(event);

        // Assert
        expect(result.statusCode).toEqual(200);
        expect(result.body).toEqual(JSON.stringify(customer));
    });

    it("should return the customer details when the customer is found by internal ID", async () => {
        // Arrange        
        const customer = { id: "101", internalId: "201" };
        const event = mockEvent(
            { ...isSuperAdminClaim(true) },
            { internalId: customer.internalId }
        );
        jest.spyOn(NetsuiteClient, "runSuiteQl").mockReturnValueOnce(Promise.resolve({
            data: {
                items: [ { entityid: customer.id, id: customer.internalId } ],
            },
        }));

        // Act
        const result = await getCustomerResponse(event);

        // Assert
        expect(result.statusCode).toEqual(200);
        expect(result.body).toEqual(JSON.stringify(customer));
    });
});
