# SI Subscription API server
This server's goal is to authorize, validate requests and then proxy them to Netsuite restlets with actual business logic.

It is an express-based server. For production it will be wrapped in a `aws-serverless-express` and deployed to AWS Lambda.

## Quick Start

Get started developing...

```shell
# install deps
npm install

# run in development mode
npm run watch

# run tests
npm run test

# run e2e tests
npm run e2e
```

## How do I modify the example API and make it my own?

There are two key files:
1. `server/routes.ts` - This references the implementation of all of your routes. Add as many routes as you like and point each route your express handler functions.
2. `server/src/common/api.yml` - This file contains your [OpenAPI spec](https://swagger.io/specification/). Describe your API here. It's recommended that you to declare any and all validation logic in this YAML. `express-no-stress-typescript`  uses [express-openapi-validator](https://github.com/cdimascio/express-openapi-validator) to automatically handle all API validation based on what you've defined in the spec.

## Testing

There are unit and e2e tests. Both use jest. E2E tests use real Netsuite sandbox.

### Unit tests
Placed in tests/*. See examples in that folder.
Run the unit tests

```shell
npm run test

# or to run particular test
npm run test -- test/util.test.ts -t defaultIfBlank
```

### E2E tests
See example in 'e2e' folder.

To configure
Edit the .env file in the app\server\ folder.
Ensure to fill the TBA fields which are empty by default (NS_CONSUMER_KEY, NS_CONSUMER_SECRET, NS_TOKEN_KEY,NS_TOKEN_SECRET). The secrets are in [passwordstate](https://passwordstate.devfactory.com/) in the 'NetSuite SB2 KEYS' item.

Sample .env file content:
```LOG_LEVEL = debug
OPENAPI_ENABLE_RESPONSE_VALIDATION = true
NS_CUSTOM_VERSION_ALLOWED=true
NS_CONSUMER_KEY =    'f3e6...........................52c9'
NS_CONSUMER_SECRET = '25d5...........................c9f2b'
NS_TOKEN_KEY =       '3214...........................efbbb'
NS_TOKEN_SECRET =    '54f7...........................3556f'
NS_CLIENT_REALM = '4914352_SB2'
NS_CLIENT_RESTLET_BASE_URL = 'https://4914352-sb2.restlets.api.netsuite.com/app/site/hosting/restlet.nl'
NS_CLIENT_REST_API_BASE_URL = 'https://4914352-sb2.suitetalk.api.netsuite.com/services/rest'
```

To run
```shell
npm run e2e

# or to run particular test
npm run e2e -- e2e/integration-product.test.ts -t checkTestData

# to run the e2e tests in a specific environment add export PACKAGE_VERSION=<env> before the e2e command
export PACKAGE_VERSION=qc; npm run e2e -- e2e/integration-product.test.ts -t checkTestData
```



## Run locally
* `npm run watch`
* Open your browser to [http://localhost:3000](http://localhost:3000)

#### Debug with VSCode

Add these [contents](https://github.com/cdimascio/generator-express-no-stress/blob/next/assets/.vscode/launch.json) to your `.vscode/launch.json` file
