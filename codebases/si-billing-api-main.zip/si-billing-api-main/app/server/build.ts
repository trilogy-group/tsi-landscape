import s from 'shelljs';
import config from './tsconfig.json';
const outDir = config.compilerOptions.outDir;
const copyNodeModules = require('copy-node-modules');

s.rm('-rf', outDir);
s.mkdir(outDir);
s.cp('.env', `${outDir}/.env`);
s.mkdir('-p', `${outDir}/common/swagger`);
s.cp('src/common/api.yml', `${outDir}/common/api.yml`);
//s.cp('lambda-express-proxy/*', `${outDir}`);
s.cp('-r', 'static', `${outDir}/static`);
copyNodeModules('.', `${outDir}`, () => {
  console.log('done');
});
