import * as fs from 'fs';
// Get environment from the variable (GitHub action)
// Similarly to what we have in ApiProxy deployment
const nsEnv = process.env.NS_SANDBOX_ENVIRONMENT;
const environmentFileName = '.env';
const envTtlInSeconds = 30;
if (nsEnv) {
  let shouldWriteFile = true;
  if (fs.existsSync(environmentFileName)) {
    const stats = fs.statSync(environmentFileName);
    const today = new Date();
    const secondsFromModification = (today.getTime() - stats.mtime.getTime()) / 1000;
    shouldWriteFile = secondsFromModification > envTtlInSeconds;
  }
  // If the file is too old or does not exist, create or update it
  if (shouldWriteFile) {
    fs.writeFileSync(environmentFileName, nsEnv + '\nNS_CUSTOM_VERSION_ALLOWED=true\n');
  }
}
import 'dotenv/config';

process.env.TZ = 'America/Los Angeles'; // To avoid any timezone issues

import { ProjectConfig } from '@jest/types/build/Config';
import NodeEnvironment from 'jest-environment-node';
import NetsuiteRestletClient from '../..//src/api/services/NetsuiteRestletClient';
import { NSTestUtils } from './NSTestUtils';
import { TestDataRequest } from './TestData';
import { E2EExtension, TestData } from './testtypes';
import logger from '../../src/common/logger';

export default class E2EjestEnvironment extends NodeEnvironment {
  constructor(config: ProjectConfig) {
    super(config);
  }

  async setup(): Promise<void> {
    const version = process.env.PACKAGE_VERSION || 'main';
    logger.info(`Worker ${process.env.JEST_WORKER_ID} started using NS version ${version}`);
    const testStaticDataResponse = await NetsuiteRestletClient.post(
      `script=customscript_si_${version}_tdata_restlet&deploy=customdeploy_si_${version}_tdata`,
      JSON.stringify(TestDataRequest)
    );
    if (testStaticDataResponse.data.error) {
      throw new Error(testStaticDataResponse.data.error);
    }
    if (testStaticDataResponse.data.msg !== 'OK') {
      throw new Error(JSON.stringify(testStaticDataResponse.data.msg));
    }
    const e2eTestData = testStaticDataResponse.data.data as TestData;
    e2eTestData.uniqueNumber = new Date().getTime();
    e2eTestData.trialConfig = TestDataRequest.trialConfig;

    const testUtils = new NSTestUtils(e2eTestData);

    const e2eExt: E2EExtension = { testData: e2eTestData, testUtils: testUtils, version: version };
    this.global.e2e = e2eExt;
  }
}
