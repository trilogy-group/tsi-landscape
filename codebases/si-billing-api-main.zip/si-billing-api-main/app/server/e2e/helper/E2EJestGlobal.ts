import { E2EExtension } from './testtypes';

declare global {
  const e2e: E2EExtension;
}

export {};
