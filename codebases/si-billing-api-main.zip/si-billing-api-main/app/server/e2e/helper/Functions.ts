// import global e2e obj
import './E2EJestGlobal';
import request from 'supertest';
import tsiapp from '../../src/tsiappe2e';
import { makeNSMainClient } from '../../src/api/services/NSMainClient';
import NetsuiteClient from '../../src/api/services/NetsuiteClient';
import { toBeDeepCloseTo } from 'jest-matcher-deep-close-to';
import logger from '../../src/common/logger';
import exp from 'constants';
import { ChargeFrequency } from '../../../../netsuite/src/ts/types';

expect.extend({ toBeDeepCloseTo });
/**
 * print the name of the file being run
 */
export function printFileName(): void {
  //FIXME: change to use https://nodejs.org/api/path.html#pathbasenamepath-ext
  const parts = expect.getState().testPath.split('\\');
  printWithWorker(`starting file ${parts[parts.length - 1]}`);
}

/**
 * print the name of the test being run
 */
export function printTestName(): void {
  printWithWorker(`executing ${expect.getState().currentTestName}`);
}

function printWithWorker(msg) {
  logger.info(`Worker ${process.env.JEST_WORKER_ID} ${msg}`);
}

function _findLast<T>(arr: Array<T>, check: (T) => boolean): T | null {
  let prev: T | null = null;
  for (const v of arr) {
    if (!check(v)) {
      return prev;
    } else {
      prev = v;
    }
  }
  return prev;
}

function _calcPriceAmount(tierType: string, tierPrice: number, quantity: number): number {
  if ('Rate' === tierType) {
    return tierPrice * quantity;
  } else if ('FixedAmount' === tierType) {
    return tierPrice;
  } else {
    throw new Error('Invalid tier type');
  }
}

function _calcTieredPriceAmount(priceRanges, quantity: number) {
  let curPrice = 0;
  let prevTier: { type: string; price: number; fromQuantity: number } | null = null;
  for (const tier of priceRanges) {
    if (quantity <= tier.fromQuantity) {
      break;
    }
    if (prevTier !== null) {
      curPrice += _calcPriceAmount(prevTier.type, prevTier.price, tier.fromQuantity - prevTier.fromQuantity);
    }
    prevTier = tier;
  }
  if (prevTier !== null) {
    curPrice += _calcPriceAmount(prevTier.type, prevTier.price, quantity - prevTier.fromQuantity);
  }

  return curPrice;
}

/**
 * calc total price of an item
 * @param item to be calculated the total price
 * @param quantity of the item
 * @param currency of the item
 * @param frequency of the item
 * @returns price
 */
export function calPlanItemTotalPrice(item, quantity: number, currency: string, frequency?: string): number {
  if (quantity === 0) {
    return 0;
  }
  const price = item.prices.find(
    (p) =>
      p.currency === currency && (p.frequency?.toLowerCase() === frequency?.toLowerCase() || p.frequency === 'ONETIME')
  );
  if (!price) {
    throw new Error('No prices for specified frequency');
  }

  if (price.type === 'Volume') {
    const tier = _findLast(
      price.ranges as { type: string; price: number; fromQuantity: number }[],
      (t) => t.fromQuantity <= quantity
    );
    if (!tier) {
      throw new Error('Cannot find applicable tier');
    }

    return _calcPriceAmount(tier.type, tier.price, quantity);
  } else if (price.type === 'Tiered') {
    return _calcTieredPriceAmount(price.ranges, quantity);
  } else {
    throw new Error(`Invalid price type ${price.type}`);
  }
}

/**
 * calc total price of an item
 * @param item to be calculated the total price
 * @param quantity of the item
 * @param currency of the item
 * @param frequency of the item
 * @returns price
 */
export function calSubscriptionItemTotalPrice(item, quantity: number, frequency?: string): number {
  if (quantity === 0) {
    return 0;
  }
  const price = item.prices.find(
    (p) => p.frequency?.toLowerCase() === frequency?.toLowerCase() || p.frequency === 'ONETIME'
  );
  if (!price) {
    throw new Error('No prices for specified frequency');
  }

  if (price.type === 'Volume') {
    const tier = _findLast(
      price.ranges as { type: string; price: number; fromQuantity: number }[],
      (t) => t.fromQuantity <= quantity
    );
    if (!tier) {
      throw new Error('Cannot find applicable tier');
    }

    return _calcPriceAmount(tier.type, tier.price, quantity);
  } else if (price.type === 'Tiered') {
    return _calcTieredPriceAmount(price.ranges, quantity);
  } else {
    throw new Error(`Invalid price type ${price.type}`);
  }
}

/**
 * asserts if the term of the subscription mathces the term informed
 * @param planTerm with units and duration to be matched
 * @param subscriptionTerm with start and end date of the subscription
 * @param startDate needs to be informed if is not today
 */
export function assertTerm(planTerm, subscriptionTerm, startDate?: Date): void {
  if (!startDate) {
    startDate = localeDateToNetsuiteTimezone(new Date());
  }
  const endDate = new Date(startDate);
  switch (planTerm.unit.toLowerCase()) {
    case 'days':
      endDate.setDate(endDate.getDate() + planTerm.duration - 1);
      break;
    case 'months':
      endDate.setMonth(endDate.getMonth() + planTerm.duration);
      if (endDate.getDate() !== startDate.getDate()) {
        endDate.setDate(0);
      }
      endDate.setDate(endDate.getDate() - 1);
      break;
    case 'weeks':
      endDate.setDate(endDate.getDate() + planTerm.duration * 7 - 1);
      break;
    case 'years':
      endDate.setFullYear(endDate.getFullYear() + planTerm.duration);
      endDate.setDate(endDate.getDate() - 1);
      break;
  }
  expect(new Date(subscriptionTerm.start).getTime()).toBe(startDate.getTime());
  expect(new Date(subscriptionTerm.end).getTime()).toBe(endDate.getTime());
}

/**
 * Return the date in netsuite timezone
 */
export function localeDateToNetsuiteTimezone(date: Date): Date {
  const newDate = new Date(date.toLocaleString('en-US', { timeZone: 'America/Los_Angeles' }));
  newDate.setMinutes(newDate.getMinutes() - newDate.getTimezoneOffset());
  newDate.setHours(0, 0, 0, 0);
  return newDate;
}

/**
 * create subscription for the e2e customer
 * @param body with params to create subscription
 * @returns subscription created
 */
export async function createSubscription(body) {
  logger.debug(`createSubscription request body: ${JSON.stringify(body)}`);
  const res = await request(tsiapp.app())
    .post('/api/v1/subscription')
    .send(body)
    .set('Authorization', e2e.testUtils.makeCustomerJWTHeader(e2e.testData.customer.id))
    .expect(200);

  logger.debug(`createSubscription res: ${JSON.stringify(res.body)}`);
  expect(res.body).toMatchObject({
    id: expect.anything(),
  });

  return res.body;
}

/**
 * update subscription for the e2e customer
 * @param subscriptionId id of subscription
 * @param body with params to be sent to update
 * @returns subscription updated
 */
export async function updateSubscription(subscriptionId, body, expectedHttpStatus?: number) {
  logger.debug(`updateSubscription request id: ${subscriptionId}, body: ${JSON.stringify(body)}`);

  const res = await request(tsiapp.app())
    .put(`/api/v1/subscription/${subscriptionId}`)
    .send(body)
    .set('Authorization', e2e.testUtils.makeCustomerJWTHeader(e2e.testData.customer.id))
    .expect(expectedHttpStatus ? expectedHttpStatus : 200);

  logger.debug(`updateSubscription res: ${JSON.stringify(res.body)}`);
  return res.body;
}

/**
 * get subscription for the e2e customer
 * @param subscriptionId id of subscription
 * @returns subscription
 */
export async function getSubscription(subscriptionId) {
  logger.debug(`getSubscription request id: ${subscriptionId}`);
  const res = await request(tsiapp.app())
    .get(`/api/v1/subscription/${subscriptionId}`)
    .set('Authorization', e2e.testUtils.makeCustomerJWTHeader(e2e.testData.customer.id))
    .expect(200);

  expect(res.body).toBeTruthy();
  expect(res.body.id).toBeTruthy();
  expect(res.body.id).toBe(subscriptionId);
  logger.debug(`getSubscription res: ${JSON.stringify(res.body)}`);
  return res.body;
}

/**
 * Create quote for subscription
 */
export async function createQuote(
  params: {
    subscriptionId: number;
    quoteLineStartDates?: {
      line: string;
      startDate: string;
    }[];
    expiry?: string;
    salesRepId?: number;
    recipients?: {
      email: string;
      role: 'Signer' | 'CC';
    }[];
  },
  expectedHttpStatus?: number
): Promise<any> {
  logger.debug(`createQuote id: ${params.subscriptionId}`);
  const res = await request(tsiapp.app())
    .post(`/api/v1/quote`)
    .send(params)
    .set('Authorization', e2e.testUtils.makeCustomerJWTHeader(e2e.testData.customer.id))
    .expect(expectedHttpStatus ? expectedHttpStatus : 200);

  logger.debug(`createQuote res: ${JSON.stringify(res.body)}`);
  return res.body;
}

/**
 * Creates a self-serve quote for a given subscription.
 * @param params The quote parameters.
 * @param expectedHttpStatus The expected HTTP status code. The default value is 200.
 * @returns The response.
 */
export async function createSelfServeQuote(
  params: {
    subscriptionId: number;
    planCode: string;
    items: {
      code: string;
      quantity: number;
    }[];
    frequency: string;
    duration: number;
    recipients?: {
      email: string;
      role: string;
    }[];
  },
): Promise<any> {
  logger.debug(`createSelfServeQuote params: ${JSON.stringify(params)}`);
  const res = await request(tsiapp.app())
    .post(`/api/v1/quote/createForSelfServe`)
    .send(params)
    .set('Authorization', e2e.testUtils.makeCustomerJWTHeader(e2e.testData.customer.id));

  logger.debug(`createSelfServeQuote res: ${JSON.stringify(res)}`);
  return res;
}

/**
 * Accept quote
 */
export async function acceptQuote(quoteId: number, expectedHttpStatus?: number) {
  logger.debug(`acceptQuote id: ${quoteId}`);
  const res = await request(tsiapp.app())
    .post(`/api/v1/quote/${quoteId}/accept`)
    .send({
      acceptor: {
        name: 'Test Acceptor',
        jobTitle: 'Test Job',
        email: e2e.testUtils.customerTestEmail,
        phone: '111-1111-11',
      },
      ccEmail: 'cc@example.com',
    })
    .set('Authorization', e2e.testUtils.makeCustomerJWTHeader(e2e.testData.customer.id))
    .expect(expectedHttpStatus ?? 200);

  logger.debug(`acceptQuote res: ${JSON.stringify(res.body)}`);
  return res.body;
}

/**
 * Download quote
 */
export async function downloadQuote(quoteId: number, expectedHttpStatus?: number) {
  logger.debug(`downloadQuote id: ${quoteId}`);

  const expectedStatus = expectedHttpStatus ? expectedHttpStatus : 200;
  const downloadRes = await request(tsiapp.app())
    .get(`/api/v1/quote/${quoteId}/download`)
    .send()
    .set('Authorization', e2e.testUtils.makeCustomerJWTHeader(e2e.testData.customer.id))
    .expect(expectedStatus);

  if (expectedStatus === 200) {
    logger.debug(`Download res length ${downloadRes.body.length}`);
    expect(downloadRes.body.length).toBeGreaterThanOrEqual(1);
  }

  return downloadRes.body;
}

/**
 * get subscription plans for the e2e customer
 * @returns list of plan available for the e2e customer
 */
export async function getSubscriptionPlans() {
  const res = await request(tsiapp.app())
    .get('/api/v1/subscriptionPlans')
    .set('Authorization', 'Bearer ' + e2e.testUtils.makeJWT({ cid: e2e.testData.customer.id }))
    .expect(200);
  expect(res.body[0]).toBeTruthy();
  return res.body;
}

/**
 * activate a draft subscription without checking if quote is accepted and it has contractual documents
 * @param subscriptionId id of draft subscription
 */
export async function activateDraftUsingInternalProcess(subscriptionId) {
  const nsMainClient = makeNSMainClient(e2e.version);
  const data = {
    op: 'subscription.internalActivate',
    subscriptionId: subscriptionId,
  };
  const res = await NetsuiteClient.post(nsMainClient.restletUrl, data);
  expect(res.status).toBe(200);
}

/**
 * create a draft renewal subscription from an active subscription
 * @param subscriptionId id of active subscription
 * @returns draft renewal subscription
 */
export async function createDraftRenewal(subscriptionId) {
  const nsMainClient = makeNSMainClient(e2e.version);
  const data = {
    op: 'subscription.createDraftRenewal',
    subscriptionId: subscriptionId,
  };
  logger.debug(`createDraftRenewal body: ${JSON.stringify(data)}`);
  const res = await NetsuiteClient.post(nsMainClient.restletUrl, data);
  expect(res.status).toBe(200);
  logger.debug(`createDraftRenewal res: ${JSON.stringify(res.data.content)}`);
  expect(res.data.content).toBeTruthy();
  return res.data.content;
}

export interface AddonDiscount {
  code: string;
  discount: number;
}
export interface Discounts {
  mainDiscount: number;
  addons?: AddonDiscount[];
}
/**
 * Creates subscription and a draft renewal subscription with discount
 * Test api method.
 * @param createSubscriptionBody - create subscription body.
 * @param discounts - the discount value.
 */
export async function createRenewal(
  createSubscriptionBody,
  discounts: number | Discounts,
  mainItemCodes?: string[],
  addonCode?: string
): Promise<{ subscription: any; draftRenewal: any }> {
  const subscription = await createAndActivateSubscription(createSubscriptionBody);

  logger.debug(`createRenewal discount type: ${JSON.stringify(typeof discounts)}, value: ${JSON.stringify(discounts)}`);
  if (typeof discounts === 'number') {
    if (discounts !== 0) await modifyPrice(subscription.id, discounts);
  } else {
    logger.debug(`createRenewal mainItemCodes ${JSON.stringify(mainItemCodes)}, value: ${JSON.stringify(discounts)}`);
    if (mainItemCodes && discounts.mainDiscount) {
      await modifyPrice(subscription.id, discounts.mainDiscount, null, mainItemCodes);
    }
    if (addonCode && discounts.addons) {
      const addonDiscount = discounts.addons.find((i) => i.code == addonCode)?.discount;
      if (addonDiscount) {
        await modifyPrice(subscription.id, addonDiscount, null, [addonCode]);
      }
    }
  }

  const renewalSubscription = await createDraftRenewal(subscription.id);
  return { subscription: subscription, draftRenewal: renewalSubscription };
}

/**
 * Creates subscription and a draft renewal subscription with discount
 * Test api method.
 * Roger: added ShouldAssertTotals and shouldPreview to not assert preview now
 * this needs to be removed when preview subscription is updated
 * @param createSubscriptionBody - create subscription body.
 * @param updateSubscriptionBody - update subscription body.
 * @param discounts - the discount value.
 * @param discountPreview - the discount value for preview.
 * @param shouldAssertTotals - do assert total.
 * @param shouldPreview - do a preview API call.
 */
export async function createAndRenewDraft(
  createSubscriptionBody,
  updateSubscriptionBody,
  discounts: number | Discounts,
  subscriptionPlans,
  discountPreview: number | Discounts,
  mainItemCodes?: string[],
  addonCode?: string,
  expectedPreview?,
  expectedTotalIntervalValue?: number
): Promise<{ subscription: any; renewalSubscription: any }> {
  if (typeof discountPreview === 'number') {
    discountPreview = { mainDiscount: discountPreview };
  }
  const { subscription, draftRenewal } = await createRenewal(
    createSubscriptionBody,
    discounts,
    mainItemCodes,
    addonCode
  );

  const preview = await previewSubscriptionAndAssert(
    updateSubscriptionBody,
    subscriptionPlans,
    discountPreview,
    draftRenewal.id,
    expectedPreview
  );
  const draftSubscription = await updateSubscription(draftRenewal.id, updateSubscriptionBody);

  if (expectedTotalIntervalValue) assertTotalIntervalValues(expectedTotalIntervalValue, draftSubscription);
  else {
    assertTotals(preview, draftSubscription);
  }
  return { subscription, renewalSubscription: draftSubscription };
}

/**
 * Modifies price of the subscription
 * @param subscriptionId - subscription id.
 * @param discount - discount.
 * @param effectiveDate - effective date.
 * @param itemCodes - items.
 */
export async function modifyPrice(subscriptionId, discount: number, effectiveDate?, itemCodes?: string[]) {
  const nsMainClient = makeNSMainClient(e2e.version);
  const data: any = {
    op: 'subscription.modifyPrice',
    subscriptionId: subscriptionId,
    reducePercentage: discount,
  };
  if (effectiveDate) {
    data.effectiveDate = effectiveDate;
  }
  if (itemCodes) {
    data.itemCodes = itemCodes;
  }
  logger.debug(`modifyPrice body: ${JSON.stringify(data)}`);
  const res = await NetsuiteClient.post(nsMainClient.restletUrl, data);
  logger.debug(`modifyPrice response: ${JSON.stringify(res.data)}`);

  expect(res.status).toBe(200);
  expect(res.data.content).toBeTruthy();
}

/**
 * Set price of the subscription items
 * @param subscriptionId - subscription id.
 * @param discount - discount.
 * @param effectiveDate - effective date.
 * @param itemCodes - items.
 */
export async function setPrices(
  subscriptionId,
  items: {
    code: string;
    price: number;
  }[]
) {
  const nsMainClient = makeNSMainClient(e2e.version);
  const data: any = {
    op: 'subscription.internalSetPrice',
    subscriptionId: subscriptionId,
    items: items,
  };
  const res = await NetsuiteClient.post(nsMainClient.restletUrl, data);
  logger.debug(`res setPrices ${res}`);
  expect(res.status).toBe(200);
  expect(res.data.content).toBeTruthy();
}

/**
 * Asserts prices of the subscription
 */
export function checkPrices(
  planCode,
  subscriptionItems,
  discount: number | Discounts,
  subscriptionPlans,
  mainItemCodes?: string[]
) {
  const plan = subscriptionPlans.find((i) => i.code === planCode);
  for (const item of subscriptionItems) {
    const itemPlan = plan.items.find((i) => i.code === item.code);
    if (itemPlan) {
      const pricePlan = itemPlan.prices.find((i) => i.frequency === item.prices[0].frequency);
      expect(item.prices[0].type).toBe(pricePlan.type);
      for (const priceTier of item.prices[0].ranges) {
        const discnt: number | null | undefined =
          typeof discount === 'number'
            ? (discount as number)
            : mainItemCodes?.some((i) => item.code === i)
              ? discount.mainDiscount
              : discount.addons?.some((i) => i.code === item.code)
                ? discount.addons?.find((i) => i.code === item.code)?.discount
                : null;
        if (typeof discnt === 'undefined' || discnt === null) {
          throw new Error(
            `Can\'t find discount for item ${item.code}, discount: ${JSON.stringify(discount)}, item: ${JSON.stringify(
              item
            )}, mainItemCodes: ${JSON.stringify(mainItemCodes)}`
          );
        }

        const price = round(
          pricePlan.ranges.find((i) => i.fromQuantity === priceTier.fromQuantity).price * (1 - discnt)
        );
        logger.debug(`checkPrices item: ${item.code}, discount: ${discnt}, price: ${priceTier.price}`);
        expect(priceTier.price).toBeCloseTo(price, 2);
        logger.debug(`checkPrices expected: ${price}, actual: ${priceTier.price}`);
      }
    }
  }
}

/**
 * Calls /preview API method and asserts the result
 */
export async function previewSubscription(requestBody, subscriptionId?) {
  const subscriptionIdParam = subscriptionId ? '/' + subscriptionId : '';
  const res = await request(tsiapp.app())
    .post('/api/v1/subscription/preview' + subscriptionIdParam)
    .send(requestBody)
    .set('Authorization', e2e.testUtils.makeCustomerJWTHeader(e2e.testData.customer.id));
  return res;
}

/**
 * Calls /preview API method and asserts the result
 */
export async function previewSubscriptionAndAssert(
  requestBody,
  subscriptionPlans,
  discounts?: Discounts,
  subscriptionId?,
  expectedPreview?,
  isEvergreen = false
) {
  logger.debug(`previewSubscriptionAndAssert id: ${subscriptionId}, body: ${JSON.stringify(requestBody)}`);
  const subscriptionIdParam = subscriptionId ? '/' + subscriptionId : '';
  const res = await request(tsiapp.app())
    .post('/api/v1/subscription/preview' + subscriptionIdParam)
    .send(requestBody)
    .set('Authorization', e2e.testUtils.makeCustomerJWTHeader(e2e.testData.customer.id))
    .expect(200);

  logger.debug(`previewSubscriptionAndAssert response: ${JSON.stringify(res)}`);

  let expected;
  if (expectedPreview) {
    expected = expectedPreview;
  } else {
    expected = {
      frequency: requestBody.frequency,
      totalAmount: 0,
      items: [] as any[],
    };
    const plan = JSON.parse(JSON.stringify(subscriptionPlans.find((i) => i.code === requestBody.planCode)));

    for (const bodyItem of requestBody.items) {
      const responseBodyItem = res.body.items.find((i) => i.code === bodyItem.code);
      const quantity = bodyItem.quantity ? bodyItem.quantity : responseBodyItem.quantity;
      const planItem = plan.items.find((i) => i.code === bodyItem.code);
      if (planItem) {
        if (discounts) {
          const addonDiscount = discounts.addons?.find((i) => i.code === bodyItem.code);
          const discount = addonDiscount ? addonDiscount.discount : discounts.mainDiscount;
          applyDiscountInItem(planItem, discount);
        }
        const amount = calPlanItemTotalPrice(planItem, quantity, 'USD', requestBody.frequency);
        expected.totalAmount += amount;
        expected.items.push({
          code: bodyItem.code,
          title: planItem.title,
          quantity: quantity,
          amount: round(amount),
        });
      }
    }
    expected.totalAmount = round(expected.totalAmount);
  }
  if (isEvergreen) {
    //TODO: remove this when evergreen is updated
  }

  logger.debug(`actual: ${JSON.stringify(res.body)}`);
  logger.debug(`expected: ${JSON.stringify(expected)}`);

  expect(res.body).toEqual(expect.objectContaining(expected));
  return res.body;
}

/**
 * applyDiscountInItem
 */
function applyDiscountInItem(item, discount) {
  logger.debug(`applyDiscountInItem params: item: ${JSON.stringify(item)}, discount: ${JSON.stringify(discount)}`);
  for (const price of item.prices) {
    for (const tier of price.ranges) {
      tier.price = round(tier.price * (1 - discount));
    }
  }
}

/**
 * Gets total discount - combined original discount with uptick
 */
export function getDiscountWithUptick(discounts: number | Discounts, uptick: number): number | Discounts {
  if (typeof discounts === 'number') {
    return discounts - uptick + discounts * uptick;
  } else {
    discounts = discounts as Discounts;
    return {
      mainDiscount: discounts.mainDiscount - uptick + discounts.mainDiscount * uptick,
      addons: discounts.addons?.map((a) => {
        return {
          code: a.code,
          discount: a.discount - uptick + a.discount * uptick,
        };
      }),
    };
  }
}

/**
 * Asserts subscription totals
 */
export function assertTotals(preview, subscription) {
  expect(subscription.totalAmount).toBeCloseTo(preview.totalAmount, 2);
  for (const item of preview.items) {
    expect(item.amount).toBeCloseTo(subscription.items.find((i) => i.code === item.code)?.amount, 2);
  }
}

/**
 * Asserts subscription totals interval values
 */
export function assertTotalIntervalValues(value, subscription) {
  expect(subscription.totalIntervalValue).toBeCloseTo(value, 2);
}

/**
 * Assert the distrubition ratio betwwen main item and support item of a subscription
 */
export async function assertDistributionRatio(
  subscriptionId: number,
  ratio: number,
  mainItemCode: string,
  supportItemCode: string
) {
  const res = await e2e.testUtils.execSuiteQL(`SELECT i.itemid, i.displayname, sp.quantity, sp.totalintervalvalue 
                                                  FROM subscriptionPriceInterval sp
                                                  INNER JOIN item i on i.id = sp.item
                                                  WHERE sp.subscription = ${subscriptionId}`);
  const mainItemAmount = res.items.find((i) => i.itemid === mainItemCode).totalintervalvalue;
  const supportItemAmount = res.items.find((i) => i.itemid === supportItemCode).totalintervalvalue;
  const calculatedRatio = supportItemAmount / mainItemAmount;
  expect(calculatedRatio).toBeCloseTo(ratio, 2);
}

/**
 * Asserts subscription operations property
 */
export async function assertOperations(
  subscriptionId: number,
  expectedOperations: string[],
  customerId?: string
): Promise<void> {
  expect(subscriptionId).toBeTruthy();

  const res = await request(tsiapp.app())
    .get(`/api/v1/subscription/${subscriptionId}`)
    .set('Authorization', e2e.testUtils.makeCustomerJWTHeader(customerId ?? e2e.testData.customer.id))
    .expect(200);

  expect(res).toBeTruthy();
  expect(res.body).toBeTruthy();
  expect(res.body).toEqual(
    expect.objectContaining({
      operations: expectedOperations,
    })
  );
}

/**
 * rounds for money values
 * @param price the amount to round
 * @returns rounded value
 */
export function round(price: number): number {
  return Math.round(price * 100) / 100;
}

/**
 * Suriprizingly create draft subscription.
 */
export async function createDraftSubscription(
  body,
  opts?: { customerId: string; productFamilyCode: string; productVariantCode?: string }
) {
  const nsMainClient = makeNSMainClient(e2e.version);
  if (!opts) {
    opts = {
      customerId: e2e.testData.customer.id,
      productFamilyCode: e2e.testData.productIntegration.pfc,
      productVariantCode: e2e.testData.productIntegration.pvc,
    };
  }
  const data = {
    op: 'subscription.create',
    ...opts,
    // contractual documents are required now to activate a subscription
    // for tests, we set default dummy document id - 2
    content: { ...body, contractualDocumentId: body.contractualDocumentId ?? 2 },
  };
  logger.debug(`createDraftSubscription REQ: ${JSON.stringify(data)}`);
  const res = await NetsuiteClient.post(nsMainClient.restletUrl, data);
  expect(res.status).toBe(200);
  logger.debug(`createDraftSubscription RES: ${JSON.stringify(res.data)}`);
  expect(res.data.content).toBeTruthy();
  return res.data.content;
}

/**
 * Create active subscription
 */
export async function createAndActivateSubscription(
  body,
  opts?: { customerId: string; endUserId?: string; productFamilyCode?: string; productVariantCode?: string },
  checkTotalAmount?: boolean
) {
  if (opts?.endUserId) {
    const endUserInternalId =
      (await e2e.testUtils.execSuiteQL(`select id from customer where entityid = '${opts?.endUserId}'`))?.items[0]
        ?.id ?? null;

    expect(endUserInternalId).not.toBeNull;

    body = { ...body, endUserInternalId: endUserInternalId };
    delete opts?.endUserId;
  }

  const nsMainClient = makeNSMainClient(e2e.version);
  if (!opts) {
    opts = {
      customerId: e2e.testData.customer.id,
      productFamilyCode: e2e.testData.productIntegration.pfc,
      productVariantCode: e2e.testData.productIntegration.pvc,
    };
  }

  // contractual documents are required now to activate a subscription
  // for tests, we set default dummy document id - 2 by default
  body = { ...body, contractualDocumentId: body.contractualDocumentId ?? 2 };

  const data = {
    op: 'subscription.internalCreateActiveSubscription',
    ...opts,
    content: body,
  };
  logger.debug(`createAndActivateSubscription body: ${JSON.stringify(data)}`);
  const res = await NetsuiteClient.post(nsMainClient.restletUrl, data);
  logger.debug(`createAndActivateSubscription res.data: ${JSON.stringify(res.data)}`);
  expect(res.status).toBe(200);
  expect(res).toBeDefined();
  expect(res.data).toBeDefined();
  logger.debug(`createAndActivateSubscription response data: ${JSON.stringify(res.data)}`);
  const content = res.data.content;
  expect(content).toBeDefined();
  expect(content.id).toBeDefined();
  expect(content.status).toBe('ACTIVE');
  expect(content.customer).toBeDefined();
  expect(content.endUser).toBeDefined();
  expect(content.plan).toBeDefined();
  expect(content.items).toBeDefined();
  expect(content.currency).toBeDefined();
  if (checkTotalAmount) {
    expect(content.totalAmount).toBeDefined();
  }
  return content;
}

/**
 * Terminate subscription
 */
export async function terminateSubscription(
  subscriptionId: number,
  date?: Date,
  itemCodes?: string[],
  opts?: { customerId: string; productFamilyCode?: string; productVariantCode?: string }
) {
  const nsMainClient = makeNSMainClient(e2e.version);
  if (!opts) {
    opts = {
      customerId: e2e.testData.customer.id,
      productFamilyCode: e2e.testData.productIntegration.pfc,
      productVariantCode: e2e.testData.productIntegration.pvc,
    };
  }
  const data = {
    op: 'subscription.internalTerminateSubscription',
    ...opts,
    subscriptionId: subscriptionId,
    date: date,
    itemCodes: itemCodes,
    content: {},
  };
  logger.debug(`terminateSubscription body: ${JSON.stringify(data)}`);
  const res = await NetsuiteClient.post(nsMainClient.restletUrl, data);
  logger.debug(`terminateSubscription res.data: ${JSON.stringify(res.data)}`);
  expect(res.status).toBe(200);
  expect(res).toBeDefined();
  expect(res.data).toBeDefined();
  logger.debug(`terminateSubscription response data: ${JSON.stringify(res.data)}`);
  const content = res.data.content;
  return content;
}

/**
 * Update subscription and activate
 */
export async function updateAndActivateSubscription(
  id: number,
  body,
  opts?: { customerId: string; productFamilyCode: string; productVariantCode?: string }
) {
  const nsMainClient = makeNSMainClient(e2e.version);
  if (!opts) {
    opts = {
      customerId: e2e.testData.customer.id,
      productFamilyCode: e2e.testData.productIntegration.pfc,
      productVariantCode: e2e.testData.productIntegration.pvc,
    };
  }

  // contractual documents are required now to activate a subscription
  // for tests, we set default dummy document id - 2 by default
  body = { ...body, contractualDocumentId: body.contractualDocumentId ?? 2 };

  const data = {
    op: 'subscription.internalUpdateAndActivate',
    ...opts,
    subscriptionId: id,
    content: body,
  };
  logger.debug(`updateAndActivateSubscription body: ${JSON.stringify(data)}`);

  const res = await NetsuiteClient.post(nsMainClient.restletUrl, data);
  expect(res.status).toBe(200);

  logger.debug(`updateAndActivateSubscription res: ${JSON.stringify(res.data)}`);
  const content = res.data.content;
  expect(content.id).toBeDefined();
  expect(content.customer).toBeDefined();
  expect(content.endUser).toBeDefined();
  expect(content.plan).toBeDefined();
  expect(content.items).toBeDefined();
  expect(content.totalAmount).toBeDefined();

  return content;
}

/**
 * Create and accept quote
 */
export async function createQuoteAndAccept(subscriptionId: number) {
  const quote = await createQuote({
    subscriptionId: subscriptionId,
  });

  await acceptQuote(quote.id);
  const subFields = (
    await e2e.testUtils.execSuiteQL(`select custrecord_contract_docs from subscription where id=${subscriptionId}`)
  ).items[0];
  expect(subFields.custrecord_contract_docs).not.toBeNull();
}

/**
 * Activate subscription
 */
export async function activate(subscriptionId: number) {
  logger.debug(`activate id: ${subscriptionId}`);
  const res = await request(tsiapp.app())
    .patch(`/api/v1/subscription/${subscriptionId}`)
    .send({
      status: 'active',
    })
    .set('Authorization', e2e.testUtils.makeCustomerJWTHeader(e2e.testData.customer.id))
    .expect(200);
  return res.body;
}

/**
 * Create the invoice for the billing account of the subscription
 */
export async function createInvoice(subscriptionId: number) {
  logger.debug(`create invoice id: ${subscriptionId}`);

  const res = await request(tsiapp.app())
    .post('/api/v1/invoice')
    .set('Authorization', e2e.testUtils.makeCustomerJWTHeader(e2e.testData.customer.id))
    .send({ subscriptionId: subscriptionId })
    .expect(200);

  return res.body;
}

/**
 * create a subscription and update doing preview and asserting totals
 */
export async function createAndUpdate(createSubscriptionBody, updateSubscriptionBody, discount, subscriptionPlans) {
  await previewSubscriptionAndAssert(createSubscriptionBody, subscriptionPlans);
  const subscription = await createAndActivateSubscription(createSubscriptionBody);
  await modifyPrice(subscription.id, discount);
  const preview = await previewSubscriptionAndAssert(
    updateSubscriptionBody,
    subscriptionPlans,
    { mainDiscount: discount },
    subscription.id
  );
  const subscriptionUpdated = await updateSubscription(subscription.id, updateSubscriptionBody);
  assertTotals(preview, subscriptionUpdated);
  return subscriptionUpdated;
}

/**
 * create a subscription with addon and check the items
 */
export async function createSubscriptionWithAddon(
  codes: { planName; mainItem; addonItem },
  effectiveDate?: string,
  addonQuantity?: number
) {
  // Define default value if undefined. Don't use ?? operator as 0 value is possible.
  const effectiveAddonQuantity = addonQuantity === undefined ? 3 : addonQuantity;

  // Create subscription body.
  const includedItems = [{ code: codes.mainItem, quantity: 2 }];
  if (effectiveAddonQuantity) {
    includedItems.push({ code: codes.addonItem, quantity: effectiveAddonQuantity });
  }
  const createSubscriptionBody: any = {
    frequency: 'ANNUALLY',
    planCode: codes.planName,
    items: includedItems,
  };
  if (effectiveDate) {
    createSubscriptionBody.effectiveDate = effectiveDate;
  }

  // create subscription
  const subscription = await createAndActivateSubscription(createSubscriptionBody);

  expect(subscription).toMatchObject({
    id: expect.anything(),
    status: 'ACTIVE',
    customer: {
      id: e2e.testData.customer.id,
    },
    term: { frequency: 'ANNUALLY' },
    includedItems: includedItems,
    plan: {
      title: codes.planName,
    },
  });
  return subscription;
}

/**
 * updates the subscription changing the item quantities and asserting that the quantities changed
 */
export async function updateSubscriptionWithAddon(
  subscriptionId,
  codes: { planName; mainItem; addonItem },
  mainItemQuantity: number,
  addonQuantity?: number,
  effectiveDate?: string
) {
  const items = [{ code: codes.mainItem, quantity: mainItemQuantity }];
  if (addonQuantity !== undefined) {
    items.push({ code: codes.addonItem, quantity: addonQuantity });
  }
  const updateSubscriptionBody: any = {
    frequency: 'ANNUALLY',
    planCode: codes.planName,
    items: items,
  };
  if (effectiveDate) {
    updateSubscriptionBody.effectiveDate = effectiveDate;
  }
  const resUpdate = await request(tsiapp.app())
    .put(`/api/v1/subscription/${subscriptionId}`)
    .send(updateSubscriptionBody)
    .set('Authorization', e2e.testUtils.makeCustomerJWTHeader(e2e.testData.customer.id))
    .expect(200);

  expect(resUpdate.body).toMatchObject({
    status: 'DRAFT',
    customer: {
      id: e2e.testData.customer.id,
    },
    term: { frequency: 'ANNUALLY' },
    includedItems: items.filter((i) => i.quantity > 0),
    plan: { title: codes.planName },
  });
}

/**
 * Creates trial subscription
 */
export async function startTrial(): Promise<any> {
  const res = await request(tsiapp.app())
    .post('/api/v1/subscription/startTrial')
    .set('Authorization', e2e.testUtils.makeCustomerJWTHeader(e2e.testData.customer.id))
    .expect(200);

  return res.body;
}

/**
 * Converts a date to NS format dd-mmm-yyyy
 */
export function convertToNSDateFormat(date: Date): string {
  const monthNames = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  const dateStr = date.toISOString().split('T')[0];
  const parts = dateStr.split('-');
  return `${parts[2]}-${monthNames[parseInt(parts[1]) - 1]}-${parts[0]}`;
}
