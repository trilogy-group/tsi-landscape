import { makeNSMainClient } from '../../src/api/services/NSMainClient';
import { KeyParams } from '../../src/common/util';
import { TestData } from './testtypes';
import nsRestClient from '../../src/api/services/NSRestClient';
import jsonwebtoken from 'jsonwebtoken';
import logger from '../../src/common/logger';

export class NSTestUtils {
  e2eTestData: TestData;
  version?: string;
  customerTestEmail: string;
  constructor(e2eTestData: TestData) {
    this.e2eTestData = e2eTestData;
    this.version = process.env.PACKAGE_VERSION || undefined;
    this.customerTestEmail = 'customer@example.com';
    logger.debug(`Version is ${this.version}`);
  }
  async createCustomer(suffix?: string, override?: (customer: any) => void) {
    if (!suffix) {
      suffix = '';
    }
    const customer = {
      individual: true,
      individualName: {
        title: 'Mr',
        firstName: 'E2E',
        lastName: `E2Ev - ${this.e2eTestData.uniqueNumber}${suffix}`,
      },

      companyName: `E2E Company ${this.e2eTestData.uniqueNumber}${suffix}`,
      currency: 'USD',
      email: `e2e.${this.e2eTestData.uniqueNumber}${suffix}@example.com`,
      phone: '1234567',
      address: {
        line1: '291 Harbor Dr',
        line2: '',
        city: 'Claymont',
        state: 'DE',
        country: 'US',
        zip: '19703',
        phone: '1234567',
      },
    };
    override?.call(this, customer);

    const custCreateResponse = await makeNSMainClient(this.version).op(
      'customer.create',
      new KeyParams(this.e2eTestData.productIntegration.pfc, this.e2eTestData.productIntegration.pvc),
      customer
    );
    const res = customer as any;
    res.id = custCreateResponse.data.content;
    return res;
  }

  async createTestCustomer() {
    this.e2eTestData.customer = await this.createCustomer();
  }

  async execSuiteQL(q: string): Promise<{ count: number; offset: number; totalResults: number; items: any[] }> {
    logger.debug(`ExecSQL: ${q}`);
    const res = await nsRestClient.post('/query/v1/suiteql', JSON.stringify({ q: q }));
    logger.debug(`ExecSQL res: ${JSON.stringify(res.data)}`);
    return res.data;
  }

  makeJWT(payload: { pfc?: string; pvc?: string; padm?: boolean; cid?: string }): string {
    const p = JSON.stringify({
      pfc: payload.pfc ?? this.e2eTestData.productIntegration.pfc,
      pvc: payload.pvc,
      padm: payload.padm || false,
      cid: payload.cid,
      version: this.version,
    });
    logger.debug(`JWT payload: ${p}`);
    return jsonwebtoken.sign(p, this.e2eTestData.productIntegration.secret);
  }

  makeJWTHeader(padm?: boolean, cid?: string): string {
    return `Bearer ${this.makeJWT({ pvc: this.e2eTestData.productIntegration.pvc, padm, cid })}`;
  }

  makeCustomerJWTHeader(cid: string): string {
    return `Bearer ${this.makeJWT({ pvc: this.e2eTestData.productIntegration.pvc, cid })}`;
  }

  keyParams(): { customerId: string; productFamilyCode: string; productVariantCode?: string } {
    return {
      customerId: this.e2eTestData.customer.id,
      productFamilyCode: this.e2eTestData.productIntegration.pfc,
      productVariantCode: this.e2eTestData.productIntegration.pvc,
    };
  }
}
