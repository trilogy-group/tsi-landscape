import { NSTestUtils } from './NSTestUtils';

export interface TestData {
  uniqueNumber: number;
  subsidiary: { name: string; id: number };
  class: { name: string; id: number };
  items: { name: string; id: number }[];
  productIntegration: { pfc: string; pvc: string; id: number; secret: string };
  subscriptionPlans: { name: string; id: number; priceBooks: { name: string; id: number }[] }[];
  trialConfig: any;
  customer: any;
}

export interface E2EExtension {
  version: string;
  testData: TestData;
  testUtils: NSTestUtils;
}
