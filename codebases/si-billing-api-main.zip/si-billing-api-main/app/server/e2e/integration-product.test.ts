// import global e2e obj
import './helper/E2EJestGlobal';
import request from 'supertest';
import tsiapp from '../src/tsiappe2e';
import { printFileName, printTestName } from './helper/Functions';

describe('integration-product', () => {
  //FIXME: change printFileName and printTestName to do via global setup
  // https://jestjs.io/docs/configuration#globalsetup-string.
  beforeAll(async () => {
    printFileName();
  });

  beforeEach(() => {
    printTestName();
  });

  it('checkTestData', async () => {
    const res = await e2e.testUtils.execSuiteQL(
      `select * from customrecordproductintegration where custrecordproductfamilycode='DNNE' and custrecordproductvariantcode='SA-Cus'`
    );

    expect(res.items[0]).toEqual(
      expect.objectContaining({
        custrecordproductfamilycode: 'DNNE',
        custrecordproductvariantcode: 'SA-Cus',
      })
    );
  });

  it('get', async () => {
    const res = await request(tsiapp.app())
      .get('/api/v1/integration/product')
      .set('Authorization', e2e.testUtils.makeJWTHeader(true));
    expect(res.body[0]).toEqual(
      expect.objectContaining({
        family: { code: 'DNNE', title: 'DNNE' },
      })
    );
  });
});
