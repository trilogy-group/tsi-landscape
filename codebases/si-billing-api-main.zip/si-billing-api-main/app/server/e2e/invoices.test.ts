// import global e2e obj
import './helper/E2EJestGlobal';
import request from 'supertest';
import tsiapp from '../src/tsiappe2e';
import { createAndActivateSubscription, printFileName, printTestName } from './helper/Functions';
import logger from '../src/common/logger';

describe('invoices', () => {
  beforeAll(async () => {
    printFileName();
    await e2e.testUtils.createTestCustomer();
  });

  beforeEach(() => {
    printTestName();
  });

  it('paymentLink', async () => {
    const res = await request(tsiapp.app())
      .get('/api/v1/invoice/123/paymentLink')
      .set('Authorization', e2e.testUtils.makeCustomerJWTHeader(e2e.testData.customer.id));
    logger.debug(res);
    expect(res.status).toEqual(404);
  });

  it('createInvoice', async () => {
    const subscription = await createAndActivateSubscription({
      planCode: 'DNNE-SA-TEST-MULTICONF',
      frequency: 'MONTHLY',
      items: [
        {
          code: 'DNNE-SA-Cus-BAS',
          quantity: 13,
        },
        {
          code: 'DNNE-SA-TS-OPTVOL',
          quantity: 1,
        },
        {
          code: 'DNNE-SA-TST-USG',
          quantity: 0,
        },
      ],
    });
    const res = await request(tsiapp.app())
      .post('/api/v1/invoice')
      .set('Authorization', e2e.testUtils.makeCustomerJWTHeader(e2e.testData.customer.id))
      .send({ subscriptionId: subscription.id })
      .expect(200);
    const createdInvoice = res.body;

    const customerInvoicesRes = await request(tsiapp.app())
      .get(`/api/v1/invoices?subscriptionId=${subscription.id}`)
      .set('Authorization', e2e.testUtils.makeCustomerJWTHeader(e2e.testData.customer.id))
      .expect(200);
    const customerInvoices = customerInvoicesRes.body;
    const inv = customerInvoices.find((i) => i.number === createdInvoice.number);
    expect(customerInvoices.length > 0).toBeTruthy();
    expect(inv).toEqual(createdInvoice);
  });
});
