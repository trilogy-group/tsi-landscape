// import global e2e obj
import './helper/E2EJestGlobal';
import request from 'supertest';
import tsiapp from '../src/tsiappe2e';
import { makeNSMainClient } from '../src/api/services/NSMainClient';
import NetsuiteClient from '../src/api/services/NetsuiteClient';
import {
  assertTerm,
  printTestName,
  createQuote,
  acceptQuote,
  updateSubscription,
  createQuoteAndAccept,
  createAndActivateSubscription,
  downloadQuote,
  calSubscriptionItemTotalPrice,
  printFileName,
  localeDateToNetsuiteTimezone,
} from './helper/Functions';
import logger from '../src/common/logger';

let customerId;
let subscriptionPlans;
let subscription;

describe('master', () => {
  beforeAll(() => {
    printFileName();
  });

  beforeEach(() => {
    printTestName();
  });

  it('create customer', async () => {
    //prepare customer data for insert
    const customer = {
      individual: true,
      individualName: {
        title: 'Mr',
        firstName: 'E2E Master Test',
        lastName: `E2Ev - ${e2e.testData.uniqueNumber}`,
      },
      companyName: `E2E Company ${e2e.testData.uniqueNumber}`,
      currency: 'USD',
      email: `e2e.${e2e.testData.uniqueNumber}@example.com`,
      phone: '1234567',
      address: {
        line1: '291 Harbor Dr',
        line2: '',
        city: 'Claymont',
        state: 'DE',
        country: 'US',
        zip: '19703',
        phone: '1234567',
      },
    };

    //create new customer
    const res = await request(tsiapp.app())
      .post('/api/v1/customer')
      .send(customer)
      .set('Authorization', e2e.testUtils.makeJWTHeader(true))
      .expect(200);
    expect(res.body).toBeTruthy();
    customerId = String(res.body);
    e2e.testData.customer = { id: customerId };
  });

  it('get customer created', async () => {
    const res = await request(tsiapp.app())
      .get('/api/v1/customer')
      .set('Authorization', e2e.testUtils.makeCustomerJWTHeader(customerId))
      .expect(200);
    expect(res.body).toEqual(
      expect.objectContaining({
        id: customerId,
        email: `e2e.${e2e.testData.uniqueNumber}@example.com`,
        phone: '1234567',
        address: {
          line1: '291 Harbor Dr',
          city: 'Claymont',
          state: 'DE',
          country: 'US',
          zip: '19703',
          phone: '1234567',
        },
      })
    );
  });

  let customer2Id;
  it('create 2nd customer', async () => {
    //prepare customer data for insert
    const customer = {
      individual: true,
      individualName: {
        title: 'Mr',
        firstName: 'E2E Master Test',
        lastName: `2nd - ${e2e.testData.uniqueNumber}`,
      },
      companyName: `E2E Company ${e2e.testData.uniqueNumber}`,
      currency: 'USD',
      email: `e2e.${e2e.testData.uniqueNumber}@example.com`,
      phone: '1234567',
      address: {
        line1: '291 Harbor Dr',
        line2: '',
        city: 'Claymont',
        state: 'DE',
        country: 'US',
        zip: '19703',
        phone: '1234567',
      },
    };

    //create new customer
    const res = await request(tsiapp.app())
      .post('/api/v1/customer')
      .send(customer)
      .set('Authorization', e2e.testUtils.makeJWTHeader(true))
      .expect(200);
    expect(res.body).toBeTruthy();
    customer2Id = String(res.body);
  });

  it('update wrong customer', async () => {
    //prepare customer data for update
    const customer = {
      id: customerId,
      individual: true,
      individualName: {
        title: 'Mr',
        firstName: 'E2E Master Test',
        lastName: `E2Ev - ${e2e.testData.uniqueNumber}`,
      },
      companyName: `E2E Company ${e2e.testData.uniqueNumber}`,
      currency: 'USD',
      email: `e2e.${e2e.testData.uniqueNumber}@example2.com`,
      phone: '987654321',
      address: {
        line1: '15 Main st',
        line2: 'Apt 3',
        city: 'Miami',
        state: 'FL',
        country: 'US',
        zip: '05424',
        phone: '987654321',
      },
    };

    //try to update customer
    const res = await request(tsiapp.app())
      .put('/api/v1/customer')
      .send(customer)
      .set('Authorization', e2e.testUtils.makeCustomerJWTHeader(customer2Id))
      .expect(500);
    expect(res.body.errors[0].message).toBe(`The customer '${customer2Id}' cannot update information of the customer '${customerId}'`);
  });

  let trialSubscriptionId;
  it('start trial', async () => {
    const res = await request(tsiapp.app())
      .post('/api/v1/subscription/startTrial')
      .set('Authorization', e2e.testUtils.makeCustomerJWTHeader(customerId))
      .expect(200);
    expect(res.body).toBeTruthy();
    trialSubscriptionId = res.body.id;
  });

  it('get subscription plans', async () => {
    const res = await request(tsiapp.app())
      .get('/api/v1/subscriptionPlans')
      .set('Authorization', e2e.testUtils.makeCustomerJWTHeader(customerId))
      .expect(200);
    expect(res.body[0]).toBeTruthy();
    subscriptionPlans = res.body;
  });

  it('upgrade from trial subscription', async () => {
    //prepare subscription data for creation
    const standardPlan = subscriptionPlans.find((i) => i.code === e2e.testData.trialConfig.planCode);
    const createSubscriptionBody = {
      frequency: 'MONTHLY',
      planCode: standardPlan.code,
      items: new Array<any>(),
    };
    for (const item of standardPlan.items) {
      createSubscriptionBody.items.push({ code: item.code, quantity: 1 });
    }

    //create subscription
    subscription = await updateSubscription(trialSubscriptionId, createSubscriptionBody);

    //assert
    assertTerm(standardPlan.initialterm, subscription.term);
    assertAmount(subscription, 'USD', 'MONTHLY');
  });

  it('create, download and accept quote', async () => {
    const quote = await createQuote({ subscriptionId: subscription.id });
    const quoteFields = (
      await e2e.testUtils.execSuiteQL(`select * from transaction where recordtype='estimate' and id=${quote.id}`)
    ).items[0];
    expect(new Date(quoteFields.startdate)).toEqual(new Date(subscription.term.start));    
    expect(new Date(quoteFields.enddate)).toEqual(new Date(subscription.term.end));

    await downloadQuote(quote.id);

    await acceptQuote(quote.id);

    const quoteInfo = await e2e.testUtils.execSuiteQL(`
    select 
      t.createddate,
      t.duedate,
      t.entity as customerinternalid,
      c.entityid as customerid, 
      t.custbody_end_user as enduserinternalid,
      eu.entityid as enduserid,
      t.custbody_related_subscription as subscription,
      es.name as status
    from transaction t
    join customer c on c.id=t.entity
    join customer eu on eu.id=t.custbody_end_user
    join entitystatus es on es.key=t.entitystatus
    where t.recordtype='estimate' and t.id = ${quote.id}`);
    expect(quoteInfo.items[0].status).toEqual('Signing');
    const subFields = (
      await e2e.testUtils.execSuiteQL(`select custrecord_contract_docs from subscription where id=${subscription.id}`)
    ).items[0];
    expect(subFields.custrecord_contract_docs).not.toBeNull();

    const agrementInfo = (
      await e2e.testUtils.execSuiteQL(`select ag.id, st.name as status 
    from customrecord_echosign_agreement ag 
    join CUSTOMLIST_ECHOSIGN_STATUS_TYPES st on st.id=ag.custrecord_echosign_status 
    where ag.custrecord_echosign_parent_record=${quote.id} order by ag.id asc
    `)
    ).items?.[0];
    logger.debug('AGREEMENT INFO');
    expect(agrementInfo).toEqual(
      expect.objectContaining({
        status: 'Out For Signature',
      })
    );
  });

  it('activate updated subscription', async () => {
    const activateRes = await request(tsiapp.app())
      .patch(`/api/v1/subscription/${subscription.id}`)
      .send({
        status: 'ACTIVE',
      })
      .set('Authorization', e2e.testUtils.makeCustomerJWTHeader(e2e.testData.customer.id))
      .expect(200);
    expect(activateRes.body.status).toEqual('ACTIVE');
  });

  it('get subscriptions', async () => {
    const res = await request(tsiapp.app())
      .get('/api/v1/subscriptions')
      .set('Authorization', e2e.testUtils.makeCustomerJWTHeader(customerId))
      .expect(200);
    expect(res.body.find((i) => i.id === subscription.id)).toBeTruthy();
  });

  it('get subscription', async () => {
    const res = await request(tsiapp.app())
      .get(`/api/v1/subscription/${subscription.id}`)
      .set('Authorization', e2e.testUtils.makeCustomerJWTHeader(customerId))
      .expect(200);
    expect(res.body).toBeTruthy();
    checkPrices(subscriptionPlans, e2e.testData.trialConfig.planCode, res.body.items);
    assertAmount(res.body, 'USD', 'MONTHLY');
    expect(res.body.term.nextBillCycleDate).toBeDefined();
    subscription = res.body;
  });

  it('check trial subscription is terminated', async () => {
    const res = await request(tsiapp.app())
      .get(`/api/v1/subscription/${trialSubscriptionId}`)
      .set('Authorization', e2e.testUtils.makeCustomerJWTHeader(customerId))
      .expect(200);
    expect(res.body).toBeTruthy();
    expect(res.body.status.toUpperCase()).toBe('TERMINATED');
  });

  it('create new subscription', async () => {
    const standardPlan = subscriptionPlans.find((i) => i.code === e2e.testData.trialConfig.planCode);
    const createSubscriptionBody = {
      frequency: 'MONTHLY',
      planCode: standardPlan.code,
      items: new Array<any>(),
    };
    for (const item of standardPlan.items) {
      createSubscriptionBody.items.push({ code: item.code, quantity: 1 });
    }

    //create subscription
    subscription = await createAndActivateSubscription(createSubscriptionBody);

    //assert
    assertTerm(standardPlan.initialterm, subscription.term);
    assertAmount(subscription, 'USD', 'MONTHLY');
  });

  it('update subscription', async () => {
    //prepare subscription data for creation
    const updateSubscriptionBody = {
      frequency: 'ANNUALLY',
      planCode: subscription.plan.title,
      items: new Array<any>(),
    };
    for (const item of subscription.includedItems) {
      updateSubscriptionBody.items.push({ code: item.code, quantity: item.quantity + 1 });
    }

    //update subscription
    const prevSubscriptionId = subscription.id;
    subscription = await updateSubscription(subscription.id, updateSubscriptionBody);
    expect(subscription.id).not.toEqual(prevSubscriptionId);
    await createQuoteAndAccept(subscription.id);
    const activateRes = await request(tsiapp.app())
      .patch(`/api/v1/subscription/${subscription.id}`)
      .send({
        status: 'ACTIVE',
      })
      .set('Authorization', e2e.testUtils.makeCustomerJWTHeader(e2e.testData.customer.id))
      .expect(200);
    expect(activateRes.body.status).toEqual('ACTIVE');

    //assert
    expect(subscription.term.frequency.toLowerCase()).toBe('annually');
    assertAmount(subscription, 'USD', 'ANNUALLY');
  });

  let renewalSubscription;
  it('create draft renewal subscription', async () => {
    const nsMainClient = makeNSMainClient(e2e.version);
    const data = {
      op: 'subscription.createDraftRenewal',
      subscriptionId: subscription.id,
    };
    const res = await NetsuiteClient.post(nsMainClient.restletUrl, data);
    expect(res.status).toBe(200);
    expect(res.data.content).toBeTruthy();
    renewalSubscription = res.data.content;
  });

  it('renew draft subscription', async () => {
    //prepare subscription data for renew
    const updateSubscriptionBody = {
      frequency: renewalSubscription.term.frequency,
      planCode: renewalSubscription.plan.title,
      items: new Array<any>(),
    };
    for (const item of renewalSubscription.includedItems) {
      updateSubscriptionBody.items.push({ code: item.code, quantity: item.quantity + 1 });
    }

    //renew subscription
    const res = await request(tsiapp.app())
      .put(`/api/v1/subscription/${renewalSubscription.id}`)
      .send(updateSubscriptionBody)
      .set('Authorization', e2e.testUtils.makeCustomerJWTHeader(customerId))
      .expect(200);

    //assert
    for (const item of updateSubscriptionBody.items) {
      const itemRenewal = res.body.includedItems.find((i) => i.code === item.code);
      expect(itemRenewal.quantity).toBe(item.quantity);
    }
    expect(res.body.status.toUpperCase()).toBe('DRAFT');
    checkPrices(subscriptionPlans, res.body.plan.title, res.body.items);
    assertAmount(res.body, 'USD', 'ANNUALLY');
    renewalSubscription = res.body;
  });

  it('generate quote for renewal', async () => {
    const quote = await createQuote({ subscriptionId: renewalSubscription.id });
    const quoteFields = (
      await e2e.testUtils.execSuiteQL(`SELECT t.title, t.startdate, t.enddate, t.duedate, bs.name as billingschedule 
        FROM transaction t
        LEFT JOIN CUSTOMLIST_QUOTE_BILLING_SCHEDULE bs on bs.id = t.custbody_billing_schedule
        WHERE t.recordtype='estimate' AND t.id=${quote.id}`)
    ).items[0];    
    expect(new Date(quoteFields.startdate)).toEqual(new Date(renewalSubscription.term.start));    
    expect(new Date(quoteFields.enddate)).toEqual(new Date(renewalSubscription.term.end));
    
    // Check title
    expect(quoteFields.title).toBeTruthy();
    const customerResponse = await request(tsiapp.app())
      .get('/api/v1/customer')
      .set('Authorization', e2e.testUtils.makeCustomerJWTHeader(e2e.testUtils.e2eTestData.customer.id));
    const customer = customerResponse.body;
    const expectedCustomerName = `${customer.individualName.title} ${customer.individualName.firstName} ${customer.individualName.lastName}`;

    expect(quoteFields.title).toMatch(new RegExp(`(${expectedCustomerName}) - DNNE - (\\d\\d_\\d\\d\\d\\d)( - (.*))?`));

    // Check due date
    expect(quoteFields.duedate).toBeTruthy();
    const dueDate = Date.parse(quoteFields.duedate);
    const today = localeDateToNetsuiteTimezone(new Date());
    const todayWithoutTime = new Date(today.getFullYear(), today.getMonth(), today.getDate()).getTime();
    const daysBeforeDueDate = (dueDate - todayWithoutTime) / (1000 * 24 * 3600);
    expect(daysBeforeDueDate).toEqual(30);

    // Check billing schedule
    expect(quoteFields.billingschedule).toEqual('100% Upon Signature');
  });

  it('update renewal', async () => {
    //prepare subscription data for renew
    const updateSubscriptionBody = {
      frequency: renewalSubscription.term.frequency === 'MONTHLY' ? 'ANNUALLY' : 'MONTHLY',
      planCode: renewalSubscription.plan.title,
      items: new Array<any>(),
    };
    for (const item of renewalSubscription.includedItems) {
      updateSubscriptionBody.items.push({ code: item.code, quantity: item.quantity });
    }

    const res = await request(tsiapp.app())
      .put(`/api/v1/subscription/${renewalSubscription.id}`)
      .send(updateSubscriptionBody)
      .set('Authorization', e2e.testUtils.makeCustomerJWTHeader(customerId))
      .expect(200);

    //assert
    for (const item of updateSubscriptionBody.items) {
      const itemRenewal = res.body.includedItems.find((i) => i.code === item.code);
      expect(itemRenewal.quantity).toBe(item.quantity);
    }
    expect(res.body.status.toUpperCase()).toBe('DRAFT');
    // check that new subscription record created
    expect(res.body.id).not.toEqual(renewalSubscription.id);
    renewalSubscription = res.body;
  });

  it('create 2nd draft renewal subscription', async () => {
    const nsMainClient = makeNSMainClient(e2e.version);
    const data = {
      op: 'subscription.createDraftRenewal',
      subscriptionId: subscription.id,
    };
    const res = await NetsuiteClient.post(nsMainClient.restletUrl, data);
    expect(res.status).toBe(200);
    expect(res.data.content).toBeTruthy();
    renewalSubscription = res.data.content;
  });

  it('renew 2nd draft subscription', async () => {
    //prepare subscription data for renew
    const updateSubscriptionBody = {
      frequency: 'MONTHLY',
      planCode: renewalSubscription.plan.title,
      items: new Array<any>(),
    };
    for (const item of renewalSubscription.includedItems) {
      updateSubscriptionBody.items.push({ code: item.code, quantity: item.quantity + 1 });
    }

    //renew subscription
    const res = await request(tsiapp.app())
      .put(`/api/v1/subscription/${renewalSubscription.id}`)
      .send(updateSubscriptionBody)
      .set('Authorization', e2e.testUtils.makeCustomerJWTHeader(customerId))
      .expect(200);

    //assert
    for (const item of updateSubscriptionBody.items) {
      const itemRenewal = res.body.includedItems.find((i) => i.code === item.code);
      expect(itemRenewal.quantity).toBe(item.quantity);
    }
    expect(res.body.status.toUpperCase()).toBe('DRAFT');
    expect(res.body.term.frequency.toUpperCase()).toBe('MONTHLY');
    // commented this as frequency change for renewals will be done in a future ticket
    //checkPrices(subscriptionPlans, res.body.plan.code, res.body.items);
    //assertAmount(res.body, 'USD', 'MONTHLY');
    renewalSubscription = res.body;
  });

  it('update customer', async () => {
    //prepare customer data for update
    const customer = {
      id: customerId,
      individual: true,
      individualName: {
        title: 'Mr',
        firstName: 'E2E Master Test',
        lastName: `E2Ev - ${e2e.testData.uniqueNumber}`,
      },
      companyName: `E2E Company ${e2e.testData.uniqueNumber}`,
      currency: 'USD',
      email: `e2e.${e2e.testData.uniqueNumber}@example2.com`,
      phone: '987654321',
      address: {
        line1: '15 Main st',
        line2: 'Apt 3',
        city: 'Miami',
        state: 'FL',
        country: 'US',
        zip: '05424',
        phone: '987654321',
      },
    };

    //update customer
    const res = await request(tsiapp.app())
      .put('/api/v1/customer')
      .send(customer)
      .set('Authorization', e2e.testUtils.makeCustomerJWTHeader(customerId))
      .expect(200);
    expect(res.body).toBeTruthy();
    customerId = String(res.body);
  });

  it('get customer updated', async () => {
    const res = await request(tsiapp.app())
      .get('/api/v1/customer')
      .set('Authorization', e2e.testUtils.makeCustomerJWTHeader(customerId))
      .expect(200);
    expect(res.body).toEqual(
      expect.objectContaining({
        id: customerId,
        email: `e2e.${e2e.testData.uniqueNumber}@example2.com`,
        phone: '987654321',
        address: {
          line1: '15 Main st',
          line2: 'Apt 3',
          city: 'Miami',
          state: 'FL',
          country: 'US',
          zip: '05424',
          phone: '987654321',
        },
      })
    );
  });

  it('check customer status', async () => {
    const nsMainClient = makeNSMainClient(e2e.version);
    const data = {
      op: 'customer.getStatus',
      customerId: customerId,
    };
    const res = await NetsuiteClient.post(nsMainClient.restletUrl, data);
    expect(res.status).toBe(200);
    expect(res.data.content).toBe('Closed-Won');
  });
});

function checkPrices(subscriptionPlans, planCode, subscriptionItems) {
  const standardPlan = subscriptionPlans.find((i) => i.code === planCode);
  for (const item of subscriptionItems) {
    const itemPlan = standardPlan.items.find((i) => i.code === item.code);
    const pricePlan = itemPlan.prices.find((i) => i.frequency === item.prices[0].frequency);
    const price = pricePlan.ranges.find((i) => i.fromQuantity == item.prices[0].ranges[0].fromQuantity).price;
    expect(item.prices[0].ranges[0].price).toBe(price);
  }
}

function assertAmount(subscription, currency, frequency) {
  let totalAmount = 0;
  for (const includedItem of subscription.includedItems) {
    const item = subscription.items.find((i) => i.id === includedItem.id);
    const price = calSubscriptionItemTotalPrice(item, includedItem.quantity, frequency);
    expect(item.amount).toBeCloseTo(price, 2);
    expect(subscription.currency).toBe(currency);
    totalAmount += item.amount;
  }
  expect(subscription.totalAmount).toBeCloseTo(totalAmount, 2);
}
