import './helper/E2EJestGlobal';
import request from 'supertest';
import tsiapp from '../src/tsiappe2e';
import { printFileName, printTestName } from './helper/Functions';
import logger from '../src/common/logger';

describe('product-catalog', () => {
  beforeAll(async () => {
    printFileName();
    await e2e.testUtils.createTestCustomer();
  });

  beforeEach(() => {
    printTestName();
  });

  it('checkProductTierTitle', async () => {
    const query = `select * from customrecordproductintegration where custrecordproductfamilycode='${e2e.testData.productIntegration.pfc}' and custrecordproductvariantcode='${e2e.testData.productIntegration.pvc}'`;
    const pi = (await e2e.testUtils.execSuiteQL(query)).items[0];
    const tierTitles = { Standard: pi.custrecordtierlabelstandard, Professional: pi.custrecordtierlabelprofessional };

    const res = await request(tsiapp.app())
      .get('/api/v1/subscriptionPlans')
      .send()
      .set('Authorization', e2e.testUtils.makeCustomerJWTHeader(e2e.testData.customer.id))
      .expect(200);
    const saCusPlans = res.body;

    expect(saCusPlans).toEqual(
      expect.arrayContaining([
        expect.objectContaining({
          code: 'DNNE Customer Cloud EVOQ BASIC',
          productTier: 'Standard',
          productTierTitle: tierTitles['Standard'],
        }),
      ])
    );
    expect(saCusPlans).toEqual(
      expect.arrayContaining([
        expect.objectContaining({
          code: 'DNNE Cloud EVOQ CONTENT',
          productTier: 'Professional',
          productTierTitle: tierTitles['Professional'],
        }),
      ])
    );
  });

  it('listSubscriptionPlans 1', async () => {
    let res = await request(tsiapp.app())
      .get('/api/v1/subscriptionPlans')
      .send()
      .set('Authorization', e2e.testUtils.makeCustomerJWTHeader(e2e.testData.customer.id))
      .expect(200);
    const saCusPlans = res.body;
    expect(saCusPlans).not.toEqual(
      expect.arrayContaining([expect.objectContaining({ code: 'DNNE Customer Cloud EVOQ BASIC Additional' })])
    );
    expect(saCusPlans).toEqual(
      expect.arrayContaining([
        expect.objectContaining({
          code: 'DNNE Cloud EVOQ Engage',
          _ns_displayname: 'DNNE-SA-Cus-STA-PLA-002',
          items: [
            expect.objectContaining({
              code: 'DNNE-SA-Cus-STA',
              title: 'DNNE Cloud EVOQ Engage',
              prices: expect.arrayContaining([
                expect.objectContaining({
                  ranges: expect.arrayContaining([
                    expect.objectContaining({
                      fromQuantity: 0,
                      price: 50750,
                    }),
                  ]),
                }),
              ]),
            }),
            expect.objectContaining({
              code: 'DNNE-SA-Sub-ADD',
              title: 'DNNE Subscription Addon',
              prices: expect.arrayContaining([
                expect.objectContaining({
                  ranges: expect.arrayContaining([
                    expect.objectContaining({
                      fromQuantity: 0,
                      price: 9000,
                    }),
                  ]),
                }),
              ]),
            }),
          ],
        }),
      ])
    );

    res = await request(tsiapp.app())
      .get('/api/v1/subscriptionPlans')
      .send()
      .set('Authorization', 'Bearer ' + e2e.testUtils.makeJWT({ cid: e2e.testData.customer.id, pvc: 'SA-ADDSUB' }))
      .expect(200);
    const testPlans = res.body;
    expect(testPlans).toEqual(
      expect.arrayContaining([expect.objectContaining({ code: 'DNNE Customer Cloud EVOQ BASIC Additional' })])
    );

    res = await request(tsiapp.app())
      .get('/api/v1/subscriptionPlans')
      .send()
      .set('Authorization', 'Bearer ' + e2e.testUtils.makeJWT({ cid: e2e.testData.customer.id }))
      .expect(200);
    const allPlans = res.body;

    expect(allPlans).toEqual(expect.arrayContaining(testPlans));
    expect(allPlans).toEqual(expect.arrayContaining(saCusPlans));
  });

  it('listSubscriptionPlans - support only plan', async () => {
    const res = await request(tsiapp.app())
      .get('/api/v1/subscriptionPlans')
      .send()
      .set('Authorization', e2e.testUtils.makeCustomerJWTHeader(e2e.testData.customer.id))
      .expect(200);
    const saCusPlans = res.body;

    const supportPlan = saCusPlans.find((p) => p.code === 'DNNE Std Silver Sup');
    logger.debug(JSON.stringify(saCusPlans));
    expect(supportPlan).toEqual(
      expect.objectContaining({
        supportLevel: 'Silver',
        productTier: 'Standard',
        revenueType: 'Support',
        items: expect.arrayContaining([
          expect.objectContaining({ code: 'DNNE-SA-Cus-SIL', required: true }),
          expect.objectContaining({ code: 'DNNE-SA-Add-BAS', required: false }),
        ]),
      })
    );
  });

  it('listSubscriptionPlans - no req items plan with codes', async () => {
    const res = await request(tsiapp.app())
      .get('/api/v1/subscriptionPlans')
      .send()
      .set('Authorization', e2e.testUtils.makeCustomerJWTHeader(e2e.testData.customer.id))
      .expect(200);
    const saCusPlans = res.body;

    const plan = saCusPlans.find((p) => p.code === 'DNNE NoReq5');
    logger.debug(JSON.stringify(plan));
    expect(plan).toEqual(
      expect.objectContaining({
        supportLevel: 'Gold',
        productTier: 'Professional',
        revenueType: 'SaaS',
        items: expect.arrayContaining([
          expect.objectContaining({ code: 'DNN-SA-CUS-PRO', required: true }),
          expect.objectContaining({ code: 'DNN-SA-DEV-ADD', required: false }),
        ]),
      })
    );
  });

  it('listSubscriptionPlans - sup plan no req items', async () => {
    const res = await request(tsiapp.app())
      .get('/api/v1/subscriptionPlans')
      .send()
      .set('Authorization', e2e.testUtils.makeCustomerJWTHeader(e2e.testData.customer.id))
      .expect(200);
    const saCusPlans = res.body;

    const plan = saCusPlans.find((p) => p.code === 'DNNE Sup NoReq');
    logger.debug(JSON.stringify(plan));
    expect(plan).toEqual(
      expect.objectContaining({
        productTier: 'Standard',
        revenueType: 'Support',
        items: expect.arrayContaining([
          expect.objectContaining({ code: 'DNNE-SA-Cus-SIL', required: true }),
          expect.objectContaining({ code: 'DNNE-SA-Add-BAS', required: false }),
          expect.objectContaining({ code: 'DNNE-SA-OT-PT', required: false }),
          expect.objectContaining({ code: 'DNNE-SA-OT-GRI', required: false }),
        ]),
      })
    );
  });
});
