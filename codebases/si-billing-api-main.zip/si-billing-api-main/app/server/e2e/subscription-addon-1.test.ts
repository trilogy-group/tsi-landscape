// import global e2e obj
import './helper/E2EJestGlobal';
import {
  createAndActivateSubscription,
  createSubscriptionWithAddon,
  printFileName,
  printTestName,
  updateSubscriptionWithAddon,
} from './helper/Functions';

const codes = {
  planName: 'DNNE Customer EVOQ BASIC Addon',
  mainItem: 'DNNE-SA-Cus-BAS',
  addonItem: 'DNNE-SA-Add-BAS',
};

describe('subscription-addon-1', () => {
  beforeAll(async () => {
    printFileName();
    await e2e.testUtils.createTestCustomer();
  });

  beforeEach(() => {
    printTestName();
  });

  it('create subscription with 0 quantity', async () => {
    const pastDate = new Date();
    pastDate.setMonth(pastDate.getMonth() - 1);
    await createSubscriptionWithAddon(codes, pastDate.toISOString().split('T')[0], 0);
  });

  it('create subscription with addon', async () => {
    // First subscription being created in the past to have billing account in the past
    const pastDate = new Date();
    pastDate.setMonth(pastDate.getMonth() - 1);
    await createSubscriptionWithAddon(codes, pastDate.toISOString().split('T')[0]);
  });

  it('update subscription adding addon', async () => {
    //create subscription without addon
    const createSubscriptionBody = {
      frequency: 'ANNUALLY',
      planCode: codes.planName,
      items: [{ code: codes.mainItem, quantity: 2 }],
    };
    const subscription = await createAndActivateSubscription(createSubscriptionBody);
    expect(subscription).toMatchObject({
      id: expect.anything(),
      status: 'ACTIVE',
      customer: {
        id: e2e.testData.customer.id,
      },
      term: { frequency: 'ANNUALLY' },
      includedItems: [{ code: codes.mainItem, quantity: 2 }],
      plan: { title: codes.planName },
    });

    // adding addon with 0 quantity (not adding effectively)
    await updateSubscriptionWithAddon(subscription.id, codes, 4, 0);

    // adding addon
    await updateSubscriptionWithAddon(subscription.id, codes, 4, 3);
  });

  it('remove addon', async () => {
    // Suspension of addon can't be in same day of activation, thus creating subscription two days before
    const pastDate = new Date();
    pastDate.setDate(pastDate.getDate() - 2);
    const subscription = await createSubscriptionWithAddon(codes, pastDate.toISOString().split('T')[0]);

    // remove addon
    await updateSubscriptionWithAddon(subscription.id, codes, 2, 0);
  });

  it('adding addon again', async () => {
    // Creating subscription 4 days before to suspend and activate addon back again
    const pastDate = new Date();
    pastDate.setDate(pastDate.getDate() - 4);
    const subscription = await createSubscriptionWithAddon(codes, pastDate.toISOString().split('T')[0]);

    pastDate.setDate(pastDate.getDate() + 2);
    // remove addon
    await updateSubscriptionWithAddon(subscription.id, codes, 3, 0, pastDate.toISOString().split('T')[0]);

    // update subscription adding addon again
    await updateSubscriptionWithAddon(subscription.id, codes, 5, 3);
  });

  it('increasing addon quantity', async () => {
    const subscription = await createSubscriptionWithAddon(codes);
    const mainItem = subscription.includedItems.find((i) => i.code === codes.mainItem);
    const addonItem = subscription.includedItems.find((i) => i.code === codes.addonItem);
    const newAddonQuantity = addonItem.quantity + 1;

    // increasing addon quantity
    await updateSubscriptionWithAddon(subscription.id, codes, mainItem.quantity, newAddonQuantity);
  });
});
