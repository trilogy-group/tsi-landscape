// import global e2e obj
import './helper/E2EJestGlobal';
import request from 'supertest';
import tsiapp from '../src/tsiappe2e';
import { makeNSMainClient } from '../src/api/services/NSMainClient';
import NetsuiteClient from '../src/api/services/NetsuiteClient';
import {
  createSubscriptionWithAddon,
  printFileName,
  printTestName,
  updateSubscriptionWithAddon,
} from './helper/Functions';

const codes = {
  planName: 'DNNE Customer EVOQ BASIC Addon',
  mainItem: 'DNNE-SA-Cus-BAS',
  addonItem: 'DNNE-SA-Add-BAS',
};

describe('subscription-addon-2', () => {
  beforeAll(async () => {
    printFileName();
    await e2e.testUtils.createTestCustomer();
  });

  beforeEach(() => {
    printTestName();
  });

  it('renew draft removing addon', async () => {
    const pastDate = new Date();
    pastDate.setMonth(pastDate.getMonth() - 1);
    const subscription = await createSubscriptionWithAddon(codes, pastDate.toISOString().split('T')[0]);

    // create draft renewal
    const nsMainClient = makeNSMainClient(e2e.version);
    const data = {
      op: 'subscription.createDraftRenewal',
      subscriptionId: subscription.id,
    };
    const resDraftRenewal = await NetsuiteClient.post(nsMainClient.restletUrl, data);
    expect(resDraftRenewal.status).toBe(200);
    expect(resDraftRenewal.data.content).toBeTruthy();

    //renew subscription without addon
    const renewalSubscriptionBody = {
      frequency: 'ANNUALLY',
      planCode: codes.planName,
      items: [
        { code: codes.mainItem, quantity: 3 },
        { code: codes.addonItem, quantity: 0 },
      ],
    };
    const resRenew = await request(tsiapp.app())
      .put(`/api/v1/subscription/${resDraftRenewal.data.content.id}`)
      .send(renewalSubscriptionBody)
      .set('Authorization', e2e.testUtils.makeCustomerJWTHeader(e2e.testData.customer.id))
      .expect(200);

    // assert
    expect(resRenew.body).toMatchObject({
      id: resDraftRenewal.data.content.id,
      status: 'DRAFT',
      customer: {
        id: e2e.testData.customer.id,
      },
      term: { frequency: 'ANNUALLY' },
      includedItems: [{ code: codes.mainItem, quantity: 3 }],
      plan: {
        title: codes.planName,
      },
    });
  });

  it('updating main quantity on the same day addon was added again', async () => {
    // Creating subscription 4 days before to suspend and activate addon back again
    const pastDate = new Date();
    pastDate.setDate(pastDate.getDate() - 4);
    const subscription = await createSubscriptionWithAddon(codes, pastDate.toISOString().split('T')[0]);

    // remove addon
    await updateSubscriptionWithAddon(subscription.id, codes, 4, 0);

    // adding addon again
    await updateSubscriptionWithAddon(subscription.id, codes, 4, 4);

    // changing main item quantity
    await updateSubscriptionWithAddon(subscription.id, codes, 5, 4);
  });

  it('changing subscription several times 3', async () => {
    // Creating subscription 4 days before to suspend and activate addon back again
    const pastDate = new Date();
    pastDate.setDate(pastDate.getDate() - 4);
    const subscription = await createSubscriptionWithAddon(codes, pastDate.toISOString().split('T')[0]);

    // change main quantity
    await updateSubscriptionWithAddon(subscription.id, codes, 3, 3);

    // remove addon
    await updateSubscriptionWithAddon(subscription.id, codes, 3, 0);

    // Add addon again
    await updateSubscriptionWithAddon(subscription.id, codes, 3, 1);

    // change main item quantity again
    await updateSubscriptionWithAddon(subscription.id, codes, 4, 1);
  });
});
