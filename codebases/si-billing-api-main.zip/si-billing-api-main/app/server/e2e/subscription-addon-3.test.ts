// import global e2e obj
import './helper/E2EJestGlobal';
import {
  createSubscriptionWithAddon,
  printFileName,
  printTestName,
  updateSubscriptionWithAddon,
} from './helper/Functions';

const codes = {
  planName: 'DNNE Customer EVOQ BASIC Addon',
  mainItem: 'DNNE-SA-Cus-BAS',
  addonItem: 'DNNE-SA-Add-BAS',
};

describe('subscription-addon-3', () => {
  beforeAll(async () => {
    printFileName();
    await e2e.testUtils.createTestCustomer();
  });

  beforeEach(() => {
    printTestName();
  });

  it('changing subscription several times 1', async () => {
    // Creating subscription 4 days before to suspend and activate addon back again
    const pastDate = new Date();
    pastDate.setDate(pastDate.getDate() - 4);
    const subscription = await createSubscriptionWithAddon(codes, pastDate.toISOString().split('T')[0]);

    // change quantities
    await updateSubscriptionWithAddon(subscription.id, codes, 5, 4);

    // remove addon
    await updateSubscriptionWithAddon(subscription.id, codes, 5, 0);

    // change main item quantity
    await updateSubscriptionWithAddon(subscription.id, codes, 6);

    // Add addon again
    await updateSubscriptionWithAddon(subscription.id, codes, 6, 5);

    // change quantity again
    await updateSubscriptionWithAddon(subscription.id, codes, 7, 3);
  });

  it('changing subscription several times 2', async () => {
    // Creating subscription 4 days before to suspend and activate addon back again
    const pastDate = new Date();
    pastDate.setDate(pastDate.getDate() - 4);
    const subscription = await createSubscriptionWithAddon(codes, pastDate.toISOString().split('T')[0]);

    // change quantities
    await updateSubscriptionWithAddon(subscription.id, codes, 3, 1);

    // remove addon
    await updateSubscriptionWithAddon(subscription.id, codes, 4, 0);

    // Add addon again
    await updateSubscriptionWithAddon(subscription.id, codes, 5, 1);

    // change addon quantity again
    await updateSubscriptionWithAddon(subscription.id, codes, 5, 3);
  });
});
