// import global e2e obj
import { Console } from 'console';
import './helper/E2EJestGlobal';
import {
  createAndActivateSubscription,
  createDraftRenewal,
  modifyPrice,
  previewSubscription,
  printFileName,
  printTestName,
  updateSubscription,
} from './helper/Functions';

const codes = {
  planName: 'DNNE Cloud EVOQ Engage',
  mainItem: 'DNNE-SA-Cus-STA',
  addonItem: 'DNNE-SA-Sub-ADD',
};

describe('subscription-addon-4', () => {
  beforeAll(async () => {
    printFileName();
    await e2e.testUtils.createTestCustomer();
  });

  beforeEach(() => {
    printTestName();
  });

  it('support level price added to items updating subscription', async () => {
    const createSubscriptionBody: any = {
      frequency: 'ANNUALLY',
      planCode: codes.planName,
      items: [
        { code: codes.mainItem, quantity: 2 },
        { code: codes.addonItem, quantity: 3 },
      ],
    };
    let preview = (await previewSubscription(createSubscriptionBody)).body;
    expect(preview).toEqual(
      expect.objectContaining({
        items: [
          expect.objectContaining({
            code: 'DNNE-SA-Cus-STA',
            title: 'DNNE Cloud EVOQ Engage',
            quantity: 2,
            amount: 101500,
          }),
          expect.objectContaining({
            code: 'DNNE-SA-Sub-ADD',
            title: 'DNNE Subscription Addon',
            quantity: 3,
            amount: 27000,
          }),
        ],
        totalAmount: 128500,
        totalListPrice: 128500,
        successPlanPremium: 0
      })
    );
    const subscription = await createAndActivateSubscription(createSubscriptionBody);
    expect(subscription).toEqual(
      expect.objectContaining({
        status: 'ACTIVE',
        plan: expect.objectContaining({
          code: 'DNNE-SA-Cus-STA-PLA-002',
          title: 'DNNE Cloud EVOQ Engage',
        }),
        items: [
          expect.objectContaining({
            code: 'DNNE-SA-Cus-STA',
            title: 'DNNE Cloud EVOQ Engage',
            required: true,
            prices: expect.arrayContaining([
              expect.objectContaining({
                ranges: expect.arrayContaining([
                  expect.objectContaining({
                    fromQuantity: 0,
                    price: 50750,
                  }),
                ]),
              }),
            ]),
            amount: 101500,
          }),
          expect.objectContaining({
            code: 'DNNE-SA-Sub-ADD',
            title: 'DNNE Subscription Addon',
            prices: expect.arrayContaining([
              expect.objectContaining({
                ranges: expect.arrayContaining([
                  expect.objectContaining({
                    fromQuantity: 0,
                    price: 9000,
                  }),
                ]),
              }),
            ]),
            amount: 27000,
          }),
        ],
        includedItems: [
          expect.objectContaining({
            code: 'DNNE-SA-Cus-STA',
            quantity: 2,
          }),
          expect.objectContaining({
            code: 'DNNE-SA-Sub-ADD',
            quantity: 3,
          }),
        ],
        totalAmount: 128500,
      })
    );

    await modifyPrice(subscription.id, 0.4);

    const updateSubscriptionBody: any = {
      frequency: 'ANNUALLY',
      planCode: codes.planName,
      items: [
        { code: codes.mainItem, quantity: 2 },
        { code: codes.addonItem, quantity: 0 },
      ],
    };
    preview = (await previewSubscription(updateSubscriptionBody, subscription.id)).body;
    expect(preview).toEqual(
      expect.objectContaining({
        items: [
          expect.objectContaining({
            code: 'DNNE-SA-Cus-STA',
            title: 'DNNE Cloud EVOQ Engage',
            quantity: 2,
            amount: 60900,
          }),
        ],
        totalAmount: 60900
      })
    );
    let updatedSubscription = await updateSubscription(subscription.id, updateSubscriptionBody);
    expect(updatedSubscription).toEqual(
      expect.objectContaining({
        status: 'DRAFT',
        plan: expect.objectContaining({
          code: 'DNNE-SA-Cus-STA-PLA-002',
          title: 'DNNE Cloud EVOQ Engage',
        }),
        items: [
          expect.objectContaining({
            code: 'DNNE-SA-Cus-STA',
            title: 'DNNE Cloud EVOQ Engage',
            required: true,
            prices: expect.arrayContaining([
              expect.objectContaining({
                ranges: expect.arrayContaining([
                  expect.objectContaining({
                    fromQuantity: 0,
                    price: 30450,
                  }),
                ]),
              }),
            ]),
            amount: 60900,
          }),
          expect.objectContaining({
            code: 'DNNE-SA-Sub-ADD',
            title: 'DNNE Subscription Addon',
            prices: expect.arrayContaining([
              expect.objectContaining({
                ranges: expect.arrayContaining([
                  expect.objectContaining({
                    fromQuantity: 0,
                    price: 5400,
                  }),
                ]),
              }),
            ]),
            amount: 0,
          }),
        ],
        includedItems: [
          expect.objectContaining({
            code: 'DNNE-SA-Cus-STA',
            quantity: 2,
          }),
        ],
        totalAmount: 60900,
      })
    );

    updateSubscriptionBody.items[0].quantity = 3;
    updateSubscriptionBody.items[1].quantity = 3;
    preview = (await previewSubscription(updateSubscriptionBody, subscription.id)).body;
    expect(preview).toEqual(
      expect.objectContaining({
        items: [
          expect.objectContaining({
            code: 'DNNE-SA-Cus-STA',
            title: 'DNNE Cloud EVOQ Engage',
            quantity: 3,
            amount: 91350,
          }),
          expect.objectContaining({
            code: 'DNNE-SA-Sub-ADD',
            title: 'DNNE Subscription Addon',
            quantity: 3,
            amount: 16200,
          }),
        ],
        totalAmount: 107550
      })
    );
    updatedSubscription = await updateSubscription(subscription.id, updateSubscriptionBody);
    expect(updatedSubscription).toEqual(
      expect.objectContaining({
        status: 'DRAFT',
        plan: expect.objectContaining({
          code: 'DNNE-SA-Cus-STA-PLA-002',
          title: 'DNNE Cloud EVOQ Engage',
        }),
        items: [
          expect.objectContaining({
            code: 'DNNE-SA-Cus-STA',
            title: 'DNNE Cloud EVOQ Engage',
            required: true,
            prices: expect.arrayContaining([
              expect.objectContaining({
                ranges: expect.arrayContaining([
                  expect.objectContaining({
                    fromQuantity: 0,
                    price: 30450,
                  }),
                ]),
              }),
            ]),
            amount: 91350,
          }),
          expect.objectContaining({
            code: 'DNNE-SA-Sub-ADD',
            title: 'DNNE Subscription Addon',
            prices: expect.arrayContaining([
              expect.objectContaining({
                ranges: expect.arrayContaining([
                  expect.objectContaining({
                    fromQuantity: 0,
                    price: 5400,
                  }),
                ]),
              }),
            ]),
            amount: 16200,
          }),
        ],
        includedItems: [
          expect.objectContaining({
            code: 'DNNE-SA-Cus-STA',
            quantity: 3,
          }),
          expect.objectContaining({
            code: 'DNNE-SA-Sub-ADD',
            quantity: 3,
          }),
        ],
        totalAmount: 107550,
      })
    );
  });

  it('support level price added to items renewing subscription not included addon', async () => {
    const createSubscriptionBody: any = {
      frequency: 'ANNUALLY',
      planCode: codes.planName,
      items: [{ code: codes.mainItem, quantity: 4 }],
    };
    let preview = (await previewSubscription(createSubscriptionBody)).body;
    expect(preview).toEqual(
      expect.objectContaining({
        items: [
          expect.objectContaining({
            code: 'DNNE-SA-Cus-STA',
            title: 'DNNE Cloud EVOQ Engage',
            quantity: 4,
            amount: 203000,
          }),
        ],
        totalAmount: 203000,
        totalListPrice: 203000,
        successPlanPremium: 0
      })
    );
    let subscription = await createAndActivateSubscription(createSubscriptionBody);
    expect(subscription).toEqual(
      expect.objectContaining({
        status: 'ACTIVE',
        plan: expect.objectContaining({
          code: 'DNNE-SA-Cus-STA-PLA-002',
          title: 'DNNE Cloud EVOQ Engage',
        }),
        items: [
          expect.objectContaining({
            code: 'DNNE-SA-Cus-STA',
            title: 'DNNE Cloud EVOQ Engage',
            required: true,
            prices: expect.arrayContaining([
              expect.objectContaining({
                ranges: expect.arrayContaining([
                  expect.objectContaining({
                    fromQuantity: 0,
                    price: 50750,
                  }),
                ]),
              }),
            ]),
            amount: 203000,
          }),
          expect.objectContaining({
            code: 'DNNE-SA-Sub-ADD',
            title: 'DNNE Subscription Addon',
            prices: expect.arrayContaining([
              expect.objectContaining({
                ranges: expect.arrayContaining([
                  expect.objectContaining({
                    fromQuantity: 0,
                    price: 9000,
                  }),
                ]),
              }),
            ]),
            amount: 0,
          }),
        ],
        includedItems: [
          expect.objectContaining({
            code: 'DNNE-SA-Cus-STA',
            quantity: 4,
          }),
        ],
        totalAmount: 203000,
      })
    );

    await modifyPrice(subscription.id, 0.5);
    subscription = await createDraftRenewal(subscription.id);
    expect(subscription).toEqual(
      expect.objectContaining({
        status: 'DRAFT',
        plan: expect.objectContaining({
          code: 'DNNE-SA-Cus-STA-PLA-002',
          title: 'DNNE Cloud EVOQ Engage',
        }),
        items: [
          expect.objectContaining({
            code: 'DNNE-SA-Cus-STA',
            title: 'DNNE Cloud EVOQ Engage',
            required: true,
            prices: expect.arrayContaining([
              expect.objectContaining({
                ranges: expect.arrayContaining([
                  expect.objectContaining({
                    fromQuantity: 0,
                    price: 36793.75,
                  }),
                ]),
              }),
            ]),
            amount: 147175,
          }),
          expect.objectContaining({
            code: 'DNNE-SA-Sub-ADD',
            title: 'DNNE Subscription Addon',
            prices: expect.arrayContaining([
              expect.objectContaining({
                ranges: expect.arrayContaining([
                  expect.objectContaining({
                    fromQuantity: 0,
                    price: 9000,
                  }),
                ]),
              }),
            ]),
            amount: 0,
          }),
        ],
        includedItems: [
          expect.objectContaining({
            code: 'DNNE-SA-Cus-STA',
            quantity: 4,
          }),
        ],
        totalAmount: 147175,
      })
    );

    const updateSubscriptionBody: any = {
      frequency: 'ANNUALLY',
      planCode: codes.planName,
      items: [
        { code: codes.mainItem, quantity: 2 },
        { code: codes.addonItem, quantity: 2 },
      ],
    };
    preview = (await previewSubscription(updateSubscriptionBody, subscription.id)).body;
    expect(preview).toEqual(
      expect.objectContaining({
        items: [
          expect.objectContaining({
            code: 'DNNE-SA-Cus-STA',
            title: 'DNNE Cloud EVOQ Engage',
            quantity: 2,
            amount: 101500,
          }),
          expect.objectContaining({
            code: 'DNNE-SA-Sub-ADD',
            title: 'DNNE Subscription Addon',
            quantity: 2,
            amount: 18000,
          }),
        ],
        totalAmount: 119500
      })
    );
    subscription = await updateSubscription(subscription.id, updateSubscriptionBody);
    expect(subscription).toEqual(
      expect.objectContaining({
        status: 'DRAFT',
        plan: expect.objectContaining({
          code: 'DNNE-SA-Cus-STA-PLA-002',
          title: 'DNNE Cloud EVOQ Engage',
        }),
        items: [
          expect.objectContaining({
            code: 'DNNE-SA-Cus-STA',
            title: 'DNNE Cloud EVOQ Engage',
            required: true,
            prices: expect.arrayContaining([
              expect.objectContaining({
                ranges: expect.arrayContaining([
                  expect.objectContaining({
                    fromQuantity: 0,
                    price: 50750,
                  }),
                ]),
              }),
            ]),
            amount: 101500,
          }),
          expect.objectContaining({
            code: 'DNNE-SA-Sub-ADD',
            title: 'DNNE Subscription Addon',
            prices: expect.arrayContaining([
              expect.objectContaining({
                ranges: expect.arrayContaining([
                  expect.objectContaining({
                    fromQuantity: 0,
                    price: 9000,
                  }),
                ]),
              }),
            ]),
            amount: 18000,
          }),
        ],
        includedItems: [
          expect.objectContaining({
            code: 'DNNE-SA-Cus-STA',
            quantity: 2,
          }),
          expect.objectContaining({
            code: 'DNNE-SA-Sub-ADD',
            quantity: 2,
          }),
        ],
        totalAmount: 119500,
      })
    );

    updateSubscriptionBody.items[0].quantity = 4;
    updateSubscriptionBody.items[1].quantity = 1;
    preview = (await previewSubscription(updateSubscriptionBody, subscription.id)).body;
    expect(preview).toEqual(
      expect.objectContaining({
        items: [
          expect.objectContaining({
            code: 'DNNE-SA-Cus-STA',
            title: 'DNNE Cloud EVOQ Engage',
            quantity: 4,
            amount: 147175,
          }),
          expect.objectContaining({
            code: 'DNNE-SA-Sub-ADD',
            title: 'DNNE Subscription Addon',
            quantity: 1,
            amount: 9000,
          }),
        ],
        totalAmount: 156175
      })
    );
    subscription = await updateSubscription(subscription.id, updateSubscriptionBody);
    expect(subscription).toEqual(
      expect.objectContaining({
        status: 'DRAFT',
        plan: expect.objectContaining({
          code: 'DNNE-SA-Cus-STA-PLA-002',
          title: 'DNNE Cloud EVOQ Engage',
        }),
        items: [
          expect.objectContaining({
            code: 'DNNE-SA-Cus-STA',
            title: 'DNNE Cloud EVOQ Engage',
            required: true,
            prices: expect.arrayContaining([
              expect.objectContaining({
                ranges: expect.arrayContaining([
                  expect.objectContaining({
                    fromQuantity: 0,
                    price: 36793.75,
                  }),
                ]),
              }),
            ]),
            amount: 147175,
          }),
          expect.objectContaining({
            code: 'DNNE-SA-Sub-ADD',
            title: 'DNNE Subscription Addon',
            prices: expect.arrayContaining([
              expect.objectContaining({
                ranges: expect.arrayContaining([
                  expect.objectContaining({
                    fromQuantity: 0,
                    price: 9000,
                  }),
                ]),
              }),
            ]),
            amount: 9000,
          }),
        ],
        includedItems: [
          expect.objectContaining({
            code: 'DNNE-SA-Cus-STA',
            quantity: 4,
          }),
          expect.objectContaining({
            code: 'DNNE-SA-Sub-ADD',
            quantity: 1,
          }),
        ],
        totalAmount: 156175,
      })
    );
  });

  it('support level price added to items renewing subscription with addon', async () => {
    const createSubscriptionBody: any = {
      frequency: 'ANNUALLY',
      planCode: codes.planName,
      items: [
        { code: codes.mainItem, quantity: 5 },
        { code: codes.addonItem, quantity: 5 },
      ],
    };
    let preview = (await previewSubscription(createSubscriptionBody)).body;
    expect(preview).toEqual(
      expect.objectContaining({
        items: [
          expect.objectContaining({
            code: 'DNNE-SA-Cus-STA',
            title: 'DNNE Cloud EVOQ Engage',
            quantity: 5,
            amount: 253750,
          }),
          expect.objectContaining({
            code: 'DNNE-SA-Sub-ADD',
            title: 'DNNE Subscription Addon',
            quantity: 5,
            amount: 45000,
          }),
        ],
        totalAmount: 298750,
        totalListPrice: 298750,
        successPlanPremium: 0
      })
    );
    let subscription = await createAndActivateSubscription(createSubscriptionBody);
    expect(subscription).toEqual(
      expect.objectContaining({
        status: 'ACTIVE',
        plan: expect.objectContaining({
          code: 'DNNE-SA-Cus-STA-PLA-002',
          title: 'DNNE Cloud EVOQ Engage',
        }),
        items: [
          expect.objectContaining({
            code: 'DNNE-SA-Cus-STA',
            title: 'DNNE Cloud EVOQ Engage',
            required: true,
            prices: expect.arrayContaining([
              expect.objectContaining({
                ranges: expect.arrayContaining([
                  expect.objectContaining({
                    fromQuantity: 0,
                    price: 50750,
                  }),
                ]),
              }),
            ]),
            amount: 253750,
          }),
          expect.objectContaining({
            code: 'DNNE-SA-Sub-ADD',
            title: 'DNNE Subscription Addon',
            prices: expect.arrayContaining([
              expect.objectContaining({
                ranges: expect.arrayContaining([
                  expect.objectContaining({
                    fromQuantity: 0,
                    price: 9000,
                  }),
                ]),
              }),
            ]),
            amount: 45000,
          }),
        ],
        includedItems: [
          expect.objectContaining({
            code: 'DNNE-SA-Cus-STA',
            quantity: 5,
          }),
          expect.objectContaining({
            code: 'DNNE-SA-Sub-ADD',
            quantity: 5,
          }),
        ],
        totalAmount: 298750,
      })
    );

    await modifyPrice(subscription.id, 0.6);
    subscription = await createDraftRenewal(subscription.id);
    expect(subscription).toEqual(
      expect.objectContaining({
        status: 'DRAFT',
        plan: expect.objectContaining({
          code: 'DNNE-SA-Cus-STA-PLA-002',
          title: 'DNNE Cloud EVOQ Engage',
        }),
        items: [
          expect.objectContaining({
            code: 'DNNE-SA-Cus-STA',
            title: 'DNNE Cloud EVOQ Engage',
            required: true,
            prices: expect.arrayContaining([
              expect.objectContaining({
                ranges: expect.arrayContaining([
                  expect.objectContaining({
                    fromQuantity: 0,
                    price: 29435,
                  }),
                ]),
              }),
            ]),
            amount: 147175,
          }),
          expect.objectContaining({
            code: 'DNNE-SA-Sub-ADD',
            title: 'DNNE Subscription Addon',
            prices: expect.arrayContaining([
              expect.objectContaining({
                ranges: expect.arrayContaining([
                  expect.objectContaining({
                    fromQuantity: 0,
                    price: 5220,
                  }),
                ]),
              }),
            ]),
            amount: 26100,
          }),
        ],
        includedItems: [
          expect.objectContaining({
            code: 'DNNE-SA-Cus-STA',
            quantity: 5,
          }),
          expect.objectContaining({
            code: 'DNNE-SA-Sub-ADD',
            quantity: 5,
          }),
        ],
        totalAmount: 173275,
      })
    );

    const updateSubscriptionBody: any = {
      frequency: 'ANNUALLY',
      planCode: codes.planName,
      items: [
        { code: codes.mainItem, quantity: 2 },
        { code: codes.addonItem, quantity: 2 },
      ],
    };
    preview = (await previewSubscription(updateSubscriptionBody, subscription.id)).body;
    expect(preview).toEqual(
      expect.objectContaining({
        items: [
          expect.objectContaining({
            code: 'DNNE-SA-Cus-STA',
            title: 'DNNE Cloud EVOQ Engage',
            quantity: 2,
            amount: 101500,
          }),
          expect.objectContaining({
            code: 'DNNE-SA-Sub-ADD',
            title: 'DNNE Subscription Addon',
            quantity: 2,
            amount: 18000,
          }),
        ],
        totalAmount: 119500
      })
    );
    subscription = await updateSubscription(subscription.id, updateSubscriptionBody);
    expect(subscription).toEqual(
      expect.objectContaining({
        status: 'DRAFT',
        plan: expect.objectContaining({
          code: 'DNNE-SA-Cus-STA-PLA-002',
          title: 'DNNE Cloud EVOQ Engage',
        }),
        items: [
          expect.objectContaining({
            code: 'DNNE-SA-Cus-STA',
            title: 'DNNE Cloud EVOQ Engage',
            required: true,
            prices: expect.arrayContaining([
              expect.objectContaining({
                ranges: expect.arrayContaining([
                  expect.objectContaining({
                    fromQuantity: 0,
                    price: 50750,
                  }),
                ]),
              }),
            ]),
            amount: 101500,
          }),
          expect.objectContaining({
            code: 'DNNE-SA-Sub-ADD',
            title: 'DNNE Subscription Addon',
            prices: expect.arrayContaining([
              expect.objectContaining({
                ranges: expect.arrayContaining([
                  expect.objectContaining({
                    fromQuantity: 0,
                    price: 9000,
                  }),
                ]),
              }),
            ]),
            amount: 18000,
          }),
        ],
        includedItems: [
          expect.objectContaining({
            code: 'DNNE-SA-Cus-STA',
            quantity: 2,
          }),
          expect.objectContaining({
            code: 'DNNE-SA-Sub-ADD',
            quantity: 2,
          }),
        ],
        totalAmount: 119500,
      })
    );

    updateSubscriptionBody.items[0].quantity = 5;
    updateSubscriptionBody.items[1].quantity = 1;
    preview = (await previewSubscription(updateSubscriptionBody, subscription.id)).body;
    expect(preview).toEqual(
      expect.objectContaining({
        items: [
          expect.objectContaining({
            code: 'DNNE-SA-Cus-STA',
            title: 'DNNE Cloud EVOQ Engage',
            quantity: 5,
            amount: 147175,
          }),
          expect.objectContaining({
            code: 'DNNE-SA-Sub-ADD',
            title: 'DNNE Subscription Addon',
            quantity: 1,
            amount: 5220,
          }),
        ],
        totalAmount: 152395,
        totalListPrice: 262750,
        successPlanPremium: 0
      })
    );
    subscription = await updateSubscription(subscription.id, updateSubscriptionBody);
    expect(subscription).toEqual(
      expect.objectContaining({
        status: 'DRAFT',
        plan: expect.objectContaining({
          code: 'DNNE-SA-Cus-STA-PLA-002',
          title: 'DNNE Cloud EVOQ Engage',
        }),
        items: [
          expect.objectContaining({
            code: 'DNNE-SA-Cus-STA',
            title: 'DNNE Cloud EVOQ Engage',
            required: true,
            prices: expect.arrayContaining([
              expect.objectContaining({
                ranges: expect.arrayContaining([
                  expect.objectContaining({
                    fromQuantity: 0,
                    price: 29435,
                  }),
                ]),
              }),
            ]),
            amount: 147175,
          }),
          expect.objectContaining({
            code: 'DNNE-SA-Sub-ADD',
            title: 'DNNE Subscription Addon',
            prices: expect.arrayContaining([
              expect.objectContaining({
                ranges: expect.arrayContaining([
                  expect.objectContaining({
                    fromQuantity: 0,
                    price: 5220,
                  }),
                ]),
              }),
            ]),
            amount: 5220,
          }),
        ],
        includedItems: [
          expect.objectContaining({
            code: 'DNNE-SA-Cus-STA',
            quantity: 5,
          }),
          expect.objectContaining({
            code: 'DNNE-SA-Sub-ADD',
            quantity: 1,
          }),
        ],
        totalAmount: 152395,
      })
    );
  });
});
