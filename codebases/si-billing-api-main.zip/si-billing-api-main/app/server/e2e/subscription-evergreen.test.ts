// import global e2e obj
import './helper/E2EJestGlobal';
import request from 'supertest';
import tsiapp from '../src/tsiappe2e';
import {
  activate,
  assertTotals,
  createAndActivateSubscription,
  createInvoice,
  getSubscriptionPlans,
  modifyPrice,
  previewSubscription,
  previewSubscriptionAndAssert,
  printFileName,
  printTestName,
  updateSubscription,
} from './helper/Functions';
import logger from '../src/common/logger';

let subscriptionPlans;
const planCodeStandard = 'DNNE Customer Cloud EVOQ Evergreen';
const mainItemStandard = 'DNNE-SA-CusEG-BAS';
const planCodeProfessional = 'DNNE Customer Cloud EVOQ Evergreen Professional';
const mainItemProfessional = 'DNNE-SA-CusEG-PRO';
const pastDate = new Date();
let effectiveDate;

describe('subscription-evergreen', () => {
  beforeAll(async () => {
    printFileName();
    await e2e.testUtils.createTestCustomer();
    subscriptionPlans = await getSubscriptionPlans();
    pastDate.setDate(pastDate.getDate() - 20);
    effectiveDate = pastDate.toISOString().split('T')[0];
  });

  beforeEach(() => {
    printTestName();
  });

  it('update downgrading plan', async () => {
    const discount = 0.6;
    const createSubscriptionBody = {
      frequency: 'MONTHLY',
      planCode: planCodeProfessional,
      items: [{ code: mainItemProfessional, quantity: 5 }],
      effectiveDate: effectiveDate,
    };
    const updateSubscriptionBody = {
      frequency: 'MONTHLY',
      planCode: planCodeStandard,
      items: [{ code: mainItemStandard, quantity: 5 }],
    };

    const subscriptionId = await createAndUpdate(
      createSubscriptionBody,
      updateSubscriptionBody,
      discount,
      0,
      effectiveDate,
      true,
      true
    );

    // if try to preview or update again should give an error message
    const expected = {
      status: 500,
      text: expect.stringContaining('This subscription can not be updated. Please contact sales.'),
    };
    let res = await previewSubscription(updateSubscriptionBody, subscriptionId);
    expect(res).toEqual(expect.objectContaining(expected));

    res = await request(tsiapp.app())
      .put(`/api/v1/subscription/${subscriptionId}`)
      .send(createSubscriptionBody)
      .set('Authorization', e2e.testUtils.makeCustomerJWTHeader(e2e.testData.customer.id))
      .expect(500);

    expect(res).toEqual(expect.objectContaining(expected));
  });

  it('update downgrading quantity', async () => {
    const discount = 0.4;
    const createSubscriptionBody = {
      frequency: 'MONTHLY',
      planCode: planCodeProfessional,
      items: [{ code: mainItemProfessional, quantity: 5 }],
      effectiveDate: effectiveDate,
    };
    const updateSubscriptionBody = {
      frequency: 'MONTHLY',
      planCode: planCodeProfessional,
      items: [{ code: mainItemProfessional, quantity: 3 }],
    };

    await createAndUpdate(createSubscriptionBody, updateSubscriptionBody, discount, 0, effectiveDate, undefined, true);
  });

  it('update overpriced downgrading plan', async () => {
    const discount = -2;
    const createSubscriptionBody = {
      frequency: 'MONTHLY',
      planCode: planCodeProfessional,
      items: [{ code: mainItemProfessional, quantity: 5 }],
      effectiveDate: effectiveDate,
    };
    const updateSubscriptionBody = {
      frequency: 'MONTHLY',
      planCode: planCodeStandard,
      items: [{ code: mainItemStandard, quantity: 5 }],
    };

    await createAndUpdate(
      createSubscriptionBody,
      updateSubscriptionBody,
      discount,
      discount,
      effectiveDate,
      undefined,
      true
    );
  });

  it('update overpriced downgrading quantity', async () => {
    const discount = -3;

    const createSubscriptionBody = {
      frequency: 'MONTHLY',
      planCode: planCodeStandard,
      items: [{ code: mainItemStandard, quantity: 5 }],
      effectiveDate: effectiveDate,
    };
    const updateSubscriptionBody = {
      frequency: 'MONTHLY',
      planCode: planCodeStandard,
      items: [{ code: mainItemStandard, quantity: 3 }],
    };

    await createAndUpdate(
      createSubscriptionBody,
      updateSubscriptionBody,
      discount,
      discount,
      effectiveDate,
      undefined,
      true
    );
  });
});

async function createAndUpdate(
  createSubscriptionBody,
  updateSubscriptionBody,
  discount,
  afterDiscount,
  effectiveDate?,
  toCreateInvoice = false,
  isEvergreen = false
) {
  await previewSubscriptionAndAssert(
    createSubscriptionBody,
    subscriptionPlans,
    undefined,
    undefined,
    undefined,
    isEvergreen
  );
  const subscription = await createAndActivateSubscription(createSubscriptionBody);
  await modifyPrice(subscription.id, discount, effectiveDate);
  if (toCreateInvoice) {
    await createInvoice(subscription.id);
  }
  const preview = await previewSubscriptionAndAssert(
    updateSubscriptionBody,
    subscriptionPlans,
    { mainDiscount: afterDiscount },
    subscription.id,
    undefined,
    isEvergreen
  );
  let subscriptionUpdated = await updateSubscription(subscription.id, updateSubscriptionBody);
  assertTotals(preview, subscriptionUpdated);
  subscriptionUpdated = await activate(subscriptionUpdated.id);
  logger.debug(subscriptionUpdated);
  expect(subscriptionUpdated.status).toBe('PENDING_ACTIVATION');
  return subscription.id;
}
