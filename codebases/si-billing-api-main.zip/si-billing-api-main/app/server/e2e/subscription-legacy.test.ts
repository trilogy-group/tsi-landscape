// import global e2e obj
import request from 'supertest';
import tsiapp from '../src/tsiappe2e';
import './helper/E2EJestGlobal';
import { toBeDeepCloseTo } from 'jest-matcher-deep-close-to';
import {
  assertDistributionRatio,
  assertTotalIntervalValues,
  createAndActivateSubscription,
  createAndRenewDraft,
  createRenewal,
  getDiscountWithUptick,
  getSubscription,
  getSubscriptionPlans,
  modifyPrice,
  previewSubscriptionAndAssert,
  printFileName,
  printTestName,
  updateSubscription,
} from './helper/Functions';

expect.extend({ toBeDeepCloseTo });
let subscriptionPlans;

describe('subscription-legacy', () => {
  beforeAll(async () => {
    printFileName();
    await e2e.testUtils.createTestCustomer();
    subscriptionPlans = await getSubscriptionPlans();
  });

  beforeEach(() => {
    printTestName();
  });

  // if all of the revenue is allocated to the primary support item, then it’s a maintenance only Subscription,
  // and return it as a maintenance Subscription (support item with 100% price allocated should be returned, not main item)
  it('legacy subscription has all of the revenue is allocated to the primary support item', async () => {
    const planName = 'DNNE Legacy BAS PLA 4';
    const mainItemCode = 'DNNE-SA-Leg-STA';
    const addOnItemCode = 'DNNE-SA-Add-BAS';
    const discountMainItem = 1;

    const createSubscriptionBody = {
      frequency: 'ANNUALLY',
      planCode: planName,
      items: [
        { code: mainItemCode, quantity: 10 },
        { code: addOnItemCode, quantity: 10 },
      ],
    };

    const subscription = await createAndActivateSubscription(createSubscriptionBody, undefined, false);
    await modifyPrice(subscription.id, discountMainItem, null, [mainItemCode]);

    const getSubscriptionResponse = await getSubscription(subscription.id);
    expect(getSubscriptionResponse).toStrictEqual(
      expect.objectContaining({
        includedItems: expect.arrayContaining([
          expect.objectContaining({
            code: 'DNNE-SA-Add-BAS',
          }),
          expect.objectContaining({
            code: 'DNNE-SA-Leg-PLA',
          }),
        ]),
        items: expect.arrayContaining([
          expect.objectContaining({
            totalIntervalValue: 100,
            code: 'DNNE-SA-Add-BAS',
          }),
          expect.objectContaining({
            totalIntervalValue: 180,
            code: 'DNNE-SA-Leg-PLA',
          }),
        ]),
        plan: expect.objectContaining({
          productTier: 'Standard',
          supportLevel: 'Platinum',
        }),
        status: 'ACTIVE',
        totalIntervalValue: 280,
      })
    );
  });

  it('active legacy subscription should throw validation error on update attempt', async () => {
    const planName = 'DNNE Legacy BAS SIL 6';
    const mainItemCode = 'DNNE-SA-Leg-STA';
    const supportItemCode = 'DNNE-SA-Leg-SIL';
    const addOnItemCode = 'DNNE-SA-Add-BAS';

    const createSubscriptionBody = {
      frequency: 'ANNUALLY',
      planCode: planName,
      items: [
        { code: mainItemCode, quantity: 10 },
        { code: supportItemCode, quantity: 10 },
        { code: addOnItemCode, quantity: 10 },
      ],
    };

    const subscription = await createAndActivateSubscription(createSubscriptionBody);
    const res = await request(tsiapp.app())
      .put(`/api/v1/subscription/${subscription.id}`)
      .send(createSubscriptionBody)
      .set('Authorization', e2e.testUtils.makeCustomerJWTHeader(e2e.testData.customer.id))
      .expect(400);

    expect(res).toEqual(
      expect.objectContaining({
        status: 400,
        text: expect.stringContaining('Updates for the legacy subscriptions are not supported'),
      })
    );
  });

  it('renewal subscription should uptick when no quantities provided', async () => {
    const planName = 'DNNE Legacy BAS SIL 6';
    const newPlanName = 'DNNE Legacy BAS PLA 4';
    const mainItemCode = 'DNNE-SA-Leg-STA';
    const addOnItemCode = 'DNNE-SA-Add-BAS';
    const discount = 0.1;
    const uptick = 0.45;

    const createSubscriptionBody = {
      frequency: 'ANNUALLY',
      planCode: planName,
      items: [
        { code: mainItemCode, quantity: 10 },
        { code: addOnItemCode, quantity: 10 },
      ],
    };
    const updateSubscriptionBodyNoQuantity = {
      frequency: 'ANNUALLY',
      planCode: newPlanName,
      items: [{ code: mainItemCode }, { code: addOnItemCode }],
    };

    const { draftRenewal } = await createRenewal(createSubscriptionBody, discount);

    const preview = await previewSubscriptionAndAssert(
      updateSubscriptionBodyNoQuantity,
      subscriptionPlans,
      { mainDiscount: getDiscountWithUptick(discount, uptick) as number },
      draftRenewal.id,
      {
        frequency: 'ANNUALLY',
        totalAmount: 456.75,
        totalListPrice: 680,
        successPlanPremium: 63,
        items: [
          {
            title: 'DNNE Legacy EVOQ Basic',
            code: 'DNNE-SA-Leg-STA',
            quantity: 10,
            amount: 391.5,
          },
          {
            title: 'DNNE Addon',
            code: 'DNNE-SA-Add-BAS',
            quantity: 10,
            amount: 65.25,
          },
        ],
      }
    );
    expect(preview).toStrictEqual(
      expect.objectContaining({
        items: expect.arrayContaining([
          expect.objectContaining({
            code: mainItemCode,
            quantity: 10,
          }),
          expect.objectContaining({
            code: addOnItemCode,
            quantity: 10,
          }),
        ]),
      })
    );
    const draftSubscription = await updateSubscription(draftRenewal.id, updateSubscriptionBodyNoQuantity);
    expect(draftSubscription.totalIntervalValue).toBeCloseTo(preview.totalAmount, 2);
  });

  it('legacy renewal subscription should uptick with reprice', async () => {
    const oldPlanName = 'DNNE Legacy BAS SIL 6';
    const newPlanName = 'DNNE Legacy BAS PLA 4';
    const mainItemCode = 'DNNE-SA-Leg-STA';
    const addOnItemCode = 'DNNE-SA-Add-BAS';
    const uptick = 0.45;

    const createSubscriptionBody = {
      frequency: 'ANNUALLY',
      planCode: oldPlanName,
      items: [
        { code: mainItemCode, quantity: 10 },
        { code: addOnItemCode, quantity: 10 },
      ],
    };

    const updateSubscriptionBody = {
      frequency: 'ANNUALLY',
      planCode: newPlanName,
      items: [
        { code: mainItemCode, quantity: 10 },
        { code: addOnItemCode, quantity: 10 },
      ],
    };

    // const renewalSubscription =
    await createAndRenewDraft(
      createSubscriptionBody,
      updateSubscriptionBody,
      0,
      subscriptionPlans,
      getDiscountWithUptick(0, uptick),
      [mainItemCode],
      addOnItemCode,
      {
        frequency: 'ANNUALLY',
        totalAmount: 507.5,
        totalListPrice: 680,
        successPlanPremium: 70,
        items: [
          {
            title: 'DNNE Legacy EVOQ Basic',
            code: 'DNNE-SA-Leg-STA',
            quantity: 10,
            amount: 435,
          },
          {
            title: 'DNNE Addon',
            code: 'DNNE-SA-Add-BAS',
            quantity: 10,
            amount: 72.5,
          },
        ],
      },
      507.5
    );
  });

  it('legacy renewal subscription should do new distribution ratio according to new success level', async () => {
    const oldPlanName = 'DNNE Legacy BAS SIL 6';
    const newPlanName = 'DNNE Legacy BAS PLA 4';
    const mainItemCode = 'DNNE-SA-Leg-STA';
    const supportItemCode = 'DNNE-SA-Leg-SIL';
    const newSupportItemCode = 'DNNE-SA-Leg-PLA';
    const addOnItemCode = 'DNNE-SA-Add-BAS';
    const expectedPreview = {
      frequency: 'ANNUALLY',
      totalAmount: 507.5,
      totalListPrice: 680,
      successPlanPremium: 70,
      items: [
        {
          title: 'DNNE Legacy EVOQ Basic',
          code: 'DNNE-SA-Leg-STA',
          quantity: 10,
          amount: 435,
        },
        {
          title: 'DNNE Addon',
          code: 'DNNE-SA-Add-BAS',
          quantity: 10,
          amount: 72.5,
        },
      ],
    };

    const createSubscriptionBody = {
      frequency: 'ANNUALLY',
      planCode: oldPlanName,
      items: [
        { code: mainItemCode, quantity: 10 },
        { code: addOnItemCode, quantity: 10 },
      ],
    };

    const updateSubscriptionBody = {
      frequency: 'ANNUALLY',
      planCode: newPlanName,
      items: [
        { code: mainItemCode, quantity: 10 },
        { code: addOnItemCode, quantity: 10 },
      ],
    };

    const { draftRenewal } = await createRenewal(createSubscriptionBody, 0, [mainItemCode], addOnItemCode);

    // This update should be ignored, as the prices from the active subscription are used for the preview calculation.
    await modifyPrice(draftRenewal.id, -1, null, [mainItemCode]);
    await modifyPrice(draftRenewal.id, -2, null, [supportItemCode]);

    await previewSubscriptionAndAssert(
      updateSubscriptionBody,
      subscriptionPlans,
      undefined,
      draftRenewal.id,
      expectedPreview
    );

    const updatedDraft = await updateSubscription(draftRenewal.id, updateSubscriptionBody);
    assertTotalIntervalValues(expectedPreview.totalAmount, updatedDraft);
    expect(updatedDraft.items.find((x) => x.code === mainItemCode).totalIntervalValue).toEqual(expectedPreview.items[0].amount);
    await assertDistributionRatio(updatedDraft.id, 0.45, mainItemCode, newSupportItemCode);
  });

  it('legacy renewal subscription should uptick without reprice if support level is the same', async () => {
    const oldPlanName = 'DNNE Legacy BAS SIL 6';
    const newPlanName = 'DNNE Legacy BAS PLA 4';
    const mainItemCode = 'DNNE-SA-Leg-STA';
    const addOnItemCode = 'DNNE-SA-Add-BAS';
    const uptick = 0.45;

    const createSubscriptionBody = {
      frequency: 'ANNUALLY',
      planCode: oldPlanName,
      items: [
        { code: mainItemCode, quantity: 10 },
        { code: addOnItemCode, quantity: 10 },
      ],
    };

    const updateSubscriptionBody = {
      frequency: 'ANNUALLY',
      planCode: newPlanName,
      items: [
        { code: mainItemCode, quantity: 10 },
        { code: addOnItemCode, quantity: 10 },
      ],
    };

    const expectedPreviewResponse = {
      frequency: 'ANNUALLY',
      totalAmount: 507.5,
      totalListPrice: 680,
      successPlanPremium: 70,
      items: [
        {
          title: 'DNNE Legacy EVOQ Basic',
          code: 'DNNE-SA-Leg-STA',
          quantity: 10,
          amount: 435,
        },
        {
          title: 'DNNE Addon',
          code: 'DNNE-SA-Add-BAS',
          quantity: 10,
          amount: 72.5,
        },
      ],
    };
    const expectedTotalIntervalValue = 507.5;

    const { renewalSubscription } = await createAndRenewDraft(
      createSubscriptionBody,
      updateSubscriptionBody,
      0,
      subscriptionPlans,
      getDiscountWithUptick(0, uptick),
      [mainItemCode],
      addOnItemCode,
      expectedPreviewResponse,
      expectedTotalIntervalValue
    );

    await previewSubscriptionAndAssert(
      updateSubscriptionBody,
      subscriptionPlans,
      undefined,
      renewalSubscription.id,
      expectedPreviewResponse
    );

    const draftSubscription = await updateSubscription(renewalSubscription.id, updateSubscriptionBody);
    assertTotalIntervalValues(expectedTotalIntervalValue, draftSubscription);
  });
});
