// import global e2e obj
import './helper/E2EJestGlobal';
import request from 'supertest';
import tsiapp from '../src/tsiappe2e';
import { createAndActivateSubscription, printFileName, printTestName } from './helper/Functions';
import logger from '../src/common/logger';

describe('subscription-list', () => {
  beforeEach(() => {
    printTestName();
  });

  beforeAll(async () => {
    printFileName();
    await e2e.testUtils.createTestCustomer();
  });

  it('listCustomerSubscription-regular', async () => {
    const subscription1 = await createAndActivateSubscription({
      frequency: 'ANNUALLY',
      planCode: 'DNNE Customer Cloud EVOQ BASIC Additional',
      items: [
        {
          code: 'DNNE-SA-ADDSUB-BAS',
          quantity: 1,
        },
      ],
    });

    const subscription2 = await createAndActivateSubscription({
      frequency: 'MONTHLY',
      planCode: 'DNNE Customer Cloud EVOQ BASIC',
      items: [
        {
          code: 'DNNE-SA-Cus-BAS',
          quantity: 1,
        },
      ],
    });

    let res = await request(tsiapp.app())
      .get('/api/v1/subscriptions')
      .send()
      .set('Authorization', 'Bearer ' + e2e.testUtils.makeJWT({ cid: e2e.testData.customer.id }))
      .expect(200);
    const allCustomerSubscriptions = res.body;
    expect(allCustomerSubscriptions).toEqual(expect.arrayContaining([expect.objectContaining(subscription1)]));
    expect(allCustomerSubscriptions).toEqual(expect.arrayContaining([expect.objectContaining(subscription2)]));
    logger.debug(JSON.stringify(allCustomerSubscriptions, null, 2));
    res = await request(tsiapp.app())
      .get('/api/v1/subscriptions')
      .send()
      .set('Authorization', 'Bearer ' + e2e.testUtils.makeJWT({ pvc: 'SA-Cus', cid: e2e.testData.customer.id }))
      .expect(200);
    const saCusCustomerSubscription = res.body;
    logger.debug(JSON.stringify(saCusCustomerSubscription, null, 2));
    expect(saCusCustomerSubscription).not.toEqual(expect.arrayContaining([expect.objectContaining(subscription1)]));
    expect(saCusCustomerSubscription).toEqual(expect.arrayContaining([expect.objectContaining(subscription2)]));
  });

  it('listCustomerSubscription-support-only-plan', async () => {
    const subscription1 = await createAndActivateSubscription({
      frequency: 'ANNUALLY',
      planCode: 'DNNE Std Silver Sup',
      items: [
        {
          code: 'DNNE-SA-Cus-SIL',
          quantity: 1,
        },
      ],
    });

    const res = await request(tsiapp.app())
      .get('/api/v1/subscriptions')
      .send()
      .set('Authorization', 'Bearer ' + e2e.testUtils.makeJWT({ cid: e2e.testData.customer.id }))
      .expect(200);
    const allCustomerSubscriptions = res.body;
    expect(allCustomerSubscriptions).toEqual(expect.arrayContaining([expect.objectContaining(subscription1)]));
    logger.debug(JSON.stringify(allCustomerSubscriptions, null, 2));
  });
});
