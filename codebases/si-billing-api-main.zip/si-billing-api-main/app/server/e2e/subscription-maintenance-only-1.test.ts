// import global e2e obj
import './helper/E2EJestGlobal';
import { toBeDeepCloseTo } from 'jest-matcher-deep-close-to';
import {
  checkPrices,
  createAndActivateSubscription,
  createDraftRenewal,
  getDiscountWithUptick,
  getSubscriptionPlans,
  modifyPrice,
  printFileName,
  printTestName,
  updateAndActivateSubscription,
  updateSubscription,
} from './helper/Functions';
import logger from '../src/common/logger';

expect.extend({ toBeDeepCloseTo });
let subscriptionPlans;

describe('subscription-maintenance-only-1', () => {
  beforeAll(async () => {
    printFileName();
    await e2e.testUtils.createTestCustomer();
    subscriptionPlans = await getSubscriptionPlans();
  });

  beforeEach(() => {
    printTestName();
  });

  // LAMBDA-23485
  it('create maintenance only subscription', async () => {
    const planCode = 'DNNE Std Silver Sup';
    const mainItem = 'DNNE-SA-Cus-SIL';

    const createSubscriptionBody = {
      frequency: 'ANNUALLY',
      planCode: planCode,
      items: [{ code: mainItem, quantity: 1 }],
    };

    const subscription = await createAndActivateSubscription(createSubscriptionBody);
    logger.debug(`subscription: ${JSON.stringify(subscription)}`);

    checkPrices(planCode, subscription.items, 0, subscriptionPlans);
  });

  // LAMBDA-23488
  it('update maintenance only subscription', async () => {
    const planCode = 'DNNE Std Silver Sup';
    const mainItem = 'DNNE-SA-Cus-SIL';

    const createSubscriptionBody = {
      frequency: 'ANNUALLY',
      planCode: planCode,
      items: [{ code: mainItem, quantity: 1 }],
    };

    const subscription = await updateSubscriptionAndAssert(createSubscriptionBody, 1);
    logger.debug(`subscription: ${JSON.stringify(subscription)}`);

    checkPrices(planCode, subscription.items, 0, subscriptionPlans);
  });

  it('renew draft maintenance only with onetime items subscription silver', async () => {
    const planCode = 'DNNE Std Silver Sup'; // DNNE Support Plan //DNNE Std Slvr Sup WOOT //DNNE Std Silver Sup
    const mainItemCode = 'DNNE-SA-Cus-SIL';
    const addonCode = 'DNNE-SA-Add-BAS';
    const oneTime1Code = 'DNNE-SA-OT-PT';
    const oneTime2Code = 'DNNE-SA-OT-GRI';
    const discountMainItem = 0.5;
    const discountAddon = 0.4;
    const uptick = 0.25;

    const createSubscriptionBody = {
      frequency: 'ANNUALLY',
      planCode: planCode,
      items: [
        { code: mainItemCode, quantity: 10 },
        { code: addonCode, quantity: 10 },
        { code: oneTime1Code, quantity: 1 },
        { code: oneTime2Code, quantity: 1 },
      ],
    };
    const subscription = await createAndActivateSubscription(createSubscriptionBody);
    await modifyPrice(subscription.id, discountMainItem, null, [mainItemCode]);
    await modifyPrice(subscription.id, discountAddon, null, [addonCode]);
    const renewalSubscription = await createDraftRenewal(subscription.id);
    checkPrices(
      planCode,
      renewalSubscription.items.filter((i) => i.code === mainItemCode),
      getDiscountWithUptick(discountMainItem, uptick),
      subscriptionPlans,
      [mainItemCode]
    );
    checkPrices(
      planCode,
      renewalSubscription.items.filter((i) => i.code === addonCode),
      getDiscountWithUptick(discountAddon, uptick),
      subscriptionPlans,
      [mainItemCode]
    );
    checkPrices(
      planCode,
      renewalSubscription.items.filter((i) => i.code === oneTime1Code || i.code === oneTime2Code),
      1,
      subscriptionPlans,
      [mainItemCode]
    );
  });

  it('renew draft maintenance only with onetime items increasing quantity', async () => {
    const planName = 'DNNE Std Silver Sup';
    const mainItemCode = 'DNNE-SA-Cus-SIL';
    const supportItemCode = 'DNNE-SA-Add-BAS';
    const oneTime1Code = 'DNNE-SA-OT-PT';
    const oneTime2Code = 'DNNE-SA-OT-GRI';
    const discountMainItem = 0.5;
    const discountSupportItem = 0.4;
    const uptick = 0.25;

    const createSubscriptionBody = {
      frequency: 'ANNUALLY',
      planCode: planName,
      items: [
        { code: mainItemCode, quantity: 10 },
        { code: supportItemCode, quantity: 10 },
        { code: oneTime1Code, quantity: 1 },
        { code: oneTime2Code, quantity: 1 },
      ],
    };
    const updateSubscriptionBody = {
      frequency: 'ANNUALLY',
      planCode: planName,
      items: [
        { code: mainItemCode, quantity: 20 },
        { code: supportItemCode, quantity: 20 },
        { code: oneTime1Code, quantity: 1 },
        { code: oneTime2Code, quantity: 1 },
      ],
    };
    const discounts = {
      mainDiscount: discountMainItem,
      addons: [{ code: supportItemCode, discount: discountSupportItem }],
    };

    const subscription = await createAndActivateSubscription(createSubscriptionBody);
    await modifyPrice(subscription.id, discountMainItem, null, [mainItemCode]);
    await modifyPrice(subscription.id, discountSupportItem, null, [supportItemCode]);
    const renewalSubscription = await createDraftRenewal(subscription.id);
    const draftSubscription = await updateSubscription(renewalSubscription.id, updateSubscriptionBody);

    checkPrices(
      planName,
      draftSubscription.items.filter((i) => i.code === mainItemCode),
      getDiscountWithUptick(discounts, uptick),
      subscriptionPlans,
      [mainItemCode]
    );
    checkPrices(
      planName,
      draftSubscription.items.filter((i) => i.code === supportItemCode),
      getDiscountWithUptick(discounts, uptick),
      subscriptionPlans,
      [mainItemCode]
    );
    checkPrices(
      planName,
      draftSubscription.items.filter((i) => i.code === oneTime1Code || i.code === oneTime2Code),
      1,
      subscriptionPlans,
      [mainItemCode]
    );
  });
});

/**
 * updates and asserts subscription for the e2e customer
 * @param body with params to create subscription
 * @returns subscription created
 */
async function updateSubscriptionAndAssert(createSubscriptionBody, itemIncrement: number) {
  const crSub = await createAndActivateSubscription(createSubscriptionBody);
  createSubscriptionBody.items.forEach((x) => {
    x.quantity = x.quantity + itemIncrement;
  });
  const subscription = await updateAndActivateSubscription(crSub.id, createSubscriptionBody);

  return subscription;
}
