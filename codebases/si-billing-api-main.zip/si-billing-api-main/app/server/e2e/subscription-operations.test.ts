// import global e2e obj
import './helper/E2EJestGlobal';
import {
  activate,
  createAndActivateSubscription,
  printTestName,
  assertOperations,
  createQuote,
  acceptQuote,
  createDraftRenewal,
  modifyPrice,
  startTrial,
  printFileName,
} from './helper/Functions';
import logger from '../src/common/logger';

describe('subscription-operations', () => {
  beforeEach(() => {
    printTestName();
  });

  beforeAll(async () => {
    printFileName();
    await e2e.testUtils.createTestCustomer();
  });

  it('regular subscription returns correct options', async () => {
    const planCode = 'DNNE Customer EVOQ BASIC Addon';
    const mainItemCode = 'DNNE-SA-Cus-BAS';
    const addonCode = 'DNNE-SA-Add-BAS';

    const createSubscriptionBody = {
      frequency: 'ANNUALLY',
      planCode: planCode,
      items: [
        { code: mainItemCode, quantity: 4 },
        { code: addonCode, quantity: 3 },
      ],
    };

    const subscription = await createAndActivateSubscription(createSubscriptionBody);
    logger.debug(`subscription: ${JSON.stringify(subscription)}`);

    await assertOperations(subscription.id, [
      'changeEdition',
      'changeSuccessPlan',
      'changeQuantity',
      'changeTerm',
      'changeBillingFrequency',
    ]);

    const renewalSubscription = await createDraftRenewal(subscription.id);
    logger.debug(`renewalSubscription: ${JSON.stringify(renewalSubscription)}`);

    await assertOperations(subscription.id, ['renew']);
    await assertOperations(renewalSubscription.id, [
      'changeEdition',
      'changeSuccessPlan',
      'changeQuantity',
      'changeTerm',
      'changeBillingFrequency',
    ]);
    const quote = await createQuote({ subscriptionId: renewalSubscription.id });
    await acceptQuote(quote.id);
    const activatedRenewalSubscription = await activate(renewalSubscription.id);
    logger.debug(`activate res: ${JSON.stringify(activatedRenewalSubscription)}`);

    await assertOperations(subscription.id, []);
    // activatedRenewalSubscription is in PENDING_ACTIVATION
    await assertOperations(activatedRenewalSubscription.id, []);
  });

  it('legacy subscription returns correct options', async () => {
    const planName = 'DNNE Legacy BAS PLA 4';
    const mainItemCode = 'DNNE-SA-Leg-STA';
    const addOnItemCode = 'DNNE-SA-Add-BAS';

    const createSubscriptionBody = {
      frequency: 'ANNUALLY',
      planCode: planName,
      items: [
        { code: mainItemCode, quantity: 10 },
        { code: addOnItemCode, quantity: 10 },
      ],
    };

    const subscription = await createAndActivateSubscription(createSubscriptionBody);
    logger.debug(`subscription: ${JSON.stringify(subscription)}`);

    await assertOperations(subscription.id, []);

    const renewalSubscription = await createDraftRenewal(subscription.id);
    logger.debug(`renewalSubscription: ${JSON.stringify(renewalSubscription)}`);

    await assertOperations(subscription.id, ['renew']);
    await assertOperations(renewalSubscription.id, ['changeSuccessPlan', 'changeTerm']);
    const quote = await createQuote({ subscriptionId: renewalSubscription.id });
    await acceptQuote(quote.id);
    const activatedRenewalSubscription = await activate(renewalSubscription.id);
    logger.debug(`activate res: ${JSON.stringify(activatedRenewalSubscription)}`);

    await assertOperations(subscription.id, []);
    // activatedRenewalSubscription is in PENDING_ACTIVATION
    await assertOperations(activatedRenewalSubscription.id, []);
  });

  it('zero price subscription returns correct options', async () => {
    const planCode = 'DNNE Customer EVOQ BASIC Addon';
    const mainItemCode = 'DNNE-SA-Cus-BAS';
    const addonCode = 'DNNE-SA-Add-BAS';

    const createSubscriptionBody = {
      frequency: 'ANNUALLY',
      planCode: planCode,
      items: [
        { code: mainItemCode, quantity: 4 },
        { code: addonCode, quantity: 3 },
      ],
    };

    const subscription = await createAndActivateSubscription(createSubscriptionBody);
    logger.debug(`subscription: ${JSON.stringify(subscription)}`);

    await modifyPrice(subscription.id, 1);

    await assertOperations(subscription.id, []);
  });

  it('trial subscription returns correct options', async () => {
    await e2e.testUtils.createTestCustomer();
    const subscription = await startTrial();
    logger.debug(`subscription: ${JSON.stringify(subscription)}`);

    await assertOperations(subscription.id, [
      'changeEdition',
      'changeSuccessPlan',
      'changeQuantity',
      'changeTerm',
      'changeBillingFrequency',
    ]);
  });

  it('request by end user who is not customer returns correct options', async () => {
    const customerId = e2e.testData.customer.id;
    await e2e.testUtils.createTestCustomer();
    const endUserId = e2e.testData.customer.id;

    const createSubscriptionBody = {
      frequency: 'ANNUALLY',
      planCode: 'DNNE Customer EVOQ BASIC Addon',
      items: [
        { code: 'DNNE-SA-Cus-BAS', quantity: 4 },
        { code: 'DNNE-SA-Add-BAS', quantity: 3 },
      ],
    };

    const subscription = await createAndActivateSubscription(createSubscriptionBody, {
      customerId: customerId,
      endUserId: endUserId,
    });
    logger.debug(`subscription: ${JSON.stringify(subscription)}`);

    await assertOperations(
      subscription.id,
      ['changeEdition', 'changeSuccessPlan', 'changeQuantity', 'changeTerm', 'changeBillingFrequency'],
      customerId
    );
    await assertOperations(subscription.id, [], endUserId);
  });
});
