// import global e2e obj
import './helper/E2EJestGlobal';
import request from 'supertest';
import tsiapp from '../src/tsiappe2e';
import { calPlanItemTotalPrice, createAndActivateSubscription, printFileName, printTestName } from './helper/Functions';
import logger from '../src/common/logger';

describe('subscription-preview', () => {
  beforeAll(async () => {
    printFileName();
    await e2e.testUtils.createTestCustomer();
  });

  beforeEach(() => {
    printTestName();
  });

  it('preview-', async () => {
    const res = await request(tsiapp.app())
      .get('/api/v1/subscriptionPlans')
      .set('Authorization', e2e.testUtils.makeCustomerJWTHeader(e2e.testData.customer.id))
      .expect(200);
    const subscriptionPlans = res.body;

    const basicPlan = subscriptionPlans.find((i) => i.code.includes(e2e.testData.trialConfig.planCode));
    const createSubscriptionBody = {
      frequency: 'MONTHLY',
      planCode: basicPlan.code,
      items: new Array<any>(),
    };
    for (const item of basicPlan.items) {
      createSubscriptionBody.items.push({ code: item.code, quantity: 1 });
    }

    let expectedItemPrice = calPlanItemTotalPrice(basicPlan.items[0], 1, 'USD', 'MONTHLY') * 12;

    let previewRes = await request(tsiapp.app())
      .post('/api/v1/subscription/preview')
      .send(createSubscriptionBody)
      .set('Authorization', e2e.testUtils.makeCustomerJWTHeader(e2e.testData.customer.id))
      .expect(200);

    expect(previewRes.body).toStrictEqual({
      frequency: 'MONTHLY',
      totalAmount: expectedItemPrice,
      totalListPrice: expectedItemPrice,
      successPlanPremium: 0,
      items: [
        {
          code: 'DNNE-SA-Cus-BAS',
          quantity: 1,
          title: 'DNNE Customer Cloud EVOQ Basic',
          amount: expectedItemPrice,
        },
      ],
    });

    // same but with ANNUALLY frequency which should use different pricebook
    createSubscriptionBody.frequency = 'ANNUALLY';
    expectedItemPrice = calPlanItemTotalPrice(basicPlan.items[0], 1, 'USD', 'ANNUALLY');
    previewRes = await request(tsiapp.app())
      .post('/api/v1/subscription/preview')
      .send(createSubscriptionBody)
      .set('Authorization', e2e.testUtils.makeCustomerJWTHeader(e2e.testData.customer.id))
      .expect(200);

    expect(previewRes.body).toStrictEqual({
      frequency: 'ANNUALLY',
      totalAmount: expectedItemPrice,
      totalListPrice: expectedItemPrice,
      successPlanPremium: 0,
      items: [
        { code: 'DNNE-SA-Cus-BAS', title: 'DNNE Customer Cloud EVOQ Basic', quantity: 1, amount: expectedItemPrice },
      ],
    });
  });

  it('preview volume start from', async () => {
    const res = await request(tsiapp.app())
      .get('/api/v1/subscriptionPlans')
      .set('Authorization', e2e.testUtils.makeCustomerJWTHeader(e2e.testData.customer.id))
      .expect(200);
    const subscriptionPlans = res.body;

    const plan = subscriptionPlans.find((i) =>
      i.items.find((j) => j.prices.find((l) => l.type === 'Volume' && l.ranges.length >= 2))
    );
    const item = plan.items.find((j) => j.prices.find((l) => l.type === 'Volume' && l.ranges.length >= 2));
    const price = item.prices.find((l) => l.type === 'Volume' && l.ranges.length >= 2);
    if (!price) {
      throw new Error('TestData changed. Not found and item with volume type and more than 1 tier.');
    }

    const previewBody = {
      frequency: price.frequency,
      planCode: plan.code,
      items: [{ code: item.code, quantity: price.ranges[1].fromQuantity }],
    };
    const expectedItemPrice =
      price.ranges[1].type === 'FixedAmount'
        ? price.ranges[1].price
        : price.ranges[1].fromQuantity * price.ranges[1].price;

    const previewRes = await request(tsiapp.app())
      .post('/api/v1/subscription/preview')
      .send(previewBody)
      .set('Authorization', e2e.testUtils.makeCustomerJWTHeader(e2e.testData.customer.id))
      .expect(200);

    expect(previewRes.body).toStrictEqual({
      frequency: price.frequency,
      totalAmount: expectedItemPrice * 12,
      totalListPrice: expectedItemPrice * 12,
      successPlanPremium: 0,
      items: [
        {
          code: item.code,
          quantity: price.ranges[1].fromQuantity,
          title: expect.anything(),
          amount: expectedItemPrice * 12,
        },
      ],
    });
  });

  it('preview tiered tiers with rate', async () => {
    const res = await request(tsiapp.app())
      .get('/api/v1/subscriptionPlans')
      .set('Authorization', 'Bearer ' + e2e.testUtils.makeJWT({ cid: e2e.testData.customer.id }))
      .expect(200);
    const subscriptionPlans = res.body;

    const plan = subscriptionPlans.find((i) =>
      i.items.find((j) =>
        j.prices.find((l) => l.type === 'Tiered' && l.ranges.length >= 2 && l.ranges[0].type === 'Rate')
      )
    );
    const item = plan.items.find((j) =>
      j.prices.find((l) => l.type === 'Tiered' && l.ranges.length >= 2 && l.ranges[0].type === 'Rate')
    );
    const price = item.prices.find((l) => l.type === 'Tiered' && l.ranges.length >= 2 && l.ranges[0].type === 'Rate');
    if (!price) {
      throw new Error('TestData changed. Not found and item with tiered type and more than 1 tier.');
    }
    const quantity = Math.round(price.ranges[1].fromQuantity / 2);
    const previewBody = {
      frequency: price.frequency,
      planCode: plan.code,
      items: [{ code: item.code, quantity: quantity }],
    };
    const expectedItemPrice = quantity * price.ranges[0].price * 12;

    const previewRes = await request(tsiapp.app())
      .post('/api/v1/subscription/preview')
      .send(previewBody)
      .set('Authorization', e2e.testUtils.makeCustomerJWTHeader(e2e.testData.customer.id))
      .expect(200);

    expect(previewRes.body).toStrictEqual({
      frequency: price.frequency,
      totalAmount: expectedItemPrice,
      totalListPrice: expectedItemPrice,
      successPlanPremium: 0,
      items: [
        {
          code: item.code,
          quantity: quantity,
          title: expect.anything(),
          amount: expectedItemPrice,
        },
      ],
    });
  });

  it('preview-support-only-plan', async () => {
    const res = await request(tsiapp.app())
      .get('/api/v1/subscriptionPlans')
      .set('Authorization', e2e.testUtils.makeCustomerJWTHeader(e2e.testData.customer.id))
      .expect(200);
    const subscriptionPlans = res.body;

    const plan = subscriptionPlans.find((i) => i.code === 'DNNE Std Silver Sup');
    const createSubscriptionBody = {
      frequency: 'ANNUALLY',
      planCode: plan.code,
      items: [
        { code: 'DNNE-SA-Cus-SIL', quantity: 1 },
        { code: 'DNNE-SA-Add-BAS', quantity: 1 },
        { code: 'DNNE-SA-OT-PT', quantity: 3 },
      ],
    };

    let expectedItemPriceSup = calPlanItemTotalPrice(
      plan.items.find((i) => i.code === 'DNNE-SA-Cus-SIL'),
      1,
      'USD',
      'ANNUALLY'
    );
    let expectedItemPriceAddon = calPlanItemTotalPrice(
      plan.items.find((i) => i.code === 'DNNE-SA-Add-BAS'),
      1,
      'USD',
      'ANNUALLY'
    );

    const expectedItemPriceOneTime = calPlanItemTotalPrice(
      plan.items.find((i) => i.code === 'DNNE-SA-OT-PT'),
      1,
      'USD',
      'ANNUALLY'
    );

    let previewRes = await request(tsiapp.app())
      .post('/api/v1/subscription/preview')
      .send(createSubscriptionBody)
      .set('Authorization', e2e.testUtils.makeCustomerJWTHeader(e2e.testData.customer.id))
      .expect(200);

    expect(previewRes.body).toStrictEqual({
      frequency: 'ANNUALLY',
      totalAmount: expectedItemPriceSup + expectedItemPriceAddon + expectedItemPriceOneTime,
      totalListPrice: expectedItemPriceSup + expectedItemPriceAddon + expectedItemPriceOneTime,
      successPlanPremium: 0,
      items: [
        { code: 'DNNE-SA-Cus-SIL', quantity: 1, title: 'DNNE Silver Support', amount: expectedItemPriceSup },
        { code: 'DNNE-SA-Add-BAS', quantity: 1, title: 'DNNE Addon', amount: expectedItemPriceAddon },
        { code: 'DNNE-SA-OT-PT', quantity: 3, title: 'PERPETUAL', amount: expectedItemPriceOneTime },
      ],
    });

    // upgrade preview
    const createRes = await createAndActivateSubscription(createSubscriptionBody);

    previewRes = await request(tsiapp.app())
      .post(`/api/v1/subscription/preview/${createRes.id}`)
      .send({ ...createSubscriptionBody, frequency: 'MONTHLY' })
      .set('Authorization', e2e.testUtils.makeCustomerJWTHeader(e2e.testData.customer.id))
      .expect(200);
    logger.debug(JSON.stringify(previewRes.body, null, 2));

    expectedItemPriceSup = calPlanItemTotalPrice(
      plan.items.find((i) => i.code === 'DNNE-SA-Cus-SIL'),
      1,
      'USD',
      'MONTHLY'
    );
    expectedItemPriceAddon = calPlanItemTotalPrice(
      plan.items.find((i) => i.code === 'DNNE-SA-Add-BAS'),
      1,
      'USD',
      'MONTHLY'
    );

    expect(previewRes.body).toStrictEqual({
      frequency: 'MONTHLY',
      totalAmount: (expectedItemPriceSup + expectedItemPriceAddon) * 12,
      totalListPrice: 13160,
      successPlanPremium: 0,
      items: [
        { code: 'DNNE-SA-Cus-SIL', quantity: 1, title: 'DNNE Silver Support', amount: expectedItemPriceSup * 12 },
        { code: 'DNNE-SA-Add-BAS', quantity: 1, title: 'DNNE Addon', amount: expectedItemPriceAddon * 12 },
        { code: 'DNNE-SA-OT-PT', quantity: 3, title: 'PERPETUAL', amount: 0 },
      ],
    });
  });

  it('preview api non zero price in support item', async () => {
    const planCode = 'DNNE Cloud EVOQ BASIC Gold Strange';
    const mainItemCode = 'DNNE-SA-Cus-BAS';

    const createSubscriptionBody = {
      frequency: 'ANNUALLY',
      planCode: planCode,
      items: [{ code: mainItemCode, quantity: 2 }],
      duration: 36,
    };

    const res = await request(tsiapp.app())
      .post('/api/v1/subscription/preview')
      .send(createSubscriptionBody)
      .set('Authorization', e2e.testUtils.makeCustomerJWTHeader(e2e.testData.customer.id))
      .expect(200);

    expect(res.body).toEqual(
      expect.objectContaining({
        frequency: 'ANNUALLY',
        totalAmount: 210,
        totalListPrice: 210,
        successPlanPremium: 138,
        items: [expect.objectContaining({ code: mainItemCode, quantity: 2, amount: 210 })],
      })
    );
  });
});
