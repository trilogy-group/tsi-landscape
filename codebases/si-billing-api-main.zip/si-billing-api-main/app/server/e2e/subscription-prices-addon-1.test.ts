// import global e2e obj
import './helper/E2EJestGlobal';
import { toBeDeepCloseTo } from 'jest-matcher-deep-close-to';
import {
  checkPrices,
  createAndActivateSubscription,
  createAndUpdate,
  getSubscriptionPlans,
  modifyPrice,
  printFileName,
  printTestName,
  round,
  updateSubscription,
} from './helper/Functions';

expect.extend({ toBeDeepCloseTo });
let subscriptionPlans;

describe('subscription-prices-addon-1', () => {
  beforeAll(async () => {
    printFileName();
    await e2e.testUtils.createTestCustomer();
    subscriptionPlans = await getSubscriptionPlans();
  });

  beforeEach(() => {
    printTestName();
  });

  it('adding addon not included previously', async () => {
    const planCode = 'DNNE Customer EVOQ BASIC Addon';
    const mainItemCode = 'DNNE-SA-Cus-BAS';
    const addonCode = 'DNNE-SA-Add-BAS';
    const discount = 0.09;

    const createSubscriptionBody = {
      frequency: 'ANNUALLY',
      planCode: planCode,
      items: [{ code: mainItemCode, quantity: 2 }],
    };
    const updateSubscriptionBody = {
      frequency: 'ANNUALLY',
      planCode: planCode,
      items: [
        { code: mainItemCode, quantity: 2 },
        { code: addonCode, quantity: 3 },
      ],
    };

    const subscription = await createAndUpdate(
      createSubscriptionBody,
      updateSubscriptionBody,
      discount,
      subscriptionPlans
    );
    checkPrices(planCode, subscription.items, discount, subscriptionPlans);
  });

  it('increasing addon quantity currently billed at 0', async () => {
    const planCode = 'DNNE Customer EVOQ BASIC Addon';
    const mainItemCode = 'DNNE-SA-Cus-BAS';
    const supportItemCode = 'DNNE-SA-Cus-SIL';
    const addonCode = 'DNNE-SA-Add-BAS';
    const discount = 0.11;

    const createSubscriptionBody = {
      frequency: 'ANNUALLY',
      planCode: planCode,
      items: [
        { code: mainItemCode, quantity: 2 },
        { code: addonCode, quantity: 3 },
      ],
    };
    const updateSubscriptionBody = {
      frequency: 'ANNUALLY',
      planCode: planCode,
      items: [
        { code: mainItemCode, quantity: 2 },
        { code: addonCode, quantity: 5 },
      ],
    };

    const subscription = await createAndActivateSubscription(createSubscriptionBody);
    await modifyPrice(subscription.id, discount, null, [mainItemCode, supportItemCode]);
    await modifyPrice(subscription.id, 1, null, [addonCode]);
    const updateResult = await updateSubscription(subscription.id, updateSubscriptionBody);
    checkPrices(
      planCode,
      updateResult.items.filter((i) => i.code === mainItemCode),
      discount,
      subscriptionPlans
    );
    checkZeroAddonPrices(
      planCode,
      updateResult.items.filter((i) => i.code === addonCode),
      discount,
      3
    );
  });

  it('increasing plan and same addon quantity currently billed at 0', async () => {
    const planCode = 'DNNE Customer EVOQ BASIC Addon';
    const mainItemCode = 'DNNE-SA-Cus-BAS';
    const supportItemCode = 'DNNE-SA-Cus-SIL';
    const addonCode = 'DNNE-SA-Add-BAS';
    const goldPlanCode = 'DNNE Cloud EVOQ BASIC Gold';
    const discount = 0.21;

    const createSubscriptionBody = {
      frequency: 'ANNUALLY',
      planCode: planCode,
      items: [
        { code: mainItemCode, quantity: 2 },
        { code: addonCode, quantity: 3 },
      ],
    };
    const updateSubscriptionBody = {
      frequency: 'ANNUALLY',
      planCode: goldPlanCode,
      items: [
        { code: mainItemCode, quantity: 2 },
        { code: addonCode, quantity: 5 },
      ],
    };

    const subscription = await createAndActivateSubscription(createSubscriptionBody);
    await modifyPrice(subscription.id, discount, null, [mainItemCode, supportItemCode]);
    await modifyPrice(subscription.id, 1, null, [addonCode]);
    const updateResult = await updateSubscription(subscription.id, updateSubscriptionBody);
    checkPrices(
      goldPlanCode,
      updateResult.items.filter((i) => i.code === mainItemCode),
      discount,
      subscriptionPlans
    );
    checkZeroAddonPrices(
      goldPlanCode,
      updateResult.items.filter((i) => i.code === addonCode),
      discount,
      3
    );
  });
});

function checkZeroAddonPrices(planCode, subscriptionItems, discount, quantity) {
  const plan = subscriptionPlans.find((i) => i.code === planCode);
  for (const item of subscriptionItems) {
    const itemPlan = plan.items.find((i) => i.code === item.code);
    const pricePlan = itemPlan.prices.find((i) => i.frequency === item.prices[0].frequency);
    let price;
    expect(item.prices[0].ranges.length).toBeGreaterThan(1);
    for (const priceTier of item.prices[0].ranges) {
      switch (priceTier.fromQuantity) {
        case 0:
          expect(priceTier.price).toBeCloseTo(0, 2);
          break;
        case quantity:
          price = round(findNearLesserOrEqualTierPrice(pricePlan.ranges, quantity) * (1 - discount));
          expect(priceTier.price).toBeCloseTo(price, 2);
          break;
        default:
          price = round(pricePlan.ranges.find((i) => i.fromQuantity === priceTier.fromQuantity).price * (1 - discount));
          expect(priceTier.price).toBeCloseTo(price, 2);
          break;
      }
    }
  }
}

function findNearLesserOrEqualTierPrice(tiers, quantity) {
  let price;
  for (const tier of tiers) {
    if (tier.fromQuantity <= quantity) {
      price = tier.price;
    } else {
      break;
    }
  }
  return price;
}
