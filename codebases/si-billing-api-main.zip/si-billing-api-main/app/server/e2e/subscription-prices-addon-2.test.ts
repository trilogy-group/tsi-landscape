// import global e2e obj
import './helper/E2EJestGlobal';
import { toBeDeepCloseTo } from 'jest-matcher-deep-close-to';
import {
  assertTotals,
  checkPrices,
  createAndActivateSubscription,
  getSubscriptionPlans,
  modifyPrice,
  previewSubscriptionAndAssert,
  printFileName,
  printTestName,
  updateSubscription,
} from './helper/Functions';

expect.extend({ toBeDeepCloseTo });
let subscriptionPlans;

describe('subscription-prices-addon-2', () => {
  beforeAll(async () => {
    printFileName();
    await e2e.testUtils.createTestCustomer();
    subscriptionPlans = await getSubscriptionPlans();
  });

  beforeEach(() => {
    printTestName();
  });

  it('upgrading subscription plan with same addon', async () => {
    const planCode = 'DNNE Customer EVOQ BASIC Addon';
    const mainItemCode = 'DNNE-SA-Cus-BAS';
    const addonCode = 'DNNE-SA-Add-BAS';
    const supportItemCode = 'DNNE-SA-Cus-SIL';
    const goldPlanCode = 'DNNE Cloud EVOQ BASIC Gold';
    const discountMainItem = 0.15;
    const discountAddon = 0.25;

    const createSubscriptionBody = {
      frequency: 'ANNUALLY',
      planCode: planCode,
      items: [
        { code: mainItemCode, quantity: 2 },
        { code: addonCode, quantity: 3 },
      ],
    };
    const updateSubscriptionBody = {
      frequency: 'ANNUALLY',
      planCode: goldPlanCode,
      items: [
        { code: mainItemCode, quantity: 2 },
        { code: addonCode, quantity: 3 },
      ],
    };

    const subscription = await createAndActivateSubscription(createSubscriptionBody);
    await modifyPrice(subscription.id, discountMainItem, null, [mainItemCode, supportItemCode]);
    await modifyPrice(subscription.id, discountAddon, null, [addonCode]);
    const preview = await previewSubscriptionAndAssert(
      updateSubscriptionBody,
      subscriptionPlans,
      { mainDiscount: discountMainItem, addons: [{ code: addonCode, discount: discountAddon }] },
      subscription.id
    );
    const updateResult = await updateSubscription(subscription.id, updateSubscriptionBody);
    assertTotals(preview, updateResult);
    checkPrices(
      goldPlanCode,
      updateResult.items.filter((i) => i.code === mainItemCode),
      discountMainItem,
      subscriptionPlans
    );
    checkPrices(
      goldPlanCode,
      updateResult.items.filter((i) => i.code === addonCode),
      discountAddon,
      subscriptionPlans
    );
  });

  it('upgrading subscription plan with different addon', async () => {
    const planCode = 'DNNE Customer EVOQ BASIC Addon';
    const mainItemCode = 'DNNE-SA-Cus-BAS';
    const addonCode = 'DNNE-SA-Add-BAS';
    const supportItemCode = 'DNNE-SA-Cus-SIL';
    const anotherPlanCode = 'DNNE-SA-TEST-MULTICONF';
    const anotherAddonCode = 'DNNE-SA-TS-OPTVOL';
    const discountMainItem = 0.19;
    const discountAddon = 0.29;

    const createSubscriptionBody = {
      frequency: 'MONTHLY',
      planCode: anotherPlanCode,
      items: [
        { code: mainItemCode, quantity: 2 },
        { code: anotherAddonCode, quantity: 3 },
      ],
    };
    const updateSubscriptionBody = {
      frequency: 'ANNUALLY',
      planCode: planCode,
      items: [
        { code: mainItemCode, quantity: 2 },
        { code: addonCode, quantity: 3 },
      ],
    };

    const subscription = await createAndActivateSubscription(createSubscriptionBody);
    await modifyPrice(subscription.id, discountMainItem, null, [mainItemCode, supportItemCode]);
    await modifyPrice(subscription.id, discountAddon, null, [anotherAddonCode]);
    const preview = await previewSubscriptionAndAssert(
      updateSubscriptionBody,
      subscriptionPlans,
      { mainDiscount: discountMainItem },
      subscription.id
    );
    const updateResult = await updateSubscription(subscription.id, updateSubscriptionBody);
    assertTotals(preview, updateResult);
    checkPrices(planCode, updateResult.items, discountMainItem, subscriptionPlans);
  });

  it('upgrading subscription plan and adding addon', async () => {
    const planCode = 'DNNE Customer EVOQ BASIC Addon';
    const mainItemCode = 'DNNE-SA-Cus-BAS';
    const addonCode = 'DNNE-SA-Add-BAS';
    const supportItemCode = 'DNNE-SA-Cus-SIL';
    const goldPlanCode = 'DNNE Cloud EVOQ BASIC Gold';
    const discountMainItem = 0.17;
    const discountAddon = 0.27;

    const createSubscriptionBody = {
      frequency: 'ANNUALLY',
      planCode: planCode,
      items: [{ code: mainItemCode, quantity: 2 }],
    };
    const updateSubscriptionBody = {
      frequency: 'ANNUALLY',
      planCode: goldPlanCode,
      items: [
        { code: mainItemCode, quantity: 2 },
        { code: addonCode, quantity: 3 },
      ],
    };

    const subscription = await createAndActivateSubscription(createSubscriptionBody);
    await modifyPrice(subscription.id, discountMainItem, null, [mainItemCode, supportItemCode]);
    await modifyPrice(subscription.id, discountAddon, null, [addonCode]);
    const preview = await previewSubscriptionAndAssert(
      updateSubscriptionBody,
      subscriptionPlans,
      { mainDiscount: discountMainItem },
      subscription.id
    );
    const updateResult = await updateSubscription(subscription.id, updateSubscriptionBody);
    assertTotals(preview, updateResult);
    checkPrices(goldPlanCode, updateResult.items, discountMainItem, subscriptionPlans);
  });
});