// import global e2e obj
import './helper/E2EJestGlobal';
import request from 'supertest';
import tsiapp from '../src/tsiappe2e';
import {
  checkPrices,
  createAndActivateSubscription,
  createAndRenewDraft,
  getDiscountWithUptick,
  getSubscription,
  getSubscriptionPlans,
  printFileName,
  printTestName,
  updateSubscription,
} from './helper/Functions';

let subscriptionPlans;

describe('subscription-prices-no-required-items', () => {
  beforeAll(async () => {
    printFileName();
    await e2e.testUtils.createTestCustomer();
    subscriptionPlans = await getSubscriptionPlans();
  });

  beforeEach(() => {
    printTestName();
  });

  it('create subscription for no req items plan', async () => {
    const planCode = 'DNNE NoReq5';
    const mainItemCode = 'DNN-SA-CUS-PRO';
    const supItemCode = 'DNN-SA-CUS-GOL';
    const plAddonCode = 'DNN-SA-DEV-ADD';

    const createSubscriptionBody = {
      frequency: 'ANNUALLY',
      planCode: planCode,
      items: [
        { code: mainItemCode, quantity: 5 },
        { code: supItemCode, quantity: 5 },
        { code: plAddonCode, quantity: 3 },
      ],
    };

    const subscription = await createAndActivateSubscription(createSubscriptionBody);
    expect(subscription).toBeTruthy();
    expect(subscription.id).toBeTruthy();

    expect(subscription).toStrictEqual(
      expect.objectContaining({
        items: expect.arrayContaining([
          expect.objectContaining({
            code: 'DNN-SA-CUS-PRO',
            required: true,
          }),
          expect.objectContaining({
            code: 'DNN-SA-DEV-ADD',
            required: false,
          }),
        ]),
      })
    );
  });

  it('put subscription for no req items plan', async () => {
    const planCode = 'DNNE NoReq5';
    const mainItemCode = 'DNN-SA-CUS-PRO';
    const plAddonCode = 'DNN-SA-DEV-ADD';

    const createSubscriptionBody = {
      frequency: 'ANNUALLY',
      planCode: planCode,
      items: [
        { code: mainItemCode, quantity: 2 },
        { code: plAddonCode, quantity: 1 },
      ],
    };

    const updateSubscriptionBody = {
      frequency: 'ANNUALLY',
      planCode: planCode,
      items: [
        { code: mainItemCode, quantity: 3 },
        { code: plAddonCode, quantity: 2 },
      ],
    };

    const subscription = await createAndActivateSubscription(createSubscriptionBody);

    expect(subscription).toBeTruthy();
    expect(subscription.id).toBeTruthy();

    const subscription2 = await getSubscription(subscription.id);
    const subscription3 = await updateSubscription(subscription2.id, updateSubscriptionBody);

    expect(subscription3).toStrictEqual(
      expect.objectContaining({
        includedItems: expect.arrayContaining([
          expect.objectContaining({
            code: 'DNN-SA-CUS-PRO',
            quantity: 3,
          }),
          expect.objectContaining({
            code: 'DNN-SA-DEV-ADD',
            quantity: 2,
          }),
        ]),
      })
    );
  });

  it('uptick renew subscription plan with no required items', async () => {
    const planCode = 'DNNE NoReq5';
    const mainItemCode = 'DNN-SA-CUS-PRO';
    const supportItemCode = 'DNN-SA-CUS-GOL';
    const addonCode = 'DNN-SA-DEV-ADD';
    const discounts = {
      mainDiscount: 0.5,
      addons: [{ code: addonCode, discount: 0.4 }],
    };
    const uptick = 0.35;

    const createSubscriptionBody = {
      frequency: 'ANNUALLY',
      planCode: planCode,
      items: [
        { code: mainItemCode, quantity: 2 },
        { code: addonCode, quantity: 2 },
      ],
    };
    const updateSubscriptionBody = {
      frequency: 'ANNUALLY',
      planCode: planCode,
      items: [
        { code: mainItemCode, quantity: 3 },
        { code: addonCode, quantity: 3 },
      ],
    };
    const { renewalSubscription } = await createAndRenewDraft(
      createSubscriptionBody,
      updateSubscriptionBody,
      discounts,
      subscriptionPlans,
      getDiscountWithUptick(discounts, uptick),
      [mainItemCode, supportItemCode],
      addonCode
    );

    checkPrices(planCode, renewalSubscription.items, getDiscountWithUptick(discounts, uptick), subscriptionPlans, [
      mainItemCode,
      supportItemCode,
    ]);
  });

  it('trial subscription has zero prices', async () => {
    await e2e.testUtils.createTestCustomer();
    const res = await request(tsiapp.app())
      .post('/api/v1/subscription/startTrial')
      .set('Authorization', e2e.testUtils.makeCustomerJWTHeader(e2e.testData.customer.id))
      .expect(200);
    expect(res.body).toBeTruthy();

    expect(res.body).toEqual(
      expect.objectContaining({
        items: expect.arrayContaining([
          expect.objectContaining({
            amount: 0,
            prices: expect.arrayContaining([
              expect.objectContaining({ ranges: expect.arrayContaining([expect.objectContaining({ price: 0 })]) }),
            ]),
          }),
        ]),
        totalAmount: 0,
      })
    );
  });
});
