// import global e2e obj
import './helper/E2EJestGlobal';
import {
  assertDistributionRatio,
  checkPrices,
  createAndRenewDraft,
  getDiscountWithUptick,
  getSubscriptionPlans,
  printFileName,
  printTestName,
} from './helper/Functions';

let subscriptionPlans;

describe('subscription-prices-renew-upgrading', () => {
  beforeAll(async () => {
    printFileName();
    await e2e.testUtils.createTestCustomer();
    subscriptionPlans = await getSubscriptionPlans();
  });

  beforeEach(() => {
    printTestName();
  });

  it('uptick renew subscription plan upgrading support level and edition-', async () => {
    const planCode_Ed_Standard_SupL_Silver = 'DNNE Customer Cloud EVOQ BASIC';
    const pl1mainItem = 'DNNE-SA-Cus-BAS';
    const planCode_Ed_Professional_SupL_Gold = 'DNNE Cloud EVOQ CONTENT GOLD';
    const pl2mainItem = 'DNNE-SA-Cus-PRO';
    const pl2supportItem = 'DNNE-SA-Cus-GOL';
    const uptick = 0.35;
    const discount = 0.5;

    const createSubscriptionBody = {
      frequency: 'ANNUALLY',
      planCode: planCode_Ed_Standard_SupL_Silver,
      items: [
        { code: pl1mainItem, quantity: 2 },
        // { code: pl1supportItem, quantity: 3 },
      ],
    };
    const updateSubscriptionBody = {
      frequency: 'ANNUALLY',
      planCode: planCode_Ed_Professional_SupL_Gold,
      items: [
        { code: pl2mainItem, quantity: 2 },
        // { code: pl2supportItem, quantity: 3 },
      ],
    };

    const { renewalSubscription } = await createAndRenewDraft(
      createSubscriptionBody,
      updateSubscriptionBody,
      discount,
      subscriptionPlans,
      getDiscountWithUptick(discount, uptick)
    );
    checkPrices(
      planCode_Ed_Standard_SupL_Silver,
      renewalSubscription.items,
      getDiscountWithUptick(discount, uptick),
      subscriptionPlans
    );
    await assertDistributionRatio(renewalSubscription.id, 0.35, pl2mainItem, pl2supportItem);
  });

  it('uptick renew subscription plan upgrading support level and edition capped by list prices', async () => {
    const planCode_Ed_Standard_SupL_Silver = 'DNNE Customer Cloud EVOQ BASIC';
    const pl1mainItem = 'DNNE-SA-Cus-BAS';
    const planCode_Ed_Professional_SupL_Gold = 'DNNE Cloud EVOQ CONTENT GOLD';
    const pl2mainItem = 'DNNE-SA-Cus-PRO';
    const pl2supportItem = 'DNNE-SA-Cus-GOL';
    const discount = 0.2;

    const createSubscriptionBody = {
      frequency: 'ANNUALLY',
      planCode: planCode_Ed_Standard_SupL_Silver,
      items: [{ code: pl1mainItem, quantity: 2 }],
    };
    const updateSubscriptionBody = {
      frequency: 'ANNUALLY',
      planCode: planCode_Ed_Professional_SupL_Gold,
      items: [{ code: pl2mainItem, quantity: 2 }],
    };

    const { renewalSubscription } = await createAndRenewDraft(
      createSubscriptionBody,
      updateSubscriptionBody,
      discount,
      subscriptionPlans,
      0
    );
    checkPrices(planCode_Ed_Standard_SupL_Silver, renewalSubscription.items, 0, subscriptionPlans);
    await assertDistributionRatio(renewalSubscription.id, 0.35, pl2mainItem, pl2supportItem);
  });
});
