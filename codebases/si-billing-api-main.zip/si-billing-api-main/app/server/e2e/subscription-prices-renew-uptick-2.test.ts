// import global e2e obj
import './helper/E2EJestGlobal';
import {
  activateDraftUsingInternalProcess,
  createDraftRenewal,
  createDraftSubscription,
  previewSubscription,
  printFileName,
  printTestName,
  setPrices,
} from './helper/Functions';

describe('subscription-prices-renew-uptick-2', () => {
  beforeAll(async () => {
    printFileName();
    await e2e.testUtils.createTestCustomer();
  });

  beforeEach(() => {
    printTestName();
  });

  it('uptick renew subscription zero prices', async () => {
    const planCode = 'DNNE Zero List Price';
    const mainItemCode = 'DNNE-SA-Cus-STA';
    const supportItemCode = 'DNNE-SA-Cus-PLA';

    const createSubscriptionBody = {
      frequency: 'ANNUALLY',
      planCode: planCode,
      items: [{ code: mainItemCode, quantity: 4 }],
    };
    const subscription = await createDraftSubscription(createSubscriptionBody);
    await setPrices(subscription.id, [
      { code: mainItemCode, price: 10000 },
      { code: supportItemCode, price: 4500 },
    ]);
    await activateDraftUsingInternalProcess(subscription.id);
    const renewalSubscription = await createDraftRenewal(subscription.id);
    expect(renewalSubscription.items[0]).toEqual(
      expect.objectContaining({
        code: mainItemCode,
        prices: expect.arrayContaining([
          expect.objectContaining({
            ranges: expect.arrayContaining([
              expect.objectContaining({
                type: 'Rate',
                fromQuantity: 0,
                price: 21025,
              }),
            ]),
          }),
        ]),
        amount: 84100,
      })
    );
    expect(renewalSubscription.totalAmount).toBe(84100);

    createSubscriptionBody.items[0].quantity = 1;
    const preview = (await previewSubscription(createSubscriptionBody, renewalSubscription.id)).body;
    expect(preview).toEqual(
      expect.objectContaining({
        totalAmount: 21025,
        totalListPrice: 0,
        successPlanPremium: 0,
        items: expect.arrayContaining([
          expect.objectContaining({
            code: mainItemCode,
            quantity: 1,
            amount: 21025,
          }),
        ]),
      })
    );
  });
});
