// import global e2e obj
import './helper/E2EJestGlobal';
import { toBeDeepCloseTo } from 'jest-matcher-deep-close-to';
import {
  AddonDiscount,
  createAndRenewDraft,
  getDiscountWithUptick,
  getSubscriptionPlans,
  printFileName,
  printTestName,
} from './helper/Functions';

expect.extend({ toBeDeepCloseTo });
let subscriptionPlans;

describe('subscription-prices-renew-uptick-addon', () => {
  beforeAll(async () => {
    printFileName();
    await e2e.testUtils.createTestCustomer();
    subscriptionPlans = await getSubscriptionPlans();
  });

  beforeEach(() => {
    printTestName();
  });

  it('uptick renew subscription plan choosing different addon-', async () => {
    const planCode1 = 'DNNE Customer EVOQ BASIC Addon';
    const mainItemCode = 'DNNE-SA-Cus-BAS';
    const supportItemCode = 'DNNE-SA-Cus-SIL';
    const pl1addonCode = 'DNNE-SA-Add-BAS';

    const planCode2 = 'DNNE Customer EVOQ BASIC DiffAddon';
    const pl2addonCode = 'DNNE-SA-Add2-BAS';
    const uptick = 0.25;
    const discounts = {
      mainDiscount: 0.5,
      addons: [
        <AddonDiscount>{ code: pl1addonCode, discount: 0.4 },
        <AddonDiscount>{ code: pl2addonCode, discount: 0.5 },
      ],
    };

    const createSubscriptionBody = {
      frequency: 'ANNUALLY',
      planCode: planCode1,
      items: [
        { code: mainItemCode, quantity: 2 },
        { code: pl1addonCode, quantity: 1 },
      ],
    };

    const updateSubscriptionBody = {
      frequency: 'ANNUALLY',
      planCode: planCode2,
      items: [
        { code: mainItemCode, quantity: 2 },
        { code: pl2addonCode, quantity: 1 },
      ],
    };

    const { renewalSubscription } = await createAndRenewDraft(
      createSubscriptionBody,
      updateSubscriptionBody,
      discounts,
      subscriptionPlans,
      getDiscountWithUptick(discounts, uptick),
      [mainItemCode, supportItemCode],
      pl1addonCode,
      {
        frequency: 'ANNUALLY',
        totalAmount: 27.5,
        totalListPrice: 64,
        successPlanPremium: 0,
        items: [
          {
            title: 'DNNE Customer Cloud EVOQ Basic',
            code: 'DNNE-SA-Cus-BAS',
            quantity: 2,
            amount: 15,
          },
          {
            title: 'DNNE Addon',
            code: 'DNNE-SA-Add2-BAS',
            quantity: 1,
            amount: 12.5,
          },
        ],
      },
      27.5
    );

    expect(renewalSubscription).toStrictEqual(
      expect.objectContaining({
        totalIntervalValue: 27.5,
        totalAmount: 27.5,
        items: expect.arrayContaining([
          expect.objectContaining({
            code: 'DNNE-SA-Cus-BAS',
            prices: expect.arrayContaining([
              expect.objectContaining({
                ranges: expect.arrayContaining([expect.objectContaining({ price: 7.5 })]),
              }),
            ]),
          }),
          expect.objectContaining({
            code: 'DNNE-SA-Add2-BAS',
            prices: expect.arrayContaining([
              expect.objectContaining({
                ranges: expect.arrayContaining([expect.objectContaining({ price: 12.5 })]),
              }),
            ]),
          }),
        ]),
      })
    );
  });

  it('uptick renew subscription plan choosing different addon capped by list prices', async () => {
    const planCode1 = 'DNNE Customer EVOQ BASIC Addon';
    const mainItemCode = 'DNNE-SA-Cus-BAS';
    const supportItemCode = 'DNNE-SA-Cus-SIL';
    const pl1addonCode = 'DNNE-SA-Add-BAS';

    const planCode2 = 'DNNE Customer EVOQ BASIC DiffAddon';
    const pl2addonCode = 'DNNE-SA-Add2-BAS';
    const discounts = {
      mainDiscount: 0.15,
      addons: [
        <AddonDiscount>{ code: pl1addonCode, discount: 0.1 },
        <AddonDiscount>{ code: pl2addonCode, discount: 0.15 },
      ],
    };

    const createSubscriptionBody = {
      frequency: 'ANNUALLY',
      planCode: planCode1,
      items: [
        { code: mainItemCode, quantity: 2 },
        { code: pl1addonCode, quantity: 1 },
      ],
    };
    const updateSubscriptionBody = {
      frequency: 'ANNUALLY',
      planCode: planCode2,
      items: [
        { code: mainItemCode, quantity: 2 },
        { code: pl2addonCode, quantity: 1 },
      ],
    };

    const { renewalSubscription } = await createAndRenewDraft(
      createSubscriptionBody,
      updateSubscriptionBody,
      discounts,
      subscriptionPlans,
      0,
      [mainItemCode, supportItemCode],
      pl1addonCode,
      {
        frequency: 'ANNUALLY',
        totalAmount: 45.5,
        totalListPrice: 64,
        successPlanPremium: 0,
        items: [
          {
            title: 'DNNE Customer Cloud EVOQ Basic',
            code: 'DNNE-SA-Cus-BAS',
            quantity: 2,
            amount: 25.5,
          },
          {
            title: 'DNNE Addon',
            code: 'DNNE-SA-Add2-BAS',
            quantity: 1,
            amount: 20,
          },
        ],
      },
      45.5
    );

    expect(renewalSubscription).toStrictEqual(
      expect.objectContaining({
        totalIntervalValue: 45.5,
        totalAmount: 45.5,
        items: expect.arrayContaining([
          expect.objectContaining({
            code: 'DNNE-SA-Cus-BAS',
            prices: expect.arrayContaining([
              expect.objectContaining({
                ranges: expect.arrayContaining([expect.objectContaining({ price: 12.75 })]),
              }),
            ]),
          }),
          expect.objectContaining({
            code: 'DNNE-SA-Add2-BAS',
            prices: expect.arrayContaining([
              expect.objectContaining({
                ranges: expect.arrayContaining([expect.objectContaining({ price: 20 })]),
              }),
            ]),
          }),
        ]),
      })
    );
  });

  it('uptick renew subscription plan with higher than list prices choosing different addon', async () => {
    const planCode1 = 'DNNE Customer EVOQ BASIC Addon';
    const mainItemCode = 'DNNE-SA-Cus-BAS';
    const supportItemCode = 'DNNE-SA-Cus-SIL';
    const pl1addonCode = 'DNNE-SA-Add-BAS';

    const planCode2 = 'DNNE Customer EVOQ BASIC DiffAddon';
    const pl2addonCode = 'DNNE-SA-Add2-BAS';
    const uptick = 0.25;
    const discounts = {
      mainDiscount: -0.5,
      addons: [
        <AddonDiscount>{ code: pl1addonCode, discount: -0.4 },
        <AddonDiscount>{ code: pl2addonCode, discount: -0.5 },
      ],
    };

    const createSubscriptionBody = {
      frequency: 'ANNUALLY',
      planCode: planCode1,
      items: [
        { code: mainItemCode, quantity: 2 },
        { code: pl1addonCode, quantity: 1 },
      ],
    };
    const updateSubscriptionBody = {
      frequency: 'ANNUALLY',
      planCode: planCode2,
      items: [
        { code: mainItemCode, quantity: 2 },
        { code: pl2addonCode, quantity: 1 },
      ],
    };

    const { renewalSubscription } = await createAndRenewDraft(
      createSubscriptionBody,
      updateSubscriptionBody,
      discounts,
      subscriptionPlans,
      getDiscountWithUptick(discounts, uptick),
      [mainItemCode, supportItemCode],
      pl1addonCode,
      {
        frequency: 'ANNUALLY',
        totalAmount: 64,
        totalListPrice: 64,
        successPlanPremium: 0,
        items: [
          {
            title: 'DNNE Customer Cloud EVOQ Basic',
            code: 'DNNE-SA-Cus-BAS',
            quantity: 2,
            amount: 44,
          },
          {
            title: 'DNNE Addon',
            code: 'DNNE-SA-Add2-BAS',
            quantity: 1,
            amount: 20,
          },
        ],
      },
      64
    );

    expect(renewalSubscription).toStrictEqual(
      expect.objectContaining({
        totalIntervalValue: 64,
        totalAmount: 64,
        items: expect.arrayContaining([
          expect.objectContaining({
            code: 'DNNE-SA-Cus-BAS',
            prices: expect.arrayContaining([
              expect.objectContaining({
                ranges: expect.arrayContaining([expect.objectContaining({ price: 22 })]),
              }),
            ]),
          }),
          expect.objectContaining({
            code: 'DNNE-SA-Add2-BAS',
            prices: expect.arrayContaining([
              expect.objectContaining({
                ranges: expect.arrayContaining([expect.objectContaining({ price: 20 })]),
              }),
            ]),
          }),
        ]),
      })
    );
  });
});
