// import global e2e obj
import './helper/E2EJestGlobal';
import { toBeDeepCloseTo } from 'jest-matcher-deep-close-to';
import { createAndRenewDraft, getDiscountWithUptick, getSubscriptionPlans, printTestName } from './helper/Functions';

expect.extend({ toBeDeepCloseTo });
let subscriptionPlans;

describe('subscription-prices-renew-uptick-legacy', () => {
  beforeAll(async () => {
    await e2e.testUtils.createTestCustomer();
    subscriptionPlans = await getSubscriptionPlans();
  });

  beforeEach(() => {
    printTestName();
  });

  it('uptick renew subscription plan without edition in the subscription plan code', async () => {
    const planCode = 'DNNE NoReq NoEd2';
    const mainItemCode = 'DNN-SA-CUS-PRO';
    const supportItemCode = 'DNN-SA-CUS-GOL';
    const discount = {
      mainDiscount: 0.5,
    };
    const uptick = 0.35;

    const createSubscriptionBody = {
      frequency: 'ANNUALLY',
      planCode: planCode,
      items: [{ code: mainItemCode, quantity: 2 }],
    };
    const updateSubscriptionBody = {
      frequency: 'ANNUALLY',
      planCode: planCode,
      items: [{ code: mainItemCode, quantity: 2 }],
    };
    await createAndRenewDraft(
      createSubscriptionBody,
      updateSubscriptionBody,
      discount,
      subscriptionPlans,
      getDiscountWithUptick(discount, uptick),
      [mainItemCode, supportItemCode],
      undefined,
      {
        items: [
          {
            amount: 27,
            code: 'DNN-SA-CUS-PRO',
            quantity: 2,
            title: 'Main item DNN-SA-CUS-PRO',
          },
        ],
        frequency: 'ANNUALLY',
        totalAmount: 27,
        totalListPrice: 40,
        successPlanPremium: 0,
      },
      27
    );
  });
});
