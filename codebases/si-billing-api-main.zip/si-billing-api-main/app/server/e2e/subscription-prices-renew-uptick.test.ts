// import global e2e obj
import './helper/E2EJestGlobal';
import {
  checkPrices,
  createAndActivateSubscription,
  createDraftRenewal,
  getDiscountWithUptick,
  getSubscriptionPlans,
  modifyPrice,
  printFileName,
  printTestName,
} from './helper/Functions';

let subscriptionPlans;

describe('subscription-prices-renew-uptick', () => {
  beforeAll(async () => {
    printFileName();
    await e2e.testUtils.createTestCustomer();
    subscriptionPlans = await getSubscriptionPlans();
  });

  beforeEach(() => {
    printTestName();
  });

  it('uptick renew subscription list prices', async () => {
    const planCode = 'DNNE Customer EVOQ BASIC Addon';
    const mainItemCode = 'DNNE-SA-Cus-BAS';
    const addonCode = 'DNNE-SA-Add-BAS';

    const createSubscriptionBody = {
      frequency: 'ANNUALLY',
      planCode: planCode,
      items: [
        { code: mainItemCode, quantity: 4 },
        { code: addonCode, quantity: 4 },
      ],
    };
    const subscription = await createAndActivateSubscription(createSubscriptionBody);
    const renewalSubscription = await createDraftRenewal(subscription.id);
    checkPrices(planCode, renewalSubscription.items, 0, subscriptionPlans);
  });

  it('uptick renew subscription silver', async () => {
    const planCode = 'DNNE Customer EVOQ BASIC Addon';
    const mainItemCode = 'DNNE-SA-Cus-BAS';
    const supportItemCode = 'DNNE-SA-Cus-SIL';
    const addonCode = 'DNNE-SA-Add-BAS';
    const discountMainItem = 0.5;
    const discountAddon = 0.4;
    const uptick = 0.25;

    const createSubscriptionBody = {
      frequency: 'ANNUALLY',
      planCode: planCode,
      items: [
        { code: mainItemCode, quantity: 5 },
        { code: addonCode, quantity: 5 },
      ],
    };
    const subscription = await createAndActivateSubscription(createSubscriptionBody);
    await modifyPrice(subscription.id, discountMainItem, null, [mainItemCode, supportItemCode]);
    await modifyPrice(subscription.id, discountAddon, null, [addonCode]);
    const renewalSubscription = await createDraftRenewal(subscription.id);
    checkPrices(
      planCode,
      renewalSubscription.items.filter((i) => i.code === mainItemCode),
      getDiscountWithUptick(discountMainItem, uptick),
      subscriptionPlans
    );
    checkPrices(
      planCode,
      renewalSubscription.items.filter((i) => i.code === addonCode),
      getDiscountWithUptick(discountAddon, uptick),
      subscriptionPlans
    );
  });

  it('uptick renew subscription gold', async () => {
    const planCode = 'DNNE Cloud EVOQ BASIC Gold';
    const mainItemCode = 'DNNE-SA-Cus-BAS';
    const supportItemCode = 'DNNE-SA-Cus-GOL';
    const addonCode = 'DNNE-SA-Add-BAS';
    const discountMainItem = 0.32;
    const discountAddon = 0.35;
    const uptick = 0.35;

    const createSubscriptionBody = {
      frequency: 'ANNUALLY',
      planCode: planCode,
      items: [
        { code: mainItemCode, quantity: 10 },
        { code: addonCode, quantity: 10 },
      ],
    };
    const subscription = await createAndActivateSubscription(createSubscriptionBody);
    await modifyPrice(subscription.id, discountMainItem, null, [mainItemCode, supportItemCode]);
    await modifyPrice(subscription.id, discountAddon, null, [addonCode]);
    const renewalSubscription = await createDraftRenewal(subscription.id);
    checkPrices(
      planCode,
      renewalSubscription.items.filter((i) => i.code === mainItemCode),
      getDiscountWithUptick(discountMainItem, uptick),
      subscriptionPlans
    );
    checkPrices(
      planCode,
      renewalSubscription.items.filter((i) => i.code === addonCode),
      getDiscountWithUptick(discountAddon, uptick),
      subscriptionPlans
    );
  });

  it('uptick renew subscription platinum', async () => {
    const planCode = 'DNNE EVOQ CONTENT PLATINUM';
    const mainItemCode = 'DNNE-SA-Cus-PRO';
    const discount = 0.39;
    const uptick = 0.45;

    const createSubscriptionBody = {
      frequency: 'ANNUALLY',
      planCode: planCode,
      items: [{ code: mainItemCode, quantity: 20 }],
    };
    const subscription = await createAndActivateSubscription(createSubscriptionBody);
    await modifyPrice(subscription.id, discount);
    const renewalSubscription = await createDraftRenewal(subscription.id);
    checkPrices(planCode, renewalSubscription.items, getDiscountWithUptick(discount, uptick), subscriptionPlans);
  });

  it('renew same plan higher prices', async () => {
    const planCode = 'DNNE Customer EVOQ BASIC Addon';
    const mainItemCode = 'DNNE-SA-Cus-BAS';
    const addonCode = 'DNNE-SA-Add-BAS';
    const discount = -0.5;

    const createSubscriptionBody = {
      frequency: 'ANNUALLY',
      planCode: planCode,
      items: [
        { code: mainItemCode, quantity: 5 },
        { code: addonCode, quantity: 5 },
      ],
    };
    const subscription = await createAndActivateSubscription(createSubscriptionBody);
    await modifyPrice(subscription.id, discount);
    const renewalSubscription = await createDraftRenewal(subscription.id);
    checkPrices(planCode, renewalSubscription.items, discount, subscriptionPlans);
  });
});
