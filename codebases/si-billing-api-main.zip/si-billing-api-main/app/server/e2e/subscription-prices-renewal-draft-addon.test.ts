// import global e2e obj
import './helper/E2EJestGlobal';
import { toBeDeepCloseTo } from 'jest-matcher-deep-close-to';
import {
  checkPrices,
  createAndActivateSubscription,
  createAndRenewDraft,
  createDraftRenewal,
  getDiscountWithUptick,
  getSubscriptionPlans,
  modifyPrice,
  printFileName,
  printTestName,
  updateSubscription,
} from './helper/Functions';

expect.extend({ toBeDeepCloseTo });
let subscriptionPlans;

describe('subscription-prices-renewal-draft-addon', () => {
  beforeAll(async () => {
    printFileName();
    await e2e.testUtils.createTestCustomer();
    subscriptionPlans = await getSubscriptionPlans();
  });

  beforeEach(() => {
    printTestName();
  });

  // this test will be covered in part 4 - ticket 22994
  // it('renew draft increasing quantity on main item and add addon', async () => {
  //   const planCode = 'DNNE Customer EVOQ BASIC Addon';
  //   const mainItemCode = 'DNNE-SA-Cus-BAS';
  //   const addonCode = 'DNNE-SA-Add-BAS';
  //   const discount = 0.3;
  //   const uptick = 0.25;

  //   // First subscription being created in the past to have billing account in the past
  //   const pastDate = new Date();
  //   pastDate.setMonth(pastDate.getMonth() - 1);
  //   const createSubscriptionBody = {
  //     frequency: 'ANNUALLY',
  //     planCode: planCode,
  //     items: [{ code: mainItemCode, quantity: 2 }],
  //     effectiveDate: pastDate.toISOString().split('T')[0],
  //   };
  //   const updateSubscriptionBody = {
  //     frequency: 'ANNUALLY',
  //     planCode: planCode,
  //     items: [
  //       { code: mainItemCode, quantity: 4 },
  //       { code: addonCode, quantity: 3 },
  //     ],
  //   };

  //   const renewalSubscription = await createAndRenewDraft(
  //     createSubscriptionBody,
  //     updateSubscriptionBody,
  //     discount,
  //     getDiscountWithUptick(discount, uptick)
  //   );
  //   checkPrices(planCode, renewalSubscription.items, getDiscountWithUptick(discount, uptick));
  // }, 150000);

  it('renew draft increasing plan having same addon', async () => {
    const planCode = 'DNNE Customer EVOQ BASIC Addon';
    const mainItemCode = 'DNNE-SA-Cus-BAS';
    const supportItemCode = 'DNNE-SA-Cus-SIL';
    const addonCode = 'DNNE-SA-Add-BAS';
    const goldPlanCode = 'DNNE Cloud EVOQ BASIC Gold';
    const discountMainItem = 0.25;
    const discountAddon = 0.35;
    const uptick = 0.35;

    const createSubscriptionBody = {
      frequency: 'ANNUALLY',
      planCode: planCode,
      items: [
        { code: mainItemCode, quantity: 5 },
        { code: addonCode, quantity: 5 },
      ],
    };
    const updateSubscriptionBody = {
      frequency: 'ANNUALLY',
      planCode: goldPlanCode,
      items: [
        { code: mainItemCode, quantity: 5 },
        { code: addonCode, quantity: 7 },
      ],
    };

    const subscription = await createAndActivateSubscription(createSubscriptionBody);
    await modifyPrice(subscription.id, discountMainItem, null, [mainItemCode, supportItemCode]);
    await modifyPrice(subscription.id, discountAddon, null, [addonCode]);
    const renewalSubscription = await createDraftRenewal(subscription.id);
    // preview needs to be changed to have new calculation for renewal
    // const preview = await previewSubscriptionAndAssert(
    //   updateSubscriptionBody,
    //   { mainDiscount: discountMainItem, addons: [{ code: addonCode, discount: discountAddon }] },
    //   renewalSubscription.id
    // );
    const subUpdated = await updateSubscription(renewalSubscription.id, updateSubscriptionBody);
    //assertTotals(preview, subUpdated);
    checkPrices(
      planCode,
      subUpdated.items.filter((i) => i.code === mainItemCode),
      getDiscountWithUptick(discountMainItem, uptick),
      subscriptionPlans
    );
    checkPrices(
      planCode,
      subUpdated.items.filter((i) => i.code === addonCode),
      getDiscountWithUptick(discountAddon, uptick),
      subscriptionPlans
    );
  });

  // this test will be covered in part 4 - ticket 22994
  // it('renew draft changing plan with different addon', async () => {
  //   const planCode = 'DNNE Customer EVOQ BASIC Addon';
  //   const mainItemCode = 'DNNE-SA-Cus-BAS';
  //   const supportItemCode = 'DNNE-SA-Cus-SIL';
  //   const addonCode = 'DNNE-SA-Add-BAS';
  //   const anotherPlanCode = 'DNNE-SA-TEST-MULTICONF';
  //   const anotherAddonCode = 'DNNE-SA-TS-OPTVOL';
  //   const discountMainItem = 0.25;
  //   const discountAddon = 0.35;

  //   const createSubscriptionBody = {
  //     frequency: 'MONTHLY',
  //     planCode: anotherPlanCode,
  //     items: [
  //       { code: mainItemCode, quantity: 3 },
  //       { code: anotherAddonCode, quantity: 3 },
  //     ],
  //   };
  //   const updateSubscriptionBody = {
  //     frequency: 'ANNUALLY',
  //     planCode: planCode,
  //     items: [
  //       { code: mainItemCode, quantity: 3 },
  //       { code: addonCode, quantity: 3 },
  //     ],
  //   };

  //   const subscription = await createSubscription(createSubscriptionBody);
  //   const renewalSubscription = await createDraftRenewal(subscription.id);
  //   await modifyPrice(renewalSubscription.id, discountMainItem, null, [mainItemCode, supportItemCode]);
  //   await modifyPrice(renewalSubscription.id, discountAddon, null, [addonCode]);
  //   const preview = await previewSubscriptionAndAssert(
  //     updateSubscriptionBody,
  //     { mainDiscount: discountMainItem },
  //     renewalSubscription.id
  //   );
  //   const subUpdated = await updateSubscription(renewalSubscription.id, updateSubscriptionBody);
  //   assertTotals(preview, subUpdated);
  //   checkPrices(planCode, subUpdated.items, discountMainItem);
  // }, 210000);

  // this test will be covered in part 4 - ticket 22994
  // it('renew draft increasing plan and add addon', async () => {
  //   const planCode = 'DNNE Customer EVOQ BASIC Addon';
  //   const mainItemCode = 'DNNE-SA-Cus-BAS';
  //   const addonCode = 'DNNE-SA-Add-BAS';
  //   const goldPlanCode = 'DNNE Cloud EVOQ BASIC Gold';
  //   const discount = 0.41;

  //   const createSubscriptionBody = {
  //     frequency: 'ANNUALLY',
  //     planCode: planCode,
  //     items: [{ code: mainItemCode, quantity: 4 }],
  //   };
  //   const updateSubscriptionBody = {
  //     frequency: 'ANNUALLY',
  //     planCode: goldPlanCode,
  //     items: [
  //       { code: mainItemCode, quantity: 4 },
  //       { code: addonCode, quantity: 3 },
  //     ],
  //   };

  //   const renewalSubscription = await createAndRenewDraft(createSubscriptionBody, updateSubscriptionBody, discount);
  //   checkPrices(goldPlanCode, renewalSubscription.items, discount);
  // }, 180000);

  // this test will be covered in part 5 - ticket 22995
  // it('renew draft changing plan frequency', async () => {
  //   const planCode = 'DNNE Customer Cloud EVOQ BASIC';
  //   const mainItem = 'DNNE-SA-Cus-BAS';
  //   const discount = 0.4;

  //   const createSubscriptionBody = {
  //     frequency: 'ANNUALLY',
  //     planCode: planCode,
  //     items: [{ code: mainItem, quantity: 2 }],
  //   };
  //   const updateSubscriptionBody = {
  //     frequency: 'MONTHLY',
  //     planCode: planCode,
  //     items: [{ code: mainItem, quantity: 2 }],
  //   };

  //   const renewalSubscription = await createAndRenewDraft(createSubscriptionBody, updateSubscriptionBody, discount);
  //   checkPrices(planCode, renewalSubscription.items, discount);
  // }, 150000);

  it('renew draft decreasing quantity on addon item', async () => {
    const planCode = 'DNNE Customer EVOQ BASIC Addon';
    const mainItemCode = 'DNNE-SA-Cus-BAS';
    const addonCode = 'DNNE-SA-Add-BAS';
    const discount = 0.33;
    const uptick = 0.25;

    const createSubscriptionBody = {
      frequency: 'ANNUALLY',
      planCode: planCode,
      items: [
        { code: mainItemCode, quantity: 4 },
        { code: addonCode, quantity: 3 },
      ],
    };
    const updateSubscriptionBody = {
      frequency: 'ANNUALLY',
      planCode: planCode,
      items: [
        { code: mainItemCode, quantity: 4 },
        { code: addonCode, quantity: 1 },
      ],
    };

    const { renewalSubscription } = await createAndRenewDraft(
      createSubscriptionBody,
      updateSubscriptionBody,
      discount,
      subscriptionPlans,
      getDiscountWithUptick(discount, uptick)
    );
    checkPrices(planCode, renewalSubscription.items, getDiscountWithUptick(discount, uptick), subscriptionPlans);
  });
});
