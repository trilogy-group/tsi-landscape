// import global e2e obj
import './helper/E2EJestGlobal';
import { toBeDeepCloseTo } from 'jest-matcher-deep-close-to';
import {
  checkPrices,
  createAndRenewDraft,
  getSubscriptionPlans,
  printFileName,
  printTestName,
} from './helper/Functions';

expect.extend({ toBeDeepCloseTo });
let subscriptionPlans;

describe('subscription-prices-renewal-draft-downgrade-1', () => {
  beforeAll(async () => {
    printFileName();
    await e2e.testUtils.createTestCustomer();
    subscriptionPlans = await getSubscriptionPlans();
  });

  beforeEach(() => {
    printTestName();
  });

  it('renew draft downgrading success plan level', async () => {
    const planCodeProfessionalSilver = 'DNNE Cloud EVOQ CONTENT';
    const mainItemProfessional = 'DNNE-SA-Cus-PRO';
    const planCodeProfessionalGold = 'DNNE Cloud EVOQ CONTENT GOLD';
    const discount = 0.2;

    const createSubscriptionBody = {
      frequency: 'ANNUALLY',
      planCode: planCodeProfessionalGold,
      items: [{ code: mainItemProfessional, quantity: 2 }],
    };
    const updateSubscriptionBody = {
      frequency: 'ANNUALLY',
      planCode: planCodeProfessionalSilver,
      items: [{ code: mainItemProfessional, quantity: 2 }],
    };

    const {renewalSubscription} = await createAndRenewDraft(
      createSubscriptionBody,
      updateSubscriptionBody,
      discount,
      subscriptionPlans,
      0
    );
    checkPrices(planCodeProfessionalSilver, renewalSubscription.items, 0, subscriptionPlans);
  });

  it('renew draft downgrading product edition', async () => {
    const planCodeStandardSilver = 'DNNE Customer Cloud EVOQ BASIC';
    const mainItemStandard = 'DNNE-SA-Cus-BAS';
    const planCodeProfessionalSilver = 'DNNE Cloud EVOQ CONTENT';
    const mainItemProfessional = 'DNNE-SA-Cus-PRO';
    const discount = 0.35;

    const createSubscriptionBody = {
      frequency: 'ANNUALLY',
      planCode: planCodeProfessionalSilver,
      items: [{ code: mainItemProfessional, quantity: 2 }],
    };
    const updateSubscriptionBody = {
      frequency: 'ANNUALLY',
      planCode: planCodeStandardSilver,
      items: [{ code: mainItemStandard, quantity: 2 }],
    };

    const {renewalSubscription} = await createAndRenewDraft(
      createSubscriptionBody,
      updateSubscriptionBody,
      discount,
      subscriptionPlans,
      0
    );
    checkPrices(planCodeStandardSilver, renewalSubscription.items, 0, subscriptionPlans);
  });
});
