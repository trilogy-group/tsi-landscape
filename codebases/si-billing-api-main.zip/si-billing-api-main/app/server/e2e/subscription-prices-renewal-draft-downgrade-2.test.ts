// import global e2e obj
import './helper/E2EJestGlobal';
import { toBeDeepCloseTo } from 'jest-matcher-deep-close-to';
import {
  checkPrices,
  createAndRenewDraft,
  getSubscriptionPlans,
  printFileName,
  printTestName,
} from './helper/Functions';

expect.extend({ toBeDeepCloseTo });
let subscriptionPlans;

describe('subscription-prices-renewal-draft-downgrade-2', () => {
  beforeAll(async () => {
    printFileName();
    await e2e.testUtils.createTestCustomer();
    subscriptionPlans = await getSubscriptionPlans();
  });

  beforeEach(() => {
    printTestName();
  });

  it('renew draft downgrading plan with addon', async () => {
    const planCode = 'DNNE Customer EVOQ BASIC Addon';
    const mainItemCode = 'DNNE-SA-Cus-BAS';
    const addonCode = 'DNNE-SA-Add-BAS';
    const goldPlanCode = 'DNNE Cloud EVOQ BASIC Gold';
    const discount = 0.21;

    const createSubscriptionBody = {
      frequency: 'ANNUALLY',
      planCode: goldPlanCode,
      items: [
        { code: mainItemCode, quantity: 5 },
        { code: addonCode, quantity: 10 },
      ],
    };
    const updateSubscriptionBody = {
      frequency: 'ANNUALLY',
      planCode: planCode,
      items: [
        { code: mainItemCode, quantity: 5 },
        { code: addonCode, quantity: 10 },
      ],
    };

    await createAndRenewDraft(
      createSubscriptionBody,
      updateSubscriptionBody,
      discount,
      subscriptionPlans,
      0,
      undefined,
      undefined,
      {
        frequency: 'ANNUALLY',
        items: [
          {
            amount: 98.75,
            code: 'DNNE-SA-Cus-BAS',
            quantity: 5,
            title: 'DNNE Customer Cloud EVOQ Basic',
          },
          {
            amount: 158,
            code: 'DNNE-SA-Add-BAS',
            quantity: 10,
            title: 'DNNE Addon',
          },
        ],
        successPlanPremium: 0,
        totalAmount: 256.75,
        totalListPrice: 210,
      }
    );
  });

  it('renew draft downgrading plan and add addon', async () => {
    const planCode = 'DNNE Customer EVOQ BASIC Addon';
    const mainItemCode = 'DNNE-SA-Cus-BAS';
    const addonCode = 'DNNE-SA-Add-BAS';
    const goldPlanCode = 'DNNE Cloud EVOQ BASIC Gold';
    const discount = 0.18;

    const createSubscriptionBody = {
      frequency: 'ANNUALLY',
      planCode: goldPlanCode,
      items: [{ code: mainItemCode, quantity: 5 }],
    };
    const updateSubscriptionBody = {
      frequency: 'ANNUALLY',
      planCode: planCode,
      items: [
        { code: mainItemCode, quantity: 5 },
        { code: addonCode, quantity: 5 },
      ],
    };

    await createAndRenewDraft(
      createSubscriptionBody,
      updateSubscriptionBody,
      discount,
      subscriptionPlans,
      0,
      undefined,
      undefined,
      {
        frequency: 'ANNUALLY',
        items: [{
            amount: 102.5,
            code: 'DNNE-SA-Cus-BAS',
            quantity: 5,
            title: 'DNNE Customer Cloud EVOQ Basic',
          },
          {
            amount: 75,
            code: 'DNNE-SA-Add-BAS',
            quantity: 5,
            title: 'DNNE Addon',
          },
        ],
        successPlanPremium: 0,
        totalAmount: 177.5,
        totalListPrice: 135,
      }
    );
  });

  it('renew draft downgrading all', async () => {
    const planCodeStandardSilver = 'DNNE Customer Cloud EVOQ BASIC';
    const mainItemStandard = 'DNNE-SA-Cus-BAS';
    const planCodeProfessionalGold = 'DNNE Cloud EVOQ CONTENT GOLD';
    const mainItemProfessional = 'DNNE-SA-Cus-PRO';
    const discount = 0.13;

    const createSubscriptionBody = {
      frequency: 'ANNUALLY',
      planCode: planCodeProfessionalGold,
      items: [{ code: mainItemProfessional, quantity: 5 }],
    };
    const updateSubscriptionBody = {
      frequency: 'ANNUALLY',
      planCode: planCodeStandardSilver,
      items: [{ code: mainItemStandard, quantity: 2 }],
    };

    const { renewalSubscription } = await createAndRenewDraft(
      createSubscriptionBody,
      updateSubscriptionBody,
      discount,
      subscriptionPlans,
      0
    );
    checkPrices(planCodeStandardSilver, renewalSubscription.items, 0, subscriptionPlans);
  });
});