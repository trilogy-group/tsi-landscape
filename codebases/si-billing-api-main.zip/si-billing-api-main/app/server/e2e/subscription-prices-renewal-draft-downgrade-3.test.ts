// import global e2e obj
import './helper/E2EJestGlobal';
import { toBeDeepCloseTo } from 'jest-matcher-deep-close-to';
import {
  checkPrices,
  createAndRenewDraft,
  getDiscountWithUptick,
  getSubscriptionPlans,
  printFileName,
  printTestName,
} from './helper/Functions';

expect.extend({ toBeDeepCloseTo });
let subscriptionPlans;

describe('subscription-prices-renewal-draft-downgrade-3', () => {
  beforeAll(async () => {
    printFileName();
    await e2e.testUtils.createTestCustomer();
    subscriptionPlans = await getSubscriptionPlans();
  });

  beforeEach(() => {
    printTestName();
  });

  it('renew draft decreasing quantity on main item', async () => {
    const planCode = 'DNNE Customer EVOQ BASIC Addon';
    const mainItemCode = 'DNNE-SA-Cus-BAS';
    const addonCode = 'DNNE-SA-Add-BAS';
    const discount = 0.3;

    const createSubscriptionBody = {
      frequency: 'ANNUALLY',
      planCode: planCode,
      items: [
        { code: mainItemCode, quantity: 4 },
        { code: addonCode, quantity: 3 },
      ],
    };
    const updateSubscriptionBody = {
      frequency: 'ANNUALLY',
      planCode: planCode,
      items: [
        { code: mainItemCode, quantity: 2 },
        { code: addonCode, quantity: 3 },
      ],
    };

    const {renewalSubscription} = await createAndRenewDraft(
      createSubscriptionBody,
      updateSubscriptionBody,
      discount,
      subscriptionPlans,
      0
    );
    checkPrices(planCode, renewalSubscription.items, 0, subscriptionPlans);
  });

  it('renew draft with higher prices downgrading', async () => {
    const planCodeStandardSilver = 'DNNE Customer Cloud EVOQ BASIC';
    const mainItemStandard = 'DNNE-SA-Cus-BAS';
    const planCodeProfessionalGold = 'DNNE Cloud EVOQ CONTENT GOLD';
    const mainItemProfessional = 'DNNE-SA-Cus-PRO';
    const discount = -0.4;
    const uptick = 0.25;

    const createSubscriptionBody = {
      frequency: 'ANNUALLY',
      planCode: planCodeProfessionalGold,
      items: [{ code: mainItemProfessional, quantity: 5 }],
    };
    const updateSubscriptionBody = {
      frequency: 'ANNUALLY',
      planCode: planCodeStandardSilver,
      items: [{ code: mainItemStandard, quantity: 2 }],
    };

    const {renewalSubscription} = await createAndRenewDraft(
      createSubscriptionBody,
      updateSubscriptionBody,
      discount,
      subscriptionPlans,
      getDiscountWithUptick(discount, uptick)
    );
    checkPrices(
      planCodeStandardSilver,
      renewalSubscription.items,
      getDiscountWithUptick(discount, uptick),
      subscriptionPlans
    );
  });
});
