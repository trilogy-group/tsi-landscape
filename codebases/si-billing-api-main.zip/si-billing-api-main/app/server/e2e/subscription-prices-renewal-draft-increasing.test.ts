// import global e2e obj
import './helper/E2EJestGlobal';
import { toBeDeepCloseTo } from 'jest-matcher-deep-close-to';
import {
  checkPrices,
  createAndRenewDraft,
  getDiscountWithUptick,
  getSubscriptionPlans,
  printFileName,
  printTestName,
} from './helper/Functions';
import logger from '../src/common/logger';

expect.extend({ toBeDeepCloseTo });
let subscriptionPlans;

describe('subscription-prices-renewal-draft-increasing', () => {
  beforeAll(async () => {
    printFileName();
    await e2e.testUtils.createTestCustomer();
    subscriptionPlans = await getSubscriptionPlans();
  });

  beforeEach(() => {
    printTestName();
  });

  it('renew draft increasing success plan', async () => {
    const planCodeProfessionalSilver = 'DNNE Cloud EVOQ CONTENT';
    const mainItemProfessional = 'DNNE-SA-Cus-PRO';
    const planCodeProfessionalGold = 'DNNE Cloud EVOQ CONTENT GOLD';
    const discount = 0.4;
    const uptick = 0.35;

    const createSubscriptionBody = {
      frequency: 'ANNUALLY',
      planCode: planCodeProfessionalSilver,
      items: [{ code: mainItemProfessional, quantity: 2 }],
    };
    const updateSubscriptionBody = {
      frequency: 'ANNUALLY',
      planCode: planCodeProfessionalGold,
      items: [{ code: mainItemProfessional, quantity: 2 }],
    };

    const { renewalSubscription } = await createAndRenewDraft(
      createSubscriptionBody,
      updateSubscriptionBody,
      discount,
      subscriptionPlans,
      getDiscountWithUptick(discount, uptick)
    );
    checkPrices(
      planCodeProfessionalGold,
      renewalSubscription.items,
      getDiscountWithUptick(discount, uptick),
      subscriptionPlans
    );
  });

  // ticket 22993 - scenario 1
  it('renew draft increasing product edition when uptick is lower than list price', async () => {
    const planCodeStandardSilver = 'DNNE Customer Cloud EVOQ BASIC';
    const mainItemStandard = 'DNNE-SA-Cus-BAS';
    const planCodeProfessionalSilver = 'DNNE Cloud EVOQ CONTENT';
    const mainItemProfessional = 'DNNE-SA-Cus-PRO';
    const discount = 0.36;
    const uptick = 0.25;

    const createSubscriptionBody = {
      frequency: 'ANNUALLY',
      planCode: planCodeStandardSilver,
      items: [{ code: mainItemStandard, quantity: 2 }],
    };
    const updateSubscriptionBody = {
      frequency: 'ANNUALLY',
      planCode: planCodeProfessionalSilver,
      items: [{ code: mainItemProfessional, quantity: 2 }],
    };

    logger.debug(`createSubscriptionBody: ${JSON.stringify(createSubscriptionBody)}`);
    logger.debug(`updateSubscriptionBody: ${JSON.stringify(updateSubscriptionBody)}`);

    const { renewalSubscription } = await createAndRenewDraft(
      createSubscriptionBody,
      updateSubscriptionBody,
      discount,
      subscriptionPlans,
      getDiscountWithUptick(discount, uptick)
    );
    checkPrices(
      planCodeProfessionalSilver,
      renewalSubscription.items,
      getDiscountWithUptick(discount, uptick),
      subscriptionPlans
    );
  }, 180000);

  // ticket 22993 - scenario 2
  it('renew draft increasing product edition when uptick is above than list price', async () => {
    const planCodeStandardSilver = 'DNNE Customer Cloud EVOQ BASIC';
    const mainItemStandard = 'DNNE-SA-Cus-BAS';
    const planCodeProfessionalSilver = 'DNNE Cloud EVOQ CONTENT';
    const mainItemProfessional = 'DNNE-SA-Cus-PRO';
    const discount = 0.1;

    const createSubscriptionBody = {
      frequency: 'ANNUALLY',
      planCode: planCodeStandardSilver,
      items: [{ code: mainItemStandard, quantity: 2 }],
    };
    const updateSubscriptionBody = {
      frequency: 'ANNUALLY',
      planCode: planCodeProfessionalSilver,
      items: [{ code: mainItemProfessional, quantity: 2 }],
    };

    logger.debug(`createSubscriptionBody: ${JSON.stringify(createSubscriptionBody)}`);
    logger.debug(`updateSubscriptionBody: ${JSON.stringify(updateSubscriptionBody)}`);

    const { renewalSubscription } = await createAndRenewDraft(
      createSubscriptionBody,
      updateSubscriptionBody,
      discount,
      subscriptionPlans,
      0
    );
    checkPrices(planCodeProfessionalSilver, renewalSubscription.items, 0, subscriptionPlans);
  }, 180000);

  // this test will be covered in part 3 - ticket 22993
  // it('renew draft increasing all', async () => {
  //   const planCodeStandardSilver = 'DNNE Customer Cloud EVOQ BASIC';
  //   const mainItemStandard = 'DNNE-SA-Cus-BAS';
  //   const planCodeProfessionalGold = 'DNNE Cloud EVOQ CONTENT GOLD';
  //   const mainItemProfessional = 'DNNE-SA-Cus-PRO';
  //   const discount = 0.13;

  //   const createSubscriptionBody = {
  //     frequency: 'MONTHLY',
  //     planCode: planCodeStandardSilver,
  //     items: [{ code: mainItemStandard, quantity: 2 }],
  //   };
  //   const updateSubscriptionBody = {
  //     frequency: 'ANNUALLY',
  //     planCode: planCodeProfessionalGold,
  //     items: [{ code: mainItemProfessional, quantity: 5 }],
  //   };

  //   const renewalSubscription = await createAndRenewDraft(createSubscriptionBody, updateSubscriptionBody, discount);
  //   checkPrices(planCodeProfessionalGold, renewalSubscription.items, discount);
  // }, 150000);
});
