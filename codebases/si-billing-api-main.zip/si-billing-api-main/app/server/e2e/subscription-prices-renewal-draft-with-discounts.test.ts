// import global e2e obj
import './helper/E2EJestGlobal';
import { toBeDeepCloseTo } from 'jest-matcher-deep-close-to';
import {
  checkPrices,
  createAndRenewDraft,
  getDiscountWithUptick,
  getSubscriptionPlans,
  printFileName,
  printTestName,
} from './helper/Functions';
import logger from '../src/common/logger';

expect.extend({ toBeDeepCloseTo });
let subscriptionPlans;

describe('subscription-prices-renewal-draft-with-discounts', () => {
  beforeAll(async () => {
    printFileName();
    await e2e.testUtils.createTestCustomer();
    subscriptionPlans = await getSubscriptionPlans();
  });

  beforeEach(() => {
    printTestName();
  });

  // ticket LAMBDA-22993, scenario 1
  it('renew draft when parent had discount and uptick is lower than list price', async () => {
    const planCodeStandardSilver = 'DNNE Customer Cloud EVOQ BASIC';
    const mainItemStandard = 'DNNE-SA-Cus-BAS';
    const discount = 0.36;
    const uptick = 0.25;

    const createSubscriptionBody = {
      frequency: 'ANNUALLY',
      planCode: planCodeStandardSilver,
      items: [{ code: mainItemStandard, quantity: 2 }],
    };

    logger.debug(`createSubscriptionBody: ${JSON.stringify(createSubscriptionBody)}`);

    const { renewalSubscription } = await createAndRenewDraft(
      createSubscriptionBody,
      createSubscriptionBody,
      discount,
      subscriptionPlans,
      getDiscountWithUptick(discount, uptick)
    );
    checkPrices(
      planCodeStandardSilver,
      renewalSubscription.items,
      getDiscountWithUptick(discount, uptick),
      subscriptionPlans
    );
  }, 180000);

  // it('renew draft when parent had discount and uptick is lower than list price for maintenace only', async () => {
  //   const planCodeStandardSilver = 'DNNE Std Silver Sup';
  //   const mainItemStandard = 'DNNE-SA-Cus-SIL';
  //   const discount = 0.36;
  //   const uptick = 0.25;

  //   const createSubscriptionBody = {
  //     frequency: 'ANNUALLY',
  //     planCode: planCodeStandardSilver,
  //     items: [{ code: mainItemStandard, quantity: 2 }],
  //   };

  //   const renewalSubscription = await createAndRenewDraft(
  //     createSubscriptionBody,
  //     createSubscriptionBody,
  //     discount,
  //     undefined,
  //     false,
  //     false
  //   );
  //   checkPrices(
  //     planCodeStandardSilver,
  //     renewalSubscription.items,
  //     getDiscountWithUptick(discount, uptick),
  //     subscriptionPlans
  //   );
  // }, 180000);

  // ticket 22993, scenario 2
  it('renew draft when parent had discount and uptick is above than list price', async () => {
    const planCodeStandardSilver = 'DNNE Customer Cloud EVOQ BASIC';
    const mainItemStandard = 'DNNE-SA-Cus-BAS';
    const discount = 0.1;

    const createSubscriptionBody = {
      frequency: 'ANNUALLY',
      planCode: planCodeStandardSilver,
      items: [{ code: mainItemStandard, quantity: 2 }],
    };

    logger.debug(`createSubscriptionBody: ${JSON.stringify(createSubscriptionBody)}`);

    const { renewalSubscription } = await createAndRenewDraft(
      createSubscriptionBody,
      createSubscriptionBody,
      discount,
      subscriptionPlans,
      0
    );
    checkPrices(planCodeStandardSilver, renewalSubscription.items, 0, subscriptionPlans);
  }, 180000);

  it('renew draft with higher prices decreasing quantity on main item', async () => {
    const planCode = 'DNNE Customer EVOQ BASIC Addon';
    const mainItemCode = 'DNNE-SA-Cus-BAS';
    const addonCode = 'DNNE-SA-Add-BAS';
    const discount = -0.3;

    const createSubscriptionBody = {
      frequency: 'ANNUALLY',
      planCode: planCode,
      items: [
        { code: mainItemCode, quantity: 4 },
        { code: addonCode, quantity: 3 },
      ],
    };
    const updateSubscriptionBody = {
      frequency: 'ANNUALLY',
      planCode: planCode,
      items: [
        { code: mainItemCode, quantity: 2 },
        { code: addonCode, quantity: 3 },
      ],
    };

    const { renewalSubscription } = await createAndRenewDraft(
      createSubscriptionBody,
      updateSubscriptionBody,
      discount,
      subscriptionPlans,
      discount
    );
    checkPrices(planCode, renewalSubscription.items, discount, subscriptionPlans);
  });
});
