// import global e2e obj
import './helper/E2EJestGlobal';
import request from 'supertest';
import tsiapp from '../src/tsiappe2e';
import {
  checkPrices,
  createAndActivateSubscription,
  createAndUpdate,
  getSubscriptionPlans,
  printFileName,
  printTestName,
} from './helper/Functions';

let subscriptionPlans;

describe('subscription-prices-update-quantity', () => {
  beforeAll(async () => {
    printFileName();
    await e2e.testUtils.createTestCustomer();
    subscriptionPlans = await getSubscriptionPlans();
  });

  beforeEach(() => {
    printTestName();
  });

  it('update downgrading quantity', async () => {
    const planCodeProfessionalGold = 'DNNE Cloud EVOQ CONTENT GOLD';
    const mainItemProfessional = 'DNNE-SA-Cus-PRO';

    const createSubscriptionBody = {
      frequency: 'ANNUALLY',
      planCode: planCodeProfessionalGold,
      items: [{ code: mainItemProfessional, quantity: 5 }],
    };
    const updateSubscriptionBody = {
      frequency: 'ANNUALLY',
      planCode: planCodeProfessionalGold,
      items: [{ code: mainItemProfessional, quantity: 3 }],
    };

    const subscription = await createAndActivateSubscription(createSubscriptionBody);
    const updateResult = await request(tsiapp.app())
      .put(`/api/v1/subscription/${subscription.id}`)
      .send(updateSubscriptionBody)
      .set('Authorization', e2e.testUtils.makeCustomerJWTHeader(e2e.testData.customer.id))
      .expect(500);
    expect(updateResult.body.errors[0].message).toBe(`It's not possible to reduce quantity in an active subscription`);
  });

  it('update upgrading plan and downgrading quantity', async () => {
    const planCodeStandardSilver = 'DNNE Customer Cloud EVOQ BASIC';
    const mainItemStandard = 'DNNE-SA-Cus-BAS';
    const planCodeProfessionalGold = 'DNNE Cloud EVOQ CONTENT GOLD';
    const mainItemProfessional = 'DNNE-SA-Cus-PRO';

    const createSubscriptionBody = {
      frequency: 'ANNUALLY',
      planCode: planCodeStandardSilver,
      items: [{ code: mainItemStandard, quantity: 5 }],
    };
    const updateSubscriptionBody = {
      frequency: 'ANNUALLY',
      planCode: planCodeProfessionalGold,
      items: [{ code: mainItemProfessional, quantity: 3 }],
    };

    const subscription = await createAndActivateSubscription(createSubscriptionBody);
    const updateResult = await request(tsiapp.app())
      .put(`/api/v1/subscription/${subscription.id}`)
      .send(updateSubscriptionBody)
      .set('Authorization', e2e.testUtils.makeCustomerJWTHeader(e2e.testData.customer.id))
      .expect(500);
    expect(updateResult.body.errors[0].message).toBe(`It's not possible to reduce quantity in an active subscription`);
  });

  it('update increasing quantity same day', async () => {
    const planCodeStandardSilver = 'DNNE Customer Cloud EVOQ BASIC';
    const mainItemStandard = 'DNNE-SA-Cus-BAS';
    const discount = 0.07;

    const createSubscriptionBody = {
      frequency: 'ANNUALLY',
      planCode: planCodeStandardSilver,
      items: [{ code: mainItemStandard, quantity: 5 }],
    };
    const updateSubscriptionBody = {
      frequency: 'ANNUALLY',
      planCode: planCodeStandardSilver,
      items: [{ code: mainItemStandard, quantity: 7 }],
    };

    const subscription = await createAndUpdate(
      createSubscriptionBody,
      updateSubscriptionBody,
      discount,
      subscriptionPlans
    );
    checkPrices(planCodeStandardSilver, subscription.items, discount, subscriptionPlans);
  });

  it('update increasing quantity different day', async () => {
    const planCodeStandardSilver = 'DNNE Customer Cloud EVOQ BASIC';
    const mainItemStandard = 'DNNE-SA-Cus-BAS';
    const discount = 0.24;

    const pastDate = new Date();
    pastDate.setDate(pastDate.getDate() - 10);
    const createSubscriptionBody = {
      frequency: 'ANNUALLY',
      planCode: planCodeStandardSilver,
      items: [{ code: mainItemStandard, quantity: 5 }],
      effectiveDate: pastDate.toISOString().split('T')[0],
    };
    const updateSubscriptionBody = {
      frequency: 'ANNUALLY',
      planCode: planCodeStandardSilver,
      items: [{ code: mainItemStandard, quantity: 7 }],
    };

    // This test needs a new customer to be created, because billing account record is created with the date of subscription
    // And when this test tries to create a subscription in the past, the error
    // "The subscription start date, 12-Feb-2022, must be on or after the billing account start date 23-Feb-2022."
    // is thrown
    await e2e.testUtils.createTestCustomer();
    const subscription = await createAndUpdate(
      createSubscriptionBody,
      updateSubscriptionBody,
      discount,
      subscriptionPlans
    );
    checkPrices(planCodeStandardSilver, subscription.items, discount, subscriptionPlans);
  });
});
