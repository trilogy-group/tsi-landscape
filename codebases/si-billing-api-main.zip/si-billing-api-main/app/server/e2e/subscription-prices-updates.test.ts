// import global e2e obj
import './helper/E2EJestGlobal';
import request from 'supertest';
import tsiapp from '../src/tsiappe2e';
import {
  checkPrices,
  createAndActivateSubscription,
  createAndUpdate,
  getSubscriptionPlans,
  printFileName,
  printTestName,
} from './helper/Functions';

let subscriptionPlans;

describe('subscription-prices-updates', () => {
  beforeAll(async () => {
    printFileName();
    await e2e.testUtils.createTestCustomer();
    subscriptionPlans = await getSubscriptionPlans();
  });

  beforeEach(() => {
    printTestName();
  });

  it('update downgrading success plan and edition', async () => {
    const planCodeStandardSilver = 'DNNE Customer Cloud EVOQ BASIC';
    const mainItemStandard = 'DNNE-SA-Cus-BAS';
    const planCodeProfessionalGold = 'DNNE Cloud EVOQ CONTENT GOLD';
    const mainItemProfessional = 'DNNE-SA-Cus-PRO';

    const createSubscriptionBody = {
      frequency: 'ANNUALLY',
      planCode: planCodeProfessionalGold,
      items: [{ code: mainItemProfessional, quantity: 5 }],
    };
    const updateSubscriptionBody = {
      frequency: 'ANNUALLY',
      planCode: planCodeStandardSilver,
      items: [{ code: mainItemStandard, quantity: 5 }],
    };

    const subscription = await createAndActivateSubscription(createSubscriptionBody);
    const updateResult = await request(tsiapp.app())
      .put(`/api/v1/subscription/${subscription.id}`)
      .send(updateSubscriptionBody)
      .set('Authorization', e2e.testUtils.makeCustomerJWTHeader(e2e.testData.customer.id))
      .expect(500);
    expect(updateResult.body.errors[0].message).toBe(`It's not possible to downgrade an active subscription`);
  });

  it('update upgrading success plan', async () => {
    const planCodeProfessionalSilver = 'DNNE Cloud EVOQ CONTENT';
    const mainItemProfessional = 'DNNE-SA-Cus-PRO';
    const planCodeProfessionalGold = 'DNNE Cloud EVOQ CONTENT GOLD';
    const discount = 0.17;

    const createSubscriptionBody = {
      frequency: 'ANNUALLY',
      planCode: planCodeProfessionalSilver,
      items: [{ code: mainItemProfessional, quantity: 7 }],
    };
    const updateSubscriptionBody = {
      frequency: 'ANNUALLY',
      planCode: planCodeProfessionalGold,
      items: [{ code: mainItemProfessional, quantity: 7 }],
    };

    const subscription = await createAndUpdate(
      createSubscriptionBody,
      updateSubscriptionBody,
      discount,
      subscriptionPlans
    );
    checkPrices(planCodeProfessionalGold, subscription.items, discount, subscriptionPlans);
  });

  it('update upgrading product edition', async () => {
    const planCodeStandardSilver = 'DNNE Customer Cloud EVOQ BASIC';
    const mainItemStandard = 'DNNE-SA-Cus-BAS';
    const planCodeProfessionalSilver = 'DNNE Cloud EVOQ CONTENT';
    const mainItemProfessional = 'DNNE-SA-Cus-PRO';
    const discount = 0.2;

    const createSubscriptionBody = {
      frequency: 'ANNUALLY',
      planCode: planCodeStandardSilver,
      items: [{ code: mainItemStandard, quantity: 3 }],
    };
    const updateSubscriptionBody = {
      frequency: 'ANNUALLY',
      planCode: planCodeProfessionalSilver,
      items: [{ code: mainItemProfessional, quantity: 3 }],
    };

    const subscription = await createAndUpdate(
      createSubscriptionBody,
      updateSubscriptionBody,
      discount,
      subscriptionPlans
    );
    checkPrices(planCodeProfessionalSilver, subscription.items, discount, subscriptionPlans);
  });
});
