// import global e2e obj
import './helper/E2EJestGlobal';
import {
  printTestName,
  createQuote,
  createSelfServeQuote,
  downloadQuote,
  acceptQuote,
  printFileName,
  createSubscription,
  createAndActivateSubscription,
  createDraftRenewal,
  convertToNSDateFormat,
} from './helper/Functions';
import logger from '../src/common/logger';

const planCode = 'DNNE Customer EVOQ BASIC Addon';
const mainItemCode = 'DNNE-SA-Cus-BAS';
const addonCode = 'DNNE-SA-Add-BAS';

const createSubscriptionBody = {
  frequency: 'ANNUALLY',
  planCode: planCode,
  items: [
    { code: mainItemCode, quantity: 4 },
    { code: addonCode, quantity: 3 },
  ],
};

describe('/subscription-quote', () => {
  beforeEach(() => {
    printTestName();
  });

  beforeAll(async () => {
    printFileName();
    await e2e.testUtils.createTestCustomer();
  });

  it('customer is not allowed to create a quote for the subscription of another customer', async () => {
    const subscription = await createSubscription(createSubscriptionBody);
    await e2e.testUtils.createTestCustomer();
    const quote = await createQuote(
      {
        subscriptionId: subscription.id,
      },
      404
    );
    logger.debug(`createQuote res: ${JSON.stringify(quote.body)}`);
  });

  it('customer is not allowed to accept or download quote of another customer', async () => {
    const subscription = await createSubscription(createSubscriptionBody);
    const quote = await createQuote({
      subscriptionId: subscription.id,
    });
    await e2e.testUtils.createTestCustomer();
    await downloadQuote(quote.id, 404);
    await acceptQuote(quote.id, 404);
    logger.debug(`createQuote res: ${JSON.stringify(quote.body)}`);
  });

  it('quote can be created with salesRep, expiry, quoteLineStartDates params', async () => {
    const planCode = 'DNNE Customer EVOQ BASIC Addon';
    const mainItemCode = 'DNNE-SA-Cus-BAS';
    const addonCode = 'DNNE-SA-Add-BAS';

    const expiryDate = new Date();
    expiryDate.setMonth(expiryDate.getMonth() + 1);

    const createSubscriptionBody = {
      frequency: 'ANNUALLY',
      planCode: planCode,
      items: [
        { code: mainItemCode, quantity: 4 },
        { code: addonCode, quantity: 3 },
      ],
    };

    const subscription = await createAndActivateSubscription(createSubscriptionBody);
    logger.debug(`subscription: ${JSON.stringify(subscription)}`);
    const renewalSubscription = await createDraftRenewal(subscription.id);
    logger.debug(`renewalSubscription: ${JSON.stringify(renewalSubscription)}`);
    const quote = await createQuote({
      subscriptionId: renewalSubscription.id,
      expiry: convertToNSDateFormat(expiryDate),
      quoteLineStartDates: [
        {
          line: 'DNNE-SA-Cus-BAS',
          startDate: subscription.term.start,
        },
        {
          line: 'DNNE-SA-Add-BAS',
          startDate: subscription.term.start,
        },
      ],
      salesRepId: 639806, //Nigel Osullivan
    });

    expect(quote).toBeDefined();
    expect(quote.id).toBeDefined();
    await assertPreview(quote.id, 'T');
  });

  it('quote cannot have two signers', async () => {
    const subscription = await createSubscription(createSubscriptionBody);
    const res = await createQuote(
      {
        subscriptionId: subscription.id,
        recipients: [
          { email: e2e.testUtils.customerTestEmail, role: 'Signer' },
          { email: 'test@test.com', role: 'Signer' },
        ],
      },
      400
    );
    expect(res).toEqual(
      expect.objectContaining({
        errors: [{ message: 'Only one signer is allowed to be informed.' }],
      })
    );
  });

  it('create quote with signers', async () => {
    const subscription = await createSubscription(createSubscriptionBody);
    const quote = await createQuote(
      {
        subscriptionId: subscription.id,
        recipients: [{ email: e2e.testUtils.customerTestEmail, role: 'Signer' }],
      },
      200
    );
    await assertQuoteSigners(subscription.id, quote.id);
  });

  it('accept quote', async () => {
    const subscription = await createSubscription(createSubscriptionBody);
    const quote = await createQuote({
      subscriptionId: subscription.id,
    });
    await acceptQuote(quote.id);
    await assertQuoteSigners(subscription.id, quote.id);
    await assertPreview(quote.id, 'F');
  });

  const defaultParamsForCreatingSelfServeQuote = {
    planCode,
    items: [
      { code: mainItemCode, quantity: 4 },
      { code: addonCode, quantity: 3 },
    ],
    frequency: 'ANNUALLY',
    duration: 12,
  };

  async function getServiceProviderSigner(subscriptionId: number, subsidiaryId?: number) {
    if (!subsidiaryId) {
      subsidiaryId = (await e2e.testUtils.execSuiteQL(`SELECT subsidiary FROM subscription WHERE id = ${subscriptionId}`))
        .items[0].subsidiary;
    }
    const res = await e2e.testUtils.execSuiteQL(`SELECT e.email, s.parent
      FROM subsidiary s
      LEFT JOIN employee e on e.id = s.custrecord_subsidiary_signatory
      WHERE s.id = ${subsidiaryId}`);
    if (res.count != 0) {
      if (res.items[0].email) {
        return res.items[0].email;
      }
      if (res.items[0].parent) {
        return getServiceProviderSigner(subscriptionId, res.items[0].parent);
      }
    }
    return undefined;
  }
  
  async function assertPreview(quoteId, expectedPreview) {
    const preview = (
      await e2e.testUtils.execSuiteQL(`SELECT a.custrecord_echosign_senddocinteractive
      FROM customrecord_echosign_agreement a
      WHERE a.custrecord_echosign_parent_record=${quoteId}`)
    ).items[0].custrecord_echosign_senddocinteractive;
    expect(preview).toBe(expectedPreview);
  }
  
  async function assertQuoteSigners(subscriptionId, quoteId) {
    const serviceProviderEmail = (await getServiceProviderSigner(subscriptionId)) + '.invalid';
    const signers = await getRecipients(quoteId);
    const expectedSigners = [
      expect.objectContaining({ email: e2e.testUtils.customerTestEmail, order: '1', role: 'Signer', toorder: '0' }),
      expect.objectContaining({ email: 'o2c@trilogy.com.invalid', role: 'CC' }),
    ];
    if (serviceProviderEmail) {
      expectedSigners.push(
        expect.objectContaining({ email: serviceProviderEmail, order: '2', role: 'Signer', toorder: '1' })
      );
    }
    expect(signers).toEqual(expect.arrayContaining(expectedSigners));
  }

  async function getRecipients(quoteId: number): Promise<{
    email: string;
    role: string;
    order: string;
    toorder: string;
  }[]> {
    const query = `
      SELECT
        s.custrecord_echosign_email AS email,
        r.name AS role,
        s.custrecord_echosign_signer_order AS order,
        s.custrecord_echosign_to_order AS toorder
      FROM customrecord_echosign_agreement a
      INNER JOIN customrecord_echosign_signer s ON s.custrecord_echosign_agree = a.id
      INNER JOIN customlist_echosign_roles r ON r.id = s.custrecord_echosign_role
      WHERE a.custrecord_echosign_parent_record = ${quoteId}
      ORDER BY s.custrecord_echosign_signer_order
    `;
    const response = await e2e.testUtils.execSuiteQL(query);
    return response.items;
  }

  it('create a self-serve quote should return 404 Not Found when the subscription is not found', async () => {
    // Arrange
    const params = {...defaultParamsForCreatingSelfServeQuote,
      subscriptionId: 0,
    };

    // Act
    const response = await createSelfServeQuote(params);

    // Assert
    expect(response.status).toEqual(404);
    expect(response.body).toBeDefined();
    expect(response.body.errors[0].message).toEqual('Subscription not found or it is from another customer');
  });

  it('create a self-serve quote should return 404 Not Found when the subscription is from another customer', async () => {
    // Arrange
    const subscription = await createAndActivateSubscription(createSubscriptionBody);
    const renewalSubscription = await createDraftRenewal(subscription.id);
    await e2e.testUtils.createTestCustomer();
    const params = {...defaultParamsForCreatingSelfServeQuote,
      subscriptionId: renewalSubscription.id,
    };

    // Act
    const response = await createSelfServeQuote(params);

    // Assert
    expect(response.status).toEqual(404);
    expect(response.body).toBeDefined();
    expect(response.body.errors[0].message).toEqual('Subscription not found or it is from another customer');
  });

  it('create a self-serve quote should return 400 Bad Request when there are two signers', async () => {
    // Arrange
    const subscription = await createAndActivateSubscription(createSubscriptionBody);
    const renewalSubscription = await createDraftRenewal(subscription.id);
    const params = {...defaultParamsForCreatingSelfServeQuote,
      subscriptionId: renewalSubscription.id,
      recipients: [
        { email: 'first-signer@trilogy.com.invalid', role: 'Signer' },
        { email: 'second-signer@trilogy.com.invalid', role: 'Signer' },
      ]
    };

    // Act
    const response = await createSelfServeQuote(params);

    // Assert
    expect(response.status).toEqual(400);
    expect(response.body).toBeDefined();
    expect(response.body.errors[0].message).toEqual('Only one signer is allowed to be informed.');
  });

  it('create a self-serve quote should create a quote with no recipients', async () => {
    // Arrange
    const subscription = await createAndActivateSubscription(createSubscriptionBody);
    const renewalSubscription = await createDraftRenewal(subscription.id);
    const params = {...defaultParamsForCreatingSelfServeQuote,
      subscriptionId: renewalSubscription.id,
    };

    // Act
    const response = await createSelfServeQuote(params);

    // Assert
    expect(response.status).toEqual(200);
    expect(response.body).toBeDefined();
    expect(response.body.id).toBeDefined();
    const quote = await getQuote(response.body.id);
    expect(quote).toBeDefined();
    expect(quote.isSelfServe).toEqual(true);
    const recipients = await getRecipients(response.body.id);
    expect(recipients).toEqual([]);
  });

  it('create a self-serve quote should create a quote with recipients', async () => {
    // Arrange
    const subscription = await createAndActivateSubscription(createSubscriptionBody);
    const renewalSubscription = await createDraftRenewal(subscription.id);
    const params = {...defaultParamsForCreatingSelfServeQuote,
      subscriptionId: renewalSubscription.id,
      recipients: [
        { email: "signer@trilogy.com.invalid", role: "Signer" },
        { email: "copy@trilogy.com.invalid", role: "CC" },
      ],
    };

    // Act
    const response = await createSelfServeQuote(params);

    // Assert
    expect(response.status).toEqual(200);
    expect(response.body).toBeDefined();
    expect(response.body.id).toBeDefined();
    const quote = await getQuote(response.body.id);
    expect(quote).toBeDefined();
    expect(quote.isSelfServe).toEqual(true);
    const recipients = await getRecipients(response.body.id);
    expect(recipients).toEqual(expect.arrayContaining([
      expect.objectContaining({ ...params.recipients[0], order: '1', toorder: '0' }),
      expect.objectContaining({ email: (await getServiceProviderSigner(renewalSubscription.id)) + '.invalid', role: 'Signer', order: '2', toorder: '1' }),
      expect.objectContaining({ ...params.recipients[1], order: '3' }),
      expect.objectContaining({ email: 'o2c@trilogy.com.invalid', role: 'CC', order: '4' }),
    ]));
  });

  async function getQuote(id: number): Promise<{
    isSelfServe: boolean;
  }> {
    const query = `
      SELECT custbody_self_serve
      FROM transaction
      WHERE id = ${id}
    `;
    const response = await e2e.testUtils.execSuiteQL(query);
    return response.items.map((item) => ({
      isSelfServe: item.custbody_self_serve === 'T',
    }))[0];
  }
});
