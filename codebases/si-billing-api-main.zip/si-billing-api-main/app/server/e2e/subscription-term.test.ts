// import global e2e obj
import './helper/E2EJestGlobal';
import request from 'supertest';
import tsiapp from '../src/tsiappe2e';
import {
  assertTerm,
  createAndActivateSubscription,
  createDraftRenewal,
  createSubscription,
  getSubscriptionPlans,
  localeDateToNetsuiteTimezone,
  printFileName,
  printTestName,
  updateSubscription,
} from './helper/Functions';

let subscriptionPlans;

describe('subscription-term', () => {
  beforeAll(async () => {
    printFileName();
    await e2e.testUtils.createTestCustomer();
    subscriptionPlans = await getSubscriptionPlans();
  });

  beforeEach(() => {
    printTestName();
  });

  it('subscription duration', async () => {
    const planCode = 'DNNE Customer Cloud EVOQ BASIC';
    const mainItemCode = 'DNNE-SA-Cus-BAS';

    const subscriptionBody: any = {
      frequency: 'MONTHLY',
      planCode: planCode,
      items: [{ code: mainItemCode, quantity: 2 }],
      duration: 48,
    };
    const subscription = await createSubscription(subscriptionBody);
    assertTerm({ unit: 'MONTHS', duration: 48 }, subscription.term);

    // assert auto renewal
    const res = await e2e.testUtils.execSuiteQL(
      `SELECT s.advancerenewalperiodnumber, s.autorenewal, t.subscriptiontermduration as defaulttermduration
      FROM subscription s
      INNER JOIN subscriptionterm t on t.id = s.defaultrenewalterm
      WHERE s.id = ${subscription.id}`
    );
    expect(res.items[0]).toEqual(
      expect.objectContaining({
        advancerenewalperiodnumber: '1457',
        autorenewal: 'T',
        defaulttermduration: '48',
      })
    );
  });

  it('subscription duration less than plan', async () => {
    const planCode = 'DNNE Customer Cloud EVOQ BASIC';
    const mainItemCode = 'DNNE-SA-Cus-BAS';

    const subscriptionBody: any = {
      frequency: 'MONTHLY',
      planCode: planCode,
      items: [{ code: mainItemCode, quantity: 2 }],
      duration: 11,
    };
    const res = await request(tsiapp.app())
      .post('/api/v1/subscription')
      .send(subscriptionBody)
      .set('Authorization', e2e.testUtils.makeCustomerJWTHeader(e2e.testData.customer.id))
      .expect(400);
    expect(res.body.errors[0]).toEqual(
      expect.objectContaining({ message: 'Duration is less than default 12 MONTHS' })
    );
  });

  it('validate term on upgrade', async () => {
    const planCode = 'DNNE Customer EVOQ BASIC Addon';
    const mainItemCode = 'DNNE-SA-Cus-BAS';

    // First subscription being created in the past to have billing account in the past
    const pastDate = localeDateToNetsuiteTimezone(new Date());
    pastDate.setMonth(pastDate.getMonth() - 6);
    const subscriptionBody: any = {
      frequency: 'ANNUALLY',
      planCode: planCode,
      items: [{ code: mainItemCode, quantity: 2 }],
      effectiveDate: pastDate.toLocaleDateString('en-us', { year: 'numeric', month: 'short', day: 'numeric' }),
    };
    const subscription = await createAndActivateSubscription(subscriptionBody);
    assertTerm(subscriptionPlans.find((i) => i.code === planCode).initialterm, subscription.term, pastDate);

    subscriptionBody.effectiveDate = undefined;
    subscriptionBody.duration = 11;
    let updateResult = await request(tsiapp.app())
      .put(`/api/v1/subscription/${subscription.id}`)
      .send(subscriptionBody)
      .set('Authorization', e2e.testUtils.makeCustomerJWTHeader(e2e.testData.customer.id))
      .expect(500);
    expect(updateResult.body.errors[0].message).toBe(`Duration can't be changed for an active subscription`);

    subscriptionBody.duration = 85;
    updateResult = await request(tsiapp.app())
      .put(`/api/v1/subscription/${subscription.id}`)
      .send(subscriptionBody)
      .set('Authorization', e2e.testUtils.makeCustomerJWTHeader(e2e.testData.customer.id))
      .expect(400);
    expect(updateResult.body.errors[0].message).toBe(`should be <= 84`);
  });

  it('increase term on renewal with same plan', async () => {
    const planCode = 'DNNE Customer EVOQ BASIC Addon';
    const mainItemCode = 'DNNE-SA-Cus-BAS';

    const pastDate = localeDateToNetsuiteTimezone(new Date());
    pastDate.setMonth(pastDate.getMonth() - 5);
    const subscriptionBody: any = {
      frequency: 'ANNUALLY',
      planCode: planCode,
      items: [{ code: mainItemCode, quantity: 2 }],
      duration: 12,
      effectiveDate: pastDate.toLocaleDateString('en-us', { year: 'numeric', month: 'short', day: 'numeric' }),
    };
    const subscription = await createAndActivateSubscription(subscriptionBody);
    const draftSubscription = await createDraftRenewal(subscription.id);

    subscriptionBody.effectiveDate = undefined;
    subscriptionBody.duration = 18;
    const update = await updateSubscription(draftSubscription.id, subscriptionBody);
    const startDateRenewal = new Date(pastDate);
    startDateRenewal.setFullYear(pastDate.getFullYear() + 1);
    assertTerm({ duration: 18, unit: 'months' }, update.term, startDateRenewal);
  });

  it('increase term on renewal with different plan', async () => {
    const planCode = 'DNNE Customer EVOQ BASIC Addon';
    const mainItemCode = 'DNNE-SA-Cus-BAS';
    const anotherPlan = 'DNNE Cloud EVOQ BASIC Gold';

    const pastDate = localeDateToNetsuiteTimezone(new Date());
    pastDate.setMonth(pastDate.getMonth() - 3);
    const subscriptionBody: any = {
      frequency: 'ANNUALLY',
      planCode: planCode,
      items: [{ code: mainItemCode, quantity: 2 }],
      duration: 12,
      effectiveDate: pastDate.toLocaleDateString('en-us', { year: 'numeric', month: 'short', day: 'numeric' }),
    };
    const subscription = await createAndActivateSubscription(subscriptionBody);
    const draftSubscription = await createDraftRenewal(subscription.id);

    subscriptionBody.effectiveDate = undefined;
    subscriptionBody.duration = 18;
    subscriptionBody.planCode = anotherPlan;
    const update = await updateSubscription(draftSubscription.id, subscriptionBody);
    const startDateRenewal = new Date(pastDate);
    startDateRenewal.setFullYear(pastDate.getFullYear() + 1);
    assertTerm({ duration: 18, unit: 'months' }, update.term, startDateRenewal);
  });
});
