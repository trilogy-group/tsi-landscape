// import global e2e obj
import './helper/E2EJestGlobal';
import request from 'supertest';
import tsiapp from '../src/tsiappe2e';
import { createAndActivateSubscription, printFileName, printTestName } from './helper/Functions';

describe('subscription-usage', () => {
  beforeEach(() => {
    printTestName();
  });

  beforeAll(async () => {
    printFileName();
    await e2e.testUtils.createTestCustomer();
  });

  it('create subscription with usage item', async () => {
    const testPlan = e2e.testData.subscriptionPlans.find((sp) => sp.name === 'DNNE-SA-TEST-MULTICONF');

    const createSubscriptionBody = {
      frequency: 'MONTHLY',
      planCode: testPlan?.name,
      items: [
        {
          code: 'DNNE-SA-Cus-BAS',
          quantity: 1,
        },
        {
          code: 'DNNE-SA-TST-USG',
          quantity: 66,
        },
      ],
    };

    //create subscription
    const subscription = await createAndActivateSubscription(createSubscriptionBody);

    expect(subscription.includedItems).toStrictEqual(
      expect.arrayContaining([
        expect.objectContaining({
          code: 'DNNE-SA-Cus-BAS',
          quantity: 1,
        }),
        expect.objectContaining({
          code: 'DNNE-SA-TST-USG',
        }),
      ])
    );
    const queryRes = await e2e.testUtils.execSuiteQL(`
      select i.itemid, sl.quantity, sl.billingmode, sl.subscriptionlinetype 
      from subscriptionline sl join item i on i.id=sl.item 
      where sl.subscription=${subscription.id} and i.itemid='DNNE-SA-TST-USG'
    `);
    expect(queryRes.items).toStrictEqual(
      expect.arrayContaining([
        expect.objectContaining({
          billingmode: 'IN_ARREARS',
          itemid: 'DNNE-SA-TST-USG',
          subscriptionlinetype: '3',
        }),
      ])
    );
  });

  it('report usage', async () => {
    const testPlan = e2e.testData.subscriptionPlans.find((sp) => sp.name === 'DNNE-SA-TEST-MULTICONF');

    const createSubscriptionBody = {
      frequency: 'MONTHLY',
      planCode: testPlan?.name,
      items: [
        {
          code: 'DNNE-SA-Cus-BAS',
          quantity: 1,
        },
        {
          code: 'DNNE-SA-TST-USG',
        },
      ],
    };

    //create subscription
    const subscription = await createAndActivateSubscription(createSubscriptionBody);

    const curDateStr = new Date(new Date().getTime() + 1000 * 60 * 60 * 24).toISOString().split('T')[0];
    const reportUsageRes = await request(tsiapp.app())
      .post('/api/v1/integration/reportUsage')
      .send([
        {
          subscriptionId: subscription.id,
          itemCode: 'invalid_item',
          quantity: 1,
          usageDate: curDateStr,
        },
        {
          subscriptionId: subscription.id,
          itemCode: 'DNNE-SA-TST-USG',
          quantity: 14,
          usageDate: curDateStr,
        },
      ])
      .set('Authorization', e2e.testUtils.makeJWTHeader(true, e2e.testData.customer.id))
      .expect(200);

    expect(reportUsageRes.body.errors).toStrictEqual([
      expect.objectContaining({ path: '0', message: 'Item not found' }),
    ]);

    const sqlRes = await e2e.testUtils.execSuiteQL(
      `select usagequantity, status from usage where usagesubscription=${subscription.id}`
    );
    expect(sqlRes.items).toStrictEqual(
      expect.arrayContaining([
        expect.objectContaining({
          usagequantity: '14',
          status: 'ACTIVE',
        }),
      ])
    );
  });
});
