// import global e2e obj
import './helper/E2EJestGlobal';
import request from 'supertest';
import tsiapp from '../src/tsiappe2e';
import {
  createAndActivateSubscription,
  createDraftRenewal,
  getSubscription,
  printFileName,
  printTestName,
  terminateSubscription,
  updateAndActivateSubscription,
  updateSubscription,
} from './helper/Functions';
import { makeNSMainClient } from '../src/api/services/NSMainClient';
import NetsuiteClient from '../src/api/services/NetsuiteClient';
import logger from '../src/common/logger';

describe('subscription', () => {
  beforeEach(() => {
    printTestName();
  });

  beforeAll(async () => {
    printFileName();
    await e2e.testUtils.createTestCustomer();
  });

  it('evergreen', async () => {
    // Test creation of an Evergreen subscription
    const res = await request(tsiapp.app())
      .get('/api/v1/subscriptionPlans')
      .set('Authorization', `Bearer ${e2e.testUtils.makeJWT({
        pfc: 'DNNE',
        pvc: 'SA-CusEG',
        cid: e2e.testData.customer.id
      })}`)
      .expect(200);
    const subscriptionPlans = res.body;
    const evergreenPlan = subscriptionPlans.find((i) => i.code === 'DNNE Customer Cloud EVOQ Evergreen');
    const createSubscriptionBody = {
      frequency: 'ANNUALLY',
      planCode: evergreenPlan.code,
      items: new Array<any>(),
    };
    for (const item of evergreenPlan.items) {
      createSubscriptionBody.items.push({ code: item.code, quantity: 1 });
    }

    const subscription = await createAndActivateSubscription(createSubscriptionBody);

    expect(subscription.term.end).toBeUndefined(); // End date should not be set for Evergreen
    expect(subscription.autorenewal).toBeFalsy(); // Renewal should be turned off for Evergreen
  });

  it('evergreen upgrade', async () => {
    const res = await request(tsiapp.app())
      .get('/api/v1/subscriptionPlans')
      .set('Authorization', `Bearer ${e2e.testUtils.makeJWT({
        pfc: 'DNNE',
        pvc: 'SA-CusEG',
        cid: e2e.testData.customer.id
      })}`)
      .expect(200);
    const subscriptionPlans = res.body;
    const evergreenPlan = subscriptionPlans.find((i) => i.code === 'DNNE Customer Cloud EVOQ Evergreen');
    logger.debug(evergreenPlan);
    const createSubscriptionBody = {
      frequency: 'ANNUALLY',
      planCode: evergreenPlan.code,
      items: new Array<any>(),
    };
    for (const item of evergreenPlan.items) {
      createSubscriptionBody.items.push({ code: item.code, quantity: 1 });
    }

    const createdSubscription = await createAndActivateSubscription(createSubscriptionBody);
    logger.debug(createdSubscription);
    const updatedSubscription = await updateAndActivateSubscription(createdSubscription.id, {
      frequency: createdSubscription.term.frequency,
      planCode: createdSubscription.plan.title,
      items: createSubscriptionBody.items.map((i) => {
        i.quantity += 1;
        return i;
      }),
    });

    expect(updatedSubscription.term.end).toBeUndefined(); // End date should not be set for Evergreen
  });

  it('multipleSubsidiaries', async () => {
    const customer = await e2e.testUtils.createCustomer('msub');
    // Test creation of an Evergreen subscription
    const res = await request(tsiapp.app())
      .get('/api/v1/subscriptionPlans')
      .set('Authorization', 'Bearer ' + e2e.testUtils.makeJWT({ cid: customer.id }))
      .expect(200);
    const subscriptionPlans = res.body;

    // create subscription with Additional subsidiary and class
    const plan = subscriptionPlans.find((i) => i.code === 'DNNE Customer Cloud EVOQ BASIC Additional');
    const createSubscriptionBody = {
      frequency: 'MONTHLY',
      planCode: plan.code,
      items: new Array<any>(),
    };
    for (const item of plan.items) {
      createSubscriptionBody.items.push({ code: item.code, quantity: 1 });
    }

    const subscriptionCreated = await createAndActivateSubscription(createSubscriptionBody, {
      customerId: customer.id,
      productFamilyCode: e2e.testData.productIntegration.pfc,
      productVariantCode: 'SA-ADDSUB',
    });

    const subscriptionSubsidiary = (
      await e2e.testUtils.execSuiteQL(`
      select sub.* from subscription s join subsidiary sub on sub.id=s.subsidiary where s.id=${subscriptionCreated.id}
    `)
    ).items[0];
    expect(subscriptionSubsidiary.name).toEqual('DNN Corp.Additional');

    // create subscription with normal subsidiary and class
    const normalPlan = subscriptionPlans.find((i) => i.code === 'DNNE Customer Cloud EVOQ BASIC');
    const createNormalSubscriptionBody = {
      frequency: 'MONTHLY',
      planCode: normalPlan.code,
      items: new Array<any>(),
    };
    for (const item of normalPlan.items) {
      createNormalSubscriptionBody.items.push({ code: item.code, quantity: 1 });
    }

    const normalSubscription = await createAndActivateSubscription(createNormalSubscriptionBody, {
      customerId: customer.id,
      productFamilyCode: e2e.testData.productIntegration.pfc,
      productVariantCode: 'SA-Cus',
    });

    const normalSbscriptionSubsidiary = (
      await e2e.testUtils.execSuiteQL(`
        select sub.* from subscription s join subsidiary sub on sub.id=s.subsidiary where s.id=${normalSubscription.id}
      `)
    ).items[0];
    expect(normalSbscriptionSubsidiary.name).toEqual('DNN Corp.');

    // check that there are 2 billing accounts created for different subsidiaries and classes
    const baSubsAndClass = (
      await e2e.testUtils.execSuiteQL(`
    select ba.frequency, sub.name as subsidiaryname, c.name as classname 
    from billingaccount ba 
    join subsidiary sub on sub.id=ba.subsidiary 
    join classification c on c.id=ba.class join customer cus on ba.customer=cus.id where cus.entityid='${customer.id}'`)
    ).items;

    expect(baSubsAndClass.length).toEqual(2);
    expect(baSubsAndClass).toEqual(
      expect.arrayContaining([
        expect.objectContaining({
          frequency: 'MONTHLY',
          subsidiaryname: e2e.testData.subsidiary.name,
          classname: e2e.testData.class.name,
        }),
        expect.objectContaining({
          frequency: 'MONTHLY',
          subsidiaryname: e2e.testData.subsidiary.name + 'Additional',
          classname: e2e.testData.class.name + 'Additional',
        }),
      ])
    );
  });

  it('get subscription returns renewalNumber and parentSubscription', async () => {
    const plansRes = await request(tsiapp.app())
      .get('/api/v1/subscriptionPlans')
      .set('Authorization', e2e.testUtils.makeCustomerJWTHeader(e2e.testData.customer.id))
      .expect(200);
    const subscriptionPlans = plansRes.body;

    const standardPlan = subscriptionPlans.find((i) => i.code.includes(e2e.testData.trialConfig.planCode));
    const createSubscriptionBody = {
      frequency: 'MONTHLY',
      planCode: standardPlan.code,
      items: new Array<any>(),
    };
    for (const item of standardPlan.items) {
      createSubscriptionBody.items.push({ code: item.code, quantity: 1 });
    }

    //create subscription
    const subscription = await createAndActivateSubscription(createSubscriptionBody);
    expect(subscription).toEqual(expect.objectContaining({ renewalNumber: 0 }));

    const nsMainClient = makeNSMainClient(e2e.version);
    const data = {
      op: 'subscription.createDraftRenewal',
      subscriptionId: subscription.id,
    };
    const createDraftRef = await NetsuiteClient.post(nsMainClient.restletUrl, data);
    expect(createDraftRef.status).toBe(200);

    const draftSubscription = createDraftRef.data.content;

    const res = await request(tsiapp.app())
      .get('/api/v1/subscription/' + draftSubscription.id)
      .send()
      .set('Authorization', e2e.testUtils.makeCustomerJWTHeader(e2e.testData.customer.id))
      .expect(200);

    expect(res.body).toEqual(expect.objectContaining({ renewalNumber: 1, parentSubscription: subscription.id }));
  });

  it('get subscriptions api for regular plans should return main and support item as required', async () => {
    const planCode = 'DNNE Cloud EVOQ BASIC Gold';
    const mainItemCode = 'DNNE-SA-Cus-BAS';
    const supportItemCode = 'DNNE-SA-Cus-GOL';
    const addonCode = 'DNNE-SA-Add-BAS';

    const createSubscriptionBody = {
      frequency: 'ANNUALLY',
      planCode: planCode,
      items: [
        { code: mainItemCode, quantity: 10 },
        { code: supportItemCode, quantity: 10 },
        { code: addonCode, quantity: 10 },
      ],
    };

    const subscription = await createAndActivateSubscription(createSubscriptionBody);
    expect(subscription.id).toBeTruthy();

    const res = await request(tsiapp.app())
      .get(`/api/v1/subscription/${subscription.id}`)
      .set('Authorization', e2e.testUtils.makeCustomerJWTHeader(e2e.testData.customer.id))
      .expect(200);
    expect(res).toBeTruthy();
    expect(res.body).toBeTruthy();
    expect(res.body).toEqual(
      expect.objectContaining({
        items: expect.arrayContaining([
          expect.objectContaining({
            code: 'DNNE-SA-Cus-BAS',
            required: true,
          }),
          expect.objectContaining({
            code: 'DNNE-SA-Add-BAS',
            required: false,
          }),
        ]),
        includedItems: expect.arrayContaining([
          expect.objectContaining({
            code: 'DNNE-SA-Cus-BAS',
          }),
          expect.objectContaining({
            code: 'DNNE-SA-Add-BAS',
          }),
        ]),
      })
    );

    logger.debug(`subscription: ${JSON.stringify(subscription)}`);
  });

  it('get subscriptions api for support only plans should return support item as required', async () => {
    const planCode = 'DNNE Pro Gold Sup';
    const supportItemCode = 'DNNE-SA-Cus-GOL';
    const addonCode = 'DNNE-SA-Add-BAS';
    const oneTime1Code = 'DNNE-SA-OT-PT';
    const oneTime2Code = 'DNNE-SA-OT-GRI';

    const createSubscriptionBody = {
      frequency: 'ANNUALLY',
      planCode: planCode,
      items: [
        { code: supportItemCode, quantity: 10 },
        { code: addonCode, quantity: 10 },
        { code: oneTime1Code, quantity: 1 },
        { code: oneTime2Code, quantity: 1 },
      ],
    };

    const subscription = await createAndActivateSubscription(createSubscriptionBody);
    expect(subscription.id).toBeTruthy();

    const res = await request(tsiapp.app())
      .get(`/api/v1/subscription/${subscription.id}`)
      .set('Authorization', e2e.testUtils.makeCustomerJWTHeader(e2e.testData.customer.id))
      .expect(200);
    expect(res).toBeTruthy();
    expect(res.body).toBeTruthy();
    expect(res.body).toEqual(
      expect.objectContaining({
        items: expect.arrayContaining([
          expect.objectContaining({
            code: 'DNNE-SA-Add-BAS',
            required: false,
          }),
          expect.objectContaining({
            code: 'DNNE-SA-OT-PT',
            required: false,
          }),
          expect.objectContaining({
            code: 'DNNE-SA-OT-GRI',
            required: false,
          }),
          expect.objectContaining({
            code: 'DNNE-SA-Cus-GOL',
            required: true,
          }),
        ]),
        includedItems: expect.arrayContaining([
          expect.objectContaining({
            code: 'DNNE-SA-Add-BAS',
          }),
          expect.objectContaining({
            code: 'DNNE-SA-OT-PT',
          }),
          expect.objectContaining({
            code: 'DNNE-SA-OT-GRI',
          }),
          expect.objectContaining({
            code: 'DNNE-SA-Cus-GOL',
          }),
        ]),
      })
    );

    logger.debug(`subscription: ${JSON.stringify(subscription)}`);
  });

  it('total amount and total interval amount should not be visible for the end user if it is not the same as the customer', async () => {
    const customerId = e2e.testData.customer.id;
    await e2e.testUtils.createTestCustomer();
    const endUserId = e2e.testData.customer.id;

    const createSubscriptionBody = {
      frequency: 'ANNUALLY',
      planCode: 'DNNE Customer EVOQ BASIC Addon',
      items: [
        { code: 'DNNE-SA-Cus-BAS', quantity: 4 },
        { code: 'DNNE-SA-Add-BAS', quantity: 3 },
      ],
    };

    const subscription = await createAndActivateSubscription(createSubscriptionBody, {
      customerId: customerId,
      endUserId: endUserId,
    });

    logger.debug(`subscription: ${JSON.stringify(subscription)}`);
    expect(subscription.id).toBeTruthy();
    expect(subscription.totalAmount).toBeDefined();
    expect(subscription.totalIntervalValue).toBeDefined();
    expect(subscription.items).toBeDefined();
    subscription.items.forEach((item) => {
      expect(item).toHaveProperty('totalIntervalValue');
    });

    const endUserViewOnSubscription = await getSubscription(subscription.id);
    expect(endUserViewOnSubscription.totalAmount).toBeUndefined();
    expect(endUserViewOnSubscription.totalIntervalValue).toBeUndefined();
    expect(endUserViewOnSubscription.items).toBeTruthy();
    endUserViewOnSubscription.items.forEach((item) => {
      expect(item.totalAmount).toBeUndefined();
      expect(item.totalIntervalValue).toBeUndefined();
    });
  });

  it('total interval amount should be returned for terminated subscriptions', async () => {
    const itemCodeToTerminate = 'DNNE-SA-Cus-BAS';
    const createSubscriptionBody = {
      frequency: 'ANNUALLY',
      planCode: 'DNNE Customer EVOQ BASIC Addon',
      items: [
        { code: 'DNNE-SA-Cus-BAS', quantity: 4 },
        { code: 'DNNE-SA-Add-BAS', quantity: 3 },
      ],
    };

    const subscription = await createAndActivateSubscription(createSubscriptionBody);
    expect(subscription.id).toBeTruthy();
    const terminatedSubscription = await terminateSubscription(subscription.id, undefined, [itemCodeToTerminate]);

    expect(terminatedSubscription).toBeTruthy();
    expect(terminatedSubscription.items).toBeTruthy();
    terminatedSubscription.items.forEach((item) => {
      expect(item).toHaveProperty('totalIntervalValue');
      if (item.code !== itemCodeToTerminate) expect(item.totalIntervalValue).toBeTruthy();
    });
    const terminatedSubscriptionAllLines = await terminateSubscription(subscription.id);
    expect(terminatedSubscriptionAllLines).toBeTruthy();
    expect(terminatedSubscriptionAllLines.items).toBeTruthy();
    terminatedSubscriptionAllLines.items.forEach((item) => {
      expect(item).toHaveProperty('totalIntervalValue');
    });
  });

  it('dont allow subscription update when draft renewal subscription is already generated for an active subscription', async () => {
    const createSubscriptionBody = {
      planCode: 'DNNE Std Silver NoSup',
      items: [
        { code: 'DNNE-SA-Cus-SIL', quantity: 1 },
        { code: 'DNNE-SA-OT-PT', quantity: 1 },
        { code: 'DNNE-SA-OT-GRI', quantity: 1 },
      ],
      frequency: 'MONTHLY',
      duration: 36,
    };

    // Scenario active subscription without draft renewals is updated
    // Given there is an active subscription
    const createdSubscription = await createAndActivateSubscription(createSubscriptionBody);
    logger.debug(`createdSubscription: ${JSON.stringify(createdSubscription)}`);
    expect(createdSubscription.id).toBeTruthy();

    // When active subscription without draft renewals is updated
    const updatedSubscription = await updateSubscription(createdSubscription.id, {
      frequency: createdSubscription.term.frequency,
      planCode: createdSubscription.plan.title,
      items: createSubscriptionBody.items.map((i) => {
        i.quantity += 1;
        return i;
      }),
    });

    // Than it is updated successfully
    expect(updatedSubscription.id).toBeTruthy();

    // Scenario active subscription with draft renewals is updated
    // Given there is an active subscription
    // And draft renewal is created for an active subscription
    const renewalSubscription = await createDraftRenewal(createdSubscription.id);
    logger.debug(`renewalSubscription: ${JSON.stringify(renewalSubscription)}`);

    // When active subscription without draft renewals is updated
    const updatedSubscription2 = await updateSubscription(
      createdSubscription.id,
      {
        frequency: createdSubscription.term.frequency,
        planCode: createdSubscription.plan.title,
        items: createSubscriptionBody.items.map((i) => {
          i.quantity += 2;
          return i;
        }),
      },
      500
    );

    // Than the error is thrown
    expect(updatedSubscription2.errors).toBeTruthy();
    expect(updatedSubscription2.errors[0].message).toBe(
      `Subscription can not be modified because renewal is already generated. Please contact support for further assistance.`
    );
  });

  it('get subscription returns the billing and shipping addresses of the customer', async () => {

    // Create the customer with a shipping address.
    const address = {
      line1: '291 Harbor Dr',
      line2: 'Attention: billing',
      city: 'Claymont',
      state: 'DE',
      country: 'US',
      zip: '19703',
      phone: '1234567',
    };
    const shippingAddress = {
      line1: '292 Harbor Dr',
      line2: 'Attention: shipping',
      city: 'Claymont',
      state: 'DE',
      country: 'US',
      zip: '19703',
      phone: '1234589',
    };
    const customer = await e2e.testUtils.createCustomer('wsadd', (customer) => {
      customer.address = address;
      customer.shippingAddress = shippingAddress;
    });

    // Retrieve the plans for this customer.
    const plansRes = await request(tsiapp.app())
      .get('/api/v1/subscriptionPlans')
      .set('Authorization', 'Bearer ' + e2e.testUtils.makeJWT({ cid: customer.id }))
      .expect(200);
    const subscriptionPlans = plansRes.body;

    // Create the subscription payload.
    const standardPlan = subscriptionPlans.find((i) => i.code.includes(e2e.testData.trialConfig.planCode));
    const createSubscriptionBody = {
      frequency: 'MONTHLY',
      planCode: standardPlan.code,
      items: new Array<any>(),
    };
    for (const item of standardPlan.items) {
      createSubscriptionBody.items.push({ code: item.code, quantity: 1 });
    }

    // Create the subscription for this customer.
    const subscription = await createAndActivateSubscription(createSubscriptionBody,{
      customerId: customer.id,
      productFamilyCode: e2e.testData.productIntegration.pfc,
      productVariantCode: e2e.testData.productIntegration.pvc,
    });

    // Assert that the subscription contains the customer's billing and shipping addresses.
    expect(subscription).toEqual(expect.objectContaining({
      customer: expect.objectContaining({ address, shippingAddress }),
    }));
  });
});
