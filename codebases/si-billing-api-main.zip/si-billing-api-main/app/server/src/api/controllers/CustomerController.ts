import { Response } from 'express';
import { Router } from 'express';
import { NSMainClient } from '../services/NSMainClient';
import { ProxyRequest } from '../../common/types';
import { pdfRequest } from '../../common/util';

export class CustomerController {
  routes(): Router {
    const path = '/';
    return Router() //
      .post(path, NSMainClient.makeInternalProxyWithBody('customer.create'))
      .put(path, NSMainClient.makeProxyWithBody('customer.update'))
      .patch(path, NSMainClient.makeProxyWithBody('customer.update', (_req) => ({
        isPartialContent: true,
      })))
      .get(path, NSMainClient.makeProxy('customer.get'));
  }

  search = NSMainClient.makeInternalProxyWithBody('customer.search');
  statement(req: ProxyRequest, res: Response): void {
    pdfRequest(req, res, 'customer.statement', ['startDate']);
  }
  latestSignedQuote(req: ProxyRequest, res: Response): void {
    pdfRequest(req, res, 'customer.getLatestSignedQuote', ['endUserId']);
  }
}
export default new CustomerController();
