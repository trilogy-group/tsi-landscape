import { Request, Response, Router } from 'express';
import { NSMainClient } from '../services/NSMainClient';
import logger from '../../common/logger';
import NetsuiteClient from '../services/NetsuiteClient';
import config from '../../common/config';

export class IntegrationController {
  async netSuiteRelay(req: Request, res: Response, next?: any): Promise<void> {
    if (
      req.headers.authorization !==
      'Bearer UEMcKYsJnX8YNyJWPHWMAA8dq9tKufBuFzqwsGaXm9HaPjMhcdEzSVEDTwR3r7WmQb24yRCUNjZwh7Trr3X8QG8jdK7N9w7nhJT29EaePEuKnuNNsQ8GDhgBWCMcjJbp'
    ) {
      res.status(401).json({ message: 'Unauthorized access' });
      return;
    }

    try {
      logger.debug(`Request: ${JSON.stringify(req.body)}`);
      const instance = config.nsClientRealm.toLowerCase().replace('_', '-');
      const renewUrl = `https://${instance}.suitetalk.api.netsuite.com/services/rest/record/v1/subscriptionChangeOrder`;
      const quoteUrl = `https://${instance}.restlets.api.netsuite.com/app/site/hosting/restlet.nl?script=customscript_si_main_main_restlet&deploy=customdeploy_si_main_main`;
      const requestBody = req.body.payload;
      if (req.body.targetNSRequest === 'generate_quote') {
        const url = quoteUrl;
        const nsResponse = await NetsuiteClient.post(url, requestBody);
        console.log('nsResponse.data', JSON.stringify({ data: nsResponse.data }));
        res.status(200).json(nsResponse.data);
      } else {
        const url = renewUrl;
        const nsResponse = await NetsuiteClient.post(url, requestBody);
        console.log('nsResponse.headers', JSON.stringify({ data: nsResponse.headers }));
        res.status(200).json({ location: nsResponse.headers.location });
      }
      return;
    } catch (e) {
      logger.error(e);
      next(e);
    }
  }

  routes(): Router {
    return Router() //
      .post('/reportUsage', NSMainClient.makeInternalProxyWithBody('subscription.reportUsage'))
      .put('/product', NSMainClient.makeInternalProxyWithBody('prodInt.update'))
      .get('/product', NSMainClient.makePrivilegedProxy('prodInt.get'));
  }
}
export default new IntegrationController();
