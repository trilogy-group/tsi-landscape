import { Response } from 'express';
import { HTTP_INTERNAL_SERVER_ERROR } from '../../common/errors';
import logger from '../../common/logger';
import { Dictionary, ProxyRequest } from '../../common/types';
import { keyParamsFromQuery } from '../../common/util';
import { makeNSMainClient, NSMainClient } from '../services/NSMainClient';

export class InvoiceController {
  searchInvoices = NSMainClient.makeProxy('invoice.find', ['subscriptionId', 'startDate', 'endDate', 'status']);
  downloadInvoice(req: ProxyRequest, res: Response): void {
    makeNSMainClient(req.user?.version)
      .op(
        'invoice.download',
        {
          ...keyParamsFromQuery(req.user!, req.query as Dictionary<string>).requireCustomerId(),
        } as any,
        { invoiceNumber: req.params.invoiceNumber }
      ) //NOSONAR
      .then((r) => {
        res.contentType('application/pdf');
        logger.debug(`Response: ${JSON.stringify(r.data)}`);
        return res.header('isBase64Encoded', '').send(r.data.content);
      })
      .catch(e => NSMainClient.defaultErrorHandler(e, res));
  }
  paymentLink = NSMainClient.makeProxy('invoice.paymentLink', [], (r) => ({
    invoiceNumber: r.params.invoiceNumber,
  }));

  createInvoice = NSMainClient.makeProxyWithBody('invoice.create');
}
export default new InvoiceController();
