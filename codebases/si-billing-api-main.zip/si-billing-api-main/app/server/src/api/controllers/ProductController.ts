import { Router } from 'express';
import { NSMainClient } from '../services/NSMainClient';

export class ProductController {
  routes(): Router {
    const path = '/';
    return Router() //
      .get(path, NSMainClient.makeProxy('prodCatalog.listProducts'));
  }
}
export default new ProductController();
