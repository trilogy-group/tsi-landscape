import { Response } from 'express';
import { Dictionary, ProxyRequest } from '../../common/types';
import { keyParamsFromQuery } from '../../common/util';
import { makeNSMainClient, NSMainClient } from '../services/NSMainClient';

export class QuoteController {
  downloadQuote(req: ProxyRequest, res: Response): void {
    makeNSMainClient(req.user?.version)
      .op('quote.download', {
        ...keyParamsFromQuery(req.user!, req.query as Dictionary<string>).requireCustomerId(),
        quoteId: parseInt(req.params.quoteId),
      } as any) //NOSONAR
      .then(async (r) => {
        res.contentType('application/pdf');
        return res.header('isBase64Encoded', '').send(r.data.content);
      })
      .catch(e => NSMainClient.defaultErrorHandler(e, res));
  }

  /**
   * @deprecated
   */
  createQuote = NSMainClient.makeProxy('quote.create', (r) => ({
    subscriptionId: r.body.subscriptionId,
    orderType: r.body.orderType,
    recipients: r.body.recipients,
    quoteLineEndDates: r.body.quoteLineEndDates,
    quoteLineStartDates: r.body.quoteLineStartDates,
    expiry: r.body.expiry,
    salesRepId: r.body.salesRepId,
  }));

  createQuoteForSelfServe = NSMainClient.makeProxyWithBody('quote.createForSelfServe');
  
  /**
   * @deprecated
   */
  acceptQuote = NSMainClient.makeProxy(
    'quote.accept',
    (r) => ({
      quoteId: parseInt(r.params.quoteId),
    }),
    (r) => ({
      ...r.body,
      time: new Date(),
      clientInfo: {
        ipAddress: r.headers['x-forwarded-for'],
        userAgent: r.headers['user-agent'],
      },
    })
  );
}

export default new QuoteController();
