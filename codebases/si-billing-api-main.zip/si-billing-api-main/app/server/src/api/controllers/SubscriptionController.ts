import { Request, Response, Router } from 'express';
import config from '../../common/config';
import logger from '../../common/logger';
import { Dictionary, JwtPayload } from '../../common/types';
import { keyParamsFromQuery, promiseAllInBatches } from '../../common/util';
import NetsuiteClient from '../services/NetsuiteClient';
import { NSMainClient, makeNSMainClient } from '../services/NSMainClient';

const ALLOWED_STATUSES = ['ACTIVE', 'PENDING_ACTIVATION', 'SUSPENDED', 'DRAFT', 'CLOSED', 'TERMINATED', 'NOT_INCLUDE'];

function extractStatuses(statuses: string[]): string[] {
  if (!statuses) {
    return ['ACTIVE', 'PENDING_ACTIVATION', 'SUSPENDED', 'TERMINATED', 'CLOSED'];
  }
  return statuses
    .flatMap(status => status.split('|'))
    .map(status => {
      if (!ALLOWED_STATUSES.includes(status)) {
        throw new Error(`Illegal status '${status}'`);
      }
      return status;
    });
}
export class SubscriptionController {
  async forCustomer(req: Request, res: Response, next?): Promise<void> {
    const keyParams = keyParamsFromQuery(req.user as JwtPayload, req.query as Dictionary<string>).requireCustomerId();

    try {
      let sql = `select s.id from subscription s 
      join customer ceu on ceu.id=s.custrecord_subs_end_user 
      join customer c on c.id=s.customer
      join subscriptionplan sp on sp.itemid=s.subscriptionplanname
      LEFT JOIN subscriptionPlan rp on rp.id = sp.defaultrenewalplan
      join customrecordproductintegration pi on pi.custrecordclass = COALESCE(rp.class, sp.class)
      where pi.custrecordproductfamilycode = '${keyParams.productFamilyCode}' 
      and (ceu.entityid='${keyParams.customerId}' OR c.entityid='${keyParams.customerId}')
      and upper(pi.custrecordproductvariantcode) = upper(REGEXP_REPLACE(
        COALESCE(rp.displayname, sp.displayname),
        '[^-]+-([^-]+-[^-]+)-.*',
        '\\1'
        ))`;

      if (keyParams.productVariantCode) {
        sql += ` and pi.custrecordproductvariantcode='${keyParams.productVariantCode}'`;
      }
      const statuses = extractStatuses(req.query.statuses as string[]);

      if (statuses !== undefined && statuses !== null && statuses.length > 0) {
        const statusSearch = statuses.map((st) => `'${st}'`).join(',');
        sql += ` AND s.billingsubscriptionstatus IN (${statusSearch})`;
      }

      const customerSubscriptionIds = await NetsuiteClient.post(
        `${config.nsClientRestApiBaseUrl}/query/v1/suiteql?limit=1000`,
        {
          q: sql,
        }
      ).then((r) => (r.data.items as { id: string }[]).map((i) => i.id));
      logger.debug(`Subscriptions: ${JSON.stringify(customerSubscriptionIds)}`);

      // why 10? just empirical value
      const batchSize = 10;
      const results = await promiseAllInBatches(
        sid => {
          return makeNSMainClient((req.user as JwtPayload).version)
            .op('subscription.get', { ...keyParams, subscriptionId: sid } as any, null) //NOSONAR
            .then(r => r.data.content);
        },
        customerSubscriptionIds,
        batchSize
      );
      res.json(results.filter((c) => c !== undefined));
    } catch (e) {
      logger.error(e);
      next(e);
    }
  }

  routes(): Router {
    return Router()
      .get(
        '/:subscriptionId',
        NSMainClient.makeProxy('subscription.get', r => ({
          subscriptionId: r.params.subscriptionId,
        }))
      )
      .post('/', NSMainClient.makeProxyWithBody('subscription.create'))
      .put(
        '/:subscriptionId',
        NSMainClient.makeProxyWithBody('subscription.updateOrRenew', r => ({
          subscriptionId: r.params.subscriptionId,
        }))
      )
      .post(
        '/preview/:subscriptionId',
        NSMainClient.makeProxyWithBody('subscription.preview', r => ({
          subscriptionId: r.params.subscriptionId,
        }))
      )
      .post('/preview', NSMainClient.makeProxyWithBody('subscription.preview'))
      .post('/startTrial', NSMainClient.makeProxy('subscription.startTrial'))
      .patch(
        '/:subscriptionId',
        NSMainClient.makeProxyWithBody('subscription.updateStatus', r => ({
          subscriptionId: r.params.subscriptionId,
        }))
      )
      .post(
        '/:subscriptionId/contractualDocuments',
        NSMainClient.makeProxyWithBody('subscription.uploadContractualDocument', r => ({
          subscriptionId: r.params.subscriptionId,
        }))
      )
      .get(
        '/:subscriptionId/renewal',
        NSMainClient.makeProxy('subscription.renewalInfo', r => ({
          subscriptionId: r.params.subscriptionId,
          productTier: r.query.productTier?.toString() ?? '',
          supportLevel: r.query.supportLevel?.toString() ?? ''
        }))
      )
      .post(
        '/:subscriptionId/renewalIntent',
        NSMainClient.makeProxyWithBody('subscription.renewalIntent', r => ({
          subscriptionId: r.params.subscriptionId,
        }))
      );
  }
}
export default new SubscriptionController();
