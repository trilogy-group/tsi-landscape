import { Router } from 'express';
import { NSMainClient } from '../services/NSMainClient';

export class SubscriptionPlanController {
  routes(): Router {
    return Router()
      .get('/', NSMainClient.makeProxy('prodCatalog.listSubscriptionPlans'))
      .get('/latestCode', NSMainClient.makeProxy('prodCatalog.getLatestSubscriptionPlanCode', r => ({
        productTier: r.query.productTier?.toString() ?? '',
        supportLevel: r.query.supportLevel?.toString() ?? '',
        isSupport: r.query.isSupport?.toString().toLowerCase() === 'true',
      }), null, 'text/plain'));
  }
}
export default new SubscriptionPlanController();
