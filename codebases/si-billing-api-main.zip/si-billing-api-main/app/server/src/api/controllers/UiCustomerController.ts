import { SESClient, SendEmailCommand } from "@aws-sdk/client-ses";
import { Response, Router } from "express";
import HttpStatus from "http-status-codes";
import { makeNSMainClient } from "../services/NSMainClient";
import config from "../../common/config";
import { ApiError } from "../../common/errors";
import { Dictionary, JwtPayload, ProxyRequest } from "../../common/types";
import { KeyParams, enumerateAsText, keyParamsFromQuery, resolveAndCatchAsyncHandler } from "../../common/util";

interface PostInterestsParams {
    token: KeyParams,
    nsVersion?: string,
    email: string,
    subscriptionId: number,
    productCodes: string[],
}

interface PostSupportParams {
    customerId: string,
    subscriptionId: number;
    email: string;
    message: string;
    firstName?: string;
    lastName?: string;
    phone?: string;
}

interface SendEmailOptions {
    from: string,
    to: string[],
    subject: string,
    body: string,
}

export class UiCustomerController {
    private readonly _ses: SESClient;

    /**
     * Default constructor.
     */
    constructor() {
        this._ses = new SESClient({ region: config.awsRegion });
    }

    /**
     * POST /ui/customer/interests
     * @param {ProxyRequest} req The request.
     * @param {Response} res The response.
     * @returns {Promise<void>}
     */
    async postInterests(req: ProxyRequest, res: Response): Promise<void> {

        // Retrieve the input parameters.
        const productEmails = config.sspProductEmails;
        const params = this.getPostInterestsParams(req, productEmails);

        // Retrieve the title of the subscription plan, then send an email to product team(s).
        const from = config.awsSesSender;
        const to = this.getMatchingProductEmails(params, productEmails);
        const { subject, body } = await this.buildMessageAsync(params);
        await this.sendEmailAsync({ from, to, subject, body });

        // Return 204 No Content.
        res.status(HttpStatus.NO_CONTENT).end();
    }

    /**
     * Validates and returns the input parameters.
     * @param {ProxyRequest} req The request.
     * @param {Record<string, string>} productEmails The product emails.
     * @returns {PostInterestsParams} The input parameters.
     */
    private getPostInterestsParams(req: ProxyRequest, productEmails: Record<string, string>): PostInterestsParams {

        // Retrieve the key params and NS version.
        const token = keyParamsFromQuery(req.user as JwtPayload, req.query as Dictionary<string>).requireCustomerId();
        const nsVersion = (req.user as JwtPayload)?.version;

        // Retrieve and validate the username in the JWT token.
        const email = req.user?.email as string;
        if (!email) {
            throw new ApiError(HttpStatus.BAD_REQUEST, "The claim 'email' in JWT token is required.");
        }

        // Retrieve and validate the subscription ID.
        const subscriptionId = req.body?.subscriptionId as number;
        if (!subscriptionId) {
            throw new ApiError(HttpStatus.BAD_REQUEST, "The parameter 'subscriptionId' is required.");
        }

        // Retrieve and validate the product codes.
        const productCodes = req.body?.productCodes as string[];
        if (!productCodes || productCodes.length === 0) {
            throw new ApiError(HttpStatus.BAD_REQUEST, "The parameter 'productCodes' is required and cannot be empty.");
        }
        const unknownProductCodes = productCodes.filter(code => !productEmails[code.toLowerCase()]);
        if (unknownProductCodes.length > 0) {
            throw new ApiError(HttpStatus.BAD_REQUEST, `Unknown product code(s): ${unknownProductCodes.join(', ')}.`);
        }

        // Return the input parameters.
        return { token, nsVersion, email, subscriptionId, productCodes};
    }

    /**
     * Returns the emails of the product team(s) matching the product codes.
     * @param {PostInterestsParams} params The input parameters.
     * @param {Record<string, string>} productEmails The product emails.
     * @returns {string[]} The emails of the product team(s).
     */
    private getMatchingProductEmails(params: PostInterestsParams, productEmails: Record<string, string>): string[] {
        return params.productCodes
            .map(code => productEmails[code.toLowerCase()])
            .filter((value, index, array) => array.indexOf(value) === index);
    }

    /**
     * Builds and returns the message to be sent.
     * @param {PostInterestsParams} params The input parameters.
     * @returns {{ subject: string, body: string }} The message to be sent.
     */
    private async buildMessageAsync(params: PostInterestsParams): Promise<{ subject: string, body: string }> {

        // Prepare prerequisite data for building the message.
        const subscriptionPlanDescription = await this.getSubscriptionPlanDescriptionAsync(params);
        const productCodesText = enumerateAsText(params.productCodes);

        // Build the message.
        const subject = `This customer is interested in ${productCodesText} Prime`;
        const body =
            `<p>Hello,</p>` +
            `<p>One of our existing customers is going through the renewal of <b>${subscriptionPlanDescription}</b> - ${params.subscriptionId}, ` +
                `and wants to learn more (be contacted) regarding the <b>${productCodesText} Prime program</b>.</p>` +
            `<p>Please follow up with our customer via this email address: ${params.email}</p>`;
        return { subject, body };
    }

    /**
     * Returns the description of the subscription plan for the given subscription.
     * @param {PostInterestsParams} params The input parameters.
     * @returns {string} The title of the subscription plan.
     */
    private async getSubscriptionPlanDescriptionAsync(params: PostInterestsParams): Promise<string> {

        // Load the subscription. If the subscription is not found, an error will be thrown and catched by the error handler.
        const subscription: { plan: { description: string } } = await makeNSMainClient(params.nsVersion)
            .op('subscription.get', { ...params.token, subscriptionId: params.subscriptionId } as any, null) //NOSONAR
            .then(r => r.data.content);

        // Return the description of the subscription plan.
        return subscription.plan.description;
    }

    /**
     * POST /ui/customer/support
     * @param {ProxyRequest} req The request.
     * @param {Response} res The response.
     * @returns {Promise<void>}
     */
    async postSupport(req: ProxyRequest, res: Response): Promise<void> {

        // Retrieve the input parameters.
        const supportConfig = config.sspSupportConfig;
        const params: PostSupportParams = await this.getPostSupportParamsAsync(req);

        // Prepare the email content.
        const from = supportConfig.sender;
        const to = [ supportConfig.recipient ];
        const subject = supportConfig.subject;
        const body = JSON.stringify(params);

        // Send the email.
        await this.sendEmailAsync({ from, to, subject, body });

        // Return 204 No Content.
        res.status(HttpStatus.NO_CONTENT).end();
    }

    /**
     * Validates and returns the input parameters.
     * @param {ProxyRequest} req The request.
     * @returns {PostSupportParams} The input parameters.
     */
    private async getPostSupportParamsAsync(req: ProxyRequest): Promise<PostSupportParams> {

        // Retrieve the key params and NS version.
        const token = keyParamsFromQuery(req.user as JwtPayload, req.query as Dictionary<string>).requireCustomerId();
        const nsVersion = (req.user as JwtPayload)?.version;

        // Retrieve and validate the email, the subscription ID and the message.
        const email = this.getUserParameter<string>(req, 'email', true);
        const subscriptionId = this.getBodyParameter<number>(req, 'subscriptionId', true);
        const message = this.getBodyParameter<string>(req, 'message', true);

        // Validate the subscription belongs to the customer context by loading it. If not found, an error will be thrown and catched by the error handler.
        const _subscription = await makeNSMainClient(nsVersion)
            .op('subscription.get', { ...token, subscriptionId } as any, null) //NOSONAR
            .then(r => r.data.content);

        // Return the input parameters.
        return {
            customerId: token.customerId as string,
            subscriptionId,
            email,
            message,
            firstName: req.body?.firstName,
            lastName: req.body?.lastName,
            phone: req.body?.phone,
        };
    }

    /**
     * Sends an email.
     * @param {SendEmailOptions} options The options for sending an email.
     */
    private async sendEmailAsync(options: SendEmailOptions): Promise<void>{
        const command = new SendEmailCommand({
            Source: options.from,
            Destination: {
                ToAddresses: options.to,
            },
            Message: {
                Subject: {
                    Data: options.subject,
                },
                Body: {
                    Html: {
                        Data: options.body,
                    },
                },
            },
        });
        await this._ses.send(command);
    }

    /**
     * Returns the value of the given user claim. If the claim is mandatory and missing, throws an error.
     * @param {ProxyRequest} req The request.
     * @param {string} claimName The name of the claim.
     * @param {boolean} [isMandatory] Whether the claim is mandatory. By default, false.
     * @returns The value of the claim.
     */
    private getUserParameter<T>(req: ProxyRequest, claimName: string, isMandatory = false): T {
        const errorMessage = isMandatory ? `The claim '${claimName}' in JWT token is required.` : undefined;
        return this.getParameter<T>(req.user as JwtPayload, claimName, errorMessage);
    }

    /**
     * Returns the value of the given body parameter. If the parameter is mandatory and missing, throws an error.
     * @param {ProxyRequest} req The request.
     * @param {string} parameterName The name of the parameter.
     * @param {boolean} [isMandatory] Whether the parameter is mandatory. By default, false.
     * @returns The value of the parameter.
     */
    private getBodyParameter<T>(req: ProxyRequest, parameterName: string, isMandatory = false): T {
        const errorMessage = isMandatory ? `The parameter '${parameterName}' is required.` : undefined;
        return this.getParameter<T>(req.body as Dictionary<string>, parameterName, errorMessage);
    }

    /**
     * Returns the value of the given parameter from the provided source object. If the parameter is mandatory and missing, throws an error.
     * @param {Dictionary<string> | JwtPayload} source The source object to retrieve the parameter from.
     * @param {string} parameterName The name of the parameter.
     * @param {string} [errorMessage] The error message to throw if the parameter is mandatory and missing. If undefined, the parameter is not mandatory.
     * @returns The value of the parameter.
     */
    private getParameter<T>(source: Dictionary<string> | JwtPayload, parameterName: string, errorMessage?: string): T {
        const value = source[parameterName] as T;
        if (errorMessage !== undefined && !value) {
            throw new ApiError(HttpStatus.BAD_REQUEST, errorMessage);
        }
        return value;
    }

    /**
     * Returns the routes for this controller.
     * @returns The routes.
     */
    routes(): Router {
        return Router()
            .post('/interests', resolveAndCatchAsyncHandler(this.postInterests.bind(this)))
            .post('/support', resolveAndCatchAsyncHandler(this.postSupport.bind(this)));
    }
}

export default new UiCustomerController();
