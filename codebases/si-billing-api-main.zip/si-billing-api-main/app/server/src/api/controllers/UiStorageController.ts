import { DynamoDBClient } from "@aws-sdk/client-dynamodb";
import { DynamoDBDocumentClient, GetCommand, PutCommand, UpdateCommand } from "@aws-sdk/lib-dynamodb";
import { Request, Response, Router } from "express";
import HttpStatus from 'http-status-codes'
import config from '../../common/config';
import { ApiError } from "../../common/errors";
import { ProxyRequest } from "../../common/types";
import { resolveAndCatchAsyncHandler } from "../../common/util";

const RETENTION_DAYS = 60;
const SECONDS_IN_MS = 1000;
const SECONDS_IN_DAY = 86400;

const DEFAULT_VALUE = {};

export class UiStorageController {
    private readonly _dynamodb: DynamoDBDocumentClient;
    private readonly tableName: string;

    /**
     * Default constructor.
     */
    constructor() {
        this._dynamodb = DynamoDBDocumentClient.from(
            new DynamoDBClient({ region: config.awsRegion })
        );
        this.tableName = config.awsTableUiStorage;
    }

    /**
     * GET /ui-storage
     * @param {ProxyRequest}req
     * @param {Response} res
     * @returns {Promise<void>}
     */
    async getAsync(req: ProxyRequest, res: Response): Promise<void> {

        // Retrieve the input parameters.
        const { username, subscriptionId } = this.getInputParams(req);

        // Get the item and return its value. If there is no item, return the default value.
        const item = await this.getItemResultAsync(username, subscriptionId);
        const value = item?.content ? JSON.parse(item.content as string) : DEFAULT_VALUE;
        res.status(HttpStatus.OK).json(value);
    }

    /**
     * PUT /ui-storage
     * @param {Request} req
     * @param {Response} res
     * @returns {Promise<void>}
     */
    async putAsync(req: Request, res: Response): Promise<void> {

        // Retrieve and validate input parameters.
        const { username, subscriptionId, value } = this.getInputParams(req);

        // Create/Update the item based on its existence. If there is no value, consider the default value.
        const content = JSON.stringify(value ?? DEFAULT_VALUE);
        const item = await this.getItemResultAsync(username, subscriptionId);
        if (item) {
            await this.updateItemResultAsync(username, subscriptionId, content);
        } else {
            await this.putItemResultAsync(username, subscriptionId, content);
        }
        res.status(HttpStatus.NO_CONTENT).end();
    }

    /**
     * Returns the input parameters.
     * @param {ProxyRequest} req
     * @returns {{ username: string, subscriptionId: string, value: unknown }} The input parameters.
     */
    private getInputParams(req: ProxyRequest): {
        username: string,
        subscriptionId: string,
        value: unknown,
    } {
        // Retrieve and validate the username in the JWT token.
        const username = req.user?.sub as string;
        if (!username) {
            throw new ApiError(HttpStatus.BAD_REQUEST, "The claim 'sub' in JWT token is required.");
        }

        // Retrieve and validate the subscription ID.
        const subscriptionId = req.query?.subscriptionId as string | undefined
        if (!subscriptionId) {
            throw new ApiError(HttpStatus.BAD_REQUEST, "The query parameter 'subscriptionId' is required.");
        }

        // Return input parameters.
        return { username, subscriptionId, value: req.body };
    }

    /**
     * Returns the routes for this controller.
     * @returns The routes.
     */
    routes(): Router {
        return Router()
            .get('/', resolveAndCatchAsyncHandler(this.getAsync.bind(this)))
            .put('/', resolveAndCatchAsyncHandler(this.putAsync.bind(this)));
    }

    /**
     * Gets the given item from table.
     * @param {string} username The username.
     * @param {string} subscriptionId The subscription ID.
     * @returns {Promise<Record<string, unknown> | undefined>} The item.
     */
    private async getItemResultAsync(username: string, subscriptionId: string): Promise<Record<string, unknown> | undefined> {
        const command = new GetCommand({
            TableName: this.tableName,
            Key: {
                username: username,
                subscriptionId: subscriptionId,
            }
        });
        const response = await this._dynamodb.send(command);
        return response.Item;
    }

    /**
     * Puts an item into the table.
     * @param {string} username The username.
     * @param {string} subscriptionId The subscription ID.
     * @param {string} content The content.
     */
    private async putItemResultAsync(username: string, subscriptionId: string, content: string): Promise<void> {
        const command = new PutCommand({
            TableName: this.tableName,
            Item: {
                username: username,
                subscriptionId: subscriptionId,
                content: content,
                ttl: this.getTimeToLive(),
            }
        });
        await this._dynamodb.send(command);
    }

    /**
     * Updates an item in the table.
     * @param {string} username The username.
     * @param {string} subscriptionId The subscription ID.
     * @param {string} content The content.
     */
    private async updateItemResultAsync(username: string, subscriptionId: string, content: string): Promise<void> {
        const command = new UpdateCommand({
            TableName: this.tableName,
            Key: {
                username: username,
                subscriptionId: subscriptionId,
            },
            UpdateExpression: "set content = :content, #ttl = :ttl",
            ExpressionAttributeValues: {
                ":content": content,
                ":ttl": this.getTimeToLive(),
            },
            // 'ttl' is a reserved keyword in any expression. Define a substitution token.
            ExpressionAttributeNames: {
                "#ttl": "ttl",
            }
        });
        await this._dynamodb.send(command);
    }

    /**
     * Returns the time to live for a created/updated item.
     * @returns The time to live in seconds.
     */
    private getTimeToLive(): number {
        return Math.floor(Date.now() / SECONDS_IN_MS) + RETENTION_DAYS * SECONDS_IN_DAY;
    }
}

export default new UiStorageController();
