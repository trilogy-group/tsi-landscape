import { Response, Router } from "express";
import HttpStatus from 'http-status-codes'
import { makeNSMainClient } from "../services/NSMainClient";
import { Dictionary, JwtPayload, ProxyRequest } from "../../common/types";
import { keyParamsFromQuery, resolveAndCatchAsyncHandler } from "../../common/util";
import { UserError } from "../../common/errors";

/**
 * Subscription view model (defined by Proxy API).
 */
export interface ApiSubscription {
    quotes?: ApiQuote[];
}

/**
 * Quote view model (defined by Proxy API).
 */
export interface ApiQuote {
    isSelfServe: boolean;
    agreements?: ApiAgreement[];
}

/**
 * Agreement view model (defined by Proxy API).
 */
export interface ApiAgreement {
    type: ApiAgreementType;
    status: ApiAgreementStatus;
}

/**
 * (Partial) Enumeration of the agreement type (defined by Proxy API).
 */
export enum ApiAgreementType {
    Quote = 'Quote',
}

/**
 * (Partial) Enumeration of the agreement status (defined by Proxy API).
 */
export enum ApiAgreementStatus {
    Cancelled = 'Cancelled',
    Draft = 'Draft',
    OutForSignature = 'Out For Signature',
    Signed = 'Signed',
}

/**
 * Agreement status response, including cases for no quote and no agreement.
 */
export enum AgreementStatusResponse {
    Draft = 'draft',
    OutForSignature = 'out-for-signature',
    Signed = 'signed',
    NoAgreement = 'no-agreement',
    NoQuote = 'no-quote',
}

export class UiSubscriptionController {

    /**
     * GET /ui/subscription/:subscriptionId/agreementStatus
     * @param {ProxyRequest} req
     * @param {Response} res
     * @returns {Promise<void>}
     */
    async getAgreementStatusAsync(req: ProxyRequest, res: Response): Promise<void> {

        // Retrieve and validate input params.
        const keyParams = keyParamsFromQuery(req.user as JwtPayload, req.query as Dictionary<string>).requireCustomerId();
        const subscriptionId = req.params.subscriptionId;
        if (!subscriptionId) {
            throw new UserError("The query parameter 'subscriptionId' is required.");
        }

        // Retrieve the subscription. If the subscription is not found, an error will be thrown and catched by the error handler.
        const subscription = await makeNSMainClient((req.user as JwtPayload)?.version)
            .op('subscription.get', { ...keyParams, subscriptionId: subscriptionId } as any, null) //NOSONAR
            .then(r => r.data.content);

        // Retrieve the most advanced agreement status, and return it.
        const result = this.getMostAdvancedAgreementStatus(subscription);
        res.status(HttpStatus.OK).send(result);
    }

    /**
     * Returns the most advanced status of a quote agreement for the given subscription.
     * If there is no quote, returns 'no-quote'.
     * If there is no quote agreement or with an unexpected status, returns 'no-agreement'.
     * Considers these agreement statuses in ascending order: 'draft', 'out-for-signature' and 'signed'.
     * Ignores quotes with only cancelled agreement(s).
     * @param {ApiSubscription} subscription The subscription.
     * @returns The most advanced status, or 'no-quote' if there is no quote, or 'no-agreement' if there is no quote agreement.
     */
    private getMostAdvancedAgreementStatus(subscription: ApiSubscription): AgreementStatusResponse {

        // If there is no self-serve quote, returns 'no-quote'.        
        // Ignore quotes with only cancelled agreement(s). Don't remove them due to no-agreement case.
        const selfServeQuotes = subscription.quotes
            ?.filter(q =>
                q.isSelfServe
                && (!q.agreements || q.agreements?.length === 0 || !q.agreements.every(a => a.status === ApiAgreementStatus.Cancelled))
            )
            ?? [];
        if (selfServeQuotes.length === 0) {
            return AgreementStatusResponse.NoQuote;
        }

        // Filter the agreements for retaining only agreements belonging to Self-Serve quotes and with expected statuses.
        const expectedStatuses = [ ApiAgreementStatus.Draft, ApiAgreementStatus.OutForSignature, ApiAgreementStatus.Signed ];
        const retainedAgreements = selfServeQuotes
            .reduce((acc: ApiAgreement[], obj: ApiQuote) => acc.concat(obj.agreements ?? []), [])
            .filter(a => a.type === ApiAgreementType.Quote && expectedStatuses.includes(a.status));

        // If there is no retained agreement , returns 'no-agreement'.
        if (retainedAgreements.length === 0) {
            return AgreementStatusResponse.NoAgreement;
        }

        // If there is at least one retained agreement, returns the most advanced status.
        if (retainedAgreements.some(a => a.status === ApiAgreementStatus.Signed)) {
            return AgreementStatusResponse.Signed;
        } else if (retainedAgreements.some(a => a.status === ApiAgreementStatus.OutForSignature)) {
            return AgreementStatusResponse.OutForSignature;
        } else {
            return AgreementStatusResponse.Draft;
        }
    }

    /**
     * Returns the routes for this controller.
     * @returns The routes.
     */
    routes(): Router {
        return Router()
            .get('/:subscriptionId/agreementStatus', resolveAndCatchAsyncHandler(this.getAgreementStatusAsync.bind(this)))
    }

}

export default new UiSubscriptionController();
