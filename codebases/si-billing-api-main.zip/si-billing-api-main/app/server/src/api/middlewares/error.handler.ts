import { Request, Response, NextFunction } from 'express';
import logger from '../../common/logger';

/**
 *
 * @param err error
 * @param _req request
 * @param res response
 * @param _next next function to be executed
 */
export default function errorHandler(err, _req: Request, res: Response, _next: NextFunction): void {
  const unathorizedStatus = 401;
  const internalServerError = 500;
  const serviceUnavailable = 503;
  const gatewayTimeout = 504;
  if (err.status === unathorizedStatus && err.message === 'invalid signature') {
    err.message = 'Invalid JWT token signature';
  } else if (err.status === serviceUnavailable && err.message === 'Response timeout') {
    err.status = gatewayTimeout;
    err.message = 'Your request is processing, check back in one minute to see if your request has been fulfilled';
  }
  const errors = err.errors || [{ message: err.message }];
  logger.debug(err);
  res.status(err.status || internalServerError).json({ errors });
}
