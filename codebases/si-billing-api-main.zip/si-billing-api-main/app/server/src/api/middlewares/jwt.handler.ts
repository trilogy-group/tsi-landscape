import jwt from 'express-jwt';
import ProductIntegrationService from '../services/ProductIntegrationService';

function secretCallback(_req, payload, done): void {
  if (payload === undefined) {
    done(new jwt.UnauthorizedError('invalid_token', { message: 'Invalid JWT token format' }));
    return;
  }
  if (payload.pfc === undefined) {
    done(new jwt.UnauthorizedError('invalid_token', { message: 'Invalid JWT token: pfc is required' }));
    return;
  }
  if (payload.cid === undefined && payload.padm !== true) {
    done(
      new jwt.UnauthorizedError('invalid_token', {
        message: 'Invalid JWT token: cid or administrative privileges required',
      })
    );
    return;
  }

  const productFamily = payload.pfc;
  const productVariant = payload.pvc ?? null;
  ProductIntegrationService.getProductIntegrationSecret(payload.version, productFamily, productVariant)
    .then((secret) => {
      done(null, secret);
    })
    .catch((e) => {
      done(e, null);
    });
}

export const handler = jwt({ secret: secretCallback, algorithms: ['HS256'] });

export const testables = {
  secretCallback: secretCallback,
};
