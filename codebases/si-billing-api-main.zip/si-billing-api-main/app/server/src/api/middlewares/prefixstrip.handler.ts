import { NextFunction, Request, Response } from 'express';

/**
 * Middleware to ignore certain prefixes
 */
export default function prefixStrip(req: Request, _res: Response, next: NextFunction): void {
  const prefixes = ['/test', '/develop', '/pr'];
  const foundPrefix = prefixes.find((prefix) => req.url.startsWith(prefix));
  if (foundPrefix) {
    req.url = req.url.substring(foundPrefix.length);
  }
  next();
}
