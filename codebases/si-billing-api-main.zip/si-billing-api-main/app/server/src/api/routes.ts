import { Application } from 'express';
import subscriptionController from './controllers/SubscriptionController';
import subscriptionPlanController from './controllers/SubscriptionPlanController';
import customerController from './controllers/CustomerController';
import productController from './controllers/ProductController';
import invoiceController from './controllers/InvoiceController';
import integrationController from './controllers/IntegrationController';
import quoteController from './controllers/QuoteController';
import * as jwtHandler from '../api/middlewares/jwt.handler';
import uiCustomerController from './controllers/UiCustomerController';
import uiStorageController from './controllers/UiStorageController';
import uiSubscriptionController from './controllers/UiSubscriptionController';

/**
 * Server routes
 * Deployment in aws can be done
 *  from command line - https://github.com/trilogy-group/si-billing-api/blob/main/deploy/README.md#build-and-deploy-portal-api
 *  or using Deploy cdk environment github action - https://github.com/trilogy-group/si-billing-api/actions/workflows/cdk-deploy.yml
 */
export default function routes(app: Application): void {
  app.use('/api/v1/integration/netsuiteRelay', integrationController.netSuiteRelay);
  app.use('/api', jwtHandler.handler); // Enable JWT for all endpoints
  app.use('/api/v1/subscription', subscriptionController.routes());
  app.use('/api/v1/products', productController.routes());
  app.use('/api/v1/subscriptionPlans', subscriptionPlanController.routes());
  app.use('/api/v1/customer', customerController.routes());
  app.get('/api/v1/customer/statement', customerController.statement.bind(customerController));
  app.get('/api/v1/customer/latestSignedQuote', customerController.latestSignedQuote.bind(customerController));
  app.use('/api/v1/subscriptions', subscriptionController.forCustomer);
  app.use('/api/v1/integration/searchCustomer', customerController.search);
  app.get('/api/v1/invoices', invoiceController.searchInvoices);
  app.get('/api/v1/invoice/:invoiceNumber/download', invoiceController.downloadInvoice.bind(invoiceController));
  app.get('/api/v1/invoice/:invoiceNumber/paymentLink', invoiceController.paymentLink.bind(invoiceController));
  app.post('/api/v1/invoice', invoiceController.createInvoice.bind(invoiceController));
  app.post('/api/v1/quote', quoteController.createQuote.bind(quoteController));
  app.post('/api/v1/quote/createForSelfServe', quoteController.createQuoteForSelfServe.bind(quoteController));
  app.get('/api/v1/quote/:quoteId/download', quoteController.downloadQuote.bind(quoteController));
  app.post('/api/v1/quote/:quoteId/accept', quoteController.acceptQuote.bind(quoteController));
  app.use('/api/v1/integration/', integrationController.routes());
  app.use('/api/v1/ui/customer/', uiCustomerController.routes());
  app.use('/api/v1/ui/storage/', uiStorageController.routes());
  app.use('/api/v1/ui/subscription/', uiSubscriptionController.routes());
}
