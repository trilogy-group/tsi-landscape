import { Request, Response } from 'express';
import config from '../../common/config';
import { ApiError, HTTP_STATUS_403 } from '../../common/errors';
import logger from '../../common/logger';
import { Dictionary, ProxyRequest, QueryParamsDict } from '../../common/types';
import { defaultIfBlank, KeyParams, keyParams } from '../../common/util';
import NetsuiteClient from './NetsuiteClient';

const HTTP_INTERNAL_SERVER_ERROR = 500;
export class NSMainClient {
  restletUrl: string;
  constructor(restletUrl: string) {
    this.restletUrl = restletUrl;
  }

  static defaultErrorHandler(e: any, res: Response) { // NOSONAR
    logger.error(e);
    res.status(e.status ?? HTTP_INTERNAL_SERVER_ERROR).json({ errors: [{ message: e.message ?? e }] });
  }

  op<T extends KeyParams>(name: string, keys: T, content?: any): Promise<any> { //NOSONAR
    const data = {
      op: name,
      ...keys,
      content: content,
    };
    logger.debug('DATA: ' + JSON.stringify(data));
    return NetsuiteClient.post(this.restletUrl, data);
  }

  proxy(req, res: Response, name: string, keys, content?, contentType?: string) {
    this.op(name, keys, content)
      .then(r => {
        logger.debug(`RESPONSE: ${JSON.stringify(r.data)}`);
        if (!req.timedout) {
          res.contentType(contentType ?? 'application/json');
          res.send(r.data.content);
        }
      })
      .catch(e => NSMainClient.defaultErrorHandler(e, res));
  }

  static makeProxy(name: string, addQueryParams?: Array<string> | ((req: ProxyRequest) => QueryParamsDict), content?, contentType?: string) {
    return (r: Request, res: Response) => {
      const version = (r as ProxyRequest).user?.version;
      const req = r as ProxyRequest;
      if (req.user === undefined) {
        throw new Error('jwt token required');
      }
      let kp = {
        ...keyParams(
          req.user,
          req.query.productFamilyCode?.toString(),
          req.query.productVariantCode?.toString(),
          req.query.customerId?.toString()
        ),
      };

      if (addQueryParams) {
        if (addQueryParams instanceof Array) {
          for (const i of addQueryParams) {
            kp[i] = req.query[i];
          }
        } else {
          kp = { ...kp, ...addQueryParams(req) };
        }
      }
      makeNSMainClient(version).proxy(r, res, name, kp, content ? content(req) : null, contentType);
    };
  }

  static makePrivilegedProxy(
    name: string,
    addQueryParams?: Array<string> | ((req: ProxyRequest) => Dictionary<string>),
    contentType?: string
  ) {
    return NSMainClient.makeProxy(name, addQueryParams, r => {
      if (!r.user.padm) {
        throw new ApiError(HTTP_STATUS_403, 'Permission required');
      }
      return undefined;
    }, contentType);
  }

  static makeProxyWithBody(name: string, addQueryParams?: Array<string> | ((req: ProxyRequest) => QueryParamsDict), contentType?: string) {
    return NSMainClient.makeProxy(name, addQueryParams, r => r.body, contentType);
  }

  static makeInternalProxyWithBody(
    name: string,
    addQueryParams?: Array<string> | ((req: ProxyRequest) => Dictionary<string>),
    contentType?: string
  ) {
    return NSMainClient.makeProxy(name, addQueryParams, r => {
      if (!r.user.padm) {
        throw new ApiError(HTTP_STATUS_403, 'Permission required');
      }
      return r.body;
    }, contentType);
  }
}

const DEFAULT_VERSION = config.nsDefaultVersion ?? 'main';

/**
 * Create a new NSMainClient to make calls to netsuite
 * @param inEnvVersion desired restlet version to run in netsuite
 * @returns new NSMainClient
 */
export function makeNSMainClient(inEnvVersion?: string | null): NSMainClient {
  const envVersion = config.nsCustomVersionAllowed ? defaultIfBlank(DEFAULT_VERSION, inEnvVersion) : DEFAULT_VERSION;
  return new NSMainClient(
    `${config.nsClientRestletBaseUrl}?script=customscript_si_${envVersion}_main_restlet&deploy=customdeploy_si_${envVersion}_main`
  );
}
