import config from '../../common/config';
import NetsuiteClient from './NetsuiteClient';

class NSRestClient {
  restApiBaseUrl: string;
  constructor(restApiBaseUrl: string) {
    this.restApiBaseUrl = restApiBaseUrl;
  }
  get(pathAndQuery: string): Promise<any> { //NOSONAR
    return NetsuiteClient.get(this.restApiBaseUrl + pathAndQuery);
  }

  post(pathAndQuery: string, data: string): Promise<any> { //NOSONAR
    return NetsuiteClient.post(this.restApiBaseUrl + pathAndQuery, data);
  }

  put(pathAndQuery: string, data: string): Promise<any> { //NOSONAR
    return NetsuiteClient.put(this.restApiBaseUrl + pathAndQuery, data);
  }
}

export default new NSRestClient(config.nsClientRestApiBaseUrl);
