import config from '../../common/config';
import crypto from 'crypto';
import OAuth from 'oauth-1.0a';
import axios, { AxiosResponse } from 'axios';
import logger from '../../common/logger';
import { HTTP_INTERNAL_SERVER_ERROR, HTTP_STATUS_400, ApiError } from '../../common/errors';

function logNsCall(url: string, authHeader: string): void {
  logger.debug('Executing call on "' + url + '"');
  logger.debug('AuthHeader: ' + authHeader);
}

const CONTENT_TYPE_JSON = 'application/json';

export default class NetsuiteClient {
  static generateHeader(url: string, method: string, data?: unknown): string {
    const oauth = new OAuth({
      consumer: {
        key: config.nsClientConsumerKey,
        secret: config.nsClientConsumerSecret,
      },
      realm: config.nsClientRealm,
      nonce_length: 11,
      signature_method: 'HMAC-SHA256',
      hash_function: (base_string, key) => {
        return crypto //
          .createHmac('sha256', key)
          .update(base_string)
          .digest('base64');
      },
    });
    const header = oauth.toHeader(
      oauth.authorize(
        { url: url, method: method, data: data },
        { key: config.nsClientTokenKey, secret: config.nsClientTokenSecret }
      )
    );

    return header.Authorization;
  }

  static get(url: string): Promise<AxiosResponse> {
    const authHeader = this.generateHeader(url, 'GET', null);
    logNsCall(url, authHeader);
    return axios.get(url, {
      headers: {
        Authorization: authHeader,
        'Content-Type': CONTENT_TYPE_JSON,
      },
    });
  }

  static async post(url: string, data: any): Promise<any> { //NOSONAR
    const authHeader = this.generateHeader(url, 'POST', null);
    try {
      return await axios.post(url, data, {
        headers: {
          Authorization: authHeader,
          'Content-Type': CONTENT_TYPE_JSON,
          prefer: 'transient',
        },
        maxBodyLength: Infinity,
        maxContentLength: Infinity,
      });
    } catch (error: any) { //NOSONAR
      throw NetsuiteClient.errorHandler(error);
    }
  }

  static async put(url: string, data: any): Promise<any> { //NOSONAR
    const authHeader = this.generateHeader(url, 'PUT', data);
    logNsCall(url, authHeader);
    try {
      return await axios.put(url, data, {
        headers: {
          Authorization: authHeader,
          'Content-Type': CONTENT_TYPE_JSON,
        },
      });
    } catch (error: any) { //NOSONAR
      throw NetsuiteClient.errorHandler(error);
    }
  }

  private static errorHandler(error: any): any { // NOSONAR
    if (error.response) {

      // Case: restlet throws error with default status 400 Bad Request. The received data is sometimes the object itself or an stringified version of it.
      if (error.config.url.toString().startsWith(config.nsClientRestletBaseUrl) && error.response.status === HTTP_STATUS_400) {
        const data = typeof error.response.data === 'string'
          ? JSON.parse(error.response.data.replace(/\\/g, ''))
          : error.response.data;
        const status = data.error?.code && !isNaN(+data.error.code)
          ? +data.error.code
          : HTTP_INTERNAL_SERVER_ERROR;
        return new ApiError(status, data.error.message);
      }

      // Default case.
      return new Error(
        `HTTP req failed (${error.response.status}): \n${JSON.stringify(error.response.data, null, 2)}`
      );
    }
    return error;
  }
}
