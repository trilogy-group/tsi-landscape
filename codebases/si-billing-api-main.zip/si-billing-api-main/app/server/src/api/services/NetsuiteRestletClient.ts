import config from '../../common/config';
import NetsuiteClient from './NetsuiteClient';

class NetsuiteRestletClient {
  restletBaseUrl: string;
  constructor(restletBaseUrl: string) {
    this.restletBaseUrl = restletBaseUrl;
  }
  get(params: string): Promise<any> {
    return NetsuiteClient.get(this.restletBaseUrl + '?' + params);
  }

  post(params: string, data: string): Promise<any> {
    return NetsuiteClient.post(this.restletBaseUrl + '?' + params, data);
  }

  put(params: string, data: string): Promise<any> {
    return NetsuiteClient.put(this.restletBaseUrl + '?' + params, data);
  }
}

export default new NetsuiteRestletClient(config.nsClientRestletBaseUrl);
