import PDFMerger from 'pdf-merger-js';

class PdfMergerService {
  async mergePdfs(pdfs: { name: string; data: string }[]): Promise<string> {
    const merger = new PDFMerger();
    for (const fileData of pdfs.map((pdf) => pdf.data)) {
      merger.add(Buffer.from(fileData, 'base64'));
    }
    const resBuf = await merger.saveAsBuffer();
    return resBuf.toString('base64');
  }
}

export default new PdfMergerService();
