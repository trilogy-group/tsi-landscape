import jwt from 'express-jwt';
import { MemoizeExpiring } from 'typescript-memoize';
import logger from '../../common/logger';
import { KeyParams } from '../../common/util';
import { makeNSMainClient } from './NSMainClient';

class ProductIntegrationService {
  /**
   * Get product integration secret fron NS.
   * @param version version of NS customization deployment
   */
  @MemoizeExpiring(60000)
  async getProductIntegrationSecret(
    version: string,
    productFamilyCode: string,
    productVariantCode: string
  ): Promise<string> {
    return makeNSMainClient(version)
      .op('prodInt.get', new KeyParams(productFamilyCode, productVariantCode))
      .then((r) => {
        if (r.data.content[0] === undefined) {
          throw new jwt.UnauthorizedError('invalid_token', { message: 'Invalid JWT token: invalid pfc or pvc value' });
        }
        return r.data.content[0].secret;
      })
      .catch((e) => {
        logger.debug('Secret not found:');
        logger.error(e);
        new Error('Internal proxy config error');
      });
  }
}

export default new ProductIntegrationService();
