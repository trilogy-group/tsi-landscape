import { SSMClient, GetParameterCommand } from "@aws-sdk/client-ssm";

export interface SupportConfig {
  sender: string;
  recipient: string;
  subject: string;
}

class Config {
  private readonly _ssm: SSMClient;

  /**
   * Default constructor.
   */
  constructor() {
    this._ssm = new SSMClient({ region: process.env.AWS_REGION });
    this.loadSync();
  }

  public awsRegion: string;
  public awsSesSender: string;
  public awsTableUiStorage: string;
  public nsCustomVersionAllowed: boolean;
  public nsDefaultVersion: string;

  public nsClientConsumerKey: string;
  public nsClientConsumerSecret: string;
  public nsClientTokenKey: string;
  public nsClientTokenSecret: string;
  public nsClientRealm: string;
  public nsClientRestApiBaseUrl: string;
  public nsClientRestletBaseUrl: string;
  public sspProductEmails: Record<string, string>;
  public sspSupportConfig: SupportConfig;

  /**
   * Loads the config parameters which can be retrieved synchronously.
   */
  private loadSync(): void {
    this.awsRegion = process.env.AWS_REGION as string;
    this.awsSesSender = process.env.AWS_SES_SENDER as string;
    this.awsTableUiStorage = process.env.AWS_TABLE_UI_STORAGE as string;
    this.nsCustomVersionAllowed = process.env.NS_CUSTOM_VERSION_ALLOWED !== 'false';
    this.nsDefaultVersion = process.env.NS_VERSION ?? 'main';
    const useEnvCredentials = process.env.USE_ENV_CREDENTIALS === 'true';
    if (useEnvCredentials) {
      this.nsClientConsumerKey = process.env.NS_CONSUMER_KEY as string;
      this.nsClientConsumerSecret = process.env.NS_CONSUMER_SECRET as string;
      this.nsClientTokenKey = process.env.NS_TOKEN_KEY as string;
      this.nsClientTokenSecret = process.env.NS_TOKEN_SECRET as string;
      this.nsClientRealm = process.env.NS_CLIENT_REALM as string;
      this.nsClientRestApiBaseUrl = process.env.NS_CLIENT_REST_API_BASE_URL as string;
      this.nsClientRestletBaseUrl = process.env.NS_CLIENT_RESTLET_BASE_URL as string;
    }
  }

  /**
   * Loads the config parameters which must be retrieved asynchronously.
   */
  async loadAsync(): Promise<void> {
    const useEnvCredentials = process.env.USE_ENV_CREDENTIALS === 'true';
    if (useEnvCredentials) {
      return;
    }
    const nsEnvName = process.env.NS_ENV_NAME as string;
    this.nsClientConsumerKey = await this.getSsmParameterValueAsync(`ns-${nsEnvName}-consumer-key`);
    this.nsClientConsumerSecret = await this.getSsmParameterValueAsync(`ns-${nsEnvName}-consumer-secret`, true);
    this.nsClientTokenKey = await this.getSsmParameterValueAsync(`ns-${nsEnvName}-token-key`);
    this.nsClientTokenSecret = await this.getSsmParameterValueAsync(`ns-${nsEnvName}-token-secret`, true);
    this.nsClientRealm = await this.getSsmParameterValueAsync(`ns-${nsEnvName}-realm`);
    this.nsClientRestApiBaseUrl = await this.getSsmParameterValueAsync(`ns-${nsEnvName}-rest-api-base-url`);
    this.nsClientRestletBaseUrl = await this.getSsmParameterValueAsync(`ns-${nsEnvName}-restlet-base-url`);
    this.sspProductEmails = await this.getSsmParameterValueAsResultAsync<Record<string, string>>('self-serve-portal-product-emails');
    this.sspSupportConfig = await this.getSsmParameterValueAsResultAsync<SupportConfig>('self-serve-portal-support-config');
  }

  /**
   * Returns the value of the given parameter from the SSM parameter store.
   * @param {string} name The parameter name.
   * @param {boolean} withDecryption Whether to decrypt the parameter value.
   * @returns {string} The parameter value.
   */
  async getSsmParameterValueAsync(name: string, withDecryption = false): Promise<string> {

    // Retrieve the parameter.
    const command = new GetParameterCommand({
      Name: name,
      WithDecryption: withDecryption,
    });
    const response = await this._ssm.send(command);

    // Validate the parameter is defined, then return the value.
    if (!response?.Parameter?.Value) {
      throw new Error(`Missing SSM parameter '${name}'.`);
    }
    return response.Parameter.Value;
  }

  /**
   * Returns the value of the given parameter from the SSM parameter store as a dictionary.
   * @param {string} name The parameter name.
   * @returns {Record<string, string>} The parameter value as a dictionary.
   */
  async getSsmParameterValueAsResultAsync<T>(name: string): Promise<T> {
    const value = await this.getSsmParameterValueAsync(name);
    try {
      return JSON.parse(value);
    } catch(e) {
      throw new Error('Invalid SSM parameter. Expect JSON.');
    }
  }
}

export default new Config();
