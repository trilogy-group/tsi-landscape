
export const HTTP_STATUS_400 = 400;
export const HTTP_STATUS_403 = 403;
export const HTTP_INTERNAL_SERVER_ERROR = 500;

export class ApiError {
  status: number;
  message: string;
  constructor(status: number, msg?: string) {
    this.status = status;
    this.message = msg || '';
  }
}
export class UserError {
  status = HTTP_STATUS_400;
  message: string;
  constructor(message: string) {
    this.message = message;
  }
}
