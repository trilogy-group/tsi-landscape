import express, { Application } from 'express';
import path from 'path';
import http from 'http';
import os from 'os';
import cookieParser from 'cookie-parser';
import l from './logger';

import errorHandler from '../api/middlewares/error.handler';
import prefixStrip from '../api/middlewares/prefixstrip.handler';
import * as OpenApiValidator from 'express-openapi-validator';
import cors from 'cors';
import config from './config';

const app = express();
export default class ExpressServer {
  private readonly routes: (app: Application) => void;
  private server;
  constructor() {
    app.use(prefixStrip);
    const root = path.normalize(__dirname + '/..');
    app.use(cors());
    app.use(express.json({ limit: process.env.REQUEST_LIMIT || '100kb' }));
    app.use(
      express.urlencoded({
        extended: true,
        limit: process.env.REQUEST_LIMIT || '100kb',
      })
    );
    app.use(express.text({ limit: process.env.REQUEST_LIMIT || '100kb' }));
    app.use(cookieParser(process.env.SESSION_SECRET));
    app.use('/api-explorer', express.static(`${root}/static`));
    app.use(express.static(`${root}/static`));

    const apiSpec = path.join(__dirname, 'api.yml');
    const validateResponses = !!(
      process.env.OPENAPI_ENABLE_RESPONSE_VALIDATION &&
      process.env.OPENAPI_ENABLE_RESPONSE_VALIDATION.toLowerCase() === 'true'
    );
    app.use(process.env.OPENAPI_SPEC || '/api/v1/spec', express.static(apiSpec));
    app.use(errorHandler);
    app.use(
      OpenApiValidator.middleware({
        apiSpec: apiSpec,
        validateRequests: true,
        validateResponses: validateResponses,
        ignorePaths: /.*\/spec(\/|$)/,
      })
    );
    app.use((_req, _res, next) => {
      config.loadAsync()
        .then(() => next())
        .catch(err => next(err));
    });
  }

  router(routes: (app: Application) => void): ExpressServer {
    routes(app);
    app.use(errorHandler);
    return this;
  }

  listen(port: number): Application {
    const welcome = (p: number) => (): void =>
      l.info(`up and running in ${process.env.NODE_ENV || 'development'} @: ${os.hostname()} on port: ${p}}`);

    this.server = http.createServer(app).listen(port, welcome(port));

    return app;
  }

  close(cb: () => unknown): void {
    this.server.close(cb);
  }

  app(): Application {
    return app;
  }
}
