import { Request } from 'express';

export interface JwtPayload {
  pfc?: string;
  pvc?: string;
  cid?: string;
  sub?: string;
  email?: string;
  padm?: boolean;
  version?: string;
}

export interface ProxyRequest extends Request {
  user?: JwtPayload;
}

export interface Dictionary<T> {
  [key: string]: T;
}

export type QueryParamsItem = boolean | number | string | string[];
export type QueryParamsDict = Dictionary<QueryParamsItem>;
