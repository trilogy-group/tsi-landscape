import { Request, Response, NextFunction } from 'express';
import { UserError } from './errors';
import { Dictionary, JwtPayload, ProxyRequest } from './types';
import { NSMainClient, makeNSMainClient } from '../api/services/NSMainClient';
export class KeyParams {
  productFamilyCode?: string;
  productVariantCode?: string;
  customerId?: string;

  constructor(productFamilyCode?: string, productVariantCode?: string, customerId?: string) {
    this.productFamilyCode = productFamilyCode;
    this.productVariantCode = productVariantCode;
    this.customerId = customerId;
  }

  requireCustomerId(): KeyParams {
    if (!this.customerId) {
      throw new UserError('customerId is required');
    }
    return this;
  }

  requireProductFamilyCode(): KeyParams {
    if (!this.productFamilyCode) {
      throw new UserError('productFamilyCode is required');
    }
    return this;
  }

  requireProductVariantCode(): KeyParams {
    if (!this.productVariantCode) {
      throw new UserError('productVariantCode is required');
    }
    return this;
  }

  toString(): string {
    return (
      (this.customerId ? `&customerId=${this.customerId}` : '') +
      (this.productFamilyCode ? `&productFamilyCode=${this.productFamilyCode}` : '') +
      (this.productVariantCode ? `&productVariantCode=${this.productVariantCode}` : '')
    );
  }
}

/**
 * Build NS restlet query params. Params in JWT token take precedence and corresponding arg will be passed only if it not specified in JWT
 * @param jwtPayload
 * @param customerId
 * @param productFamilyCode
 * @param productVariantCode
 * @throws UserError if customerId
 */
export function keyParams(
  jwtPayload: JwtPayload,
  productFamilyCode?: string,
  productVariantCode?: string | undefined,
  customerId?: string | undefined
): KeyParams {
  return new KeyParams(
    jwtPayload.pfc || productFamilyCode,
    jwtPayload.pvc || productVariantCode,
    jwtPayload.cid || customerId
  );
}

/**
 * Returns key params from query parameters.
 * @param {JwtPayload} jwtPayload
 * @param {Dictionary<string>} queryParams
 * @returns {KeyParams}
 */
export function keyParamsFromQuery(jwtPayload: JwtPayload, queryParams: Dictionary<string>): KeyParams {
  return keyParams(jwtPayload, queryParams.productFamilyCode, queryParams.productVariantCode, queryParams.customerId);
}

/**
 * Returns the value or, if undefined, the default value.
 * @param {string} defaultVal
 * @param {string | null} [val]
 * @returns {string}
 */
export function defaultIfBlank(defaultVal: string, val?: string | null): string {
  if (val !== undefined && val !== null && val.trim().length > 0) {
    return val;
  } else {
    return defaultVal;
  }
}

/**
 * Processes all items for a given task in batches.
 * @param task
 * @param {unknown[]} items
 * @param {number} batchSize
 * @returns {Promise<unknown[]>}
 */
export async function promiseAllInBatches(task, items: unknown[], batchSize: number): Promise<unknown[]> {
  let position = 0;
  let results: unknown[] = [];
  while (position < items.length) {
    const itemsForBatch = items.slice(position, position + batchSize);
    results = [...results, ...(await Promise.all(itemsForBatch.map((item) => task(item))))];
    position += batchSize;
  }
  return results;
}

/**
 * Transforms an async handler in a sync handler by encapsulating the async handler.
 * @param {(req: Request, res: Response, next?: any) => Promise<void>} fn The async handler.
 * @returns {(req: Request, res: Response, next?: any) => void} The sync handler encapsulating the async handler.
 */
export function resolveAndCatchAsyncHandler(
  fn: (req: Request, res: Response, next?: NextFunction) => Promise<void>
): (req: Request, res: Response, next?: NextFunction) => void {
    return (req: Request, res: Response, next?: NextFunction) => {
        Promise.resolve(fn(req, res, next)).catch(next);
    };
}

/**
 * Enumerates a list of values with given separators. By default, returns the conjunction of values.
 * @param {string[]} values The list of values to enumerate.
 * @param {string} [defaultSeparator] The separator to use between values.
 * @param {string} [lastSeparator] The separator to use between the last two values.
 * @returns {string} The enumerated list of values.
 */
export function enumerateAsText(values: string[], defaultSeparator?: string, lastSeparator?: string): string {
  if (values.length === 0) {
      return "";
  } else if (values.length === 1) {
      return values[0];
  } else {
      return `${values.slice(0, -1).join(defaultSeparator ?? ', ')}${lastSeparator ?? ' and '}${values.slice(-1)}`;
  }
}

/**
 * make a request and return a pdf
 * @param req request
 * @param res response
 * @param operation netsuite operation
 * @param paramKey keys from query to be informed as content
 */
export function pdfRequest(req: ProxyRequest, res: Response, operation: string, paramKey: string[]): void {
  const paramContent = {};
  for (const i of paramKey) {
    if (req.query[i]) {
      paramContent[i] = req.query[i];
    }
  }
  makeNSMainClient(req.user?.version)
    .op(
      operation,
      {
        ...keyParamsFromQuery(req.user!, req.query as Dictionary<string>).requireCustomerId(),
      } as any,
      paramContent
    ) //NOSONAR
    .then((r) => {
      res.contentType('application/pdf');
      return res.header('isBase64Encoded', '').send(r.data.content);
    })
    .catch((e) => NSMainClient.defaultErrorHandler(e, res));
}
