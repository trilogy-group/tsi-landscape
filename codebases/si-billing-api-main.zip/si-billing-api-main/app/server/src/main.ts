/**
 * Start express server
 */
import './common/env';
import l from './common/logger';
import tsiapp from './tsiapp';

const port = parseInt(process.env.PORT ?? '3000');
function handleSignal(s: string) {
  l.info(`${s} signal received: closing HTTP server`);
  tsiapp.close(() => {
    l.info('HTTP server closed');
  });
}
process.on('SIGINT', () => handleSignal('SIGINT'));
process.on('SIGTERM', () => handleSignal('SIGTERM'));

tsiapp.listen(port);
