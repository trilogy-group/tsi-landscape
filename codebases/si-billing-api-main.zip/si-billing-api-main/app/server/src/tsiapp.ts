/*
   Create and export server. Should be started somewhere else
 */
import './common/env';
import Server from './common/server';
import routes from './api/routes';

export default new Server().router(routes);
