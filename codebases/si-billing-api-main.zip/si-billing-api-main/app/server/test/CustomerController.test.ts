import express from 'express';
import { Response } from 'express';
import { makeNSMainClient } from '../src/api/services/NSMainClient';
import * as NsMainClientModule from '../src/api/services/NSMainClient';
import { NSMainClient } from '../src/api/services/NSMainClient';
import { ProxyRequest } from '../src/common/types';
import { CustomerController } from '../src/api/controllers/CustomerController';

describe('CustomerController', () => {
  const customerController = new CustomerController();
  let mockRequest: ProxyRequest;
  let mockResponse: Response;
  let nsMainClient;

  beforeEach(() => {
    mockRequest = {
      query: {
        endUserId: '1234',
        startDate: '01-Jan-2021',
      },
      user: {
        pfc: 'Customer Support',
        pvc: 'Customer Support',
        cid: 'TEST',
        version: 'v1',
      },
    } as any;

    mockResponse = ({
      contentType: jest.fn(),
      type: jest.fn(),
      header: () => {
        return { send: jest.fn() };
      },
      status: (_st) => {
        return { json: jest.fn() };
      },
    } as unknown) as express.Response;

    nsMainClient = makeNSMainClient();
    jest.spyOn(nsMainClient, 'op');
    jest.spyOn(NsMainClientModule, 'makeNSMainClient').mockReturnValue(nsMainClient);
  });

  afterEach(() => {
    jest.clearAllMocks();
  });

  it('statement should call NSMainClient.op with correct parameters', async () => {
    const mockOp = jest.spyOn(nsMainClient, 'op').mockResolvedValue({ data: { content: 'mockContent' } });
    (nsMainClient.op as any).mockReturnValueOnce({
      then: (x) => {
        x({ data: { content: 'mockContent' } });
        return {
          catch: (y) => {
            y('error');
          },
        };
      },
    });

    await customerController.statement(mockRequest, mockResponse);

    expect(makeNSMainClient).toHaveBeenCalledWith(mockRequest.user?.version);
    expect(mockOp).toHaveBeenCalledWith(
      'customer.statement',
      expect.objectContaining({
        customerId: 'TEST',
        productFamilyCode: 'Customer Support',
        productVariantCode: 'Customer Support',
      }),
      expect.objectContaining({})
    );
    expect(mockResponse.contentType).toHaveBeenCalledWith('application/pdf');
  });

  it('statement should call NSMainClient.defaultErrorHandler if an error occurs', async () => {
    const mockOp = jest.spyOn(NSMainClient, 'defaultErrorHandler').mockImplementation(() => {});
    (nsMainClient.op as any).mockReturnValueOnce({
      then: (x) => {
        x({ data: { content: 'mockContent' } });
        return {
          catch: (y) => {
            y('error');
          },
        };
      },
    });

    await customerController.statement(mockRequest, mockResponse);

    expect(mockOp).toHaveBeenCalled();
  });

  it('getLatestSignedQuote should call NSMainClient.op with correct parameters', async () => {
    const mockOp = jest.spyOn(nsMainClient, 'op').mockResolvedValue({ data: { content: 'mockContent' } });
    (nsMainClient.op as any).mockReturnValueOnce({
      then: (x) => {
        x({ data: { content: 'mockContent' } });
        return {
          catch: (y) => {
            y('error');
          },
        };
      },
    });

    await customerController.latestSignedQuote(mockRequest, mockResponse);

    expect(makeNSMainClient).toHaveBeenCalledWith(mockRequest.user?.version);
    expect(mockOp).toHaveBeenCalledWith(
      'customer.getLatestSignedQuote',
      expect.objectContaining({
        customerId: 'TEST',
        productFamilyCode: 'Customer Support',
        productVariantCode: 'Customer Support',
      }),
      expect.objectContaining({})
    );
    expect(mockResponse.contentType).toHaveBeenCalledWith('application/pdf');
  });

  it('getLatestSignedQuote should call NSMainClient.defaultErrorHandler if an error occurs', async () => {
    const mockOp = jest.spyOn(NSMainClient, 'defaultErrorHandler').mockImplementation(() => {});
    (nsMainClient.op as any).mockReturnValueOnce({
      then: (x) => {
        x({ data: { content: 'mockContent' } });
        return {
          catch: (y) => {
            y('error');
          },
        };
      },
    });

    await customerController.latestSignedQuote(mockRequest, mockResponse);

    expect(mockOp).toHaveBeenCalled();
  });
});
