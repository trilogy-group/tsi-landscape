import { Request, Response } from 'express';
import 'mocha';
import NetsuiteClient from '../src/api/services/NetsuiteClient';

import { makeNSMainClient, NSMainClient } from '../src/api/services/NSMainClient';

function makeResponse() {
  const response = {} as any;
  //response.
  response.send = (data) => {
    console.log(`send called with ${JSON.stringify(data)}`);
    response._resolvePromise(data);
  };

  response.status = (s) => {
    console.log(`status called ${s}`);
    response.statusSent = s;
    return response;
  };

  response.json = (data) => {
    console.log(`json called with ${JSON.stringify(data)}`);
    response.jsonSent = data;
    response._rejectPromise(data);
    return response;
  };
  response.contentType = (type) => {
    response.contentTypeSet = type;
  };
  return response;
}

describe('NSMainClient', () => {
  it('makeProxy', async () => {
    const response = makeResponse();
    NetsuiteClient.post = (_arg1, data) =>
      new Promise((resolve, _reject) => {
        resolve({ data: { content: { request: data } } });
      });
    const proxyHandler = NSMainClient.makeProxy('test.action', []);
    const prom = new Promise((resolve, reject) => {
      response._resolvePromise = resolve;
      response._rejectPromise = reject;
      proxyHandler(({ query: {}, user: { pfc: 'pfc1', pvc: 'pvc1' } } as unknown) as Request, response as Response);
    });

    const dataSent = await prom;

    expect(dataSent).toStrictEqual({
      request: {
        productFamilyCode: 'pfc1',
        productVariantCode: 'pvc1',
        op: 'test.action',
        content: null,
        customerId: undefined,
      },
    });
  });

  it('makeProxy_user_undefined', async () => {
    const response = makeResponse();
    NetsuiteClient.post = (_arg1, data) =>
      new Promise((resolve, _reject) => {
        resolve({ data: { content: { request: data } } });
      });
    const proxyHandler = NSMainClient.makeProxy('test.action', []);

    const prom = new Promise((resolve, reject) => {
      response._resolvePromise = resolve;
      response._rejectPromise = reject;
      try {
        proxyHandler(({ query: {} } as unknown) as Request, response as Response);
      } catch (e) {
        reject(e);
      }
    });
    let error = '';
    try {
      await prom;
    } catch (e) {
      error = e.message;
    }
    expect(error).toBe('jwt token required');
  });

  it('makeProxyWithBody', async () => {
    const response = makeResponse();
    NetsuiteClient.post = (_arg1, data) =>
      new Promise((resolve, _reject) => {
        resolve({ data: { content: { request: data } } });
      });
    const proxyHandler = NSMainClient.makeProxyWithBody('test.action', []);
    const prom = new Promise((resolve, reject) => {
      response._resolvePromise = resolve;
      response._rejectPromise = reject;
      proxyHandler(
        ({ query: {}, body: 'testbody', user: { pfc: 'pfc1', pvc: 'pvc1' } } as unknown) as Request,
        response as Response
      );
    });
    const dataSent = await prom;
    expect(dataSent).toStrictEqual({
      request: {
        productFamilyCode: 'pfc1',
        productVariantCode: 'pvc1',
        op: 'test.action',
        content: 'testbody',
        customerId: undefined,
      },
    });
  });

  it('proxyWithError', async () => {
    const response = makeResponse();
    const expectedErrorMessage = 'Test error message';
    NetsuiteClient.post = (_arg1, _) =>
      new Promise((_resolve, reject) => {
        reject({ status: 500, message: expectedErrorMessage });
      });
    const proxyHandler = NSMainClient.makeProxyWithBody('test.action', []);
    const prom = new Promise((resolve, reject) => {
      response._resolvePromise = resolve;
      response._rejectPromise = reject;
      proxyHandler(
        ({ query: {}, body: 'testbody', user: { pfc: 'pfc1', pvc: 'pvc1' } } as unknown) as Request,
        response as Response
      );
    });

    try {
      await prom;
      fail('Error expected');
    } catch (e: any) {
      expect(e.errors[0].message).toBe(expectedErrorMessage);
    }
  });

  it('makeInternalProxyWithBody error', async () => {
    const response = makeResponse();
    NetsuiteClient.post = (_arg1, _) =>
      new Promise((_resolve, reject) => {
        reject({ status: 500, message: 'Test error message' });
      });
    const proxyHandler = NSMainClient.makeInternalProxyWithBody('test.action', []);
    const prom = new Promise((resolve, reject) => {
      response._resolvePromise = resolve;
      response._rejectPromise = reject;
      proxyHandler(
        ({ query: {}, body: 'testbody', user: { pfc: 'pfc1', pvc: 'pvc1' } } as unknown) as Request,
        response as Response
      );
    });

    try {
      await prom;
      fail('Error expected');
    } catch (e) {
      expect(e.status).toBe(403);
    }
  });

  it('makeInternalProxyWithBody', async () => {
    const response = makeResponse();
    NetsuiteClient.post = (_arg1, data) =>
      new Promise((resolve, _reject) => {
        resolve({ data: { content: { request: data } } });
      });
    const proxyHandler = NSMainClient.makeInternalProxyWithBody('test.action', []);
    const prom = new Promise((resolve, reject) => {
      response._resolvePromise = resolve;
      response._rejectPromise = reject;
      proxyHandler(
        ({
          query: { productFamilyCode: 'pfc2', productgVariantCode: 'pvc2', customerId: 'cid2' },
          body: 'testbody',
          user: { pfc: 'pfc1', pvc: 'pvc1', padm: true },
        } as unknown) as Request,
        response as Response
      );
    });

    const dataSent = await prom;

    expect(dataSent).toStrictEqual({
      request: {
        productFamilyCode: 'pfc1',
        productVariantCode: 'pvc1',
        op: 'test.action',
        content: 'testbody',
        customerId: 'cid2',
      },
    });
  });

  it('makePrivilegedProxy', async () => {
    const response = makeResponse();
    NetsuiteClient.post = (_arg1, data) =>
      new Promise((resolve, _reject) => {
        resolve({ data: { content: { request: data } } });
      });
    const proxyHandler = NSMainClient.makePrivilegedProxy('test.action', []);
    const prom = new Promise((resolve, reject) => {
      response._resolvePromise = resolve;
      response._rejectPromise = reject;
      proxyHandler(
        ({
          query: { productFamilyCode: 'pfc2', productgVariantCode: 'pvc2', customerId: 'cid2' },
          user: { pfc: 'pfc1', pvc: 'pvc1', padm: true },
        } as unknown) as Request,
        response as Response
      );
    });

    const dataSent = await prom;

    expect(dataSent).toStrictEqual({
      request: {
        productFamilyCode: 'pfc1',
        productVariantCode: 'pvc1',
        op: 'test.action',
        content: undefined,
        customerId: 'cid2',
      },
    });
  });

  it('makePrivilegedProxy error', async () => {
    const response = makeResponse();
    NetsuiteClient.post = (_arg1, _) =>
      new Promise((_resolve, reject) => {
        reject({ status: 500, message: 'Test error message' });
      });
    const proxyHandler = NSMainClient.makePrivilegedProxy('test.action', []);
    const prom = new Promise((resolve, reject) => {
      response._resolvePromise = resolve;
      response._rejectPromise = reject;
      proxyHandler(
        ({ query: {}, body: 'testbody', user: { pfc: 'pfc1', pvc: 'pvc1' } } as unknown) as Request,
        response as Response
      );
    });

    try {
      await prom;
      fail('Error expected');
    } catch (e) {
      expect(e.status).toBe(403);
    }
  });
});
