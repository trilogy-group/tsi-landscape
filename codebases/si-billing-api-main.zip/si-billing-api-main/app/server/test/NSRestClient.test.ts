import { AxiosResponse } from 'axios';
import { Request, Response } from 'express';
import { url } from 'inspector';
import 'mocha';
import NetsuiteClient from '../src/api/services/NetsuiteClient';
import nsRestClient from '../src/api/services/NSRestClient';
import config from '../src/common/config';

function makeResponse() {
  const response = {} as any;
  //response.
  response.send = (data) => {
    console.log(`send called with ${JSON.stringify(data)}`);
    response._resolvePromise(data);
  };

  response.status = (s) => {
    console.log(`status called ${s}`);
    response.statusSent = s;
    return response;
  };

  response.json = (data) => {
    console.log(`json called with ${JSON.stringify(data)}`);
    response.jsonSent = data;
    response._rejectPromise(data);
    return response;
  };
  response.contentType = (type) => {
    response.contentTypeSet = type;
  };
  return response;
}

describe('NSRestClient', () => {
  it('get', async () => {
    NetsuiteClient.get = (url) =>
      new Promise((resolve, _reject) => {
        resolve({ data: { content: { request: { url: url } } } } as AxiosResponse<any>);
      });

    const res = await nsRestClient.get('/testurl');

    expect(res.data.content.request.url).toEqual(config.nsClientRestApiBaseUrl + '/testurl');
  });

  it('post', async () => {
    NetsuiteClient.post = (url, data) =>
      new Promise((resolve, _reject) => {
        resolve({ data: { content: { request: { url: url, data: data } } } } as AxiosResponse<any>);
      });

    const res = await nsRestClient.post('/testurl', 'testdata');

    expect(res.data.content.request.url).toEqual(config.nsClientRestApiBaseUrl + '/testurl');
    expect(res.data.content.request.data).toEqual('testdata');
  });

  it('put', async () => {
    NetsuiteClient.put = (url, data) =>
      new Promise((resolve, _reject) => {
        resolve({ data: { content: { request: { url: url, data: data } } } } as AxiosResponse<any>);
      });

    const res = await nsRestClient.put('/testurl', 'testdata');

    expect(res.data.content.request.url).toEqual(config.nsClientRestApiBaseUrl + '/testurl');
    expect(res.data.content.request.data).toEqual('testdata');
  });
});
