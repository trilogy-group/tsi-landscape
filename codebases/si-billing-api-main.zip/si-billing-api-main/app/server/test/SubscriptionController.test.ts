import subscriptionController from '../src/api/controllers/SubscriptionController';
import NetsuiteClient from '../src/api/services/NetsuiteClient';
import { makeNSMainClient } from '../src/api/services/NSMainClient';
import * as NsMainClientModule from '../src/api/services/NSMainClient';

function makeResponse() {
  const response = {} as any;
  //response.
  response.send = (data) => {
    console.log(`send called with ${JSON.stringify(data)}`);
    response._resolvePromise(data);
  };

  response.status = (s) => {
    console.log(`status called ${s}`);
    response.statusSent = s;
    return response;
  };

  response.json = (data) => {
    console.log(`json called with ${JSON.stringify(data)}`);
    response.jsonSent = data;
    if (response._rejectPromise) {
      response._rejectPromise(data);
    }
    return response;
  };
  response.contentType = (type) => {
    response.contentTypeSet = type;
  };
  return response;
}

let nsMainClient;

describe('SubscriptionController', () => {
  beforeEach(() => {
    jest.restoreAllMocks();
    jest.spyOn(NetsuiteClient, 'post');
    nsMainClient = makeNSMainClient();
    jest.spyOn(nsMainClient, 'op');
    jest.spyOn(NsMainClientModule, 'makeNSMainClient').mockReturnValue(nsMainClient);
  });

  it('forCustomer', async () => {
    const req = {
      user: {
        cid: 'TestCustomerId',
      },
      query: {
        statuses: ['ACTIVE', 'DRAFT'],
      },
    } as any;
    const res = makeResponse();
    (NetsuiteClient.post as any).mockReturnValueOnce(
      new Promise((resolve, _reject) => {
        resolve({
          data: { items: [{ id: '1' }, { id: '2' }, { id: '3' }, { id: '4' }] },
        });
      })
    );

    (nsMainClient.op as any).mockImplementation((_name, keys, _data) => {
      return new Promise((resolve, _reject) => {
        resolve({
          data: {
            content: {
              id: keys.subscriptionId,
            },
          },
        });
      });
    });

    await subscriptionController.forCustomer(req, res);

    expect(res.jsonSent).toStrictEqual([{ id: '1' }, { id: '2' }, { id: '3' }, { id: '4' }]);
  });

  it('forCustomer_invalidStatuses', async () => {
    const req = {
      user: {
        cid: 'TestCustomerId',
      },
      query: {
        statuses: ['ACTIVE', `') union drop table users`, 'DRAFT'],
      },
    } as any;
    const res = makeResponse();
    (NetsuiteClient.post as any).mockReturnValueOnce(
      new Promise((resolve, _reject) => {
        resolve({});
      })
    );

    let err = null;
    await subscriptionController.forCustomer(req, res, (e) => {
      err = e;
    });

    expect(err).not.toBeNull();
  });
});
