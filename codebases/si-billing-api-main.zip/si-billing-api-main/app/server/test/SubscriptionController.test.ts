import { json as jsonParser } from 'body-parser';
import express, { Express } from 'express';
import jwtMiddleware from 'express-jwt';
import jwt from 'jsonwebtoken';
import request from 'supertest';
import subscriptionController from '../src/api/controllers/SubscriptionController';
import NetsuiteClient from '../src/api/services/NetsuiteClient';
import * as NsMainClientModule from '../src/api/services/NSMainClient';
import { makeNSMainClient, NSMainClient } from '../src/api/services/NSMainClient';

function makeResponse() {
  const response = {} as any;
  //response.
  response.send = (data) => {
    console.log(`send called with ${JSON.stringify(data)}`);
    response._resolvePromise(data);
  };

  response.status = (s) => {
    console.log(`status called ${s}`);
    response.statusSent = s;
    return response;
  };

  response.json = (data) => {
    console.log(`json called with ${JSON.stringify(data)}`);
    response.jsonSent = data;
    if (response._rejectPromise) {
      response._rejectPromise(data);
    }
    return response;
  };
  response.contentType = (type) => {
    response.contentTypeSet = type;
  };
  return response;
}

let nsMainClient;

describe('SubscriptionController', () => {
  let mockedApp: Express;
  let mockedJwtToken: string;

  beforeEach(() => {
    jest.restoreAllMocks();
    jest.spyOn(NetsuiteClient, 'post');
    nsMainClient = makeNSMainClient();
    jest.spyOn(nsMainClient, 'op');
    jest.spyOn(NsMainClientModule, 'makeNSMainClient').mockReturnValue(nsMainClient);

    // Prepare a mocked JWT token.
    const payload = {
      pfc: 'pfc1',
      pvc: 'pvc1',
      padm: true,
    };
    const secret = 'mock-secret';
    const options = { expiresIn: '1h' };
    mockedJwtToken = jwt.sign(payload, secret, options);

    // Prepare JWT for all endpoints.
    mockedApp = express();
    mockedApp.use(jsonParser());
    mockedApp.use('/api', jwtMiddleware({ secret, algorithms: ['HS256'] }));
    mockedApp.use('/api/v1/subscription', subscriptionController.routes());
  });

  it('forCustomer', async () => {
    const req = {
      user: {
        cid: 'TestCustomerId',
      },
      query: {
        statuses: ['ACTIVE', 'DRAFT'],
      },
    } as any;
    const res = makeResponse();
    (NetsuiteClient.post as any).mockReturnValueOnce(
      new Promise((resolve, _reject) => {
        resolve({
          data: { items: [{ id: '1' }, { id: '2' }, { id: '3' }, { id: '4' }] },
        });
      })
    );

    (nsMainClient.op as any).mockImplementation((_name, keys, _data) => {
      return new Promise((resolve, _reject) => {
        resolve({
          data: {
            content: {
              id: keys.subscriptionId,
            },
          },
        });
      });
    });

    await subscriptionController.forCustomer(req, res);

    expect(res.jsonSent).toStrictEqual([{ id: '1' }, { id: '2' }, { id: '3' }, { id: '4' }]);
  });

  it('forCustomer_invalidStatuses', async () => {
    const req = {
      user: {
        cid: 'TestCustomerId',
      },
      query: {
        statuses: ['ACTIVE', `') union drop table users`, 'DRAFT'],
      },
    } as any;
    const res = makeResponse();
    (NetsuiteClient.post as any).mockReturnValueOnce(
      new Promise((resolve, _reject) => {
        resolve({});
      })
    );

    let err = null;
    await subscriptionController.forCustomer(req, res, (e) => {
      err = e;
    });

    expect(err).not.toBeNull();
  });

  it('renewalIntent should invoke NSMainClient.op with correctly', async () => {
    const subscriptionId = '747474';
    const mockedNSResponse = {
      subscriptionId,
      lastActivity: new Date().toISOString(),
    };

    const mockedNSOp = jest
      .spyOn(NSMainClient.prototype, 'op')
      .mockImplementationOnce(async (_name, _keys, _content) => ({ data: { content: mockedNSResponse } }));

    const response = await request(mockedApp)
      .post(`/api/v1/subscription/${subscriptionId}/renewalIntent`)
      .set('Authorization', `Bearer ${mockedJwtToken}`)
      .send();

    expect(response.status).toBe(200);
    expect(mockedNSOp).toHaveBeenCalled();
    expect(mockedNSOp).toHaveBeenCalledWith(
      'subscription.renewalIntent',
      expect.objectContaining({ subscriptionId }),
      expect.anything()
    );
    expect(response.body).toEqual(mockedNSResponse);
  });
});
