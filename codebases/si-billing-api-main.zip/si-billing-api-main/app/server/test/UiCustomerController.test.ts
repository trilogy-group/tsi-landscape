import { SESClient, SESClientResolvedConfig, SendEmailCommand, ServiceInputTypes, ServiceOutputTypes } from '@aws-sdk/client-ses';
import { AwsStub, mockClient } from 'aws-sdk-client-mock';
import HttpStatus from 'http-status-codes';
import UiCustomerController from "../src/api/controllers/UiCustomerController";
import config from "../src/common/config";
import { ApiError } from "../src/common/errors";
import NetsuiteClient from '../src/api/services/NetsuiteClient';
import { fail } from 'assert';

describe('UiCustomerController', () => {
    let _sesMock: AwsStub<ServiceInputTypes, ServiceOutputTypes, SESClientResolvedConfig>;
    
    const productEmails = { cloudfix: "cloudfix@fake.com", crossover: "crossover@fake.com" };
    const supportConfig = {
        sender: "sender@trilogy.com",
        recipient: "recipient@trilogy.com",
        subject: "my-subject",
    };

    beforeAll(() => {
        _sesMock = mockClient(SESClient);
    });

    beforeEach(() => {
        _sesMock.reset();
        jest.resetAllMocks();
        config.sspProductEmails = productEmails;
        config.sspSupportConfig = supportConfig;
    });

    it('postInterests should throw error when a parameter is missing or invalid', async () => {
        // Arrange
        const initialRequest: any = {
            user: { cid: "1", email : "customer@fake.com" },
            query: {},
            body: { subscriptionId: 101, productCodes: [ "Cloudfix", "Crossover" ] },
        };
        const res: any = {};

        const tests = [
            { preAction: (req: any) => delete req.user.email, expected: { message: "The claim 'email' in JWT token is required." } },
            { preAction: (req: any) => delete req.body.subscriptionId, expected: { message: "The parameter 'subscriptionId' is required." } },
            { preAction: (req: any) => delete req.body.productCodes, expected: { message: "The parameter 'productCodes' is required and cannot be empty." } },
            { preAction: (req: any) => req.body.productCodes.length = 0, expected: { message: "The parameter 'productCodes' is required and cannot be empty." } },
            { preAction: (req: any) => req.body.productCodes = [ "fake-1", "Cloudfix", "fake-2" ], expected: { message: "Unknown product code(s): fake-1, fake-2." } },
        ]
        for (const test of tests) {
            const req = JSON.parse(JSON.stringify(initialRequest));
            test.preAction(req);

            try {
                // Act
                await UiCustomerController.postInterests(req, res);
                fail();
            } catch (e) {
                // Assert
                expect(e).toBeInstanceOf(ApiError);
                const apiError = e as ApiError;
                expect(apiError.status).toBe(HttpStatus.BAD_REQUEST);
                expect(apiError.message).toBe(test.expected.message);
            }
        }        
    });

    it('postInterests should send an email', async () => {
        // Arrange
        const req: any = {
            user: { cid: "1", email : "customer@fake.com" },
            query: {},
            body: { subscriptionId: 101, productCodes: [ "Cloudfix", "Crossover" ] },
        };
        const res: any = {
            status: jest.fn().mockReturnThis(),
            end: jest.fn(),
        };
        const subscription = {
            plan: {
                id: 201,
            },
        };
        const subscriptionPlans = [
            { id: 201, title: 'Plan A' },
            { id: 202 },
        ];
        jest.spyOn(NetsuiteClient, 'post')
            .mockResolvedValueOnce({ data: { content: subscription }})
            .mockResolvedValueOnce({ data: { content: subscriptionPlans }});
        _sesMock.on(SendEmailCommand).resolves({});

        // Act
        await UiCustomerController.postInterests(req, res);

        // Assert
        expect(res.status).toHaveBeenCalledWith(HttpStatus.NO_CONTENT);
    });

    it('postSupport should throw error when a parameter is missing or invalid', async () => {
        // Arrange
        const initialRequest: any = {
            user: { cid: "1", email: "customer@fake.com" },
            query: {},
            body: { subscriptionId: 101, message: "Need help with my account." },
        };
        const res: any = {};
        jest.spyOn(NetsuiteClient, 'post').mockReturnValueOnce(
            Promise.resolve({ data: { content: { id: 101 } } })
        );

        const tests = [
            { preAction: (req: any) => delete req.user.email, expected: { message: "The claim 'email' in JWT token is required." } },
            { preAction: (req: any) => delete req.body.subscriptionId, expected: { message: "The parameter 'subscriptionId' is required." } },
            { preAction: (req: any) => delete req.body.message, expected: { message: "The parameter 'message' is required." } },
        ];

        for (const test of tests) {
            const req = JSON.parse(JSON.stringify(initialRequest));
            test.preAction(req);

            try {
                // Act
                await UiCustomerController.postSupport(req, res);
                fail();
            } catch (e) {
                // Assert
                expect(e).toBeInstanceOf(ApiError);
                const apiError = e as ApiError;
                expect(apiError.status).toBe(HttpStatus.BAD_REQUEST);
                expect(apiError.message).toBe(test.expected.message);
            }
        }
    });

    it('postSupport should send an email with the correct parameters', async () => {
        // Arrange
        const req: any = {
            user: { cid: "1", email: "customer@fake.com" },
            query: {},
            body: {
                subscriptionId: 101,
                message: "Need help with my account.",
                firstName: "John",
                lastName: "Smith",
                phone: "123-456-7890",
            },
        };
        const res: any = {
            status: jest.fn().mockReturnThis(),
            end: jest.fn(),
        };
        jest.spyOn(NetsuiteClient, 'post').mockReturnValueOnce(
            Promise.resolve({ data: { content: { id: 101 } } })
        );
        const expectedBody = {
            customerId: req.user.cid,
            email: req.user.email,
            ...req.body,
        };
        let actualCommand;
        _sesMock.on(SendEmailCommand).callsFakeOnce((command) => actualCommand = command);

        // Act
        await UiCustomerController.postSupport(req, res);

        // Assert
        expect(actualCommand).toBeDefined();
        expect(actualCommand.Source).toEqual(supportConfig.sender);
        expect(actualCommand.Destination?.ToAddresses[0]).toEqual(supportConfig.recipient);
        expect(actualCommand.Message?.Subject?.Data).toEqual(supportConfig.subject);
        expect(JSON.parse(actualCommand.Message?.Body?.Html?.Data)).toMatchObject(expectedBody);
        expect(res.status).toHaveBeenCalledWith(HttpStatus.NO_CONTENT);
    });

    it('getUserParameter should throw an error when a required user parameter is missing', () => {
        // Arrange
        const req: any = {
            user: {},
        };
        const claimName = 'email';
        const isMandatory = true;

        try {
            // Act
            Object.getPrototypeOf(UiCustomerController).getUserParameter(req, claimName, isMandatory);
            fail("unexpected success");
        } catch(e) {
            // Assert
            expect(e).toBeInstanceOf(ApiError);
            const error = e as ApiError;
            expect(error.message).toBe(`The claim '${claimName}' in JWT token is required.`);
            expect(error.status).toBe(HttpStatus.BAD_REQUEST);
        }
    });

    it('getBodyParameter should throw an error when a required body parameter is missing', () => {
        // Arrange
        const req: any = {
            body: {},
        };
        const parameterName = 'subscriptionId';
        const isMandatory = true;

        try {
            // Act
            Object.getPrototypeOf(UiCustomerController).getBodyParameter(req, parameterName, isMandatory);
        } catch(e) {
            // Assert
            expect(e).toBeInstanceOf(ApiError);
            const error = e as ApiError;
            expect(error.message).toBe(`The parameter '${parameterName}' is required.`);
            expect(error.status).toBe(HttpStatus.BAD_REQUEST);
        }
    });

    it('getParameter should retrieve a parameter when it exists', () => {
        // Arrange
        const source = { email: "customer@fake.com" };
        const parameterName = 'email';

        // Act
        const result = Object.getPrototypeOf(UiCustomerController).getParameter(source, parameterName);

        // Assert
        expect(result).toEqual(source.email);
    });

    it('getParameter should return undefined when it does not exist and it is not required', () => {
        // Arrange
        const source = {};
        const parameterName = 'email';

        // Act
        const result = Object.getPrototypeOf(UiCustomerController).getParameter(source, parameterName);

        // Assert
        expect(result).toBeUndefined();
    });

    it('getBodyParameter should retrieve a body parameter when it exists', () => {
        // Arrange
        const req: any = {
            body: { subscriptionId: 101},
        };
        const parameterName = 'subscriptionId';

        // Act
        const result = Object.getPrototypeOf(UiCustomerController).getBodyParameter(req, parameterName);

        // Assert
        expect(result).toEqual(req.body.subscriptionId);
    });
});
