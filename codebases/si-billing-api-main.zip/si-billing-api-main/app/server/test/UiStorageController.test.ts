import { AwsStub, mockClient } from "aws-sdk-client-mock";
import { DynamoDBClientResolvedConfig, ServiceInputTypes, ServiceOutputTypes } from "@aws-sdk/client-dynamodb";
import { DynamoDBDocumentClient, GetCommand, PutCommand, UpdateCommand } from "@aws-sdk/lib-dynamodb";
import uiStorageController from "../src/api/controllers/UiStorageController";
import { ApiError } from "../src/common/errors";
import HttpStatus from 'http-status-codes';

describe('UiStorageController', () => {
    let _dynamodbMock: AwsStub<ServiceInputTypes, ServiceOutputTypes, DynamoDBClientResolvedConfig>;

    beforeAll(() => {
        _dynamodbMock = mockClient(DynamoDBDocumentClient);
    });

    beforeEach(() => {
        _dynamodbMock.reset();
    });

    it('getInputParams should throw API error when sub is missing', async() => {
        // Arrange
        const req: any = {
            user: { sub: undefined },
            query: { subscriptionId: "123" },
        };
        const res: any = {};

        try {
            // Act
            await uiStorageController.getAsync(req, res);
            fail();
        } catch (e) {
            // Assert
            expect(e).toBeInstanceOf(ApiError);
            const apiError = e as ApiError;
            expect(apiError.status).toBe(HttpStatus.BAD_REQUEST);
            expect(apiError.message).toBe("The claim 'sub' in JWT token is required.");
        }
    });

    it('getInputParams should throw API error when subscriptionId is missing', async() => {
        // Arrange
        const req: any = {
            user: { sub: "john.smith" },
            query: { subscriptionId: undefined },
        };
        const res: any = {};

        try {
            // Act
            await uiStorageController.getAsync(req, res);
            fail();
        } catch (e) {
            // Assert
            expect(e).toBeInstanceOf(ApiError);
            const apiError = e as ApiError;
            expect(apiError.status).toBe(HttpStatus.BAD_REQUEST);
            expect(apiError.message).toBe("The query parameter 'subscriptionId' is required.");
        }
    });

    it('getAsync should return default value when no value is found', async() => {
        // Arrange
        const req: any = {
            user: { sub: "john.smith" },
            query: { subscriptionId: "123" },
        };
        const res: any = {
            status: jest.fn().mockReturnThis(),
            json: jest.fn(),
        };
        _dynamodbMock.on(GetCommand).resolves({
            Item: undefined,
        });

        // Act
        await uiStorageController.getAsync(req, res);

        // Assert
        expect(res.status).toHaveBeenCalledWith(HttpStatus.OK);
        expect(res.json).toHaveBeenCalledWith({});
    });

    it('getAsync should return value when value is found', async() => {
        // Arrange
        const req: any = {
            user: { sub: "john.smith" },
            query: { subscriptionId: "123" },
        };
        const res: any = {
            status: jest.fn().mockReturnThis(),
            json: jest.fn(),
        };
        const value = { property1: "value1", property2: "value2" };
        _dynamodbMock.on(GetCommand).resolvesOnce({
            Item: {
                username: "john.smith",
                subscriptionId: "123",
                content: JSON.stringify(value),
                ttl: 0,
            },
        });

        // Act
        await uiStorageController.getAsync(req, res);

        // Assert
        expect(res.status).toHaveBeenCalledWith(HttpStatus.OK);
        expect(res.json).toHaveBeenCalledWith(value);
    });

    it('putAsync should create item when it does not exist', async() => {
        // Arrange
        const req: any = {
            user: { sub: "john.smith" },
            query: { subscriptionId: "123" },
            body: { property1: "value1", property2: "value2" },
        };
        const res: any = {
            status: jest.fn().mockReturnThis(),
            end: jest.fn(),
        };
        _dynamodbMock.on(GetCommand).resolvesOnce({
            Item: undefined,
        });
        let actualCommand;
        _dynamodbMock.on(PutCommand).callsFakeOnce(command => actualCommand = command);

        // Act
        await uiStorageController.putAsync(req, res);

        // Assert
        expect(actualCommand).toBeDefined();
        expect(actualCommand?.Item).toEqual(expect.objectContaining(
            {
                username: req.user.sub,
                subscriptionId: req.query.subscriptionId,
                content: JSON.stringify(req.body),
            }
        ));
        expect(res.status).toHaveBeenCalledWith(HttpStatus.NO_CONTENT);
    });

    it('putAsync should update item when it exists', async() => {
        // Arrange
        const req: any = {
            user: { sub: "john.smith" },
            query: { subscriptionId: "123" },
            body: { property1: "value1", property2: "value2" },
        };
        const res: any = {
            status: jest.fn().mockReturnThis(),
            end: jest.fn(),
        };
        _dynamodbMock.on(GetCommand).resolvesOnce({
            Item: {
                username: "john.smith",
                subscriptionId: "123",
                content: "something else",
                ttl: 0,
            },
        });
        let actualCommand;
        _dynamodbMock.on(UpdateCommand).callsFakeOnce(command => actualCommand = command);

        // Act
        await uiStorageController.putAsync(req, res);

        // Assert
        expect(actualCommand).toBeDefined();
        expect(actualCommand?.Key).toEqual(expect.objectContaining(
            {
                username: req.user.sub,
                subscriptionId: req.query.subscriptionId,
            }
        ));
        expect(actualCommand?.ExpressionAttributeValues).toEqual(expect.objectContaining(
            {
                ":content": JSON.stringify(req.body),
            }
        ));
        expect(res.status).toHaveBeenCalledWith(HttpStatus.NO_CONTENT);        
    });

    it('putAsync should save default value when the body is undefined', async() => {
        // Arrange
        const defaulValue = {};
        const req: any = {
            user: { sub: "john.smith" },
            query: { subscriptionId: "123" },
            body: undefined,
        };
        const res: any = {
            status: jest.fn().mockReturnThis(),
            end: jest.fn(),
        };
        _dynamodbMock.on(GetCommand).resolvesOnce({
            Item: undefined,
        });
        let actualCommand;
        _dynamodbMock.on(PutCommand).callsFakeOnce(command => actualCommand = command);

        // Act
        await uiStorageController.putAsync(req, res);

        // Assert
        expect(actualCommand).toBeDefined();
        expect(actualCommand?.Item).toEqual(expect.objectContaining(
            {
                username: req.user.sub,
                subscriptionId: req.query.subscriptionId,
                content: JSON.stringify(defaulValue),
            }
        ));
        expect(res.status).toHaveBeenCalledWith(HttpStatus.NO_CONTENT);        
    });
});
