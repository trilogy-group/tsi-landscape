import uiSubscriptionController, { AgreementStatusResponse, ApiAgreementStatus, ApiAgreementType } from "../src/api/controllers/UiSubscriptionController";
import NetsuiteClient from "../src/api/services/NetsuiteClient";
import { UserError } from "../src/common/errors";
import HttpStatus from 'http-status-codes';

describe('UiSubscriptionController', () => {

    beforeEach(() => {
        jest.clearAllMocks();
    });

    function getAgreementStatusAsyncMock(subscription?: any) {
        const req: any = {
            user: { cid: "1" },
            query: {},
            params: { subscriptionId: "123" },
        };
        const res: any = {
            status: jest.fn().mockReturnThis(),
            send: jest.fn(),
        };
        if (subscription) {
            jest.spyOn(NetsuiteClient, 'post').mockReturnValueOnce(
                Promise.resolve({ data: { content: subscription } })
            );
        }        
        return {
            req,
            actionAsync: async () => await uiSubscriptionController.getAgreementStatusAsync(req, res),
            expect: (response: AgreementStatusResponse) => {
                expect(res.status).toHaveBeenCalledWith(HttpStatus.OK);
                expect(res.send).toHaveBeenCalledWith(response);
            },
        };
    }

    it('getAgreementStatusAsync should throw error when the customer ID is missing', async () => {
        // Arrange
        const mock = getAgreementStatusAsyncMock();
        mock.req.user.cid = undefined;

        try {
            // Act
            await mock.actionAsync();
            fail();
        } catch (e) {
            // Assert
            expect(e).toBeInstanceOf(UserError);
            const userError = e as UserError;
            expect(userError.message).toBe("customerId is required");
        }
    });

    it('getAgreementStatusAsync should throw error when the subscription ID is missing', async () => {
        // Arrange
        const mock = getAgreementStatusAsyncMock();
        mock.req.params.subscriptionId = undefined;

        try {
            // Act
            await mock.actionAsync();
            fail();
        } catch (e) {
            // Assert
            expect(e).toBeInstanceOf(UserError);
            const userError = e as UserError;
            expect(userError.message).toBe("The query parameter 'subscriptionId' is required.");
        }
    });

    it('getAgreementStatusAsync should return no-quote when there is no quote', async () => {
        // Arrange
        const subscription = { quotes: [] };
        const mock = getAgreementStatusAsyncMock(subscription);

        // Act
        await mock.actionAsync();

        // Assert
        mock.expect(AgreementStatusResponse.NoQuote);
    });

    it('getAgreementStatusAsync should return no-agreement when there is no agreement', async () => {
        // Arrange
        const subscription = { quotes: [
            { isSelfServe: true },
            { isSelfServe: true, agreements: [] },
        ] };
        const mock = getAgreementStatusAsyncMock(subscription);

        // Act
        await mock.actionAsync();

        // Assert
        mock.expect(AgreementStatusResponse.NoAgreement);
    });

    it('getAgreementStatusAsync should return no-agreement when the agrement type or status is an unexpected value', async () => {
        // Arrange
        const subscription = { quotes: [
            { isSelfServe: true, agreements: [ { type: 'unexpected', status: ApiAgreementStatus.Draft } ] },
            { isSelfServe: true, agreements: [ { type: ApiAgreementType.Quote, status: 'unexpected' } ] },
        ] };
        const mock = getAgreementStatusAsyncMock(subscription);

        // Act
        await mock.actionAsync();

        // Assert
        mock.expect(AgreementStatusResponse.NoAgreement);
    });

    it('getAgreementStatusAsync should return signed when that is the most advanced agreeement status', async () => {
        // Arrange
        const subscription = { quotes: [
            { isSelfServe: true, agreements: [ { type: ApiAgreementType.Quote, status: ApiAgreementStatus.Draft } ] },
            { isSelfServe: true, agreements: [ { type: ApiAgreementType.Quote, status: ApiAgreementStatus.OutForSignature } ] },
            { isSelfServe: true, agreements: [ { type: ApiAgreementType.Quote, status: ApiAgreementStatus.Signed } ] },
        ] };
        const mock = getAgreementStatusAsyncMock(subscription);

        // Act
        await mock.actionAsync();

        // Assert
        mock.expect(AgreementStatusResponse.Signed);
    });

    it('getAgreementStatusAsync should return out-for-signature when that is the most advanced agreeement status', async () => {
        // Arrange
        const subscription = { quotes: [
            { isSelfServe: true, agreements: [ { type: ApiAgreementType.Quote, status: ApiAgreementStatus.Draft } ] },
            { isSelfServe: true, agreements: [ { type: ApiAgreementType.Quote, status: ApiAgreementStatus.OutForSignature } ] },
        ] };
        const mock = getAgreementStatusAsyncMock(subscription);

        // Act
        await mock.actionAsync();

        // Assert
        mock.expect(AgreementStatusResponse.OutForSignature);
    });

    it('getAgreementStatusAsync should return draft when that is the most advanced agreeement status', async () => {
        // Arrange
        const subscription = { quotes: [
            { isSelfServe: true, agreements: [ { type: ApiAgreementType.Quote, status: ApiAgreementStatus.Draft } ] },
        ] };
        const mock = getAgreementStatusAsyncMock(subscription);

        // Act
        await mock.actionAsync();

        // Assert
        mock.expect(AgreementStatusResponse.Draft);
    });

    it('getAgreementStatusAsync should return no-quote when there are only non-Self-Serve quotes', async () => {
        // Arrange
        const subscription = { quotes: [
            { isSelfServe: false, agreements: [ { type: ApiAgreementType.Quote, status: ApiAgreementStatus.Draft } ] },
            { isSelfServe: false, agreements: [ { type: ApiAgreementType.Quote, status: ApiAgreementStatus.OutForSignature } ] },
        ] };
        const mock = getAgreementStatusAsyncMock(subscription);

        // Act
        await mock.actionAsync();

        // Assert
        mock.expect(AgreementStatusResponse.NoQuote);
    });

    it('getAgreementStatusAsync should return most advanced agreement status for Self-Serve quotes when there are both (non-)Self-Serve quotes', async () => {
        // Arrange
        const subscription = { quotes: [
            { isSelfServe: true, agreements: [ { type: ApiAgreementType.Quote, status: ApiAgreementStatus.Draft } ] },
            { isSelfServe: false, agreements: [ { type: ApiAgreementType.Quote, status: ApiAgreementStatus.OutForSignature } ] },
        ] };
        const mock = getAgreementStatusAsyncMock(subscription);

        // Act
        await mock.actionAsync();

        // Assert
        mock.expect(AgreementStatusResponse.Draft);
    });

    it('getAgreementStatusAsync should return no-quote when the quote contains only Canceled agreements', async () => {
        // Arrange
        const subscription = { quotes: [
            { isSelfServe: true, agreements: [ { type: ApiAgreementType.Quote, status: ApiAgreementStatus.Cancelled } ] },
        ] };
        const mock = getAgreementStatusAsyncMock(subscription);

        // Act
        await mock.actionAsync();

        // Assert
        mock.expect(AgreementStatusResponse.NoQuote);
    });

    it('getAgreementStatusAsync should return most advanced agreement status when a quote contains a Canceled and another agreements', async () => {
        // Arrange
        const subscription = { quotes: [
            { isSelfServe: true, agreements: [
                { type: ApiAgreementType.Quote, status: ApiAgreementStatus.Cancelled },                    
                { type: ApiAgreementType.Quote, status: ApiAgreementStatus.Draft },
            ] },
        ] };
        const mock = getAgreementStatusAsyncMock(subscription);

        // Act
        await mock.actionAsync();

        // Assert
        mock.expect(AgreementStatusResponse.Draft);
    });
});
