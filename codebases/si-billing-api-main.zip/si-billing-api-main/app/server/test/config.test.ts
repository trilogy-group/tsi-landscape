import { GetParameterCommand, SSMClient, SSMClientResolvedConfig, ServiceInputTypes, ServiceOutputTypes } from '@aws-sdk/client-ssm';
import { AwsStub, mockClient } from 'aws-sdk-client-mock';
import config from '../src/common/config';
import { fail } from 'assert';

describe('config', () => {
    let _ssmMock: AwsStub<ServiceInputTypes, ServiceOutputTypes, SSMClientResolvedConfig>;

    beforeAll(() => {
        _ssmMock = mockClient(SSMClient);
    });

    beforeEach(() => {
        _ssmMock.reset();
        jest.resetAllMocks();
    });

    it('getSsmParameterValueAsync should throw an error when the SSM parameter is missing', async () => {
        // Arrange
        const name = "missing-parameter";
        _ssmMock.on(GetParameterCommand).resolves({
            Parameter: undefined,
        });

        try {
            // Act
            await config.getSsmParameterValueAsync(name);
            fail();
        } catch (e) {
            // Assert
            expect(e).toBeInstanceOf(Error);
            const error = e as Error;
            expect(error.message).toBe(`Missing SSM parameter '${name}'.`);
        }
    });

    it('getSsmParameterValueAsync should return the parameter value', async () => {
        // Arrange
        const name = "paramater-1";
        const parameter = {
            Value: "value-1",
        };
        _ssmMock.on(GetParameterCommand).resolves({
            Parameter: parameter,
        });

        // Act
        const result = await config.getSsmParameterValueAsync(name);

        // Assert
        expect(result).toBe(parameter.Value);
    });

    it('getSsmParameterValueAsResultAsync should throw an error when the parameter value is not a JSON', async () => {
        // Arrange
        const name = "paramater-1";
        const value = "not-a-json";
        jest.spyOn(config, 'getSsmParameterValueAsync').mockResolvedValueOnce(value);

        try {
            // Act
            await config.getSsmParameterValueAsResultAsync(name);
            fail();
        } catch (e) {
            // Assert
            expect(e).toBeInstanceOf(Error);
            const error = e as Error;
            expect(error.message).toBe('Invalid SSM parameter. Expect JSON.');
        }
    });

    it('getSsmParameterValueAsResultAsync should return the parameter value as a dictionary', async () => {
        // Arrange
        const name = "paramater-1";
        const dic = {
            prop1: "value-1",
            prop2: "value2",
        }
        const json = JSON.stringify(dic);
        jest.spyOn(config, 'getSsmParameterValueAsync').mockResolvedValueOnce(json);
        
        // Act
        const result = await config.getSsmParameterValueAsResultAsync<Record<string, string>>(name);

        // Assert
        expect(result).toMatchObject(dic);
    });

    it('loadAsync should load the config parameters', async () => {
        // Arrange
        process.env.NS_ENV_NAME = 'sb';
        const ssmParameters = {
            'ns-sb-consumer-key': 'fake-consumer-key',
            'ns-sb-consumer-secret': 'fake-consumer-secret',
            'ns-sb-token-key': 'fake-token-key',
            'ns-sb-token-secret': 'fake-token-secret',
            'ns-sb-realm': 'fale-realm',
            'ns-sb-rest-api-base-url': 'fake-rest-api-base-url',
            'ns-sb-restlet-base-url': 'fake-restlet-base-url',
            'self-serve-portal-product-emails': JSON.stringify({product: 'fake-email'}),
            'self-serve-portal-support-config': JSON.stringify({sender: 'fake-email-1', recipient: 'fake-email-2', subject: 'fake-subject'}),
        };
        jest.spyOn(config, 'getSsmParameterValueAsync').mockImplementation((name: string) => {
            return Promise.resolve(ssmParameters[name]);
        });

        // Act
        await config.loadAsync();

        // Assert
        expect(config.nsClientConsumerKey).toBe(ssmParameters['ns-sb-consumer-key']);
        expect(config.nsClientConsumerSecret).toBe(ssmParameters['ns-sb-consumer-secret']);
        expect(config.nsClientTokenKey).toBe(ssmParameters['ns-sb-token-key']);
        expect(config.nsClientTokenSecret).toBe(ssmParameters['ns-sb-token-secret']);
        expect(config.nsClientRealm).toBe(ssmParameters['ns-sb-realm']);
        expect(config.nsClientRestApiBaseUrl).toBe(ssmParameters['ns-sb-rest-api-base-url']);
        expect(config.nsClientRestletBaseUrl).toBe(ssmParameters['ns-sb-restlet-base-url']);
        expect(config.sspProductEmails).toMatchObject(JSON.parse(ssmParameters['self-serve-portal-product-emails']));
        expect(config.sspSupportConfig).toMatchObject(JSON.parse(ssmParameters['self-serve-portal-support-config']));
    });
});