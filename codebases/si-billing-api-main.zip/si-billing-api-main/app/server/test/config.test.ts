import { GetParameterCommand, SSMClient, SSMClientResolvedConfig, ServiceInputTypes, ServiceOutputTypes } from '@aws-sdk/client-ssm';
import { AwsStub, mockClient } from 'aws-sdk-client-mock';
import config from '../src/common/config';
import { fail } from 'assert';

describe('config', () => {
    let _ssmMock: AwsStub<ServiceInputTypes, ServiceOutputTypes, SSMClientResolvedConfig>;

    beforeAll(() => {
        _ssmMock = mockClient(SSMClient);
    });

    beforeEach(() => {
        _ssmMock.reset();
        jest.resetAllMocks();
    });

    it('getSsmParameterValueAsync should throw an error when the SSM parameter is missing', async () => {
        // Arrange
        const name = "missing-parameter";
        _ssmMock.on(GetParameterCommand).resolves({
            Parameter: undefined,
        });

        try {
            // Act
            await config.getSsmParameterValueAsync(name);
            fail();
        } catch (e) {
            // Assert
            expect(e).toBeInstanceOf(Error);
            const error = e as Error;
            expect(error.message).toBe(`Missing SSM parameter '${name}'.`);
        }
    });

    it('getSsmParameterValueAsync should return the parameter value', async () => {
        // Arrange
        const name = "paramater-1";
        const parameter = {
            Value: "value-1",
        };
        _ssmMock.on(GetParameterCommand).resolves({
            Parameter: parameter,
        });

        // Act
        const result = await config.getSsmParameterValueAsync(name);

        // Assert
        expect(result).toBe(parameter.Value);
    });

    it('getSsmParameterValueAsResultAsync should throw an error when the parameter value is not a JSON', async () => {
        // Arrange
        const name = "paramater-1";
        const value = "not-a-json";
        jest.spyOn(config, 'getSsmParameterValueAsync').mockResolvedValueOnce(value);

        try {
            // Act
            await config.getSsmParameterValueAsResultAsync(name);
            fail();
        } catch (e) {
            // Assert
            expect(e).toBeInstanceOf(Error);
            const error = e as Error;
            expect(error.message).toBe('Invalid SSM parameter. Expect JSON.');
        }
    });

    it('getSsmParameterValueAsResultAsync should return the parameter value as a dictionary', async () => {
        // Arrange
        const name = "paramater-1";
        const dic = {
            prop1: "value-1",
            prop2: "value2",
        }
        const json = JSON.stringify(dic);
        jest.spyOn(config, 'getSsmParameterValueAsync').mockResolvedValueOnce(json);
        
        // Act
        const result = await config.getSsmParameterValueAsResultAsync<Record<string, string>>(name);

        // Assert
        expect(result).toMatchObject(dic);
    });

    it('loadAsync should load the config parameters', async () => {
        // Arrange
        process.env.NS_ENV_NAME = 'sb';
        const ssmParameters = {
            'ns-sb-consumer-key': 'fake-consumer-key',
            'ns-sb-consumer-secret': 'fake-consumer-secret',
            'ns-sb-token-key': 'fake-token-key',
            'ns-sb-token-secret': 'fake-token-secret',
            'ns-sb-realm': 'fale-realm',
            'ns-sb-rest-api-base-url': 'fake-rest-api-base-url',
            'ns-sb-restlet-base-url': 'fake-restlet-base-url',
            'self-serve-portal-product-emails': JSON.stringify({product: 'fake-email'}),
            'self-serve-portal-support-config': JSON.stringify({sender: 'fake-email-1', recipient: 'fake-email-2', subject: 'fake-subject'}),
        };
        jest.spyOn(config, 'getSsmParameterValueAsync').mockImplementation((name: string) => {
            return Promise.resolve(ssmParameters[name]);
        });

        // Act
        await config.loadAsync();

        // Assert
        expect(config.nsClientConsumerKey).toBe(ssmParameters['ns-sb-consumer-key']);
        expect(config.nsClientConsumerSecret).toBe(ssmParameters['ns-sb-consumer-secret']);
        expect(config.nsClientTokenKey).toBe(ssmParameters['ns-sb-token-key']);
        expect(config.nsClientTokenSecret).toBe(ssmParameters['ns-sb-token-secret']);
        expect(config.nsClientRealm).toBe(ssmParameters['ns-sb-realm']);
        expect(config.nsClientRestApiBaseUrl).toBe(ssmParameters['ns-sb-rest-api-base-url']);
        expect(config.nsClientRestletBaseUrl).toBe(ssmParameters['ns-sb-restlet-base-url']);
        expect(config.sspProductEmails).toMatchObject(JSON.parse(ssmParameters['self-serve-portal-product-emails']));
        expect(config.sspSupportConfig).toMatchObject(JSON.parse(ssmParameters['self-serve-portal-support-config']));
    });

    it('loadSync should load the config parameters synchronously', () => {
        // Arrange
        process.env.AWS_REGION = 'us-west-2';
        process.env.AWS_SES_SENDER = 'sender@example.com';
        process.env.AWS_TABLE_UI_STORAGE = 'ui-storage-table';
        process.env.NS_CUSTOM_VERSION_ALLOWED = 'true';
        process.env.NS_VERSION = 'v1';
        process.env.USE_ENV_CREDENTIALS = 'true';
        process.env.NS_CONSUMER_KEY = 'consumer-key';
        process.env.NS_CONSUMER_SECRET = 'consumer-secret';
        process.env.NS_TOKEN_KEY = 'token-key';
        process.env.NS_TOKEN_SECRET = 'token-secret';
        process.env.NS_CLIENT_REALM = 'client-realm';
        process.env.NS_CLIENT_REST_API_BASE_URL = 'https://api.example.com';
        process.env.NS_CLIENT_RESTLET_BASE_URL = 'https://restlet.example.com';

        const configPrototype = Object.getPrototypeOf(config);
        // Act
        configPrototype.loadSync();

        // Assert
        expect(configPrototype.awsRegion).toBe('us-west-2');
        expect(configPrototype.awsSesSender).toBe('sender@example.com');
        expect(configPrototype.awsTableUiStorage).toBe('ui-storage-table');
        expect(configPrototype.nsCustomVersionAllowed).toBe(true);
        expect(configPrototype.nsDefaultVersion).toBe('v1');
        expect(configPrototype.nsClientConsumerKey).toBe('consumer-key');
        expect(configPrototype.nsClientConsumerSecret).toBe('consumer-secret');
        expect(configPrototype.nsClientTokenKey).toBe('token-key');
        expect(configPrototype.nsClientTokenSecret).toBe('token-secret');
        expect(configPrototype.nsClientRealm).toBe('client-realm');
        expect(configPrototype.nsClientRestApiBaseUrl).toBe('https://api.example.com');
        expect(configPrototype.nsClientRestletBaseUrl).toBe('https://restlet.example.com');
    });
});