import * as errorHandler from '../src/api/middlewares/error.handler';
import { getMockReq, getMockRes } from '@jest-mock/express';

describe('error.handler', () => {
  it('invalid jwt token', async () => {
    const err = { status: 401, message: 'invalid signature' };
    let res = getMockRes();
    errorHandler.default(err, getMockReq(), res.res, res.next);
    expect(err.message).toStrictEqual('Invalid JWT token signature');
  });

  it('timeout', async () => {
    const err = { status: 503, message: 'Response timeout' };
    let res = getMockRes();
    errorHandler.default(err, getMockReq(), res.res, res.next);
    expect(err.message).toStrictEqual(
      'Your request is processing, check back in one minute to see if your request has been fulfilled'
    );
  });

  it('any error', async () => {
    const err: any = { message: 'error without status' };
    const res = getMockRes();
    errorHandler.default(err, getMockReq(), res.res, res.next);
    expect(res.res.status).lastCalledWith(500);
  });
});
