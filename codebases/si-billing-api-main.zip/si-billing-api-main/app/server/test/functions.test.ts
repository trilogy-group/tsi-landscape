import { checkPrices } from '../e2e/helper/Functions';

describe('E2eFunctions', () => {
  it('checkPrices', async () => {
    const params = {
      planCode: 'DNNE Customer EVOQ BASIC DiffAddon',
      subscriptionItems: [
        {
          id: 84626,
          code: 'DNNE-SA-Cus-BAS',
          title: 'DNNE Customer Cloud EVOQ Basic',
          type: 'Recurring',
          typeId: 2,
          required: true,
          prices: [
            {
              type: 'Volume',
              frequency: 'ANNUALLY',
              currency: 'USD',
              pricebookid: 12460,
              ranges: [
                {
                  priceplanid: 4783736,
                  type: 'Rate',
                  fromQuantity: 0,
                  price: 22,
                },
              ],
            },
          ],
          amount: 44,
          productTier: 'Standard',
          revenueType: 'SaaS',
        },
        {
          id: 86580,
          code: 'DNNE-SA-Add2-BAS',
          title: 'DNNE Addon',
          type: 'Recurring',
          typeId: 2,
          required: false,
          prices: [
            {
              type: 'Volume',
              frequency: 'ANNUALLY',
              currency: 'USD',
              pricebookid: 12460,
              ranges: [
                {
                  priceplanid: 4783738,
                  type: 'Rate',
                  fromQuantity: 0,
                  price: 20,
                },
              ],
            },
          ],
          amount: 20,
          revenueType: 'SaaS',
        },
      ],
      discount: {
        mainDiscount: 0,
        addons: [
          {
            code: 'DNNE-SA-Add2-BAS',
            discount: 0,
          },
        ],
      },
      subscriptionPlans: [
        {
          _ns_displayname: 'DNNE-SA-Cus-BAS-SIL',
          isTrial: false,
          code: 'DNNE Customer Cloud EVOQ BASIC',
          id: 84641,
          product: {
            family: {
              code: 'DNNE',
              title: 'DNNE',
            },
            variant: {
              title: 'SaaS',
              code: 'SA-Cus',
            },
          },
          initialterm: {
            name: 'Annual - 1 Year',
            unit: 'MONTHS',
            duration: 12,
            type: 'STANDARD',
          },
          supportLevel: 'Silver',
          supportOnly: false,
          items: [
            {
              id: 84626,
              code: 'DNNE-SA-Cus-BAS',
              title: 'DNNE Customer Cloud EVOQ Basic',
              required: true,
              type: 'Recurring',
              typeId: 2,
              prices: [
                {
                  type: 'Volume',
                  frequency: 'ANNUALLY',
                  currency: 'USD',
                  pricebookid: 10611,
                  ranges: [
                    {
                      priceplanid: 4640274,
                      type: 'Rate',
                      fromQuantity: 0,
                      price: 10,
                    },
                    {
                      priceplanid: 4640274,
                      type: 'Rate',
                      fromQuantity: 10,
                      price: 9,
                    },
                  ],
                },
                {
                  type: 'Volume',
                  frequency: 'MONTHLY',
                  currency: 'USD',
                  pricebookid: 10612,
                  ranges: [
                    {
                      priceplanid: 4640275,
                      type: 'Rate',
                      fromQuantity: 0,
                      price: 1,
                    },
                    {
                      priceplanid: 4640275,
                      type: 'Rate',
                      fromQuantity: 10,
                      price: 0.9,
                    },
                  ],
                },
              ],
            },
          ],
          productTier: 'Standard',
          productTierTitle: 'Standard',
          revenueType: 'SaaS',
        },
        {
          _ns_displayname: 'DNNE-SA-Cus-PRO-SIL',
          isTrial: false,
          code: 'DNNE Cloud EVOQ CONTENT',
          id: 84642,
          product: {
            family: {
              code: 'DNNE',
              title: 'DNNE',
            },
            variant: {
              title: 'SaaS',
              code: 'SA-Cus',
            },
          },
          initialterm: {
            name: 'Annual - 1 Year',
            unit: 'MONTHS',
            duration: 12,
            type: 'STANDARD',
          },
          supportLevel: 'Silver',
          supportOnly: false,
          items: [
            {
              id: 84628,
              code: 'DNNE-SA-Cus-PRO',
              title: 'DNNE Customer Cloud EVOQ Content',
              required: true,
              type: 'Recurring',
              typeId: 2,
              prices: [
                {
                  type: 'Volume',
                  frequency: 'ANNUALLY',
                  currency: 'USD',
                  pricebookid: 10613,
                  ranges: [
                    {
                      priceplanid: 4612893,
                      type: 'Rate',
                      fromQuantity: 0,
                      price: 20,
                    },
                  ],
                },
              ],
            },
          ],
          productTier: 'Professional',
          productTierTitle: 'Engage',
          revenueType: 'SaaS',
        },
        {
          _ns_displayname: 'DNNE-SA-Cus-PRO-GOL',
          isTrial: false,
          code: 'DNNE Cloud EVOQ CONTENT GOLD',
          id: 84643,
          product: {
            family: {
              code: 'DNNE',
              title: 'DNNE',
            },
            variant: {
              title: 'SaaS',
              code: 'SA-Cus',
            },
          },
          initialterm: {
            name: 'Annual - 1 Year',
            unit: 'MONTHS',
            duration: 12,
            type: 'STANDARD',
          },
          supportLevel: 'Gold',
          supportOnly: false,
          items: [
            {
              id: 84628,
              code: 'DNNE-SA-Cus-PRO',
              title: 'DNNE Customer Cloud EVOQ Content',
              required: true,
              type: 'Recurring',
              typeId: 2,
              prices: [
                {
                  type: 'Volume',
                  frequency: 'ANNUALLY',
                  currency: 'USD',
                  pricebookid: 10614,
                  ranges: [
                    {
                      priceplanid: 4612895,
                      type: 'Rate',
                      fromQuantity: 0,
                      price: 20,
                    },
                  ],
                },
              ],
            },
          ],
          productTier: 'Professional',
          productTierTitle: 'Engage',
          revenueType: 'SaaS',
        },
        {
          _ns_displayname: 'DNNE-SA-Cus-CON-PLA',
          isTrial: false,
          code: 'DNNE Cloud EVOQ CONTENT PLATINUM',
          id: 84644,
          product: {
            family: {
              code: 'DNNE',
              title: 'DNNE',
            },
            variant: {
              title: 'SaaS',
              code: 'SA-Cus',
            },
          },
          initialterm: {
            name: 'Annual - 1 Year',
            unit: 'MONTHS',
            duration: 12,
            type: 'STANDARD',
          },
          supportLevel: 'Platinum',
          supportOnly: false,
          items: [
            {
              id: 84628,
              code: 'DNNE-SA-Cus-CON',
              title: 'DNNE Customer Cloud EVOQ Content',
              required: true,
              type: 'Recurring',
              typeId: 2,
              prices: [
                {
                  type: 'Volume',
                  frequency: 'ANNUALLY',
                  currency: 'USD',
                  pricebookid: 10615,
                  ranges: [
                    {
                      priceplanid: 4612897,
                      type: 'Rate',
                      fromQuantity: 0,
                      price: 20,
                    },
                  ],
                },
              ],
            },
          ],
          productTier: 'Professional',
          productTierTitle: 'Engage',
          revenueType: 'SaaS',
        },
        {
          _ns_displayname: 'DNNE-SA-Cus-ENG-SIL',
          isTrial: false,
          code: 'DNNE Customer Cloud EVOQ ENGAGE',
          id: 84645,
          product: {
            family: {
              code: 'DNNE',
              title: 'DNNE',
            },
            variant: {
              title: 'SaaS',
              code: 'SA-Cus',
            },
          },
          initialterm: {
            name: 'Annual - 1 Year',
            unit: 'MONTHS',
            duration: 12,
            type: 'STANDARD',
          },
          supportLevel: 'Silver',
          supportOnly: false,
          items: [
            {
              id: 84631,
              code: 'DNNE-SA-Cus-ENG',
              title: 'DNNE Customer Cloud EVOQ Engage',
              required: true,
              type: 'Recurring',
              typeId: 2,
              prices: [
                {
                  type: 'Volume',
                  frequency: 'ANNUALLY',
                  currency: 'USD',
                  pricebookid: 10616,
                  ranges: [
                    {
                      priceplanid: 4612899,
                      type: 'Rate',
                      fromQuantity: 0,
                      price: 30,
                    },
                  ],
                },
              ],
            },
          ],
          productTier: 'Enterprise',
          productTierTitle: 'Growth',
          revenueType: 'SaaS',
        },
        {
          _ns_displayname: 'DNNE-SA-Cus-ENG-PLA',
          isTrial: false,
          code: 'DNNE Customer Cloud EVOQ ENGAGE PLATINUM',
          id: 84646,
          product: {
            family: {
              code: 'DNNE',
              title: 'DNNE',
            },
            variant: {
              title: 'SaaS',
              code: 'SA-Cus',
            },
          },
          initialterm: {
            name: 'Annual - 1 Year',
            unit: 'MONTHS',
            duration: 12,
            type: 'STANDARD',
          },
          supportLevel: 'Platinum',
          supportOnly: false,
          items: [
            {
              id: 84631,
              code: 'DNNE-SA-Cus-ENG',
              title: 'DNNE Customer Cloud EVOQ Engage',
              required: true,
              type: 'Recurring',
              typeId: 2,
              prices: [
                {
                  type: 'Volume',
                  frequency: 'ANNUALLY',
                  currency: 'USD',
                  pricebookid: 10617,
                  ranges: [
                    {
                      priceplanid: 4612901,
                      type: 'Rate',
                      fromQuantity: 0,
                      price: 30,
                    },
                  ],
                },
              ],
            },
          ],
          productTier: 'Enterprise',
          productTierTitle: 'Growth',
          revenueType: 'SaaS',
        },
        {
          _ns_displayname: 'DNNE-SA-Cus-BAS-SIL',
          isTrial: false,
          code: 'DNNE Customer EVOQ BASIC Addon',
          id: 84650,
          product: {
            family: {
              code: 'DNNE',
              title: 'DNNE',
            },
            variant: {
              title: 'SaaS',
              code: 'SA-Cus',
            },
          },
          initialterm: {
            name: 'Annual - 1 Year',
            unit: 'MONTHS',
            duration: 12,
            type: 'STANDARD',
          },
          supportLevel: 'Silver',
          supportOnly: false,
          items: [
            {
              id: 84626,
              code: 'DNNE-SA-Cus-BAS',
              title: 'DNNE Customer Cloud EVOQ Basic',
              required: true,
              type: 'Recurring',
              typeId: 2,
              prices: [
                {
                  type: 'Volume',
                  frequency: 'ANNUALLY',
                  currency: 'USD',
                  pricebookid: 10621,
                  ranges: [
                    {
                      priceplanid: 4612909,
                      type: 'Rate',
                      fromQuantity: 0,
                      price: 12,
                    },
                  ],
                },
              ],
            },
            {
              id: 84636,
              code: 'DNNE-SA-Add-BAS',
              title: 'DNNE Addon',
              required: false,
              type: 'Recurring',
              typeId: 2,
              prices: [
                {
                  type: 'Volume',
                  frequency: 'ANNUALLY',
                  currency: 'USD',
                  pricebookid: 10621,
                  ranges: [
                    {
                      priceplanid: 4612911,
                      type: 'Rate',
                      fromQuantity: 0,
                      price: 15,
                    },
                  ],
                },
              ],
            },
          ],
          productTier: 'Standard',
          productTierTitle: 'Standard',
          revenueType: 'SaaS',
        },
        {
          _ns_displayname: 'DNNE-SA-Cus-BAS-SIL',
          isTrial: false,
          code: 'DNNE Customer Cloud EVOQ Evergreen',
          id: 84652,
          product: {
            family: {
              code: 'DNNE',
              title: 'DNNE',
            },
            variant: {
              title: 'SaaS',
              code: 'SA-Cus',
            },
          },
          initialterm: {
            name: 'Evergreen Term',
            type: 'EVERGREEN',
          },
          supportOnly: false,
          items: [
            {
              id: 84626,
              code: 'DNNE-SA-Cus-BAS',
              title: 'DNNE Customer Cloud EVOQ Basic',
              required: true,
              type: 'Recurring',
              typeId: 2,
              prices: [
                {
                  type: 'Tiered',
                  frequency: 'ANNUALLY',
                  currency: 'USD',
                  pricebookid: 10623,
                  ranges: [
                    {
                      priceplanid: 4692511,
                      type: 'Rate',
                      fromQuantity: 0,
                      price: 12,
                    },
                  ],
                },
                {
                  type: 'Tiered',
                  frequency: 'MONTHLY',
                  currency: 'USD',
                  pricebookid: 10821,
                  ranges: [
                    {
                      priceplanid: 4621933,
                      type: 'Rate',
                      fromQuantity: 0,
                      price: 1,
                    },
                  ],
                },
              ],
            },
          ],
          productTier: 'Standard',
          productTierTitle: 'Standard',
          revenueType: 'SaaS',
        },
        {
          _ns_displayname: 'DNNE-SA-Cus-BAS-Gold',
          isTrial: false,
          code: 'DNNE Cloud EVOQ BASIC Gold',
          id: 84653,
          product: {
            family: {
              code: 'DNNE',
              title: 'DNNE',
            },
            variant: {
              title: 'SaaS',
              code: 'SA-Cus',
            },
          },
          initialterm: {
            name: 'Annual - 1 Year',
            unit: 'MONTHS',
            duration: 12,
            type: 'STANDARD',
          },
          supportLevel: 'Gold',
          supportOnly: false,
          items: [
            {
              id: 84626,
              code: 'DNNE-SA-Cus-BAS',
              title: 'DNNE Customer Cloud EVOQ Basic',
              required: true,
              type: 'Recurring',
              typeId: 2,
              prices: [
                {
                  type: 'Volume',
                  frequency: 'ANNUALLY',
                  currency: 'USD',
                  pricebookid: 10624,
                  ranges: [
                    {
                      priceplanid: 4612917,
                      type: 'Rate',
                      fromQuantity: 0,
                      price: 25,
                    },
                  ],
                },
                {
                  type: 'Tiered',
                  frequency: 'MONTHLY',
                  currency: 'USD',
                  pricebookid: 10820,
                  ranges: [
                    {
                      priceplanid: 4621530,
                      type: 'Rate',
                      fromQuantity: 0,
                      price: 1,
                    },
                  ],
                },
              ],
            },
            {
              id: 84636,
              code: 'DNNE-SA-Add-BAS',
              title: 'DNNE Addon',
              required: false,
              type: 'Recurring',
              typeId: 2,
              prices: [
                {
                  type: 'Volume',
                  frequency: 'ANNUALLY',
                  currency: 'USD',
                  pricebookid: 10624,
                  ranges: [
                    {
                      priceplanid: 4612919,
                      type: 'Rate',
                      fromQuantity: 0,
                      price: 20,
                    },
                  ],
                },
                {
                  type: 'Tiered',
                  frequency: 'MONTHLY',
                  currency: 'USD',
                  pricebookid: 10820,
                  ranges: [
                    {
                      priceplanid: 4621532,
                      type: 'Rate',
                      fromQuantity: 0,
                      price: 1,
                    },
                  ],
                },
              ],
            },
          ],
          productTier: 'Standard',
          productTierTitle: 'Standard',
          revenueType: 'SaaS',
        },
        {
          _ns_displayname: 'DNNE-SA-Cus-BAS-Add3',
          isTrial: false,
          code: 'DNNE Customer EVOQ BASIC Addon 3',
          id: 86680,
          product: {
            family: {
              code: 'DNNE',
              title: 'DNNE',
            },
            variant: {
              title: 'SaaS',
              code: 'SA-Cus',
            },
          },
          initialterm: {
            name: 'Annual - 1 Year',
            unit: 'MONTHS',
            duration: 12,
            type: 'STANDARD',
          },
          supportLevel: 'Silver',
          supportOnly: false,
          items: [
            {
              id: 84626,
              code: 'DNNE-SA-Cus-BAS',
              title: 'DNNE Customer Cloud EVOQ Basic',
              required: true,
              type: 'Recurring',
              typeId: 2,
              prices: [
                {
                  type: 'Tiered',
                  frequency: 'ANNUALLY',
                  currency: 'USD',
                  pricebookid: 12459,
                  ranges: [
                    {
                      priceplanid: 4778598,
                      type: 'Rate',
                      fromQuantity: 0,
                      price: 30,
                    },
                  ],
                },
              ],
            },
            {
              id: 84636,
              code: 'DNNE-SA-Add-BAS',
              title: 'DNNE Addon',
              required: false,
              type: 'Recurring',
              typeId: 2,
              prices: [
                {
                  type: 'Tiered',
                  frequency: 'ANNUALLY',
                  currency: 'USD',
                  pricebookid: 12459,
                  ranges: [
                    {
                      priceplanid: 4778600,
                      type: 'Rate',
                      fromQuantity: 0,
                      price: 15,
                    },
                  ],
                },
              ],
            },
            {
              id: 86580,
              code: 'DNNE-SA-Add2-BAS',
              title: 'DNNE Addon',
              required: false,
              type: 'Recurring',
              typeId: 2,
              prices: [
                {
                  type: 'Tiered',
                  frequency: 'ANNUALLY',
                  currency: 'USD',
                  pricebookid: 12459,
                  ranges: [
                    {
                      priceplanid: 4778601,
                      type: 'Rate',
                      fromQuantity: 0,
                      price: 25,
                    },
                  ],
                },
              ],
            },
          ],
          productTier: 'Standard',
          productTierTitle: 'Standard',
          revenueType: 'SaaS',
        },
        {
          _ns_displayname: 'DNNE-SA-Cus-STA-SUP-002',
          isTrial: false,
          code: 'DNNE Support Plan',
          id: 85976,
          product: {
            family: {
              code: 'DNNE',
              title: 'DNNE',
            },
            variant: {
              title: 'SaaS',
              code: 'SA-Cus',
            },
          },
          initialterm: {
            name: 'Annual - 1 Year',
            unit: 'MONTHS',
            duration: 12,
            type: 'STANDARD',
          },
          supportLevel: 'Silver',
          supportOnly: true,
          items: [
            {
              id: 84627,
              code: 'DNNE-SA-Cus-SIL',
              title: 'DNNE Silver Support',
              supportLevel: 'Silver',
              required: true,
              type: 'Recurring',
              typeId: 2,
              prices: [
                {
                  type: 'Tiered',
                  frequency: 'MONTHLY',
                  currency: 'USD',
                  pricebookid: 11855,
                  ranges: [
                    {
                      priceplanid: 4694542,
                      type: 'Rate',
                      fromQuantity: 0,
                      price: 25,
                    },
                  ],
                },
              ],
            },
            {
              id: 84636,
              code: 'DNNE-SA-Add-BAS',
              title: 'DNNE Addon',
              required: false,
              type: 'Recurring',
              typeId: 2,
              prices: [
                {
                  type: 'Tiered',
                  frequency: 'MONTHLY',
                  currency: 'USD',
                  pricebookid: 11855,
                  ranges: [
                    {
                      priceplanid: 4694543,
                      type: 'Rate',
                      fromQuantity: 0,
                      price: 12,
                    },
                  ],
                },
              ],
            },
          ],
          productTier: 'Standard',
          productTierTitle: 'Standard',
          revenueType: 'SaaS',
        },
        {
          _ns_displayname: 'DNNE-SA-Cus-BAS-GOL',
          isTrial: false,
          code: 'DNNE Cloud EVOQ BASIC Gold Strange',
          id: 85977,
          product: {
            family: {
              code: 'DNNE',
              title: 'DNNE',
            },
            variant: {
              title: 'SaaS',
              code: 'SA-Cus',
            },
          },
          initialterm: {
            name: 'Annual - 1 Year',
            unit: 'MONTHS',
            duration: 12,
            type: 'STANDARD',
          },
          supportLevel: 'Gold',
          supportOnly: false,
          items: [
            {
              id: 84626,
              code: 'DNNE-SA-Cus-BAS',
              title: 'DNNE Customer Cloud EVOQ Basic',
              required: true,
              type: 'Recurring',
              typeId: 2,
              prices: [
                {
                  type: 'Volume',
                  frequency: 'ANNUALLY',
                  currency: 'USD',
                  pricebookid: 11856,
                  ranges: [
                    {
                      priceplanid: 4696361,
                      type: 'Rate',
                      fromQuantity: 0,
                      price: 25,
                    },
                  ],
                },
              ],
            },
            {
              id: 84636,
              code: 'DNNE-SA-Add-BAS',
              title: 'DNNE Addon',
              required: false,
              type: 'Recurring',
              typeId: 2,
              prices: [
                {
                  type: 'Volume',
                  frequency: 'ANNUALLY',
                  currency: 'USD',
                  pricebookid: 11856,
                  ranges: [
                    {
                      priceplanid: 4696363,
                      type: 'Rate',
                      fromQuantity: 0,
                      price: 20,
                    },
                  ],
                },
              ],
            },
          ],
          productTier: 'Standard',
          productTierTitle: 'Standard',
          revenueType: 'SaaS',
        },
        {
          _ns_displayname: 'DNNE-SA-CusEG-PRO-SIL-001',
          isTrial: false,
          code: 'DNNE Customer Cloud EVOQ Evergreen Professional',
          id: 85774,
          product: {
            family: {
              code: 'DNNE',
              title: 'DNNE',
            },
            variant: {
              title: 'SaaS',
              code: 'SA-Cus',
            },
          },
          initialterm: {
            name: 'Evergreen Term',
            type: 'EVERGREEN',
          },
          supportOnly: false,
          items: [
            {
              id: 84628,
              code: 'DNNE-SA-Cus-PRO',
              title: 'DNNE Customer Cloud EVOQ Content',
              required: true,
              type: 'Recurring',
              typeId: 2,
              prices: [
                {
                  type: 'Tiered',
                  frequency: 'MONTHLY',
                  currency: 'USD',
                  pricebookid: 11553,
                  ranges: [
                    {
                      priceplanid: 4675484,
                      type: 'Rate',
                      fromQuantity: 0,
                      price: 2,
                    },
                  ],
                },
              ],
            },
          ],
          productTier: 'Professional',
          productTierTitle: 'Engage',
          revenueType: 'SaaS',
        },
        {
          _ns_displayname: 'DNNE-SA-Cus-STA-SIL-MNT-001',
          isTrial: false,
          code: 'DNNE Std Silver Sup',
          id: 86077,
          product: {
            family: {
              code: 'DNNE',
              title: 'DNNE',
            },
            variant: {
              title: 'SaaS',
              code: 'SA-Cus',
            },
          },
          initialterm: {
            name: 'Annual - 1 Year',
            unit: 'MONTHS',
            duration: 12,
            type: 'STANDARD',
          },
          supportLevel: 'Silver',
          supportOnly: true,
          items: [
            {
              id: 84627,
              code: 'DNNE-SA-Cus-SIL',
              title: 'DNNE Silver Support',
              supportLevel: 'Silver',
              required: true,
              type: 'Recurring',
              typeId: 2,
              prices: [
                {
                  type: 'Volume',
                  frequency: 'ANNUALLY',
                  currency: 'USD',
                  pricebookid: 11956,
                  ranges: [
                    {
                      priceplanid: 4702673,
                      type: 'Rate',
                      fromQuantity: 0,
                      price: 30,
                    },
                  ],
                },
                {
                  type: 'Volume',
                  frequency: 'MONTHLY',
                  currency: 'USD',
                  pricebookid: 11957,
                  ranges: [
                    {
                      priceplanid: 4702677,
                      type: 'Rate',
                      fromQuantity: 0,
                      price: 35,
                    },
                  ],
                },
              ],
            },
            {
              id: 84636,
              code: 'DNNE-SA-Add-BAS',
              title: 'DNNE Addon',
              required: false,
              type: 'Recurring',
              typeId: 2,
              prices: [
                {
                  type: 'Volume',
                  frequency: 'ANNUALLY',
                  currency: 'USD',
                  pricebookid: 11956,
                  ranges: [
                    {
                      priceplanid: 4702674,
                      type: 'Rate',
                      fromQuantity: 0,
                      price: 15,
                    },
                  ],
                },
                {
                  type: 'Volume',
                  frequency: 'MONTHLY',
                  currency: 'USD',
                  pricebookid: 11957,
                  ranges: [
                    {
                      priceplanid: 4702678,
                      type: 'Rate',
                      fromQuantity: 0,
                      price: 20,
                    },
                  ],
                },
              ],
            },
            {
              id: 85876,
              code: 'DNNE-SA-OT-PT',
              title: 'PERPETUAL',
              required: false,
              type: 'One Time',
              typeId: 1,
              prices: [
                {
                  type: 'Volume',
                  frequency: 'ONETIME',
                  currency: 'USD',
                  pricebookid: 11956,
                  ranges: [
                    {
                      priceplanid: 4702675,
                      type: 'FixedAmount',
                      fromQuantity: 0,
                      price: 12500,
                    },
                  ],
                },
                {
                  type: 'Volume',
                  frequency: 'ONETIME',
                  currency: 'USD',
                  pricebookid: 11957,
                  ranges: [
                    {
                      priceplanid: 4702679,
                      type: 'FixedAmount',
                      fromQuantity: 0,
                      price: 12500,
                    },
                  ],
                },
              ],
            },
            {
              id: 85877,
              code: 'DNNE-SA-OT-GRI',
              title: 'GRINDING',
              required: false,
              type: 'One Time',
              typeId: 1,
              prices: [
                {
                  type: 'Volume',
                  frequency: 'ONETIME',
                  currency: 'USD',
                  pricebookid: 11956,
                  ranges: [
                    {
                      priceplanid: 4702676,
                      type: 'FixedAmount',
                      fromQuantity: 0,
                      price: 12000,
                    },
                  ],
                },
                {
                  type: 'Volume',
                  frequency: 'ONETIME',
                  currency: 'USD',
                  pricebookid: 11957,
                  ranges: [
                    {
                      priceplanid: 4702680,
                      type: 'FixedAmount',
                      fromQuantity: 0,
                      price: 12000,
                    },
                  ],
                },
              ],
            },
          ],
          productTier: 'Standard',
          productTierTitle: 'Standard',
          revenueType: 'SaaS',
        },
        {
          _ns_displayname: 'DNNE-SA-CUS-STA-Sup1',
          title: 'DNNE Standard SSP otint title',
          isTrial: false,
          code: 'DNNE Standard SSP otint',
          id: 86177,
          product: {
            family: {
              code: 'DNNE',
              title: 'DNNE',
            },
            variant: {
              title: 'SaaS',
              code: 'SA-Cus',
            },
          },
          initialterm: {
            name: 'Annual - 1 Year',
            unit: 'MONTHS',
            duration: 12,
            type: 'STANDARD',
          },
          supportLevel: 'Silver',
          supportOnly: true,
          items: [
            {
              id: 84627,
              code: 'DNNE-SA-Cus-SIL',
              title: 'DNNE Silver Support',
              supportLevel: 'Silver',
              required: true,
              type: 'Recurring',
              typeId: 2,
              prices: [
                {
                  type: 'Tiered',
                  frequency: 'ANNUALLY',
                  currency: 'USD',
                  pricebookid: 12056,
                  ranges: [
                    {
                      priceplanid: 4705161,
                      type: 'Rate',
                      fromQuantity: 0,
                      price: 12,
                    },
                  ],
                },
              ],
            },
            {
              id: 84636,
              code: 'DNNE-SA-Add-BAS',
              title: 'DNNE Addon',
              required: false,
              type: 'Recurring',
              typeId: 2,
              prices: [
                {
                  type: 'Tiered',
                  frequency: 'ANNUALLY',
                  currency: 'USD',
                  pricebookid: 12056,
                  ranges: [
                    {
                      priceplanid: 4705162,
                      type: 'Rate',
                      fromQuantity: 0,
                      price: 1,
                    },
                  ],
                },
              ],
            },
            {
              id: 85876,
              code: 'DNNE-SA-OT-PT',
              title: 'PERPETUAL',
              required: false,
              type: 'One Time',
              typeId: 1,
              prices: [
                {
                  type: 'Tiered',
                  frequency: 'ONETIME',
                  currency: 'USD',
                  pricebookid: 12056,
                  ranges: [
                    {
                      priceplanid: 4705163,
                      type: 'Rate',
                      fromQuantity: 0,
                      price: 1000,
                    },
                  ],
                },
              ],
            },
            {
              id: 85877,
              code: 'DNNE-SA-OT-GRI',
              title: 'GRINDING',
              required: false,
              type: 'One Time',
              typeId: 1,
              prices: [
                {
                  type: 'Volume',
                  frequency: 'ONETIME',
                  currency: 'USD',
                  pricebookid: 12056,
                  ranges: [
                    {
                      priceplanid: 4705264,
                      type: 'FixedAmount',
                      fromQuantity: 0,
                      price: 1020,
                    },
                    {
                      priceplanid: 4705264,
                      type: 'Rate',
                      fromQuantity: 5,
                      price: 3,
                    },
                  ],
                },
              ],
            },
          ],
          productTier: 'Standard',
          productTierTitle: 'Standard',
          revenueType: 'SaaS',
        },
        {
          _ns_displayname: 'DNNE-SA-Cus-STA-SUP-001',
          isTrial: false,
          code: 'DNNE Std Slvr Sup WOOT',
          id: 86279,
          product: {
            family: {
              code: 'DNNE',
              title: 'DNNE',
            },
            variant: {
              title: 'SaaS',
              code: 'SA-Cus',
            },
          },
          initialterm: {
            name: 'Annual - 1 Year',
            unit: 'MONTHS',
            duration: 12,
            type: 'STANDARD',
          },
          supportLevel: 'Silver',
          supportOnly: true,
          items: [
            {
              id: 84627,
              code: 'DNNE-SA-Cus-SIL',
              title: 'DNNE Silver Support',
              supportLevel: 'Silver',
              required: true,
              type: 'Recurring',
              typeId: 2,
              prices: [
                {
                  type: 'Volume',
                  frequency: 'ANNUALLY',
                  currency: 'USD',
                  pricebookid: 12158,
                  ranges: [
                    {
                      priceplanid: 4710007,
                      type: 'Rate',
                      fromQuantity: 0,
                      price: 30,
                    },
                  ],
                },
                {
                  type: 'Volume',
                  frequency: 'MONTHLY',
                  currency: 'USD',
                  pricebookid: 12159,
                  ranges: [
                    {
                      priceplanid: 4710009,
                      type: 'Rate',
                      fromQuantity: 0,
                      price: 35,
                    },
                  ],
                },
              ],
            },
            {
              id: 84636,
              code: 'DNNE-SA-Add-BAS',
              title: 'DNNE Addon',
              required: false,
              type: 'Recurring',
              typeId: 2,
              prices: [
                {
                  type: 'Volume',
                  frequency: 'ANNUALLY',
                  currency: 'USD',
                  pricebookid: 12158,
                  ranges: [
                    {
                      priceplanid: 4710008,
                      type: 'Rate',
                      fromQuantity: 0,
                      price: 15,
                    },
                  ],
                },
                {
                  type: 'Volume',
                  frequency: 'MONTHLY',
                  currency: 'USD',
                  pricebookid: 12159,
                  ranges: [
                    {
                      priceplanid: 4710010,
                      type: 'Rate',
                      fromQuantity: 0,
                      price: 20,
                    },
                  ],
                },
              ],
            },
          ],
          productTier: 'Standard',
          productTierTitle: 'Standard',
          revenueType: 'SaaS',
        },
        {
          _ns_displayname: 'DNNE-SA-Cus-BAS-Add2-001',
          isTrial: false,
          code: 'DNNE Customer EVOQ BASIC Addon 2',
          id: 86581,
          product: {
            family: {
              code: 'DNNE',
              title: 'DNNE',
            },
            variant: {
              title: 'SaaS',
              code: 'SA-Cus',
            },
          },
          initialterm: {
            name: 'Annual - 1 Year',
            unit: 'MONTHS',
            duration: 12,
            type: 'STANDARD',
          },
          supportLevel: 'Silver',
          supportOnly: false,
          items: [
            {
              id: 84626,
              code: 'DNNE-SA-Cus-BAS',
              title: 'DNNE Customer Cloud EVOQ Basic',
              required: true,
              type: 'Recurring',
              typeId: 2,
              prices: [
                {
                  type: 'Volume',
                  frequency: 'ANNUALLY',
                  currency: 'USD',
                  pricebookid: 12359,
                  ranges: [
                    {
                      priceplanid: 4778398,
                      type: 'Rate',
                      fromQuantity: 0,
                      price: 22,
                    },
                  ],
                },
              ],
            },
            {
              id: 86580,
              code: 'DNNE-SA-Add2-BAS',
              title: 'DNNE Addon',
              required: false,
              type: 'Recurring',
              typeId: 2,
              prices: [
                {
                  type: 'Volume',
                  frequency: 'ANNUALLY',
                  currency: 'USD',
                  pricebookid: 12359,
                  ranges: [
                    {
                      priceplanid: 4778400,
                      type: 'Rate',
                      fromQuantity: 0,
                      price: 20,
                    },
                  ],
                },
              ],
            },
          ],
          productTier: 'Standard',
          productTierTitle: 'Standard',
          revenueType: 'SaaS',
        },
        {
          _ns_displayname: 'DNNE-SA-Cus-STA-SUP-001',
          isTrial: false,
          code: 'DNNE Std Silver NoSup',
          id: 86380,
          product: {
            family: {
              code: 'DNNE',
              title: 'DNNE',
            },
            variant: {
              title: 'SaaS',
              code: 'SA-Cus',
            },
          },
          initialterm: {
            name: 'Annual - 1 Year',
            unit: 'MONTHS',
            duration: 12,
            type: 'STANDARD',
          },
          supportLevel: 'Silver',
          supportOnly: true,
          items: [
            {
              id: 84627,
              code: 'DNNE-SA-Cus-SIL',
              title: 'DNNE Silver Support',
              supportLevel: 'Silver',
              required: true,
              type: 'Recurring',
              typeId: 2,
              prices: [
                {
                  type: 'Volume',
                  frequency: 'ANNUALLY',
                  currency: 'USD',
                  pricebookid: 12259,
                  ranges: [
                    {
                      priceplanid: 4757021,
                      type: 'Rate',
                      fromQuantity: 0,
                      price: 30,
                    },
                  ],
                },
                {
                  type: 'Volume',
                  frequency: 'MONTHLY',
                  currency: 'USD',
                  pricebookid: 12260,
                  ranges: [
                    {
                      priceplanid: 4757024,
                      type: 'Rate',
                      fromQuantity: 0,
                      price: 35,
                    },
                  ],
                },
              ],
            },
            {
              id: 85876,
              code: 'DNNE-SA-OT-PT',
              title: 'PERPETUAL',
              required: false,
              type: 'One Time',
              typeId: 1,
              prices: [
                {
                  type: 'Volume',
                  frequency: 'ONETIME',
                  currency: 'USD',
                  pricebookid: 12259,
                  ranges: [
                    {
                      priceplanid: 4757022,
                      type: 'FixedAmount',
                      fromQuantity: 0,
                      price: 12500,
                    },
                  ],
                },
                {
                  type: 'Volume',
                  frequency: 'ONETIME',
                  currency: 'USD',
                  pricebookid: 12260,
                  ranges: [
                    {
                      priceplanid: 4757025,
                      type: 'FixedAmount',
                      fromQuantity: 0,
                      price: 12500,
                    },
                  ],
                },
              ],
            },
            {
              id: 85877,
              code: 'DNNE-SA-OT-GRI',
              title: 'GRINDING',
              required: false,
              type: 'One Time',
              typeId: 1,
              prices: [
                {
                  type: 'Volume',
                  frequency: 'ONETIME',
                  currency: 'USD',
                  pricebookid: 12259,
                  ranges: [
                    {
                      priceplanid: 4757023,
                      type: 'FixedAmount',
                      fromQuantity: 0,
                      price: 12000,
                    },
                  ],
                },
                {
                  type: 'Volume',
                  frequency: 'ONETIME',
                  currency: 'USD',
                  pricebookid: 12260,
                  ranges: [
                    {
                      priceplanid: 4757026,
                      type: 'FixedAmount',
                      fromQuantity: 0,
                      price: 12000,
                    },
                  ],
                },
              ],
            },
          ],
          productTier: 'Standard',
          productTierTitle: 'Standard',
          revenueType: 'SaaS',
        },
        {
          _ns_displayname: 'DNNE-SA-Cus-STA-SUP-001',
          isTrial: false,
          code: 'DNNE Std Slvr Sup',
          id: 86179,
          product: {
            family: {
              code: 'DNNE',
              title: 'DNNE',
            },
            variant: {
              title: 'SaaS',
              code: 'SA-Cus',
            },
          },
          initialterm: {
            name: 'Annual - 1 Year',
            unit: 'MONTHS',
            duration: 12,
            type: 'STANDARD',
          },
          supportLevel: 'Silver',
          supportOnly: true,
          items: [
            {
              id: 84627,
              code: 'DNNE-SA-Cus-SIL',
              title: 'DNNE Silver Support',
              supportLevel: 'Silver',
              required: true,
              type: 'Recurring',
              typeId: 2,
              prices: [
                {
                  type: 'Volume',
                  frequency: 'ANNUALLY',
                  currency: 'USD',
                  pricebookid: 12058,
                  ranges: [
                    {
                      priceplanid: 4708344,
                      type: 'Rate',
                      fromQuantity: 0,
                      price: 30,
                    },
                  ],
                },
                {
                  type: 'Volume',
                  frequency: 'MONTHLY',
                  currency: 'USD',
                  pricebookid: 12059,
                  ranges: [
                    {
                      priceplanid: 4708346,
                      type: 'Rate',
                      fromQuantity: 0,
                      price: 35,
                    },
                  ],
                },
              ],
            },
            {
              id: 84636,
              code: 'DNNE-SA-Add-BAS',
              title: 'DNNE Addon',
              required: false,
              type: 'Recurring',
              typeId: 2,
              prices: [
                {
                  type: 'Volume',
                  frequency: 'ANNUALLY',
                  currency: 'USD',
                  pricebookid: 12058,
                  ranges: [
                    {
                      priceplanid: 4708345,
                      type: 'Rate',
                      fromQuantity: 0,
                      price: 15,
                    },
                  ],
                },
                {
                  type: 'Volume',
                  frequency: 'MONTHLY',
                  currency: 'USD',
                  pricebookid: 12059,
                  ranges: [
                    {
                      priceplanid: 4708347,
                      type: 'Rate',
                      fromQuantity: 0,
                      price: 20,
                    },
                  ],
                },
              ],
            },
          ],
          productTier: 'Standard',
          productTierTitle: 'Standard',
          revenueType: 'SaaS',
        },
        {
          _ns_displayname: 'DNNE-SA-Cus-STA-GLD-001',
          title: 'DNNE Gold Support Plan',
          isTrial: false,
          code: 'DNNE Gold Support Plan',
          id: 86178,
          product: {
            family: {
              code: 'DNNE',
              title: 'DNNE',
            },
            variant: {
              title: 'SaaS',
              code: 'SA-Cus',
            },
          },
          initialterm: {
            name: 'Annual - 1 Year',
            unit: 'MONTHS',
            duration: 12,
            type: 'STANDARD',
          },
          supportLevel: 'Gold',
          supportOnly: true,
          items: [
            {
              id: 84629,
              code: 'DNNE-SA-Cus-GOL',
              title: 'DNNE Gold Support',
              supportLevel: 'Gold',
              required: true,
              type: 'Recurring',
              typeId: 2,
              prices: [
                {
                  type: 'Volume',
                  frequency: 'MONTHLY',
                  currency: 'USD',
                  pricebookid: 12057,
                  ranges: [
                    {
                      priceplanid: 4707077,
                      type: 'Rate',
                      fromQuantity: 0,
                      price: 20,
                    },
                  ],
                },
              ],
            },
            {
              id: 84636,
              code: 'DNNE-SA-Add-BAS',
              title: 'DNNE Addon',
              required: false,
              type: 'Recurring',
              typeId: 2,
              prices: [
                {
                  type: 'Volume',
                  frequency: 'MONTHLY',
                  currency: 'USD',
                  pricebookid: 12057,
                  ranges: [
                    {
                      priceplanid: 4707079,
                      type: 'Rate',
                      fromQuantity: 0,
                      price: 25,
                    },
                  ],
                },
              ],
            },
            {
              id: 85876,
              code: 'DNNE-SA-OT-PT',
              title: 'PERPETUAL',
              required: false,
              type: 'One Time',
              typeId: 1,
              prices: [
                {
                  type: 'Volume',
                  frequency: 'ONETIME',
                  currency: 'USD',
                  pricebookid: 12057,
                  ranges: [
                    {
                      priceplanid: 4707078,
                      type: 'FixedAmount',
                      fromQuantity: 0,
                      price: 15000,
                    },
                  ],
                },
              ],
            },
          ],
          productTier: 'Standard',
          productTierTitle: 'Standard',
          revenueType: 'SaaS',
        },
        {
          _ns_displayname: 'DNNE-SA-Cus-STA-SUP-001',
          title: 'DNNE Standard Silver Support Plan Title',
          isTrial: false,
          code: 'DNNE Standard Silver Support Plan',
          id: 85878,
          product: {
            family: {
              code: 'DNNE',
              title: 'DNNE',
            },
            variant: {
              title: 'SaaS',
              code: 'SA-Cus',
            },
          },
          initialterm: {
            name: 'Annual - 1 Year',
            unit: 'MONTHS',
            duration: 12,
            type: 'STANDARD',
          },
          supportLevel: 'Silver',
          supportOnly: true,
          items: [
            {
              id: 84627,
              code: 'DNNE-SA-Cus-SIL',
              title: 'DNNE Silver Support',
              supportLevel: 'Silver',
              required: true,
              type: 'Recurring',
              typeId: 2,
              prices: [
                {
                  type: 'Volume',
                  frequency: 'ANNUALLY',
                  currency: 'USD',
                  pricebookid: 11657,
                  ranges: [
                    {
                      priceplanid: 4684694,
                      type: 'Rate',
                      fromQuantity: 0,
                      price: 30,
                    },
                  ],
                },
                {
                  type: 'Volume',
                  frequency: 'MONTHLY',
                  currency: 'USD',
                  pricebookid: 11755,
                  ranges: [
                    {
                      priceplanid: 4690008,
                      type: 'Rate',
                      fromQuantity: 0,
                      price: 35,
                    },
                  ],
                },
              ],
            },
            {
              id: 84636,
              code: 'DNNE-SA-Add-BAS',
              title: 'DNNE Addon',
              required: false,
              type: 'Recurring',
              typeId: 2,
              prices: [
                {
                  type: 'Volume',
                  frequency: 'ANNUALLY',
                  currency: 'USD',
                  pricebookid: 11657,
                  ranges: [
                    {
                      priceplanid: 4684695,
                      type: 'Rate',
                      fromQuantity: 0,
                      price: 15,
                    },
                  ],
                },
                {
                  type: 'Volume',
                  frequency: 'MONTHLY',
                  currency: 'USD',
                  pricebookid: 11755,
                  ranges: [
                    {
                      priceplanid: 4690009,
                      type: 'Rate',
                      fromQuantity: 0,
                      price: 20,
                    },
                  ],
                },
              ],
            },
            {
              id: 85876,
              code: 'DNNE-SA-OT-PT',
              title: 'PERPETUAL',
              required: false,
              type: 'One Time',
              typeId: 1,
              prices: [
                {
                  type: 'Volume',
                  frequency: 'ONETIME',
                  currency: 'USD',
                  pricebookid: 11657,
                  ranges: [
                    {
                      priceplanid: 4684696,
                      type: 'FixedAmount',
                      fromQuantity: 0,
                      price: 12500,
                    },
                  ],
                },
                {
                  type: 'Volume',
                  frequency: 'ONETIME',
                  currency: 'USD',
                  pricebookid: 11755,
                  ranges: [
                    {
                      priceplanid: 4690010,
                      type: 'FixedAmount',
                      fromQuantity: 0,
                      price: 12500,
                    },
                  ],
                },
              ],
            },
            {
              id: 85877,
              code: 'DNNE-SA-OT-GRI',
              title: 'GRINDING',
              required: false,
              type: 'One Time',
              typeId: 1,
              prices: [
                {
                  type: 'Volume',
                  frequency: 'ONETIME',
                  currency: 'USD',
                  pricebookid: 11657,
                  ranges: [
                    {
                      priceplanid: 4684697,
                      type: 'FixedAmount',
                      fromQuantity: 0,
                      price: 12000,
                    },
                  ],
                },
                {
                  type: 'Volume',
                  frequency: 'ONETIME',
                  currency: 'USD',
                  pricebookid: 11755,
                  ranges: [
                    {
                      priceplanid: 4690011,
                      type: 'FixedAmount',
                      fromQuantity: 0,
                      price: 12000,
                    },
                  ],
                },
              ],
            },
          ],
          productTier: 'Standard',
          productTierTitle: 'Standard',
          revenueType: 'SaaS',
        },
        {
          _ns_displayname: 'DNNE-SA-Cus-BAS-Add-002',
          isTrial: false,
          code: 'DNNE EVOQ BASIC OT',
          id: 86379,
          product: {
            family: {
              code: 'DNNE',
              title: 'DNNE',
            },
            variant: {
              title: 'SaaS',
              code: 'SA-Cus',
            },
          },
          initialterm: {
            name: 'Annual - 1 Year',
            unit: 'MONTHS',
            duration: 12,
            type: 'STANDARD',
          },
          supportLevel: 'Silver',
          supportOnly: false,
          items: [
            {
              id: 84626,
              code: 'DNNE-SA-Cus-BAS',
              title: 'DNNE Customer Cloud EVOQ Basic',
              required: true,
              type: 'Recurring',
              typeId: 2,
              prices: [
                {
                  type: 'Tiered',
                  frequency: 'ANNUALLY',
                  currency: 'USD',
                  pricebookid: 12258,
                  ranges: [
                    {
                      priceplanid: 4747455,
                      type: 'Rate',
                      fromQuantity: 0,
                      price: 200,
                    },
                  ],
                },
              ],
            },
            {
              id: 84636,
              code: 'DNNE-SA-Add-BAS',
              title: 'DNNE Addon',
              required: false,
              type: 'Recurring',
              typeId: 2,
              prices: [
                {
                  type: 'Tiered',
                  frequency: 'ANNUALLY',
                  currency: 'USD',
                  pricebookid: 12258,
                  ranges: [
                    {
                      priceplanid: 4747457,
                      type: 'Rate',
                      fromQuantity: 0,
                      price: 100,
                    },
                  ],
                },
              ],
            },
            {
              id: 85876,
              code: 'DNNE-SA-OT-PT',
              title: 'PERPETUAL',
              required: false,
              type: 'One Time',
              typeId: 1,
              prices: [
                {
                  type: 'Tiered',
                  frequency: 'ONETIME',
                  currency: 'USD',
                  pricebookid: 12258,
                  ranges: [
                    {
                      priceplanid: 4747458,
                      type: 'FixedAmount',
                      fromQuantity: 0,
                      price: 20000,
                    },
                  ],
                },
              ],
            },
          ],
          productTier: 'Standard',
          productTierTitle: 'Standard',
          revenueType: 'SaaS',
        },
        {
          _ns_displayname: 'DNNE-SA-Cus-BAS-SIL-001',
          isTrial: false,
          code: 'DNNE Customer EVOQ BASIC DiffAddon',
          id: 86681,
          product: {
            family: {
              code: 'DNNE',
              title: 'DNNE',
            },
            variant: {
              title: 'SaaS',
              code: 'SA-Cus',
            },
          },
          initialterm: {
            name: 'Annual - 1 Year',
            unit: 'MONTHS',
            duration: 12,
            type: 'STANDARD',
          },
          supportLevel: 'Silver',
          supportOnly: false,
          items: [
            {
              id: 84626,
              code: 'DNNE-SA-Cus-BAS',
              title: 'DNNE Customer Cloud EVOQ Basic',
              required: true,
              type: 'Recurring',
              typeId: 2,
              prices: [
                {
                  type: 'Volume',
                  frequency: 'ANNUALLY',
                  currency: 'USD',
                  pricebookid: 12460,
                  ranges: [
                    {
                      priceplanid: 4779008,
                      type: 'Rate',
                      fromQuantity: 0,
                      price: 22,
                    },
                  ],
                },
              ],
            },
            {
              id: 86580,
              code: 'DNNE-SA-Add2-BAS',
              title: 'DNNE Addon',
              required: false,
              type: 'Recurring',
              typeId: 2,
              prices: [
                {
                  type: 'Volume',
                  frequency: 'ANNUALLY',
                  currency: 'USD',
                  pricebookid: 12460,
                  ranges: [
                    {
                      priceplanid: 4779010,
                      type: 'Rate',
                      fromQuantity: 0,
                      price: 20,
                    },
                  ],
                },
              ],
            },
          ],
          productTier: 'Standard',
          productTierTitle: 'Standard',
          revenueType: 'SaaS',
        },
        {
          _ns_displayname: 'DNNE-SA-CusEG-CON-SIL',
          isTrial: false,
          code: 'DNNE Customer Cloud EVOQ CONTENT Evergreen',
          id: 84834,
          product: {
            family: {
              code: 'DNNE',
              title: 'DNNE',
            },
            variant: {
              title: 'SaaS',
              code: 'SA-CusEG',
            },
          },
          initialterm: {
            name: 'Evergreen Term',
            type: 'EVERGREEN',
          },
          supportOnly: false,
          items: [
            {
              id: 84626,
              code: 'DNNE-SA-Cus-BAS',
              title: 'DNNE Customer Cloud EVOQ Basic',
              required: true,
              type: 'Recurring',
              typeId: 2,
              prices: [
                {
                  type: 'Tiered',
                  frequency: 'ANNUALLY',
                  currency: 'USD',
                  pricebookid: 10822,
                  ranges: [
                    {
                      priceplanid: 4621934,
                      type: 'Rate',
                      fromQuantity: 0,
                      price: 2,
                    },
                  ],
                },
              ],
            },
          ],
          productTier: 'Standard',
          productTierTitle: 'Standard',
          revenueType: 'SaaS',
        },
        {
          _ns_displayname: 'DNNE-SA-Cus2-BAS-SIL',
          isTrial: false,
          code: 'DNNE Customer Cloud EVOQ BASIC pvc2',
          id: 84935,
          product: {
            family: {
              code: 'DNNE',
              title: 'DNNE',
            },
            variant: {
              title: 'SaaS',
              code: 'SA-Cus2',
            },
          },
          initialterm: {
            name: 'Annual - 1 Year',
            unit: 'MONTHS',
            duration: 12,
            type: 'STANDARD',
          },
          supportOnly: false,
          items: [
            {
              id: 84626,
              code: 'DNNE-SA-Cus-BAS',
              title: 'DNNE Customer Cloud EVOQ Basic',
              required: true,
              type: 'Recurring',
              typeId: 2,
              prices: [
                {
                  type: 'Volume',
                  frequency: 'ANNUALLY',
                  currency: 'USD',
                  pricebookid: 10922,
                  ranges: [
                    {
                      priceplanid: 4626257,
                      type: 'Rate',
                      fromQuantity: 0,
                      price: 10,
                    },
                  ],
                },
              ],
            },
          ],
          productTier: 'Standard',
          productTierTitle: 'Standard',
          revenueType: 'SaaS',
        },
        {
          _ns_displayname: 'DNNE-SA-Leg-BAS-PLA',
          isTrial: false,
          code: 'DNNE Legacy EVOQ BASIC PLATINUM',
          id: 84654,
          product: {
            family: {
              code: 'DNNE',
              title: 'DNNE',
            },
            variant: {
              title: 'SA-Leg',
              code: 'SA-Leg',
            },
          },
          initialterm: {
            name: 'Annual - 1 Year',
            unit: 'MONTHS',
            duration: 12,
            type: 'STANDARD',
          },
          supportLevel: 'Platinum',
          supportOnly: true,
          items: [
            {
              id: 84639,
              code: 'DNNE-SA-Leg-BAS',
              title: 'DNNE Legacy EVOQ Basic',
              required: false,
              type: 'Recurring',
              typeId: 2,
              prices: [
                {
                  type: 'Volume',
                  frequency: 'ANNUALLY',
                  currency: 'USD',
                  pricebookid: 10625,
                  ranges: [
                    {
                      priceplanid: 4612920,
                      type: 'Rate',
                      fromQuantity: 0,
                      price: 40,
                    },
                  ],
                },
              ],
            },
            {
              id: 84640,
              code: 'DNNE-SA-Leg-PLA',
              title: 'DNNE Legacy Platinum Support',
              supportLevel: 'Platinum',
              required: false,
              type: 'Recurring',
              typeId: 2,
              prices: [
                {
                  type: 'Volume',
                  frequency: 'ANNUALLY',
                  currency: 'USD',
                  pricebookid: 10625,
                  ranges: [
                    {
                      priceplanid: 4612921,
                      type: 'Rate',
                      fromQuantity: 0,
                      price: 0,
                    },
                  ],
                },
              ],
            },
          ],
          productTier: 'Standard',
          productTierTitle: 'Standard',
          revenueType: 'SaaS',
        },
        {
          _ns_displayname: 'DNNE-SA-ADDSUB-BAS-SIL',
          isTrial: false,
          code: 'DNNE Customer Cloud EVOQ BASIC Additional',
          id: 85174,
          product: {
            family: {
              code: 'DNNE',
              title: 'DNNE',
            },
            variant: {
              title: 'SA-ADDSUB',
              code: 'SA-ADDSUB',
            },
          },
          initialterm: {
            name: 'Annual - 1 Year',
            unit: 'MONTHS',
            duration: 12,
            type: 'STANDARD',
          },
          supportLevel: 'Silver',
          supportOnly: false,
          items: [
            {
              id: 85172,
              code: 'DNNE-SA-ADDSUB-BAS',
              title: 'DNNE Customer Cloud EVOQ Basic Additional',
              required: true,
              type: 'Recurring',
              typeId: 2,
              prices: [
                {
                  type: 'Volume',
                  frequency: 'ANNUALLY',
                  currency: 'USD',
                  pricebookid: 11154,
                  ranges: [
                    {
                      priceplanid: 4671687,
                      type: 'Rate',
                      fromQuantity: 0,
                      price: 10,
                    },
                  ],
                },
                {
                  type: 'Volume',
                  frequency: 'MONTHLY',
                  currency: 'USD',
                  pricebookid: 11155,
                  ranges: [
                    {
                      priceplanid: 4671689,
                      type: 'Rate',
                      fromQuantity: 0,
                      price: 1,
                    },
                  ],
                },
              ],
            },
          ],
          productTier: 'Standard',
          productTierTitle: 'Basic',
          revenueType: 'SaaS',
        },
        {
          _ns_displayname: 'DNNE-SA-Cus-BAS-SIL-001',
          isTrial: false,
          code: 'DNNE-SA-TEST-MULTICONF',
          id: 85040,
          product: {
            family: {
              code: 'DNNE',
              title: 'DNNE',
            },
            variant: {
              title: 'SA-TEST',
              code: 'SA-TEST',
            },
          },
          initialterm: {
            name: 'Annual - 1 Year',
            unit: 'MONTHS',
            duration: 12,
            type: 'STANDARD',
          },
          supportLevel: 'Silver',
          supportOnly: false,
          items: [
            {
              id: 84626,
              code: 'DNNE-SA-Cus-BAS',
              title: 'DNNE Customer Cloud EVOQ Basic',
              required: true,
              type: 'Recurring',
              typeId: 2,
              prices: [
                {
                  type: 'Tiered',
                  frequency: 'MONTHLY',
                  currency: 'USD',
                  pricebookid: 11023,
                  ranges: [
                    {
                      priceplanid: 4645594,
                      type: 'Rate',
                      fromQuantity: 0,
                      price: 1,
                    },
                    {
                      priceplanid: 4645594,
                      type: 'Rate',
                      fromQuantity: 10,
                      price: 2,
                    },
                    {
                      priceplanid: 4645594,
                      type: 'FixedAmount',
                      fromQuantity: 30,
                      price: 42,
                    },
                    {
                      priceplanid: 4645594,
                      type: 'Rate',
                      fromQuantity: 50,
                      price: 12,
                    },
                  ],
                },
              ],
            },
            {
              id: 84637,
              code: 'DNNE-SA-TS-OPTVOL',
              title: 'DNNE-SA-TS-OPTVOL',
              required: false,
              type: 'Recurring',
              typeId: 2,
              prices: [
                {
                  type: 'Volume',
                  frequency: 'MONTHLY',
                  currency: 'USD',
                  pricebookid: 11023,
                  ranges: [
                    {
                      priceplanid: 4645596,
                      type: 'Rate',
                      fromQuantity: 0,
                      price: 3,
                    },
                    {
                      priceplanid: 4645596,
                      type: 'FixedAmount',
                      fromQuantity: 100,
                      price: 50,
                    },
                    {
                      priceplanid: 4645596,
                      type: 'Rate',
                      fromQuantity: 200,
                      price: 2,
                    },
                  ],
                },
              ],
            },
            {
              id: 84638,
              code: 'DNNE-SA-TST-USG',
              title: 'DNNE-SA-TST-USG',
              required: false,
              type: 'Usage',
              typeId: 3,
              prices: [
                {
                  type: 'Volume',
                  frequency: 'MONTHLY',
                  currency: 'USD',
                  pricebookid: 11023,
                  ranges: [
                    {
                      priceplanid: 4645597,
                      type: 'Rate',
                      fromQuantity: 0,
                      price: 3,
                    },
                    {
                      priceplanid: 4645597,
                      type: 'FixedAmount',
                      fromQuantity: 100,
                      price: 50,
                    },
                    {
                      priceplanid: 4645597,
                      type: 'Rate',
                      fromQuantity: 200,
                      price: 2,
                    },
                  ],
                },
              ],
            },
          ],
          productTier: 'Standard',
          productTierTitle: 'Standard',
          revenueType: 'SaaS',
        },
      ],
      mainItemCodes: ['DNNE-SA-Cus-BAS', 'DNNE-SA-Cus-SIL'],
      expectedUptic: 0,
    };
    const res = checkPrices(
      params.planCode,
      params.subscriptionItems,
      params.discount,
      params.subscriptionPlans,
      params.mainItemCodes
    );
  });
});
