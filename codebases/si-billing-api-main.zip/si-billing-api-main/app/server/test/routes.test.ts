import routes from '../src/api/routes';

describe('routes', () => {
  it('routes', () => {
    let usages = 0;
    routes({
      use: () => {
        usages++;
      },
      get: () => {
        usages++;
      },
      post: () => {
        usages++;
      },
    } as any);

    expect(usages).toBeGreaterThan(6);
  });
});
