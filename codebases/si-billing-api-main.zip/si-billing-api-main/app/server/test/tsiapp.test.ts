import tsiapp from '../src/tsiapp';

describe('tsiapp', () => {
  it('tsiapp', () => {
    tsiapp.listen(3000);
    tsiapp.close(() => {
      return null;
    });
  });
});
