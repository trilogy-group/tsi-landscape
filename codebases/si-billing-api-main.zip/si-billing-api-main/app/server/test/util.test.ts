import { Request, Response, NextFunction } from 'express';
import * as util from '../src/common/util';
import { defaultIfBlank } from '../src/common/util';

describe('util', () => {
  it('promiseAllInBatches', async () => {
    const testItmes = [1, 2, 3, 4, 5, 6];
    const res = await util.promiseAllInBatches(async (i) => i * 10, testItmes, 2);

    expect(res).toStrictEqual([10, 20, 30, 40, 50, 60]);
  });

  it('defaultIfBlank', async () => {
    expect(defaultIfBlank('defaultValue')).toStrictEqual('defaultValue');
    expect(defaultIfBlank('defaultValue', '')).toStrictEqual('defaultValue');
    expect(defaultIfBlank('defaultValue', '   ')).toStrictEqual('defaultValue');
    expect(defaultIfBlank('defaultValue', null)).toStrictEqual('defaultValue');
    expect(defaultIfBlank('defaultValue', '   normal value')).toStrictEqual('   normal value');
  });

  it('resolveAndCatchAsyncHandler resolve without error', async () => {
    // Arrange
    let value = '';
    const fn = async (_req: Request, _res: Response): Promise<void> => {
      value = 'resolved';
    };
    const req: Request = {} as Request;
    const res: Response = {} as Response;
    const next: NextFunction = () => value = 'thrown';

    // Act
    const handler = util.resolveAndCatchAsyncHandler(fn);
    handler(req, res, next);
    await delay(100); // wait for callback method execution if any

    // Assert
    expect(value).toStrictEqual('resolved');
  });

  it('resolveAndCatchAsyncHandler resolve with error', async () => {
    // Arrange    
    let value = '';
    const fn = async (_req: Request, _res: Response): Promise<void> => {
      value = 'resolved';
      throw new Error();
    };
    const req: Request = {} as Request;
    const res: Response = {} as Response;
    const next: NextFunction = () => value = 'thrown';

    // Act
    const handler = util.resolveAndCatchAsyncHandler(fn);
    handler(req, res, next);
    await delay(100); // wait for callback method execution if any

    // Assert
    expect(value).toStrictEqual('thrown');
  });

  it('enumerateAsText should return an empty text when there is no value', () => {
    // Arrange
    const values = [];

    // Act
    const result = util.enumerateAsText(values);
  
    // Assert
    expect(result).toStrictEqual('');
  });

  it('enumerateAsText should return the unique value when there is only one value', () => {
    // Arrange
    const values = [ "value-1" ];

    // Act
    const result = util.enumerateAsText(values);
  
    // Assert
    expect(result).toStrictEqual(values[0]);
  });

  it('enumerateAsText should return the enumerated values when there are more than one value with given separators', () => {
    // Arrange
    const values = [ "value-1", "value-2", "value-3" ];
    const defaultSeparator = '; ';
    const lastSeparator = ';; ';

    // Act
    const result = util.enumerateAsText(values, defaultSeparator, lastSeparator);
  
    // Assert
    expect(result).toStrictEqual(`${values[0]}${defaultSeparator}${values[1]}${lastSeparator}${values[2]}`);
  });

  it('enumerateAsText should return the enumerated values as conjunction when there are more than one value', () => {
    // Arrange
    const values = [ "value-1", "value-2", "value-3" ];

    // Act
    const result = util.enumerateAsText(values);
  
    // Assert
    expect(result).toStrictEqual(`${values[0]}, ${values[1]} and ${values[2]}`);
  });

  function delay(time: number): Promise<void> {
    return new Promise(resolve => setTimeout(resolve, time));
  }
});
