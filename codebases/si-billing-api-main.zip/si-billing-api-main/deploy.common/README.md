CDK deployment for the common resources used by the test, prod and development stacks.
This project is based on https://github.com/trilogy-group/lambda-cdk-infra

## Prerequisites
* [Setup AWS CLI](https://docs.aws.amazon.com/cli/latest/userguide/cli-configure-quickstart.html) in us-east-1 region

## Build and Deploy Common Resources
Only 'test' and 'prod' are supposed to be deployed, but any other deployment is ok if needed.
The 'test' deployment is used in the staging and development environment. The 'prod' is used in production only.

Run these commands folder:

To prepare(build):
```
npm run cli -- prepare "'*'"
```

To deploy to the 'test' env:
```
npm run cli -- deploy test "'*'" --cdk-args="--require-approval never --force"
```
