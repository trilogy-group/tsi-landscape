import { LambdaBuilders, AutoDeployOnChange, ChangeObserver, Deployment, Prepare, PrepareCallback, PrepareConfig, RootStack, StackConfig } from '@trilogy-group/lambda-cdk-infra';
import * as lambda from "aws-cdk-lib/aws-lambda";
import * as cognito from 'aws-cdk-lib/aws-cognito';
import * as dynamodb from "aws-cdk-lib/aws-dynamodb";
import * as kms from 'aws-cdk-lib/aws-kms';
import * as path from 'path';
import { IGrantable } from "aws-cdk-lib/aws-iam";
import { DeploymentUtil } from '../../libs/deploymentUtil';
import { Duration } from 'aws-cdk-lib';


const PROJECT_NAME = 'common-resources';
const PROJECT_DIR = path.resolve(__dirname, "../../app/portal/");
@Prepare(PROJECT_NAME)
class PrepareProject implements PrepareCallback {
  invoke = async (config: PrepareConfig) => {
    const lambdaPaths = [
      'lambdas/custom-auth/create-auth-challenge',
      'lambdas/custom-auth/define-auth-challenge',
      'lambdas/custom-auth/pre-signup',
      'lambdas/custom-auth/verify-auth-challenge-response',
    ];
    const failed = lambdaPaths.reduce((acc, lambdaPath) => acc || !LambdaBuilders.prepareNpmTsProject(path.join(PROJECT_DIR, lambdaPath), config), false);
    if (failed) {
      throw new Error(`Deployment preparation failed for the project ${PROJECT_NAME}!`);
    }
  };
}

@Deployment(PROJECT_NAME, PROJECT_NAME)
export class CommonResources extends RootStack {
  private envName: string;

  constructor(config: StackConfig) {
    config.props = {
      env: {
        account: process.env.CDK_DEFAULT_ACCOUNT,
        region: process.env.CDK_DEFAULT_REGION,
      },
    };
    super(config);
    DeploymentUtil.addTags(this, config.environmentName);
    this.envName = this.config.environmentName;
  
    this.deployCustomAuthResources();
    this.deployUiStorageResources();
  }

  /**
   * Deploys all resources related to custom authentication.
   */
  private deployCustomAuthResources() {

    // Deploy KMS Key.
    const authKey = new kms.Key(this, 'AuthenticationEncryptionKey', {
      alias: `selfserveportal-${this.envName}-auth-key`,
      description: 'Key used to encrypt authentication token.',
      enableKeyRotation: true,
    });

    // Deploy Pre-Signup Lambda function.
    const preSignupLambda = new lambda.Function(this, "custom-auth-pre-signup", {
      code: lambda.Code.fromAsset(path.resolve(PROJECT_DIR, "lambdas/custom-auth/pre-signup")),
      handler: "pre-signup.handler",
      functionName: `CognitoCustomAuthPreSignup-common-${this.envName}`,
      runtime: lambda.Runtime.NODEJS_14_X,
      environment: {},
    });

    // Deploy Define Auth Challenge Lambda function.
    const defineAuthChallengeLambda = new lambda.Function(this, "custom-auth-define-auth-challenge", {
      code: lambda.Code.fromAsset(path.resolve(PROJECT_DIR, "lambdas/custom-auth/define-auth-challenge")),
      handler: "define-auth-challenge.handler",
      functionName: `CognitoCustomAuthDefineAuthChallenge-common-${this.envName}`,
      runtime: lambda.Runtime.NODEJS_14_X,
      environment: {},
    });

    // Deploy Create Auth Challenge Lambda function.
    const createAuthChallengeLambda = new lambda.Function(this, "custom-auth-create-auth-challenge", {
      code: lambda.Code.fromAsset(path.resolve(PROJECT_DIR, "lambdas/custom-auth/create-auth-challenge")),
      handler: "create-auth-challenge.handler",
      functionName: `CognitoCustomAuthCreateAuthChallenge-common-${this.envName}`,
      runtime: lambda.Runtime.NODEJS_14_X,
      environment: {},
    });

    // Deploy Verify Auth Challenge Response Lambda function.
    const verifyAuthChallengeResponseLambda = new lambda.Function(this, "custom-auth-verify-auth-challenge-response", {
      code: lambda.Code.fromAsset(path.resolve(PROJECT_DIR, "lambdas/custom-auth/verify-auth-challenge-response")),
      handler: "verify-auth-challenge-response.handler",
      functionName: `CognitoCustomAuthVerifyAuthChallengeResponse-common-${this.envName}`,
      runtime: lambda.Runtime.NODEJS_14_X,
      environment: {
        AUTH_KEY_ID: authKey.keyId,
      },
    });
    authKey.grantDecrypt(verifyAuthChallengeResponseLambda.role as IGrantable);

    // Deploy Cognito User Pool.
    const userPool = new cognito.UserPool(this, 'passwordless-user-pool', {
      userPoolName: `selfserveportal-${this.envName}-passwordless`,
      standardAttributes: {
        email: { required: true, mutable: false },
      },
      customAttributes: {
        authChallenge: new cognito.StringAttribute({ mutable: true }),
        customerIds: new cognito.StringAttribute({ mutable: true }),
        isSuperAdmin: new cognito.BooleanAttribute({ mutable: true }),
      },
      selfSignUpEnabled: false,
      accountRecovery: cognito.AccountRecovery.NONE,
      signInAliases: {
        email: true,
      },
      signInCaseSensitive: false,
      passwordPolicy: {
        requireDigits: false,
        requireUppercase: false,
        requireSymbols: false,
      },
      lambdaTriggers: {
        preSignUp: preSignupLambda,
        defineAuthChallenge: defineAuthChallengeLambda,
        createAuthChallenge: createAuthChallengeLambda,
        verifyAuthChallengeResponse: verifyAuthChallengeResponseLambda,
      },
    });

    // Deploy Cognito User Pool Client.
    userPool.addClient('passwordless-user-pool-client', {
      userPoolClientName: `selfserveportal-client-${this.envName}-passwordless`,
      authFlows: { custom: true, userPassword: false },
      preventUserExistenceErrors: true,
      accessTokenValidity: Duration.hours(12),
      idTokenValidity: Duration.hours(12),
    });
  }

  /**
   * Deploy all resources related to the UI storage.
   */
  private deployUiStorageResources() {

    // Deploy the DynamoDB table.
    const _uiStorageTable = new dynamodb.Table(this, `ui-storage-table`, {
      tableName: `portal-${this.envName}-ui-storage`,
      billingMode: dynamodb.BillingMode.PROVISIONED,
      readCapacity: 1,
      writeCapacity: 1,
      partitionKey: { name: 'username', type: dynamodb.AttributeType.STRING },
      sortKey: { name: 'subscriptionId', type: dynamodb.AttributeType.STRING },
      timeToLiveAttribute: 'ttl',
    });
  }
}

@AutoDeployOnChange('common-resources')
class CommonResourcesSource implements ChangeObserver {
  paths(): string[] {
    return [
      __filename, // This stack file
      `${PROJECT_DIR}/lambdas/custom-auth/**`,
    ];
  }
}