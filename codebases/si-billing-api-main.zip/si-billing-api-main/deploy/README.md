CDK deployment based on https://github.com/trilogy-group/lambda-cdk-infra

## Prerequisites
* [Setup AWS CLI](https://docs.aws.amazon.com/cli/latest/userguide/cli-configure-quickstart.html) in us-east-1 region
* Docker must be running to execute the deploy command from your local machine.

## Build and Deploy Proxy and Portal API
This integration supports building and deploying things from one place.
Run these commands inside deploy folder:

To prepare(build):
```
npm run cli -- prepare "'*'"
```

To deploy on 'qc' env:
```
npm run cli -- deploy qc "'*'" --cdk-args="--require-approval never --force"
```

## Build and Deploy Proxy API
To prepare(build):
```
npm run cli -- prepare "api-proxy"
```

To deploy on 'qc' env:
```
npm run cli -- deploy qc "api-proxy" --cdk-args="--require-approval never --force"
```

## Build and Deploy Portal API
To prepare(build):
```
npm run cli -- prepare "portal-api"
```

To deploy on 'qc' env:
```
npm run cli -- deploy qc "portal-api" --cdk-args="--require-approval never --force"
```