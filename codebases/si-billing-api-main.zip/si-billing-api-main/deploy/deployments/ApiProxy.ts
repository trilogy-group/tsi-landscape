import { AutoDeployOnChange, ChangeObserver, Deployment, Prepare, PrepareCallback, PrepareConfig, RootStack, StackConfig } from '@trilogy-group/lambda-cdk-infra';
import { LambdaBuilders } from '@trilogy-group/lambda-cdk-infra/';
import { Subnet, Vpc } from 'aws-cdk-lib/aws-ec2';
import * as ecs from 'aws-cdk-lib/aws-ecs';
import * as path from 'path';
import * as fs from 'fs'
import { TsiExpressService } from './TsiExpressService'
import { tsiDomainBase } from './config';
import { DeploymentUtil } from '../../libs/deploymentUtil';
import * as dynamodb from 'aws-cdk-lib/aws-dynamodb';

const PROJECT_NAME = 'api-proxy';
const PROJECT_DIR = path.resolve(__dirname, "../../app/server/");

@Prepare(PROJECT_NAME)
class PrepareProject implements PrepareCallback {
  invoke = async (config: PrepareConfig) => {
    if (config.env !== 'prod') {
      fs.appendFileSync(path.join(PROJECT_DIR, '.env'), "NS_CUSTOM_VERSION_ALLOWED=true\n")
    }

    if (!LambdaBuilders.prepareNpmTsProject(PROJECT_DIR, config)) {
      throw new Error(`Deployment preparation failed for the project ${PROJECT_NAME}!`);
    }
  };
}

@AutoDeployOnChange(PROJECT_NAME)
class ProjectSource implements ChangeObserver {
  paths(): string[] {
    return [
      __filename, // This stack file
      `${PROJECT_DIR}/**`,
    ];
  }
}

@Deployment(PROJECT_NAME, PROJECT_NAME)
class ApiProxyStack extends RootStack {
  constructor(config: StackConfig) {
    config.props = {
      env: {
        account: process.env.CDK_DEFAULT_ACCOUNT,
        region: process.env.CDK_DEFAULT_REGION,
      },
    };
    super(config);
    DeploymentUtil.addTags(this, config.environmentName);
    const envName = (config.environmentName === "prod" ? "" : config.environmentName).toLowerCase();
    const nsEnvName = config.environmentName === "prod" ? "prod" : "sb2";
    const domainBase = (config.environmentName === "prod" ? tsiDomainBase : `dev.${tsiDomainBase}`);

    const vpcFilterOptions = config.environmentName === "prod" ?
      { isDefault: true, } :
      { vpcId: "vpc-0156cd9a85b4b3fac", } // Search by id, because there is no option to create a default VPC for a dev account
    const vpc = Vpc.fromLookup(this, 'tsi-default-vpc', vpcFilterOptions);
    const cluster = ecs.Cluster.fromClusterAttributes(this, 'tsi-api-cluster', {
      clusterName: config.environmentName === "prod" ? "tsi-api-cluster" : 'tsi-api-cluster-dev',
      vpc,
      securityGroups: [],
    });
    const subnets = config.environmentName === "prod" ? undefined : vpc.selectSubnets({
      // Filter by ID, because there are two public subnets in the availability zone 'us-east-1c' for DEV account.
      subnets: [
        Subnet.fromSubnetAttributes(this, 'subnet-0e251e1c64ffec456', {
          subnetId: 'subnet-0e251e1c64ffec456',
          availabilityZone: 'us-east-1c',
        }),
        Subnet.fromSubnetAttributes(this, 'subnet-027165e52297871a7', {
          subnetId: 'subnet-027165e52297871a7',
          availabilityZone: 'us-east-1d',
        }),
      ],
    });
    const tableUiStorage = `portal-${config.environmentName === 'prod' ? 'prod' : 'test'}-ui-storage`;
    const tables = [
      dynamodb.Table.fromTableName(this, 'ui-storage-table', tableUiStorage),
    ];
    const environment = {
      "AWS_REGION": "us-east-1",
      "AWS_SES_SENDER": config.environmentName === 'prod'
        ? 'Renewals Self-Serve Portal <no-reply@trilogy.com>'
        : 'Sandbox Renewals Self-Serve Portal <no-reply@dev.trilogy.com>',
      "AWS_TABLE_UI_STORAGE": tableUiStorage,
      "NS_VERSION": "main",
      "NS_ENV_NAME": nsEnvName,
      "REQUEST_LIMIT": '15mb',
    };
    new TsiExpressService(this, config.stackName, {
      dockerContextDir: PROJECT_DIR,
      healthcheckPath: '/api/v1/spec',
      domain: domainBase,
      mainDomainPrefix: 'api',
      envName: envName,
      nsEnvName,
      prod: config.environmentName === "prod",
      vpc,
      cluster,
      subnets,
      tables,
      environment,
    });
  }
}

