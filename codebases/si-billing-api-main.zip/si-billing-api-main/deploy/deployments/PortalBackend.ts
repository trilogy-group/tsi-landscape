import {
  AutoDeployOnChange, ChangeObserver, Deployment, LambdaBuilders,
  Prepare, PrepareCallback, PrepareConfig, RootStack, StackConfig
} from '@trilogy-group/lambda-cdk-infra';
import * as cdk from "aws-cdk-lib";
import * as lambda from "aws-cdk-lib/aws-lambda";
import * as cognito from "aws-cdk-lib/aws-cognito";
import * as iam from "aws-cdk-lib/aws-iam";
import * as kms from 'aws-cdk-lib/aws-kms';
import * as route53 from 'aws-cdk-lib/aws-route53';
import * as targets from 'aws-cdk-lib/aws-route53-targets';
import { Cors, RestApiProps } from "aws-cdk-lib/aws-apigateway";

import { CognitoToApiGatewayToLambda } from "../thirdparty/aws-cognito-apigateway-lambda";
import { IGrantable } from "aws-cdk-lib/aws-iam";
import { Certificate, CertificateValidation } from "aws-cdk-lib/aws-certificatemanager";
import { HostedZone } from "aws-cdk-lib/aws-route53";
import * as path from 'path';
import { tsiDomainBase } from './config';
import { DeploymentUtil } from '../../libs/deploymentUtil';
import { RemovalPolicy } from 'aws-cdk-lib';
import { Bucket } from 'aws-cdk-lib/aws-s3';
import { CloudFrontWebDistribution, OriginAccessIdentity, ViewerCertificate } from 'aws-cdk-lib/aws-cloudfront';
import { BucketDeployment, Source } from 'aws-cdk-lib/aws-s3-deployment';

const PROJECT_NAME = 'portal-api';
const PROJECT_DIR = path.resolve(__dirname, "../../app/portal/");

@Prepare(PROJECT_NAME)
class PrepareProject implements PrepareCallback {
  invoke = async (config: PrepareConfig) => {
    const lambdaPaths = [
      'lambdas/portal-api',
    ];
    const failed = lambdaPaths.reduce((acc, lambdaPath) => acc || !LambdaBuilders.prepareNpmTsProject(path.join(PROJECT_DIR, lambdaPath), config), false);
    if (failed) {
      throw new Error(`Deployment preparation failed for the project ${PROJECT_NAME}!`);
    }
  };
}

@AutoDeployOnChange(PROJECT_NAME)
class PortalBackendSource implements ChangeObserver {
  paths(): string[] {
    return [
      __filename, // This stack file
      `${PROJECT_DIR}/**`,
    ];
  }
}

const AwsEnvironment = "si";

function existingResourcesForEnv(envName: string): {
  userPoolId: string;
  userPoolClientId: string;
  authKeyArn: string;
} {
  if (envName === 'prod') {
    return {
      userPoolId: 'us-east-1_6C4T4qDOU',
      userPoolClientId: '6v8065bqiphspjlok81kpvur10',
      authKeyArn: 'arn:aws:kms:us-east-1:524963845153:key/19de9e9a-3dc5-46ac-afd5-20030ba16943',
    };
  } else {
    return {
      userPoolId: 'us-east-1_hgQK2Ooa9',
      userPoolClientId: '7r029uemeep2itq3jju36o49mj',
      authKeyArn: 'arn:aws:kms:us-east-1:941633908494:key/f33c8a4d-a1ff-4d7b-bfc6-33a5a282e3ef',
    };
  }
}

@Deployment('portal-api', 'portal-api')
export class PortalBackendStack extends RootStack {
  mainLambdaFunctionName: string; // The main API Lambda name
  envName: string;
  cognitoToApiToLambdaConstruct: CognitoToApiGatewayToLambda; // The API GW construct
  domainZone: route53.IHostedZone; // The hosted zone for the deployment
  domain: string; // Domain for the deployment
  netsuiteEnvName: string;
  private stackConfig: StackConfig;

  constructor(config: StackConfig) {
    config.props = {
      env: {
        account: process.env.CDK_DEFAULT_ACCOUNT,
        region: process.env.CDK_DEFAULT_REGION,
      },
    };
    super(config);
    DeploymentUtil.addTags(this, config.environmentName);
    this.stackConfig = config;
    this.envName = (config.environmentName || "test").toLowerCase();
    this.netsuiteEnvName = this.envName === 'prod' ? 'prod' : 'sb2';

    const domainBase = this.envName === 'prod' ? tsiDomainBase : `dev.${tsiDomainBase}`;
    this.domain = this.envName === 'prod' ? `portal.${domainBase}` : `${this.envName}.portal.${domainBase}`;

    this.domainZone = HostedZone.fromLookup(this, 'Zone', { domainName: domainBase });


    this.deployMainApi();

    const resourceCustomer = this.cognitoToApiToLambdaConstruct.apiGateway.root.addResource("customer");
    resourceCustomer.addMethod("GET");

    const resourceJwt =
      this.cognitoToApiToLambdaConstruct.apiGateway.root.addResource("jwt");
    resourceJwt.addMethod("GET");

    const resourceIntegrations =
      this.cognitoToApiToLambdaConstruct.apiGateway.root.addResource("integrations");
    resourceIntegrations.addMethod("GET");

    const resourceUser =
      this.cognitoToApiToLambdaConstruct.apiGateway.root.addResource("user");
    resourceUser.addMethod("GET");

    const resourceConfig =
      this.cognitoToApiToLambdaConstruct.apiGateway.root.addResource("config");
    resourceConfig.addMethod("GET");
    resourceConfig.addMethod("PUT");

    const resourceSignup = this.cognitoToApiToLambdaConstruct.apiGateway.root.addResource("signup");
    resourceSignup.addMethod("POST");

    const resourceSignin = this.cognitoToApiToLambdaConstruct.apiGateway.root.addResource("signin");
    resourceSignin.addMethod("POST");

    // Mandatory to call this method to Apply the Cognito Authorizers on all API methods
    // the parameter defines public endpoints
    this.cognitoToApiToLambdaConstruct.addAuthorizersWithPublic([
      "POST/signup",
      "POST/signin",
    ]);

    // Deploy the SPAs
    this.deployUIApplications(this.domain, this.domainZone);

    // Add outputs
    const _portalBackendEndpointOutput = new cdk.CfnOutput(this, "portalBackendEndpoint", {
      value: `https://${this.domain}/api`,
    });
    const _userPoolIdOutput = new cdk.CfnOutput(this, "userPoolId", {
      value: this.cognitoToApiToLambdaConstruct.userPool.userPoolId,
    });
    const _userPoolClientIdOutput = new cdk.CfnOutput(this, "userPoolClientId", {
      value: this.cognitoToApiToLambdaConstruct.userPoolClient.userPoolClientId,
    });
  }

  /**
   * Deploys API GW, Cognito user pool and the backend lambda
   */
  private deployMainApi() {
    const certificate = new Certificate(this, 'Certificate', {
      domainName: this.domain,
      validation: CertificateValidation.fromDns(this.domainZone),
    });

    const resources = existingResourcesForEnv(this.envName);
    const userPool = cognito.UserPool.fromUserPoolId(this, this.stackConfig.stackName + '-up', resources.userPoolId);
    if (!userPool) {
      throw new Error(`User pool '${resources.userPoolId}' not found.`);
    }
    const userPoolClient = cognito.UserPoolClient.fromUserPoolClientId(this, this.stackConfig.stackName + '-upc', resources.userPoolClientId);
    if (!userPoolClient) {
      throw new Error(`User pool client '${resources.userPoolClientId}' not found.`);
    }
    const authKey = kms.Key.fromKeyArn(this, 'AuthKey', resources.authKeyArn);
    if (!authKey) {
      throw new Error(`Auth key '${resources.authKeyArn}' not found.`);
    }

    this.mainLambdaFunctionName = `PortalBackendMainLambda-${this.stackConfig.environmentName}`;
    this.cognitoToApiToLambdaConstruct = new CognitoToApiGatewayToLambda(
      this,
      this.stackConfig.stackName,
      {
        lambdaFunctionProps: {
          code: lambda.Code.fromAsset(path.resolve(PROJECT_DIR, "lambdas/portal-api")),
          runtime: lambda.Runtime.NODEJS_14_X,
          handler: "index.handler",
          functionName: this.mainLambdaFunctionName,
          timeout: cdk.Duration.seconds(25),
          environment: {
            STACK_NAME: this.stackName,
            AWS_ENV_NAME: AwsEnvironment,
            NETSUITE_ENV_NAME: this.netsuiteEnvName,
            SES_SENDER: this.envName === 'prod'
              ? 'Renewals Self-Serve Portal <no-reply@trilogy.com>'
              : 'Sandbox Renewals Self-Serve Portal <no-reply@dev.trilogy.com>',
            AUTH_KEY_ID: authKey?.keyId ?? '',
            USER_POOL_ID: resources.userPoolId,
            USER_POOL_CLIENT_ID: resources.userPoolClientId,
          },
        },
        apiGatewayProps: {
          restApiName: this.stackConfig.stackName + '-restapi',
          proxy: false,
          domainName: {
            basePath: 'api',
            domainName: this.domain,
            certificate: certificate,
          },
          defaultCorsPreflightOptions: {
            allowOrigins: Cors.ALL_ORIGINS,
            allowCredentials: true,
          }
        } as RestApiProps,
        cognitoUserPool: userPool as cognito.UserPool,
        cognitoUserPoolClient: userPoolClient as cognito.UserPoolClient,
      }
    );

    const _customDomainAliasRecord = new route53.ARecord(this, 'CustomDomainAliasRecord', {
      zone: this.domainZone,
      recordName: this.domain,
      target: route53.RecordTarget.fromAlias(new targets.ApiGateway(this.cognitoToApiToLambdaConstruct.apiGateway))
    });

    // allow the lambda to access the Parameter Store
    this.setMainLambdaPolicies(authKey);
  }

  /**
   * Add policies for the main backend lambda
   */
  private setMainLambdaPolicies(authKey: cdk.aws_kms.IKey) {
    const ssmPolicy = new iam.PolicyStatement({
      effect: iam.Effect.ALLOW,
      actions: ["ssm:GetParameter"],
      resources: [
        `arn:aws:ssm:${this.region}:${this.account}:parameter/${AwsEnvironment}-*`,
        `arn:aws:ssm:${this.region}:${this.account}:parameter/ns-${this.netsuiteEnvName}-*`,
        `arn:aws:ssm:${this.region}:${this.account}:parameter/self-serve-portal-*`,
      ],
    });
    this.cognitoToApiToLambdaConstruct.lambdaFunction.role?.attachInlinePolicy(
      new iam.Policy(this, "ssm-parameters-access", {
        statements: [
          ssmPolicy,
          new iam.PolicyStatement({
            effect: iam.Effect.ALLOW,
            actions: ["ssm:PutParameter"],
            resources: [
              `arn:aws:ssm:${this.region}:${this.account}:parameter/self-serve-portal-*`,
            ],
          }),
          // Email sending
          new iam.PolicyStatement({
            effect: iam.Effect.ALLOW,
            actions: ["ses:SendEmail", "SES:SendRawEmail"],
            resources: ["*"],
          }),
        ],
      })
    );

    // allow the lambda to access user pools
    const userPoolsPolicy = new iam.PolicyStatement({
      effect: iam.Effect.ALLOW,
      actions: ["cognito-idp:*"],
      resources: ["*"],
    });
    this.cognitoToApiToLambdaConstruct.lambdaFunction.role?.attachInlinePolicy(
      new iam.Policy(this, "user-pools-access", {
        statements: [userPoolsPolicy],
      })
    );

    // Grant permissions to the lambda function for the authentication key.
    authKey.grantEncrypt(this.cognitoToApiToLambdaConstruct.lambdaFunction.role as IGrantable);
  }

  /**
   * Deploy the UI applications.
   */
  private deployUIApplications(
    domain: string,
    domainZone: route53.IHostedZone
  ) {
    // Deploye the test UI
    this.deployApiExplorer({
      uiPrefix: "api-explorer",
      uiDomain: "api-explorer." + domain,
      domainZone,
      folder: "api-explorer",
      index: "index.html",
    });
  }

  /**
   * Deploy the API explorer.
   * @param config The configuration for the deployment.
   */
  private deployApiExplorer(config: {
    uiPrefix: string;
    uiDomain: string;
    domainZone: route53.IHostedZone;
    folder: string;
    index: string;
  }) {
    // Create the certificate.
    const certificateId = config.uiPrefix + '-certificate';
    const certificate = new Certificate(this, certificateId, {
      certificateName: this.stackConfig.stackName + '-' + certificateId,
      domainName: config.uiDomain,
      validation: CertificateValidation.fromDns(config.domainZone),
    });

    // Create the S3 bucket.
    const bucketId = config.uiPrefix + '-bucket';
    const bucket = new Bucket(this, bucketId, {
      bucketName: this.stackConfig.stackName + '-' + bucketId,
      websiteIndexDocument: config.index,
      publicReadAccess: false,
      removalPolicy: RemovalPolicy.DESTROY,
      autoDeleteObjects: true,
    });

    // Create the origin access identity.
    const accessIdentity = new OriginAccessIdentity(this, config.uiPrefix + '-access-identity', {
      comment: `${bucket.bucketName}-access-identity`
    });

    // Create the CloudFront distribution.
    const cfDistribution = new CloudFrontWebDistribution(this, config.uiPrefix + '-cloudfront-distribution', {
      originConfigs: [
        {
          s3OriginSource: {
            s3BucketSource: bucket,
            originAccessIdentity: accessIdentity,
          },
          behaviors: [{ isDefaultBehavior: true }],
        },
      ],
      errorConfigurations: [
        { errorCode: 403, responseCode: 200, responsePagePath: `/${config.index}` },
        { errorCode: 404, responseCode: 200, responsePagePath: `/${config.index}` }
      ],
      viewerCertificate: ViewerCertificate.fromAcmCertificate(certificate, {
        aliases: [ config.uiDomain ],
      }),
    });

    // Create the bucket deployment.
    const _bucketDeployment = new BucketDeployment(this, config.uiPrefix + '-bucket-deployment', {
        sources: [ Source.asset(path.resolve(PROJECT_DIR, config.folder)) ],
        destinationBucket: bucket,
        distribution: cfDistribution,
        distributionPaths: ['/', `/${config.index}`],
    });

    // Add the CloudFront domain to the output.
    const _cfDomainOutput = new cdk.CfnOutput(this, config.uiPrefix + 'domain-output', {
        description: 'The domain of the website',
        value: cfDistribution.distributionDomainName,
    });

    // UI Alias
    const _portalDomainAliasRecord = new route53.ARecord(this, config.uiPrefix + '-alias-record', {
      zone: config.domainZone,
      recordName: config.uiDomain,
      target: route53.RecordTarget.fromAlias(
        new targets.CloudFrontTarget(cfDistribution)
      ),
    });
  }
}
