import * as ec2 from 'aws-cdk-lib/aws-ec2';
import * as ecs from 'aws-cdk-lib/aws-ecs';
import * as ecsPatterns from 'aws-cdk-lib/aws-ecs-patterns';
import { HostedZone } from 'aws-cdk-lib/aws-route53';
import { Certificate, CertificateValidation } from 'aws-cdk-lib/aws-certificatemanager';
import { ApplicationLoadBalancer, SslPolicy } from 'aws-cdk-lib/aws-elasticloadbalancingv2';
import * as cdk from 'aws-cdk-lib';
import * as constructs from 'constructs';
import * as dynamodb from 'aws-cdk-lib/aws-dynamodb';
import * as iam from "aws-cdk-lib/aws-iam";

export interface NsClientConfig {
  nsClientConsumerKey: string;
  nsClientConsumerSecret: string;
  nsClientTokenKey: string;
  nsClientTokenSecret: string;
  nsClientRealm: string;
  nsClientRestletBaseUrl: string;
  nsClientRestApiBaseUrl: string;
}
export interface TsiExpressServiceProps {
  /**
   * The VPC
   */
  readonly vpc: ec2.IVpc;
  readonly subnets?: ec2.SubnetSelection;
  readonly cluster?: ecs.ICluster;
  readonly tables: dynamodb.ITable[];

  /**
   * options to customize the servide
   *
   * @defult - None
   */
  readonly serviceOptions?: ecsPatterns.ApplicationLoadBalancedFargateServiceProps;
  /**
   * local path to the docker assets directory
   */
  readonly dockerContextDir: string;
  readonly healthcheckPath: string;

  readonly domain: string;

  readonly mainDomainPrefix?: string;
  readonly envName: string;
  readonly nsEnvName: string;
  /**
   * True, if this is a prod deployment
   */
  readonly prod: boolean;
  readonly environment?: { [key: string]: string };
}

export class TsiExpressService extends constructs.Construct {
  readonly dockerContextDir: string;

  constructor(scope: constructs.Construct, id: string, props: TsiExpressServiceProps) {
    super(scope, id);

    const envName = props.envName;
    const mainDomainPrefix = props.mainDomainPrefix ?? '';

    this.dockerContextDir = props.dockerContextDir;

    const domainZone = HostedZone.fromLookup(this, 'Zone', { domainName: props.domain });

    const domainPrefix = envName ? envName + (mainDomainPrefix ? `.${mainDomainPrefix}` : '') : mainDomainPrefix;
    const domain = `${domainPrefix ? `${domainPrefix}.` : ''}${props.domain}`;
    console.log(`Target domain: ${domain}`);
    new cdk.CfnOutput(this, 'EnvUrl', {
      value: 'https://' + domain,
    });

    const certificate = new Certificate(this, 'Certificate', {
      domainName: domain,
      validation: CertificateValidation.fromDns(domainZone),
    });
    /*const certificate = Certificate.fromCertificateArn(
      this,
      'tsi-api-wildcard-cert',
      'arn:aws:acm:us-east-1:524963845153:certificate/8c088274-d980-4eb8-a114-4bdf112d64b9'
    );*/

    // If there are selected subnets, create the load balancer separately. "taskSubnets" parameter for Fargate service doesn't work.
    const lb = props.subnets ? new ApplicationLoadBalancer(this, `proxy-api-${props.envName}-load-balancer`, {
      vpc: props.vpc,
      internetFacing: true,
      vpcSubnets: props.subnets,
    }) : undefined;

    const lbs = new ecsPatterns.ApplicationLoadBalancedFargateService(this, 'Service', {
      certificate,
      sslPolicy: SslPolicy.RECOMMENDED,
      domainName: domainPrefix,
      domainZone,
      assignPublicIp: true,
      loadBalancer: lb,
      cluster: props.cluster,
      taskImageOptions: {
        image: ecs.ContainerImage.fromAsset(this.dockerContextDir),
        // The DNS 10.212.70.10 works for the dev account onlys
        entryPoint: ["sh", "-c", (props.prod ? "" : "echo 'nameserver 10.212.70.10' > /etc/resolv.conf && ") + "node main.js"],
        environment: props.environment,
        logDriver: ecs.LogDrivers.awsLogs({
          streamPrefix: id,
          logRetention: 7, //days
        }),
      },
      ...props.serviceOptions,
    });
    lbs.loadBalancer.setAttribute('idle_timeout.timeout_seconds', '300');
    lbs.targetGroup.configureHealthCheck({
      path: props.healthcheckPath,
    });
    lbs.targetGroup.setAttribute('deregistration_delay.timeout_seconds', '15');

    // Grant permissions to read/write to the tables.
    for (const table of props.tables) {
      table.grantReadWriteData(lbs.taskDefinition.taskRole);
    }

    // Grant permissions to retrieve SSM parameters.
    lbs.taskDefinition.taskRole?.attachInlinePolicy(
      new iam.Policy(this, "ssm-parameters-access", {
        statements: [
          new iam.PolicyStatement({
            effect: iam.Effect.ALLOW,
            actions: ["ssm:GetParameter"],
            resources: [
              `arn:aws:ssm:${process.env.CDK_DEFAULT_REGION}:${process.env.CDK_DEFAULT_ACCOUNT}:parameter/ns-${props.nsEnvName}-*`,
              `arn:aws:ssm:${process.env.CDK_DEFAULT_REGION}:${process.env.CDK_DEFAULT_ACCOUNT}:parameter/self-serve-portal-*`
            ],
          }),   
        ],    
      })
    );

    // Grant permissions SES for sending an email.
    lbs.taskDefinition.taskRole?.attachInlinePolicy(
      new iam.Policy(this, "ses-access", {
        statements: [
          new iam.PolicyStatement({
            effect: iam.Effect.ALLOW,
            actions: ["ses:SendEmail"],
            resources: ["*"],
          }),
        ],
      })
    );
  }
}
