export const tsiDomainBase = 'si.trilogy.com';
