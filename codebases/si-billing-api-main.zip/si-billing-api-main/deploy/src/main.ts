import { Infra } from '@trilogy-group/lambda-cdk-infra';
import * as path from 'path';

(async () => {
  try {
    await Infra.scanPath(path.resolve(__dirname + '/../', 'deployments')); // Path to your deployments
    await Infra.initialize({
      projectName: 'tsi', // Your project name
      entryPoint: __filename, // Leave it as is
    });
  } catch(e) {
    console.error(e);
    process.exit(1);
  }
})();