import * as path from 'path';
import * as fs from 'fs';
import { RootStack } from '@trilogy-group/lambda-cdk-infra';
import { Tags } from 'aws-cdk-lib';

export class DeploymentUtil {
    static addTags(stack: RootStack, envName: string) {
        const conf = JSON.parse(fs.readFileSync(path.resolve(__dirname, '../../../config.json')).toString());

        for (const key in conf.tags.common) {
            Tags.of(stack).add(key, conf.tags.common[key]);
        }

        const tags = envName === 'prod' ? conf.tags.production : conf.tags.development;
        for (const key in tags) {
            Tags.of(stack).add(key, tags[key]);
        }
    }
}