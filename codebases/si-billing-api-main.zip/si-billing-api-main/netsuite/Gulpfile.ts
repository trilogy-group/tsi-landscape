import gulp from 'gulp';
import ts from 'gulp-typescript';
import preprocess from 'gulp-preprocess';
import rename from 'gulp-rename';
import run from 'gulp-run-command';
import log from 'fancy-log';
import del from 'del';

const tsProject = ts.createProject('tsconfig.json');
const targetDir = 'dist';
const packageVersion = process.env.PACKAGE_VERSION ?? 'main';

/**
 * Cleans target dir.
 */
export function clean() {
  return del([targetDir]);
}
/**
 * Compiles.
 */
export function compile() {
  return gulp
    .src('src/ts/**/*.ts')
    .pipe(tsProject())
    .js.pipe(gulp.dest(`${targetDir}/FileCabinet/SuiteScripts/si/${packageVersion}`));
}
/**
 * Compiles objects
 */
export function objects() {
  return gulp
    .src('src/Objects/*.xml')
    .pipe(preprocess({ context: { NODE_ENV: process.env.NODE_ENV, PACKAGE_VERSION: packageVersion } }))
    .pipe(
      rename(function (path) {
        path.basename = path.basename.replace('PACKAGE_VERSION', packageVersion);
      })
    )
    .pipe(gulp.dest(`${targetDir}/Objects`));
}
/**
 * Generates manifest
 */
export function manifest() {
  return gulp.src('src/*.xml').pipe(gulp.dest(`${targetDir}`));
}
/**
 * Generates build info
 */
function buildInfo() {
  log(`Building with PACKAGE_VERSION=${packageVersion}`);
  return gulp.src('.', { allowEmpty: true });
}
/**
 * Adds dependencies
 */
function addDeps() {
  return run(`suitecloud project:adddependencies  ${targetDir}`)();
}
/**
 * Deploys package
 */
function sdfDeploy() {
  return run(`suitecloud project:deploy --validate ${targetDir}`)();
}

export const build = gulp.series(buildInfo, compile, objects, manifest);
export const deployOnly = gulp.series(addDeps, sdfDeploy);
export const deploy = gulp.series(clean, build, addDeps, sdfDeploy);
