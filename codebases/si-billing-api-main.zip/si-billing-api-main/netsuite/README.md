# Netsuite script and objects

## Prerequisites
* Install Nodejs
* For Windows, use Git Bash
* Clone the repo
* Run `cd netsuite`
* Run `npm install` in project dir
* Run `npm install -D gulp`
* Run `npm run build` to build the first time
* Run `npm run suitecloud -- account:setup -i` and enter tsi-dev-auth for Auth ID

## Build
Build all scripts and objects in src
```
npm run build
```

Run tests
```
npm test
```

## Deploy
Build and deploy everything
For development always use some unique PACKAGE_VERSION env variable. This will deploy restlets under different names so reduce clash possibilities with main, qc and other dev versions.

```
export PACKAGE_VERSION=dev; npm run deploy
```

## See package.json for all commands

