export const Encoding = {
  BASE_64: null,
  UTF_8: null
}