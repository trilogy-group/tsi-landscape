import { Any } from '../../src/ts/types';

export function create() {
  return 0;
}

export function load() {
  return {
    name: 'testfile',
    getContents: () => 'testfilecontent',
    save: () => 1,
  } as Any;
}

export enum Type {
  AUTOCAD,
  BMPIMAGE,
  CSV,
  EXCEL,
  FLASH,
  FREEMARKER,
  GIFIMAGE,
  GZIP,
  HTMLDOC,
  ICON,
  JAVASCRIPT,
  JPGIMAGE,
  JSON,
  MESSAGERFC,
  MP3,
  MPEGMOVIE,
  MSPROJECT,
  PDF,
  PJPGIMAGE,
  PLAINTEXT,
  PNGIMAGE,
  POSTSCRIPT,
  POWERPOINT,
  QUICKTIME,
  RTF,
  SMS,
  STYLESHEET,
  TAR,
  TIFFIMAGE,
  VISIO,
  WEBAPPPAGE,
  WEBAPPSCRIPT,
  WORD,
  XMLDOC,
  XSD,
  ZIP,
}
