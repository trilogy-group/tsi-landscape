export function parse(args) {
  const monthNames = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  switch (args.type) {
    case 'date': {
      if (args.value) {
        const parts = args.value.split('-');
        if (parts.length === 3) {
          return new Date(parseInt(parts[2]), monthNames.indexOf(parts[1]), parseInt(parts[0]));
        }
      }
      return undefined;
    }

    default:
      return args.value;
  }
}
