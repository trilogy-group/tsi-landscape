export const post = jest.fn((arg) => {
  status: 200;
});
export const createSecureString = jest.fn((arg) => {
  return {
    convertEncoding: () => '',
    appendSecureString: (arg) => {},
  };
});

export const requestSuiteTalkRest = jest.fn((obj) => {
  if (obj.url.includes('/customer/')) {
    return { code: 200, body: JSON.stringify({ custentity_stripe_customer_account_link: 'test link' }) };
  } else {
    return { code: 404, body: '' };
  }
});

export function get() {
  return {
    status: 200,
    body: 'TestBody',
  };
}

export enum Method {
  DELETE = "DELETE",
  GET = "GET",
  PUT = "PUT",
  POST = "POST",
}
