export const runSuiteQL = jest.fn((options) => {
  return {results: [{asMap: () => {return {}}}]};
});