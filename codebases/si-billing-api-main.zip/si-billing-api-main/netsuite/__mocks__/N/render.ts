export const transaction = jest.fn((opts) => {
  return {
    getContents: () => "TestFileContent"
  }
});

export const create = jest.fn((opts) => {
  return {
  }
});

export const statement = jest.fn((opts) => {
  return {
    getContents: () => "TestFileContent"
  }
});


export enum PrintMode {
  PDF = 1
}