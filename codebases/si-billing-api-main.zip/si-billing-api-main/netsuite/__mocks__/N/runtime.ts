export const accountId = 'test';
export function getCurrentUser() {
  return {
    id: 1,
  };
}
