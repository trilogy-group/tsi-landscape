class Search {
  id: number;
  value: any;
  
  constructor(id: number) {this.id = id}
}

export const create = jest.fn((params) : Search => {
  return new Search(1)
})

export const createColumn = jest.fn((params) => {
  return [params.name, params.join];
})



/** N/search.Operator enum */
export enum Operator { 
  AFTER,
  IS, // 'is'
}

export enum Sort {
  ASC,
  DESC,
  NONE,
}
