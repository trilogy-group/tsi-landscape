export function resolveScript() {
  return 'http://example.com';
}
