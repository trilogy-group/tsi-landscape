import { InputParams, HandlerResponse, BillingSchedule } from './types';
import * as nsutils from './nsutils';
import { RecWrapper } from './nsutils';
import * as record from 'N/record';
import * as file from 'N/file';
import { NotFoundError, ValidationError, assertNotNull, assertNotNullMsg, isNotBlank, isNotNull, isNull, must } from './validation';
import entityDao, { EntityType } from './dao/EntityDao';
import billingAccountDao from './dao/BillingAccountDao';
import { DynamicSublistWrapper } from './models/DynamicSublistWrapper';
import customerDao from './dao/CustomerDao';
import { ProductIntegration } from './ProductIntegration';
import { OperationContext } from './models/OperationContext';
import { Address, Contact, PersonName } from './models/apitypes';
import subscriptionDao from './dao/SubscriptionDao';
import QuoteDao from './dao/QuoteDao';
import * as render from 'N/render';

const CUSTOMER_NOT_FOUND = 'Customer not found'

interface Customer {
  id: string;
  /**
   * False or omit for company
   */
  individual: boolean;
  individualName?: PersonName;
  /**
   * Required if customer is company
   */
  companyName?: string;
  /**
   * ISO currency code
   */
  currency?: string;
  email?: string;
  phone?: string;
  /**
   * The billing address, and if not defined separately, the shipping address.
   */
  address?: Address;
  /**
   * The shipping address, if different from the billing address.
   */
  shippingAddress?: Address;
  /**
   * Only if company
   */
  primaryContact?: Contact;
  paymentMethods?: Array<{
    type?: 'card';
  }>;
}
interface CustomerParams extends InputParams {
  content?: Customer;
  isPartialContent?: boolean;
}

interface SearchCustomerParams extends InputParams {
  content?: {
    firstName?: string;
    lastName?: string;
    email?: string;
    companyName?: string;
  };
}

interface StatementParams extends InputParams {
  content?: {
    startDate: string;
  };
}

interface InsertSignedTCsParams extends InputParams {
  quoteId?: number;
  agreementId?: number;
}

interface GetLatestQuoteParams extends InputParams {
  content?: {
    endUserId?: string;
  }
}

const SALES_DEPARTMENT_ID = 2;

class CustomerService {
  private getCustomerByEntityId(entityId: string): Customer {
    const queryText = `
  SELECT
      c.id as internalid,
      c.entityid,
      c.isperson,
      c.title,
      c.firstname,
      c.middlename,
      c.lastname,
      c.companyname,
      cur.symbol AS currency,
      c.email,
      c.phone,
      c.defaultbillingaddress,
      c.defaultshippingaddress,
      FROM customer c
      left join currency cur ON c.currency = cur.id
      WHERE  c.entityid = ?`;
    const res = nsutils.queryFirstToJson(queryText, [entityId], {
      internalid: 'internalid',
      entityid: 'id',
      isperson: { key: 'individual', f: nsutils.convert.toBoolean },
      title: 'individualName.title',
      firstname: 'individualName.firstName',
      middlename: 'individualName.middleName',
      lastname: 'individualName.lastName',
      companyname: 'companyName',
      currency: 'currency',
      email: 'email',
      phone: 'phone',
      defaultbillingaddress: 'address.id',
      defaultshippingaddress: 'shippingAddress.id',
    });
    if (!res.individual) {
      res.individualName = undefined;
    }

    // Load the addresses and contact if any.
    customerDao.loadAddresses(res);
    customerDao.loadPrimaryContact(res);

    // Get the Stripe link
    const customer = record.load({ type: record.Type.CUSTOMER, id: res.internalid });
    res.stripeCustomerAccountLink = customer.getValue('custentity_stripe_customer_account_link') as string;
    // Do not expose the internal id field
    delete res.internalid;

    return res;
  }

  getCustomer(params: InputParams): HandlerResponse {
    const customerId = must(params.customerId, 'customerId');
    const res = this.getCustomerByEntityId(customerId);
    return res ? { content: res } : { status: 404 };
  }

  getStatus(params: InputParams): HandlerResponse {
    const customerId = must(params.customerId, 'customerId');
    const queryText = `select  s.name from Customer c
                      inner join entitystatus s on s.key = c.entitystatus
                      where c.entityid = ?`;
    const res = nsutils.queryFirstToJson(queryText, [customerId]);
    return res ? { content: res.name } : { status: 404 };
  }

  /**
   * Compares both given addresses.
   * Two values are equal if both are undefined or both are defined and equal.
   * A value is considered undefined by being undefined or empty.
   * @param {Address} inAddress1 The first address.
   * @param {Address} inAddress2 The second address.
   * @returns {boolean} True if both addresses are equal; False otherwise.
   */
  private areSameAddresses(inAddress1: Address, inAddress2: Address): boolean {
    const areEqual = (v1: string | undefined, v2: string | undefined) => !v1 && !v2 || !!v1 && !!v2 && v1 === v2;
    return (
      areEqual(inAddress1.line1, inAddress2.line1) &&
      areEqual(inAddress1.line2, inAddress2.line2) &&
      areEqual(inAddress1.city, inAddress2.city) &&
      areEqual(inAddress1.state, inAddress2.state) &&
      areEqual(inAddress1.country, inAddress2.country) &&
      areEqual(inAddress1.zip, inAddress2.zip) &&
      areEqual(inAddress1.phone, inAddress2.phone)
    );
  }

  /**
   * Returns the Address object from the record.
   * @param {record.Record} addressRecord The address record.
   * @returns {Address} The address object.
   */
  private getAddressValues(addressRecord: record.Record): Address {
    return {
      line1: addressRecord.getValue('addr1') as string,
      line2: addressRecord.getValue('addr2') as string,
      city: addressRecord.getValue('city') as string,
      state: addressRecord.getValue('state') as string,
      country: addressRecord.getValue('country') as string,
      zip: addressRecord.getValue('zip') as string,
      phone: addressRecord.getValue('addrphone') as string,
    };
  }

  private setAddressValues(address: record.Record, inAddress: Address): void {
    const addr = new RecWrapper(address);
    addr.setIfDef('addr1', inAddress.line1 ?? '');
    addr.setIfDef('addr2', inAddress.line2);
    addr.setIfDef('city', inAddress.city);
    addr.setIfDef('state', inAddress.state);
    addr.setIfDef('country', inAddress.country);
    addr.setIfDef('zip', inAddress.zip);
    addr.setIfDef('addrphone', inAddress.phone);
  }

  /**
   * Upserts an address in the customer record.
   * @param {record.Record} customer The customer record.
   * @param {Address | null | undefined} inAddress The input address.
   * @param {string} fieldId The field ID of the default address. Can be 'defaultbilling' or 'defaultshipping'.
   * @returns The line number and the previous line number of the address in the customer record.
   */
  private upsertSublistAddress(customer: record.Record, inAddress: Address | null | undefined, fieldId: string): {
    line: number;
    previousLine: number;
  } {
    // Retrieve the line number of the current default address if any.
    const previousLine = customer.findSublistLineWithValue({ sublistId: 'addressbook', fieldId, value: true });

    // If the input address is undefined, do nothing. Return the existing line number of the current default address if any.
    if (inAddress === undefined) {
      return { line: previousLine, previousLine };
    }

    // If the input address is null, remove it. Remove the default flag if any and return no line number (-1).
    if (inAddress === null) {
      if (previousLine >= 0) {
        customer.setSublistValue({ sublistId: 'addressbook', fieldId, line: previousLine, value: false });
      }
      return { line: -1, previousLine };
    }

    // Search for an existing address that matches the input address.
    let line: number | undefined;
    const lineCount = customer.getLineCount({ sublistId: 'addressbook' });
    for (let i = 0; i < lineCount; i++) {
      const existingAddressRecord = customer.getSublistSubrecord({ sublistId: 'addressbook', fieldId: 'addressbookaddress', line: i });
      const existingAddress = this.getAddressValues(existingAddressRecord);
      if (this.areSameAddresses(inAddress, existingAddress)) {
        line = i;
        break;
      }
    }

    // If there is no match, insert a new address line and set common fields.
    if (line === undefined) {
      line = lineCount;
      customer.insertLine({ sublistId: 'addressbook', line: line });
      const addressRecord = customer.getSublistSubrecord({ sublistId: 'addressbook', fieldId: 'addressbookaddress', line: line });
      this.setAddressValues(addressRecord, inAddress);
    }

    // Set the default address flag, then return the line number.
    customer.setSublistValue({ sublistId: 'addressbook', fieldId, line: line, value: true });
    return { line, previousLine };
  }

  private upsertSublistAddresses(customer: record.Record, inAddress?: Address | null, inShippingAddress?: Address | null): void {
    // Note that an address cannot be deleted if referred to by other records.

    // Unset the shipping address when the billing and shipping addresses are defined and identical.
    if (inAddress && inShippingAddress && this.areSameAddresses(inAddress, inShippingAddress)) {
      inShippingAddress = null;
    }

    // Upsert the billing address, then the shipping address.
    const { line: billingAddressLine, previousLine: previousBillingAddressLine } = this.upsertSublistAddress(customer, inAddress, 'defaultbilling');
    const { line: shippingAddressLine, previousLine: previousShippingAddressLine } = this.upsertSublistAddress(customer, inShippingAddress, 'defaultshipping');

    // Set the shipping address as the billing address if there is a billing address but no shipping address,
    // i.e. if the shipping address is unset or was equal to the billing address.
    if (billingAddressLine >= 0 && !inShippingAddress && (shippingAddressLine < 0 || previousShippingAddressLine === previousBillingAddressLine)) {
      customer.setSublistValue({ sublistId: 'addressbook', fieldId: 'defaultshipping', line: billingAddressLine, value: true });
    }
  }

  private setCustomerValues(customer: record.Record, inCustomer: Customer): void {
    const cust = new RecWrapper(customer);

    cust.calcIfDef('isperson', inCustomer.individual, (val) => (val ? 'T' : 'F'));

    if (inCustomer.individual) {
      cust.setIfDef('title', inCustomer.individualName?.title);
      cust.setIfDef('firstname', inCustomer.individualName?.firstName);
      cust.setIfDef('middlename', inCustomer.individualName?.middleName);
      cust.setIfDef('lastname', inCustomer.individualName?.lastName);
    }
    cust.setIfDef('email', inCustomer.email);
    cust.setIfDef('phone', inCustomer.phone);
    cust.setIfDef('companyname', inCustomer.companyName);

    // The currency can be null only at creation. In this case, let the default value.
    cust.calcIfDef('currency', inCustomer.currency === null ? undefined : inCustomer.currency, (val) => {
      assertNotNull(val);
      const cur = nsutils.queryFirstAsMap('select id from currency where symbol=?', [val]);
      if (!cur) {
        throw new Error('Cannot find currency by code ' + val);
      }
      return cur.id;
    });

    this.upsertSublistAddresses(customer, inCustomer.address, inCustomer.shippingAddress);
  }

  private upsertPrimaryContactRecord(pi: ProductIntegration, customerId: number, inContact: Contact) {
    // For a company, the primary contact is mandatory and cannot be emptied.
    // For an individual, there is no contact.

    // Attempt to find an existing contact within the company. Initially, use the entity ID (case-sensitive) as the primary method.
    assertNotNull(inContact.name, 'primaryContact.name');
    const entityId = [ inContact.name.firstName, inContact.name.middleName?.charAt(0), inContact.name.lastName ].filter(Boolean).join(' ');
    assertNotNullMsg(entityId, 'At least the first name, the middle name or the last name must be defined.');
    let matchedContactId = parseInt(
      nsutils.queryFirstAsMap('select id from contact where company=? and entityid=?', [customerId, entityId])?.id as string
    );

    // If not successful, try using the email (case-insensitive) to accommodate changes in names.
    if (!matchedContactId && inContact.email) {
      matchedContactId = parseInt(
        nsutils.queryFirstAsMap('select id from contact where company=? and LOWER(email)=?', [customerId, inContact.email.toLowerCase()])?.id as string
      );
    }

    // If there is a match, load the record. Otherwise, create a new one.
    let contact: record.Record;
    if (matchedContactId) {
      contact = record.load({ type: record.Type.CONTACT, id: matchedContactId });
    } else {
      contact = record.create({ type: record.Type.CONTACT });
      contact.setValue({ fieldId: 'company', value: customerId });
    }
    this.setContactValues(pi, inContact, contact);
    const contactId = contact.save({ enableSourcing: false, ignoreMandatoryFields: false });

    // If the contact reference is not the primary contact on customer, set it.
    const customer = record.load({ type: record.Type.CUSTOMER, id: customerId });
    const primaryContactId = parseInt(customer.getValue({ fieldId: 'contact' }) as string);
    if (primaryContactId !== contactId) {
      customer.setValue({ fieldId: 'contact', value: contactId });
      customer.save({ enableSourcing: false, ignoreMandatoryFields: false });
    }
  }

  private setContactValues(pi: ProductIntegration, inContact: Contact, contact: record.Record): void {
    const cont = new RecWrapper(contact);
    cont.setIfDef('subsidiary', pi.newCustomerSubsidiaryId);
    cont.setIfDef('email', inContact.email);
    if (inContact.name) {
      cont.setIfDef('title', inContact.name.title);
      cont.setIfDef('firstname', inContact.name.firstName);
      cont.setIfDef('middlename', inContact.name.middleName);
      cont.setIfDef('lastname', inContact.name.lastName);
    }
    cont.setIfDef('phone', inContact.phone);
    if (inContact.billingAddress !== undefined) {
      this.upsertSublistAddress(contact, inContact.billingAddress, 'billingaddress');
    }
  }

  createBillingAccount(params: {
    customerId: string;
    frequency: BillingSchedule;
    subsidiaryId: number;
    classId: number;
    effectiveDate?: string;
  }): number {
    const baRec = record.create({
      type: record.Type.BILLING_ACCOUNT,
    });

    const ba = new nsutils.RecWrapper(baRec);
    ba.setIfDef('customer', params.customerId);
    ba.setIfDef('billingschedule', billingAccountDao.getBillingScheduleId(params.frequency));
    ba.setIfDef('subsidiary', params.subsidiaryId);
    ba.setIfDef('class', params.classId);
    ba.setIfDef('department', SALES_DEPARTMENT_ID);
    if (params.effectiveDate) {
      ba.setIfDef('startdate', new Date(params.effectiveDate));
    }

    return baRec.save();
  }

  createCustomer(params: CustomerParams) {
    return this.upsertCustomer(params, true);
  }

  updateCustomer(params: CustomerParams) {
    return this.upsertCustomer(params, false);
  }

  private upsertCustomer(params: CustomerParams, isNewCustomer: boolean) {

    // Retrieve the product integration record.
    assertNotNull(params.productFamilyCode, 'productFamilyCode');
    assertNotNull(params.productVariantCode, 'productVariantCode');
    const context = OperationContext.fromParams(params);

    // Validate the input parameters.
    const inCustomer = must(params.content, 'body');
    const isPartialContent = params.isPartialContent ?? false;
    this.validateInputParametersForUpsertingCustomer(context, inCustomer, isNewCustomer, isPartialContent);

    // Upsert the customer record and, if any, the related primary contact.
    const { id, entityId } = this.upsertCustomerRecord(context, inCustomer, isNewCustomer, isPartialContent);
    if (inCustomer.primaryContact !== undefined) {
      this.upsertPrimaryContactRecord(context.productIntegration, id, inCustomer.primaryContact);
    }

    // Returns the entity ID of the customer.
    return { content: entityId };
  }

  /**
   * Validates the input parameters for upserting a customer.
   * @param {OperationContext} context The operation context.
   * @param {Customer} inCustomer The input parameters.
   * @param {boolean} isNewCustomer Whether the customer is a new one.
   * @param {boolean} isPartialContent Whether the content is partial.
   */
  private validateInputParametersForUpsertingCustomer(context: OperationContext, inCustomer: Customer, isNewCustomer: boolean, isPartialContent: boolean): void {

    // Validate the mandatory fields.
    // - When updating with a full content, a mandatory field must be defined.
    // - When updating with a partial content, a mandatory field must not be null. Undefined fields will be ignored.
    const mandatoryFields = this.getMandatoryFieldsForUpsertingCustomer(inCustomer, isNewCustomer);
    const missingFields = Object.keys(mandatoryFields)
      .filter((key) => isPartialContent ? mandatoryFields[key] === null : isNull(mandatoryFields[key]))
      .map((key) => key);
    if (missingFields.length > 0) {
      throw new Error(`The following fields ${isPartialContent ? 'cannot be emptied' : 'are missing'}: ${missingFields.join(', ')}`);
    }

    // Validate data consistency.
    if (inCustomer.individual && inCustomer.primaryContact) {
      throw new Error('An individual customer cannot have a contact.');
    }

    // Authorize the upsert of the customer.
    const { isCustomerUpdatingEndUser } = this.authorizeUpsertCustomer(context, inCustomer, isNewCustomer, isPartialContent);

    // When updating a related end-user, the update is limited to the shipping address (and the ID).
    if (isCustomerUpdatingEndUser) {
      const hasOnlyShippingAddress = Object.keys(inCustomer).length === 2 && inCustomer.shippingAddress;
      if (!hasOnlyShippingAddress) {
        throw Error('A customer can only update the shipping address of a related end-user.');
      }
    }
  }

  /**
   * Returns the mandatory fields for upserting a customer.
   * @param {Customer} inCustomer The input parameters.
   * @param {boolean} isNewCustomer Whether the customer is a new one.
   * @returns {Record<string, unknown>} A record containing the mandatory fields, with the key as a label and its value.
   */
  private getMandatoryFieldsForUpsertingCustomer(inCustomer: Customer, isNewCustomer: boolean): Record<string, unknown> {
    const mandatoryFields = {};

    // When updating, the identifier and the currency are mandatory. The currency has a default value at creation.
    if (!isNewCustomer) {
      mandatoryFields["id"] = inCustomer.id;
      mandatoryFields["currency"] = inCustomer.currency;
    }

    // The customer is either an individual or a company, with different mandatory fields.
    if (inCustomer.individual) {
      mandatoryFields["individualName.firstName"] = inCustomer.individualName?.firstName;
      mandatoryFields["individualName.lastName"] = inCustomer.individualName?.lastName;
    } else {
      mandatoryFields["companyName"] = inCustomer.companyName;
      mandatoryFields["primaryContact"] = inCustomer.primaryContact;
    }

    // If a nested object is defined, add the related mandatory fields.
    if (inCustomer.primaryContact) {
      mandatoryFields["primaryContact.name.firstName"] = inCustomer.primaryContact.name?.firstName;
      mandatoryFields["primaryContact.name.lastName"] = inCustomer.primaryContact.name?.lastName;
    }
    const addresses = [
      { label: 'address', value: inCustomer.address },
      { label: 'shippingAddress', value: inCustomer.shippingAddress },
    ];
    for (const address of addresses) {
      if (address.value) {
        mandatoryFields[`${address.label}.country`] = address.value.country;
      }
    }

    return mandatoryFields;
  }

  /**
   * Authorizes the upsert of the customer for the given context.
   * @param {OperationContext} context The operation context.
   * @param {Customer} inCustomer The input parameters.
   * @param {boolean} isNewCustomer Whether the customer is a new one.
   * @param {boolean} isPartialContent Whether the content is partial.
   * @returns Flags for exception.
   */
  private authorizeUpsertCustomer(context: OperationContext, inCustomer: Customer, isNewCustomer: boolean, isPartialContent: boolean): {
    isCustomerUpdatingEndUser: boolean;
  } {
    let isCustomerUpdatingEndUser = false;

    // Only an administrator can create a new customer record.
    if (isNewCustomer && context.customerId !== undefined) {
      throw Error(`The customer '${context.customerId}' cannot create a new customer`);
    }

    // A customer can only modify its own record.
    if (!isNewCustomer && context.customerId !== undefined && inCustomer.id !== context.customerId) {

      // Exception: a customer can partially update the end-user from a related draft subscriptions.
      isCustomerUpdatingEndUser = isPartialContent && subscriptionDao.isEndUserInDraftSubscriptions(context, inCustomer.id);

      // If there is no exception, the update is not authorized.
      if (!isCustomerUpdatingEndUser) {
        throw Error(`The customer '${context.customerId}' cannot update information of the customer '${inCustomer.id}'`);
      }
    }

    return { isCustomerUpdatingEndUser };
  }

  /**
   * Upserts the customer records based on the input parameters.
   * @param {OperationContext} context The operation context.
   * @param {Customer} inCustomer The input parameters.
   * @param {boolean} isNewCustomer Whether the customer is a new one.
   * @param {boolean} isPartialContent Whether the content is partial.
   * @returns { id: number, entityId: string } The internal ID and the entity ID of the customer record.
   */
  private upsertCustomerRecord(context: OperationContext, inCustomer: Customer, isNewCustomer: boolean, _isPartialContent: boolean): { id: number, entityId: string } {

    // Create or update the customer record based on the input parameters.
    const upsertCustomerRecord = isNewCustomer ? this.createCustomerRecord : this.updateCustomerRecord;
    const customer = upsertCustomerRecord.call(this, context, inCustomer);

    // Save the record, then return the (internal) ID and the entity ID.
    const id = customer.save({ enableSourcing: false, ignoreMandatoryFields: false });
    const entityId = inCustomer.id ?? nsutils.queryFirstAsMap('select entityid from customer where id=?', [id])?.entityid;
    return { id, entityId };
  }

  private createCustomerRecord(context: OperationContext, inCustomer: Customer): record.Record {

    // Initialize the customer record.
    const customer = record.create({ type: record.Type.CUSTOMER });

    // Set specific fields at creation, then common fields.
    if (isNotNull(inCustomer?.id)) {
      customer.setValue({ fieldId: 'autoname', value: false });
      customer.setValue({ fieldId: 'entityid', value: inCustomer.id });
    }
    customer.setValue('entitystatus', entityDao.getEntityStatusKey(EntityType.CUSTOMER, 'Prospect'));
    if (context.productIntegration.newCustomerSubsidiaryId) {
      customer.setValue({ fieldId: 'subsidiary', value: context.productIntegration.newCustomerSubsidiaryId });
    }
    this.setCustomerValues(customer, inCustomer);

    return customer;
  }

  private updateCustomerRecord(_context: OperationContext, inCustomer: Customer): record.Record {

    // Retrieve the internal ID of the customer record.
    const c = nsutils.queryFirstAsMap('select id from customer where entityid=?', [inCustomer.id]);
    if (!c) {
      throw Error(CUSTOMER_NOT_FOUND);
    }
    
    // Load the existing customer record, then set common fields.
    const customer = record.load({ type: record.Type.CUSTOMER, id: c.id });
    this.setCustomerValues(customer, inCustomer);

    return customer;
  }

  addSubsidiary(customerId: string, subsidiaryId: number) {
    const customer = this.getCustomerRecord(customerId);
    const submachineList = new DynamicSublistWrapper(customer, 'submachine');
    while (submachineList.nextLine()) {
      nsutils.logMayBe('addSubsidiary', {
        existingSubsidiary: submachineList.getFieldValue('subsidiary'),
        subsidiaryId,
      });
      if (parseInt(submachineList.getFieldValue('subsidiary') as string) === subsidiaryId) {
        return;
      }
    }
    customer.selectNewLine({ sublistId: 'submachine' });
    customer.setCurrentSublistValue({ sublistId: 'submachine', fieldId: 'subsidiary', value: subsidiaryId });
    customer.commitLine({ sublistId: 'submachine' });
    customer.save();
  }

  getCustomerRecord(customerEntityId: string): record.Record {
    const customerInternalId = customerDao.getInternalId(customerEntityId);
    assertNotNull(customerInternalId, 'customerInternalId');
    return record.load({ type: record.Type.CUSTOMER, id: customerInternalId, isDynamic: true });
  }

  updateCustomerStatus(customerInternalId: number, newStatus: number) {
    const customer = record.load({ type: record.Type.CUSTOMER, id: customerInternalId });
    customer.setValue({ fieldId: 'entitystatus', value: newStatus });
    customer.save();
  }

  searchCustomer(params: SearchCustomerParams): HandlerResponse {
    let sql = `
  SELECT 
      c.entityid
  FROM   customer c
        left join currency cur
              ON c.currency = cur.id
        left join entityaddress addr
          ON addr.nkey = c.defaultbillingaddress
        left join contact con
        ON c.contact=con.id 
  WHERE 1=1 
`;
    const sqlParams: Array<number | string | boolean> = [];

    assertNotNull(params.content);
    const customerParams = must(params.content, 'body');

    if (isNotBlank(customerParams.firstName)) {
      sql += 'AND (UPPER(c.firstname) = ? OR UPPER(con.firstname) = ?) ';
      sqlParams.push(customerParams.firstName.toUpperCase());
      sqlParams.push(customerParams.firstName.toUpperCase());
    }
    if (isNotBlank(params.content.lastName)) {
      sql += 'AND (UPPER(c.lastname) = ? OR UPPER(con.lastname) = ?) ';
      sqlParams.push(params.content.lastName.toUpperCase());
      sqlParams.push(params.content.lastName.toUpperCase());
    }
    if (isNotBlank(params.content.email)) {
      sql += 'AND (UPPER(c.email) = ? OR UPPER(con.email) = ?) ';
      sqlParams.push(params.content.email.toUpperCase());
      sqlParams.push(params.content.email.toUpperCase());
    }
    if (isNotBlank(params.content.companyName)) {
      sql += 'AND UPPER(c.companyname) = ?';
      sqlParams.push(params.content.companyName.toUpperCase());
    }
    const customerIds = nsutils.queryToJson(sql, sqlParams);
    nsutils.logMayBe('customer.search', { sql: sql, params: sqlParams });
    const res: Array<Customer> = [];
    for (const cid of customerIds) {
      res.push(this.getCustomerByEntityId(cid.entityid));
    }
    return { content: res };
  }

  getStatement(params: StatementParams): HandlerResponse {
    const customerInternalId = customerDao.getInternalId(must(params.customerId, 'customerId')) as number;
    assertNotNull(customerInternalId, CUSTOMER_NOT_FOUND);
    const statementParams: render.StatementOptions = {
      entityId: customerInternalId,
      printMode: render.PrintMode.PDF
    };
    if (params.content?.startDate) {
      statementParams.startDate = params.content.startDate;
    }
    const statement = render.statement(statementParams);
    return { content: statement.getContents() };
  }

  getLatestSignedQuote(params: GetLatestQuoteParams): HandlerResponse {
    nsutils.logMayBe('getLatestSignedQuote params', params);
    const customerInternalId = customerDao.getInternalId(must(params.customerId, 'customerId')) as number;
    assertNotNull(customerInternalId, CUSTOMER_NOT_FOUND);

    let endUserInternalId: number | undefined;
    if (params.content?.endUserId) {
      endUserInternalId = customerDao.getInternalId(params.content.endUserId) as number;
      assertNotNull(endUserInternalId, 'End user not found');
    } else {
      const customer = record.load({ type: record.Type.CUSTOMER, id: customerInternalId });
      const channelTier = parseInt(customer.getValue('custentity_customer_channel_tier') as string);
      if (channelTier === channelTiers.reseller || channelTier === channelTiers.distributor) {
        throw new ValidationError('Customer is Reseller/Distributor and end user was not provided.');
      }
    }

    // return the signed quotes ordered
    const res = QuoteDao.getSignedQuotesByCustomer(customerInternalId, endUserInternalId);
    for (const quote of res) {
      nsutils.logMayBe('getLatestSignedQuote quote', quote);
      let fileId: number | undefined;
      // if the quote agreement is signed, get the file id to download the file
      if (quote.agreementId && quote.agreementStatus === 'Signed') {
        const agreement = record.load({
          type: 'customrecord_echosign_agreement',
          id: quote.agreementId
        });
        fileId = agreement.getValue('custrecord_echosign_signed_doc') as number;
      }
      // if we only have the link from the contractual documents, get the file id from the link
      else if (quote.contractualDocumentsLink && quote.linkType === quoteLinkType[quoteLinkType.contractualDocuments]) {
        const id = quote.contractualDocumentsLink.match(/id=(\d+)/)?.[1];
        if (id) {
          fileId = parseInt(id);
        }
      }
      // if we have a file id, we can return as we only want to return the latest signed quote
      if (fileId) {
        const fileObj = file.load({
          id: fileId
        });
        return { content: fileObj.getContents() };
      }
    }
    nsutils.logMayBe('getLatestSignedQuote finish', 'finish');
    throw new NotFoundError('No signed quote found');
  }
}

enum quoteLinkType {
  softLink,
  hardLink,
  contractualDocuments
}

enum channelTiers {
  endUser = 1,
  reseller = 2,
  distributor = 3
}

export default new CustomerService();
