import { InputParams, HandlerResponse, TypedHandlerResponse, OrderType, SqlParams } from './types';
import * as nsutils from './nsutils';
import { assertNotNull, must, NotFoundError, SubscriptionNotFoundError, ValidationError } from './validation';
import invoiceDao from './dao/InvoiceDao';
import * as render from 'N/render';
import * as record from 'N/record';
import { SubscriptionRecord } from './models/SubscriptionRecord';
import CustomerDao from './dao/CustomerDao';
import { ApiInvoiceInfo } from './models/apitypes';

const STRIPE_PAYMENT_BASE_URL = 'https://app.suitesync.io/payments/';

export interface FindInvoicesParams extends InputParams {
  subscriptionId?: string;
  startDate?: string;
  endDate?: string;
  status?: Array<string>;
}

interface InvoiceParam extends InputParams {
  content?: {
    invoiceNumber?: string;
  };
}

interface PaymentLink {
  type: 'stripeUrl';
  url: string;
}

interface CreateInvoiceFromSubscriptionParams extends InputParams {
  content?: {
    subscriptionId?: number;
  };
}

class InvoiceService {
  private doFindInvoices(params: {
    invoiceId?: number;
    customerId?: string;
    subscriptionId?: string;
    startDate?: string;
    endDate?: string;
    status?: Array<string>;
    classId?: number;
  }): ApiInvoiceInfo[] {
    let sql = `
  SELECT 
    '${STRIPE_PAYMENT_BASE_URL}'||s.custrecord_stripe_account_id||'/custinvc/'||i.id as stripeInvoicePaymentLink,
    i.tranid,
    i.trandate as date,
    i.duedate,
    i.status as statuscode,
    tr_stat_dict.name as statustitle,
    cur.symbol as currency,
    i.foreigntotal,
    i.taxtotal,
    i.asofdate,
    i.id
  FROM transaction i
    JOIN billingaccount ba on i.billingaccount=ba.id
    JOIN customer c  on ba.customer=c.id
    JOIN currency cur on cur.id=i.currency
    JOIN CUSTOMRECORD_SWE_TRANSACTION_STATUS tr_stat_dict on (i.type||':'||i.status=tr_stat_dict.CUSTRECORD_SWE_TRAN_STATUS_SEARCH_KEY AND tr_stat_dict.isinactive='F')
    LEFT JOIN transactionLine line ON line.transaction = i.id AND line.linesequencenumber = 0
    LEFT JOIN subsidiary s ON s.id = line.subsidiary
  WHERE i.abbrevtype='INV'
    AND c.entityid=? AND lower(i.tranid) NOT LIKE '%internal%'
  `;
    const sqlParams: SqlParams = [must(params.customerId, 'customerId')];

    if (params.invoiceId) {
      sql += ` AND i.id = ?`;
      sqlParams.push(params.invoiceId);
    }

    if (params.startDate) {
      sql += ` AND i.trandate >= TO_DATE(?, 'MM/DD/YYYY')`;
      sqlParams.push(params.startDate);
    }

    if (params.endDate) {
      sql += ` AND i.trandate <= TO_DATE(?, 'MM/DD/YYYY')`;
      sqlParams.push(params.endDate);
    }

    if (params.subscriptionId) {
      sql += ` AND i.id in (select transaction from transactionline where subscription=?)`;
      sqlParams.push(params.subscriptionId);
    }

    if (params.status && params.status.length > 0) {
      sql += ` AND i.status IN ( ${params.status.map(() => '?').join(',')} )`;
      for (const st of params.status) {
        sqlParams.push(st);
      }
    }
    nsutils.logMayBe('invoices.find', sql);
    nsutils.logMayBe('invoices.find', sqlParams);
    const res = nsutils.queryToJson(sql, sqlParams, {
      stripeinvoicepaymentlink: 'stripeInvoicePaymentLink',
      tranid: 'number',
      date: 'date',
      duedate: 'dueDate',
      statuscode: 'status.code',
      statustitle: 'status.title',
      currency: 'currency',
      foreigntotal: 'totalAmount',
      taxtotal: { key: 'taxAmount', f: (v) => v || 0 },
      asofdate: '_asofdate',
      id: '_id',
    });

    return res;
  }

  /**
   * Find customer invoices
   */
  findInvoices(params: FindInvoicesParams): TypedHandlerResponse<ApiInvoiceInfo[]> {
    return { content: this.doFindInvoices(params) };
  }

  /**
   * Download invoice pdf in base64 format
   */
  downloadInvoice(params: InvoiceParam): HandlerResponse {
    assertNotNull(params.content?.invoiceNumber, 'invoiceNumber');
    assertNotNull(params.customerId, 'customerId');
    const invId = invoiceDao.findInvoiceInternalId(params.customerId, params.content?.invoiceNumber);
    if (!invId) {
      throw new NotFoundError('Cannot find such invoice');
    }
    const f = render.transaction({
      entityId: invId,
      printMode: render.PrintMode.PDF,
    });
    nsutils.logMayBe('invoice.f', JSON.stringify(f));
    return { content: f.getContents() };
  }

  private getStripeInvoicePaymentLink(customerId: string, invoiceNumber: string) {
    assertNotNull(invoiceNumber, 'invoiceNumber');
    assertNotNull(customerId, 'customerId');
    const sql = `
    SELECT 
      '${STRIPE_PAYMENT_BASE_URL}'||s.custrecord_stripe_account_id||'/custinvc/'||i.id as stripeInvoicePaymentLink
    FROM transaction i
       JOIN transactionLine line ON line.transaction = i.id
       JOIN subsidiary s ON s.id = line.subsidiary
       JOIN billingaccount ba ON i.billingaccount = ba.id
       JOIN customer c ON ba.customer=c.id
    WHERE i.abbrevtype='INV'  
      AND i.tranid=?
      AND c.entityid=?
    `;
    const sqlParams = [invoiceNumber, customerId];
    const res = nsutils.queryToJson(sql, sqlParams, {
      stripeinvoicepaymentlink: 'stripeInvoicePaymentLink',
    });
    if (res.length === 0) {
      throw new NotFoundError('Cannot find such invoice');
    }
    return res[0].stripeInvoicePaymentLink;
  }

  generatePaymentLink(params: InvoiceParam): TypedHandlerResponse<PaymentLink> {
    assertNotNull(params.content?.invoiceNumber, 'invoiceNumber');
    assertNotNull(params.customerId, 'customerId');

    return {
      content: {
        type: 'stripeUrl',
        url: this.getStripeInvoicePaymentLink(params.customerId, params.content.invoiceNumber),
      },
    };
  }

  private createInvoiceForBA(customerId: string, billingAccountId: number): ApiInvoiceInfo {
    const customerInternalId = must(CustomerDao.getInternalId(customerId), 'customerInternalId');
    const rec = record.create({
      type: record.Type.INVOICE,
      defaultValues: {
        entity: customerInternalId,
        billingaccount: billingAccountId,
        billcharges: 'T',
      },
    });

    if (!nsutils.isProduction()) {
      // This is required for sandbox where avatax doesn't work.
      // This flag without custom tax parameters for items effectively make taxes 0.
      nsutils.logDebug('Sandbox. Overriding tax to avoid Avatax errors', '');
      rec.setValue('taxdetailsoverride', true);
    }
    rec.setValue('custbody_end_user', customerInternalId);
    rec.setValue('custbody_order_type', OrderType.New);

    // Fix to handle missing 0-prefix introduced by NetSuite on asofdate by re-applying the value.
    // The value is deduced from nextbillcycledate when setting the billing account ID but there is an unexpected mismatch for one-digit day. (e.g. '6-Mar-2023' instead of '06-Mar-2023').
    const asOfDate = rec.getValue('asofdate')?.toString();
    if (asOfDate) {
      rec.setValue('asofdate', new Date(asOfDate)); 
    }
    
    const invoiceId = rec.save();

    const invoices = this.doFindInvoices({ customerId, invoiceId }) as ApiInvoiceInfo[];
    if (invoices.length > 0) {
      return invoices[0];
    } else {
      throw new NotFoundError('Invoice not found');
    }
  }

  /**
   * Find a billing account tied to subscription and create next invoice as per billing cycle for that billing account
   * @privateRemarks
   * Documentation spec: https://docs.google.com/document/d/1G3fhOD6SiBUhIkqFXeMiNpCgGtqLpT_1hWwOi_PJMh0/edit#bookmark=kix.mvk07a8zx5yp
   */
  createInvoiceFromSubscription(params: CreateInvoiceFromSubscriptionParams): TypedHandlerResponse<ApiInvoiceInfo> {
    assertNotNull(params.content?.subscriptionId, 'subscriptionId');
    assertNotNull(params.customerId, 'customerId');
    const sub = SubscriptionRecord.load(params.content?.subscriptionId);
    if (!sub.isWritableForCustomer(params.customerId)) {
      throw new SubscriptionNotFoundError();
    }

    const existingInvoices = this.doFindInvoices({ customerId: params.customerId });
    if (existingInvoices.length > 0) {
      throw new ValidationError('Customer already has invoices');
    }

    assertNotNull(sub, 'subscription');

    return { content: this.createInvoiceForBA(params.customerId, sub.billingAccount) };
  }
}

export default new InvoiceService();
