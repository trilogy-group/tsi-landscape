import {
  InputParams,
  HandlerResponse,
  SqlParams,
  ProductTierUtil,
  SupportLevelUtil
} from './types';
import * as nsutils from './nsutils';
import { NotFoundError, assertNotNull, isNotBlank, must } from './validation';
import subscriptionPlanUtility from './utility/SubscriptionPlanUtility';
import { Any } from '../../src/ts/types';
import { ListSubscriptionPlanParams, SubscriptionPlan } from './models/SubscriptionPlan';
import SubscriptionPlanDao from './dao/SubscriptionPlanDao';

export interface GetLatestSubscriptionPlanCodeParams extends InputParams {
  productTier?: string;
  supportLevel?: string;
  isSupport?: boolean;
}

/**
 * Returns the latest subscription plan code (itemid) matching the input params.
 * @param params
 * @returns The latest subscription plan code if any.
 */
export function getLatestSubscriptionPlanCode(params: GetLatestSubscriptionPlanCodeParams): HandlerResponse {
  assertNotNull(params.productFamilyCode, 'productFamilyCode');
  assertNotNull(params.productVariantCode, 'productVariantCode');
  assertNotNull(params.productTier ,'productTier');
  assertNotNull(params.supportLevel, 'supportLevel');
  assertNotNull(params.isSupport, 'isSupport');

  // Validate the product tier and the support level.
  const productTier = ProductTierUtil.nameToProductTier(params.productTier);
  if (!productTier) {
    throw new Error(`Invalid product tier: ${params.productTier}`);
  }
  const supportLevel = SupportLevelUtil.nameToSupportLevel(params.supportLevel);
  if (!supportLevel) {
    throw new Error(`Invalid support level: ${params.supportLevel}`);
  }

  // Get the latest subscription plan, and return the plan code (itemid) if any.
  const subscriptionPlan = SubscriptionPlanDao.getLatestSubscriptionPlan(
    params.productFamilyCode, params.productVariantCode, productTier, supportLevel, params.isSupport
  );
  if (!subscriptionPlan) {
    throw new NotFoundError('Subscription plan not found for the given parameters');
  }
  return { content: subscriptionPlan.itemid };
}

/**
 * product integrations list for the informed family and variant
 * @param params containing the family and variant to search
 * @returns list of the records found
 */
export function listProducts(params: InputParams): HandlerResponse {
  const queryParams: SqlParams = [];
  let sql = `
    SELECT 
      custrecordproductfamilycode,
      custrecordproductfamilytitle,
      custrecordproductvariantcode,
      custrecordproductvarianttitle
    FROM customrecordproductintegration
    WHERE 1=1 
  `;
  if (isNotBlank(params.productFamilyCode)) {
    sql += 'AND custrecordproductfamilycode=?';
    queryParams.push(params.productFamilyCode);
  }
  if (isNotBlank(params.productVariantCode)) {
    sql += 'AND custrecordproductvariantcode=?';
    queryParams.push(params.productVariantCode);
  }
  return {
    content: nsutils.queryToJson(sql, queryParams, {
      custrecordproductfamilycode: 'family.code',
      custrecordproductfamilytitle: 'family.title',
      custrecordproductvariantcode: 'variant.code',
      custrecordproductvarianttitle: 'variant.title',
    }),
  };
}

/**
 * list subscription plans for the informed family and variant
 * @privateRemarks
 * Doc spec: https://docs.google.com/document/d/1G3fhOD6SiBUhIkqFXeMiNpCgGtqLpT_1hWwOi_PJMh0/edit#heading=h.aqgs9dl88wn
 * @param params containing the family and variant to search
 * @returns the subscription plans and their items
 */
export function listSubscriptionPlans(params: ListSubscriptionPlanParams): HandlerResponse {
  const plans = getSubscriptionPlansForCustomer(params);
  plans.forEach(mapToFrontView);
  return { content: plans };
}

/**
 * Get subscription plans as it's defined in api documentation hiding fields used internally
 */
export function getSubscriptionPlansForCustomer(params: ListSubscriptionPlanParams): SubscriptionPlan[] {
  const plans = subscriptionPlanUtility.getSubscriptionPlans(params);
  plans.forEach(function (plan: SubscriptionPlan) {
    const supportItemCodes = subscriptionPlanUtility.addSupportPricesToItems(plan);
    // filter out support item if we have main item
    // https://docs.google.com/document/d/1G3fhOD6SiBUhIkqFXeMiNpCgGtqLpT_1hWwOi_PJMh0/edit#bookmark=id.akx0rgytc0i4
    plan.items = plan.items.filter((i) => supportItemCodes.findIndex(code => code === i.code) === -1);    
  });
  return plans;
}

function mapToFrontView(plan: SubscriptionPlan) {
  // remove fields that we are not exposing to public
  if (plan.product !== undefined) {
    delete plan.product.tierLabels;
  }
  delete plan.isLegacyPlan;
  delete plan.mainItemCode;
  delete plan.supportItemCode;
  delete plan.renewalPlanId;

  //changes to keep integrity
  plan._ns_displayname = plan.code;
  plan.code = must(plan.name);
  delete plan.name;

  plan.items.forEach((item) => {
    if (item.isMainItem || (plan.supportOnly && item.isSupportMainItem)) {
      item.required = true;
    }
    delete (item as unknown as Any).isMainItem;
    delete (item as unknown as Any).isSupportMainItem;
    delete (item as unknown as Any).isSupportAddonItem;
  });
}