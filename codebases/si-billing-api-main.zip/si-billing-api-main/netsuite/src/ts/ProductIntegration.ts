import { convert, logMayBe, MappingTransform, ProductWebhook, queryFirstToJson, queryToJson } from './nsutils';
import { CodeAndTitle, ProductTier, SqlParams } from './types';
import { parseIntOrNull } from './utility/GeneralUtility';
import { assertNotNull, isNotNull } from './validation';

export class ProductIntegration {
  id?: number;
  family?: CodeAndTitle;
  variant?: CodeAndTitle;
  nsClass!: {
    id: number;
    name: string;
    fullname: string;
    renewalManagerId?: number;
  };
  newCustomerSubsidiaryId?: number;
  notification?: ProductWebhook;
  secret?: string;
  isUptickEnabled: boolean = true;
  trialSubscriptionConfig?: string;
  tierLabels?: { [P in keyof ProductTier]?: string };

  static mapping: MappingTransform = {
    id: { key: 'id', f: parseIntOrNull },
    custrecordproductfamilycode: 'family.code',
    custrecordproductfamilytitle: 'family.title',
    custrecordproductvariantcode: 'variant.code',
    custrecordproductvarianttitle: 'variant.title',
    custrecordclass: 'nsClass.id',
    classname: 'nsClass.name',
    classfullname: 'nsClass.fullname',
    classrenewalmanager: 'nsClass.renewalManagerId',
    custrecordnewcustomersubsidiary: 'newCustomerSubsidiaryId',
    custrecordnotificationurl: 'notification.url',
    custrecordnotificationusername: 'notification.auth.username',
    custrecordnotificationpassword: 'notification.auth.password',
    custrecordenablerenewalautomation: { key: 'isUptickEnabled', f: convert.toBoolean },
    custrecordsecret: 'secret',
    custrecordtrialsubscriptionconfig: 'trialSubscriptionConfig',
    custrecordtierlabelstandard: `tierLabels.${ProductTier.Standard}`,
    custrecordtierlabelprofessional: `tierLabels.${ProductTier.Professional}`,
    custrecordtierlabelenterprise: `tierLabels.${ProductTier.Enterprise}`,
  };

  static getProductIntegration(
    productFamilyCode: string | undefined,
    productVariantCode: string | undefined
  ): ProductIntegration {
    const pi = this.getProductIntegrationOrDefault(productFamilyCode, productVariantCode);
    if (!pi) {
      throw new Error(
        `Cannot find product integration or more than one found for pfc: ${productFamilyCode}, pvc: ${productVariantCode}.`
      );
    }
    return pi;
  }

  static getProductIntegrationOrDefault(
    productFamilyCode: string | undefined,
    productVariantCode: string | undefined
  ): ProductIntegration | undefined {
    assertNotNull(productFamilyCode, 'productFamilyCode');
    assertNotNull(productVariantCode, 'productVariantCode');
    return ProductIntegration.findProductIntegration(productFamilyCode, productVariantCode);
  }

  static findProductIntegration(pfc: string, pvc: string): ProductIntegration | undefined {
    let sql = `
    SELECT pi.*,c.name as classname, c.fullname as classfullname, c.custrecord_renewal_manager as classrenewalmanager
    FROM customrecordproductintegration pi 
    JOIN classification c on pi.custrecordclass=c.id 
    WHERE LOWER(pi.custrecordproductfamilycode)=?`;
    const params: Array<string> = [pfc.toLowerCase()];
    if (pvc) {
      sql += ' AND LOWER(pi.custrecordproductvariantcode)=?';
      params.push(pvc.toLowerCase());
    } else {
      sql += ' AND pi.custrecordproductvariantcode is null';
    }
    sql += ' OFFSET 0 ROWS FETCH NEXT 1 ROWS ONLY';
    logMayBe('findProductIntegration sql', { sql: sql, params: params });
    const res = queryToJson(sql, params, ProductIntegration.mapping) as unknown as ProductIntegration[];
    logMayBe('findProductIntegration res', res);
    if (res.length === 0) {
      return undefined;
    }
    return res[0];
  }

  static findByClass(classId: number, pvc?: string): ProductIntegration[] {
    let sql = `
    SELECT pi.*,c.name as classname, c.fullname as classfullname 
    FROM customrecordproductintegration pi 
    JOIN classification c on pi.custrecordclass=c.id 
    WHERE c.id=?`;
    const params: SqlParams = [classId];
    if (isNotNull(pvc)) {
      sql += ' and upper(pi.custrecordproductvariantcode)=upper(?)';
      params.push(pvc);
    }
    const res = queryToJson(sql, params, ProductIntegration.mapping) as unknown as ProductIntegration[];
    logMayBe('findByClass res', res);
    return res;
  }

  static findBySubscriptionPlanName(subscriptionPlanName: string): ProductIntegration | undefined {
    const res = (queryFirstToJson(
      `
      SELECT pi.*
      FROM customrecordproductintegration pi
      JOIN subscriptionplan sp on upper(pi.custrecordproductvariantcode) = upper(REGEXP_REPLACE(
        sp.displayname,
        '[^-]+-([^-]+-[^-]+)-.+',
        '\\1'
        )) AND sp.class = pi.custrecordclass
      WHERE sp.itemid = ?
    `,
      [subscriptionPlanName],
      ProductIntegration.mapping
    ) || undefined) as unknown as ProductIntegration;

    logMayBe('findBySubscriptionPlan res', res);
    return res;
  }

  static getBySubscriptionPlanIdOrDefault(subscriptionPlanId: number): ProductIntegration | undefined {
    const res = (queryFirstToJson(
      `
      SELECT pi.*
      FROM customrecordproductintegration pi
      JOIN subscriptionplan sp on upper(pi.custrecordproductvariantcode) = upper(REGEXP_REPLACE(
        sp.displayname,
        '[^-]+-([^-]+-[^-]+)-.+',
        '\\1'
        )) AND sp.class = pi.custrecordclass
      WHERE sp.id = ?
    `,
      [subscriptionPlanId],
      ProductIntegration.mapping
    ) || undefined) as unknown as ProductIntegration;

    logMayBe('findBySubscriptionPlan res', res);
    return res;
  }
}
