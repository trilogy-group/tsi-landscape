import { InputParams, HandlerResponse } from './types';
import * as nsutils from './nsutils';
import { assertNotNull, isNotNull } from './validation';

/**
 * Get product integration endpoint
 */
export function getProductIntegration(params: InputParams): HandlerResponse {
  assertNotNull(params.productFamilyCode);

  let sql = 'SELECT * from customrecordproductintegration WHERE custrecordproductfamilycode=? and ROWNUM <= 1';
  const sqlParams = [params.productFamilyCode];
  if (isNotNull(params.productVariantCode)) {
    sql += ' and custrecordproductvariantcode=?';
    sqlParams.push(params.productVariantCode);
  } else {
    sql += ' and custrecordproductvariantcode is null';
  }
  return {
    content: nsutils.queryToJson(sql, sqlParams, {
      custrecordproductfamilycode: 'family.code',
      custrecordproductfamilytitle: 'family.title',
      custrecordproductvariantcode: 'variant.code',
      custrecordproductvarianttitle: 'variant.title',
      custrecordnotificationurl: 'notification.url',
      custrecordnotificationusername: 'notification.auth.username',
      custrecordnotificationpassword: 'notification.auth.password',
      custrecordsecret: 'secret',
    }),
  };
}
