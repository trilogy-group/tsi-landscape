import {
  InputParams,
  HandlerResponse,
  TypedHandlerResponse,
  SubscriptionStatus,
  SubscriptionTermType,
  Any,
  TermUnit,
  ProductTier,
  SupportLevel,
  OperationUtils,
  ContractualDocumentTypeUtils,
} from './types';
import * as nsutils from './nsutils';
import * as record from 'N/record';
import * as log from 'N/log';
import {
  assertNotNull,
  assertNotNullMsg,
  isNotNull,
  must,
  SubscriptionNotFoundError,
  ValidationError,
} from './validation';
import { DynamicSublistWrapper } from './models/DynamicSublistWrapper';
import { PreviewResponseItem, SubscriptionPreviewResponse } from './models/SubscriptionPreview';
import {
  ChangeOrderParams,
  ChangeQuoteLinkParams,
  FindForCustomerParams,
  FindSuitableSubsidiaryParams,
  ModifyPriceParams,
  ReportUsageParam,
  SetPriceParams,
  SubscriptionConfiguration,
  SubscriptionConfigurationItem,
  SubscriptionConfigurationItemNoQuantityReq,
  SubscriptionConfigurationNoQuantityReq,
  SubscriptionCreateParams,
  SubscriptionParams,
  SubscriptionPreviewParams,
  SubscriptionTerminateParams,
  SubscriptionUpdateOrRenewParams,
  SubscriptionUpdateParams,
  SubscriptionUpdateStatusParams,
  UploadContractualDocumentParams,
  zeroDiscounts,
  GetRenewalInfoParams,
  GetSubscriptionsToSyncParams,
} from './models/SubscriptionParams';
import customerDao from './dao/CustomerDao';
import subscriptionDao from './dao/SubscriptionDao';
import subscriptionPlanDao from './dao/SubscriptionPlanDao';
import subscriptionChangeOrderUtility from './utility/SubscriptionChangeOrderUtility';
import subscriptionCreateUtility from './utility/SubscriptionCreateUtility';
import subscriptionGetUtility from './utility/SubscriptionGetUtility';
import subscriptionGetRenewalInfoUtility from './utility/SubscriptionGetRenewalInfoUtility';
import subscriptionPlanUtility from './utility/SubscriptionPlanUtility';
import subscriptionItemUtility, { ItemCode } from './utility/SubscriptionItemUtility';
import subscriptionPriceUtility from './utility/SubscriptionPriceUtility';
import subscriptionUpdateUtility from './utility/SubscriptionUpdateUtility';
import subscriptionValidateUtility from './utility/SubscriptionValidateUtility';
import subscriptionUsageUtility from './utility/SubscriptionUsageUtility';
import { SubscriptionRecord } from './models/SubscriptionRecord';
import { clone, roundMoney } from './utility/GeneralUtility';
import SubscriptionStatusService from './utility/SubscriptionStatusService';
import SubscriptionUtility from './utility/SubscriptionUtility';
import { ProductIntegration } from './ProductIntegration';
import { ApiSubscription } from './models/apitypes';
import {
  PlanInfo,
  PriceTierType,
  SubscriptionItem,
  SubscriptionPlan,
  SubscriptionPlanItem,
} from './models/SubscriptionPlan';
import fileService, { Folder } from './utility/FileService';
import ContractualDocumentsService from './utility/ContractualDocumentsService';

interface Item {
  code: string,
  bundleCode?: string,
  supportCode?: string,
  quantity: number,
  isMainItem: boolean,
  lineNumber?: number,
  isSupportItem?: boolean,
  isSupportMainItem?: boolean,
  ARR: number,
  productTier?: ProductTier,
  supportLevel?: SupportLevel
}

export class SubscriptionService {
  get(params: SubscriptionParams): HandlerResponse {
    return {
      content: subscriptionGetUtility.getSubscriptionByIdForCustomer(
        params.subscriptionId,
        must(params.customerId, 'customerId')
      ),
    };
  }

  // Return the subscription items in salesforce bundle format
  internalGetItems(params: SubscriptionParams): HandlerResponse {
    const subscriptionRecord = record.load({
      type: record.Type.SUBSCRIPTION,
      id: must(params.subscriptionId),
    });
    const subscriptionSnapshot = clone(subscriptionRecord);
    const subscriptionPlan = subscriptionPlanUtility.getSubscriptionPlanById(
      parseInt(subscriptionSnapshot.fields.subscriptionplan)
    );

    const priceLines = subscriptionGetUtility.convertLinesToArray(subscriptionSnapshot.sublists.priceinterval);
    const subscriptionLines = subscriptionGetUtility.convertLinesToArray(subscriptionSnapshot.sublists.subscriptionline);
    const items = this.getItemsFromSnapshot(subscriptionLines, priceLines, subscriptionPlan);
    const mergedItems = this.mergeItems(items).sort((a,b) => (a.lineNumber as number) - (b.lineNumber as number));
    if (mergedItems.length === 0) {
      return {
        content: {
          items: []
        }
      }
    }

    // if there is no main item found by code, considering as the main item the first or second item in the subscription if included
    const mainItem = mergedItems.find(i => i.isMainItem || i.isSupportMainItem);
    if (mainItem) {
      mainItem.isMainItem = true;
    }
    const secondLineNumber = 2;
    if (!mainItem && (mergedItems[0].lineNumber as number) <= secondLineNumber) {
      mergedItems[0].isMainItem = true;
    }
    for (const item of mergedItems) {
      this.mapItemToView(item, subscriptionPlan);
    }
    return {
      content: {
        items: mergedItems
      }
    };
  }

  private mapItemToView(item: Item, subscriptionPlan: SubscriptionPlan) {
    const codeSize = 3;
    // format bundle code
    const itemCode = new ItemCode(item.code);
    const itemSupportLevel = item.supportLevel ?? subscriptionPlan.supportLevel;
    const itemSupportLevelCode = itemSupportLevel ? itemSupportLevel.substring(0,codeSize).toUpperCase() : 'SIL';
    const itemProductTier = item.productTier ?? subscriptionPlan.productTier;
    const itemProductTierCode = itemProductTier ? itemProductTier.substring(0,codeSize).toUpperCase() : 'STA';
    if (itemCode.isValid) {
      if (item.isSupportItem) {
        item.bundleCode =  `${itemCode.codeWOSuffix()}-${itemProductTierCode}-${itemSupportLevelCode}-MNT`;
      } else {
        item.bundleCode =  `${item.code}-${itemSupportLevelCode}`;
      }
    }

    // formatting numbers
    const decimalPlaces = 2;
    item.ARR = parseFloat(item.ARR.toFixed(decimalPlaces));

    // removing properties that we don't want to return
    delete item.isSupportItem;
    delete item.isSupportMainItem;
    delete item.productTier;
    delete item.supportLevel;
    delete item.lineNumber;
  }

  //get active pricelines with basic information OR all items for subscription that was never activated
  private getItemsFromSnapshot(subscriptionLines, priceLines, subscriptionPlan: SubscriptionPlan): Item[] {
    // if any item is active it means subscription was activated
    const subscriptionHasBeenActivated = !!priceLines.find(i => i.status === 'ACTIVE');

    // Sort items by startdate
    const sortedItems = priceLines.sort((a, b) => new Date(b.startdate).getTime() - new Date(a.startdate).getTime());

    // filter out terminated price lines that are terminated when the subscription line is active
    // this is to prevent an active subscription to show 0 arr if termination is in future
    let filteredItems = sortedItems.filter(item => {
      const subscriptionLine = subscriptionLines.find(i => i.linenumber === item.linenumber);
      if (subscriptionLine && subscriptionLine.status === 'ACTIVE' && item.status === 'TERMINATED') {
        return false;
      }
      return true;
    });

    // Keep only the last occurrence of each linenumber
    const linenumberSet = new Set();
    filteredItems = filteredItems.filter(item => {
      if (!linenumberSet.has(item.linenumber)) {
        linenumberSet.add(item.linenumber);
        return true;
      }
      return false;
    });

    const statusToFilterOut = ['NOT_INCLUDED','TERMINATED','SUSPENDED'];
    // if subscription has been activated, not getting pending activation and draft items
    if (subscriptionHasBeenActivated) {
      statusToFilterOut.push(...['PENDING_ACTIVATION','DRAFT']);
    }

    // Filter out NOT INCLUDED and TERMINATED
    filteredItems = filteredItems.filter(item => !statusToFilterOut.includes(item.status));

    return filteredItems.map(i => {
      const itemCode = new ItemCode(i.item_display);
      return {
        code: i.item_display,
        lineNumber: parseInt(i.linenumber),
        quantity: i.quantity ? parseInt(i.quantity) : 0,
        isSupportItem: itemCode.isSupport(),
        isMainItem: i.item_display === subscriptionPlan.mainItemCode,
        isSupportMainItem: i.item_display === subscriptionPlan.supportItemCode,
        ARR: this.getItemARR(parseFloat(i.recurringamount), i.frequency, i.repeatevery),
        productTier: itemCode.productTier(),
        supportLevel: itemCode.supportLevel()
      }
    });
  }

  private getItemARR(recurringAmount: number, frequency: string, repeatEvery: number): number {
    let frequencyMultiplier;
    switch (frequency.toUpperCase()) {
      case 'MONTHLY':
        frequencyMultiplier = 12;
        break;
      case 'WEEKLY':
        frequencyMultiplier = 52;
        break;
      default: //ANNUALLY OR ANY OTHER NOT HANDLED
        frequencyMultiplier = 1;
    }

    return recurringAmount * frequencyMultiplier / repeatEvery;
  }

  //merge items that have the same key summing up the quantity and discarding supporting items that have a main item
  private mergeItems(items: Item[]): Item[] {
    const itemMap = new Map<string, Item>();
    const supportItems: Item[] = [];
    const itemsNotMapped: Item[] = [];

    for (const item of items) {
      if (item.ARR < 0) {
        item.quantity = item.quantity * -1;
      }
      const itemCode = new ItemCode(item.code);
      if (!itemCode.isValid) {
        itemsNotMapped.push(item);
        continue;
      }

      if (item.isSupportItem) {
        supportItems.push(item);
      } else {
        this.mergeProductItem(itemMap, item, itemCode);
      }
    }
    this.mergeSupportItems(itemMap, supportItems);
    const mergedItems: Item[] = Array.from(itemMap.values());
    mergedItems.push(...itemsNotMapped);
    return mergedItems;
  }

  private mergeProductItem(itemMap: Map<string, Item>, item: Item, itemCode: ItemCode) {
    const key = itemCode.codeWOSuffix();
    if (itemMap.has(key)) {
      const existingItem = itemMap.get(key) as Item;
      existingItem.quantity += item.quantity;
      existingItem.isMainItem = existingItem.isMainItem || item.isMainItem;
      existingItem.ARR += item.ARR;
      if (!existingItem.productTier && item.productTier) {
        existingItem.productTier = item.productTier;
        existingItem.code = item.code;
      }
    } else {
      itemMap.set(key, { ...item });
    }
  }

  private mergeSupportItem(itemMap: Map<string, Item>, item: Item, key: string) {
    const existingItem = itemMap.get(key) as Item;
    if (existingItem.isSupportItem) {
      existingItem.quantity += item.quantity;
      existingItem.isSupportMainItem = existingItem.isSupportMainItem || item.isSupportMainItem;
    } else {
      existingItem.isMainItem = existingItem.isMainItem || item.isSupportMainItem as boolean;
      if (!existingItem.supportLevel && item.supportLevel) {
        existingItem.supportLevel = item.supportLevel;
        existingItem.supportCode = item.code;
      }
    }
    existingItem.ARR += item.ARR;
  }

  private mergeSupportItems(itemMap: Map<string, Item>, supportItems: Item[]) {
    for (const item of supportItems) {
      const itemCode = new ItemCode(item.code);
      const key = itemCode.codeWOSuffix();
      if (!itemMap.has(key)) {
        itemMap.set(key, { ...item });
      } else {
        this.mergeSupportItem(itemMap, item, key);
      }
    }
  }

  findForCustomer(params: FindForCustomerParams): HandlerResponse {
    nsutils.logMayBe('findForCustomer params', params);
    assertNotNull(params.customerId, 'customerId');
    const customerSubscriptionIds = subscriptionDao.getCustomerSubscriptionIds(params.customerId, {
      productFamilyCode: must(params.productFamilyCode, 'productFamilyCode'),
      productVariantCode: params.productVariantCode,
      statuses: params.statuses,
      maxResults: params.maxResults,
    });
    const res: unknown[] = [];
    for (const subscriptionId of customerSubscriptionIds) {
      res.push(subscriptionGetUtility.getSubscriptionByIdForCustomer(subscriptionId.id, params.customerId));
    }
    return { content: res };
  }

  create(params: SubscriptionCreateParams, trial = false): HandlerResponse {
    return {
      content: subscriptionCreateUtility.createSubscription(params, {
        trial,
        discounts: zeroDiscounts,
      }),
    };
  }

  internalCreateActiveSubscription(params: SubscriptionCreateParams, trial = false): HandlerResponse {
    return {
      content: subscriptionCreateUtility.createSubscription(params, {
        trial,
        discounts: { mainItemDiscount: 0, addons: [] },
        activate: true,
      }),
    };
  }

  internalTerminateSubscription(params: SubscriptionTerminateParams): HandlerResponse {
    const terminateOrder = subscriptionChangeOrderUtility.terminateSubscriptionChangeOrder(
      must(params.subscriptionId, 'subscriptionId'),
      params.date,
      params.itemCodes,
      true
    );
    terminateOrder.save();

    return {
      content: subscriptionGetUtility.getSubscriptionByIdForCustomer(
        params.subscriptionId,
        must(params.customerId, 'customerId')
      ),
    };
  }

  createDraftRenewal(params: SubscriptionParams): HandlerResponse {
    nsutils.logMayBe('createDraftRenewal params', params);
    assertNotNull(params.subscriptionId, 'subscriptionId');
    const activeSubscription = record.load({
      type: record.Type.SUBSCRIPTION,
      id: params.subscriptionId,
      isDynamic: true,
    });
    const status = activeSubscription.getValue('billingsubscriptionstatus') as string;
    if (status.toUpperCase() !== 'ACTIVE') {
      throw new Error('Subscription must be active to create a draft renewal');
    }
    const values = {
      renewalmethod: 'CREATE_NEW_SUBSCRIPTION',
    };
    const changeOrder = subscriptionChangeOrderUtility.createRenewChangeOrder(params.subscriptionId, values);
    nsutils.logMayBe('createDraftRenewal changeOrder', changeOrder);
    const subscriptionId = subscriptionChangeOrderUtility.getSubscriptionIdFromRenewChangeOrder(changeOrder);
    nsutils.logMayBe('createDraftRenewal subscriptionId', subscriptionId);
    return { content: subscriptionGetUtility.getSubscriptionByIdInternal(subscriptionId) };
  }

  updateOrRenew(params: SubscriptionUpdateOrRenewParams, activate: boolean = false): HandlerResponse {
    nsutils.logMayBe('updateOrRenew params', params);
    subscriptionValidateUtility.validateAndPrepareUpdateData(params);
    const subscriptionRec = SubscriptionRecord.load(params.subscriptionId!);
    const subscriptionRecWithFields = record.load({ type: record.Type.SUBSCRIPTION, id: params.subscriptionId! });
    const subscriptionSnapshot = clone(subscriptionRecWithFields);
    const status = subscriptionSnapshot.fields.billingsubscriptionstatus;
    const { subscriptionItems } = subscriptionGetUtility.getSubscriptionRecItems(subscriptionSnapshot);
    const newPlan = subscriptionPlanUtility.getSubscriptionPlanById(must(params.content?.planId));
    const items = this.getItemsWithQuantity(
      [...subscriptionItems.availableItems, ...subscriptionItems.supportItems],
      newPlan,
      params.content?.items
    );
    const updateParams: SubscriptionUpdateParams = { ...params, content: { ...params.content, items: items } };
    nsutils.logMayBe('updateOrRenew updateParams', updateParams);

    subscriptionValidateUtility.validateSubscriptionItems(updateParams);
    subscriptionValidateUtility.validateActiveSubscriptionHasNoDrafts(updateParams.subscriptionId!, status);

    // Fill the End User, Distributor and Reseller fields to preserve the values
    if (updateParams.content) {
      if (subscriptionRec.distributorInternalId) {
        updateParams.content.distributorId = subscriptionRec.distributorId;
      }
      if (subscriptionRec.resellerInternalId) {
        updateParams.content.resellerId = subscriptionRec.resellerId;
      }
      updateParams.content.endUserInternalId = subscriptionRec.endUserInternalId;
    }
    switch (status) {
      case SubscriptionStatus.ACTIVE: {
        return subscriptionUpdateUtility.update(params, subscriptionRec, activate);
      }
      case SubscriptionStatus.DRAFT:
        if (subscriptionRec.initialTermType === SubscriptionTermType.EVERGREEN) {
          throw new ValidationError('Cannot renew EVERGREEN subscription', 'subscriptionId');
        }
        return subscriptionUpdateUtility.renew(updateParams, subscriptionRec);
      default:
        throw new Error(`Not possible to use this method in subscription with status ${status}`);
    }
  }

  internalDeleteDraftSubscription(params: SubscriptionParams): HandlerResponse {
    const subscriptionId = must(params.subscriptionId, 'subscriptionId');
    const subscriptionRecord = SubscriptionRecord.load(subscriptionId, true);
    //checking first if it is a draft subscription because the method to delete will try to delete the related objects(ex: quotes) first
    // and it will only fail to delete the subscription after all related objects are deleted
    if (subscriptionRecord.status !== SubscriptionStatus.DRAFT) {
      return {
        content: {
          success: false,
          error: 'You cannot delete this subscription. The subscription is not in draft status.',
        },
      };
    }

    // checking if the subscription has some price line with ACTIVE or TERMINATED status which indicates that an active or termination change order exists
    // and if it exists the subscription can't be deleted.
    // The status can be Draft because it has one item on draft status and all other items are terminated or closed.
    let hasActiveOrTerminationChangeOrder = false;
    subscriptionRecord.processSublist('priceinterval',(priceLine) => {
      while (priceLine.nextLine()) {
        const status = priceLine.getFieldValue('status');
        if (status === 'ACTIVE' || status === 'TERMINATED') {
          hasActiveOrTerminationChangeOrder = true;
          break;
        }
      }
    });
    if (hasActiveOrTerminationChangeOrder) {
      return {
        content: {
          success: false,
          error: 'You cannot delete this subscription. The subscription has an activation or termination change order.',
        },
      };
    }

    try {
      SubscriptionUtility.deleteDraftSubscription(subscriptionId);
      return { content: { success: true } };
    } catch (ex: Any) {
      // Additional information for debug purposes
      nsutils.logDebug(`Exception: ${ex.message}`, ex);
      return { content: { success: false, error: ex.message } };
    }
  }

  internalUpdateAndActivate(params: SubscriptionUpdateParams): HandlerResponse {
    return this.updateOrRenew(params, true);
  }

  internalActivate(params: SubscriptionParams): HandlerResponse {
    SubscriptionStatusService.internalActivate(params.subscriptionId);
    return { content: true };
  }

  internalCreateRenewalChangeOrder(params: ChangeOrderParams): HandlerResponse {
    const values = {
      renewalmethod: params.renewalMethod,
      modificationtype: params.modificationType,
      renewalterm: params.renewalTerm,
      subline: params.subline
    };
    if (params.renewalPlan) {
      values["renewalplan"] = params.renewalPlan;
    }
    if (params.renewalPriceBook) {
      values["renewalpricebook"] = params.renewalPriceBook;
    }
    if (params.customer) {
      values["customer"] = params.customer;
    }
    if (params.billingAccount) {
      values["billingaccount"] = params.billingAccount;
    }
    const renewalOrder = subscriptionChangeOrderUtility.createRenewChangeOrder(params.subscriptionId, values);
    return { content: {
      changeOrderId: renewalOrder.id
    }};
  }

  updateStatus(params: SubscriptionUpdateStatusParams): HandlerResponse {
    nsutils.logMayBe('updateStatus', params);
    assertNotNull(params.customerId, 'customerId');
    assertNotNull(params.subscriptionId, 'subscriptionId');
    assertNotNull(params.content?.status, 'status');

    const subscriptionRec = SubscriptionRecord.load(params.subscriptionId);
    if (!subscriptionRec.isWritableForCustomer(params.customerId)) {
      throw new SubscriptionNotFoundError();
    }

    const status = params.content.status.toUpperCase();

    switch (status) {
      case SubscriptionStatus.ACTIVE:
        // assuming that PENDING_ACTIVATION always accompanied by activation CO
        if (
          subscriptionRec.status !== SubscriptionStatus.ACTIVE &&
          subscriptionRec.status !== SubscriptionStatus.PENDING_ACTIVATION
        ) {
          SubscriptionStatusService.activate(subscriptionRec);
        }
        break;
      default:
        throw new ValidationError(`Status ${params.content.status} not allowed`, 'status');
    }

    return { content: subscriptionGetUtility.getSubscriptionByIdForCustomer(params.subscriptionId, params.customerId) };
  }

  preview(params: SubscriptionPreviewParams): TypedHandlerResponse<SubscriptionPreviewResponse> {
    nsutils.logMayBe('preview params', params);
    assertNotNull(params.customerId, 'customerId');
    assertNotNull(params.content, 'content');
    const config = params.content;
    assertNotNull(config.planCode, 'planCode');
    assertNotNull(config.items, 'items');
    assertNotNull(config.frequency, 'frequency');
    params.content.items = params.content.items?.filter((x) => x.quantity !== 0); // Ignore zero quantity items

    const subscriptionPlanInfo = nsutils.queryFirstAsMap(`select id, itemid from subscriptionplan where itemid=?`, [
      config.planCode,
    ]);
    assertNotNullMsg(subscriptionPlanInfo.id, 'Invalid plan code');

    // Find the currency to use for the preview from the subscription if provided, otherwise from the customer.
    const { id: currencyId, symbol: currency } = params.subscriptionId
      ? subscriptionDao.getCurrency(params.subscriptionId)
      : customerDao.getPrimaryCurrency(params.customerId);

    // Load the subscription plan, then sum the product and support prices into the product items.
    const newPlan = subscriptionPlanUtility.getSubscriptionPlanById(subscriptionPlanInfo.id);
    subscriptionPlanUtility.addSupportPricesToItems(newPlan);

    // Disregard support items from the input.
    params.content.items = params.content.items?.filter((i) => {
      const planItem = newPlan.items.find((ic) => ic.code === i.code);
      assertNotNullMsg(planItem, `Invalid item code or no pricing for item '${i.code}'`);
      return !(planItem.isSupportAddonItem || (!newPlan.supportOnly && planItem.isSupportMainItem));
    });

    nsutils.logMayBe('preview planItems planOptions', newPlan);

    if (params.subscriptionId) {
      subscriptionValidateUtility.validateAndPrepareUpdateData(params);
      const subscription = subscriptionGetUtility.getSubscriptionByIdInternal(params.subscriptionId);
      const subscriptionRec = record.load({ type: record.Type.SUBSCRIPTION, id: subscription.id });
      const subscriptionSnapshot = clone(subscriptionRec);
      const { subscriptionItems } = subscriptionGetUtility.getSubscriptionRecItems(subscriptionSnapshot);

      const items = this.getItemsWithQuantity(
        [...subscriptionItems.availableItems, ...subscriptionItems.supportItems],
        newPlan,
        config.items
      );
      const updateParams: SubscriptionUpdateParams = { ...params, content: { ...params.content, items: items } };
      subscriptionValidateUtility.validateSubscriptionItems(updateParams);

      const currentPlanInfo = subscriptionPlanUtility.getSubscriptionPlanInfoById(subscription.plan.id);

      switch (subscription.status.toLowerCase()) {
        // we are doing upgrade and uptick shouldn't be applied
        case 'active': {
          return this.previewForUpgradeSubscription(
            subscription,
            newPlan,
            currency,
            items,
            config.frequency,
            config.duration,
            currentPlanInfo,
            params
          );
        }

        // we are doing a renewal and need to apply an uptick
        case 'draft': {
          const pi = ProductIntegration.getProductIntegration(
            updateParams.productFamilyCode,
            updateParams.productVariantCode
          );
          return this.previewForDraftRenewalSubscription(
            subscription,
            newPlan.items,
            currency,
            currencyId,
            subscriptionPlanInfo.id,
            items,
            config.frequency,
            pi.isUptickEnabled,
            must(currentPlanInfo.isLegacyPlan),
            params,
            config.duration
          );
        }
        default:
          throw new Error(`Not possible to use this method in subscription with status ${subscription.status}`);
      }
    } else {
      const previewConfig = this.validateAndGetPreviewConfigWithRequiredQuantity(config);
      return this.previewFromScratch(previewConfig, newPlan, currency, params);
    }
  }

  private getQuantityFromItemOrFromExistingSubscription(
    newItem: SubscriptionConfigurationItemNoQuantityReq,
    newPlan: SubscriptionPlan,
    subscriptionItems: SubscriptionItem[]
  ): number {
    if (isNotNull(newItem.quantity)) {
      return newItem.quantity;
    }

    const newPlanItem = newPlan.items.find((i) => i.code === newItem.code);
    assertNotNullMsg(newPlanItem, `requested item code ${newItem.code} is missing in the plan ${newPlan.name}`);
    // get the quantity from main item of existing subscription
    if (newPlanItem.isMainItem) {
      const existingMainItem = subscriptionItems.find((i) => i.isMainItem === true);
      if (existingMainItem) return existingMainItem.quantity;
      throw new ValidationError(
        `quantity of the main item with code ${newItem.code} was not found in the subscription`
      );
    } else if (newPlanItem.isSupportMainItem) {
      // just in case of some weird cases when support item quantity is not equal to main item quantity,
      // try to get the quantity from support item first
      let existingItem = subscriptionItems.find((i) => i.isSupportMainItem === true);
      if (existingItem) return existingItem.quantity;
      existingItem = subscriptionItems.find((i) => i.isMainItem === true);
      if (existingItem) return existingItem.quantity;
      throw new ValidationError(
        `quantity of the support item with code ${newItem.code} was not found in the subscription`
      );
    } else {
      const existingItem = subscriptionItems.find((i) => i.code === newItem.code);
      if (existingItem) return existingItem.quantity;
      throw new ValidationError(`quantity of the item with code ${newItem.code} was not found in the subscription`);
    }
  }

  private getItemsWithQuantity(
    subscriptionItems: SubscriptionItem[],
    newPlan: SubscriptionPlan,
    newItems?: SubscriptionConfigurationItemNoQuantityReq[]
  ): SubscriptionConfigurationItem[] {
    nsutils.logMayBe('getItemsWithQuantity params', { subscriptionItems, items: newItems });
    if (newItems) {
      const itemsWithQuantities = newItems?.map((newItem) => {
        return {
          code: newItem.code,
          id: newItem.id,
          quantity: this.getQuantityFromItemOrFromExistingSubscription(newItem, newPlan, subscriptionItems),
        } as SubscriptionConfigurationItem;
      });
      nsutils.logMayBe('getItemsWithQuantity res', itemsWithQuantities);
      return itemsWithQuantities;
    } else {
      return [];
    }
  }

  validateAndGetPreviewConfigWithRequiredQuantity(
    config: SubscriptionConfigurationNoQuantityReq
  ): SubscriptionConfiguration {
    const previewConfig: SubscriptionConfiguration = {
      ...config,
      items: config.items?.map((x) => {
        assertNotNull(x.quantity, `quantity for the item wiht code ${x.code}`);
        if (Number.isNaN(x.quantity) || x.quantity < 0) {
          throw new ValidationError(`quantity should be a non-negative number for the item with code ${x.code}`);
        }
        return {
          code: x.code,
          id: x.id,
          quantity: x.quantity,
        };
      }),
    };

    return previewConfig;
  }

  previewFromScratch(
    config: SubscriptionConfiguration,
    plan: SubscriptionPlan,
    currency: string,
    previewParams: SubscriptionPreviewParams
  ): TypedHandlerResponse<SubscriptionPreviewResponse> {
    nsutils.logMayBe('previewFromScratch params', { config, plan, currency });
    assertNotNull(config.frequency, 'frequency');
    const frequency = config.frequency!;
    let resItems;
    if (config.items) {
      resItems = config.items.map((i) => {
        const planItem = plan.items.find((pi) => pi.code === i.code);
        assertNotNullMsg(planItem, `Invalid item code or no pricing for item '${i.code}'`);

        return {
          code: planItem.code,
          title: planItem.title,
          quantity: i.quantity,
          amounts: subscriptionPriceUtility.calcItemTotalPrice(
            planItem,
            null,
            i.quantity,
            currency,
            frequency,
            this.getDurationInMonth(plan.initialterm.duration, TermUnit[plan.initialterm.unit], config.duration)
          ),
        };
      });
    }
    return this.getPreviewResponse(resItems, frequency, plan, previewParams);
  }

  previewForUpgradeSubscription(
    subscription: ApiSubscription,
    newPlan: SubscriptionPlan,
    currency: string,
    newItems: SubscriptionConfigurationItem[],
    frequency: string,
    duration: number | undefined,
    currentPlanInfo: PlanInfo,
    previewParams: SubscriptionPreviewParams
  ): TypedHandlerResponse<SubscriptionPreviewResponse> {
    nsutils.logMayBe('previewForUpgradeSubscription params', {subscription, newPlan, currency, newItems, frequency, duration, currentPlanInfo, previewParams});
    const subscriptionRec = SubscriptionRecord.load(subscription.id);
    const { isDowngrade } = subscriptionValidateUtility.validateUpdateActive(
      subscription.id,
      duration,
      currentPlanInfo,
      newPlan,
      newItems,
      subscriptionRec.initialTermType
    );
    const discounts = subscriptionPriceUtility.getDiscountForUpdate(
      subscriptionRec.initialTermType,
      isDowngrade,
      subscription.id,
      subscription
    );

    nsutils.logMayBe('previewForUpgradeSubscription params calculated', {isDowngrade, discounts});
    let resItems;
    if (newItems) {
      resItems = newItems.map((i) => {
        const planItem = newPlan.items.find((pi) => pi.code === i.code);
        assertNotNullMsg(planItem, `Cant find plan item by code: '${i.code}'`);

        return {
          code: planItem.code,
          title: planItem.title,
          quantity: i.quantity,
          amounts: subscriptionPriceUtility.calcItemTotalPrice(
            planItem,
            null,
            i.quantity,
            currency,
            frequency,
            this.getDurationInMonth(subscriptionRec.initialTermDuration, subscriptionRec.initialTermUnits, duration),
            discounts
          ),
        };
      });
    }
    nsutils.logMayBe('previewForUpgradeSubscription resItems', resItems);
    return this.getPreviewResponse(resItems, frequency, newPlan, previewParams);
  }

  previewForDraftRenewalSubscription(
    subscription: ApiSubscription,
    planItems: SubscriptionPlanItem[],
    currency: string,
    currencyId: number,
    newPlanId: number,
    requestedPlanItems: SubscriptionConfigurationItem[],
    frequency: string,
    isUptickEnabled: boolean,
    isCurrentLegacyPlan: boolean,
    previewParams: SubscriptionPreviewParams,
    duration?: number,
  ): TypedHandlerResponse<SubscriptionPreviewResponse> {
    nsutils.logMayBe('previewForDraftRenewalSubscription params', {
      subscription,
      planItems,
      currency,
      currencyId,
      newPlanId,
      requestedPlanItems,
      frequency,
      isUptickEnabled,
      isCurrentLegacyPlan,
    });
    if (!subscription.parentSubscription) {
      throw new Error(`Failed to get parent subscription of subscription with id: ${subscription.id}`);
    }
    const parentSubscription = subscriptionGetUtility.getSubscriptionByIdInternal(subscription.parentSubscription);

    const subscriptionSnapshot = clone(record.load({ type: record.Type.SUBSCRIPTION, id: subscription.id }));
    const { plan: draftPlan, subscriptionItems: draftItems } =
      subscriptionGetUtility.getSubscriptionRecItems(subscriptionSnapshot);

    nsutils.logMayBe('previewForDraftRenawalSubscription subscriptionRec', subscriptionSnapshot);

    const parentPlanInfo = subscriptionPlanUtility.getSubscriptionPlanInfoById(parentSubscription.plan.id);

    this.applyNewPlanOnExistingSubscription(
      newPlanId,
      requestedPlanItems,
      planItems,
      currencyId,
      frequency,
      subscriptionSnapshot,
      isCurrentLegacyPlan
    );
    nsutils.logMayBe('previewForDraftRenawalSubscription subscriptionRec new plan applied', subscriptionSnapshot);

    // get new subscription info
    const { plan: newPlan, subscriptionItems: virtualSubscriptionItems } =
      subscriptionGetUtility.getSubscriptionRecItems(subscriptionSnapshot);

    const newFrequency = subscriptionPlanDao.getFrequencyFromPriceBook(subscriptionSnapshot.fields.pricebook);

    const uptickedPrices = subscriptionPriceUtility.calcModifiedPrices(
      isUptickEnabled,
      false,
      true,
      false,
      newPlan,
      newFrequency,
      virtualSubscriptionItems,
      draftItems,
      draftPlan,
      subscription.parentSubscription,
      parentSubscription,
      parentPlanInfo
    );
    nsutils.logMayBe('preview previewForDraftRenawalSubscription uptickedPrices', uptickedPrices);

    let resItems;
    if (requestedPlanItems) {
      resItems = requestedPlanItems.map((i) => {
        const planItem = planItems.find((pi) => pi.code === i.code);
        assertNotNullMsg(planItem, `Invalid item code or no pricing for item '${i.code}'`);
        const uptickedPrice = uptickedPrices ? uptickedPrices.find((up) => up.id === planItem.id) : null;
        if (uptickedPrices) {
          assertNotNullMsg(
            uptickedPrice,
            `Can't find upticked price for item '${i.code}'. uptickedPrices: ${JSON.stringify(uptickedPrices)}, ` +
              `planItem: ${JSON.stringify(planItem)}`
          );
        }

        return {
          code: planItem.code,
          title: planItem.title,
          quantity: i.quantity,
          amounts: subscriptionPriceUtility.calcItemTotalPrice(
            planItem,
            uptickedPrice,
            i.quantity,
            currency,
            frequency,
            this.getDurationInMonth(
              subscription.term.initialTermDuration!,
              subscription.term.initialTermUnits!,
              duration
            )
          ),
        };
      });
    }
    return this.getPreviewResponse(resItems, frequency, newPlan, previewParams);
  }

  getDurationInMonth(termDuration: number, termUnits?: TermUnit, configDuration?: number): number {
    nsutils.logMayBe('getDuration params', {
      termDuration,
      termUnits,
      configDuration,
    });
    if (configDuration) {
      nsutils.logMayBe('getDuration returns requested duration', configDuration);
      return configDuration!;
    }
    if (!termUnits) {
      nsutils.logMayBe('getDuration res', 0);
      return 0;
    }
    let res: number;
    switch (termUnits) {
      case TermUnit.MONTHS:
        res = termDuration;
        break;
      case TermUnit.YEARS:
        res = termDuration * 12;
        break;
      case TermUnit.DAYS:
        res = (termDuration * 12) / 365;
        break;
      case TermUnit.WEEKS:
        res = termDuration / 4;
        break;
      default:
        throw new Error(`Not implemented for: ${termUnits}`);
    }

    nsutils.logMayBe('getDuration res', res);
    return res;
  }

  // TODO we need to refactor calcUptickPrices to remove dependency on subscriptionRec and parentSubscription.
  // It's a bad design when we pass superfluous data into the underlying methods. This way we hide dependency and complicate the usage.
  // The calcUptickPrices needs to be dependent on old and new plan, discounts, and new plan items only.
  // The rule of thumb, is to pass only the data, that the method needs to perform its duties
  // When it is refactored, this method may be removed so it has some code duplication
  private applyNewPlanOnExistingSubscription(
    newPlanId: number,
    requestedItems: SubscriptionConfigurationItem[] | undefined,
    planItems: SubscriptionPlanItem[],
    currencyId: number,
    frequency: string,
    subscriptionRec,
    isLegacyPlan: boolean
  ): SubscriptionConfigurationItem[] {
    nsutils.logMayBe('applyNewPlanOnExistingSubscription params', {
      newPlanId,
      requestedItems,
      planItems,
      currencyId,
      frequency,
      subscriptionRec,
      isLegacyPlan,
    });
    subscriptionRec.fields.subscriptionplan = newPlanId.toString();
    subscriptionRec.fields.currency = currencyId.toString();

    // remove the items missing in the new plan and update the quantity for the present item
    this.removeMissingAndUpdateExistingPlanItems(
      subscriptionRec.sublists.priceinterval,
      true,
      requestedItems,
      frequency,
      planItems,
      isLegacyPlan
    );

    // remove the items missing in the new plan and update the quantity for the present item
    this.removeMissingAndUpdateExistingPlanItems(
      subscriptionRec.sublists.subscriptionline,
      false,
      requestedItems,
      frequency,
      planItems,
      isLegacyPlan
    );

    // find new plan items to add
    const currentItemCodes = Object.keys(subscriptionRec.sublists.subscriptionline)
      .filter((k) => k.indexOf('line ') === 0)
      .map((k) => subscriptionRec.sublists.subscriptionline[k].item_display);

    const newPlanItemsToAdd: SubscriptionConfigurationItem[] = [];
    requestedItems?.forEach((pi) => {
      if (currentItemCodes.length === 0 || !currentItemCodes?.some((c) => c.toLowerCase() === pi.code.toLowerCase())) {
        newPlanItemsToAdd.push(pi);
      }
    });

    // add new plan items
    if (newPlanItemsToAdd.length > 0) {
      const lineNumbers = Object.keys(subscriptionRec.sublists.subscriptionline)
        .filter((k) => k.indexOf('line ') === 0)
        .map((l) => parseInt(l.replace('line ', '')));
      let maxLineNumber = lineNumbers.length === 0 ? 0 : lineNumbers.max((n) => n);

      nsutils.logMayBe('applyNewPlanOnExistingSubscription max line', maxLineNumber);

      // add new plan items
      newPlanItemsToAdd?.forEach((pi) => {
        maxLineNumber = maxLineNumber + 1;
        const key = `line ${maxLineNumber}`;

        const planItem = planItems.find((i) => pi.code === i.code);
        assertNotNullMsg(planItem, `Cant find plan item by code: '${pi.code}'`);

        nsutils.logMayBe('applyNewPlanOnExistingSubscription add', { pi, planItem });

        subscriptionRec.sublists.subscriptionline[key] = {
          item_display: pi.code,
          item: planItem.id.toString(),
          isrequired: planItem.required ? 'T' : 'F',
          isincluded: 'T',
          status: 'DRAFT',
          subscriptionlinetype: planItem.typeId.toString(),
          linenumber: maxLineNumber,
        };
        subscriptionRec.sublists.priceinterval[key] = {
          frequency: frequency.toUpperCase(),
          // the value doesn't metter as we are going to recalculated it. just should be not 0 to be included
          recurringamount: '1',
          totalintervalvalue: '1',
          quantity: pi.quantity.toString(),
          // the price plan id doesn't metter as we are going to recalculated it. just should be not empty
          priceplan: planItem.prices[0]?.ranges[0]?.priceplanid?.toString(),
          item: planItem.id.toString(),
          linenumber: maxLineNumber,
          // dummy date, id doesn't metter as we are going to recalculated it. just should be not empty
          startdate: '1-Jan-2020',
        };
      });
    }

    nsutils.logMayBe('applyNewPlanOnExistingSubscription subscriptionRec after update', subscriptionRec);
    return newPlanItemsToAdd;
  }

  /**
   * Removes missing plan items from sublist collection
   * @constructor
   * @param {any} sublist - The input collection.
   */
  private removeMissingAndUpdateExistingPlanItems(
    sublist,
    isPriceinterval: boolean,
    newPlanItems: SubscriptionConfigurationItem[] | undefined,
    frequency: string,
    planItems: SubscriptionPlanItem[],
    isLegacyPlan: boolean
  ) {
    const keys = Object.keys(sublist);
    const keysToRemove: string[] = [];
    keys.forEach((k) => {
      if (k.indexOf('line ') === 0) {
        if (!newPlanItems?.some((i) => i.code.toLowerCase() === sublist[k].item_display.toLowerCase())) {
          keysToRemove.push(k);
        } else {
          const newPlanItem = newPlanItems?.find((i) => i.code.toLowerCase() === sublist[k].item_display.toLowerCase());
          assertNotNull(newPlanItem, "newPlanItem shouldn't be null");
          nsutils.logMayBe('preview newPlanItem quantity', {
            old: sublist[k].quantity,
            new: newPlanItem.quantity.toString(),
          });
          sublist[k].quantity = newPlanItem.quantity.toString();
          sublist[k].item = newPlanItem.id!.toString();
          if (isPriceinterval) {
            sublist[k].frequency = frequency.toUpperCase();
            // the value doesn't metter as we are going to recalculated it. just should be not 0 to be included
            sublist[k].recurringamount = '1';
            sublist[k].totalintervalvalue = '1';
            if (!isLegacyPlan) {
              const planItem = planItems.find((i) => newPlanItem.code === i.code);
              assertNotNullMsg(planItem, `Cant find plan item by code: '${newPlanItem.code}'`);
              // the price plan id doesn't metter as we are going to recalculated it. just should be not empty
              sublist[k].priceplan = planItem.prices[0]?.ranges[0]?.priceplanid?.toString();
              sublist[k].item = planItem.id.toString();
            }
          }
        }
      }
    });

    nsutils.logMayBe('preview priceinterval keysToRemove', keysToRemove);
    keysToRemove.forEach((k) => {
      delete sublist[k];
    });
  }

  private getPreviewResponse(resItems, frequency: string, plan: SubscriptionPlan, previewParams) {
    nsutils.logMayBe('getPreviewResponse vars', { resItems, frequency, plan, previewParams });

    const totalAmount = roundMoney(resItems.sum((x) => x.amounts.totalIntervalValue));
    // success plan premium is the amount difference between silver plan and current plan
    let successPlanPremium = 0;
    if (plan && plan.supportLevel !== SupportLevel.Silver) {
      const silverSubscriptionPlan = subscriptionPlanDao.getSilverSubscriptionPlan(plan.code);
      nsutils.logMayBe('getPreviewResponse silverSubscriptionPlan', silverSubscriptionPlan);
      if (silverSubscriptionPlan) {
        try {
          const newParams = clone(previewParams);
          newParams.content.planCode = silverSubscriptionPlan.itemid;
          // change the items to be silver items
          const regex = /^((?:[^-]*-){3})(GOL|PLA)(-.*)?$/;
          newParams.content.items = newParams.content.items.map(item => {
              return {
                  ...item,
                  code: item.code.replace(regex, (match, p1, p2, p3) => {
                      return `${p1}SIL${p3 || ''}`;
                  })
              };
          });
          const previewContent = OperationUtils.callAndGetContent(Subscription, Subscription.preview, newParams);
          successPlanPremium = roundMoney(totalAmount - previewContent.totalAmount);
        } catch (ex: Any) {
          nsutils.logDebug(`Error calling preview to get successPlanPremium`,
            `planCode: ${previewParams.planCode}. Exception: ${ex.message} - ${ex}`);
        }
      }
    }

    // return parts from subscription
    const response: SubscriptionPreviewResponse = {
      frequency: frequency,
      totalAmount: totalAmount,
      totalListPrice: roundMoney(resItems.sum((x) => x.amounts.totalListPrice)),
      items: resItems.map(
        (x) => ({ title: x.title, code: x.code, quantity: x.quantity, amount: roundMoney(x.amounts.totalIntervalValue) } as PreviewResponseItem)
      ),
      successPlanPremium: successPlanPremium,
    };
    return {
      content: response,
    } as HandlerResponse;
  }

  startTrial(params: InputParams): HandlerResponse {
    nsutils.logMayBe('startTrial params', params);
    assertNotNull(params.customerId, 'customerId');
    const pi = ProductIntegration.getProductIntegration(params.productFamilyCode, params.productVariantCode);

    const existingSubscriptionIds = subscriptionDao.getCustomerSubscriptionIds(params.customerId, {
      productFamilyCode: params.productFamilyCode!,
      productVariantCode: params.productVariantCode!,
    });
    if (existingSubscriptionIds.length > 0) {
      throw new Error('Cannot start trial. Customer already have or had subscriptions');
    }

    nsutils.logMayBe('startTrial', 'Customer is ok');
    const createParams = {} as SubscriptionCreateParams;
    createParams.customerId = params.customerId;
    createParams.productFamilyCode = params.productFamilyCode;
    createParams.productVariantCode = params.productVariantCode;
    createParams.content = JSON.parse(must(pi.trialSubscriptionConfig, 'trialSubscriptionConfig'));

    return this.create(createParams, true);
  }

  internalSetPrice(params: SetPriceParams): HandlerResponse {
    assertNotNull(params.subscriptionId, 'subscriptionId');
    const subscriptionRec = record.load({ type: record.Type.SUBSCRIPTION, id: params.subscriptionId, isDynamic: true });
    const subPricing = new DynamicSublistWrapper(subscriptionRec, 'priceinterval');
    const items = subscriptionPlanDao.getItems(params.items?.map((i) => i.code));
    while (subPricing.nextLine()) {
      // It's only possible to change the price on draft items
      if (subPricing.getFieldValue('status') !== 'DRAFT') {
        continue;
      }
      const itemId = parseInt(subPricing.getFieldValue('item')?.toString() as string);
      const code = items?.find((i) => i.id === itemId)?.code;
      const price = params.items?.find((i) => i.code === code)?.price;
      if (!price) {
        continue;
      }
      const newPricePlanRec = record.create({
        type: record.Type.PRICE_PLAN,
        isDynamic: true,
      });
      subscriptionPriceUtility.createPriceTier(newPricePlanRec, 0, price, PriceTierType.Rate);
      const newPricePlan = newPricePlanRec.save();
      subPricing.setFieldValue('priceplan', newPricePlan);
      subPricing.commit();
    }
    subscriptionRec.save();
    return { content: true };
  }

  modifyPrice(params: ModifyPriceParams): HandlerResponse {
    nsutils.logMayBe('modifyPrice params', params);
    assertNotNull(params.subscriptionId, 'subscriptionId');
    assertNotNull(params.reducePercentage, 'reducePercentage');
    const subscriptionRec = record.load({ type: record.Type.SUBSCRIPTION, id: params.subscriptionId, isDynamic: true });
    const subPricing = new DynamicSublistWrapper(subscriptionRec, 'priceinterval');
    nsutils.logMayBe('modifyPrice subscriptionRec', subscriptionRec);
    nsutils.logMayBe('modifyPrice subPricing', subPricing);

    const activeItems: {
      id: number;
      newPricePlan: number;
    }[] = [];
    const itemIds = subscriptionPlanDao.getItemIds(params.itemCodes);
    while (subPricing.nextLine()) {
      nsutils.logMayBe('modifyPrice subPricing priceplan', {
        priceplan: subPricing.getFieldValue('priceplan'),
        item: subPricing.getFieldValue('item'),
        status: subPricing.getFieldValue('status'),
      });
      const itemId = parseInt(subPricing.getFieldValue('item')?.toString() as string);
      if (itemIds && !itemIds.includes(itemId)) {
        continue;
      }
      const newPricePlan = subscriptionPriceUtility.applyDiscount(
        params.reducePercentage,
        subPricing.getFieldValue('priceplan')
      );
      nsutils.logMayBe('modifyPrice newPricePlan', newPricePlan);
      assertNotNull(newPricePlan, 'newPricePlan');
      if (subPricing.getFieldValue('status') === 'ACTIVE') {
        const item = {
          id: itemId,
          newPricePlan: newPricePlan,
        };
        activeItems.push(item);
      } else if (subPricing.getFieldValue('status') === 'DRAFT') {
        subPricing.setFieldValue('priceplan', newPricePlan);
        subPricing.commit();
      }
    }
    subscriptionRec.save();
    nsutils.logMayBe('modifyPrice updated subscriptionRec', subscriptionRec);
    nsutils.logMayBe('modifyPrice updated subPricing', subPricing);

    if (activeItems.length > 0) {
      const conf: SubscriptionConfiguration = { items: [] };
      if (params.effectiveDate) {
        conf.effectiveDate = params.effectiveDate;
      }
      const { changeOrder, subLines } = subscriptionChangeOrderUtility.createChangeOrder(
        params.subscriptionId,
        'MODIFY_PRICING',
        conf
      );
      nsutils.logMayBe('modifyPrice changeOrder', changeOrder);
      nsutils.logMayBe('modifyPrice subLines', subLines);
      while (subLines.nextLine()) {
        const itemId = parseInt(subLines.getFieldValue('item')?.toString() as string);
        const item = activeItems.find((i) => i.id === itemId);
        if (item) {
          subLines.setFieldValue('priceplannew', item.newPricePlan);
          subLines.commit();
        }
      }
      changeOrder.save();
      nsutils.logMayBe('modifyPrice updated changeOrder', changeOrder);
    }
    return { content: true };
  }

  reportUsage(params: ReportUsageParam): HandlerResponse {
    nsutils.logMayBe('reportUsage params', params);
    const customerInternalId = customerDao.getInternalId(params.customerId);
    assertNotNullMsg(customerInternalId, 'customer not found');
    assertNotNull(params.content);

    const errors: { path: string; message: string }[] = [];
    for (let idx = 0; idx < params.content.length; idx++) {
      try {
        const usageParam = params.content[idx];
        assertNotNull(usageParam.subscriptionId);
        assertNotNull(usageParam.itemCode);
        assertNotNull(usageParam.usageDate);
        const usageId = subscriptionUsageUtility.createUsage(usageParam);
        nsutils.logMayBe('reportUsage createUsage', `Usage ${usageId} created`);
      } catch (e: Any) {
        log.error('reportUsage', e);
        errors.push({ path: '' + idx, message: e.message });
      }
    }

    return { content: { errors } };
  }

  changeQuoteLink(params: ChangeQuoteLinkParams): HandlerResponse {
    SubscriptionUtility.changeSubscriptionQuoteLinks(params.oldSubscriptionId, params.newSubscriptionId);
    return { content: true };
  }

  /**
   * Finds the subsidiary that is the most suitable for the given customer, class and parent subscription.
   * @param {FindSuitableSubsidiaryParams} params
   * @returns {HandlerResponse} The subsidiary.
   */
  findSuitableSubsidiary(params: FindSuitableSubsidiaryParams): HandlerResponse {

    // Retrieve the entity ID of the customer.
    const entityId = customerDao.getEntityId(params.customerId);
    if (!entityId) {
      throw new Error(`Customer with id ${params.customerId} not found`);
    }

    // Find the subsidiary ID that is the most suitable, then return it.
    const subsidiaryId = subscriptionCreateUtility.findSuitableSubsidiary(entityId, params.classId, params.parentSubscriptionId);
    return { content: { subsidiaryId } };
  }

  /**
   * Uploads a file as a contractual document to the given subscription.
   * @param {UploadContractualDocumentParams} params The parameters for uploading the contractual document.
   * @returns {HandlerResponse}
   */
  uploadContractualDocument(params: UploadContractualDocumentParams): HandlerResponse {
    assertNotNull(params.customerId, 'customerId');
    assertNotNull(params.subscriptionId, 'subscriptionId');
    assertNotNull(params.content?.type, 'type');
    assertNotNull(params.content?.filename, 'filename');
    assertNotNull(params.content?.contents, 'contents');

    // Validate the document type and the file extension are supported.
    if (!ContractualDocumentTypeUtils.hasValue(params.content.type)) {
      throw new Error('Contractual document type not supported');
    }
    if (!params.content.filename.toLowerCase().endsWith('.pdf')) {
      throw new Error('Contractual document must be PDF file');
    }

    // Load the subscription and validate it against the customer context.
    const subscription = SubscriptionRecord.load(params.subscriptionId, false);
    if (!subscription.isWritableForCustomer(params.customerId)) {
      throw new SubscriptionNotFoundError();
    }

    // Validate the contractual documents record exists and the document type is not already attached.
    if (!subscription.contractDocs) {
      throw new Error('Contractual documents not found');
    }
    if (ContractualDocumentsService.containsDocumentType(subscription.contractDocs, params.content.type)) {
      throw new Error('Contractual document type already attached');
    }

    // Upload the file.
    const prefix = ContractualDocumentTypeUtils.documentTypeToPrefix(params.content.type)
    const uploadFileParams = {
      filename: `${prefix}${params.content.filename}`,
      contents: params.content.contents,
      folder: Folder.Agreement,
    };
    const fileId = fileService.uploadFile(uploadFileParams);

    // Attach it to the contractual documents.
    const attachFileParams = {
      contractualDocumentsId: subscription.contractDocs,
      fileId: fileId,
      signedQuote: false,
    };
    OperationUtils.callAndGetContent(ContractualDocumentsService, ContractualDocumentsService.attachFile, attachFileParams);

    return { content: { contractualDocumentsId: subscription.contractDocs, fileId } };
  }

  getRenewalInfo(params: GetRenewalInfoParams): HandlerResponse {
    return {
      content: subscriptionGetRenewalInfoUtility.getRenewalInfo(params),
    }
  }

  getSubscriptionsToSync(params: GetSubscriptionsToSyncParams): HandlerResponse {
    return {
      content: SubscriptionUtility.getSubscriptionsToSync(params),
    }
  }

  private getARR(subscription: record.Record): number | null {
    const subscriptionSnapshot = clone(subscription);
    const priceLines = subscriptionGetUtility.convertLinesToArray(subscriptionSnapshot.sublists.priceinterval);
    nsutils.logMayBe('getARR priceLines', priceLines);
    const subscriptionLines = subscriptionGetUtility.convertLinesToArray(subscriptionSnapshot.sublists.subscriptionline);

    // if there are no active price lines, not calculating ARR, ARR field should be kept blank
    if (!priceLines.find(i => i.status === 'ACTIVE')) {
      nsutils.logMayBe('getARR no active price lines', 'exit');
      return null;
    }

    const subscriptionPlan = subscriptionPlanUtility.getSubscriptionPlanById(
        parseInt(subscriptionSnapshot.fields.subscriptionplan), true
    );
    nsutils.logMayBe('getARR subscriptionPlan', subscriptionPlan);

    const items = this.getItemsFromSnapshot(subscriptionLines, priceLines, subscriptionPlan);
    nsutils.logMayBe('getARR items', items);
    return items.sum(i => i.ARR);
  }

  calculateAndSaveARR(subscriptionId: number): void {
    nsutils.logMayBe('calculateAndSaveARR subscriptionId', subscriptionId);
    const subscription = record.load({
        type: record.Type.SUBSCRIPTION,
        id: subscriptionId
    });
    nsutils.logMayBe('calculateAndSaveARR subscription', subscription);
    const ARR = this.getARR(subscription);
    nsutils.logMayBe('calculateAndSaveARR ARR', ARR);
    subscription.setValue({
        fieldId: 'custrecord_arr',
        value: ARR
    });
    subscription.save();
  }

  calculateAndSaveARRExposed(params: SubscriptionParams): HandlerResponse {
    this.calculateAndSaveARR(must(params.subscriptionId));
    return { content: true };
  }

  recordRenewalIntent(params: SubscriptionParams): HandlerResponse {
    nsutils.logMayBe('recordRenewalIntent subscriptionId', params.subscriptionId);
    const subscription = record.load({
      type: record.Type.SUBSCRIPTION,
      id: must(params.subscriptionId, "subscriptionId")
    });
    nsutils.logMayBe('recordRenewalIntent subscription', subscription);
    const now = new Date();
    subscription.setValue({
      fieldId: 'custrecord_self_serve_last_activity',
      value: now
    });
    subscription.save();
    nsutils.logMayBe('recordRenewalIntent timestamp', now);
    return {
      content: {
        subscriptionId: params.subscriptionId,
        lastActivity: now.toISOString(),
      },
    };
  }
}

export const Subscription = new SubscriptionService();
export const testables = {
  findItemForLine: (subscriptionItemUtility as any).findItemForLine, //NOSONAR
  findItemInfos: (subscriptionItemUtility as any).findItemInfos, //NOSONAR
};
