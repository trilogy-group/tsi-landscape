import * as record from 'N/record';
import { HandlerResponse } from "../../types";
import { assertNotNullMsg } from "../../validation";
import classDao from "../../dao/ClassDao";

export interface UpdateClassParams {
    className: string;
    renewalManagerId?: string;
}

class ClassOperations {

    /**
     * Updates the class record.
     * @param {UpdateClassParams} params
     * @returns {HandlerResponse}
     */
    update(params: UpdateClassParams): HandlerResponse {
        assertNotNullMsg(params?.className, 'className is missing');

        // Retrieve the class from the name.
        const classId = classDao.getClassId(params.className);
        const classRecord = record.load({ type: record.Type.CLASSIFICATION, id: classId });

        // If the value differs, update the renewal manager.
        const newRenewalManagerId = params.renewalManagerId ?? null;
        if (newRenewalManagerId !== classRecord.getValue({ fieldId: 'custrecord_renewal_manager' })) {
            classRecord.setValue({ fieldId: 'custrecord_renewal_manager', value: newRenewalManagerId });
        }

        classRecord.save();
        return { content: true };
    }
}

export default new ClassOperations();
