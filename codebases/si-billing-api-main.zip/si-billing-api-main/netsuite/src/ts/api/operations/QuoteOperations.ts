import * as record from 'N/record';
import { Any, BillingSchedule, QuoteBillingSchedule, RevenueTypeUtils, TypedHandlerResponse, InputParams, OperationUtils, TermUnit, HandlerResponse } from '../../types';
import {
  assertNotNull,
  assertNotNullMsg,
  assertNsDate,
  must,
  QuoteNotFoundError,
  SubscriptionNotFoundError,
  ValidationError,
} from '../../validation';
import QuoteDao, { QuoteEntityStatus, TcKeys } from '../../dao/QuoteDao';
import QuoteService, { AgreementType } from '../../utility/QuoteService';
import SubscriptionDao, { UnlinkedQuoteInfo } from '../../dao/SubscriptionDao';
import { SubscriptionRecord } from '../../models/SubscriptionRecord';
import { OperationContext } from '../../models/OperationContext';
import AdobeESignService from '../../utility/AdobeESignService';
import * as nsutils from '../../nsutils';
import ContractualDocumentsService from './../../utility/ContractualDocumentsService';
import { clone, roundMoney } from '../../utility/GeneralUtility';
import { Subscription } from '../../Subscription';
import { SubscriptionPreviewParams } from '../../models/SubscriptionParams';
import { SubscriptionPlan } from '../../models/SubscriptionPlan';
import { TermDuration } from '../../models/TermDuration';
import SubscriptionCreateUtility from '../../utility/SubscriptionCreateUtility';
import { ItemCode } from '../../utility/SubscriptionItemUtility';
import SubscriptionPlanUtility from '../../utility/SubscriptionPlanUtility';
import { supportLevelDistributionRatio } from '../../models/SupportLevel';
import { PreviewResponseItem, SubscriptionPreviewResponse } from '../../models/SubscriptionPreview';
import { QuoteRecord } from '../../models/QuoteRecord';

export interface DownloadQuoteParams extends InputParams {
  quoteId?: number;
}

export enum QuoteOrderType {
  Renewal = 'renewal',
  Quote = 'quote',
}

export interface GenerateQuoteParams extends InputParams {
  subscriptionId?: number;
  orderType?: QuoteOrderType;
  recipients?: {
    email: string;
    role: string;
  }[];
  quoteLineEndDates?: {
    line: string;
    endDate: string;
  }[];
  quoteLineStartDates?: {
    line: string;
    startDate: string;
  }[];
  expiry?: string;
  salesRepId?: number;
  lineItemsHeaderText?: string;
  lineItemsFooterText?: string;
  terms?: string;
}

export interface GenerateSelfServeQuoteParams extends InputParams {
  content?: GenerateSelfServeQuoteContentParams;
}

export interface GenerateSelfServeQuoteContentParams {
  subscriptionId: number;
  planCode: string;
  frequency: string;
  duration: number;
  items: GenerateSelfServeQuoteItemParams[];
  recipients?: {
    email: string;
    role: string;
  }[];
}

export interface GenerateSelfServeQuoteItemParams {
  code: string;
  quantity?: number;
}

export interface UnlinkedQuoteItem {
  item: number;
  quantity: number;
  rate: number;
  startDate?: string;
  endDate?: string;
  amount: number;
  listRate?: number;
}

export interface GenerateUnlinkedQuoteParams extends InputParams {
  startdate: string;
  enddate: string;
  endUserInternalId: number;
  distributorInternalId?: number;
  resellerInternalId?: number;
  relatedSubscriptionId?: number;
  items: UnlinkedQuoteItem[];
  // Plan is used to find the class
  planId: number;
  subsidiary: string;
  // USD, EUR, GBP, etc.
  currency: string;
  frequency: string;

  orderType?: QuoteOrderType;
  recipients?: {
    email: string;
    role: string;
  }[];
  expiry?: string;
  salesRepId?: number;
  lineItemsHeaderText?: string;
  lineItemsFooterText?: string;
  terms?: string;
  isSelfServe?: boolean;
  arQuote?: boolean;
}

export interface AcceptQuoteParty {
  name?: string;
  jobTitle?: string;
  email?: string;
  phone?: string;
}
export interface AcceptQuoteParams extends InputParams {
  quoteId?: number;
  content?: {
    acceptor: AcceptQuoteParty;
    ccEmail?: string;
    time?: string;
    clientInfo?: {
      ipAddress: string;
      userAgent: string;
    };
  };
}

export interface AgreementParams extends InputParams {
  agreementId?: number;
}

export interface GetQuoteTypeParams {
  quoteId: number;
}

const WEEK_DAYS = 7;
const MONTH30_DAYS = 30;

class QuoteOperations {
  download(params: DownloadQuoteParams): TypedHandlerResponse<string> {
    assertNotNull(params.quoteId, 'quoteId');
    const quoteInfo = QuoteDao.findQuoteInfo(params.quoteId);
    if (!quoteInfo || (params.customerId && params?.customerId !== quoteInfo?.customerId)) {
      throw new QuoteNotFoundError();
    }

    return {
      content: AdobeESignService.downloadAgreementPdf(quoteInfo.previewAgId),
    };
  }

  cancelAgreement(params: AgreementParams): TypedHandlerResponse<Any> {
    assertNotNull(params.agreementId, 'agreementId');
    QuoteService.cancelAgreement(params.agreementId);
    return {
      content: {
        success: true,
      }
    };
  }

  sendAgreementForSignature(params: AgreementParams): TypedHandlerResponse<Any> {
    assertNotNull(params.agreementId, 'agreementId');
    const rec = record.load({
      type: 'customrecord_echosign_agreement',
      isDynamic: true,
      id: params.agreementId
    });
    rec.setValue('custrecord_echosign_senddocinteractive', false);
    rec.save();
    QuoteService.sendAgreementForSignature(params.agreementId);
    return {
      content: {
        success: true,
      }
    };
  }

  public validateCreateQuoteParams(params: GenerateQuoteParams) {
    assertNotNull(params.subscriptionId, 'subscriptionId');

    if (params.expiry) {
      assertNsDate(params.expiry, 'expiry param');
    }

    if (params.quoteLineStartDates) {
      for (const line of params.quoteLineStartDates) {
        assertNsDate(line.startDate, 'quoteLineStartDates.startDate param');
      }
    }

    if (params.quoteLineEndDates) {
      for (const line of params.quoteLineEndDates) {
        assertNsDate(line.endDate, 'quoteLineEndDates.endDate param');
      }
    }
  }

  createQuote(params: GenerateQuoteParams): TypedHandlerResponse<{ id: number, quoteType: string }> {
    nsutils.logMayBe('createQuote params', params);
    this.validateCreateQuoteParams(params);

    assertNotNull(params.subscriptionId, 'subscriptionId');
    if (params.recipients) {
      const signers = params.recipients.filter(i => i.role.toLowerCase() === 'signer');
      if (signers.length > 1) {
        throw new ValidationError('Only one signer is allowed to be informed.', 'recipients');
      }
    }
    const ctx = OperationContext.fromParams(params);
    const si = SubscriptionDao.getInfoForQuote(params.subscriptionId!);
    if (params.customerId && params.customerId !== si.customerId) {
      throw new SubscriptionNotFoundError();
    }

    // set quote due date
    const dueDate: Date = this.getDueDate(params.expiry, si.startDate);

    // Set billing schedule
    const billingSchedule = this.getBillingSchedule(si);

    // Format quote name
    const quoteName = this.getQuoteName(params, si);
    const preview = !!params.salesRepId;
    const lineItemsHeaderText = params.lineItemsHeaderText ?? '';
    const lineItemsFooterText = params.lineItemsFooterText ?? '';

    const subscription = SubscriptionRecord.load(params.subscriptionId);

    const [quoteId, quoteForm] = QuoteService.generateQuote(ctx, {
      startDate: si.startDate,
      endDate: si.endDate,
      dueDate,
      endUserId: si.endUserInternalId,
      customerId: si.customerInternalId,
      subscription: subscription,
      name: quoteName,
      orderType: params.orderType,
      quoteLineStartDates: params.quoteLineStartDates,
      quoteLineEndDates: params.quoteLineEndDates,
      billingSchedule: billingSchedule,
      salesRepId: params.salesRepId,
      lineItemsHeaderText: lineItemsHeaderText,
      lineItemsFooterText: lineItemsFooterText,
      terms: params.terms
    });

    let tcKeys = QuoteService.getTermsAndConditionsForQuote(quoteForm);
    QuoteService.createAdobeServicesAgreement(quoteId, tcKeys, preview, AgreementType.Quote, clone(params.recipients));

    // create end user acknowledgement when subscription is sold through reseller/distributor
    if (subscription.customerInternalId !== subscription.endUserInternalId) {
      tcKeys = [];
      if (subscription.isMaintenance) {
        tcKeys.push(TcKeys.EUA_Maintenance);
      }
      QuoteService.createAdobeServicesAgreement(quoteId, tcKeys, true, AgreementType.EndUserAcknowledgement, clone(params.recipients));
    }

    return {
      content: {
        id: quoteId,
        quoteType: QuoteService.getQuoteType(quoteForm)
      },
    };
  }

  /**
   * Creates a self-serve quote. The quote is a quote soft-linked to the related subscription.
   * @param {GenerateSelfServeQuoteParams} params The parameters for creating the quote.
   * @returns {TypedHandlerResponse<{ id: number}>} The identifier of the created quote.
   */
  createSelfServeQuote(params: GenerateSelfServeQuoteParams): TypedHandlerResponse<{ id: number}> {
    assertNotNull(params.customerId, 'customerId');
    assertNotNull(params.productFamilyCode, 'productFamilyCode');
    assertNotNull(params.productVariantCode, 'productVariantCode');
    assertNotNull(params.content, 'content');
    assertNotNull(params.content.subscriptionId, 'content.subscriptionId');
    assertNotNull(params.content.planCode, 'content.planCode');
    assertNotNull(params.content.frequency, 'content.frequency');
    assertNotNull(params.content.duration, 'content.duration');
    assertNotNull(params.content.items, 'content.items');
    const operationContext = OperationContext.fromParams(params);

    // Load and validate the renewal subscription for the contextual customer.
    const subscription = SubscriptionRecord.load(params.content.subscriptionId, false);
    if (!subscription.isWritableForCustomer(params.customerId)) {
      throw new SubscriptionNotFoundError();
    }
    assertNotNullMsg(subscription.parentId, 'The subscription is not a renewal subscription.');

    // Load the subscription plan and validate the operation context.
    const subscriptionPlan = SubscriptionPlanUtility.getSubscriptionPlanByCode(params.content.planCode);
    if (operationContext.productFamilyCode !== subscriptionPlan.product.family.code
      || operationContext.productVariantCode && operationContext.productVariantCode !== subscriptionPlan.product.variant.code) {
      throw new ValidationError(
        `The subscription plan '${subscriptionPlan.code}' does not match `
        + `the product family '${operationContext.productFamilyCode}' and the product variant '${operationContext.productVariantCode}'.`
      );
    }

    // Call the subscription preview operation, then add the support items based on the subscription plan items.
    const previewParams = { ...operationContext,
      content: params.content,
      subscriptionId: params.content.subscriptionId,
    } as SubscriptionPreviewParams;
    const previewContent = OperationUtils.callAndGetContent(Subscription, Subscription.preview, previewParams);
    this.addSupportItemsToPreviewContent(previewContent, subscriptionPlan);

    // If recipients are defined, add internal recipients as Cc.
    if (params.content.recipients) {
      this.splitRecipientEmailList(params.content.recipients);
      this.addRecipientIfAny(params.content.recipients, subscription.salesRepId);
      this.addRecipientIfAny(params.content.recipients, operationContext.productIntegration.nsClass.renewalManagerId);
    }

    // Call the unlinked quote generation operation and return the identifier of the created quote.
    const unlinkedQuoteItems = previewContent.items.map(i => (
      {
        item: subscriptionPlan.items.find(spi => spi.code === i.code)?.id,
        quantity: i.quantity,
        rate: roundMoney(i.amount / i.quantity),
        amount: i.amount,
      }
    ));
    const unlinkedQuoteParams = { ...operationContext,
      orderType: 'renewal',
      relatedSubscriptionId: params.content.subscriptionId,
      frequency: params.content.frequency,
      startdate: nsutils.convert.toDateText(subscription.startDate),
      enddate: nsutils.convert.toDateText(TermDuration.calculateEndDate(params.content.duration, TermUnit.MONTHS, subscription.startDate)),
      endUserInternalId: subscription.endUserInternalId,
      distributorInternalId: subscription.distributorInternalId,
      resellerInternalId: subscription.resellerInternalId,
      currency: subscription.currencySymbol,
      planId: subscriptionPlan.id,
      subsidiary: `${SubscriptionCreateUtility.findSuitableSubsidiary(params.customerId, operationContext.productIntegration.nsClass.id, subscription.parentId)}`,
      expiry: nsutils.convert.toDateText(this.getDueDate(undefined, subscription.startDate)),
      terms: this.getQuoteTerms(subscription.startDate),
      items: unlinkedQuoteItems,
      isSelfServe: true,
      recipients: params.content.recipients,
    } as GenerateUnlinkedQuoteParams;
    const createUnlinkedQuoteContent = OperationUtils.callAndGetContent(this, this.createUnlinkedQuote, unlinkedQuoteParams);
    return { content: { id: createUnlinkedQuoteContent.id }};
  }

  /**
   * Adds the support items to the given preview content based on the subscription plan.
   * @param {SubscriptionPreviewResponse[]} previewContent The preview content, including only license items.
   * @param {SubscriptionPlan[]} subscriptionPlan The subscription plan, including the license and the support items.
   */
  private addSupportItemsToPreviewContent(previewContent: SubscriptionPreviewResponse, subscriptionPlan: SubscriptionPlan) {

    // Determine the support level distribution ratio based on the support level.
    const supportRatio = supportLevelDistributionRatio(subscriptionPlan.supportLevel);

    // Browse preview items containing only license items, for adding the support items from the plan if any. Adapt the amount based on the support ratio.
    for (const previewItem of [...previewContent.items]) {

      // If the preview item is support, continue.
      const previewItemCode = new ItemCode(previewItem.code);
      if (previewItemCode.isSupport()) {
        continue;
      }

      // Try to find a match for a support item.
      const matchedSupportItem = subscriptionPlan.items.find(i => previewItemCode.isDifferentOnlyInSuffix(new ItemCode(i.code)));
      if (matchedSupportItem) {

        // If there is a match, create the support item by calculating the amount based on the support ratio.
        const previewSupportItem: PreviewResponseItem = {
          code: matchedSupportItem.code,
          title: matchedSupportItem.title,
          quantity: previewItem.quantity,
          amount: roundMoney(previewItem.amount * supportRatio),
        };
        previewContent.items.push(previewSupportItem);

        // Update the license item by substracting the amount for the support item.
        previewItem.amount -= previewSupportItem.amount;
      }
    }

    // Sort preview items by considering the plan items order.
    const findIndex = (i: PreviewResponseItem) => subscriptionPlan.items.findIndex(j => j.code === i.code);
    previewContent.items.sort((a, b) => findIndex(a) - findIndex(b));
  }

  /**
   * Splits any email list defined for a recipient by considering a list of recipients with unique email.
   * @param {{ email: string, role: string }[]} recipients
   */
  private splitRecipientEmailList(recipients: { email: string, role: string }[]) {

    // For each recipient email, remove any space character and split by ',' and ','.
    recipients.forEach((recipient, i) => {
      recipient.email.replace(/\s/g, '').split(/[;,]/).forEach((email, j) => {

        // Set the first email for the current recipient. For any additional email, add a new recipient.
        if (j === 0) {
            recipients[i].email = email;
        } else if (email) {
            recipients.push({ email: email, role: recipient.role });
        }
      });
    });
  }

  /**
   * Adds the email of the employee to the recipients if the employee is defined and has an email address.
   * @param {{ email: string, role: string }[]} recipients The array of recipients.
   * @param {number} [employeeId] The identifier of the employee.
   */
  private addRecipientIfAny(recipients: { email: string, role: string }[], employeeId?: number) {
    if (employeeId) {
      const employee = nsutils.queryFirstToJson(`SELECT email FROM employee WHERE id = ?`, [ employeeId ]);
      if (employee.email) {
        recipients.push({ email: employee.email, role: 'cc' });
      }
    }
  }

  createUnlinkedQuote(params: GenerateUnlinkedQuoteParams): TypedHandlerResponse<{ id: number; quoteType: string }> {
    nsutils.logMayBe('createUnlinked params', params);

    if (params.recipients) {
      const signers = params.recipients.filter(i => i.role.toLowerCase() === 'signer');
      if (signers.length > 1) {
        throw new ValidationError('Only one signer is allowed to be informed.', 'recipients');
      }
    }
    const ctx = OperationContext.fromParams(params);
    const endUserInfo = nsutils.queryFirstToJson(
      `
      select 
	      c_enduser.id enduserinternalid,
        c_enduser.entityid as enduserid,
        case
           when c_enduser.isperson = 'T' then REGEXP_REPLACE(c_enduser.title || ' ' || c_enduser.firstname || ' ' || c_enduser.middlename || ' ' || c_enduser.lastname, '  +', ' ')
          else c_enduser.companyname
        end as endusercompany
      from customer c_enduser
      where c_enduser.id=?
    `,
      [params.endUserInternalId],
      {
        enduserid: 'endUserId',
        enduserinternalid: 'endUserInternalId',
        endusercompany: 'endUserCompanyName',
      }
    );
    assertNotNull(endUserInfo.endUserId, 'endUserId');
    const planInfo = nsutils.queryFirstToJson(
      `
      select       
      cl.fullname as class_name,
      sp.id as subscription_plan_id
    from subscriptionplan sp
    left join classification cl on cl.id=sp.class
    where sp.id=?
    `,
      [params.planId],
      {
        class_name: 'productClass',
        subscription_plan_id: 'subscriptionPlanId',
      }
    );
    assertNotNull(planInfo.subscriptionPlanId, 'subscriptionPlanId');
    const currencyInfo = nsutils.queryFirstToJson(
      `
      select id
      from currency where symbol=?
    `,
      [params.currency],
      {
        id: 'id',
      }
    );

    const customerInfo = nsutils.queryFirstToJson(
      `
      select 
	      c.id
      from customer c
      where entityid=?
    `,
      [must(params.customerId)],
      {
        id: 'id',
      }
    );
    assertNotNull(customerInfo.id, 'customerId');
    const si: UnlinkedQuoteInfo = {
      startDate: nsutils.convert.toDate(params.startdate),
      endDate: nsutils.convert.toDate(params.enddate),
      endUserId: endUserInfo.endUserId,
      customerInternalId: customerInfo.id,
      endUserInternalId: endUserInfo.endUserInternalId,
      endUserCompanyName: endUserInfo.endUserCompanyName,
      productClass: planInfo.productClass,
      // We do not have renewal number in SF
      renewalNumber: "",
      frequency: params.frequency as BillingSchedule,
    };

    // set quote due date
    const dueDate: Date = this.getDueDate(params.expiry, si.startDate);

    // Set billing schedule
    const billingSchedule = this.getBillingSchedule({
      frequency: si.frequency,
      startDate: si.startDate,
      endDate: si.endDate,
    });
    // Format quote name
    const quoteName = this.getQuoteName(params, si);
    const preview = !!params.salesRepId;
    const lineItemsHeaderText = params.lineItemsHeaderText ?? '';
    const lineItemsFooterText = params.lineItemsFooterText ?? '';
    const plan = SubscriptionPlanUtility.getSubscriptionPlanById(params.planId, true);
    const parentSubscriptionId = params.relatedSubscriptionId ? SubscriptionRecord.load(must(params.relatedSubscriptionId)).parentId : undefined;
    const [quoteId, quoteForm] = QuoteService.generateUnlinkedQuote(ctx, {
      startDate: si.startDate,
      endDate: si.endDate,
      dueDate,
      endUserId: si.endUserInternalId,
      customerId: si.customerInternalId,
      subscription: {
        customerId: must(params.customerId),
        isMaintenance: plan.supportOnly,
        customerInternalId: customerInfo.id,
        endUserInternalId: params.endUserInternalId,
        revenueType: RevenueTypeUtils.nameToRevenueType(plan.revenueType),
        subsidiary: parseInt(params.subsidiary),
        distributorInternalId: params.distributorInternalId,
        resellerInternalId: params.resellerInternalId,
        currency: currencyInfo.id,
        id: params.relatedSubscriptionId,
        subscriptionPlanId: plan.id,
        parentId: parentSubscriptionId
      },
      name: quoteName,
      orderType: params.orderType,
      items: params.items,
      billingSchedule: billingSchedule,
      salesRepId: params.salesRepId,
      lineItemsHeaderText: lineItemsHeaderText,
      lineItemsFooterText: lineItemsFooterText,
      terms: params.terms,
      isSelfServe: params.isSelfServe,
      arQuote: params.arQuote
    });

    let tcKeys = QuoteService.getTermsAndConditionsForQuote(quoteForm);
    QuoteService.createAdobeServicesAgreement(quoteId, tcKeys, preview, AgreementType.Quote, clone(params.recipients));

    // create end user acknowledgement when subscription is sold through reseller/distributor
    if (params.endUserInternalId !== customerInfo.id) {
      tcKeys = [];
      if (plan.supportOnly) {
        tcKeys.push(TcKeys.EUA_Maintenance);
      }
      QuoteService.createAdobeServicesAgreement(quoteId, tcKeys, true, AgreementType.EndUserAcknowledgement, clone(params.recipients));
    }

    return {
      content: {
        id: quoteId,
        quoteType: QuoteService.getQuoteType(quoteForm)
      },
    };
  }

  setContractualDocumentsInfo(params: GenerateQuoteParams): TypedHandlerResponse<{
    message: string, found?: boolean,
    contractualDocumentIdsChanged?: string
  }> {
    assertNotNull(params.subscriptionId, 'subscriptionId');

    const subscription = SubscriptionRecord.load(params.subscriptionId);
    if (subscription.customerInternalId !== subscription.endUserInternalId) {
      return {
        content: {
          message: 'Customer and End user are different'
        }
      };
    }

    // if the subscription doesn't have parent, it means it was not previously signed
    if (!subscription.parentId) {
      return {
        content: {
          message: 'Subscription doesn\'t have a parent subscription'
        }
      };
    }

    const res = QuoteService.setSignedQuotesToContractualDocuments(subscription.parentId, []);
    delete res.masterContract;
    return {
      content: {
        found: res.found,
        message: res.message,
        contractualDocumentIdsChanged: res.contractualDocumentIdsChanged.join(',')
      }
    };
  }

  // Returns quote name
  public getQuoteName(params: GenerateQuoteParams, si: {
    startDate: Date;
    renewalNumber?: string;
    productClass: string;
    endUserCompanyName: string;
  }): string {
    let orderTypeName = '';
    // Param type name should be included only if the input parameter contains it
    if (params.orderType) {
      orderTypeName = ` - ${params.orderType?.toLowerCase() === QuoteOrderType.Renewal ? 'Renewal' : 'New sale'}`;
    }
    const monthPadLength = 2;
    const dateYearMon = `${(si.startDate.getMonth() + 1).toString().padStart(monthPadLength, '0')}_${si.startDate.getFullYear()}`;
    const renewalNumber = `${si.renewalNumber ? ' - ' + si.renewalNumber.toString() : ''}`;
    const shortClassName = si.productClass ? si.productClass.split(':').reverse()[0].trim() : '';
    // Class name without the 'Product' postffix
    const productName = shortClassName.replace(/( Product|)$/, '');
    return `${si.endUserCompanyName} - ${productName}${orderTypeName} - ${dateYearMon}${renewalNumber}`;
  }

  // Returns the due date for the quote
  public getDueDate(expiry: string | undefined, startDate: Date) {
    let dueDate: Date;
    if (expiry) {
      dueDate = nsutils.convert.toDate(expiry);
    } else {
      dueDate = new Date();
      const diffInDays = nsutils.diffDateInDays(startDate, dueDate);
      if (diffInDays >= MONTH30_DAYS) {
        dueDate.setDate(dueDate.getDate() + MONTH30_DAYS);
      } else {
        dueDate.setDate(dueDate.getDate() + WEEK_DAYS);
      }
    }
    return dueDate;
  }

  /**
   * Returns the default quote terms based on the start date.
   * If the start date is after 30 days, then the terms are 'Net 30'; otherwise, returns 'Due on receipt'.
   * @param {Date} startDate The start date for the quote.
   * @returns The terms.
   */
  private getQuoteTerms(startDate: Date) {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const diffInDays = nsutils.diffDateInDays(startDate, today);
    return diffInDays >= MONTH30_DAYS ? 'Net 30' : 'Due on receipt';
  }

  // Returns the billing schedule for the quote
  public getBillingSchedule(si: {
    frequency: BillingSchedule;
    startDate: Date;
    endDate: Date;
  }): QuoteBillingSchedule {
    let billingSchedule: QuoteBillingSchedule;
    const yearFromStart = new Date(si.startDate.getFullYear() + 1, si.startDate.getMonth(), si.startDate.getDate());
    switch (si.frequency) {
      case BillingSchedule.ANNUALLY: {
        if (yearFromStart < si.endDate) {
          billingSchedule = QuoteBillingSchedule.ANNUALLY_DUE_AT_START;
        } else {
          billingSchedule = QuoteBillingSchedule.FULL_UPON_SIGNATURE
        }
        break;
      }
      case BillingSchedule.QUARTERLY: {
        billingSchedule = QuoteBillingSchedule.QUARTERLY_DUE_AT_START;
        break;
      }
      case BillingSchedule.MONTHLY: {
        billingSchedule = QuoteBillingSchedule.MONTHLY_DUE_AT_START;
        break;
      }
      default: {
        billingSchedule = QuoteBillingSchedule.FULL_UPON_SIGNATURE;
      }
    }
    return billingSchedule;
  }

  acceptQuote(params: AcceptQuoteParams): TypedHandlerResponse<Any> {
    assertNotNull(params.quoteId, 'quoteId');

    const quoteInfo = QuoteDao.findQuoteInfo(params.quoteId);
    if (!quoteInfo || (params.customerId && params.customerId !== quoteInfo.customerId)) {
      throw new QuoteNotFoundError();
    }

    if (quoteInfo.status !== QuoteEntityStatus.Proposal) {
      throw new ValidationError('Quote is not eligible for accept', 'quoteId');
    }

    if (!quoteInfo.subscriptionId) {
      throw new ValidationError('Quote is not linked to any subscription', 'quoteId');
    }

    const contractualDocsId = ContractualDocumentsService.create(params.quoteId,
      quoteInfo.subscriptionId, 'Acceptance Info', this.getNoteText(params));

    const subscription = SubscriptionRecord.load(quoteInfo.subscriptionId);
    subscription.contractDocs = contractualDocsId;

    const adobeSignId = QuoteService.sendForSignature(params.quoteId, subscription.subsidiary, {
      acceptor: must(params.content?.acceptor),
      ccEmail: params.content?.ccEmail,
    });

    subscription.save();

    QuoteDao.updateStatus(params.quoteId, QuoteEntityStatus.Signing);

    return {
      content: {
        id: params.quoteId,
        contractualDocId: contractualDocsId,
        adobeSignId: adobeSignId,
      },
    };
  }

  private getNoteText(params: AcceptQuoteParams): string {
    return `Acceptor: 
    * Name: ${params.content?.acceptor.name || ''}  
    * Job title: ${params.content?.acceptor.jobTitle || ''}
    * Email: ${params.content?.acceptor.email || ''}
    * Phone: ${params.content?.acceptor.phone || ''}
  CCEmail:  ${params.content?.ccEmail || ''}
  Time: ${params.content?.time || ''}
  Client info:
    * IPAddress: ${params.content?.clientInfo?.ipAddress || ''}
    * User-Agent: '${params.content?.clientInfo?.userAgent || ''}'
      `;
  }

  /**
   * Returns the quote type of the given quote.
   * @param {GetQuoteTypeParams} params
   * @returns {HandlerResponse} The quote type.
   */
  getQuoteType(params: GetQuoteTypeParams): HandlerResponse {
    assertNotNull(params.quoteId, 'quoteId');

    // Load the quote, then deduce the quote type based on the custom form.
    const quote = QuoteRecord.load(params.quoteId, false);
    const quoteType = QuoteService.getQuoteType(quote.customForm);

    return { content: { quoteType } };
  }
}

export default new QuoteOperations();
