import * as format from 'N/format';
import * as nsutils from '../nsutils';
import { BillingSchedule } from '../types';

export class BillingAccountDao {
  getBillingScheduleId(s: BillingSchedule): number {
    const nsScheduleName = s === BillingSchedule.MONTHLY ? 'Monthly Billing' : 'Annual Billing';
    const res = nsutils.queryFirstAsMap("select id from billingschedule where name=? and isinactive='F'", [
      nsScheduleName,
    ]);
    if (!res || !res.id) {
      throw new Error(`Billing schedule record for ${s} not found`);
    }
    return res.id;
  }

  nextBillCycleDate(billingAccountId: number): Date | undefined {
    const nbcString = nsutils.queryFirstAsMap(`select nextbillcycledate from billingaccount where id=?`, [
      billingAccountId,
    ])?.nextbillcycledate;
    return nbcString ? (format.parse({ value: nbcString, type: format.Type.DATE }) as Date) : undefined;
  }
}

export default new BillingAccountDao();
