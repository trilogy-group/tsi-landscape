import * as nsutils from '../nsutils';

class ClassDao {
  getSubsidiaries(classId: number): { domestic: number | null, german: number | null, japan: number | null, other: number | null } {
    return nsutils.queryFirstToJson(
      `SELECT custrecord_cls_entity_us_domestic as domestic, 
              custrecord_cls_entity_german as german,
              custrecord_cls_entity_japan as japan,
              custrecord_cls_entity_other as other
      FROM classification
      WHERE id = ?`,
      [classId]
    );
  }

  getClassId(className: string): number | null {
    return nsutils.queryFirstToJson(
      `SELECT id
      FROM classification
      WHERE name = ?`,
      [className]
    )?.id;
  }

  getClassIds(classNames: string): number[] {
    const classes = classNames.split(',').map((c) => `'${c}'`).join(',');
    return nsutils.queryToJson(
      `SELECT id
      FROM classification
      WHERE name in (${classes})`,
      []
    ).map((c) => c.id);
  }
}

export default new ClassDao();
