import * as nsutils from '../nsutils';

class ContractualDocumentsDao {
  findContractualDocumentsForSubscription(subscriptionId: number): number[] {
    return nsutils
      .queryToJson(
        `
        SELECT id
        FROM customrecord697
        WHERE custrecord_sub_doc = ?`,
        [subscriptionId]
      )
      .map((r) => r.id);
  }
}

export default new ContractualDocumentsDao();
