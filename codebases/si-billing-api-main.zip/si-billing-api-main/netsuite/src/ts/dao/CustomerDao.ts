import { ApiCustomerInfo, Contact } from '../models/apitypes';
import * as nsutils from '../nsutils';
import { BillingSchedule } from '../types';
import { ValidationError } from '../validation';

export class CustomerDao {
  getInternalId(entityid: string | undefined, fieldName?: string): number | undefined {
    if (entityid === undefined || entityid === null) {
      return undefined;
    }
    const res = nsutils.queryFirstAsMap('select id from customer where entityid=?', [entityid]);
    if (!res || !res.id) {
      throw new ValidationError(`Customer with id ${entityid} not found`, fieldName);
    }
    return res ? res.id : undefined;
  }

  getEntityId(internalId: number): string | undefined {
    if (internalId === undefined || internalId === null || Number.isNaN(internalId)) {
      return undefined;
    }
    const res = nsutils.queryFirstAsMap('select entityid from customer where id=?', [internalId]);
    if (!res || !res.entityid) {
      throw new ValidationError(`Customer with id ${internalId} not found`);
    }
    return res.entityid;
  }

  getEntityStatus(entityid: string) {
    const res = nsutils.queryFirstAsMap('select id, entitystatus from customer where entityid=?', [entityid]);
    if (!res || !res.id) {
      throw new Error(`Customer id ${entityid} not found`);
    }
    return res.entitystatus;
  }

  getCustomerInfo(customerInternalId: number | null): ApiCustomerInfo | undefined {

    // If the customer ID is undefined, return nothing.
    if (customerInternalId === null) {
      return undefined;
    }

    // Retrieve customer details and map them.
    const res = nsutils.queryFirstToJson(`
        SELECT
          c.entityid,
          c.firstname,
          c.lastname,
          c.email,
          c.phone,
          c.companyname,
          c.defaultbillingaddress,
          c.defaultshippingaddress
        FROM customer c
        WHERE id=?
      `,
      [customerInternalId],
      {
        entityid: 'id',
        firstname: 'firstName',
        lastname: 'lastName',
        email: 'email',
        phone: 'phone',
        companyname: 'companyName',
        defaultbillingaddress: 'address.id',
        defaultshippingaddress: 'shippingAddress.id',
      }
    );

    // Load the addresses and contact if any.
    this.loadAddresses(res);
    this.loadPrimaryContact(res);
    return res;
  }

  /**
   * Loads billing and shipping addresses if any.
   * The address is not loaded with the customer details for performance issue.
   * @param {{ address?: { id: number }, shippingAddress?: { id: number }}} customer
   */
  loadAddresses(customer: { address?: { id: number }, shippingAddress?: { id: number }}) {

    // If the (billing) address and the shipping address are the same ones, then the shipping address is not needed.
    if (customer.shippingAddress?.id && customer.shippingAddress.id === customer.address?.id) {
      delete customer.shippingAddress;
    }

    // Load the address(es).
    if (customer.address?.id) {
      customer.address = this.getAddress(customer.address.id);
    }
    if (customer.shippingAddress?.id) {
      customer.shippingAddress = this.getAddress(customer.shippingAddress.id);
    }
  }

  /**
   * Loads the primary contact if any.
   * @param {{ id: string, primaryContact?: Contact }} customer
   */
  loadPrimaryContact(customer: { id: string, primaryContact?: Contact }) {

    // Retrieve the primary contact details.
    const primaryContact = nsutils.queryFirstToJson(`
        SELECT 
          con.title,
          con.firstname,
          con.middlename,
          con.lastname,
          con.email,
          con.phone,
          con.defaultbillingaddress
        FROM customer c
        JOIN contact con ON c.contact = con.id
        WHERE c.entityid = ?
      `,
      [customer.id],
      {
        title: 'name.title',
        firstname: 'name.firstName',
        middlename: 'name.middleName',
        lastname: 'name.lastName',
        email: 'email',
        phone: 'phone',
        defaultbillingaddress: 'billingAddress.id',
      }
    );

    // Load the billing address if any.
    if (primaryContact?.billingAddress?.id) {
      primaryContact.billingAddress = this.getAddress(primaryContact.billingAddress.id);
    } else {
      delete primaryContact?.billingAddress;
    }

    // Set the primary contact on the customer.
    customer.primaryContact = primaryContact;
  }

  /**
   * Returns the address.
   * @param {number} addressId The identifier of the address.
   * @returns The address details.
   */
  getAddress(addressId: number) {
    return nsutils.queryFirstToJson(`
      SELECT
        addr1,
        addr2,
        city,
        state,
        country,
        zip,
        addrphone
      FROM entityaddress
      WHERE nkey = ?
    `,
    [addressId],
    {
      addr1: 'line1',
      addr2: 'line2',
      city: 'city',
      state: 'state',
      country: 'country',
      zip: 'zip',
      addrphone: 'phone',
    });
  }

  findCustomerAndBa(params: {
    customerId: string;
    frequency: BillingSchedule;
    subsidiaryId: number;
    classId: number;
    effectiveDate?: string;
  }) {
    return nsutils.queryFirstToJson(
      `
    SELECT 
      c.id  AS customerid,
      ba.id AS billingaccountid
    FROM   customer c
          left join billingaccount ba
            ON ba.customer = c.id and ba.frequency = ? and ba.class = ? and ba.subsidiary = ?
    WHERE  c.entityid = ?
  `,
      [params.frequency, params.classId, params.subsidiaryId, params.customerId],
      { customerid: 'customerId', billingaccountid: 'billingAccountId' }
    );
  }

  getCustomerSubsidiaries(customerId: string): { subsidiaryId: string; primary: boolean }[] {
    return nsutils.queryToJson(
      `
    SELECT 
      csr.subsidiary,
      csr.isprimarysub
    FROM  customer c
    INNER JOIN customersubsidiaryrelationship csr on csr.entity = c.id
    WHERE  c.entityid = ?
  `,
      [customerId],
      {
        subsidiary: { key: 'subsidiaryId', f: (v) => '' + v },
        isprimarysub: { key: 'primary', f: (v) => v === 'T' },
      }
    );
  }

  getCustomerBillingCountry(customerId: string): { country: string, addr1: string} {
    return nsutils.queryFirstToJson(
      `SELECT a.country, a.addr1
      FROM customer c
      INNER JOIN customerAddressbookEntityAddress a on c.defaultBillingAddress = a.nkey
      WHERE c.entityid = ?`,
      [customerId]
    );
  }

  findSubsidiaryOverrideForClass(customerId: string, classId: number): number | undefined {
    return nsutils.queryFirstToJson(
      `SELECT o.custrecord_default_subsidiary_subsidiary  AS subsidiary
      FROM customrecord_default_customer_subsidiary o
      INNER JOIN customer c on c.id = o.custrecord_default_subsidiary_customer
      WHERE c.entityid  = ? AND o.custrecord_default_subsidiary_class = ?`,
      [customerId,classId]
    )?.subsidiary;
  }

  /**
   * Returns the primary currency of the customer.
   * @param {string} customerId The customer ID, i.e. the entity ID.
   * @returns The ID and the symbol of the currency.
   */
  getPrimaryCurrency(customerId: string): { id: number; symbol: string } {
    return nsutils.queryFirstAsMap(`
      SELECT cur.id, cur.symbol 
      FROM customer c 
      JOIN currency cur ON c.currency = cur.id
      WHERE c.entityid = ?`,
      [customerId]
    );
  }
}

export default new CustomerDao();
