import * as nsutils from '../nsutils';

export enum EntityType {
  CUSTOMER = 'CUSTOMER',
  PROSPECT = 'PROSPECT',
}

export class EntityDao {
  getEntityStatusKey(entityType: EntityType, name: string) {
    const res = nsutils.queryFirstAsMap(
      "select key from entitystatus where entitytype=? and inactive = 'F' and name = ?",
      [entityType, name]
    );
    return res !== null ? res.key : undefined;
  }
}

export default new EntityDao();
