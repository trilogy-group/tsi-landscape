import * as nsutils from '../nsutils';

class InvoiceDao {
  findInvoiceInternalId(customerId: string, invoiceNumber: string): number | undefined {
    const inv = nsutils.queryFirstAsMap(
      `
    select id 
    from transaction i 
    WHERE
      i.billingaccount in (select ba.id from billingaccount ba join customer c on ba.customer=c.id where c.entityid=?)
      and i.abbrevtype='INV' 
      and i.tranid=?`,
      [customerId, invoiceNumber]
    );
    return inv ? inv.id : undefined;
  }
}

export default new InvoiceDao();
