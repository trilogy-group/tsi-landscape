import * as nsutils from '../nsutils';
import * as record from 'N/record';
import EntityDao, { EntityType } from './EntityDao';
import { Any } from '../types';
import { convert } from '../nsutils';

export enum QuoteEntityStatus {
  Proposal = 'Proposal',
  Signing = 'Signing',
}
export interface QuoteInfo {
  id: number;
  customerInternalId: number;
  customerId: string;
  endUserInternalId: number;
  endUserId: string;
  subscriptionId: number;
  createdDate: Date;
  dueDate: Date;
  status: QuoteEntityStatus;
  previewAgId: string;
  isSelfServe: boolean;
}

export interface AgreementInfo {
  parentId: number;
  id: number;
  type: string;
  status: string;
}

export enum AgreementRecipientType {
  Signer = 1,
  CC = 2,
}

class QuoteDao {
  findQuoteInfo(quoteId: number): QuoteInfo | undefined {
    return this.getQuotes([quoteId])[0];
  }

  getQuotes(quoteIds: number[]): QuoteInfo[] {

    // If there is no quote ID, return an empty array.
    if (quoteIds.length === 0) {
      return [];
    }

    // Query the database for the quote details.
    return nsutils.queryToJson(`
      SELECT DISTINCT
        t.id,
        t.createddate,
        t.duedate,
        t.entity as customerinternalid,
        c.entityid as customerid, 
        t.custbody_end_user as enduserinternalid,
        eu.entityid as enduserid,
        t.custbody_related_subscription as subscription,
        es.name as status,
        t.custbody_tsi_quotepreview_ag_id,
        t.custbody_self_serve
      FROM transaction t
      JOIN customer c ON c.id=t.entity
      JOIN customer eu ON eu.id=t.custbody_end_user
      JOIN entitystatus es ON es.key=t.entitystatus
      WHERE t.recordtype = 'estimate'
        AND t.id IN (${quoteIds.map(_ => '?').join(',')})
    `,
    [...quoteIds],
    {
      id: 'id',
      createddate: 'createdDate',
      duedate: 'dueDate',
      customerinternalid: 'customerInternalId',
      customerid: 'customerId',
      enduserinternalid: 'endUserInternalId',
      enduserid: 'endUserId',
      subscription: 'subscriptionId',
      status: 'status',
      custbody_tsi_quotepreview_ag_id: 'previewAgId',
      custbody_self_serve: { key: 'isSelfServe', f: (v) => convert.toBoolean(v) },
    });
  }

  findLastAdobeAgreementId(quoteId: number): number | undefined {
    return nsutils.queryFirstAsMap(
      `
    select id from 
          (select id from customrecord_echosign_agreement where custrecord_echosign_parent_record=? order by id desc)
        where ROWNUM <= 1`,
      [quoteId]
    )?.id;
  }

  findLastAgreementIdByType(quoteId: number, agreementType: number): number | undefined {
    return nsutils.queryFirstAsMap(
      `
    select id from 
          (select id from customrecord_echosign_agreement 
            where custrecord_echosign_parent_record = ? 
            and custrecord_agreement_type = ?
            order by id desc)
        where ROWNUM <= 1`,
      [quoteId, agreementType]
    )?.id;
  }

  /**
   * Find last created agreement and it's files in the quote
   */
  findLastAdobeAgreementInfo(quoteId: number): { id: number; files: number[] } {
    const res = nsutils.queryToJson(
      `
      select id, custrecord_echosign_agreement from 
      customrecord_echosign_document where custrecord_echosign_agreement in 
        (select id from 
          (select id from customrecord_echosign_agreement where custrecord_echosign_parent_record=? order by id desc)
        where ROWNUM <= 1)`,
      [quoteId]
    );
    return {
      id: res?.[0].custrecord_echosign_agreement,
      files: res.map((i) => {
        const docRec = record.load({
          type: 'customrecord_echosign_document',
          id: i.id,
        });
        return docRec.getValue('custrecord_echosign_file') as number;
      }),
    };
  }

  findAdobeAgreementRecipients(agId: number): Any[] {
    return nsutils
      .queryToJson(
        `SELECT id, custrecord_echosign_email as email,
          custrecord_echosign_role as role,
          custrecord_echosign_signer_order as order,
        FROM customrecord_echosign_signer 
        WHERE custrecord_echosign_agree=?
        ORDER BY custrecord_echosign_signer_order `,
        [agId]
      );
  }

  findSignedAgreementId(quoteId: number): number | undefined {
    return nsutils.queryFirstToJson(
      `SELECT id FROM customrecord_echosign_agreement 
        WHERE custrecord_echosign_status = 3 and isinactive = 'F' 
          and custrecord_echosign_parent_record = ?`,
      [quoteId]
    )?.id;
  }

  getAdobeAgreements(quoteId: number): { id: number; status: string }[] {
    return nsutils.queryToJson(
      `SELECT agr.id, status.name AS status
        FROM customrecord_echosign_agreement agr
        INNER JOIN customlist_echosign_status_types status ON status.id = agr.custrecord_echosign_status
        WHERE agr.custrecord_echosign_parent_record = ?`,
      [quoteId]
    );
  }

  /**
   * Returns the agreement details related to the given quotes.
   * @param {number[]} quoteIds An array of quote IDs.
   * @returns An array of agreement details.
   */
  getAdobeAgreementsInfo(quoteIds: number[]): AgreementInfo[] {

    // If there is no quote ID, return an empty array.
    if (quoteIds.length === 0) {
      return [];
    }

    // Query the database for the agreement details.
    return nsutils.queryToJson(`
      SELECT t.id AS parent, ag.id, agt.name AS type, ags.name AS status
      FROM transaction t
      LEFT JOIN customrecord_echosign_agreement ag ON ag.custrecord_echosign_parent_record = t.id
      LEFT JOIN customlist_echosign_status_types ags ON ags.id = ag.custrecord_echosign_status
      LEFT JOIN customlist_agreement_type_list agt ON agt.id = ag.custrecord_agreement_type
      WHERE t.recordtype = 'estimate'
        AND t.id IN (${quoteIds.map(_ => '?').join(',')})
    `,
    [...quoteIds],
    {
      parent: 'parentId',
      id: 'id',
      type: 'type',
      status: 'status',
    });
  }

  private getContactId(email: string, agreementId: number){
    return nsutils
      .queryToJson(
        `SELECT id, company FROM contact
        WHERE email = ? 
        and (company = (SELECT q.entity
                        FROM customrecord_echosign_agreement a
                        INNER JOIN transaction q on q.id = a.custrecord_echosign_parent_record
                        WHERE a.id = ?) or company is null)
        ORDER BY company`,
        [email, agreementId]
      )?.[0]?.id;
  }

  addAgreementRecipient(agId: number, email: string, cc: boolean, order: number, specificOrder: number): number {
    const rec = record.create({
      type: 'customrecord_echosign_signer',
    });
    rec.setValue({ fieldId: 'custrecord_echosign_agree', value: agId });
    const contactId = this.getContactId(email, agId);
    if (contactId) {
      rec.setValue({ fieldId: 'custrecord_echosign_signer', value: contactId });
    }
    rec.setValue({ fieldId: 'custrecord_echosign_email', value: email });
    rec.setValue({
      fieldId: 'custrecord_echosign_role',
      value: cc ? AgreementRecipientType.CC : AgreementRecipientType.Signer,
    });
    rec.setValue({ fieldId: 'custrecord_echosign_signer_order', value: order });

    if (!cc) {
      rec.setValue({ fieldId: 'custrecord_echosign_to_order', value: specificOrder });
    } else {
      rec.setValue({ fieldId: 'custrecord_echosign_cc_order', value: specificOrder });
    }
    return rec.save();
  }

  updateStatus(quoteId: number, status: QuoteEntityStatus) {
    const quoteRec = record.load({
      type: record.Type.ESTIMATE,
      id: quoteId,
    });
    quoteRec.setValue('entitystatus', EntityDao.getEntityStatusKey(EntityType.PROSPECT, status));
    quoteRec.save();
  }

  /**
   * Hard linked quotes are quotes linked through transaction line and to delete a subscription we also need to delete the quote
   */
  findHardLinkedQuotes(subscriptionId: number): number[] {
    return nsutils
      .queryToJson(
        `
      select distinct
        t.id
      from transaction t 
      join transactionline tl on tl.transaction=t.id and tl.subscription is not null 
      join customer c on c.id=t.entity
      join customer eu on eu.id=t.custbody_end_user
      join entitystatus es on es.key=t.entitystatus
      where t.recordtype='estimate' and tl.subscription=?`,
        [subscriptionId]
      )
      .map((r) => r.id);
  }

  /**
   * Soft linked quotes are linked through a custom field. This field is only a integer fields that will contain the subscription id.
   */
  findSoftLinkedQuotes(subscriptionId: number): number[] {
    return nsutils
      .queryToJson(
        `select t.id
        from transaction t 
        where t.recordtype='estimate' and t.custbody_related_subscription=?`,
        [subscriptionId]
      )
      .map((r) => r.id);
  }

  /**
   * Finds quotes related to a given subscription, whether they are hard-linked or soft-linked quotes.
   * @param {number} subscriptionId The subscription ID.
   * @returns {number[]} An array of quote IDs.
   */
  findLinkedQuotes(subscriptionId: number): number[] {
    return [
      ...this.findHardLinkedQuotes(subscriptionId),
      ...this.findSoftLinkedQuotes(subscriptionId),
    ];
  }

  findTcMapping(key: TcKeys): number | undefined {
    return nsutils.queryFirstAsMap(`select id from customrecord_quote_tcs_mapping where name =? and ROWNUM <= 1`, [key])
      ?.id;
  }

  findEmployeeId(name: string): number | undefined {
    const res = nsutils.queryFirstToJson(`SELECT id, entityid FROM employee WHERE upper(entityid) = upper(?)`, [
      name,
    ])?.id;
    nsutils.logMayBe('findEmployeeId res', res);
    return res;
  }

  getQuoteIdByTranId(tranId: string): number | undefined {
    return nsutils.queryFirstToJson(
      `SELECT id FROM transaction WHERE recordtype = 'estimate' and tranid = ?`,
      [tranId]
    )?.id;
  }

  getTermId(term?: string): number | undefined {
    if (!term) {
      return undefined;
    }
    return nsutils.queryFirstToJson(
      `SELECT id FROM term WHERE name = ?`,
      [term]
    )?.id;
  }

  /**
   * Only returns signed quotes (custrecord_echosign_status = 3 is signed) or
   * contractual documents that have link to contract pdf set
   * @param customerId
   * @param endUserId in case of customer being a reseller, to get the signed quotes for a specific end user
   * @returns quotes order by subscription start date desc, then subscription id desc, then link type desc
   * link types are Soft link, Hard link, Contractual documents
   * custrecord_agreement_type = 1 is quote
   */
  getSignedQuotesByCustomer(customerId: number, endUserId?: number): {
    subscriptionId: number;
    subscriptionName: string;
    subscriptionStartDate: Date;
    subscriptionStatus: string;
    quoteId?: number;
    quoteNumber?: number;
    agreementId?: number;
    agreementStatus?: string;
    contractualDocumentsLink?: string;
    linkType: string;
  }[] {
    nsutils.logMayBe('getSignedQuotesByCustomer params', { customerId, endUserId });
    let queryParams = `s.customer = ${customerId}`;
    if (endUserId) {
      queryParams += ` AND s.custrecord_subs_end_user = ${endUserId}`;
    }
    nsutils.logMayBe('getSignedQuotesByCustomer queryParams', { queryParams });
    const res = nsutils.queryToJson(
      `SELECT distinct qj.subscriptionId, s.name as subscriptionName, s.startdate, s.billingsubscriptionstatus,
        qj.quoteId, qt.tranId as quoteNumber, ag.id as agreementId, ags.name as agreementStatus,
        qj.contractualDocumentsLink, qj.linkType
      FROM (
        SELECT slq.custbody_related_subscription as subscriptionId, slq.id as quoteId,
          null as contractualDocumentsLink, 'softLink' as linkType
        FROM transaction slq
        WHERE slq.recordtype='estimate'
        AND slq.custbody_related_subscription in (
          SELECT s.id FROM subscription s WHERE ${queryParams} AND s.custrecord_isautorenewal = 'F'
        )
        UNION
        SELECT tl.subscription as subscriptionId, hlq.id as quoteId,
          null as contractualDocumentsLink, 'hardLink' as linkType
        FROM transaction hlq
        INNER JOIN transactionline tl ON tl.transaction = hlq.id AND tl.subscription is not null
        WHERE hlq.recordtype='estimate'
        AND tl.subscription in (
          SELECT s.id FROM subscription s WHERE ${queryParams} AND s.custrecord_isautorenewal = 'F'
        )
        UNION
        SELECT s.id as subscriptionId, custrecord_sub_doc_quote as quoteId,
          custrecord_sub_doc_link as contractualDocumentsLink, 'contractualDocuments' as linkType
        FROM subscription s
        INNER JOIN customrecord697 cd ON cd.id = s.custrecord_contract_docs
        WHERE ${queryParams}
          AND s.custrecord_isautorenewal = 'F'
          AND (cd.custrecord_sub_doc_quote is not null or cd.custrecord_sub_doc_link is not null)
      ) qj
      INNER JOIN subscription s ON s.id = qj.subscriptionId
      INNER JOIN subscriptionchangeorder sco ON sco.subscription = s.id AND sco.action = 'ACTIVATE'
        AND sco.subscriptionchangeorderstatus = 'ACTIVE'
      LEFT JOIN customrecord_echosign_agreement ag ON ag.custrecord_echosign_parent_record = qj.quoteId
        AND (ag.custrecord_agreement_type = 1 OR ag.custrecord_agreement_type is null)
        AND  ag.custrecord_echosign_status = 3
      LEFT JOIN customlist_echosign_status_types ags ON ags.id = ag.custrecord_echosign_status
      LEFT JOIN transaction qt ON qt.id = qj.quoteId
      WHERE (ag.custrecord_echosign_status = 3 or qj.contractualDocumentsLink is not null)
      ORDER BY s.startdate DESC, qj.subscriptionId DESC, qj.linkType DESC
      `,
      [],
      {
        subscriptionid: 'subscriptionId',
        subscriptionname: 'subscriptionName',
        startdate: 'subscriptionStartDate',
        billingsubscriptionstatus: 'subscriptionStatus',
        quoteid: 'quoteId',
        quotenumber: 'quoteNumber',
        agreementid: 'agreementId',
        agreementstatus: 'agreementStatus',
        contractualdocumentslink: 'contractualDocumentsLink',
        linktype: 'linkType',
      }
    );
    nsutils.logMayBe('getSignedQuotesByCustomer res', res);
    return res;
  }

  getOrderTypeAndOutboundEmailDomain(quoteId: number): {
    orderType: number,
    outboundEmailDomain: string,
  } | undefined {
    return nsutils.queryFirstToJson(
      `
      SELECT 
        ot.id as order_type, 
        c.custrecord_outbound_email_domain as outbound_email_domain
      FROM transaction t
      LEFT JOIN customlist_order_type ot ON ot.id = t.custbody_order_type
      LEFT JOIN subscriptionplan sp ON sp.id = t.custbody_subscription_plan
      LEFT JOIN classification c ON c.id = sp.class
      WHERE t.id = ?
      `,
      [quoteId],
      {
        order_type: "orderType",
        outbound_email_domain: 'outboundEmailDomain',
      }
    );
  }
}

export enum TcKeys {
  Saas = 'SAAS',
  OnPremise = 'ONPREMISE',
  ProfessionalServices = 'PS',
  Maintenance = 'MAINTENANCE',
  EUA_Maintenance = 'EUAMAINTENANCE',
}

export default new QuoteDao();
