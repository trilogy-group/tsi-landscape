import { OperationContext } from '../models/OperationContext';
import * as nsutils from '../nsutils';
import { BillingSchedule, SqlParams, SubscriptionStatus, TermUnit } from '../types';
import { isNotNull } from '../validation';

//FIXME: Change the places where endUserCompanyName is used to use endUserName and remove endUserCompanyName
export interface SubscriptionInfoForQuote {
  startDate: Date;
  endDate: Date;
  endUserId: string;
  customerId: string;
  customerInternalId: number;
  endUserInternalId: number;
  endUserCompanyName: string;
  status: SubscriptionStatus;
  subscriptionName: string;
  endUserName: string;
  productClass: string;
  renewalNumber?: string;
  frequency: BillingSchedule;
  subscriptionPlanId: number;
}

/**
 * Information needed for Quote not linked to a subscription to be created.
 */
export interface UnlinkedQuoteInfo {
  startDate: Date;
  endDate: Date;
  endUserId: string;
  customerInternalId: number;
  endUserInternalId: number;
  endUserCompanyName: string;
  productClass: string;
  renewalNumber?: string;
  frequency: BillingSchedule;
}

export enum SubscriptionStatusChangeReason {
  // Customer Activated
  CUSTOMER_ACTIVATED = 1,
  // Customer Cancelled
  CUSTOMER_CANCELLED = 2,
  // Auto Renewed
  AUTO_RENEWED = 3,
  // Finance Action
  FINANCE_ACTION = 4,
  //Invalid Subscription
  INVALID_SUBSCRIPTION = 5,
}

export class SubscriptionDao {
  findPricesAndItemFields(pricePlanId: number, itemId: number) {
    nsutils.logMayBe('findPricesAndItemFields params', { pricePlanId, itemId });
    const res = nsutils.queryToJson(
      `
    SELECT i.id,
      i.itemid         AS code,
      i.displayname    AS title,
      i.description,
      pmt.name         AS pricetype,
      pp.id            AS priceplanid,
      pt.fromval       AS fromquantity,
      pt.value         AS price,
      pt.pricingoption,
      i.maximumquantity,
      i.minimumquantity,
      ir.id as renewitemid,
      ir.itemid as renewitemcode,
      sl.name as support_level_name,
      ptier.name as product_tier_name
    FROM  item i
      LEFT JOIN customlist_support_level sl
        ON sl.id=i.custitem_support_level
      LEFT JOIN item ir
        ON ir.id = i.custitem_renew_with
      LEFT JOIN customlist_product_tier ptier
        ON ptier.id=i.custitem_product_tier
      , priceplan pp
      JOIN pricetiers pt
        ON pt.priceplan = pp.id
      JOIN pricemodeltype pmt
        ON pmt.KEY = pp.priceplantype
    WHERE  pp.id=? AND i.id=?
    ORDER BY fromquantity
  `,
      [pricePlanId, itemId]
    );
    nsutils.logMayBe('findPricesAndItemFields res', res);
    return res;
  }

  findTodaysActiveModifyPricingCO(subscriptionId: number) {
    return nsutils
      .queryToJson(
        `
  select id from subscriptionchangeorder 
  where subscription=? and action='MODIFY_PRICING' and  subscriptionchangeorderstatus='ACTIVE' and effectivedate=trunc(current_date)
  `,
        [subscriptionId]
      )
      .map((i) => i.id);
  }

  findTodaysCO(subscriptionId: number, actions: Array<string>) {
    const sqlParams: SqlParams = [subscriptionId];
    for (const item of actions) {
      sqlParams.push(item);
    }
    return nsutils.queryToJson(
      `
      SELECT id FROM subscriptionchangeorder 
      WHERE subscription=? and action IN (${actions.map(() => '?').join(',')}) 
        AND subscriptionchangeorderstatus='ACTIVE' and effectivedate=trunc(current_date)
  `,
      sqlParams
    );
  }

  getCustomerSubscriptionIds(
    customerId: string,
    opts: {
      productFamilyCode: string;
      productVariantCode?: string;
      statuses?: Array<string>;
      maxResults?: number;
      isTrial?: boolean;
    }
  ) {
    nsutils.logMayBe('getCustomerSubscriptionIds params', { customerId, opts });

    let sql = `select s.id from subscription s 
      join customer c on c.id=s.custrecord_subs_end_user 
      join subscriptionplan sp on sp.itemid=s.subscriptionplanname 
      join customrecordproductintegration pi on pi.custrecordclass=sp.class
      where pi.custrecordproductfamilycode = ? and c.entityid=? and upper(pi.custrecordproductvariantcode) = upper(REGEXP_REPLACE(
        sp.displayname,
        '[^-]+-([^-]+-[^-]+)-.*',
        '\\1'
        ))`;
    const sqlParams: SqlParams = [opts.productFamilyCode, customerId];
    if (isNotNull(opts.productVariantCode)) {
      sql += ' and pi.custrecordproductvariantcode = ?';
      sqlParams.push(opts.productVariantCode);
    }

    if (opts.statuses && opts.statuses.length > 0) {
      sql += ` AND s.billingsubscriptionstatus IN (${opts.statuses.map(() => '?').join(',')})`;
      for (const st of opts.statuses) {
        sqlParams.push(st);
      }
    }

    if (isNotNull(opts.isTrial)) {
      sql += ' AND subscriptionplanname in (select name from subscriptionplan where custitemistrial=?)';
      sqlParams.push(opts.isTrial);
    }

    nsutils.logMayBe('getCustomerSubscriptionIds query', { sql, sqlParams });
    const res = nsutils.queryToJson(sql, sqlParams, undefined, opts.maxResults);

    nsutils.logMayBe('getCustomerSubscriptionIds res', res);
    return res;
  }

  /**
   * Returns True if there is at least one 'Draft' subscription with the given end-user for the given context; otherwise, returns False.
   * @param {OperationContext} context The context of the operation.
   * @param {string} endUserId The end-user ID (i.e. the entity ID).
   * @returns Whether there is at least one 'Draft' subscription with the given end-user for the given context.
   */
  isEndUserInDraftSubscriptions(context: OperationContext, endUserId: string): boolean {

    // Build the default query.
    let query = `
      SELECT COUNT(*) AS count
      FROM subscription s
      JOIN subscriptionplan sp ON sp.itemid = s.subscriptionplanname 
      JOIN customrecordproductintegration pi ON pi.custrecordclass = sp.class
        AND UPPER(pi.custrecordproductvariantcode) = UPPER(REGEXP_REPLACE(
            sp.displayname,
            '[^-]+-([^-]+-[^-]+)-.*',
            '\\1'
          ))
      JOIN customer c ON c.id = s.customer
      JOIN customer ceu ON ceu.id = custrecord_subs_end_user
      WHERE s.billingsubscriptionstatus = 'DRAFT'
        AND ceu.entityid = ?
        AND pi.custrecordproductfamilycode = ?
    `;
    const params = [endUserId, context.productFamilyCode];

    // If available, add additional conditions.
    if (context.customerId) {
      query += 'AND c.entityid = ?';
      params.push(context.customerId);
    }
    if (context.productVariantCode) {
      query += ' AND pi.custrecordproductvariantcode = ?';
      params.push(context.productVariantCode);
    }

    // Execute the query and map the result to an array of end user IDs.
    const result = nsutils.queryFirstToJson(query, params);
    return parseInt(result.count) > 0;
  }

  findItemCodes(
    itemIds: Array<number>
  ): Array<{ id: number; status: string | undefined; code: string; supportlevelid: number }> {
    return nsutils.queryToJson(
      `SELECT id, itemid as code , custitem_support_level as supportlevelid FROM item WHERE id in (${itemIds
        .map(() => '?')
        .join(',')})`,
      itemIds
    );
  }

  findSubscriptionItemCodes(
    itemIds: Array<number>,
    planId: string
  ): Array<{ id: number; status: string | undefined; code: string; supportlevelid: number; isrequired: boolean }> {
    return nsutils.queryToJson(
      `SELECT item.id as id, itemid as code, custitem_support_level as supportlevelid, spm.isrequired as isrequired
        FROM item 
        INNER JOIN subscriptionplanmember spm on spm.item = item.id and spm.subscriptionplan = ?
      WHERE item.id in (${itemIds.map(() => '?').join(',')})`,
      [planId, ...itemIds],
      {
        id: 'id',
        code: 'code',
        supportlevelid: 'supportlevelid',
        isrequired: { key: 'isrequired', f: nsutils.convert.toBoolean },
      }
    );
  }

  findStandardTerm(duration: number, unit: TermUnit) {
    return nsutils.queryFirstToJson(
      `
      SELECT id
      FROM  subscriptionterm
      WHERE isinactive = ? and
            subscriptiontermduration = ? and 
            subscriptiontermunit = ? and 
            subscriptiontermtype = ?
    `,
      ['F', duration, unit, 'STANDARD']
    );
  }

  getSubscriptionPlanId(subscriptionId) {
    return nsutils.queryFirstToJson(
      `
      SELECT pb.subscriptionplan FROM subscription s
        INNER JOIN pricebook pb on s.pricebook = pb.id
        WHERE s.id = ?
    `,
      [subscriptionId]
    )?.subscriptionplan;
  }

  getCurrentItems(subscriptionId: number) {
    const items = nsutils.queryToJson(
      `SELECT pi.linenumber, pi.item as itemid, i.itemid as code, pi.quantity, pi.totalintervalvalue, pi.status, spm.isrequired, pi.priceplan
        FROM subscriptionPriceInterval pi
        INNER JOIN item i on i.id = pi.item
        INNER JOIN subscription s on s.id = pi.subscription
        INNER JOIN pricebook pb on pb.id = s.pricebook
        INNER JOIN subscriptionplanmember spm on spm.subscriptionplan = pb.subscriptionplan and spm.item = pi.item
        WHERE pi.subscription = ?
        ORDER BY pi.linenumber, pi.enddate desc`,
      [subscriptionId]
    );
    //remove duplicates
    for (let i = items.length - 1; i > 0; i--) {
      if (items[i].linenumber === items[i - 1].linenumber) {
        items.splice(i, 1);
      }
    }
    return items;
  }

  findSubsidiaryId(subscriptionId: number): number | undefined {
    return nsutils.queryFirstAsMap(`select subsidiary from subscription where id = ?`, [subscriptionId])?.subsidiary;
  }

  getInfoForQuote(subscriptionId: number): SubscriptionInfoForQuote {
    //FIXME: remove c_enduser.title or change to e_enduser.salutation. c_enduser.title is the job title
    //FIXME: change endusercompany to endusername
    const res = nsutils.queryFirstToJson(
      `
      select 
        s.startdate as start_date, 
        s.enddate, 
        s.custrecord_subs_end_user,
	      c_enduser.id enduserinternalid,
        c_enduser.entityid as enduserid,
        case
           when c_enduser.isperson = 'T' then REGEXP_REPLACE(c_enduser.title || ' ' || c_enduser.firstname || ' ' || c_enduser.middlename || ' ' || c_enduser.lastname, '  +', ' ')
          else c_enduser.companyname
        end as endusercompany,
        c_cust.id customerinternalid,
        c_cust.entityid as customerid,
        s.billingsubscriptionstatus,
        s.renewalnumber as subs_renewal_number,
        cl.fullname as class_name,
        case when bs.frequency = 'MONTHLY' and bs.repeatevery=3 then 'QUARTERLY' else s.frequency end as frequency,
        sp.id as subscription_plan_id
      from subscription s 
      left join customer c_enduser on s.custrecord_subs_end_user=c_enduser.id
      join customer c_cust on s.customer=c_cust.id
      join subscriptionplan sp on sp.itemid=s.subscriptionplanname 
      join billingschedule bs on bs.id=s.billingschedule
      left join classification cl on cl.id=sp.class
      where s.id=?
    `,
      [subscriptionId],
      {
        start_date: { key: 'startDate', f: nsutils.convert.toDate },
        enddate: { key: 'endDate', f: nsutils.convert.toDate },
        custrecord_subs_end_user: 'endUserInternalId',
        enduserid: 'endUserId',
        customerinternalid: 'customerInternalId',
        enduserinternalid: 'endUserInternalId',
        customerid: 'customerId',
        endusercompany: 'endUserCompanyName',
        billingsubscriptionstatus: 'status',
        subs_renewal_number: 'renewalNumber',
        class_name: 'productClass',
        frequency: 'frequency',
        subscription_plan_id: 'subscriptionPlanId',
      }
    );
    nsutils.logMayBe('getInfoForQuote res', res);
    return res;
  }

  findUpdates(subscriptionId: number, status: SubscriptionStatus): number[] {
    return nsutils
      .queryToJson(
        `select id from subscription where billingsubscriptionstatus=? and name like '% - Update - ${subscriptionId}'`,
        [status]
      )
      .map((r) => r.id);
  }

  public findSubscriptionIdsByContractualDocumentsIds(contractualDocumentsIds: number[]): number[] {
    if(!contractualDocumentsIds || contractualDocumentsIds.length === 0) {
      // No contractual documents
      return [];
    }
    return nsutils
      .queryToJson(
        `
        SELECT id
        FROM subscription
        WHERE custrecord_contract_docs in (${contractualDocumentsIds.join(',')})`,
        []
      )
      .map((r) => r.id);
  }

  public getRenewalHistoryOfSubscription(subscriptionId: number): { id: number; status: SubscriptionStatus }[] {
    const sql = `
    SELECT renewal_subscr.id, renewal_subscr.billingsubscriptionstatus status
      FROM subscription renewal_subscr
      LEFT JOIN subscriptionRenewalHistory hist on hist.newsubscription = renewal_subscr.id
      WHERE hist.subscription = ?`;
    const items = nsutils.queryToJson(sql, [subscriptionId], {
      id: 'id',
      status: {
        key: 'status',
        f: function (nsStr: string): SubscriptionStatus {
          return SubscriptionStatus[nsStr];
        },
      },
    });
    nsutils.logMayBe('getRenewalHistoryOfSubscription ' + subscriptionId + ' items', items);

    return items;
  }

  getCurrencySymbol(currencyId: number): string {
    return nsutils.queryFirstToJson(`SELECT symbol FROM currency WHERE id = ?`, [currencyId])?.symbol;
  }
  
  //find signed quote Id for a specified subscription
  public findSignedQuoteId(subscriptionId: number): number | null {

    //searching a quote with a signed quote agreement for a specified subscription
    const query = `
      select distinct
        t.id as tid,
        a.id as aid
      from 
        CUSTOMRECORD_ECHOSIGN_AGREEMENT a
        join transaction t on a.custrecord_echosign_parent_record = t.id
        left join transactionline tl on tl.transaction = t.id
      WHERE 
        a.custrecord_agreement_type = 1 /* Quote */
        and a.custrecord_echosign_status= 3 /* Signed */
        and a.custrecord_echosign_parent_type = 'estimate'
        and t.recordtype='estimate'
        and t.status not in ('C' /*Closed*/, 'V' /* Voided */)
        and (tl.subscription = ? or t.custbody_related_subscription = ?)`;

    return nsutils.queryFirstAsMap(query, [subscriptionId, subscriptionId])?.tid;
  }

  /**
   * Returns the currency of the subscription.
   * @param {number} subscriptionId The subscription ID.
   * @returns The ID and the symbol of the currency.
   */
  getCurrency(subscriptionId: number): { id: number; symbol: string } {
    return nsutils.queryFirstAsMap(`
      SELECT cur.id, cur.symbol 
      FROM subscription s
      JOIN currency cur ON s.currency = cur.id
      WHERE s.id = ?`,
      [subscriptionId]
    );
  }

  /**
   * Filter the subscriptions returning only subscriptions that are not prime and that have a parent subscription.
   */
  getSubscriptionsToSync(subscriptionIds: number[]): {
    id: number;
    class: string;
  }[] {
    return nsutils.queryToJson(
      `SELECT s.id, class.fullname as class
      FROM subscription s
      INNER JOIN classification class on class.id = s.class
      LEFT JOIN subscriptionRenewalHistory hist on hist.newsubscription = s.id
      WHERE s.id IN (${subscriptionIds.join(',')})
      AND (s.custrecord_isprime IS NULL OR s.custrecord_isprime <> 1)
      AND CASE
        WHEN s.custrecord_parent_subscription IS NOT NULL THEN s.custrecord_parent_subscription
        ELSE hist.subscription
      END IS NOT NULL
      `,
      []
    );
  }
}

export default new SubscriptionDao();
