import { ListSubscriptionPlanParams, PlanInfo } from '../models/SubscriptionPlan';
import * as nsutils from '../nsutils';
import { BillingSchedule, ProductTier, ProductTierUtil, SqlParams, SupportLevel, SupportLevelUtil } from '../types';

export class SubscriptionPlanDao {
  getSubscriptionPlanInfos(params: ListSubscriptionPlanParams): PlanInfo[] {
    nsutils.logMayBe('getSubscriptionPlans params', params);
    let sql = `
      SELECT sp.id, sp.itemid, sp.displayname, sp.description, sp.description AS title, sp.defaultrenewalplan,
        pi.custrecordproductfamilycode, pi.custrecordproductfamilytitle, pi.custrecordproductvariantcode, pi.custrecordproductvarianttitle,
        pi.custrecordtierlabelstandard, pi.custrecordtierlabelprofessional, pi.custrecordtierlabelenterprise, 
        st.name as initialtermname, st.subscriptiontermunit, st.subscriptiontermduration, st.subscriptiontermtype
      FROM subscriptionplan sp
      LEFT JOIN subscriptionPlan rp on rp.id = sp.defaultrenewalplan
      LEFT JOIN customrecordproductintegration pi ON pi.custrecordclass = COALESCE(rp.class, sp.class)
        AND upper(pi.custrecordproductvariantcode) = upper(REGEXP_REPLACE(
          COALESCE(rp.displayname, sp.displayname),
          '[^-]+-([^-]+-[^-]+)-.+',
          '\\1'
        ))
      JOIN subscriptionTerm st
        ON sp.initialterm = st.id
    `;
    const queryParams: SqlParams = [];
    const whereClause: string[] = [];
    if (!params.getInactive) {
      whereClause.push(`sp.isinactive='F'`);
    }
    if (params.productFamilyCode) {
      whereClause.push('pi.custrecordproductfamilycode=?');
      queryParams.push(params.productFamilyCode);
    }
    if (params.productVariantCode) {
      whereClause.push('pi.custrecordproductvariantcode=?');
      queryParams.push(params.productVariantCode);
    }
    if (params.subscriptionPlanId) {
      whereClause.push('sp.id=?');
      queryParams.push(params.subscriptionPlanId);
    }
    if (params.subscriptionPlanCode) {
      whereClause.push('sp.itemid=?');
      queryParams.push(params.subscriptionPlanCode);
    }
    if (whereClause.length > 0) {
      sql += `WHERE ${whereClause.join(' AND ')}`;
    }
    nsutils.logMayBe('getSubscriptionPlans sql', sql);
    return nsutils.queryToJson(sql, queryParams, {
      id: 'id',
      itemid: 'name',
      displayname: 'code',
      description: 'description',
      title: 'title',
      defaultrenewalplan: 'renewalPlanId',
      custrecordproductfamilycode: 'product.family.code',
      custrecordproductfamilytitle: 'product.family.title',
      custrecordproductvariantcode: 'product.variant.code',
      custrecordproductvarianttitle: 'product.variant.title',
      custrecordtierlabelstandard: `product.tierLabels.${ProductTier.Standard}`,
      custrecordtierlabelprofessional: `product.tierLabels.${ProductTier.Professional}`,
      custrecordtierlabelenterprise: `product.tierLabels.${ProductTier.Enterprise}`,
      initialtermname: 'initialterm.name',
      subscriptiontermunit: 'initialterm.unit',
      subscriptiontermduration: 'initialterm.duration',
      subscriptiontermtype: 'initialterm.type',
    }) as PlanInfo[];
  }

  getInternalIdAndSubsidiary(
    name: string | undefined
  ): { id: number; subsidiaries: string[]; class: number } | undefined {
    if (name === undefined || name === null) {
      return undefined;
    }
    return nsutils.queryFirstToJson('select id, subsidiary, class from subscriptionplan where itemid=?', [name], {
      id: 'id',
      class: 'class',
      subsidiary: { key: 'subsidiaries', f: (v: string) => v.split(',').map((velm) => velm.trim()) },
    });
  }

  getClassDetails(subscriptionPlanId: number): {
    classId: number,
    productClassName: string,
    subscriptionPlanId: number,
  } | undefined {
    return nsutils.queryFirstToJson(
      `
      SELECT 
        sp.class as class_id,
        cl.fullname as product_class_name,
        sp.id as subscription_plan_id
      FROM subscriptionPlan sp
      LEFT JOIN classification cl on cl.id = sp.class
      WHERE sp.id = ?
      `,
      [subscriptionPlanId],
      {
        class_id: "classId",
        product_class_name: 'productClassName',
        subscription_plan_id: 'subscriptionPlanId',
      }
    );
  }

  findPriceBook(subscriptionPlanId: number, customerId: string, frequency: BillingSchedule): number | undefined {
    const res = nsutils.queryFirstAsMap(
      `
      SELECT pb.id
      FROM  pricebook pb
        JOIN priceBookLineInterval pi on pi.pricebook=pb.id and pi.linenumber=1
      WHERE  pb.subscriptionplan = ?
        AND pb.currency IN (SELECT currency
                            FROM   customer
                            WHERE  entityid = ? ) 
        AND pi.frequency = ?
        AND pb.name NOT LIKE '%DO NOT USE%'
      `,
      [subscriptionPlanId, customerId, frequency]
    );
    return !res ? undefined : res.id;
  }

  getItemIds(itemCodes?: string[]) {
    if (!itemCodes) {
      return undefined;
    }
    const res = nsutils.queryToJson(
      `
      SELECT id
      FROM item
      WHERE itemid in (${itemCodes.map(() => '?').join(',')})
      `,
      [...itemCodes]
    );
    return res.map((i) => i.id);
  }

  getItems(itemCodes?: string[]):
    | {
      id: number;
      code: string;
    }[]
    | undefined {
    if (!itemCodes) {
      return undefined;
    }
    return nsutils.queryToJson(
      `
      SELECT id, itemid as code
      FROM item
      WHERE itemid in (${itemCodes.map(() => '?').join(',')})
      `,
      [...itemCodes]
    );
  }

  getFrequencyFromPriceBook(id: number): string {
    return nsutils.queryFirstToJson(
      `SELECT frequency FROM priceBookLineInterval WHERE pricebook = ? order by linenumber`,
      [id]
    )?.frequency;
  }

  getSilverSubscriptionPlan(planCode: string):
    | {
      id: number;
      displayname: string;
      itemid: string;
    }
    | undefined {
    if (!planCode) {
      return undefined;
    }
    const parts = planCode.split('-');
    let silverCode = `${parts[0]}-${parts[1]}-${parts[2]}-${parts[3]}-SIL`;
    let query;
    if (parts[5] === 'MNT') {
      silverCode = silverCode.concat('-MNT%');
      query = `SELECT id, displayname, itemid FROM subscriptionplan WHERE lower(displayname) like lower(?)
        ORDER BY displayname desc`;
    } else {
      silverCode = silverCode.concat('%');
      query = `SELECT id, displayname, itemid FROM subscriptionplan where lower(displayname) like lower(?) AND
        displayname not like ('%-MNT-%') ORDER BY displayname desc`;
    }
    return nsutils.queryFirstToJson(query, [silverCode]);
  }

  /**
   * Returns the latest active subscription plan for the given product family, variant, tier, the support level and the revenue type.
   * @param productFamilyCode The product family code.
   * @param productVariantCode  The product variant code.
   * @param productTier  The product tier.
   * @param supportLevel  The support level.
   * @param isSupport  Whether the revenue type is Support or not.
   * @returns The latest subscription plan matching the input params.
   */
  getLatestSubscriptionPlan(
    productFamilyCode: string,
    productVariantCode: string,
    productTier: ProductTier,
    supportLevel: SupportLevel,
    isSupport: boolean
  ):
    | {
      id: number;
      displayname: string;
      itemid: string;
    }
    | undefined {
    // Determine the plan code prefix.
    const planCodeParts = [
      productFamilyCode,
      productVariantCode,
      ProductTierUtil.productTierToCode(productTier),
      SupportLevelUtil.supportLevelToCode(supportLevel),
    ];
    if (isSupport) {
      planCodeParts.push('MNT');
    }
    const planCodePrefix = planCodeParts.join('-');

    // Build the query retrieving matching subscription plans sorted by version descending.
    const query = `
      SELECT id, displayname, itemid
      FROM subscriptionplan
      WHERE isInactive = 'F'
        AND LOWER(displayname) LIKE LOWER(?)
        ${isSupport ? '' : "AND displayname NOT LIKE ('%-MNT-%')"}
      ORDER BY displayname DESC
    `;

    // Execute the query and return the result.
    return nsutils.queryFirstToJson(query, [planCodePrefix.concat('-%')]);
  }

  /**
   * Returns the product tier code from the items of the subscription plan.
   * - If there is no product tier code, returns undefined.
   * - If there is more than one product tier code, returns the first one ordered by the line number.
   * @param subscriptionPlanId The identifier of the subscription plan.
   * @returns The product tier code.
   */
  getProductTierCodeFromItems(subscriptionPlanId: number): string | undefined {
    // Determine the possible values for the product tier suffix.
    const productTierCodes = Object.values(ProductTier).map(ProductTierUtil.productTierToCode);

    // Build the query retrieving the product tier suffix from the items of the subscription plan.
    const query = `
      SELECT TOP 1 t.itemsuffix
      FROM (
        SELECT spm.linenumber, REGEXP_REPLACE(i.itemid, '.+-([^-]+)', '\\1') as itemsuffix
        FROM subscriptionplanmember spm
        JOIN item i ON i.id = spm.item
        WHERE subscriptionplan = ?
      ) t
      WHERE t.itemsuffix IN (${productTierCodes.map((_) => '?').join(',')})
      ORDER BY t.linenumber
    `;

    // Execute the query and return the result.
    const result = nsutils.queryFirstToJson(query, [subscriptionPlanId, ...productTierCodes]);
    return result?.itemsuffix;
  }

  getRenewalItems(itemIds: number[]): {
    id: number;
    code: string;
    renewId: number;
    renewCode: string;
  }[] {
    return nsutils.queryToJson(
      `
      SELECT i.id, i.itemid as code, r.id as renewId, r.itemid as renewCode
      FROM item i
      LEFT JOIN item r ON i.custitem_renew_with = r.id
      WHERE i.id in (${itemIds.map(() => '?').join(',')})
      `,
      [...itemIds],
      {
        id: 'id',
        code: 'code',
        renewid: 'renewId',
        renewcode: 'renewCode',
      }
    );
  }

  /**
   * Returns the product family code from the subscription plan ID.
   * If a default renewal plan is defined, considers it instead of the target subscription.
   * If the subscription plan code is not structured, returns undefined. It is not possible to determine the product family code.
   * If there is no match, returns undefined.
   * @param subscriptionPlanId The subscription plan ID.
   * @returns The product family code.
   */
  getProductFamilyCode(subscriptionPlanId: number): string | undefined {
    return nsutils.queryFirstToJson(
      `
        SELECT REGEXP_REPLACE(COALESCE(rsp.displayname, sp.displayname), '([^-]+)-.+', '\\1') AS pfc
        FROM subscriptionplan sp
        LEFT JOIN subscriptionplan rsp ON rsp.id = sp.defaultrenewalplan
        WHERE sp.id = ?
          AND REGEXP_LIKE(COALESCE(rsp.displayname, sp.displayname), '[^-]+-.+')
      `,
      [subscriptionPlanId]
    )?.pfc;
  }
}

export default new SubscriptionPlanDao();
