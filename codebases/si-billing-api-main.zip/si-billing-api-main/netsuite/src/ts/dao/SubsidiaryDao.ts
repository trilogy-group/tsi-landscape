import * as nsutils from '../nsutils';

export class SubsidiaryDao {
  getSubsidiaryName(id: number) {
    return nsutils.queryFirstAsMap(
      "SELECT name FROM subsidiary WHERE id = ?",
      [id]
    )?.name;
  }

  getServiceProviderQuoteSigner(id: number) {
    const res = nsutils.queryFirstAsMap(
      `SELECT e.email, s.parent
      FROM subsidiary s
      LEFT JOIN employee e on e.id = s.custrecord_subsidiary_signatory
      WHERE s.id = ?`,
      [id]
    );
    if (res) {
      if (res.email) {
        if (!nsutils.isProduction()){
          res.email += '.invalid';
        }
        return res.email;
      }
      if (res.parent) {
        return this.getServiceProviderQuoteSigner(res.parent);
      }
    }
    return undefined;
  }
}

export default new SubsidiaryDao();
