/**
 * @NApiVersion 2.1
 * @NModuleScope SameAccount
 * @NScriptType UserEventScript
 */

import * as record from "N/record";
import * as redirect from "N/redirect";
import { EntryPoints } from "N/types";
import { FieldType } from "N/ui/serverWidget";
import { QuoteRecord } from "../models/QuoteRecord";
import * as nsutils from '../nsutils';

/**
 * Replaces the 'Send For Signature' button with a custom one showing an error message if the agreement type is empty.
 * @param context
 * @returns
 */
export const beforeLoad: EntryPoints.UserEvent.beforeLoad = (context: EntryPoints.UserEvent.beforeLoadContext) => {
    // If the user event type is different than VIEW, then return.
    if (context.type !== context.UserEventType.VIEW) {
        return;
    }

    replaceSendForSignatureButton(context);
    setExpirationDays(context);
};

function replaceSendForSignatureButton(context) {
    // If the agreement type is filled in, then return.
    const agreementType = context.newRecord.getValue('custrecord_agreement_type');
    if (agreementType) {
        return;
    }

    // If the 'Send For Signature' button is undefined, then return.
    const sendForSignatureBtn = context.form.getButton({ id: 'custpage_send_button' });
    if (!sendForSignatureBtn) {
        return;
    }

    // Replace the built-in 'Send For Signature' button with a custome one showing the error message.
    context.form.removeButton({ id: 'custpage_send_button' });
    context.form.addButton({
        id: 'custpage_send_error_button',
        label: 'Send For Signature',
        functionName: 'showErrorMessage'
    });

    // Add the script to show the error message.
    const errorMessage = 'Agreement Type is empty. Please fill it before sending for signature.';
    const script = `<script>function showErrorMessage() { alert('${errorMessage}'); }</script>`;
    context.form.addField({
        id: 'custpage_script_field_empty_agreement_type',
        label: 'Script Field',
        type: FieldType.INLINEHTML,
    }).defaultValue = script;
}

function setExpirationDays(context) {
    // If it's not in draft status, then we can't modify more the agreement
    const status = context.newRecord.getValue('custrecord_echosign_status') as string;
    if (status !== '1') {
        return;
    }
    // Setting expiration days only for agreements created from quotes
    const parentType = context.newRecord.getValue('custrecord_echosign_parent_type') as string;
    if (parentType !== 'estimate') {
        return;
    }

    const quoteId = context.newRecord.getValue('custrecord_echosign_parent_record') as number;
    const quote = QuoteRecord.load(quoteId);
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const days = getDifferenceInDays(quote.expirationDate, today);

    const expirationDaysField = context.newRecord.getValue('custrecord_echosign_days_until_deadline') as number;
    nsutils.logMayBe('setExpirationDays expirationDaysField', expirationDaysField);
    // expiration days can't be lower than 1 and if it's already set the same number, we don't need to save it again
    if (days < 1 || days === expirationDaysField) {
        return;
    }
    record.submitFields({
        type: 'customrecord_echosign_agreement',
        id: context.newRecord.id,
        values: {
            custrecord_echosign_days_until_deadline: days
        }
    });
    redirect.toRecord({
        type: 'customrecord_echosign_agreement',
        id: context.newRecord.id
    });
}

function getDifferenceInDays(startDate: Date, endDate: Date): number {
    const diffInMs = Math.abs(endDate.getTime() - startDate.getTime());
    return Math.round(diffInMs / (1000 * 60 * 60 * 24));
}
