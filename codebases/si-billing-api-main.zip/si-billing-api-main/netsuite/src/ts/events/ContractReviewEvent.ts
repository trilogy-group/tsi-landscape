/**
 * @NApiVersion 2.1
 * @NModuleScope SameAccount
 * @NScriptType UserEventScript
 */

import { EntryPoints } from 'N/types';
import * as record from 'N/record';

export const beforeSubmit: EntryPoints.UserEvent.beforeSubmit = (context: EntryPoints.UserEvent.beforeSubmitContext) => {
  const newRecord = context.newRecord;

  if (context.type === context.UserEventType.CREATE) {
    updateNameField(newRecord);
  }

  else if (context.type === context.UserEventType.EDIT) {
    const oldRecord = context.oldRecord;
    const oldSubscriptionId = oldRecord.getValue('custrecord_cr_subscription');
    const newSubscriptionId = newRecord.getValue('custrecord_cr_subscription');

    if (oldSubscriptionId !== newSubscriptionId) {
      updateNameField(newRecord);
    }
  }
}

function updateNameField(newRecord) {
  const subscriptionId = newRecord.getValue({ fieldId: 'custrecord_cr_subscription' });

  // Load the subscription record and get the customer and plan name values
  const subscriptionRecord = record.load({ type: record.Type.SUBSCRIPTION, id: subscriptionId });

  const customerId = subscriptionRecord.getValue('customer');
  const customer = record.load({ type: record.Type.CUSTOMER, id: customerId });

  const customerName = customer.getValue('altname');
  const planName = subscriptionRecord.getValue('subscriptionplanname');
  // Set the name field in the custom record
  newRecord.setValue('custrecord_cr_name', `${customerName} - ${planName}`);
}
