/**
 * @NApiVersion 2.1
 * @NModuleScope SameAccount
 * @NScriptType UserEventScript
 */

import { EntryPoints } from "N/types";
import { ContractualDocumentsRecord } from "../models/ContractualDocumentsRecord";
import { QuoteRecord } from "../models/QuoteRecord";
import QuoteService from "../utility/QuoteService";

/**
 * Fills in automatically some missing fields from related records.
 * @param {EntryPoints.UserEvent.beforeSubmitContext} context
 */
export const beforeSubmit: EntryPoints.UserEvent.beforeSubmit = (context: EntryPoints.UserEvent.beforeSubmitContext) => {

    // If the user event type is different than CREATE and EDIT, then return.
    if (context.type !== context.UserEventType.CREATE && context.type !== context.UserEventType.EDIT) {
        return;
    }

    // Set missing fields from related records.
    const newRecord = new ContractualDocumentsRecord(context.newRecord, false);
    setMissingFieldsFromQuoteIfAny(newRecord);
};

/**
 * Sets the missing fields from the quote, if the quote is defined.
 * @param {ContractualDocumentsRecord} newRecord The new contractual documents record.
 */
function setMissingFieldsFromQuoteIfAny(newRecord: ContractualDocumentsRecord): void {

    // Load the related quote if any.
    if (newRecord.quote === null) {
        return;
    }
    const quote = QuoteRecord.load(newRecord.quote);

    // Set the ESW paper checkbox based on the custom form of the quote.
    newRecord.isESWPaper = QuoteService.isESWForm(quote.customForm);

    // If the link to the contract PDF is undefined, set it based on the agreement.
    if (!newRecord.linkToContractPDF) {
        newRecord.linkToContractPDF = QuoteService.getSignedDocUrlFromQuote(newRecord.quote);
    }
}
