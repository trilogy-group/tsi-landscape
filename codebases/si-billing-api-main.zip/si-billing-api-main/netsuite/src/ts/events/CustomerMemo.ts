/**
 * @NApiVersion 2.1
 * @NScriptType UserEventScript
 * Copy customer memo from a subscription associated with invoice to the invoice
 */

import { EntryPoints } from 'N/types';
import { SubscriptionRecord } from '../models/SubscriptionRecord';
import * as log from 'N/log';
import SubscriptionDao from '../dao/SubscriptionDao';
import { QuoteRecord } from '../models/QuoteRecord';

//copy customer memo from quote => subscription

function shouldTransferQuoteToSub(context: EntryPoints.UserEvent.afterSubmitContext) : boolean {
  const isCreate = context.type === context.UserEventType.CREATE;
  const recType = (context.newRecord.getValue('type') as string)?.toLowerCase();
  const action = (context.newRecord.getValue('action') as string)?.toLowerCase();
  const status = (context.newRecord.getValue('subscriptionchangeorderstatus') as string)?.toLowerCase();
  log.debug( { title: 'CustomerMemo/shouldTransferQuoteToSub', details: `RecType: ${recType}, op: ${context.type}` } );

  //verify event properties
  if (!(
    isCreate &&
    recType === 'subscriptionchangeorder' &&
    action === 'activate' &&
    status === 'active'
  )) {
    return false;
  }
  return true;
}

export const afterSubmit: EntryPoints.UserEvent.beforeSubmit = (context: EntryPoints.UserEvent.afterSubmitContext) => {
  const FUNC_TITLE = 'CustomerMemo/afterSubmit';

  if(!shouldTransferQuoteToSub(context)) {
    return;
  }

  const subscriptionId = context.newRecord.getValue('subscription') as string;
  if (!subscriptionId) {
    log.debug({ title: FUNC_TITLE, details: `Subscription Id is not set for change order ${context.newRecord.id}`});
    return;
  }

  //transfer customer memo from quote to subscription
  //
  try {
    const subId = parseInt(subscriptionId.toString());
    const signedQuoteId = SubscriptionDao.findSignedQuoteId(subId);

    //transfer from a signed quote
    if(!signedQuoteId) {
      return;
    }

    const quote = QuoteRecord.load(signedQuoteId);
    var newMemo : string | null = quote.lineItemsHeaderText;
    if(!newMemo || newMemo.length === 0) {
      return;
    }

    //append to customer memo unless the subscription memo already contains the quote memo
    const subscription = SubscriptionRecord.load(subId);
    const subCustomerMemo = subscription.customerMemo;
    newMemo = addStringIfNotPresent(subCustomerMemo, newMemo);
    if(newMemo && newMemo.length > 0 && newMemo !== subCustomerMemo) {
      subscription.customerMemo =  newMemo;
      subscription.save();
    }

  } catch (ex) {
    log.error({ title: FUNC_TITLE, details: `Failed to copy customer memo from quote (subId: ${subscriptionId}). ${ex}` });
  }
};

//copy customer memo subscription => invoice
export const beforeSubmit: EntryPoints.UserEvent.beforeSubmit = (context: EntryPoints.UserEvent.beforeSubmitContext) => {
  const FUNC_TITLE = 'CustomerMemo/beforeSubmit';

  const isCreate = context.type === context.UserEventType.CREATE;
  const recType = (context.newRecord.getValue('type') as string)?.toLowerCase();
  log.debug( { title: FUNC_TITLE, details: `RecType: ${recType}, op: ${context.type}` } );

  if (!(isCreate && recType === 'custinvc')) {
    return;
  }

  const subscriptionId = context.newRecord.getSublistValue('item', 'subscription', 0);
  if (!subscriptionId) {
    return;
  }

  try {
    const subscription = SubscriptionRecord.load(parseInt(subscriptionId.toString()));
    const memo = addStringIfNotPresent(context.newRecord.getValue('custbody_customer_memo') as string, subscription.customerMemo);
    if(memo && memo.length > 0) {
      context.newRecord.setValue('custbody_customer_memo', memo);
    }
  } catch (ex) {
    log.error({ title: FUNC_TITLE, details: `Failed to copy customer memo from subscription ${subscriptionId}. ${ex}` });
  }
};

/**
 * @description Add stringToAdd to originalString if originalString is not null and stringToAdd is not in stringToAdd
 * @param originalString
 * @param stringToAdd
 * @returns originalString if originalString is null, otherwise originalString + '\r\n' + stringToAdd
 */
export function addStringIfNotPresent(originalString: string | null, stringToAdd: string | null): string| null {

  if (originalString == null || stringToAdd == null) {
    return originalString ?? stringToAdd;
  }
  if (originalString.includes(stringToAdd)) {
    return originalString;
  } else {
    return `${originalString}\r\n${stringToAdd}`;
  }
}
