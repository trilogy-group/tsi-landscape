/**
 * @NApiVersion 2.1
 * @NScriptType ScheduledScript
 */

import * as record from 'N/record';
import * as query from 'N/query';
import * as nsutils from '../nsutils';

interface Customer {
    id: string;
    arr?: number;
}

/**
 * Updates the Has Active Subscription and Platinum Customer fields on the Customer record
 * @param context schedule job context
 */
export function execute(context): void {
    updateActiveSubscriptions();
    updatePlatinumSubscriptions();
    updateCustomerARR();
}

function updateCustomerField(customers: Customer[], fieldId: string, fieldName: string, value): void {
    if (customers.length > 1) {
        nsutils.logDebug(`${fieldName} Updated to ${value} count`, `${customers.length}`);
    }
    const updatedCustomerIds: string[] = [];
    for (const customer of customers) {
        try {
            record.submitFields({
                type: 'customer',
                id: customer.id,
                values: {
                    [fieldId]: value
                }
            });
            updatedCustomerIds.push(customer.id);
        } catch (e) {
            nsutils.logDebug(`Error Updating Customer ${fieldName} field to ${value}`, `Customer ID: ${customer.id}, Error: ${e}`);
        }
    }
    if (updatedCustomerIds.length > 0) {
        nsutils.logDebug(`${fieldName} Updated to ${value}`, `Customer IDs: ${updatedCustomerIds.join(',')}`);
    }
}

function updateActiveSubscriptions(): void {
    const activeSubscriptionQuery = `
        SELECT c.id
        FROM customer c
        INNER JOIN subscription s ON c.id = s.customer
        WHERE s.billingsubscriptionstatus = 'ACTIVE'
            AND (s.custrecord_isprime is null or s.custrecord_isprime = 2)
            AND (c.custentity_has_active_subscription is null or c.custentity_has_active_subscription = 'F')

        UNION

        SELECT c.id
        FROM customer c
        INNER JOIN subscription s ON c.id = s.custrecord_subs_end_user
        WHERE s.billingsubscriptionstatus = 'ACTIVE'
            AND (s.custrecord_isprime is null or s.custrecord_isprime = 2)
            AND (c.custentity_has_active_subscription is null or c.custentity_has_active_subscription = 'F')`;
    const activeCustomers = query.runSuiteQL({ query: activeSubscriptionQuery }).asMappedResults<Customer>();
    updateCustomerField(activeCustomers, 'custentity_has_active_subscription', 'Has Active Subscription', true);

    const inactiveSubscriptionQuery = `
        SELECT c.id
        FROM customer c
        WHERE c.custentity_has_active_subscription = 'T'
            AND NOT EXISTS (
                SELECT 1
                FROM subscription s
                WHERE c.id = s.customer
                    AND s.billingsubscriptionstatus = 'ACTIVE'
                    AND (s.custrecord_isprime IS NULL OR s.custrecord_isprime = 2)
            )
            AND NOT EXISTS (
                SELECT 1
                FROM subscription s
                WHERE c.id = s.custrecord_subs_end_user
                    AND s.billingsubscriptionstatus = 'ACTIVE'
                    AND (s.custrecord_isprime IS NULL OR s.custrecord_isprime = 2)
            )`;
    const inactiveCustomers = query.runSuiteQL({ query: inactiveSubscriptionQuery }).asMappedResults<Customer>();
    updateCustomerField(inactiveCustomers, 'custentity_has_active_subscription', 'Has Active Subscription', false);
}

function updatePlatinumSubscriptions(): void {
    const platinumSubscriptionQuery = `
        SELECT c.id
        FROM customer c
        INNER JOIN subscription s ON c.id = s.customer
        INNER JOIN subscriptionplan sp ON s.subscriptionplanname = sp.itemid
        WHERE s.billingsubscriptionstatus = 'ACTIVE'
            AND (s.custrecord_isprime is null or s.custrecord_isprime = 2)
            AND REGEXP_INSTR(sp.displayname, '(.*-){4}PLA') > 0
            AND (c.custentity_platinum_customer is null or c.custentity_platinum_customer = 'F')

        UNION
        
        SELECT c.id
        FROM customer c
        INNER JOIN subscription s ON c.id = s.custrecord_subs_end_user
        INNER JOIN subscriptionplan sp ON s.subscriptionplanname = sp.itemid
        WHERE s.billingsubscriptionstatus = 'ACTIVE'
            AND (s.custrecord_isprime is null or s.custrecord_isprime = 2)
            AND REGEXP_INSTR(sp.displayname, '(.*-){4}PLA') > 0
            AND (c.custentity_platinum_customer is null or c.custentity_platinum_customer = 'F')`;
    const platinumCustomers = query.runSuiteQL({ query: platinumSubscriptionQuery }).asMappedResults<Customer>();
    updateCustomerField(platinumCustomers, 'custentity_platinum_customer', 'Platinum Customer', true);

    const nonPlatinumSubscriptionQuery = `
        SELECT c.id
        FROM customer c
        WHERE c.custentity_platinum_customer = 'T'
            AND NOT EXISTS (
                SELECT 1
                FROM subscription s
                INNER JOIN subscriptionplan sp ON s.subscriptionplanname = sp.itemid
                WHERE c.id = s.customer
                    AND s.billingsubscriptionstatus = 'ACTIVE'
                    AND (s.custrecord_isprime is null or s.custrecord_isprime = 2)
                    AND REGEXP_INSTR(sp.displayname, '(.*-){4}PLA') > 0
            )
            AND NOT EXISTS (
                SELECT 1
                FROM subscription s
                INNER JOIN subscriptionplan sp ON s.subscriptionplanname = sp.itemid
                WHERE c.id = s.custrecord_subs_end_user
                    AND s.billingsubscriptionstatus = 'ACTIVE'
                    AND (s.custrecord_isprime is null or s.custrecord_isprime = 2)
                    AND REGEXP_INSTR(sp.displayname, '(.*-){4}PLA') > 0
            )`;
    const nonPlatinumCustomers = query.runSuiteQL({ query: nonPlatinumSubscriptionQuery }).asMappedResults<Customer>();
    updateCustomerField(nonPlatinumCustomers, 'custentity_platinum_customer', 'Platinum Customer', false);
}

function updateCustomerARR(): void {
    const arrQuery = `
        SELECT c.id, s.ARR AS ARR 
        FROM customer c 
        LEFT JOIN (
            SELECT customer, SUM(ARR) AS ARR 
            FROM (
                SELECT customer, SUM(custrecord_arr) AS ARR 
                    FROM subscription 
                    WHERE billingsubscriptionstatus = 'ACTIVE' 
                    GROUP BY customer
                UNION ALL
                SELECT custrecord_subs_end_user AS customer, SUM(custrecord_arr) AS ARR 
                    FROM subscription 
                    WHERE billingsubscriptionstatus = 'ACTIVE' AND custrecord_subs_end_user != customer
                    GROUP BY custrecord_subs_end_user
            ) GROUP BY customer
        ) s ON c.id = s.customer
        WHERE c.custentity_arr != s.ARR
            OR (c.custentity_arr is null and s.arr is not null) 
            OR (c.custentity_arr is not null and s.arr is null)
        ORDER BY s.arr desc, c.id
    `;
    const customers = query.runSuiteQL({ query: arrQuery }).asMappedResults<Customer>();
    // group by ARR
    const customersByARR = customers.reduce((acc, customer) => {
        if (customer.arr === null || customer.arr === undefined) {
            customer.arr = -1;
        }
        if (!acc[customer.arr]) {
            acc[customer.arr] = [];
        }
        acc[customer.arr].push(customer);
        return acc;
    }, {});
    for (const arr in customersByARR) {
        const arrValue = arr === '-1' ? null : parseFloat(arr);
        updateCustomerField(customersByARR[arr], 'custentity_arr', 'ARR', arrValue);
    }
}
