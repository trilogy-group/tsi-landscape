/**
 * @NApiVersion 2.1
 * @NModuleScope SameAccount
 * @NScriptType UserEventScript
 */

import { EntryPoints } from 'N/types';
import * as nsutils from '../nsutils';

export const beforeSubmit: EntryPoints.UserEvent.beforeSubmit = (context: EntryPoints.UserEvent.beforeSubmitContext) => {
  if (context.newRecord.getValue('type') !== 'item') {
    return;
  }
  const renewId = context.newRecord.getValue('custitem_renew_with') as string;
  if (!renewId) {
    return;
  }
  const type = nsutils.queryFirstToJson('SELECT itemtype FROM item WHERE id = ?', [parseInt(renewId)])?.itemtype;
  if (type === 'SubscriPlan') {
    throw new Error('Not possible to save a Subscription Plan in the RENEW WITH field. Choose another item.');
  }
};
