/**
 * @NApiVersion 2.1
 * @NModuleScope SameAccount
 * @NScriptType UserEventScript
 */

import { EntryPoints } from 'N/types';
import * as nsutils from '../nsutils';
import * as log from 'N/log';
import * as record from 'N/record';
import * as task from 'N/task';
import subscriptionGetUtility from '../utility/SubscriptionGetUtility';
import productNotificationUtility, { ChangeType } from '../utility/ProductNotificationUtility';
import { ProductIntegration } from '../ProductIntegration';
import { SubscriptionRecord } from '../models/SubscriptionRecord';

const LOG_CATEGORY = 'product.notification';
const USE_SCHEDULED_SCRIPT = false;
const SCHEDULED_SCRIPT_ID = 'customscript_si_main_pi_nfn_ss';

function processSubscription(type: ChangeType, subscription: record.Record) {
  const jsonedSubscription = JSON.parse(JSON.stringify(subscription));
  const subRec = new SubscriptionRecord(subscription, false);
  const pi = ProductIntegration.findBySubscriptionPlanName(subRec.subscriptionPlanName);
  if (pi) {
    if (!pi.notification || !pi.notification.url) {
      // ignore event if no notification url specified
      nsutils.logMayBe(LOG_CATEGORY, `Event ${type} ignored because of empty notification settings`);
      return;
    }
    if (USE_SCHEDULED_SCRIPT) {
      try {
        const t = task.create({
          taskType: task.TaskType.SCHEDULED_SCRIPT,
        });
        t.scriptId = SCHEDULED_SCRIPT_ID;
        t.params = {
          args: JSON.stringify({
            subscriptionId: jsonedSubscription.id,
            changeType: type,
            notification: pi.notification,
          }),
        };
        t.submit();
      } catch (e) {
        log.error('Failed to create task', e);
      }
    } else {
      const si = subscriptionGetUtility.buildSubscription(jsonedSubscription);
      productNotificationUtility.notifyWebhook(pi.notification, type, si);
    }
  } else {
    nsutils.logMayBe(LOG_CATEGORY, `Unable to find product integration for subscription ${subRec.name}`);
  }
}

function processChangeOrder(type, changeOrder) {
  const jsonedChangeOrder = JSON.parse(JSON.stringify(changeOrder));
  if (!jsonedChangeOrder.fields.subscription) {
    // change order is probably voided, it will rollback previous pricing values
    return;
  }
  const subscription = record.load({
    type: record.Type.SUBSCRIPTION,
    id: jsonedChangeOrder.fields.subscription,
  });
  let changeType;
  if (jsonedChangeOrder.fields.action === 'ACTIVATE') {
    changeType = ChangeType.CREATE;
  } else {
    changeType = jsonedChangeOrder.fields.action === 'TERMINATE' ? ChangeType.TERMINATE : ChangeType.UPDATE;
  }
  processSubscription(changeType, subscription);
}

export const afterSubmit: EntryPoints.UserEvent.beforeSubmit = (context: EntryPoints.UserEvent.beforeSubmitContext) => {
  const jsonedRecord = JSON.parse(JSON.stringify(context.newRecord));
  nsutils.logMayBe(LOG_CATEGORY, { eventType: context.type, recordType: jsonedRecord.type });
  if (jsonedRecord.type === record.Type.SUBSCRIPTION) {
    // ignoring subscription
    //processSubscription(context.type, jsonedRecord);
  } else if (jsonedRecord.type === record.Type.SUBSCRIPTION_CHANGE_ORDER) {
    processChangeOrder(context.type, jsonedRecord);
  }
};
