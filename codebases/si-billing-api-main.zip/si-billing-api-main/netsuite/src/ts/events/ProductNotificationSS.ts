/**
 * @NApiVersion 2.1
 * @NModuleScope SameAccount
 * @NScriptType ScheduledScript
 */

import { EntryPoints } from 'N/types';
import * as log from 'N/log';
import * as runtime from 'N/runtime';
import * as nsutils from '../nsutils';
import subscriptionGetUtility from '../utility/SubscriptionGetUtility';
import productNotificationUtility, { ChangeType } from '../utility/ProductNotificationUtility';

const RETRY_COUNT = 2;

export interface ProductNotificationArgs {
  subscriptionId: number;
  notification: nsutils.ProductWebhook;
  changeType: ChangeType;
}

export const execute: EntryPoints.Scheduled.execute = (ctx: EntryPoints.Scheduled.executeContext) => {
  const scriptObj = runtime.getCurrentScript();
  const argsStr = scriptObj.getParameter({ name: 'custscriptargs' }) as string;
  const args: ProductNotificationArgs = JSON.parse(argsStr);

  nsutils.logMayBe('Args', args);

  const si = subscriptionGetUtility.getSubscriptionByIdInternal(args.subscriptionId);

  productNotificationUtility.notifyWebhook(args.notification, args.changeType, si, RETRY_COUNT);
};
