/**
 * @NApiVersion 2.1
 * @NModuleScope SameAccount
 * @NScriptType UserEventScript
 */

import { EntryPoints } from 'N/types';
import * as record from 'N/record';
import subscriptionPlanUtility from '../utility/SubscriptionPlanUtility';
import { ProductIntegration } from '../ProductIntegration';
import { SupportLevel, SupportLevelUtil } from '../types';
import { TSI_INTEGRATION_USER_ID, sendEmail } from '../nsutils';
import SubscriptionPriceUtility from '../utility/SubscriptionPriceUtility';
import { SubscriptionPlan, SubscriptionPlanItem } from '../models/SubscriptionPlan';
import { HUNDRED, roundMoney } from '../utility/GeneralUtility';
import { ItemCode } from '../utility/SubscriptionItemUtility';

const RPSIEmail = 'rp-si@trilogy.com';

export const beforeSubmit: EntryPoints.UserEvent.beforeSubmit = (context: EntryPoints.UserEvent.beforeSubmitContext) => {
  if (context.type !== context.UserEventType.CREATE || context.newRecord.getValue('type') !== 'estimate') {
    return;
  }
  const subscriptionId = context.newRecord.getValue('custbody_related_subscription');
  const subscriptionPlanId = context.newRecord.getValue('custbody_subscription_plan') as number;

  //if this step fails, the quote won't be created
  trySetPlatinumAcknowledgmentClauses(context.newRecord, subscriptionPlanId, subscriptionId);
  
  trySetListPrices(context.newRecord, subscriptionPlanId, subscriptionId);
  trySetSignatureImage(context.newRecord, subscriptionId);
};

function getMonthsBetweenDates(startDateStr: string, endDateStr: string): number {
  const startDate = new Date(startDateStr);
  const endDate = new Date(endDateStr);

  let months;
  months = (endDate.getFullYear() - startDate.getFullYear()) * 12;
  months -= startDate.getMonth();
  months += endDate.getMonth();

  // Calculate the difference between days
  const dayDifference = endDate.getDate() - startDate.getDate();

  if (dayDifference < 0) {
      // End date's day is earlier in the month than start date's day
      const absDayDifference = Math.abs(dayDifference);
      if (absDayDifference >= 15) {
          // If it's less than 15 days, decrease month count by 1
          months--;
      }
  } else if (dayDifference >= 15) {
      // End date's day is 15 or more days later than start date's day
      months++;
  }

  return months <= 0 ? 0 : months;
}

function getListPriceForItem(newRecord, i: number, quantity: number, planItem: SubscriptionPlanItem, quoteInfo) {
  // priceintervalfrequency doesn't get set for lines unlinked to the subscription
  // Getting the list price always based on the annual frequency
  const frequency = 'Annually'; //newRecord.getSublistValue('item', 'priceintervalfrequency', i);
  const startDate = newRecord.getSublistValue('item', 'custcol_swe_contract_start_date', i) ?? quoteInfo.startDate;
  const endDate = newRecord.getSublistValue('item', 'custcol_swe_contract_end_date', i) ?? quoteInfo.endDate;
  let price;
  try {
    price = SubscriptionPriceUtility.calcItemTotalPrice(planItem, null, quantity, quoteInfo.currencySymbol, frequency,
      getMonthsBetweenDates(startDate,endDate));
  }
  catch {
    price = false;
  }
  return price;
}

function setCurrentPriceAsListPrice(newRecord, i: number, rate){
  //if there is no plan item or discount is 0 or negative, set as list rate the current rate
  // rounding rate, because list prices have 2 decimals, but rates can have more because of price split and then we can have small differences
  // in the list price when there is no discount
  // smallDecimal is a workaround when the price split get exact half in product and support item. This will correct the list price.
  const smallDecimal = 0.000000000001;
  newRecord.setSublistValue('item', 'custcol_list_rate', i, roundMoney(rate - smallDecimal));
  newRecord.setSublistValue('item', 'custcol_inline_discount', i, 0);
}

function setListPrices(newRecord, subscriptionPlan: SubscriptionPlan) {
  const items = newRecord.getLineCount('item');
  const quoteInfo = {
    currencySymbol: newRecord.getValue('currencysymbol'),
    startDate: newRecord.getValue('startdate'),
    endDate: newRecord.getValue('enddate')
  }

  for (let i = 0; i < items; i++) {
    const itemType = newRecord.getSublistValue('item', 'itemtype', i);
    // Skip subscription plan item
    if (itemType === 'SubscriPlan') {
      continue;
    }

    const itemId = parseInt(newRecord.getSublistValue('item', 'item', i));
    const rate = newRecord.getSublistValue('item', 'rate', i);
    const planItem = subscriptionPlan.items.find(pi => pi.id === itemId);
    if (!planItem) {
      setCurrentPriceAsListPrice(newRecord, i, rate);
      continue;
    }

    const quantity = newRecord.getSublistValue('item', 'quantity', i);
    const price = getListPriceForItem(newRecord, i, quantity, planItem, quoteInfo);
    if (!price) {
      setCurrentPriceAsListPrice(newRecord, i, rate);
      continue;
    }

    // the list price is individual price for the term
    const listPrice = quantity !== 0 ? price.totalIntervalValue / quantity : price.totalIntervalValue;
    const discountPercent = ((listPrice - rate) / listPrice) * HUNDRED;
    if (discountPercent > 0) {
      newRecord.setSublistValue('item', 'custcol_list_rate', i, listPrice);
      newRecord.setSublistValue('item', 'custcol_inline_discount', i, discountPercent);
      continue;
    }

    setCurrentPriceAsListPrice(newRecord, i, rate);
  }
}

function setPlatinumAcknowledgmentClauses(newRecord, supportLevel: SupportLevel, productIntegrationId?: number) {
  // if there is no product integration record we can't set the platinum acknowledgment clause
  if (!productIntegrationId) {
    return;
  }

  // not adding Platinum Knowledgment clauses for platinum
  if (supportLevel === SupportLevel.Platinum) {
    return;
  }

  const piRecord = record.load({
    type: 'customrecordproductintegration',
    id: productIntegrationId
  });
  newRecord.setValue('custbodyquote_clauses',piRecord.getValue('custrecordquoteclauses'));
}

function trySetPlatinumAcknowledgmentClauses(newRecord, subscriptionPlanId, subscriptionId) {
  try {
    let productIntegration;
    let supportLevel;
    if (subscriptionPlanId) {
      const subscriptionPlan = subscriptionPlanUtility.getSubscriptionPlanById(subscriptionPlanId);
      productIntegration = ProductIntegration.getBySubscriptionPlanIdOrDefault(subscriptionPlan.id);
      supportLevel = subscriptionPlan.supportLevel;
    } else {
      //if subscription plan is not linked, try to get the product integration record and support level from the first and second item
      const itemCode1 = newRecord.getSublistValue('item', 'custcol_ava_item', 0) as string;
      const ic1 = new ItemCode(itemCode1);
      const itemCode2 = newRecord.getSublistValue('item', 'custcol_ava_item', 1) as string;
      const ic2 = new ItemCode(itemCode2);

      if (ic1.isValid) {
        productIntegration = ProductIntegration.getProductIntegrationOrDefault(ic1.productCode, `${ic1.revenueType}-${ic1.itemCode}`);
      } else if (ic2.isValid) {
        productIntegration = ProductIntegration.getProductIntegrationOrDefault(ic2.productCode, `${ic2.revenueType}-${ic2.itemCode}`);
      }

      if (ic1.isSupport()) {
        supportLevel = SupportLevelUtil.codeToSupportLevel(ic1.suffix);
      } else if (ic2.isSupport()) {
        supportLevel = SupportLevelUtil.codeToSupportLevel(ic2.suffix);
      } else {
        supportLevel = SupportLevel.Silver;
      }
    }
    setPlatinumAcknowledgmentClauses(newRecord, supportLevel, productIntegration?.id);
  } catch (ex) {
    sendEmail([RPSIEmail], 'Quote Event script error - Ackowledgment Clauses',
      `An error happened on the quote event creation trigger for subscription ${subscriptionId}. Quote is not created.
${ex}`);
    throw new Error(`An error happened on the Quote Event script. Please, create a lambda ticket with the print of the screen before saving. ${ex}`);
  }
}

function trySetListPrices(newRecord, subscriptionPlanId, subscriptionId) {
  try {
    // if subscription plan is not linked to quote we don't have how to calculate list prices
    // and we only calculate list prices for quotes created by automation
    if (subscriptionPlanId && parseInt(newRecord.getValue('nluser') as string) === TSI_INTEGRATION_USER_ID) {
      const subscriptionPlan = subscriptionPlanUtility.getSubscriptionPlanById(subscriptionPlanId);
      setListPrices(newRecord, subscriptionPlan);
    }
  } catch (ex) {
    sendEmail([RPSIEmail], 'Quote Event script error - List Prices',
      `An error happened on the quote event creation trigger for subscription ${subscriptionId}.
List prices are not applied to the quote.
${ex}`);
  }
}

function trySetSignatureImage(newRecord, subscriptionId) {
  try {
    const subsidiaryId = newRecord.getValue('subsidiary');
    const subsidiary = record.load({
      type: record.Type.SUBSIDIARY,
      id: subsidiaryId
    });
    const signerEmployeeId = subsidiary.getValue('custrecord_subsidiary_signatory');
    const employee = record.load({
      type: record.Type.EMPLOYEE,
      id: signerEmployeeId
    });
    const signatureImage = employee.getValue('custentity_signature');
    if (signatureImage) {
      newRecord.setValue('custbody_service_provider_signature', signatureImage);
    } else {
      const employeeName = employee.getValue('entityid');
      const subsidiaryName = subsidiary.getValue('name');
      sendEmail([RPSIEmail], 'Quote Event - Employee Signature Image not found',
      `The employee signature image was not found for ${employeeName} when generating quote for subscription ${subscriptionId}.
He is the signatory for subsidiary ${subsidiaryId} - ${subsidiaryName}.`);
    }
  }
  catch (ex) {
    sendEmail([RPSIEmail], 'Quote Event script error - Signature Image',
      `An error happened on the quote event creation trigger for subscription ${subscriptionId}.
Service Provider signature image couldn't be load to the quote.
${ex}`);
  }
}
