/**
 * @NApiVersion 2.1
 * @NModuleScope SameAccount
 * @NScriptType UserEventScript
 */

import { EntryPoints } from '@hitc/netsuite-types/N/types';

export const beforeLoad: EntryPoints.UserEvent.beforeLoad = (context: EntryPoints.UserEvent.beforeLoadContext) => {
  if (context.type !== context.UserEventType.VIEW || context.newRecord.getValue('type') !== 'estimate') {
    return;
  }

  context.form.clientScriptModulePath = '/SuiteScripts/si/main/utility/QuoteCreateEUAScript.js';
  // Add a custom button to the form that will call createEUA() when clicked. CreateEUA is defined in QuoteCreateEUAScript.js
  context.form.addButton({
      id: 'custpage_create_adobe_agreement',
      label: 'Create EUA',
      functionName: 'createEUA'
  });
};
