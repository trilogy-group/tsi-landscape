/**
 * @NApiVersion 2.1
 * @NScriptType UserEventScript
 */

import { EntryPoints } from 'N/types';
import { Subscription } from '../Subscription';
import * as nsutils from '../nsutils';

export const afterSubmit: EntryPoints.UserEvent.afterSubmit = (context: EntryPoints.UserEvent.afterSubmitContext) => {
    nsutils.logMayBe('SubscriptionChangeOrderEvent start', 'started');
    nsutils.logMayBe('SubscriptionChangeOrderEvent context', context);
    const action = context.newRecord.getValue({ fieldId: 'action' });
    const renewalMethod = context.newRecord.getValue({ fieldId: 'renewalmethod' });

    // Exit if the action is RENEW and method is CREATE_NEW_SUBSCRIPTION because
    // the change doesn't impact the current subscription
    if (action === 'RENEW' && renewalMethod === 'CREATE_NEW_SUBSCRIPTION') {
        return;
    }

    let subscriptionId = context.newRecord.getValue({ fieldId: 'subscription' });
    if (!subscriptionId) {
       subscriptionId = context.oldRecord.getValue({ fieldId: 'subscription' });
    }
    if (!subscriptionId) {
        let id = context.newRecord.getValue({ fieldId: 'id' });
        if (!id) {
            id = context.oldRecord.getValue({ fieldId: 'id' });
        }
        nsutils.sendEmail(['rp-si@trilogy.com'],'Subscription Change Order without subscription',
            `Subscription Id is not set for change order ${id}`);
        return;
    }
    nsutils.logMayBe('SubscriptionChangeOrderEvent subscriptionId', subscriptionId);
    Subscription.calculateAndSaveARR(subscriptionId as number);
}
