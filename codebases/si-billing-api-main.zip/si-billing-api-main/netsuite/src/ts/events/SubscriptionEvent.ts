/**
 * @NApiVersion 2.1
 * @NModuleScope SameAccount
 * @NScriptType UserEventScript
 */

import * as record from 'N/record';
import { EntryPoints } from 'N/types';
import * as nsutils from '../nsutils';

export const afterSubmit: EntryPoints.UserEvent.afterSubmit = (context: EntryPoints.UserEvent.afterSubmitContext) => {
    const isSubscriptionType = context.newRecord.getValue('type') === 'subscription';
    if (!isSubscriptionType) {
        return;
    }

    const isCreateEvent = context.type === context.UserEventType.CREATE;
    const isEditEvent = context.type === context.UserEventType.EDIT;
    if (!isCreateEvent && !isEditEvent) {
        return;
    }

    let newParentSubscription = getParentSubscription(context.newRecord);
    nsutils.logMayBe("newParentSubscription", newParentSubscription);

    if (isEditEvent) {
        const oldParentSubscription = getParentSubscription(context.oldRecord);
        nsutils.logMayBe("oldParentSubscription", oldParentSubscription);

        // On updates, we only set the serial if the parent is changed.
        if (newParentSubscription === oldParentSubscription) {
            newParentSubscription = null;
        }
    }

    if (newParentSubscription) {
        const serialOrLicenseNumber = nsutils
            .queryFirstToJson(
                `
                SELECT custrecord_serial_or_license_number AS serial
                FROM subscription 
                WHERE id = ?
                `,
                [newParentSubscription]
        )?.serial;
        nsutils.logMayBe("parent -> serialOrLicenseNumber", serialOrLicenseNumber);

        // Store value.
        const subscriptionRecord = record.load({ type: record.Type.SUBSCRIPTION, id: context.newRecord.id });
        subscriptionRecord.setValue('custrecord_serial_or_license_number', serialOrLicenseNumber);
        subscriptionRecord.save();
    }
};

function getParentSubscription(record: record.Record): number | null {
    const fields = record.toJSON().fields;
    const parentSubscription = fields.parentsubscription || fields.custrecord_parent_subscription;
    return parentSubscription ? parseInt(parentSubscription) : null;
}
