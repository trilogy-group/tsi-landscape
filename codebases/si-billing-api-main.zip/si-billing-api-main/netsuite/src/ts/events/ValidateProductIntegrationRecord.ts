/**
 * @NApiVersion 2.1
 * @NModuleScope SameAccount
 * @NScriptType UserEventScript
 */

import { EntryPoints } from 'N/types';
import * as nsutils from '../nsutils';
import { assertNotNull, isNotBlank, isNotNull, must, ValidationError } from '../validation';
import { SubscriptionConfiguration } from '../models/SubscriptionParams';
import { BillingSchedule } from '../types';
import subscriptionPlanUtility from '../utility/SubscriptionPlanUtility';

function validateItems(subConf: SubscriptionConfiguration, planId: number) {
  const planItems = subscriptionPlanUtility.getSubscriptionPlanById(planId).items;
  const subItems = must(subConf.items, 'items');
  subItems.forEach((subItem, i) => {
    const planItem = planItems.find((pi) => pi.code === subItem.code);
    if (!planItem) {
      throw new ValidationError(`Item '${subItem.code}' does not exist in plan`, `items[${i}]`);
    }
    if (!isNotNull(subItem.quantity) || !Number.isInteger(subItem.quantity) || subItem.quantity < 0) {
      throw new ValidationError(`Invalid quantity on item '${subItem.code}'`, `items[${i}]`);
    }
    if (planItem.minQuantity && subItem.quantity < planItem.minQuantity) {
      throw new ValidationError(
        `Quantity is less than minimum ${planItem.minQuantity} on item '${subItem.code}'`,
        `items[${i}]`
      );
    }
    if (planItem.maxQuantity && subItem.quantity > planItem.maxQuantity) {
      throw new ValidationError(
        `Quantity is greater than maximum ${planItem.maxQuantity} on item '${subItem.code}'`,
        `items[${i}]`
      );
    }
  });

  planItems.forEach((planItem) => {
    if (planItem.required && subItems.find((v) => v.code === planItem.code) === undefined) {
      throw new ValidationError(`Item ${planItem.code} is required`, 'items');
    }
  });
}

/**
 * Validate trial subscription configuration JSON
 */
export function validateTrialSubscriptionConfig(config: string) {
  const subConf: SubscriptionConfiguration = JSON.parse(config);
  nsutils.logMayBe('validateTrialSubscriptionConfig subConf', subConf);

  assertNotNull(subConf.planCode);
  const planInfo = nsutils.queryFirstAsMap(
    `select id, itemid from subscriptionplan where isinactive='F' and itemid=?`,
    [subConf.planCode]
  );
  if (!planInfo) {
    throw new ValidationError(`No such subscription plan ${subConf.planCode}`, 'planCode');
  }

  // trial duration is required
  if (subConf.trialDuration === undefined || Number.isNaN(subConf.trialDuration)) {
    throw new ValidationError('trialDuration should be set and be a number', 'trialDuration');
  }

  // trial duration should positive integer
  if (!Number.isInteger(subConf.trialDuration) || subConf.trialDuration <= 0) {
    throw new ValidationError('trialDuration should be positive integer', 'trialDuration');
  }

  if (
    !isNotBlank(subConf.frequency) ||
    !Object.values(BillingSchedule).includes(subConf.frequency as BillingSchedule)
  ) {
    throw new ValidationError(`Empty or invalid frequency '${subConf.frequency}'`, 'frequency');
  }

  validateItems(subConf, planInfo.id);
}

export const beforeSubmit: EntryPoints.UserEvent.beforeSubmit = (
  context: EntryPoints.UserEvent.beforeSubmitContext
) => {
  const trialConfigStr = context.newRecord.getValue('custrecordtrialsubscriptionconfig') as string;
  nsutils.logMayBe('validateTrialSubscriptionConfig params', { trialConfigStr });
  if (isNotBlank(trialConfigStr)) {
    try {
      validateTrialSubscriptionConfig(trialConfigStr);
    } catch (e) {
      throw new ValidationError(`Invalid 'Trial Subscription Config': ` + e);
    }
  } else {
    nsutils.logMayBe('validateTrialSubscriptionConfig skipped - trialConfigStr is empty', {});
  }
};
