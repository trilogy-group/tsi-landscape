/**
 * @NApiVersion 2.1
 * @NModuleScope SameAccount
 * @NScriptType RESTlet
 */

import { EntryPoints } from 'N/types';
//DO NOT CHANGE ABOVE CODE INCL LINE BREAKS

import { Any, InputParams, RequestHandler } from './types';
import * as log from 'N/log';
import * as nsutils from './nsutils';

export class Router {
  handlers: { [key: string]: RequestHandler<any> } = {};

  op<T extends InputParams>(opName: string, handler: RequestHandler<T>): Router {
    this.handlers[opName] = handler as RequestHandler<InputParams>;
    return this;
  }

  internalOp<T extends any>(opName: string, handler: RequestHandler<T>): Router {
    this.handlers[opName] = handler;
    return this;
  }

  run(params: any): any {
    try {
      return this.handlers[params.op](params);
    } catch (e: Any) {
      log.error(params.op, e);

      // Determine the error type and details.
      let type: string;
      const details: Any = { status: e.status ?? HttpStatusCode.INTERNAL_SERVER_ERROR, message: e.message, full: e, fullToString: e?.toString() };
      if (e.status) {
        if (e.fieldName) {
          type = `run ${params.op} validation error`;
          details.path = e.fieldName;
        } else {
          type = `run ${params.op} error`;
        }
      } else {
        type = `run ${params.op} unhandled error`;
      }
      nsutils.logMayBe(type, details);

      // Return the error response to API client. Any error returns a 400 Bad Request.
      const errorResponse = { // NOSONAR
        name: details.status.toString(),
        message: details.message,
      };
      throw errorResponse;
    }
  }
}

const router = new Router();

import customerOps from './CustomerService';
import * as prodIntOps from './ProductIntegrationGetter';
import * as prodCatalogOps from './ProductCatalog';
import { Subscription as subscriptionOps } from './Subscription';
import invoiceOps from './InvoicesService';
import quoteOps, { GenerateUnlinkedQuoteParams, GetQuoteTypeParams } from './api/operations/QuoteOperations';
import classOps, {UpdateClassParams} from './api/operations/ClassOperations';
import fileOps from './utility/FileService';
import contractualDocumentsOps from './utility/ContractualDocumentsService';
import { HttpStatusCode } from './utility/ProductNotificationUtility';
import { ChangeQuoteLinkParams, FindSuitableSubsidiaryParams, GetSubscriptionsToSyncParams, SubscriptionParams } from './models/SubscriptionParams';

router.internalOp('class.internalUpdate', (p) => classOps.update(p as UpdateClassParams));
router.op('customer.get', (p) => customerOps.getCustomer(p));
router.op('customer.getStatus', (p) => customerOps.getStatus(p));
router.op('customer.update', (p) => customerOps.updateCustomer(p));
router.op('customer.create', (p) => customerOps.createCustomer(p));
router.op('customer.search', (p) => customerOps.searchCustomer(p));
router.op('customer.getLatestSignedQuote', (p) => customerOps.getLatestSignedQuote(p));
router.op('customer.statement', (p) => customerOps.getStatement(p));
router.op('prodInt.get', prodIntOps.getProductIntegration);
router.op('prodCatalog.getLatestSubscriptionPlanCode', prodCatalogOps.getLatestSubscriptionPlanCode);
router.op('prodCatalog.listProducts', prodCatalogOps.listProducts);
router.op('prodCatalog.listSubscriptionPlans', prodCatalogOps.listSubscriptionPlans);
router.op('subscription.get', (p) => subscriptionOps.get(p));
router.op('subscription.findForCustomer', (p) => subscriptionOps.findForCustomer(p));
router.op('subscription.create', (p) => subscriptionOps.create(p));
router.op('subscription.updateOrRenew', (p) => subscriptionOps.updateOrRenew(p)); // put
router.op('subscription.preview', (p) => subscriptionOps.preview(p));
router.op('subscription.startTrial', (p) => subscriptionOps.startTrial(p));
router.op('subscription.createDraftRenewal', (p) => subscriptionOps.createDraftRenewal(p));
router.op('subscription.modifyPrice', (p) => subscriptionOps.modifyPrice(p));
router.op('subscription.reportUsage', (p) => subscriptionOps.reportUsage(p));
router.op('subscription.updateStatus', (p) => subscriptionOps.updateStatus(p));
router.op('subscription.uploadContractualDocument', (p) => subscriptionOps.uploadContractualDocument(p));
router.op('subscription.internalGetItems', (p) => subscriptionOps.internalGetItems(p));
router.op('subscription.internalCreateActiveSubscription', (p) => subscriptionOps.internalCreateActiveSubscription(p));
router.op('subscription.internalTerminateSubscription', (p) => subscriptionOps.internalTerminateSubscription(p));
router.op('subscription.internalUpdateAndActivate', (p) => subscriptionOps.internalUpdateAndActivate(p));
router.op('subscription.internalDeleteDraft', (p) => subscriptionOps.internalDeleteDraftSubscription(p));
router.op('subscription.internalSetPrice', (p) => subscriptionOps.internalSetPrice(p));
router.op('subscription.internalActivate', (p) => subscriptionOps.internalActivate(p));
router.op('subscription.internalCreateRenewalChangeOrder', (p) => subscriptionOps.internalCreateRenewalChangeOrder(p));
router.op('subscription.internalSetContractualDocumentsInfo', (p) => quoteOps.setContractualDocumentsInfo(p));
router.internalOp('subscription.internalChangeQuoteLink', (p) => subscriptionOps.changeQuoteLink(p as ChangeQuoteLinkParams));
router.internalOp('subscription.internalFindSuitableSubsidiary', (p) => subscriptionOps.findSuitableSubsidiary(p as FindSuitableSubsidiaryParams));
router.internalOp('subscription.getSubscriptionsToSync', (p) => subscriptionOps.getSubscriptionsToSync(p as GetSubscriptionsToSyncParams));
router.internalOp('subscription.calculateARR', (p) => subscriptionOps.calculateAndSaveARRExposed(p as SubscriptionParams));
router.op('subscription.renewalInfo', (p) => subscriptionOps.getRenewalInfo(p));
router.op('invoice.find', (p) => invoiceOps.findInvoices(p));
router.op('invoice.create', (p) => invoiceOps.createInvoiceFromSubscription(p));
router.op('invoice.download', (p) => invoiceOps.downloadInvoice(p));
router.op('invoice.paymentLink', (p) => invoiceOps.generatePaymentLink(p));
router.op('quote.create', (p) => quoteOps.createQuote(p)); // deprecated
router.op('quote.createForSelfServe', (p) => quoteOps.createSelfServeQuote(p));
router.op('quote.unlinkedQuote', (p) => quoteOps.createUnlinkedQuote(p as unknown as GenerateUnlinkedQuoteParams));
router.op('quote.download', (p) => quoteOps.download(p));
router.op('quote.accept', (p) => quoteOps.acceptQuote(p)); // deprecated
router.op('quote.internalSendAgreement', (p) => quoteOps.sendAgreementForSignature(p));
router.op('quote.internalCancelAgreement', (p) => quoteOps.cancelAgreement(p));
router.internalOp('quote.internalGetQuoteType', (p) => quoteOps.getQuoteType(p as GetQuoteTypeParams));
router.op('search.internalAttachedFields', (p) => fileOps.searchAttachedFiles(p));
router.op('file.internalAttachToRecord', (p) => fileOps.attachFile(p));
router.op('contractualDocuments.internalCreate', (p) => contractualDocumentsOps.createWithJiraTicket(p));
router.op('contractualDocuments.internalAttachFile', (p) => contractualDocumentsOps.attachFile(p));

function _removeNullsFromObj(obj, fun) {
  const newObj = {};

  Object.keys(obj).forEach((k) => {
    const v = fun(obj[k]);
    if (v !== null && !(typeof v === 'number' && isNaN(v)) && v !== undefined) {
      newObj[k] = v;
    }
  });
  return newObj;
}

function deepRemoveNulls(obj) {
  if (obj === null || (typeof obj === 'number' && isNaN(obj)) || obj === undefined) {
    return obj;
  }
  if (Array.isArray(obj)) {
    return obj.map((v) => deepRemoveNulls(v));
  } else if (typeof obj === 'object') {
    return _removeNullsFromObj(obj, deepRemoveNulls);
  }
  return obj;
}

export const post: EntryPoints.RESTlet.post = (params) => deepRemoveNulls(router.run(params));
