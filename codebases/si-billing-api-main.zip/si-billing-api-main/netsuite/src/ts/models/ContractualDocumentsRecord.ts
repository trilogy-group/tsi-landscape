import * as record from 'N/record';
import QuoteDao from '../dao/QuoteDao';
import { NotFoundError } from '../validation';
import { parseIntOrNull } from '../utility/GeneralUtility';
import { SubscriptionRecord } from './SubscriptionRecord';

export const CONTRACTUAL_DOCUMENTS_RECORD_TYPE = 'customrecord697';
export const CONTRACTUAL_DOCUMENTS_RECORD_TYPE_NUMBER = '697';

export class ContractualDocumentsRecord {
  readonly rec: record.Record;
  readonly isDynamic: boolean;

  constructor(rec: record.Record, isDynamic: boolean) {
    this.rec = rec;
    this.isDynamic = isDynamic;
  }

  static load(id: number, isDynamic = true): ContractualDocumentsRecord {
    let r;
    try {
      r = record.load({ type: CONTRACTUAL_DOCUMENTS_RECORD_TYPE, id: id, isDynamic });
    } catch (e) {
      throw new NotFoundError('Contractual Documents not found');
    }
    return new ContractualDocumentsRecord(r, isDynamic);
  }

  get id(): number {
    return parseInt(this.rec.getValue('id') as string);
  }

  save(): number {
    return this.rec.save();
  }

  saveIfNotSavedBefore(contractDocIds: number[]) {
    if (!contractDocIds.includes(this.id)) {
      this.rec.save();
      contractDocIds.push(this.id);
    }
  }

  get name(): string {
    return this.rec.getValue('name') as string;
  }

  private _quoteId?: number;
  get quoteIdFromName(): number | undefined {
    if (this._quoteId) {
      return this._quoteId;
    }
    let regex = /^https:\/\/.+\/estimate.nl\?(.+)?id=(?<id>\d+)([^\d]+)?$/;
    const quoteId = this.name.match(regex)?.groups?.id;
    if (quoteId) {
      this._quoteId = parseInt(quoteId);
      return this._quoteId;
    }

    regex = /(Q|Quote|quote|QUOTE)\s?#?\s?(?<id>\d+)/
    const quoteTranId = this.name.match(regex)?.groups?.id;
    if (quoteTranId) {
      this._quoteId = QuoteDao.getQuoteIdByTranId(quoteTranId);
      return this._quoteId;
    }

    return undefined;
  }

  get isMasterContract(): boolean {
    return this.rec.getValue('custrecord_sub_doc_is_master_contract') as boolean;
  }

  set isMasterContract(value: boolean) {
    this.rec.setValue({ fieldId: 'custrecord_sub_doc_is_master_contract', value: value });
  }

  get revenueType(): number | null {
    return parseIntOrNull(this.rec.getValue('custrecord_sub_doc_revenue_type') as string);
  }

  set revenueType(id: number | null) {
    this.rec.setValue({ fieldId: 'custrecord_sub_doc_revenue_type', value: id });
  }

  get linkToContractPDF(): string | null {
    return this.rec.getValue('custrecord_sub_doc_link') as string
  }

  set linkToContractPDF(url: string | null) {
    this.rec.setValue({ fieldId: 'custrecord_sub_doc_link', value: url });
  }

  get isESWPaper(): boolean {
    return this.rec.getValue('custrecord_con_sta_is_esw_paper') as boolean;
  }

  set isESWPaper(value: boolean) {
    this.rec.setValue({ fieldId: 'custrecord_con_sta_is_esw_paper', value: value });
  }

  get quote(): number | null {
    return parseIntOrNull(this.rec.getValue('custrecord_sub_doc_quote') as string);
  }

  set quote(id: number | null) {
    this.rec.setValue({ fieldId: 'custrecord_sub_doc_quote', value: id });
  }

  private _subscription?: SubscriptionRecord;
  get subscription(): SubscriptionRecord {
    if (!this._subscription) {
      const subscriptionId = parseInt(this.rec.getValue('custrecord_sub_doc') as string);
      this._subscription = SubscriptionRecord.load(subscriptionId);
    }
    return this._subscription;
  }

  /**
   * only populates the subscription field to use it here in the script
   */
  set subscription(value: SubscriptionRecord) {
    this._subscription = value;
  }
}
