import * as record from 'N/record';

export class SublistIterator<T> {
  readonly sublist: DynamicSublistWrapper;
  private readonly lineConstructor: (sublist: DynamicSublistWrapper) => T;

  constructor(sublist: DynamicSublistWrapper, lineConstructor: (sublist: DynamicSublistWrapper) => T) {
    this.sublist = sublist;
    this.lineConstructor = lineConstructor;
  }
  nextLine(): boolean {
    return this.sublist.nextLine();
  }
  line(): T {
    return this.lineConstructor(this.sublist);
  }

  commit() {
    this.sublist.commit();
  }
}

export class DynamicSublistWrapper {
  rec: record.Record;
  sublistId: string;
  curIdx: number;
  linesCount: number;
  constructor(rec: record.Record, sublistId: string) {
    this.rec = rec;
    this.sublistId = sublistId;
    this.linesCount = rec.getLineCount({ sublistId: sublistId });
    this.curIdx = 0;
  }

  nextLine(): boolean {
    if (this.curIdx > this.linesCount - 1) {
      return false;
    }
    this.rec.selectLine({ sublistId: this.sublistId, line: this.curIdx });
    this.curIdx++;
    return true;
  }

  getFieldValue(fieldId: string): record.FieldValue {
    return this.rec.getCurrentSublistValue({ sublistId: this.sublistId, fieldId: fieldId });
  }

  getFieldText(fieldId: string): string {
    return this.rec.getCurrentSublistText({ sublistId: this.sublistId, fieldId: fieldId });
  }

  setFieldValue(fieldId: string, val: record.FieldValue): void {
    this.rec.setCurrentSublistValue({ sublistId: this.sublistId, fieldId: fieldId, value: val });
  }

  setValueIfDef(fieldId: string, val: record.FieldValue): void {
    if (val) {
      this.rec.setCurrentSublistValue({ sublistId: this.sublistId, fieldId: fieldId, value: val });
    }
  }

  calcValueIfDef<T>(fieldId: string, val: T, f: (val: T) => record.FieldValue): void {
    if (val) {
      this.rec.setCurrentSublistValue({ sublistId: this.sublistId, fieldId: fieldId, value: f(val) });
    }
  }

  commit(): void {
    this.rec.commitLine({ sublistId: this.sublistId });
  }

  lineNumber() {
    return this.curIdx > 0 ? this.curIdx - 1 : 0;
  }

  newLine() {
    this.rec.selectNewLine({ sublistId: this.sublistId });
  }

  selectLine(idx: number) {
    this.curIdx = idx;
    this.rec.selectLine({ sublistId: this.sublistId, line: this.curIdx });
  }
}
