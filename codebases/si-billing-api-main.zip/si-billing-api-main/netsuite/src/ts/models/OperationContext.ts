import { InputParams } from '../types';
import { must } from '../validation';
import { ProductIntegration } from '../ProductIntegration';

export class OperationContext {
  readonly customerId?: string;
  readonly productFamilyCode: string;
  readonly productVariantCode?: string;

  private pi?: ProductIntegration;

  constructor(params: { customerId?: string; productFamilyCode: string; productVariantCode?: string }) {
    this.productFamilyCode = params.productFamilyCode;
    this.productVariantCode = params.productVariantCode;
    this.customerId = params.customerId;
  }

  static fromParams(params: InputParams) {
    return new OperationContext({
      customerId: params.customerId,
      productFamilyCode: must(params.productFamilyCode, 'productFamilyCode'),
      productVariantCode: params.productVariantCode,
    });
  }

  get productIntegration(): ProductIntegration {
    if (!this.pi) {
      this.pi = ProductIntegration.getProductIntegration(this.productFamilyCode, this.productVariantCode ?? '');
    }
    return this.pi;
  }
}
