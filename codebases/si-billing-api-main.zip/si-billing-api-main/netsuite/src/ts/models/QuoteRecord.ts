import * as record from 'N/record';
import { NotFoundError } from '../validation';

export class QuoteRecord {
  readonly rec: record.Record;
  readonly isDynamic: boolean;

  constructor(rec: record.Record, isDynamic: boolean) {
    this.rec = rec;
    this.isDynamic = isDynamic;
  }

  static load(id: number, isDynamic = true): QuoteRecord {
    let r;
    try {
      r = record.load({ type: record.Type.ESTIMATE, id: id, isDynamic });
    } catch (e) {
      throw new NotFoundError('Quote not found');
    }
    return new QuoteRecord(r, isDynamic);
  }

  public save(): number {
    return this.rec.save();
  }

  public get expirationDate(): Date {
    return new Date(this.rec.getValue('duedate') as string);
  }

  public get lineItemsHeaderText(): string {
    return this.rec.getValue('custbody_line_items_header_text') as string;
  }

  public set subscriptionId(value: number | null) {
    this.rec.setValue('custbody_related_subscription', value);
  }

  public get subscriptionPlanId(): number {
    return this.rec.getValue('custbody_subscription_plan') as number;
  }

  get customForm(): number {
    return parseInt(this.rec.getValue('customform') as string);
  }

  get signatureImage(): string | null {
    return this.rec.getValue('custbody_service_provider_signature') as string;
  }
}
