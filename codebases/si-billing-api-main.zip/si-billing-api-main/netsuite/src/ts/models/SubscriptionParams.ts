import { ContractualDocumentType, InputParams, SubscriptionStatus } from '../types';

export interface ChangeOrderParams extends SubscriptionParams {
  customer?: number;
  billingAccount?: number;
  renewalTerm?: number;
  renewalPlan?: number;
  renewalPriceBook?: number;
  renewalMethod?: string;
  modificationType?: string;
  subline?: any;
}

export interface SubscriptionParams extends InputParams {
  subscriptionId?: number;
}
export interface SubscriptionTerminateParams extends SubscriptionParams {
  date?: Date;
  itemCodes?: string[];
}

export interface SubscriptionCreateParams extends InputParams {
  content?: SubscriptionConfiguration;
  activationDate?: Date;
}

export interface SubscriptionPreviewParams extends InputParams {
  content?: SubscriptionConfigurationNoQuantityReq;
  activationDate?: Date;
  subscriptionId?: number;
}

export interface SubscriptionUpdateParams extends SubscriptionCreateParams {
  subscriptionId?: number;
}
export interface SubscriptionCreateParamsNoQuantityReq extends InputParams {
  content?: SubscriptionConfigurationNoQuantityReq;
  activationDate?: Date;
}

export interface SubscriptionUpdateParamsNoQuantityReq extends SubscriptionCreateParamsNoQuantityReq {
  subscriptionId?: number;
}

export interface SubscriptionUpdateOrRenewParams extends InputParams {
  subscriptionId?: number;
  content?: SubscriptionConfiguration;
  activationDate?: Date;
}

export interface SubscriptionUpdateStatusParams extends InputParams {
  subscriptionId?: number;
  content?: {
    status?: SubscriptionStatus;
  };
}

export interface FindForCustomerParams extends InputParams {
  statuses?: Array<string>;
}

export interface ModifyPriceParams extends SubscriptionParams {
  reducePercentage?: number;
  effectiveDate?: string;
  itemCodes?: string[];
}

export interface SetPriceParams extends SubscriptionParams {
  items?: {
    code: string;
    price: number;
  }[];
}

export interface SubscriptionConfigurationItemOptionalQuantity {
  id?: number;
  code: string;
  quantity?: number;
}
export interface SubscriptionConfigurationItem {
  id?: number;
  code: string;
  quantity: number;
}

export interface SubscriptionConfigurationItemNoQuantityReq {
  id?: number;
  code: string;
  quantity?: number;
}
export class SubscriptionConfigurationNoQuantityReq {
  planCode?: string;
  frequency?: string;
  resellerId?: string;
  distributorId?: string;
  endUserInternalId?: number;
  items?: SubscriptionConfigurationItemNoQuantityReq[];
  planId?: number;
  planClass?: number;
  priceBookId?: number;
  trialDuration?: number;
  effectiveDate?: string;
  renewalDaysBeforeEndDate?: number;
  // subscription term duration in months
  duration?: number;
}
export class SubscriptionConfiguration {
  planCode?: string;
  frequency?: string;
  resellerId?: string;
  distributorId?: string;
  endUserInternalId?: number;
  items?: SubscriptionConfigurationItem[];
  planId?: number;
  planClass?: number;
  priceBookId?: number;
  trialDuration?: number;
  effectiveDate?: string;
  renewalDaysBeforeEndDate?: number;
  // subscription term duration in months
  duration?: number;
  contractualDocumentId?: number;
}

export interface ReportUsageParam extends InputParams {
  content?: {
    subscriptionId?: string;
    itemCode?: string;
    quantity?: number;
    lineNumber?: number;
    usageDate?: string;
  }[];
}

export interface AddonDiscount {
  id: number;
  code: string;
  discount: number;
  freeQuantity?: number;
}

export interface Discounts {
  mainItemDiscount: number;
  addons: AddonDiscount[];
}

export const zeroDiscounts = {
  mainItemDiscount: 0,
  addons: [],
} as Discounts;

export interface RenewParams extends SubscriptionUpdateParams {
  planChange?: boolean;
  isDowngrade?: boolean;
  discounts?: Discounts;
}

export interface ChangeQuoteLinkParams {
  oldSubscriptionId: number;
  newSubscriptionId: number;
}

export interface FindSuitableSubsidiaryParams {
  customerId: number;
  classId: number;
  parentSubscriptionId: number;
}

export interface UploadContractualDocumentParams extends InputParams {
  subscriptionId?: number;
  content?: UploadContractualDocumentContentParams;
}

export interface UploadContractualDocumentContentParams {
  type: ContractualDocumentType;
  filename: string;
  contents: string;
}

export interface GetRenewalInfoParams extends SubscriptionParams {
  productTier?: string;
  supportLevel?: string;
}

export interface GetSubscriptionsToSyncParams {
  sinceDate: string;
  classes: string;
}
