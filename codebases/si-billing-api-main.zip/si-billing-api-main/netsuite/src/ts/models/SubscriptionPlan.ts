import { ChargeFrequency, CodeAndTitle, InputParams, ProductTier, SubscriptionItemInfo, SupportLevel } from "../types";

export interface ListSubscriptionPlanParams extends InputParams {
  subscriptionPlanId?: number;
  subscriptionPlanCode?: string;
  getInactive?: boolean;
}


export enum PriceModelType {
  Tiered = 2,
  Volume = 4,
}

export enum PriceTierType {
  Rate = -101,
  FixedAmount = -102,
}

export interface SubscriptionItem extends CodeAndTitle, SubscriptionItemInfo {
  id: number;
  amount: number;
  quantity: number;
  totalIntervalValue: number;
  recuringAmount: number;
  frequency: ChargeFrequency;
  repeatEvery: number;
  required: boolean;
  desc: string;
  type: string;
  typeId: number;
  minQuantity: number;
  maxQuantity: number;
  prices: SubscriptionItemPrice[];
  renewItemId?: number;
  renewItemCode?: string;
}

export interface SubscriptionPlanItem extends CodeAndTitle, SubscriptionItemInfo {
  id: number;
  required: boolean;
  desc: string;
  type: string;
  typeId: number;
  minQuantity: number;
  maxQuantity: number;
  prices: Price[];
}

export interface SubscriptionIncludedItem {
  id?: number;
  code: string;
  quantity: number;
}

export interface ItemPrice {
  id: number;
  price: Price;
}
export interface Price {
  type: string;
  frequency: string;
  currency: string;
  pricebookid: number;
  ranges: PriceTier[];
}
export interface SubscriptionItemPrice {
  type: string;
  frequency: string;
  pricebookid: number;
  ranges: PriceTier[];
}

export interface UptickPlanItem {
  id: number;
  price: SubscriptionItemPrice;
}
export interface PriceTier {
  priceplanid: number;
  type: string;
  fromQuantity: number;
  price: number;
}

export interface SubscriptionItems {
  availableItems: SubscriptionItem[];
  supportItems: SubscriptionItem[];
  mainItem?: SubscriptionItemWithQuantity;
  supportItem?: SubscriptionItemWithQuantity;
}

export interface SubscriptionItemWithQuantity {
  item: SubscriptionItem;
  isIncluded: boolean;
  quantity: number;
}

export interface PlanInfo extends CodeAndTitle {
  id: number;
  description: string;
  name?: string;
  revenueType?: string;
  supportLevel: SupportLevel;
  productTier: ProductTier;
  productTierTitle?: string;
  mainItemCode?: string;
  supportItemCode?: string;
  supportOnly: boolean;
  isLegacyPlan?: boolean;
  renewalPlanId?: number;
  product: {
    family: CodeAndTitle;
    variant: CodeAndTitle;
    tierLabels?: { [P in keyof ProductTier]?: string };
  };
  initialterm: {
    name: string;
    unit: string;
    duration: number;
    type: string;
  };
}

export interface SubscriptionPlan extends PlanInfo {
  items: SubscriptionPlanItem[];
  _ns_displayname?: string;
}
