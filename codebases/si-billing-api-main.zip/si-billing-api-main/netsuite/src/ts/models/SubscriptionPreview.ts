export interface SubscriptionPreviewResponse {
  frequency?: string;
  totalAmount: number;
  items: PreviewResponseItem[];
  totalListPrice: number;
  successPlanPremium: number;
}

export interface PreviewResponseItem {
  code: string;
  title: string;
  quantity: number;
  amount: number;
}
