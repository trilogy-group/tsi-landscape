import * as nsutils from '../nsutils';
import * as record from 'N/record';
import CustomerDao from '../dao/CustomerDao';
import {
  RevenueType,
  RevenueTypeUtils,
  SubscriptionLineStatus,
  SubscriptionStatus,
  SubscriptionTermType,
  TermUnit,
} from '../types';
import { DynamicSublistWrapper, SublistIterator } from './DynamicSublistWrapper';
import { clone, parseIntOrNull } from '../utility/GeneralUtility';
import { SubscriptionNotFoundError, assertNonNegative, assertNotNull } from '../validation';
import { must } from '../validation';
import { SubscriptionPlan } from './SubscriptionPlan';
import SubscriptionPlanUtility from '../utility/SubscriptionPlanUtility';
import SubscriptionDao from '../dao/SubscriptionDao';

export class SubscriptionLine {
  readonly sublist: DynamicSublistWrapper;
  constructor(sublist: DynamicSublistWrapper) {
    this.sublist = sublist;
  }
  get included(): boolean {
    return this.sublist.getFieldValue('isincluded') as boolean;
  }

  set included(incl: boolean) {
    this.sublist.setFieldValue('isincluded', incl);
  }

  get required(): boolean {
    return this.sublist.getFieldValue('isrequired') as boolean;
  }

  get status(): SubscriptionLineStatus {
    return this.sublist.getFieldValue('status') as SubscriptionLineStatus;
  }

  set status(st: SubscriptionLineStatus) {
    this.sublist.setFieldValue('status', st);
  }

  get itemId(): number {
    return this.sublist.getFieldValue('item') as number;
  }
}

const SUBSCRIPTION_UPDATE_NAME_PATTERN = /^.+ - Update - (\d+)$/;
export class SubscriptionUpdateNamePattern {
  static matches(name: string): boolean {
    return SUBSCRIPTION_UPDATE_NAME_PATTERN.test(name);
  }

  static getUpdateSubscriptionId(name: string): number | null {
    const match = SUBSCRIPTION_UPDATE_NAME_PATTERN.exec(name);
    if (match) {
      return parseInt(match[1]);
    }
    return null;
  }

  static generateName(planCode: string, previousSubscriptionId: number) {
    assertNotNull(planCode, 'planCode');
    assertNonNegative(previousSubscriptionId, 'previousSubscriptionId');
    return `${planCode} - Update - ${previousSubscriptionId}`;
  }
}

export class SubscriptionRecord {
  readonly rec: record.Record;
  readonly isDynamic: boolean;

  constructor(rec: record.Record, isDynamic: boolean) {
    this.rec = rec;
    this.isDynamic = isDynamic;
  }

  static load(id: number, isDynamic: boolean = true): SubscriptionRecord {
    let r;
    try {
      r = record.load({ type: record.Type.SUBSCRIPTION, id: id, isDynamic });
    } catch (e) {
      throw new SubscriptionNotFoundError();
    }
    return new SubscriptionRecord(r, isDynamic);
  }

  save(): number {
    return this.rec.save();
  }

  /**
   * Check if customer allowed to read subscription.
   * Allowed to customer and end user.
   */
  isReadableForCustomer(customerId: string) {
    nsutils.logMayBe('isReadableForCustomer params', {
      customerIdToCheck: customerId,
      endUser: this.endUserId,
      customerId: this.customerId,
      testCustomerId: customerId,
    });
    return this.endUserId === customerId || this.customerId === customerId;
  }

  /**
   * Check if customer allowed to update/modify subscription or related records.
   * Allowed to customer only.
   */
  isWritableForCustomer(customerId: string) {
    nsutils.logMayBe('isWritableForCustomer', {
      customerId: this.customerId,
      testCustomerId: customerId,
    });
    return this.customerId === customerId;
  }

  get id(): number {
    return this.rec.getValue('id') as number;
  }

  get status(): SubscriptionStatus {
    return SubscriptionStatus[(this.rec.getValue({ fieldId: 'billingsubscriptionstatus' }) as string).toUpperCase()];
  }

  get initialTermType(): SubscriptionTermType {
    return SubscriptionTermType[this.rec.getValue('initialtermtype') as string];
  }

  get billingAccount(): number {
    return this.rec.getValue('billingaccount') as number;
  }

  get contractDocs(): number | null {
    return parseIntOrNull(this.rec.getValue('custrecord_contract_docs') as string);
  }

  set contractDocs(id: number | null) {
    this.rec.setValue({ fieldId: 'custrecord_contract_docs', value: id });
  }

  get endUserInternalId(): number {
    return parseInt(this.rec.getValue('custrecord_subs_end_user') as string);
  }

  get serialOrLicenseNumber(): string {
    return this.rec.getValue('custrecord_serial_or_license_number') as string;
  }

  private _endUserId?: string;
  get endUserId(): string | undefined {
    if (!this._endUserId) {
      this._endUserId = CustomerDao.getEntityId(this.endUserInternalId);
    }
    return this._endUserId;
  }

  get resellerInternalId(): number {
    return parseInt(this.rec.getValue('custrecord_subs_reseller') as string);
  }

  private _resellerId?: string;
  get resellerId(): string | undefined {
    if (!this._resellerId) {
      this._resellerId = CustomerDao.getEntityId(this.resellerInternalId);
    }
    return this._resellerId;
  }

  get distributorInternalId(): number {
    return parseInt(this.rec.getValue('custrecord_subs_distributor') as string);
  }
  private _distributorId?: string;
  get distributorId(): string | undefined {
    if (!this._distributorId) {
      this._distributorId = CustomerDao.getEntityId(this.distributorInternalId);
    }
    return this._distributorId;
  }

  get customerInternalId(): number {
    return parseInt(this.rec.getValue('customer') as string);
  }

  private _customerId?: string;
  get customerId() {
    if (!this._customerId) {
      this._customerId = CustomerDao.getEntityId(this.customerInternalId);
    }
    return must(this._customerId);
  }

  get startDate(): Date {
    return this.rec.getValue('startdate') as Date;
  }

  get endDate(): Date {
    return this.rec.getValue('enddate') as Date;
  }

  get currency(): number {
    return this.rec.getValue('currency') as number;
  }
  
  private _currencySymbol?: string;
  get currencySymbol(): string {
    if (!this._currencySymbol) {
      this._currencySymbol = SubscriptionDao.getCurrencySymbol(this.currency);
    }
    return must(this._currencySymbol);
  }

  processSublist<T>(sublistId: string, f: (sublist: DynamicSublistWrapper) => T): T {
    if (!this.isDynamic) {
      throw new Error('dynamic iteration not supported for standard mode');
    }
    const sublist = new DynamicSublistWrapper(this.rec, sublistId);
    return f(sublist);
  }

  processSubscriptionLines<T>(f: (sublist: SublistIterator<SubscriptionLine>) => T): T {
    if (!this.isDynamic) {
      throw new Error('dynamic iteration not supported for standard mode');
    }
    const dsw = new DynamicSublistWrapper(this.rec, 'subscriptionline');
    const iter = new SublistIterator<SubscriptionLine>(dsw, (w) => new SubscriptionLine(w));
    return f(iter);
  }

  get department(): number {
    return parseInt(this.rec.getValue('department') as string) as number;
  }

  get subsidiary(): number {
    return parseInt(this.rec.getValue('subsidiary') as string);
  }

  get name(): string {
    return this.rec.getValue('name') as string;
  }

  set name(v: string) {
    this.rec.setValue('name', v);
  }

  get initialTermId(): number {
    return parseInt(this.rec.getValue('initialterm') as string);
  }

  get initialTermDuration(): number {
    return parseInt(this.rec.getValue('initialtermduration') as string);
  }

  get initialTermUnits(): TermUnit {
    return TermUnit[this.rec.getValue('initialtermunits') as string];
  }

  get subscriptionPlanId(): number {
    return parseInt(this.rec.getValue('subscriptionplan') as string);
  }

  get isTrial(): boolean {
    return this.rec.getValue('custrecord_istrial') as boolean;
  }

  set isTrial(val: boolean) {
    this.rec.setValue('custrecord_istrial', val);
  }

  get subscriptionPlanName() {
    return this.rec.getValue('subscriptionplanname') as string;
  }

  get defaultRenewalTerm() {
    return this.rec.getValue('defaultrenewalterm') as string;
  }

  private _subscriptionPlan!: SubscriptionPlan;
  get subscriptionPlan() {
    if (!this._subscriptionPlan) {
      this._subscriptionPlan = SubscriptionPlanUtility.getSubscriptionPlanById(this.subscriptionPlanId, true);
    }
    return this._subscriptionPlan;
  }

  get subscriptionPlanCode(): string {
    return this.subscriptionPlan.code;
  }

  get isMaintenance(): boolean {
    return this.subscriptionPlan.supportOnly;
  }

  get revenueType(): RevenueType | undefined {
    return RevenueTypeUtils.nameToRevenueType(this.subscriptionPlan.revenueType);
  }

  set automaticallyInitiateRenewalProcess(v: boolean) {
    this.rec.setValue('autorenewal', v);
  }
  
  private _parentId!: number | undefined;
  get parentId(): number | undefined {
    if (!this._parentId) {
      this._parentId = getParentIdFromSnapshot(clone(this.rec));
    }
    return this._parentId;
  }

  get customerMemo() {
    return this.rec.getValue('custrecord_customer_memo') as string;
  }
  set customerMemo(memo: string) {
    this.rec.setValue('custrecord_customer_memo', memo);
  }

  get salesRepId() {
    return parseInt(this.rec.getValue('custrecord_subscription_salesrep') as string);
  }

  set salesRepId(value: number) {
    this.rec.setValue('custrecord_subscription_salesrep', value);
  }
}

/**
 * Get parent subscription id checking first internal netsuite field and then the custom record parent field
 */
export function getParentIdFromSnapshot(subscriptionSnapshot): number | undefined {
  let parentSubscriptionId = subscriptionSnapshot.fields.parentsubscription ?? subscriptionSnapshot.fields.custrecord_parent_subscription;
  if (parentSubscriptionId) {
    parentSubscriptionId = parseInt(parentSubscriptionId);
  }
  return parentSubscriptionId;
}
