import { SupportLevel } from '../types';

/**
 * support level distribution ratio
 * @param {SupportLevel} sl support level
 * @returns {number} the distribution ratio
 */
export function supportLevelDistributionRatio(sl: SupportLevel): number {
  // https://docs.google.com/spreadsheets/d/1ljUrYZLrIq-cYDORx5GR1pM3noqDslbS_3-k8PiUGbc/edit#gid=0
  let supportLevelPercent = 0;
  switch (sl) {
    case SupportLevel.Silver:
      supportLevelPercent = 0.20; //NOSONAR this is not a magic number
      break;
    case SupportLevel.Gold:
      supportLevelPercent = 0.35; //NOSONAR this is not a magic number
      break;
    case SupportLevel.Platinum:
      supportLevelPercent = 0.45; //NOSONAR this is not a magic number
      break;
  }
  return 1/(1 + supportLevelPercent) * supportLevelPercent;
}

/**
 * uptick percent apply to each support level
 * @param sl support level
 * @returns the percent uptick to apply
 */
export function supportLevelUptick(sl: SupportLevel): number {
  // https://docs.google.com/document/d/1er4EKdCZ-TTdO2mqTP6ysAvYR865qDmGNzw7eBp2t7o/edit#bookmark=id.p7511kgkzk4x
  switch (sl) {
    case SupportLevel.Silver:
      return 0.25; //NOSONAR this is not a magic number
    case SupportLevel.Gold:
      return 0.35; //NOSONAR this is not a magic number
    case SupportLevel.Platinum:
      return 0.45; //NOSONAR this is not a magic number
    default:
      return 0.25; //NOSONAR this is not a magic number
  }  
}
