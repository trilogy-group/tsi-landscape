import { TermUnit } from '../types';
import { assertNotNull, assertNonNegative } from '../validation';

const MS_IN_A_DAY = 24 * 60 * 60 * 1000;
const DAYS_IN_WEEK = 7;
const MS_IN_A_WEEK = DAYS_IN_WEEK * MS_IN_A_DAY;
export const MONTHS_IN_A_YEAR = 12;

export class TermDuration {
  readonly duration: number;
  readonly units: TermUnit;

  constructor(duration: number, units: TermUnit) {
    assertNonNegative(duration, 'duration');
    assertNotNull(units, 'units');
    this.duration = duration;
    this.units = units;
  }

  isLessThan(term: TermDuration): boolean {
    if (this.units === term.units) {
      return this.duration < term.duration;
    }

    return this.calculateEndDate() < term.calculateEndDate();
  }

  toString(): string {
    return `${this.duration} ${this.units}`;
  }

  /**
   * Calculate the end date from the given duration and start date.
   * @param {number} duration The value of the duration.
   * @param {TermUnit} units The unit of the duration.
   * @param {Date} startDate The start date. If empty, the start date is today.
   * @returns The end date.
   */
  public static calculateEndDate(duration: number, units: TermUnit, startDate?: Date): Date {
    const endDate = startDate ? new Date(startDate) : new Date();
    endDate.setHours(0, 0, 0, 0);
    switch (units) {
      case TermUnit.DAYS:
        endDate.setDate(endDate.getDate() + duration);
        break;
      case TermUnit.WEEKS:
        endDate.setDate(endDate.getDate() + duration * DAYS_IN_WEEK);
        break;
      case TermUnit.MONTHS:
        endDate.setMonth(endDate.getMonth() + duration);
        break;
      case TermUnit.YEARS:
        endDate.setFullYear(endDate.getFullYear() + duration);
        break;
      default:
        throw new Error('Invalid unit');
    }
    endDate.setDate(endDate.getDate() - 1);
    return endDate;
  }

  private calculateEndDate(): Date {
    return TermDuration.calculateEndDate(this.duration, this.units);
  }
}
