import { CodeAndTitle, ProductTier, SubscriptionStatus, SupportLevel, TermUnit } from '../types';
import { SubscriptionIncludedItem, SubscriptionItem } from './SubscriptionPlan';

export interface Address {
  line1?: string;
  line2?: string;
  city?: string;
  state?: string;
  country?: string;
  zip?: string;
  phone?: string;
}

export interface Contact {
  id?: string;
  email?: string;
  name?: PersonName;
  firstName?: string;
  middleName?: string;
  lastName?: string;
  phone?: string;
  billingAddress?: Address;
}

export interface PersonName {
  title?: string;
  firstName?: string;
  middleName?: string;
  lastName?: string;
}

export interface ApiCustomerInfo {
  id: string;
  firstName?: string;
  lastName?: string;
  email: string;
  companyName: string;
  address?: Address;
  shippingAddress?: Address;
  primaryContact?: Contact;
}

export interface ApiSubscriptionPlan {
  id: number;
  code: string;
  description: string;
  title?: string;
  productTier?: ProductTier;
  productTierTitle?: string;
  supportLevel?: SupportLevel;
  revenueType?: string;
  isTrial?: boolean;
  isSupportOnly?: boolean;
  isLegacy?: boolean;
}

export type OperationPermission =
  | 'renew'
  | 'changeEdition'
  | 'changeSuccessPlan'
  | 'changeQuantity'
  | 'changeTerm'
  | 'changeBillingFrequency';

export interface ApiSubscription {
  id: number;
  status: SubscriptionStatus;
  customer: ApiCustomerInfo;
  distributor?: ApiCustomerInfo;
  reseller?: ApiCustomerInfo;
  endUser?: ApiCustomerInfo;
  plan: ApiSubscriptionPlan;
  items: SubscriptionItem[];
  includedItems: SubscriptionIncludedItem[];
  term: {
    start: string;
    end: string;
    frequency: string;
    nextBillCycleDate: string;
    initialTermDuration?: number;
    initialTermUnits?: TermUnit;
  };
  autorenewal: boolean;
  parentSubscription?: number;
  renewalNumber: number;
  totalAmount?: number;
  currency: string;
  totalIntervalValue?: number;
  operations: OperationPermission[];
  quotes: ApiQuote[];
}

export interface ApiQuote {
  id: number;
  isSelfServe: boolean;
  agreements: ApiAgreement[];
}

export interface ApiAgreement {
  id: number;
  type: string;
  status: string;
}

export interface ApiInvoiceInfo {
  number: string;
  date: string;
  dueDate: string;
  totalAmount: number;
  taxAmount?: number;
  currency: string;
  status: CodeAndTitle;
  stripeInvoicePaymentLink: string;
}
