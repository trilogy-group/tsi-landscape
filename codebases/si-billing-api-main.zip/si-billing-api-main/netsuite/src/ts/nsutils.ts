import * as query from 'N/query';
import * as record from 'N/record';
import * as log from 'N/log';
import { SqlParams, Primitive, AnyValue, Any } from './types';
import { FormatOptions, format, parse } from 'N/format';
import * as runtime from 'N/runtime';
import * as https from 'N/https';
import * as email from 'N/email';

export const TSI_INTEGRATION_USER_ID = 672750;

/**
 *
 * @param sql Sql query
 * @param params Positional parameters
 */
export function queryFirstAsMap(sql: string, params: Primitive[]): Any {
  const results = query.runSuiteQL({
    query: sql,
    params: params,
  }).results;

  if (results.length > 0) {
    return results[0].asMap();
  } else {
    return null;
  }
}

/**
 * Assigns a value to a path in an object
 * @param obj object that will receive the value
 * @param keyPath path where will be the value
 * @param value value to assign to the object
 */
export function assign(obj: object, keyPath: string[], value: Primitive | null): void {
  const lastKeyIndex = keyPath.length - 1;
  for (let i = 0; i < lastKeyIndex; ++i) {
    const key = keyPath[i];
    if (!(key in obj)) {
      obj[key] = {};
    }
    obj = obj[key];
  }
  obj[keyPath[lastKeyIndex]] = value;
}

interface TransformPair {
  key: string;
  f: (val: Any) => Any;
}

export type MappingTransform = { [key: string]: string | TransformPair };

/**
 * Transforms the values as specified by the mapping
 * @param vals values to be transformed
 * @param mapping mapping how the values will be transformed
 */
export function mapNested(vals: { [field: string]: Primitive | null }, mapping: MappingTransform): Any {
  const res = {};
  for (const k of Object.keys(vals)) {
    const p = mapping[k];
    if (p) {
      let key = p;
      let value: AnyValue = vals[k];
      if (typeof p === 'object') {
        key = p.key;
        value = p.f(value);
      }
      assign(res, (key as string).split('.'), value as Primitive);
    }
  }
  return res;
}

/**
 *
 * @param sql Sql query
 * @param params Positional parameters
 * @param mapping {"name_in_result": "name_in_target_object_with.dots.if.needed"}
 */
export function queryToJson(sql: string, params: SqlParams, mapping?: MappingTransform, maxResults?: number): Any[] {
  //NOSONAR abstract code
  let results = query.runSuiteQL({
    query: sql,
    params: params,
  }).results;

  if (maxResults) {
    results = results.slice(0, maxResults);
  }

  const res = [] as Any[];
  results.forEach(function (r) {
    if (mapping) {
      res.push(mapNested(r.asMap(), mapping));
    } else {
      res.push(r.asMap());
    }
  });

  logMayBe('queryToJson res', res);

  return res;
}

/**
 *
 * @param sql Sql query
 * @param params Positional parameters
 * @param mapping {"name_in_result": "name_in_target_object_with.dots.if.needed"}
 */
export function queryFirstToJson(sql: string, params: SqlParams, mapping?: MappingTransform): Any | undefined {
  //NOSONAR abstract code
  const res = queryToJson(sql, params, mapping, 1);
  if (res.length > 0) {
    return res[0];
  } else {
    return undefined;
  }
}

/**
 * creates hash with the key specified
 * @param results result to transform
 * @param keyCol column to be the key
 */
export function asHash(results: object[], keyCol: string) {
  const res = {} as object; //NOSONAR abstract code
  for (const o of results) {
    const keyVal = o[keyCol];
    res[keyVal] = o;
  }
  return res;
}

/**
 * Set the values in the parameter in the record
 * @param record record to set the values
 * @param values object with values to set
 */
export function setRecordValues(recordToSet: record.Record, values: object): void {
  for (const key in values) {
    if (Object.prototype.hasOwnProperty.call(values, key)) {
      recordToSet.setValue({
        fieldId: key,
        value: values[key],
      });
    }
  }
}

/**
 * Breaks (long) strings to chunks of requested size
 * @param str input string
 * @param size size of the chunkobject with values to set
 */
export function chunkSubstr(str: string, size: number): string[] {
  const numChunks = Math.ceil(str.length / size);
  const chunks: string[] = [];

  for (let i = 0, o = 0; i < numChunks; ++i, o += size) {
    chunks[i] = str.substring(o, o + size);
  }

  return chunks;
}

const maxNsLogMessageSize = 3999;

/**
 * Is used to overcome the netsuite log limitation on the message length of 4000 characters.
 * The log message is split on several chunks if to large
 * @param title log title
 * @param details log details
 */
export function logDebug(title: string, details: AnyValue): void {
  const detailsAsStr = typeof details === 'string' ? details : JSON.stringify(details);

  if (detailsAsStr && detailsAsStr.length > maxNsLogMessageSize) {
    const chunks = chunkSubstr(detailsAsStr, maxNsLogMessageSize);
    for (let i = 0; i < chunks.length; i++) {
      log.debug(`${title} ${i}`, chunks[i]);
    }
  } else {
    log.debug(title, details);
  }
}

/**
 * Is used to overcome the netsuite log limitation on the amount of messages per day (100000).
 * The log message is logged only if log is enabled in the code
 * @param title log title
 * @param details log details
 */
export function logMayBe(title: string, details): void {
  if (title && (title.startsWith('something') || title.startsWith('something2'))) {
  logDebug(title, details);
}
}

/**
 * Is used to overcome the netsuite log limitation on the amount of messages per day (100000)
 * and log only if the condition is met and if log is enabled in the code
 * @param logIf log condition
 * @param title log title
 * @param details log details
 */
export function logMayBeIf(logIf: boolean, title: string, details): void {
  if (logIf) {
    logMayBe(title, details);
  }
}

export const convert = {
  toBoolean: function (nsBoolStr: string): boolean {
    return nsBoolStr === 'T';
  },
  toDate: function (nsDateStr: string): Date {
    return parse({ value: nsDateStr, type: 'date' } as FormatOptions) as Date;
  },
  toDateText: function (nsDate: Date): string {
    return format({ value: nsDate, type: 'date' } as FormatOptions);
  },
  toDateTimeSearch: function (date: Date): string {
    // format options don't have the option to return in the format expected by the search
    // the format expected by the search is dd-MMM-yyyy hh:mm tt
    const monthNames = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    const dateText = `${date.getDate()}-${monthNames[date.getMonth()]}-${date.getFullYear()}`;
    let hour = date.getHours();
    const minute = date.getMinutes().toString().padStart(2, '0');
    // Convert to 12-hour format and determine AM/PM
    const ampm = hour >= 12 ? 'pm' : 'am';
    hour = hour % 12;
    hour = hour || 12; // Convert hour '0' to '12'
    return `${dateText} ${hour}:${minute} ${ampm}`;
  }
};

export class RecWrapper {
  rec: record.Record;

  constructor(rec: record.Record) {
    this.rec = rec;
  }

  setIfDef(fieldId: string, value: record.FieldValue | undefined): RecWrapper {
    if (value !== undefined) {
      this.rec.setValue({ fieldId: fieldId, value: value });
    }
    return this;
  }

  setIfValid(fieldId: string, value: record.FieldValue | undefined): RecWrapper {
    if (value) {
      this.rec.setValue({ fieldId: fieldId, value: value });
    }
    return this;
  }

  setIfDefText(fieldId: string, text: string | string[] | undefined): RecWrapper {
    if (text !== undefined) {
      this.rec.setText({ fieldId: fieldId, text: text });
    }
    return this;
  }

  calcIfDef<T>(fieldId: string, value: T, valueF: (value: T) => record.FieldValue): RecWrapper {
    if (value !== undefined) {
      this.rec.setValue({ fieldId: fieldId, value: valueF(value) });
    }
    return this;
  }
}

export interface ProductWebhook {
  url: string;
  auth: {
    username: string;
    password: string;
  };
}

/**
 * Returns true if the code is running on Production
 */
export function isProduction(): boolean {
  return !(runtime.accountId.includes('_SB') || runtime.accountId == 'test'); // Not a Sanbdox and not a unit test environment
}

/**
 * Returns number between the dates in days
 */
export function diffDateInDays(endDate: Date, startDate: Date): number {
  const MS_IN_DAY = 1000 * 3600 * 24;
  return Math.floor((endDate.getTime() - startDate.getTime()) / MS_IN_DAY);
}

/**
 * calling a website to delay because netsuite doesn't have a method to delay and when we get the
 * subscription right after saving, sometimes the total interval value is not yet calculated
 */
export function delay(milliseconds: number) {
  try {
    https.get({
      url: `https://httpstat.us/200?sleep=${milliseconds}`
    });
  } catch (e) {
    // if an error happens we don't want to throw the error
  }
}

/**
 * Sends an email to the recipients specified with the subject and message informed
 * When running in a sandbox, NS automatically adds the word SANDBOX to the title and only sends it to the current user
 */
export function sendEmail(recipients: string[], subject: string, message: string) {
  email.send({
      author: TSI_INTEGRATION_USER_ID,
      recipients: recipients.join(','),
      subject: subject,
      body: message
  });
}
