/**
 * @NApiVersion 2.1
 * @NScriptType Suitelet
 */

import { EntryPoints } from 'N/types';
import * as https from 'N/https';
import * as redirect from 'N/redirect';
import QuoteService from './utility/QuoteService';

export const onRequest: EntryPoints.Suitelet.onRequest = (context: EntryPoints.Suitelet.onRequestContext) => {
  if (context.request.method === https.Method.GET && context.request.parameters.op === 'createEUA'
    && context.request.parameters.quoteId) {
    const agreementId = QuoteService.createEUA(context.request.parameters.quoteId);
    redirect.toRecord({
      type: 'customrecord_echosign_agreement',
      id: agreementId,
    });
  } else {
    context.response.write({
      output: '<html><body><h1>Invalid request</h1></body></html>'
    });
  }
};
