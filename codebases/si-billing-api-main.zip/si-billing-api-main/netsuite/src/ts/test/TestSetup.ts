/**
 * @NApiVersion 2.1
 * @NModuleScope SameAccount
 * @NScriptType RESTlet
 */

import { EntryPoints } from 'N/types';
//DO NOT CHANGE ABOVE CODE INCL LINE BREAKS

import * as nsutils from '../nsutils';
import * as record from 'N/record';
import * as log from 'N/log';
import {
  InputData,
  InputDataAggregatedPriceBookLine,
  InputDataItem,
  InputDataLine,
  InputDataPricebook,
  InputDataPricePlanLine,
  InputDataSubscriptionPlan,
  OutputData,
} from './TestSetupTypes';
import { isNotNull } from '../validation';
import { LineType } from '../types';
import { ProductIntegration } from '../ProductIntegration';

/**
 * Group objects in list by specified keys and construct new list where element is object with key fields and prop: array of other fields
 * @param list original list
 * @param keys list of keys from original list type to use as keys
 * @param prop property name for rest data list
 * @returns {...keys, $prop: []}[]
 */
function group<T, Keys extends keyof T, UniqueKeys extends Keys>(
  list: T[],
  keys: UniqueKeys[],
  copyKeys: Keys[],
  prop: string
): (Pick<T, Keys> & { [p in typeof prop]: T[] })[] {
  const res: (Pick<T, Keys> & { [p in typeof prop]: T[] })[] = [];
  const findKeyObj = (elm: T): (Pick<T, Keys> & { [p in typeof prop]: T[] }) | undefined => {
    for (const r of res) {
      let equal: boolean = true;
      for (const k of keys) {
        if ((r[k] as any) != elm[k]) {
          equal = false;
          break;
        }
      }
      if (equal) {
        return r;
      }
    }
    return undefined;
  };
  for (const elm of list) {
    const existingElm = findKeyObj(elm);
    if (existingElm === undefined) {
      const e: Pick<T, Keys> & { [p in typeof prop]: T[] } = {} as any;
      for (const p of copyKeys) {
        (e as any)[p] = elm[p];
      }
      (e as any)[prop] = [elm];
      res.push(e);
    } else {
      existingElm[prop].push(elm);
    }
  }
  return res;
}

class TestData {
  classPrefix: string;
  classTitle: string;
  subsidiaryParentId: number;
  subsidiaryName: string;
  classId?: number;
  subsidiary?: { name: string; id: number };
  additionalClassId?: number;
  additionalSubsidiary?: { name: string; id: number };

  constructor(classPrefix: string, classTitle: string, subsidiaryName: string, subsidiaryParentId?: number) {
    this.classPrefix = classPrefix;
    this.classTitle = classTitle;
    this.subsidiaryName = subsidiaryName;
    this.subsidiaryParentId = subsidiaryParentId || 9 /*THe Group*/;
  }

  createClass(title?: string, subsidiaryId?: number): number {
    const res = nsutils.queryFirstAsMap(`select id from classification where name=?`, [title || this.classTitle]);
    if (res) {
      return res.id;
    }
    const rec = record.create({
      type: record.Type.CLASSIFICATION,
    });
    rec.setValue({ fieldId: 'name', value: title || this.classTitle });
    rec.setValue({ fieldId: 'parent', value: 9 /*Other*/ });
    const subsidiaries = [this.subsidiary!.id];
    let contractingEntityId: number;
    if (subsidiaryId) {
      subsidiaries.push(subsidiaryId);
      contractingEntityId = subsidiaryId;
    } else {
      contractingEntityId = this.subsidiary!.id;
    }
    for (const fieldSuffix of [ 'japan', 'german', 'other', 'us_domestic' ]) {
      rec.setValue({ fieldId: `custrecord_cls_entity_${fieldSuffix}`, value: contractingEntityId });
    }
    rec.setValue({ fieldId: 'subsidiary', value: subsidiaries });
    return rec.save();
  }

  createSubsidiary(name: string): number {
    const rec = record.create({
      type: record.Type.SUBSIDIARY,
      isDynamic: true,
    });

    rec.setValue({ fieldId: 'parent', value: this.subsidiaryParentId });
    rec.setValue({ fieldId: 'name', value: name });
    rec.setValue({ fieldId: 'country', value: 'US' });
    rec.setValue({ fieldId: 'state', value: 'DE' });
    const subsidiaryId = rec.save();

    this.createSubsidiaryTaxRegistration(subsidiaryId); // must be done after the record creation
    return subsidiaryId;
  }

  findOrCreateSubsidiary(name: string): { name: string; id: number } {
    const res = nsutils.queryFirstAsMap(`select id from subsidiary where parent=? and name=?`, [
      this.subsidiaryParentId,
      name,
    ]);
    if (res === null) {
      return { name: name, id: this.createSubsidiary(name) };
    } else {
      this.createSubsidiaryTaxRegistrationIfNone(res.id);
      return { name: name, id: res.id };
    }
  }

  createSubsidiaryTaxRegistration(subsidiaryId: number) {
    const subsidiary = record.load({
      id: subsidiaryId,
      type: record.Type.SUBSIDIARY,
      isDynamic: true,
    });

    subsidiary.selectNewLine({ sublistId: 'taxregistration' });
    subsidiary.setCurrentSublistValue({ sublistId: 'taxregistration', fieldId: 'nexuscountry', value: 'US' });
    subsidiary.setCurrentSublistValue({ sublistId: 'taxregistration', fieldId: 'nexus', value: 4 }); // TX, must be set after nexuscountry = 'US'
    subsidiary.setCurrentSublistValue({ sublistId: 'taxregistration', fieldId: 'taxregistrationnumber', value: '12-3456789' });
    subsidiary.setCurrentSublistValue({ sublistId: 'taxregistration', fieldId: 'taxengine', value: '1472' }); // SuiteTax Engine
    subsidiary.setCurrentSublistValue({ sublistId: 'taxregistration', fieldId: 'effectivefrom', value: new Date(2023, 0, 1) }); // past date to be effective
    subsidiary.commitLine({ sublistId: 'taxregistration' });
    subsidiary.save();
  }

  createSubsidiaryTaxRegistrationIfNone(subsidiaryId: number) {
    const res = nsutils.queryFirstAsMap(
      `select tr.id from subsidiary s left join subsidiarytaxregistration tr on tr.subsidiary = s.id where s.id = ?`, 
      [ subsidiaryId ]
    );

    if (res === null || res.id === null) { // second condition matches in case of a previous deletion
      this.createSubsidiaryTaxRegistration(subsidiaryId);
    }
  }

  createItem(fields: InputDataItem): { name: string; id: number; isSupport: boolean } {
    const rec = record.create({
      type: 'noninventorysaleitem',
      isDynamic: true,
    });
    rec.setValue({ fieldId: 'itemid', value: fields.itemid });
    rec.setValue({ fieldId: 'class', value: fields.additionalSubsidiary ? this.additionalClassId! : this.classId! });
    rec.setValue({ fieldId: 'department', value: 2 /* Sales */ });
    rec.setText({ fieldId: 'custitem_product_line', text: 'None' });
    rec.setText({ fieldId: 'custitem_item_category', text: 'Other' });
    rec.setText({ fieldId: 'custitem_quantity_type', text: 'Other' });
    if (fields.itemdisplayname) {
      rec.setText({ fieldId: 'displayname', text: fields.itemdisplayname });
    }
    if (fields.support_level_name) {
      rec.setText({ fieldId: 'custitem_support_level', text: fields.support_level_name });
    } else if (fields.product_tier_name !== null && fields.product_tier_name !== undefined) {
      rec.setText({ fieldId: 'custitem_product_tier', text: fields.product_tier_name });
    }
    const subsidiaries = [this.subsidiary!.id];
    if (fields.additionalSubsidiary) {
      subsidiaries.push(this.additionalSubsidiary!.id);
    }
    rec.setValue({ fieldId: 'subsidiary', value: subsidiaries });
    rec.setValue({ fieldId: 'incomeaccount', value: 531 });
    rec.setValue({ fieldId: 'revenuerecognitionrule', value: 1 });
    rec.setValue({ fieldId: 'deferredrevenueaccount', value: 221 });
    rec.setValue({ fieldId: 'expenseaccount', value: 221 });
    rec.setValue({ fieldId: 'isfulfillable', value: false });
    if (fields.minimumquantity > 0) {
      rec.setValue({ fieldId: 'minimumquantity', value: fields.minimumquantity });
    }

    return { name: fields.itemid, id: rec.save(), isSupport: fields.support_level_name ? true : false };
  }

  findOrCreateItem(fields: InputDataItem): { name: string; id: number; isSupport: boolean } {
    const res = nsutils.queryFirstAsMap('select id from item where itemid=?', [fields.itemid]);
    if (res === null || res.id === null) {
      return this.createItem(fields);
    } else {
      return { name: fields.itemid, id: res.id, isSupport: fields.support_level_name ? true : false };
    }
  }

  findOrCreateProductIntegration(secret, trialConfig, pvc: string, additional = false) {
    const pi = ProductIntegration.getProductIntegrationOrDefault(this.classPrefix, pvc);

    if (isNotNull(pi)) {
      return { pfc: this.classPrefix, pvc: pvc, secret: secret, class: this.classId! };
    }

    nsutils.logMayBe('findOrCreateProductIntegration - product integration record was not found, a new one will be created', {
      secret,
      trialConfig,
      classTitle: this.classTitle,
      pfc: this.classPrefix,
      pvc: pvc,
      class: this.classId!,
    });

    const rec = record.create({
      type: 'customrecordproductintegration',
    });
    if (additional) {
      rec.setValue({ fieldId: 'custrecordclass', value: this.additionalClassId! });
      rec.setValue({ fieldId: 'custrecordnewcustomersubsidiary', value: this.additionalSubsidiary!.id });
    } else {
      rec.setValue({ fieldId: 'custrecordclass', value: this.classId! });
      rec.setValue({ fieldId: 'custrecordnewcustomersubsidiary', value: this.subsidiary!.id });
    }
    rec.setValue({ fieldId: 'custrecordproductfamilycode', value: this.classPrefix });
    rec.setValue({ fieldId: 'custrecordproductfamilytitle', value: this.classTitle });
    rec.setValue({ fieldId: 'custrecordproductvariantcode', value: pvc });
    rec.setValue({ fieldId: 'custrecordproductvarianttitle', value: pvc });
    rec.setValue({ fieldId: 'custrecordtierlabelstandard', value: 'Basic' });
    rec.setValue({ fieldId: 'custrecordtierlabelprofessional', value: 'Engage' });
    rec.setValue({ fieldId: 'custrecordtierlabelenterprise', value: 'Growth' });
    rec.setValue({ fieldId: 'custrecordsecret', value: secret });
    rec.setValue({ fieldId: 'custrecordtrialsubscriptionconfig', value: JSON.stringify(trialConfig) });
    rec.setValue({ fieldId: 'custrecordenablerenewalautomation', value: true });
    return { pfc: this.classPrefix, pvc: pvc, id: rec.save(), secret: secret, class: this.classId! as number };
  }

  createSubscriptionPlan(fields: InputDataSubscriptionPlan, items: InputDataLine[]) {
    const rec = record.create({
      type: record.Type.SUBSCRIPTION_PLAN,
      isDynamic: true,
    });
    rec.setValue({ fieldId: 'itemid', value: fields.sp_name });
    rec.setValue({ fieldId: 'description', value: fields.sp_description });
    rec.setValue({ fieldId: 'class', value: fields.additionalSubsidiary ? this.additionalClassId! : this.classId! });
    rec.setValue({ fieldId: 'department', value: 2 /* Sales */ });
    rec.setValue({
      fieldId: 'initialterm',
      value: nsutils.queryFirstAsMap(`select id from subscriptionterm where isinactive='F' and name=?`, [
        fields.sp_initialterm,
      ])?.id,
    });
    const subsidiaries = [this.subsidiary!.id];
    if (fields.additionalSubsidiary) {
      subsidiaries.push(this.additionalSubsidiary!.id);
    }
    rec.setValue({ fieldId: 'subsidiary', value: subsidiaries });
    rec.setValue({ fieldId: 'displayname', value: fields.sp_displayname });
    rec.setValue({ fieldId: 'autorenewal', value: fields.sp_autorenewal === 'T' ? true : false });
    rec.setValue({ fieldId: 'defaultrenewalmethod', value: fields.sp_defaultrenewalmethod });
    rec.setValue({ fieldId: 'defaultrenewalterm', value: fields.sp_defaultrenewalterm });
    rec.setValue({ fieldId: 'defaultrenewaltrantype', value: fields.sp_defaultrenewaltrantype });
    rec.setValue({ fieldId: 'advancerenewalperiodnumber', value: fields.sp_advancerenewalperiodnumber });
    rec.setValue({ fieldId: 'advancerenewalperiodunit', value: fields.sp_advancerenewalperiodunit });

    for (const item of items) {
      rec.selectNewLine({ sublistId: 'member' });
      rec.setCurrentSublistValue({
        sublistId: 'member',
        fieldId: 'item',
        value: nsutils.queryFirstAsMap(`select id from item where itemid=?`, [item.itemid])?.id,
      });
      rec.setCurrentSublistText({ sublistId: 'member', fieldId: 'subscriptionlinetype', text: item.chargetype });
      rec.setCurrentSublistValue({ sublistId: 'member', fieldId: 'renewaloption', value: 'ALWAYS' });
      rec.setCurrentSublistValue({
        sublistId: 'member',
        fieldId: 'isrequired',
        value: item.isrequired === 'T' ? true : false,
      });
      rec.commitLine({ sublistId: 'member' });
    }
    const id = rec.save();

    return { name: fields.sp_name, id: id };
  }

  createPricePlan(priceType: string, tiers: InputDataPricePlanLine[]) {
    const rec = record.create({
      type: record.Type.PRICE_PLAN,
      isDynamic: true,
    });
    rec.setText({ fieldId: 'priceplantype', text: priceType });
    for (const tier of tiers) {
      rec.selectNewLine({ sublistId: 'pricetiers' });
      rec.setCurrentSublistValue({ sublistId: 'pricetiers', fieldId: 'fromval', value: tier.fromquantity });
      rec.setCurrentSublistValue({ sublistId: 'pricetiers', fieldId: 'value', value: tier.price });
      rec.setCurrentSublistText({ sublistId: 'pricetiers', fieldId: 'pricingoption', text: tier.pricingoption });
      rec.commitLine({ sublistId: 'pricetiers' });
    }
    return rec.save();
  }

  findOrCreatePriceBook(
    fields: InputDataPricebook,
    lines: InputDataAggregatedPriceBookLine[]
  ): { name: string; id: number } {
    nsutils.logMayBe('createPricebook', fields);

    const res = nsutils.queryFirstAsMap(
      `select id from pricebook where subscriptionplan in (select id from subscriptionplan where itemid=?) and name=?`,
      [fields.sp_name, fields.pricebookname]
    );
    if (res && res.id) {
      return { name: fields.pricebookname, id: res.id };
    }

    const rec = record.create({
      type: record.Type.PRICE_BOOK,
      isDynamic: true,
      defaultValues: {
        subscriptionplan: nsutils.queryFirstAsMap(`select id from subscriptionplan where itemid=?`, [fields.sp_name])
          ?.id,
      },
    });

    //rec.setValue({fieldId: 'subscriptionplan', value: subscriptionPlanId})

    rec.setValue({
      fieldId: 'currency',
      value: nsutils.queryFirstAsMap(`select id from currency where isinactive='F' and symbol=?`, [
        fields.pricebookcurrency,
      ])?.id,
    });
    rec.setValue({ fieldId: 'name', value: fields.pricebookname });

    let i = 0;
    for (const line of lines) {
      const newPricePlan = this.createPricePlan(line.pricetype, line.pricePlan);
      nsutils.logMayBe('createPriceBook', 'pricePlanCreated');
      //rec.insertLine({ sublistId: "priceinterval", line: i})
      rec.selectLine({ sublistId: 'priceinterval', line: i });
      rec.setCurrentSublistValue({
        sublistId: 'priceinterval',
        fieldId: 'item',
        value: nsutils.queryFirstAsMap(`select id from item where itemid=?`, [line.itemid])?.id,
      });

      rec.setCurrentSublistValue({ sublistId: 'priceinterval', fieldId: 'startoffsetvalue', value: 1 });
      rec.setCurrentSublistValue({ sublistId: 'priceinterval', fieldId: 'startoffsetunit', value: 'MONTH' });

      rec.setCurrentSublistText({ sublistId: 'priceinterval', fieldId: 'chargetype', text: line.chargetype });
      rec.setCurrentSublistValue({ sublistId: 'priceinterval', fieldId: 'priceplan', value: newPricePlan });
      rec.setCurrentSublistValue({ sublistId: 'priceinterval', fieldId: 'frequency', value: line.frequency });
      if (line.chargetype === LineType.OneTime) {
        rec.setCurrentSublistValue({ sublistId: 'priceinterval', fieldId: 'repeatevery', value: 0 });
      } else {
        rec.setCurrentSublistValue({ sublistId: 'priceinterval', fieldId: 'repeatevery', value: 1 });
      }
      //rec.setCurrentSublistValue({ sublistId: "priceinterval", fieldId: "prorateby", value:  "DAY"})

      rec.commitLine({ sublistId: 'priceinterval' });
      nsutils.logMayBe('createPriceBook', 'priceBookLine committed');
      i++;
    }

    return { name: fields.pricebookname, id: rec.save() };
  }

  findOrCreateSubscriptionPlan(fields: InputDataSubscriptionPlan, items: InputDataLine[]) {
    const res = nsutils.queryFirstAsMap('select id from subscriptionplan where itemid=?', [fields.sp_name]);
    let sp;
    if (res === null || res.id === null) {
      sp = this.createSubscriptionPlan(fields, items);
    } else {
      sp = { name: fields.sp_name, id: res.id };
    }

    return sp;
  }

  findIncomeAccountId() {
    const res = nsutils.queryFirstAsMap('select id from account where acctnumber=?', ['51150']);
    return res.id;
  }

  deploy(input: InputData[], trialConfig, secret): { error?: unknown; data: OutputData } {
    const data = {} as OutputData;
    try {
      this.subsidiary = this.findOrCreateSubsidiary(this.subsidiaryName);
      data.subsidiary = this.subsidiary;

      this.classId = this.createClass();
      data.class = { name: this.classTitle, id: this.classId };

      this.additionalSubsidiary = this.findOrCreateSubsidiary(this.subsidiaryName + 'Additional');
      this.additionalClassId = this.createClass(this.classTitle + 'Additional', this.additionalSubsidiary.id);

      data.items = [] as any[];
      for (const item of group(
        input,
        ['itemid'],
        [
          'itemid',
          'itemdisplayname',
          'itemdescription',
          'support_level_name',
          'product_tier_name',
          'maximumquantity',
          'minimumquantity',
          'additionalSubsidiary',
        ],
        'other'
      )) {
        const createdItem = this.findOrCreateItem(item);
        data.items.push(createdItem);
      }

      data.subscriptionPlans = [] as any[];
      for (const sp of group(
        input,
        ['sp_name'],
        [
          'sp_name',
          'sp_description',
          'sp_displayname',
          'sp_initialterm',
          'sp_autorenewal',
          'sp_defaultrenewalmethod',
          'sp_defaultrenewalplan',
          'sp_defaultrenewalterm',
          'sp_defaultrenewaltrantype',
          'sp_advancerenewalperiodnumber',
          'sp_advancerenewalperiodunit',
          'additionalSubsidiary',
        ],
        'items'
      )) {
        const spItems = group(sp.items, ['itemid'], ['chargetype', 'itemid', 'isrequired', 'linenumber'], 'other');
        const subscriptionPlan = this.findOrCreateSubscriptionPlan(sp, spItems);

        for (const inPriceBook of group(
          sp.items,
          ['pricebookname'],
          ['sp_name', 'pricebookname', 'pricebookcurrency'],
          'lines'
        )) {
          const pbLines = group(
            inPriceBook.lines,
            ['itemid'],
            ['itemid', 'linenumber', 'chargetype', 'pricetype', 'frequency'],
            'pricePlan'
          );
          const priceBook = this.findOrCreatePriceBook(inPriceBook, pbLines as any);
          if (subscriptionPlan.priceBooks) {
            subscriptionPlan.priceBooks.push(priceBook);
          } else {
            subscriptionPlan.priceBooks = [priceBook];
          }
        }

        data.subscriptionPlans.push(subscriptionPlan);
      }

      data.productIntegration = this.findOrCreateProductIntegration(secret, trialConfig, 'SA-Cus');
      data.productIntegrationList = [
        data.productIntegration,
        this.findOrCreateProductIntegration(secret, trialConfig, 'SA'),
        this.findOrCreateProductIntegration(secret, trialConfig, 'SA-TEST'),
        this.findOrCreateProductIntegration(secret, trialConfig, 'SA-Leg'),
        this.findOrCreateProductIntegration(secret, trialConfig, 'SA-CusEG'),
        this.findOrCreateProductIntegration(secret, trialConfig, ''),
        this.findOrCreateProductIntegration(secret, trialConfig, 'SA-ADDSUB', true),
      ];

      return { data };
    } catch (e) {
      log.error('testdata', e);
      return { error: e, data: data };
    }
  }
}

export const post: EntryPoints.RESTlet.post = (params) => {
  const res = new TestData(params.prefix, params.title, params.subsidiaryName, params.subsidiaryParentId).deploy(
    params.subscriptionPlans,
    params.trialConfig,
    params.secret
  );
  if (res.error) {
    return { msg: res.error, data: res.data };
  } else {
    return { msg: 'OK', data: res.data };
  }
};
