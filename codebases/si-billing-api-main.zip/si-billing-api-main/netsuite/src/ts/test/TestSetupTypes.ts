import { ChargeFrequency, NameAndId, PriceType, ProductTier, SupportLevel } from '../types';

export interface InputDataSubscriptionPlan {
  sp_name: string; //"Sococo Test Enterprise Platinum",
  sp_displayname: string; // "SOT-SA-ENT-PLA",
  sp_description: string;
  sp_initialterm: string;
  sp_autorenewal: string;
  sp_defaultrenewalmethod: string;
  sp_defaultrenewalplan: number;
  sp_defaultrenewalterm: number;
  sp_defaultrenewaltrantype: string;
  sp_advancerenewalperiodnumber: number;
  sp_advancerenewalperiodunit: string;
  additionalSubsidiary?: boolean;
}

export interface InputDataItem {
  additionalSubsidiary?: boolean;
  itemid: string; //"SOT-SA-USE-ENT",
  itemdisplayname: string;
  itemdescription: string; // Users
  support_level_name: SupportLevel; //Silver,
  product_tier_name: ProductTier; //"Enterprise",
  maximumquantity: number; //null,
  minimumquantity: number; //null,
}

export interface InputDataLine {
  itemid: string;
  isrequired: string;
  linenumber: number;
  chargetype: string;
}

export interface InputDataPricebook {
  sp_name: string;
  pricebookname: string; // SOT_SA-ENT-PLA-PB-MON
  pricebookcurrency: string; // "USD",
}

export interface InputDataPriceBookLine {
  //pricebookname: string;
  itemid: string;
  linenumber: number; //1,
  chargetype: string; //"Recurring",
  pricetype: PriceType; // "Tiered",
  frequency: ChargeFrequency; // "MONTHLY",
}

export interface InputDataPricePlanLine {
  fromquantity: number; //0,
  price: number; //29.99,
  pricingoption: string; //
}

export interface InputData
  extends InputDataSubscriptionPlan,
    InputDataItem,
    InputDataLine,
    InputDataPricebook,
    InputDataPriceBookLine,
    InputDataPricePlanLine {}

export interface InputDataAggregatedPriceBookLine extends InputDataPriceBookLine {
  pricePlan: InputDataPricePlanLine[];
}

export interface OutputData {
  subsidiary: NameAndId;
  class: NameAndId;
  productIntegration: { pfc: string; pvc: string; class: number };
  productIntegrationList: { pfc: string; pvc: string; class: number }[];
  items: { id: number; name: string; isSupport: boolean }[];
  subscriptionPlans: (NameAndId & { priceBooks: NameAndId[] })[];
}
