export type Primitive = string | number | boolean;
export type AnyValue = Primitive | object | null;
export type Any = any; // NOSONAR

export interface InputParams {
  productFamilyCode?: string;
  productVariantCode?: string;
  customerId?: string;
  maxResults?: number;
}
export interface SuccessResponse {
  content: Any;
}

export interface ErrorResponse {
  status: number;
  message?: string;
}

export type HandlerResponse = SuccessResponse | ErrorResponse;

export interface TypedSuccessResponse<T> {
  content: T;
}
export type TypedHandlerResponse<T> = TypedSuccessResponse<T> | ErrorResponse;

export type RequestHandler<ParamsType extends any> = (req: ParamsType) => HandlerResponse;

export class OperationUtils {

  /**
   * Calls an operation internally and returns the content result.
   * @param {any} _this The this object of the bound function.
   * @param {(params: P) => TypedHandlerResponse<R>} operation The operation as a bound function.
   * @param {P} params The parameters for the operation.
   * @returns {R} The content result.
   */
  static callAndGetContent<P, R>(_this: Any, operation: (params: P) => TypedHandlerResponse<R>, params: P): R {
    const result = operation.call(_this, params) as unknown as TypedSuccessResponse<R>;
    return result.content;
  }
}

export type SqlType = boolean | string | number | null;
export type SqlParams = Array<NonNullable<SqlType>>;

export interface CodeAndTitle {
  code: string;
  title: string;
}

export enum BillingSchedule {
  MONTHLY = 'MONTHLY',
  ANNUALLY = 'ANNUALLY',
  QUARTERLY = 'QUARTERLY',
}

/**
 * Price plan type
 */
export enum PriceType {
  Tiered = 'Tiered',
  Volume = 'Volume',
}

/**
 * Subscription line type
 */
export enum LineType {
  OneTime = 'One Time',
  Recurring = 'Recurring',
  Usage = 'Usage',
}

/**
 * Price book line frequency
 */
export enum ChargeFrequency {
  Weekly = 'Weekly',
  Monthly = 'Monthly',
  Annually = 'Annually',
  Quarterly = 'Quarterly'
}

/**
 * Billing schedule on a quote
 */
export enum QuoteBillingSchedule {
  // 100% Upon Signature
  FULL_UPON_SIGNATURE = 1,
  //Annually, Due at the start of each term
  ANNUALLY_DUE_AT_START = 2,
  //Monthly, Due at the start of each term
  MONTHLY_DUE_AT_START = 4,
  //Quarterly, Due at the start of quarter
  QUARTERLY_DUE_AT_START = 6,
}

/**
 * Items support level
 */
export enum SupportLevel {
  Silver = 'Silver',
  Gold = 'Gold',
  Platinum = 'Platinum',
}

export class SupportLevelUtil {
  /**
   * Converts short SupportLevel name into SupportLevel
   * @param short code name of SupportLevel
   * @returns SupportLevel
   */
  static codeToSupportLevel(code?: string): SupportLevel | undefined {
    switch (code?.toUpperCase()) {
      case 'SIL':
        return SupportLevel.Silver;
      case 'GOL':
        return SupportLevel.Gold;
      case 'PLA':
        return SupportLevel.Platinum;
      default:
        return undefined;
    }
  }

  /**
   * Converts long SupportLevel name into SupportLevel
   * @param long code name of SupportLevel
   * @returns SupportLevel
   */
  static nameToSupportLevel(name?: string): SupportLevel | undefined {
    switch (name?.toUpperCase()) {
      case 'SILVER':
        return SupportLevel.Silver;
      case 'GOLD':
        return SupportLevel.Gold;
      case 'PLATINUM':
        return SupportLevel.Platinum;
      default:
        return undefined;
    }
  }

  /**
   * Converts number to SupportLevel
   * @param val of support level
   * @returns 1, 2, 3
   */
  static supportLevelFromNumber(val: number): SupportLevel {
    switch (val) {
      case 1: //NOSONAR this is not a magic number
        return SupportLevel.Silver;
      case 2: //NOSONAR this is not a magic number
        return SupportLevel.Gold;
      case 3: //NOSONAR this is not a magic number
        return SupportLevel.Platinum;
      default:
        throw new Error(`Couldn't convert ${val} into SupportLevel`);
    }
  }

  /**
   * Convers support level value into code.
   * @param {SupportLevel} val The support level value.
   * @returns {string} The support level code.
   */
  static supportLevelToCode(val: SupportLevel): string {
    switch (val) {
      case SupportLevel.Silver:
        return 'SIL';
      case SupportLevel.Gold:
        return 'GOL';
      case SupportLevel.Platinum:
        return 'PLA';
      default:
        throw new Error(`Couldn't convert ${val} into SupportLevel code`);
    }
  }

  /**
   * Converts SupportLevel to number to simplify the level comparison
   * @param val of support level
   * @returns 1, 2, 3
   */
  static supportLevelToNumber(val: SupportLevel): number {
    switch (val) {
      case SupportLevel.Silver:
        return 1; //NOSONAR this is not a magic number
      case SupportLevel.Gold:
        return 2; //NOSONAR this is not a magic number
      case SupportLevel.Platinum:
        return 3; //NOSONAR this is not a magic number
      default:
        throw new Error(`Couldn't convert ${val} into SupportLevel number`);
    }
  }
}

/**
 * Item product tier
 */
export enum ProductTier {
  Standard = 'Standard',
  Professional = 'Professional',
  Enterprise = 'Enterprise',
}

export class ProductTierUtil {
  /**
   * Converts short ProductTier short name into ProductTier
   * @param short code name of ProductTier
   * @returns ProductTier
   */
  static codeToProductTier(code?: string): ProductTier | undefined {
    switch (code) {
      case 'STA':
        return ProductTier.Standard;
      case 'PRO':
        return ProductTier.Professional;
      case 'ENT':
        return ProductTier.Enterprise;
      default:
        return undefined;
    }
  }

  /**
   * Convers product tier value into code.
   * @param {ProductTier} val The product tier value.
   * @returns {string} The product tier code.
   */
  static productTierToCode(val: ProductTier): string {
    switch (val) {
      case ProductTier.Standard:
        return 'STA';
      case ProductTier.Professional:
        return 'PRO';
        case ProductTier.Enterprise:
        return 'ENT';
      default:
        throw new Error(`Couldn't convert ${val} into ProductTier code`);
    }
  }

  /**
   * Converts ProductTier to number to simplify the tiers comparison
   * @param val of support level
   * @returns 1, 2, 3
   */
  static productTierToNumber(val: ProductTier): number {
    switch (val) {
      case ProductTier.Standard:
        return 1; //NOSONAR this is not a magic number
      case ProductTier.Professional:
        return 2; //NOSONAR this is not a magic number
      case ProductTier.Enterprise:
        return 3; //NOSONAR this is not a magic number
      default:
        throw new Error(`Couldn't convert ${val} into ProductTier number`);
    }
  }

  /**
   * Converts long ProductTier name into ProductTier
   * @param long code name of ProductTier
   * @returns ProductTier
   */
  static nameToProductTier(name?: string): ProductTier | undefined {
    switch (name?.toUpperCase()) {
      case 'STANDARD':
        return ProductTier.Standard;
      case 'ENTERPRISE':
        return ProductTier.Enterprise;
      case 'PROFESSIONAL':
        return ProductTier.Professional;
      default:
        return undefined;
    }
  }
}

/**
 * Common name and id structore
 */
export interface NameAndId {
  id: number;
  name: string;
}

export enum ItemType {
  MAIN,
  SUPPORT,
  ADDON,
}

export enum TermUnit {
  DAYS = 'DAYS',
  WEEKS = 'WEEKS',
  MONTHS = 'MONTHS',
  YEARS = 'YEARS',
}

export enum SubscriptionTermType {
  STANDARD = 'STANDARD',
  CUSTOM = 'CUSTOM',
  EVERGREEN = 'EVERGREEN',
}

export enum SubscriptionStatus {
  NOT_INCLUDED = 'NOT_INCLUDED',
  DRAFT = 'DRAFT',
  PENDING_ACTIVATION = 'PENDING_ACTIVATION',
  ACTIVE = 'ACTIVE',
  SUSPENDED = 'SUSPENDED',
  CLOSED = 'CLOSED',
  TERMINATED = 'TERMINATED',
}

export enum SubscriptionLineStatus {
  NOT_INCLUDED = 'NOT_INCLUDED',
  DRAFT = 'DRAFT',
  PENDING_ACTIVATION = 'PENDING_ACTIVATION',
  ACTIVE = 'ACTIVE',
}

export enum RenewalMethod {
  CREATE_NEW_SUBSCRIPTION = 'CREATE_NEW_SUBSCRIPTION',
}

export interface SubscriptionItemInfo {
  supportLevel?: SupportLevel;
  productTier?: ProductTier;
  isMainItem: boolean;
  isSupportMainItem: boolean;
  isSupportAddonItem: boolean;
}

export enum OrderType {
  New = 1,
  Upsell = 2,
  Renewal = 3,
  Downsell = 4,
}

export enum RevenueType {
  Hosted = 1,
  OnPremise = 2,
  SaaS = 3,
  ProfessionalServices = 5,
  Support = 8
}

export class RevenueTypeUtils {
  /**
   * Converts string revenue type name into RevenueType
   * @param long code name of ProductTier
   * @returns ProductTier
   */
   static nameToRevenueType(name?: string): RevenueType | undefined {
    switch (name?.toUpperCase()) {
      case 'HOSTED':
        return RevenueType.Hosted;
      case 'ON-PREMISE':
        return RevenueType.OnPremise;
      case 'SAAS':
        return RevenueType.SaaS;
      case 'PROFESSIONAL SERVICES':
        return RevenueType.ProfessionalServices;
      case 'SUPPORT':
        return RevenueType.Support;
      default:
        return undefined;
    }
  }

  static codeToRevenueType(code?: string): RevenueType | undefined {
    switch (code?.toUpperCase()) {
      case 'OP':
        return RevenueType.OnPremise;
      case 'HO':
        return RevenueType.Hosted;
      case 'SA':
        return RevenueType.SaaS;
      case 'PS':
        return RevenueType.ProfessionalServices;
      default:
        return undefined;
    }
  }

  static revenueTypeToName(revenueType?: RevenueType): string | undefined {
    if (!revenueType) {
      return undefined;
    }
    switch (revenueType) {
      case RevenueType.OnPremise:
        return "On-Premise";
      case RevenueType.ProfessionalServices:
        return "Professional Services";
      default:
        return RevenueType[revenueType];
    }
  }
}

export enum channelSalesTiers {
  EndUser = 1,
  Reseller = 2,
  Distributor = 3
}

export enum ContractualDocumentType {
  PurchaseOrder = 'purchase-order',
}

export class ContractualDocumentTypeUtils {

  /**
   * Validates if a given value is a defined contractual document type or not.
   * @param {ContractualDocumentType} value The contractual document type to validate.
   * @returns True if the given contractual document type is defined; otherwise, returns false.
   */
  static hasValue(value: ContractualDocumentType): boolean {
    return Object.values(ContractualDocumentType).includes(value);
  }

  /**
   * Returns the prefix for the filename based on the contractual document type.
   * @param {ContractualDocumentType} type The contractual document type.
   * @returns {string} The prefix for the filename.
   */
  static documentTypeToPrefix(type: ContractualDocumentType): string {
    switch(type) {
      case ContractualDocumentType.PurchaseOrder:
        return "PO-";
      default:
        throw new Error(`The contractual document type '${type}' is not supported`);
    }
  }
}
