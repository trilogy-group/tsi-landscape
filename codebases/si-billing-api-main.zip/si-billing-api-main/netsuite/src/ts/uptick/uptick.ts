/**
 * @NApiVersion 2.1
 * @NScriptType WorkflowActionScript
 */

import { DynamicSublistWrapper } from '../models/DynamicSublistWrapper';
import { clone } from '../utility/GeneralUtility';
import subscriptionGetUtility from '../utility/SubscriptionGetUtility';
import subscriptionPriceUtility from '../utility/SubscriptionPriceUtility';
import * as nsutils from '../nsutils';
import { ProductIntegration } from '../ProductIntegration';

/**
 * Workflow action to uptick prices in the moment a renewal is created
 * @param scriptContext workflow action context
 * @returns the message to have in log for the workflow action
 */
export function onAction(scriptContext) {
  // if the plan or frequency is different, netsuite sets the quantity of items to 1 and
  // we can't run the uptick calculation at this time, as it will be considered a downgrade.
  // apllyUptickPrices is running also when a renewal happens through the self-serve widget to cover when plan or frequency is different
  const newSubscription = clone(scriptContext.newRecord);
  const newSubscriptionPlanId = parseInt(newSubscription.fields.subscriptionplan);
  const pi = ProductIntegration.getBySubscriptionPlanIdOrDefault(newSubscriptionPlanId);
  // skip, if we have no Product Integration Record
  if (pi) {
    nsutils.logMayBe('uptick PI', pi);
    let parentSubscription;
    try {
      parentSubscription = subscriptionGetUtility.getSubscriptionByIdInternal(
        newSubscription.fields.parentsubscription
      );
      if (parentSubscription.plan.id !== newSubscriptionPlanId) {
        nsutils.logMayBe(
          'uptick action',
          'Uptick not applied. New subscription have different plan from parent subscription.'
        );
        return 'Not applied. New subscription have different plan from parent subscription.';
      }
      const items = new DynamicSublistWrapper(scriptContext.newRecord, 'priceinterval');
      items.nextLine();
      const frequency = items.getFieldValue('frequency') as string;
      if (parentSubscription.term.frequency.toUpperCase() !== frequency.toUpperCase()) {
        nsutils.logMayBe(
          'uptick action',
          'Uptick not applied. New subscription have different frequency from parent subscription.'
        );
        return 'Not applied. New subscription have different frequency from parent subscription.';
      }

      nsutils.logMayBe('uptick context', scriptContext);
      return subscriptionPriceUtility.applyModifiedPrices(
        scriptContext.newRecord,
        pi.isUptickEnabled,
        true,
        false,
        false,
        undefined,
        undefined,
        parentSubscription
      );
    }
    catch (ex) {
      nsutils.sendEmail(['rp-si@trilogy.com'], 'Uptick not applied to subscription',
      `An error happened when trying to apply uptick to renewal done for subscription ${newSubscription.fields.parentsubscription} (This is the parent subscription id that was renewed).
Normally this happens when the parent subscription is non standard.
The subscription was created without uptick.
${ex}`);
      scriptContext.newRecord.setValue('custrecord_memo','SYSTEM: Uptick Not Applied.');
      return `Not applied. Error when trying to uptick: ${ex}`;
    }
  } else {
    nsutils.logMayBe('uptick no PIr', null);
    return 'Not applied. No Product Integration Record found.';
  }
}
