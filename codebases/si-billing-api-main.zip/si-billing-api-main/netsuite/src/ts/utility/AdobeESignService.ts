import * as nsutils from '../nsutils';
import * as https from 'N/https';
import * as log from 'N/log';
import * as url from 'N/url';
import * as file from 'N/file';
import * as runtime from 'N/runtime';
import { HttpStatusCode } from './ProductNotificationUtility';

const TEMPORARY_AGREEMENT_SIGNER = 'customer@example.com';
const MULTIPART_BOUNDARY = 'X-LONG-LIVE-ROCKNROLL';

interface AdobeESignConf {
  accessToken: string;
  apiBaseUrl: string;
}

export class AdobeESignService {
  resolveManagerSuitelet(queryParams: { [k: string]: string }): string {
    const suiteletURL = url.resolveScript({
      scriptId: 'customscript_echosign_service_manager',
      deploymentId: 'customdeploy_echosign_service_manager_de',
      returnExternalUrl: true,
      params: queryParams,
    });
    return suiteletURL;
  }

  private triggerRefreshAdobeESignAccessToken() {
    const anyAggId = nsutils.queryFirstAsMap(
      `select id from customrecord_echosign_agreement where custrecord_echosign_status=2 and ROWNUM < 2`,
      []
    ).id;
    const res = https.get({
      url: this.resolveManagerSuitelet({
        echoaction: 'updateStatus',
        recid: `${anyAggId}`,
        senderid: `${runtime.getCurrentUser().id}`,
      }),
    });

    nsutils.logMayBe('triggerRefreshAdobeESignAccessToken request body', res.body);

    if (res.code !== HttpStatusCode.OK) {
      throw new Error('Failed to refresh access token');
    }
  }

  private getConfig(): AdobeESignConf {
    return nsutils.queryFirstToJson(
      'select custrecord_echosign_access_token, custrecord_echosign_api_access_point from customrecord_echosign_config',
      [],
      {
        custrecord_echosign_access_token: 'accessToken',
        custrecord_echosign_api_access_point: { key: 'apiBaseUrl', f: (v) => v + 'api/rest/v6' },
      }
    );
  }

  private uploadTransientDoc(conf: AdobeESignConf, f: file.File): string {
    const body = `--${MULTIPART_BOUNDARY}\r
Content-Disposition: form-data; name="File-Name"\r
\r
${f.name}\r
--${MULTIPART_BOUNDARY}\r
Content-Disposition: form-data; name="Mime-Type	"\r
\r
application/pdf\r
--${MULTIPART_BOUNDARY}\r
Content-Disposition: form-data; name="File"; filename="${f.name}"\r
Content-Transfer-Encoding: base64\r
Content-Type: application/pdf\r
\r
${f.getContents()}\r
--${MULTIPART_BOUNDARY}--\r
    `;
    const res = https.post({
      headers: {
        Authorization: `Bearer ${conf.accessToken}`,
        'Content-Type': `multipart/form-data; boundary=${MULTIPART_BOUNDARY}`,
        'Content-Length': body.length,
      },
      url: `${conf.apiBaseUrl}/transientDocuments`,
      body: body,
    });
    nsutils.logMayBe(`uploadTransientDoc ${f.name} res`, { code: res.code, body: res.body });

    if (res.code !== HttpStatusCode.OK) {
      throw new Error(`Failed to upload transient doc ${f.name}`);
    }

    const resObj = JSON.parse(res.body);
    return resObj.transientDocumentId;
  }

  /**
   * Create temporary agreement to be used for quote preview purposes.
   * @param quoteId quote
   * @param files list of agreement files
   * @returns Adobe ESign Agreement ID
   */
  createTemporaryAgreement(quoteId: number, expirationTime: Date, files: file.File[]) {
    this.triggerRefreshAdobeESignAccessToken();
    const adobeESignConf = this.getConfig();
    const transientDocs: string[] = [];
    for (const f of files) {
      transientDocs.push(this.uploadTransientDoc(adobeESignConf, f));
    }
    const reqBody = {
      name: `Quote Preview Agreement - ${quoteId}`,
      message: 'This is for preview only',
      participantSetsInfo: [
        {
          memberInfos: [
            {
              email: TEMPORARY_AGREEMENT_SIGNER,
            },
          ],
          role: 'SIGNER',
          order: 1,
        },
      ],
      expirationTime: expirationTime,
      signatureType: 'WRITTEN',
      state: 'AUTHORING',
      fileInfos: transientDocs.map((docId) => ({ transientDocumentId: docId })),
    };

    nsutils.logMayBe(`createTemporaryAgreement reqBody`, reqBody);

    const res = https.post({
      headers: {
        Authorization: `Bearer ${adobeESignConf.accessToken}`,
        'Content-Type': 'application/json',
        Accept: 'application/json',
      },
      url: `${adobeESignConf.apiBaseUrl}/agreements`,
      body: JSON.stringify(reqBody),
    });
    nsutils.logMayBe('createTemporaryAgreement res', { code: res.code, body: res.body });
    if (res.code !== HttpStatusCode.CREATED) {
      throw new Error('Failed to create temporary agreement');
    }
    const body = JSON.parse(res.body);
    return body.id;
  }

  /**
   * Return base64 converted pdf corresponding to agreement
   */
  downloadAgreementPdf(adobeAgreementId: string): string {
    // required to refresh access token if it expired
    this.triggerRefreshAdobeESignAccessToken();
    const adobeESignConf = this.getConfig();

    const agPdfRes = https.get({
      headers: {
        Authorization: `Bearer ${adobeESignConf.accessToken}`,
        Accept: 'application/pdf;encoding=base64',
      },
      url: `${adobeESignConf.apiBaseUrl}/agreements/${adobeAgreementId}/combinedDocument`,
    });

    nsutils.logMayBe('downloadAgreementPdf res', { code: agPdfRes.code, headers: agPdfRes.headers });
    if (agPdfRes.code !== HttpStatusCode.OK) {
      throw new Error(`Failed to download agreement ${adobeAgreementId}`);
    }
    return agPdfRes.body;
  }
}

export default new AdobeESignService();
