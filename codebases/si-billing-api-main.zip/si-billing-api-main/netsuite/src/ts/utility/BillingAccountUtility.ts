import * as nsutils from '../nsutils';
import customerDao from '../dao/CustomerDao';
import customerService from '../CustomerService';
import { assertNotNull, assertNotNullMsg, ValidationError } from '../validation';
import { Any, BillingSchedule } from '../types';

export class BillingAccountUtility {
  private createBillingAccount(params: {
    customerId: string;
    frequency: BillingSchedule;
    subsidiaryId: number;
    classId: number;
    effectiveDate?: string;
  }) {
    try {
      return customerService.createBillingAccount(params);
    } catch (e: Any) {
      if (e?.message && e.message.indexOf('for the following field: class') >= 0) {
        throw new ValidationError('Customer is incompatible with this product');
      }
      throw e;
    }
  }

  public getCustomerAndBA(params: {
    customerId: string;
    frequency: BillingSchedule;
    subsidiaryId: number;
    classId: number;
    effectiveDate?: string;
  }) {
    assertNotNull(params.customerId, 'customerId');
    assertNotNull(params.frequency, 'frequency');
    assertNotNull(params.classId, 'classId');
    assertNotNull(params.subsidiaryId, 'subsidiaryId');
    const custAndBa = customerDao.findCustomerAndBa(params);
    nsutils.logMayBe('customer', custAndBa);
    assertNotNullMsg(custAndBa?.customerId, 'customer not found');

    if (!custAndBa.billingAccountId) {
      nsutils.logMayBe('getCustomerAndBA', 'Cannot find billing account. Creating new one');
      custAndBa.billingAccountId = this.createBillingAccount({ ...params, customerId: custAndBa.customerId });
    }
    return custAndBa;
  }
}

export default new BillingAccountUtility();
