import * as record from 'N/record';
import { CONTRACTUAL_DOCUMENTS_RECORD_TYPE, CONTRACTUAL_DOCUMENTS_RECORD_TYPE_NUMBER, ContractualDocumentsRecord } from '../models/ContractualDocumentsRecord';
import { Any, ContractualDocumentType, ContractualDocumentTypeUtils, InputParams, TypedHandlerResponse } from '../types';
import { assertNotNull } from '../validation';
import FileService from './FileService';
import QuoteService from './QuoteService';

export class ContractualDocumentsService {
  public attachFile(params: AttachFileParams): TypedHandlerResponse<Any> {
    assertNotNull(params.contractualDocumentsId, 'contractualDocumentsId');
    assertNotNull(params.fileId, 'fileId');
    FileService.attachFile({
      fileId: params.fileId,
      recordType: CONTRACTUAL_DOCUMENTS_RECORD_TYPE,
      recordId: params.contractualDocumentsId
    });

    if (params.signedQuote) {
      const contractDocs = ContractualDocumentsRecord.load(params.contractualDocumentsId);
      contractDocs.linkToContractPDF = FileService.getUrl(params.fileId);
      contractDocs.save();
    }
    return {
      content: {
        success: true
      },
    };
  }

  public createWithJiraTicket(params: ContractualDocumentsParams): TypedHandlerResponse<Any> {
    assertNotNull(params.quoteId, 'quoteId');
    assertNotNull(params.subscriptionId, 'subscriptionId');
    assertNotNull(params.jiraTicketId, 'jiraTicketId');

    const contractualDocumentsId = this.create(params.quoteId, params.subscriptionId,
      params.jiraTicketId, `Raised ${params.jiraTicketId} invoice request ticket`, params.quoteFileId);

    if (params.fileIds) {
      for (const fileId of params.fileIds) {
        FileService.attachFile({
          fileId: fileId,
          recordType: CONTRACTUAL_DOCUMENTS_RECORD_TYPE,
          recordId: contractualDocumentsId
        });
      }
    }

    return {
      content: {
        contractualDocumentsId: contractualDocumentsId
      },
    };
  }

  /**
   * Create new contractual documents record and attach to sbuscription
   */
  create(quoteId: number, subscriptionId: number, noteTitle: string, noteText: string, contractFileLinkId?: number): number {
    const quote = record.load({
      type: record.Type.ESTIMATE,
      id: quoteId,
      isDynamic: true
    });

    const rec = record.create({
      type: CONTRACTUAL_DOCUMENTS_RECORD_TYPE,
    });
    rec.setValue({ fieldId: 'custrecord_sub_doc', value: subscriptionId });
    rec.setValue({ fieldId: 'name', value: `Quote ${quote.getValue('tranid')}` });
    const cDocsId = rec.save();

    const customForm = parseInt(quote.getValue('customform') as string);
    const contractDocs = ContractualDocumentsRecord.load(cDocsId);
    contractDocs.quote = quoteId;
    contractDocs.isMasterContract = QuoteService.isFullTCsForm(customForm);
    contractDocs.revenueType = QuoteService.getRevenueTypeFromFormNumber(customForm);
    if (contractFileLinkId) {
      contractDocs.linkToContractPDF = FileService.getUrl(contractFileLinkId);
    }
    contractDocs.save();

    const note = record.create({
      type: record.Type.NOTE,
    });
    note.setValue({ fieldId: 'record', value: cDocsId });
    note.setValue({ fieldId: 'recordtype', value: CONTRACTUAL_DOCUMENTS_RECORD_TYPE_NUMBER });
    note.setValue({ fieldId: 'title', value: noteTitle });
    note.setValue({
      fieldId: 'note',
      value: noteText,
    });
    note.save();
    return cDocsId;
  }

  /**
   * Validates if the given document type is attached to a contractual documents record.
   * @param {number} contractualDocumentsId The identifier of the contractual documents record.
   * @param {ContractualDocumentType} documentType The document type.
   * @returns True if the document type is attached; otherwise, returns false.
   */
  public containsDocumentType(contractualDocumentsId: number, documentType: ContractualDocumentType) {
    const attachedFiles = FileService.getAttachedFiles(CONTRACTUAL_DOCUMENTS_RECORD_TYPE, contractualDocumentsId);
    const prefix = ContractualDocumentTypeUtils.documentTypeToPrefix(documentType).toLowerCase();
    return attachedFiles.some((f) => f.fileName.toLowerCase().startsWith(prefix));
  }
}

interface ContractualDocumentsParams extends InputParams {
  quoteId?: number;
  subscriptionId?: number;
  jiraTicketId?: string;
  fileIds?: number[];
  quoteFileId?: number;
}

interface AttachFileParams extends InputParams {
  contractualDocumentsId?: number;
  fileId?: number;
  signedQuote?: boolean;
}

export default new ContractualDocumentsService();
