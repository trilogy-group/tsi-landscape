import * as file from 'N/file';
import * as search from 'N/search';
import * as record from 'N/record';
import * as runtime from 'N/runtime';
import * as nsutils from '../nsutils';
import { Any, InputParams, TypedHandlerResponse } from '../types';
import { assertNotNull } from '../validation';

const FILE_INTERNAL_ID = 'file.internalid';

export enum Folder {
  Agreement = 1168595,
}

export class FileService {
  public searchAttachedFiles(params: SearchParams): TypedHandlerResponse<Any> {
    assertNotNull(params.recordType, 'recordType');
    assertNotNull(params.id, 'id');
    return {
      content: {
        result: this.getAttachedFiles(params.recordType, params.id)
      },
    };
  }

  public getAttachedFiles(recordType: string, id: number) {
    const results = search.create({
      type: recordType,
      filters: [
        ['internalid',search.Operator.IS, id]
      ],
      columns: [
        search.createColumn({ name: 'internalid', join: 'file'}),
        search.createColumn({ name: 'name', join: 'file'}),
        search.createColumn({ name: 'filetype', join: 'file'}),
        search.createColumn({ name: 'url', join: 'file'})
      ]
    }).run().getRange({
      start: 0,
      end: 100
    });

    return results.map((i) => i.getAllValues()).filter((value, index, self) =>
      self.findIndex((i) => i[FILE_INTERNAL_ID][0]?.value === value[FILE_INTERNAL_ID][0]?.value) === index).map((i) => {
      return {
        fileId: i[FILE_INTERNAL_ID][0]?.value,
        fileName: i['file.name'] as string,
        fileType: i['file.filetype'][0],
        fileUrl: i['file.url'] ? `https://${runtime.accountId.replace('_','-')}.app.netsuite.com${i['file.url']}` : i['file.url'],
      }
    }).filter(i => i.fileName !== '');
  }

  public attachFile(params: AttachFileParams): TypedHandlerResponse<Any> {
    assertNotNull(params.fileId, 'fileId');
    assertNotNull(params.recordType, 'recordType');
    assertNotNull(params.recordId, 'recordId');
    record.attach({
      record:{
          type:'file',
          id: params.fileId
      },
      to:{
          type: params.recordType,
          id: params.recordId
      }
    });
    return {
      content: {
        success: true
      }
    }
  }

  public getUrl(fileId: number) {
    let url = nsutils.queryFirstAsMap(
      "SELECT url FROM file WHERE id = ?",
      [fileId]
    )?.url;
    if (url) {
      url = `https://${runtime.accountId.replace('_','-')}.app.netsuite.com${url}`;
    }
    return url;
  }

  /**
   * Uploads a file.
   * @param {UploadFileParams} params The parameters for uploading the file.
   * @returns {number} The file identifier.
   */
  public uploadFile(params: UploadFileParams): number {

    // Create the file record.
    const fileRec = file.create({
      name: params.filename,
      fileType: params.type ?? this.getFileType(params.filename),
      contents: params.contents,
      folder: params.folder,
    });

    // Save it and return the identifier.
    return fileRec.save();
  }

  /**
   * Returns the file type based on the filename.
   * Only a subset of supported file types will matched. If there is no matched, an error is thrown.
   * All file types supported by NetSuite: https://docs.oracle.com/en/cloud/saas/netsuite/ns-online-help/section_4228999954.html#file.Type
   * @param {string} filename The filename.
   * @returns {file.Type} The file type.
   */
  private getFileType(filename: string): file.Type {
    const ext = filename.split('.').pop()?.toLowerCase();
    switch (ext) {
      case 'csv':
        return file.Type.CSV;
      case 'json':
        return file.Type.JSON;
      case 'pdf':
        return file.Type.PDF;
      case 'txt':
        return file.Type.PLAINTEXT;
      default:
        throw new Error(`The file extension ${ext} is not supported`);
    }
  }
}

interface SearchParams extends InputParams {
  recordType?: string;
  id?: number;
}

interface AttachFileParams extends InputParams {
  fileId?: number;
  recordType?: string;
  recordId?: number;
}

export interface UploadFileParams {
  filename: string;
  type?: file.Type;
  contents: string;
  folder?: number;
}

export default new FileService();
