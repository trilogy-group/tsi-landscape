/**
 * Clones the object
 * @constructor
 * @param {any} val - The input object.
 */
export function clone(val) {
  if (val === undefined || val === null) {
    return val;
  }
  return JSON.parse(JSON.stringify(val));
}

/**
 * Finds the last item by condition
 * @constructor
 * @param {Array<T>} arr - The input collection.
 * @param {(T) => boolean} check - Filter func.
 */
export function findLast<T>(arr: Array<T>, check: (T) => boolean): T | null {
  let prev: T | null = null;
  for (const v of arr) {
    if (!check(v)) {
      return prev;
    } else {
      prev = v;
    }
  }
  return prev;
}

declare global {
  interface Array<T> {
    max<T>(this: Array<T>, getPropFunc: (item: T) => number): number;
    sum<T>(this: Array<T>, getPropFunc: (item: T) => number | undefined | null): number;
    last<T>(this: Array<T>): T;
    remove<T>(this: Array<T>, shouldRemoveFunc: (item: T) => boolean): T[];
    groupBy<T, TKey>(this: Array<T>, getKeyFunc: (item: T) => TKey): { key: TKey; count: number; groupItems: T[] }[];
    firstOrUndefined<T>(this: Array<T>, predicate?: (item: T) => boolean): T | undefined;
  }
  interface String {
    toPascalCase(): string | null | undefined;
  }
  interface Date {
    addDays(days: number);
  }
}

/**
 * Calculates maximum of the property value in the array
 * @constructor
 * @param {Array<T>} arr - The input collection.
 * @param {(item: T) => number} getPropFunc - The function, that returns the value of the item we want to find the maximum value for.
 */
if (!Array.prototype.max) {
  Array.prototype.max = function max<T>(this: Array<T>, getPropFunc: (item: T) => number): number {
    if (this.length < 1) {
      throw new Error('source contains no elements');
    }
    return this.reduce((prev, curr) => Math.max(prev, getPropFunc(curr)), Number.MIN_VALUE);
  };
}

/**
 * Gets last item of array
 * @constructor
 * @param {Array<T>} arr - The input collection.
 */
if (!Array.prototype.last) {
  Array.prototype.last = function last<T>(this: Array<T>): T {
    if (this.length < 1) {
      throw new Error('source contains no elements');
    }
    return this[this.length - 1];
  };
}

/**
 * Calculates sum of the property value in the array
 * @constructor
 * @param {Array<T>} arr - The input collection.
 * @param {(item: T) => number} getPropFunc - The function, that returns the value of the item we want to sum a value.
 */
if (!Array.prototype.sum) {
  Array.prototype.sum = function sum<T>(this: Array<T>, getPropFunc: (item: T) => number | undefined | null): number {
    if (this.length < 1) {
      return 0;
    }
    return this.reduce((prev, curr) => {
      const val = getPropFunc(curr);
      return prev + (val ? val : 0);
    }, 0);
  };
}

/**
 * Removes items from the array
 * @constructor
 * @param {Array<T>} arr - The input collection.
 * @param {(item: T) => number} shouldRemoveFunc - The function, evaluated to decide if should item needs to be removed.
 */
if (!Array.prototype.remove) {
  Array.prototype.remove = function remove<T>(this: Array<T>, shouldRemoveFunc: (item: T) => boolean): T[] {
    if (this.length < 1) {
      return [];
    }
    return this.filter((x) => !shouldRemoveFunc(x));
  };
}

/**
 * Returns first matching item or null
 * @constructor
 * @param {Array<T>} arr - The input collection.
 * @param {(item: T) => number} shouldRemoveFunc - The function, evaluated to decide if should item needs to be removed.
 */
if (!Array.prototype.firstOrUndefined) {
  Array.prototype.firstOrUndefined = function firstOrDefault<T>(
    this: Array<T>,
    predicate?: (item: T) => boolean
  ): T | undefined {
    return this.find((x) => (predicate ? predicate(x) : true));
  };
}

/**
 * Calculates maximum of the property value in the array
 * @constructor
 * @param {Array<T>} arr - The input collection.
 * @param {(item: T) => number} getPropFunc - The function, that returns the value of the item we want to find the maximum value for.
 */
if (!Array.prototype.groupBy) {
  Array.prototype.groupBy = function groupBy<T, TKey>(
    this: Array<T>,
    getKeyFunc: (item: T) => TKey
  ): { key: TKey; count: number; groupItems: T[] }[] {
    const groups = this.reduce<{ key: TKey; count: number; groupItems: T[] }[]>(
      (previousValue: { key: TKey; count: number; groupItems: T[] }[], currentValue: T) => {
        const key = getKeyFunc(currentValue);
        let group = previousValue.find((x) => x.key === key);
        if (!group) {
          group = { key: key, count: 0, groupItems: [] };
          previousValue.push(group);
        }
        group.count = group.count + 1;
        group.groupItems.push(currentValue);
        return previousValue;
      },
      []
    );

    return groups;
  };
}

/**
 * Parse int or return null if string is wrong.
 * @param {string} s - input string.
 */
export function parseIntOrNull(s: string): number | null {
  const r = parseInt(s);
  return Number.isNaN(r) ? null : r;
}

export const HUNDRED = 100;

/**
 * Parse float and round to the second decimal place.
 * @param {string} s - input string.
 */
export function parseMoney(s: string): number | null {
  const r = parseFloat(s);
  return Number.isNaN(r) ? null : Math.round(r * HUNDRED) / HUNDRED;
}

/**
 * Rounds may be float to money.
 * @param {number | null} f - input number or null.
 */
export function roundToMoney(f: number | null): number | null {
  if (f === null || Number.isNaN(f)) {
    return null;
  }
  return Math.round(f * HUNDRED) / HUNDRED;
}

/**
 * Rounds float to money.
 * @param {number} f - input number.
 */
export function roundMoney(f: number): number {
  return Math.round(f * HUNDRED) / HUNDRED;
}

/**
 * Converts string to pascal case.
 */
if (!String.prototype.toPascalCase) {
  String.prototype.toPascalCase = function toPascalCase(this: String): string | null | undefined {
    if (this) {
      return this.toUpperCase().substring(0, 1) + this.toLowerCase().substring(1);
    }
    return this;
  };
}

const monthNames = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

/**
 * Parses NetSuite date.
 * @param {string} dateStr - date string in NetSuite format - 11-Jun-2023.
 */
export function tryParseNsDate(dateStr: string): Date | undefined {
  if (dateStr) {
    const parts = dateStr.split('-');
    if (parts.length === 3) {
      return new Date(parseInt(parts[2]), monthNames.indexOf(parts[1]), parseInt(parts[0]));
    }
  }
  return undefined;
}

if (!Date.prototype.addDays) {
  Date.prototype.addDays = function addDays(this: Date, days: number): void {
    this.setDate(this.getDate() + days);
  };
}
