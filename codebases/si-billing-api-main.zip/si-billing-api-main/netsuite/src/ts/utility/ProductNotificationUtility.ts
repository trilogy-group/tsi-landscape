import * as https from 'N/https';
import * as log from 'N/log';
import * as encode from 'N/encode';
import * as nsutils from '../nsutils';
import { assertNotNull, isNotBlank } from '../validation';

export enum ChangeType {
  CREATE = 'subscription_created',
  UPDATE = 'subscription_updated',
  TERMINATE = 'subscription_terminated',
}

export enum HttpStatusCode {
  OK = 200,
  CREATED = 201,
  INTERNAL_SERVER_ERROR = 500
}

export class ProductNotificationUtility {
  buildHeaders(piNotification: nsutils.ProductWebhook) {
    const headers = { 'Content-type': 'application/json' };

    if (isNotBlank(piNotification?.auth?.username)) {
      // Create BASE-64 encoded name:password pair
      const secStringKeyInBase64 = https.createSecureString({
        input: '{' + piNotification.auth.username + '}:{' + piNotification.auth.password + '}',
      });

      secStringKeyInBase64.convertEncoding({
        toEncoding: encode.Encoding.BASE_64,
        fromEncoding: encode.Encoding.UTF_8,
      } as any); //NOSONAR

      // Construct the Authorization header
      const secStringBasicAuthHeader = https.createSecureString({
        input: 'Basic',
      });

      secStringBasicAuthHeader.appendSecureString({
        secureString: secStringKeyInBase64,
        keepEncoding: true,
      } as any); //NOSONAR

      headers['Authorization'] = secStringBasicAuthHeader;
    }
    return headers;
  }

  notifyWebhook(
    piNotification: nsutils.ProductWebhook,
    changeType: ChangeType,
    subscription: { id: number; customer: unknown },
    retryCount: number = 0
  ) {
    assertNotNull(piNotification?.url);

    const headers = this.buildHeaders(piNotification);

    for (let i = 0; i < 1 + retryCount; i++) {
      try {
        const response = https.post({
          url: piNotification.url,
          headers: headers,
          body: JSON.stringify({
            type: changeType,
            content: { subscription: subscription, customer: subscription.customer },
          }),
        });
        if (response.code !== HttpStatusCode.OK) {
          log.error({
            title:
              'Failed to notify webhook "' +
              piNotification.url +
              '" about subscription(id="' +
              subscription.id +
              '") update',
            details: 'Response status is ' + response.code,
          });
        }
      } catch (e) {
        log.error(
          'Failed to notify webhook "' +
            piNotification.url +
            '" about subscription(id="' +
            subscription.id +
            '") update',
          e
        );
      }
    }
  }
}

export default new ProductNotificationUtility();
