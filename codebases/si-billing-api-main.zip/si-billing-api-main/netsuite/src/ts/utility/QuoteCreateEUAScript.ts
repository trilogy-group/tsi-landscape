/**
 * @NApiVersion 2.1
 * @NScriptType ClientScript
 */

import * as currentRecord from 'N/currentRecord';
import * as url from 'N/url';

/**
 * This is needed to make the script available
 */
export function pageInit(scriptContext) {
  // Do nothing
}

/**
 * This function is called when the custom button is clicked
 * It calls the suitelet that creates the EUA
 */
export function createEUA(): void {
  const record = currentRecord.get();
  const quoteId = record.id;

  const suiteletUrl = url.resolveScript({
    scriptId: 'customscript_si_main_suitelet',
    deploymentId: 'customdeploy_si_main_suitelet',
    returnExternalUrl: false
  });

  window.open(`${suiteletUrl}&op=createEUA&quoteId=${quoteId}`, '_blank');
}
