import * as record from 'N/record';
import * as nsutils from '../nsutils';
import * as runtime from 'N/runtime';
import * as render from 'N/render';
import * as https from 'N/https';
import * as file from 'N/file';
import { DynamicSublistWrapper } from '../models/DynamicSublistWrapper';
import { must } from '../validation';
import { SubscriptionRecord } from '../models/SubscriptionRecord';
import { AcceptQuoteParty, UnlinkedQuoteItem } from '../api/operations/QuoteOperations';
import { OperationContext } from '../models/OperationContext';
import { HttpStatusCode } from './ProductNotificationUtility';
import quoteDao, { AgreementRecipientType, TcKeys } from '../dao/QuoteDao';
import SubsidiaryDao from '../dao/SubsidiaryDao';
import AdobeESignService from './AdobeESignService';
import { channelSalesTiers, QuoteBillingSchedule, RevenueType } from '../types';
import { ContractualDocumentsRecord, CONTRACTUAL_DOCUMENTS_RECORD_TYPE } from '../models/ContractualDocumentsRecord';
import FileService from './FileService';
import { QuoteRecord } from '../models/QuoteRecord';
import SubscriptionPlanUtility from './SubscriptionPlanUtility';
import CustomerService from '../CustomerService';
import { clone } from './GeneralUtility';

const HUNDRED_PERCENTS = 100;
const QUOTE_FILES_FOLDER_ID = -4;
const EUA_FOLDER_ID = 8833432;

const ENG_NEW_RESELLERS_QUOTE = 162;
const ESW_QUOTE_MAINT_FULL_TCS = 220;
const ESW_QUOTE_SAAS_FULL_TCS = 221;
const ESW_QUOTE_PS_FULL_TCS = 222;
const ESW_QUOTE_ON_PREM_FULL_TCS = 223;
const ESW_QUOTE_RENEWAL_NO_TC_ATTACHMENTS = 219;
const ESW_QUOTE_STANDARD_SUBSCRIPTION_QUOTE = 181;
const ESW_QUOTE_STANDARD_SUBSCRIPTION_QUOTE_WITH_PLAN = 245
const ESW_EUA = 171;
const ESW_EUA_MAINT = 172;

/**
 * This enum must be kept in sync with the IDs from
 * NS table `customlist_order_type`!
 */
export enum QuoteOrderType {
  New = 1,
  Renewal = 2,
  Upsell = 3,
  ManualRenewal = 12,
  Downsell = 13
}

export enum AgreementType {
  Quote = 1,
  EndUserAcknowledgement = 2
}

class QuoteService {
  /**
   * Generate new quote for subscription.
   * @param dueDate Quote expiration date
   * @param startDate Start date of subscription term.
   * @param endDate End date of the subscription term.
   * @returns [quote id, quote record]
   */
  generateQuote(
    ctx: OperationContext,
    params: {
      endUserId: number;
      customerId: number;
      subscription: SubscriptionRecord;
      name: string;
      dueDate: Date;
      startDate: Date;
      endDate: Date;
      billingSchedule: QuoteBillingSchedule;
      orderType?: string;
      quoteLineEndDates?: {
        line: string;
        endDate: string;
      }[];
      quoteLineStartDates?: {
        line: string;
        startDate: string;
      }[];
      salesRepId?: number;
      lineItemsHeaderText?: string;
      lineItemsFooterText?: string;
      terms?: string;
    }
  ): [number, number] {
    nsutils.logMayBe('generateQuote params', params);
    const linesStartDatesMap: any = {} as Map<string, Date>;
    const linesEndDatesMap: any = {} as Map<string, Date>;
    if (params.quoteLineStartDates) {
      params.quoteLineStartDates.forEach((element) => {
        linesStartDatesMap[element.line] = nsutils.convert.toDate(element.startDate);
      });
    }
    if (params.quoteLineEndDates) {
      params.quoteLineEndDates.forEach((element) => {
        linesEndDatesMap[element.line] = nsutils.convert.toDate(element.endDate);
      });
    }
    const rec = new nsutils.RecWrapper(
      record.create({
        type: record.Type.ESTIMATE,
        isDynamic: true,
      })
    );

    const quoteForm = this.setCommonQuoteFields(params, rec);

    const items = new DynamicSublistWrapper(rec.rec, 'item');
    items.newLine();
    items.setFieldValue('subscription', must(params.subscription.id, 'subscriptionId'));
    items.setFieldValue('department', params.subscription.department);
    // Set list rate for the first row to prevent editing error
    items.setFieldValue('custcol_list_rate', 0);
    items.commit();

    this.updateDates(new DynamicSublistWrapper(rec.rec, 'item'), linesStartDatesMap, linesEndDatesMap);
    const quoteId = rec.rec.save();

    return [quoteId, quoteForm];
  }

  generateUnlinkedQuote(
    ctx: OperationContext,
    params: {
      endUserId: number;
      customerId: number;
      subscription: {
        customerId: string;
        isMaintenance: boolean;
        customerInternalId: number;
        endUserInternalId: number;
        revenueType: RevenueType | undefined;
        subsidiary: number;
        distributorInternalId?: number;
        resellerInternalId?: number;
        currency: number;
        id?: number;
        subscriptionPlanId?: number;
        parentId?: number;
      };
      name: string;
      dueDate: Date;
      startDate: Date;
      endDate: Date;
      billingSchedule: QuoteBillingSchedule;
      orderType?: string;
      items: UnlinkedQuoteItem[],
      salesRepId?: number;
      lineItemsHeaderText?: string;
      lineItemsFooterText?: string;
      terms?: string;
      isSelfServe?: boolean;
      arQuote?: boolean;
    }
  ): [number, number] {
    nsutils.logMayBe('generateQuote params', params);

    const rec = new nsutils.RecWrapper(
      record.create({
        type: record.Type.ESTIMATE,
        isDynamic: true,
      })
    );

    CustomerService.addSubsidiary(params.subscription.customerId, params.subscription.subsidiary);

    const quoteForm = this.setCommonQuoteFields(params, rec);

    const targetItems = new DynamicSublistWrapper(rec.rec, 'item');

    for (const quoteLine of params.items) {
      targetItems.newLine();
      targetItems.setValueIfDef('item', quoteLine.item);
      targetItems.setValueIfDef('quantity', quoteLine.quantity);
      targetItems.setFieldValue('rate', quoteLine.rate);
      targetItems.setValueIfDef('custcol_swe_contract_start_date', quoteLine.startDate ? nsutils.convert.toDate(quoteLine.startDate) : params.startDate);
      targetItems.setValueIfDef('custcol_swe_contract_end_date', quoteLine.endDate ? nsutils.convert.toDate(quoteLine.endDate) : params.endDate);
      targetItems.setFieldValue('amount', quoteLine.amount);
      targetItems.setValueIfDef('custcol_list_rate', quoteLine.listRate ?? null);
      targetItems.commit();
    }
    const quoteId = rec.rec.save();

    return [quoteId, quoteForm];
  }

  private setCommonQuoteFields(params: {
    endUserId: number; customerId: number; subscription: {
      isMaintenance: boolean;
      customerInternalId: number;
      endUserInternalId: number;
      revenueType: RevenueType | undefined;
      subsidiary: number;
      distributorInternalId?: number;
      resellerInternalId?: number;
      currency: number;
      id?: number;
      subscriptionPlanId?: number;
      parentId?: number;
    };
    name: string;
    dueDate: Date;
    startDate: Date;
    endDate: Date;
    billingSchedule: QuoteBillingSchedule;
    orderType?: string;
    salesRepId?: number;
    lineItemsHeaderText?: string;
    lineItemsFooterText?: string;
    terms?: string;
    isSelfServe?: boolean;
    arQuote?: boolean;
  }, rec: nsutils.RecWrapper) {
    const quoteForm = this.getCustomFormNumber(params.subscription);
    rec.setIfDef('customform', quoteForm);
    rec.setIfDef('custbody_end_user', must(params.endUserId, 'endUserId'));
    rec.setIfDef('entity', must(params.customerId, 'customerId'));
    rec.setIfDef('custbody_billing_schedule', params.billingSchedule);
    rec.setIfDef('custbody_renewal_terms', 1);
    rec.setIfDef('probability', HUNDRED_PERCENTS);
    rec.setIfDef('subsidiary', params.subscription.subsidiary);
    rec.setIfDef('custbody_related_subscription', params.subscription.id);
    rec.setIfDef('custbody_subscription_plan', params.subscription.subscriptionPlanId);
    rec.setIfDef('custbody_self_serve', params.isSelfServe);

    rec.setIfDef('duedate', must(params.dueDate, 'dueDate'));
    if (params.salesRepId) {
      rec.setIfDef('salesrep', params.salesRepId);
    }
    rec.setIfDef('startdate', must(params.startDate, 'startDate'));
    rec.setIfDef('enddate', must(params.endDate, 'endDate'));
    rec.setIfDef('title', must(params.name, 'name'));
    rec.setIfDef('custbody_line_items_header_text', must(params.lineItemsHeaderText, 'lineItemsHeaderText'));
    rec.setIfDef('custbody_line_items_footer_text', must(params.lineItemsFooterText, 'lineItemsFooterText'));

    if (params.orderType?.toLowerCase() === 'quote') {
      rec.setIfDef('custbody_order_type', 1); // Contract - New
    } else {
      rec.setIfDef('custbody_order_type', 2); // Contract - Renewal
    }
    rec.setIfValid('custbody_distributor', params.subscription.distributorInternalId);
    rec.setIfValid('custbody_reseller', params.subscription.resellerInternalId);
    if (params.subscription.distributorInternalId) {
      rec.setIfDef('custbody_bill_to_tier', channelSalesTiers.Distributor);
    } else if (params.subscription.resellerInternalId) {
      rec.setIfDef('custbody_bill_to_tier', channelSalesTiers.Reseller);
    } else {
      rec.setIfDef('custbody_bill_to_tier', channelSalesTiers.EndUser);
    }
    rec.setIfDef('currency', params.subscription.currency);
    this.setShipingAddress(params.endUserId, params.customerId, rec);
    rec.setIfDef('terms', quoteDao.getTermId(params.terms));
    rec.setIfDef('custbody_ar_quote', params.arQuote);
    return quoteForm;
  }

  customFormIsFullTCs(customFormNumber: number): boolean {
    switch (customFormNumber) {
      case ESW_QUOTE_MAINT_FULL_TCS:
      case ESW_QUOTE_SAAS_FULL_TCS:
      case ESW_QUOTE_PS_FULL_TCS:
      case ESW_QUOTE_ON_PREM_FULL_TCS:
        return true;
      default:
        return false;
    }
  }

  private setShipingAddress(endUserId: number, customerId: number, estimateRec: nsutils.RecWrapper) {
    // NS automatically assigns the customer shipping address to the quote
    // no need to change if the end user is not different from the customer
    if (endUserId !== customerId) {
      const endUser = record.load({
        type: record.Type.CUSTOMER,
        id: endUserId,
        isDynamic: true
      });
      const defaultShippingAddressLineNumber = endUser.findSublistLineWithValue({
        sublistId: 'addressbook',
        fieldId: 'defaultshipping',
        value: true,
      });
      estimateRec.setIfDef('shipaddresslist', null);
      if (defaultShippingAddressLineNumber >= 0) {
        const addressKey = endUser.getSublistValue('addressbook', 'addressbookaddress_key', defaultShippingAddressLineNumber);
        estimateRec.setIfDef('shippingaddress_key', addressKey);
      } else {
        estimateRec.setIfDef('shippingaddress_key', null);
      }
    }
  }

  private findMasterContractId(parentSubscriptionId: number | undefined, customerInternalId: number, revenueType: RevenueType | undefined, subsidiary: number,
    calledSubscriptionIds: number[]): number | null {
    nsutils.logMayBe('customForm params', {
      parentSubscriptionId, revenueType, subsidiary
    });

    // subscription doesn't have parent, which means doesn't have master contract
    // or if it's already called it's because it's calling itself or a child subscription
    if (!parentSubscriptionId || calledSubscriptionIds.includes(parentSubscriptionId)) {
      return null;
    }
    calledSubscriptionIds.push(parentSubscriptionId);

    const parentSubscription = SubscriptionRecord.load(parentSubscriptionId);
    // parent subscription doesn't have contractual documents, search in the parent of the parent
    if (!parentSubscription.contractDocs) {
      return this.findMasterContractId(parentSubscription.parentId, customerInternalId, revenueType, subsidiary, calledSubscriptionIds);
    }

    const contractDocs = ContractualDocumentsRecord.load(parentSubscription.contractDocs, false);
    // contractual documents is not master, search in the parent of the parent
    if (!contractDocs.isMasterContract) {
      return this.findMasterContractId(parentSubscription.parentId, customerInternalId, revenueType, subsidiary, calledSubscriptionIds);
    }

    // another customer, master contract not applicable
    if (customerInternalId !== parentSubscription.customerInternalId) {
      return null;
    }

    /* LAMBDA-62602 condition disabled: waiting next occurrence(s) to check the scenario before deleting the "Revenue Type" field.
    // another revenue type, master contract not applicable
    if (this.isDifferentRevenueTypeForForm(revenueType, contractDocs.revenueType)) {
      return null;
    }
    */

    // another subsidiary, master contract not applicable
    if (subsidiary !== parentSubscription.subsidiary) {
      return null;
    }

    // master contract found for same revenue type and subsidiary
    return contractDocs.id;
  }

  private isDifferentRevenueTypeForForm(revenueType1, revenueType2) {
    return revenueType1 && revenueType2 && revenueType1 !== revenueType2 &&
      // revenue type Hosted and OnPremise uses the same custom form
      !((revenueType1 === RevenueType.Hosted || revenueType1 === RevenueType.OnPremise) &&
        (revenueType2 === RevenueType.Hosted || revenueType2 === RevenueType.OnPremise));
  }

  setSignedQuotesToContractualDocuments(subscriptionId: number | undefined, calledSubscriptionIds: number[]): {
    message: string, found: boolean, masterContract?: ContractualDocumentsRecord, contractualDocumentIdsChanged: number[]
  } {
    nsutils.logMayBe('setSignedQuotesToContractualDocuments subscriptionId', subscriptionId);

    // if it's empty, is because no more parent exists
    // or if it's already in called subscriptions is because the subscription is referencing itself or a child subscription
    if (!subscriptionId || calledSubscriptionIds.includes(subscriptionId)) {
      return {
        message: 'Signed Full TCs not found',
        found: false,
        contractualDocumentIdsChanged: []
      };
    }
    calledSubscriptionIds.push(subscriptionId);

    const subscription = SubscriptionRecord.load(subscriptionId);
    if (!subscription.contractDocs) {
      return this.setSignedQuotesToContractualDocuments(subscription.parentId, calledSubscriptionIds);
    }

    const contractDocs = ContractualDocumentsRecord.load(subscription.contractDocs, false);
    if (!contractDocs.quoteIdFromName) {
      return this.setSignedQuotesToContractualDocuments(subscription.parentId, calledSubscriptionIds);
    }

    const quote = record.load({
      type: record.Type.ESTIMATE,
      id: contractDocs.quoteIdFromName,
    });
    const customForm = parseInt(quote.getValue('customform') as string);
    nsutils.logMayBe('setSignedQuotesToContractualDocuments customForm', customForm);

    contractDocs.quote = contractDocs.quoteIdFromName;
    contractDocs.isMasterContract = this.isFullTCsForm(customForm);
    contractDocs.revenueType = this.getRevenueTypeFromFormNumber(customForm);
    contractDocs.subscription = subscription;

    const signedAgreementId = quoteDao.findSignedAgreementId(contractDocs.quoteIdFromName);

    // search for files with word signed in the name attached to the contractual document
    const files = FileService.getAttachedFiles(CONTRACTUAL_DOCUMENTS_RECORD_TYPE, subscription.contractDocs)
      .filter(i => !i.fileName.toLowerCase().includes('unsigned'));
    const signedTCs = files.find(i => i.fileName.toLowerCase().includes('signed'));

    let message;
    if (signedAgreementId) {
      // signed agreement through adobe automation
      contractDocs.linkToContractPDF = this.getSignedDocUrlFromAgreement(signedAgreementId);
      message = 'Full TCs agreement signed through adobe sign found';
    } else if (signedTCs) {
      // attached file in contractual documents with 'signed' word in it
      contractDocs.linkToContractPDF = signedTCs?.fileUrl as string;
      message = 'Full TCs found attached in contractual documents with signed word in it';
    }

    if (contractDocs.isMasterContract) {
      contractDocs.save();
      return {
        found: true,
        masterContract: contractDocs,
        message: message ?? 'Quote is using Full TCs form but signed pdf couldn\'t be find.',
        contractualDocumentIdsChanged: [contractDocs.id]
      }
    }

    const result = this.setSignedQuotesToContractualDocuments(subscription.parentId, calledSubscriptionIds);
    contractDocs.saveIfNotSavedBefore(result.contractualDocumentIdsChanged);
    return result;
  }

  getSignedDocUrlFromAgreement(agreementId: number): string {
    const agreement = record.load({
      type: 'customrecord_echosign_agreement',
      id: agreementId
    });
    const fileId = agreement.getValue('custrecord_echosign_signed_doc') as number;
    return FileService.getUrl(fileId);
  }

  /**
   * Returns the URL of the signed document if it exists.
   * @param quoteId The internal ID of the quote.
   * @returns {string | null} The URL of the signed document.
   */
  getSignedDocUrlFromQuote(quoteId: number): string | null {

    // If there is a signed agreement, return the URL of the signed document.
    const signedAgreementId = quoteDao.findSignedAgreementId(quoteId);
    if (signedAgreementId) {
      return this.getSignedDocUrlFromAgreement(signedAgreementId);
    }

    // Else, the signed document is not found.
    return null;
  }

  private getCustomFormNumber(subscription: {
    isMaintenance: boolean;
    customerInternalId: number;
    endUserInternalId: number;
    revenueType: RevenueType | undefined;
    subsidiary: number;
    parentId?: number;
  }): number {
    if (subscription.customerInternalId !== subscription.endUserInternalId) {
      return ENG_NEW_RESELLERS_QUOTE;
    }

    nsutils.logMayBe('customForm check', {
      maint: subscription.isMaintenance,
      revenueType: subscription.revenueType
    });
    const fullTCsForm = this.getFullTCsFormNumber(subscription);
    nsutils.logMayBe('customForm fullTCsForm', fullTCsForm);

    if (!fullTCsForm || this.findMasterContractId(subscription.parentId, subscription.customerInternalId, subscription.revenueType, subscription.subsidiary, [])) {
      return ESW_QUOTE_RENEWAL_NO_TC_ATTACHMENTS;
    }

    return fullTCsForm;
  }

  public getFullTCsFormNumber(subscription: {
    isMaintenance: boolean;
    revenueType: RevenueType | undefined;
  }): number | undefined {
    let fullTCsForm;
    if (subscription.isMaintenance) {
      fullTCsForm = ESW_QUOTE_MAINT_FULL_TCS;
    } else if (subscription.revenueType === RevenueType.SaaS) {
      fullTCsForm = ESW_QUOTE_SAAS_FULL_TCS;
    } else if (subscription.revenueType === RevenueType.OnPremise || subscription.revenueType === RevenueType.Hosted) {
      fullTCsForm = ESW_QUOTE_ON_PREM_FULL_TCS;
    } else if (subscription.revenueType === RevenueType.ProfessionalServices) {
      fullTCsForm = ESW_QUOTE_PS_FULL_TCS;
    }
    return fullTCsForm;
  }

  isFullTCsForm(customFormNumber: number): boolean {
    switch (customFormNumber) {
      case ESW_QUOTE_MAINT_FULL_TCS:
      case ESW_QUOTE_ON_PREM_FULL_TCS:
      case ESW_QUOTE_PS_FULL_TCS:
      case ESW_QUOTE_SAAS_FULL_TCS:
        return true;
      default:
        return false;
    }
  }

  isESWForm(customFormNumber: number): boolean {
    switch (customFormNumber) {
      case ESW_QUOTE_MAINT_FULL_TCS:
      case ESW_QUOTE_ON_PREM_FULL_TCS:
      case ESW_QUOTE_PS_FULL_TCS:
      case ESW_QUOTE_SAAS_FULL_TCS:
      case ESW_QUOTE_RENEWAL_NO_TC_ATTACHMENTS:
      case ESW_QUOTE_STANDARD_SUBSCRIPTION_QUOTE:
      case ESW_QUOTE_STANDARD_SUBSCRIPTION_QUOTE_WITH_PLAN:
        return true;
      default:
        return false;
    }
  }

  getRevenueTypeFromFormNumber(customFormNumber: number): RevenueType | null {
    switch (customFormNumber) {
      case ESW_QUOTE_MAINT_FULL_TCS:
        return RevenueType.Support;
      case ESW_QUOTE_SAAS_FULL_TCS:
        return RevenueType.SaaS;
      case ESW_QUOTE_ON_PREM_FULL_TCS:
        return RevenueType.OnPremise;
      case ESW_QUOTE_PS_FULL_TCS:
        return RevenueType.ProfessionalServices;
      default:
        return null;
    }
  }

  /**
   * Set end dates for the quote
   */
  private updateDates(
    sublist: DynamicSublistWrapper,
    startDatesMap: Map<string, Date>,
    endDatesMap: Map<string, Date>
  ) {
    while (sublist.nextLine()) {
      const lineTitle = sublist.getFieldValue('custcol_ava_item');
      const itemCode = lineTitle?.toString() ?? '';
      if (startDatesMap[itemCode]) {
        sublist.setFieldValue('custcol_swe_contract_start_date', startDatesMap[itemCode]);
      }
      if (endDatesMap[itemCode]) {
        sublist.setFieldValue('custcol_swe_contract_end_date', endDatesMap[itemCode]);
      }
      sublist.commit();
    }
  }

  /**
   * Create new adobe services agreement for the quote.
   * Attach terms and conditions doc corresponding to PI record in ctx
   */
  createAdobeServicesAgreement(
    quoteId: number,
    tcKeys: TcKeys[],
    preview: boolean,
    type: AgreementType,
    recipients?: {
      email: string;
      role: string;
    }[]
  ): number {
    nsutils.logMayBe('createAdobeServicesAgreement recipients', recipients);
    const rec = record.create({
      type: 'customrecord_echosign_agreement',
      isDynamic: true,
    });
    rec.setValue('custrecord_echosign_parent_type', 'estimate');
    rec.setValue('custrecord_echosign_parent_record', quoteId);
    rec.setValue('custrecord_echosign_senddocinteractive', preview);
    rec.setValue('custrecord_agreement_type', type);

    const quoteRec = record.load({
      type: record.Type.ESTIMATE,
      id: quoteId,
    });
    const subsidiaryId = parseInt(quoteRec.getValue('subsidiary') as string);
    const subsidiaryName = SubsidiaryDao.getSubsidiaryName(subsidiaryId);
    let name = `${subsidiaryName} / ${quoteRec.getValue('title')}`;

    if (type === AgreementType.EndUserAcknowledgement) {
      name += ` End User Acknowledgement`;
      rec.setValue('custrecord_echosign_message', `Dear Partner,
    
Please kindly delegate the signature of this document to the End User and return the signed copy back to us.

Thank you for your continued partnership.

Best regards,
${subsidiaryName} Orders Team`);
    }

    rec.setValue('name', name);
    const echosignAgreementId = rec.save();

    this.addRecipients(echosignAgreementId, subsidiaryId, type, quoteId, recipients);

    let quoteFile;
    if (type === AgreementType.Quote) {
      quoteFile = this.attachQuotePDF(quoteId, echosignAgreementId);
    } else if (type === AgreementType.EndUserAcknowledgement) {
      //select maintenance template if it's maintenance
      const templateId = tcKeys.includes(TcKeys.EUA_Maintenance) ? ESW_EUA_MAINT : ESW_EUA;
      this.attachAdvancedTemplate(templateId, quoteRec, EUA_FOLDER_ID, echosignAgreementId, name);
    }

    const files = this.addTermsAndConditions(tcKeys, echosignAgreementId, []);

    // if there are recipients, it means it’s not self-serve and we don't need to generate a temporary agreement
    // when it's self-serve, we generate a temporary agreement to allow the customer to see the agreement with all the fields from the quote
    if (type === AgreementType.Quote && !recipients) {
      files.unshift(quoteFile);
      const previewAgId = AdobeESignService.createTemporaryAgreement(
        quoteId,
        quoteRec.getValue('duedate') as Date,
        files
      );

      quoteRec.setValue('custbody_tsi_quotepreview_ag_id', previewAgId);
      quoteRec.save();
    }

    return echosignAgreementId;
  }

  private attachAdvancedTemplate(templateId: number, templateRecord: record.Record, folderId: number, agreementId: number, name: string) {
    const renderer = render.create();
    renderer.addRecord({
      templateName: 'record',
      record: templateRecord
    });
    renderer.setTemplateById({ id: templateId })

    const pdf = renderer.renderAsPdf();
    pdf.folder = folderId;
    pdf.name = `${name}.pdf`;
    const pdfFileId = pdf.save();
    this.createAdobeAgreementDoc(agreementId, pdfFileId);
  }

  private attachQuotePDF(quoteId: number, agreementId: number) {
    const quoteFile = render.transaction({
      entityId: quoteId,
      printMode: render.PrintMode.PDF,
    });
    quoteFile.folder = QUOTE_FILES_FOLDER_ID;
    const quotePdfFileId = quoteFile.save();
    this.createAdobeAgreementDoc(agreementId, quotePdfFileId);
    return quoteFile;
  }

  private addRecipients(agreementId: number,
    subsidiaryId: number,
    type: AgreementType,
    quoteId: number,
    recipients?: {
      email: string;
      role: string;
    }[]) {
    if (!recipients) {
      return;
    }
    // Cloning here because the list will be altered.
    const localRecipients = clone(recipients);

    const customerSignerIndex = localRecipients.findIndex(i => i.role.toLowerCase() === 'signer');
    // if a signer is not found, no recipient is added because the customer signer needs to be the first recipient
    // in order to work signer order in adobe
    let order = 1;
    if (customerSignerIndex === -1) {
      return;
    }

    // For renewal quotes, add the implicit BU recipient, as per:
    // https://trilogy-confluence.atlassian.net/wiki/spaces/CentralFinance/pages/369725149/2a.+How+to+prepare+a+quote
    const quoteDetails = quoteDao.getOrderTypeAndOutboundEmailDomain(quoteId);
    if (
      quoteDetails?.orderType === QuoteOrderType.Renewal ||
      quoteDetails?.orderType === QuoteOrderType.ManualRenewal
    ) {
      this.addBusinessUnitRenewalsRecipient(localRecipients, quoteDetails?.outboundEmailDomain);
    }

    const customerSignerEmail = localRecipients.splice(customerSignerIndex, 1)[0].email;
    quoteDao.addAgreementRecipient(agreementId, customerSignerEmail, false, order, 0);
    order++;

    let ccOrder = 0;
    if (type === AgreementType.Quote) {
      const quote = QuoteRecord.load(quoteId);
      if (quote.signatureImage) {
        this.addServiceProviderSignerAgreement(subsidiaryId, agreementId, true, order, ccOrder);
        ccOrder++;
      } else {
        this.addServiceProviderSignerAgreement(subsidiaryId, agreementId, false, order, 1);
      }
      order++;
    }

    for (const newRecipientEmail of localRecipients) {
      quoteDao.addAgreementRecipient(agreementId, newRecipientEmail.email, true, order, ccOrder);
      order++;
      ccOrder++;
    }
    this.addO2CEmailasCC(agreementId, order, ccOrder);
  }

  /**
   * Augment a recipients list with the Business Unit's email for renewals.
   * @param {{ email: string, role: string }[]} recipients The array of recipients to be augmented.
   */
  private addBusinessUnitRenewalsRecipient(recipients: { email: string; role: string }[], outboundEmailDomain?: string) {
    if (outboundEmailDomain) {
      const recipientEmail = nsutils.isProduction()
        ? `renewals@${outboundEmailDomain}`
        : `renewals@${outboundEmailDomain}.invalid`;
      recipients.push({ email: recipientEmail, role: 'cc' });
    }
  }

  private addServiceProviderSignerAgreement(subsidiaryId: number, echosignAgreementId: number, cc: boolean, order: number, signerOrder: number): boolean {
    const serviceProviderEmail = SubsidiaryDao.getServiceProviderQuoteSigner(subsidiaryId);
    if (serviceProviderEmail) {
      quoteDao.addAgreementRecipient(
        echosignAgreementId,
        serviceProviderEmail,
        cc,
        order,
        signerOrder
      );
      return true;
    }
    return false;
  }

  private getO2CEmail(): string {
    return nsutils.isProduction() ? 'o2c@trilogy.com' : 'o2c@trilogy.com.invalid';
  }

  private addO2CEmailasCC(echosignAgreementId: number, order: number, ccOrder: number) {
    quoteDao.addAgreementRecipient(
      echosignAgreementId,
      this.getO2CEmail(),
      true,
      order,
      ccOrder
    );
  }

  getQuoteType(quoteForm: number): string {
    switch (quoteForm) {
      case ESW_QUOTE_MAINT_FULL_TCS:
      case ESW_QUOTE_ON_PREM_FULL_TCS:
      case ESW_QUOTE_SAAS_FULL_TCS:
      case ESW_QUOTE_PS_FULL_TCS:
        return "FullTCs";
      case ENG_NEW_RESELLERS_QUOTE:
        return "Reseller";
      case ESW_QUOTE_RENEWAL_NO_TC_ATTACHMENTS:
        return "NoTCs";
      default:
        return "Other";
    }
  }

  // spec: https://trilogy-confluence.atlassian.net/wiki/spaces/CentralFinance/pages/369725149/2a.+How+to+prepare+a+quote
  // spec: under How to generate Agreements for signature
  getTermsAndConditionsForQuote(quoteForm: number): TcKeys[] {
    const res: TcKeys[] = [];
    switch (quoteForm) {
      case ESW_QUOTE_MAINT_FULL_TCS:
        res.push(TcKeys.Maintenance);
        break;
      case ESW_QUOTE_ON_PREM_FULL_TCS:
        res.push(TcKeys.OnPremise);
        break;
      case ESW_QUOTE_SAAS_FULL_TCS:
        res.push(TcKeys.Saas);
        break;
      case ESW_QUOTE_PS_FULL_TCS:
        res.push(TcKeys.ProfessionalServices);
        break;
      default:
        // other revenue types will not have TC attached
        break;
    }
    nsutils.logMayBe('getTermsAndConditionsForQuote res', res);
    return res;
  }

  getTcTemplateFileId(key: TcKeys): number | undefined {
    nsutils.logMayBe('getTcTemplateFileId params', { key });
    const mappingId = quoteDao.findTcMapping(key);
    if (mappingId) {
      const mappingRec = record.load({
        type: 'customrecord_quote_tcs_mapping',
        id: mappingId!,
      });

      const fileId = mappingRec.getValue('custrecord_quote_tcs_mapping_file') as number;
      nsutils.logMayBe('getTcTemplateFileId res', fileId);
      return fileId;
    }
    return undefined;
  }

  addTermsAndConditions(tcKeys: TcKeys[], echosignAgreementId: number, files: file.File[]) {
    nsutils.logMayBe('addTermsAndConditions params', { tcKeys, echosignAgreementId, files });

    const tcFileIds = tcKeys
      .map((k) => this.getTcTemplateFileId(k))
      .filter((fId) => !!fId)
      .map((fId) => fId!);

    nsutils.logMayBe('addTermsAndConditions tcFileIds', tcFileIds);

    tcFileIds.forEach((tcFileId) => {
      this.createAdobeAgreementDoc(echosignAgreementId, tcFileId);

      // Add the terms and conditions file only if it is set for the product integration
      files.push(file.load({ id: tcFileId }));
    });

    return files;
  }

  private createAdobeAgreementDoc(agreementId: number, fileId: number): number {
    const doc = record.create({
      type: 'customrecord_echosign_document',
    });
    doc.setValue({ fieldId: 'custrecord_echosign_agreement', value: agreementId });
    doc.setValue({
      fieldId: 'custrecord_echosign_file',
      value: fileId,
    });
    return doc.save();
  }

  /**
   * Send first agreement in the quote for signature
   */
  sendForSignature(quoteId: number, subsidiaryId: number, recipients: { acceptor: AcceptQuoteParty; ccEmail?: string }): number {
    const agInfo = quoteDao.findLastAdobeAgreementInfo(quoteId);
    const existingRecipients = quoteDao.findAdobeAgreementRecipients(agInfo.id);
    if (existingRecipients.length > 0) {
      throw new Error(`Failed to send agreement to signature: Agreement can't have recipients or adobe can't send to customer signer first.`);
    }
    const recipientList = [{ email: must(recipients.acceptor.email), role: 'signer' }];
    if (recipients.ccEmail) {
      recipientList.push({ email: recipients.ccEmail, role: 'cc' });
    }
    this.addRecipients(agInfo.id, subsidiaryId, AgreementType.Quote, quoteId, recipientList);
    this.sendAgreementForSignature(agInfo.id);
    return agInfo.id;
  }

  sendAgreementForSignature(agreementId) {
    const suiteletURL = AdobeESignService.resolveManagerSuitelet({
      echoaction: 'sendDocument',
      recid: `${agreementId}`,
      senderid: `${runtime.getCurrentUser().id}`,
    });
    nsutils.logMayBe('sendForSignature url', suiteletURL);
    const res = https.get({
      url: suiteletURL,
    });
    if (res.code !== HttpStatusCode.OK || !JSON.parse(res.body)?.success) {
      throw new Error(`Failed to send agreement to signature: ${res.body}`);
    }
  }

  deleteQuote(quoteId: number) {
    const agreements = quoteDao.getAdobeAgreements(quoteId);
    for (const agreement of agreements) {
      switch (agreement.status) {
        case 'Draft':
        case 'Not Yet Sent For Signature':
          record.delete({ type: 'customrecord_echosign_agreement', id: agreement.id });
          break;
        case 'Out For Signature':
          this.cancelAgreement(agreement.id);
          break;
        default:
          // other statuses not necessary to do anything
          break;
      }
    }
    record.delete({ type: record.Type.ESTIMATE, id: quoteId });
  }

  public cancelAgreement(agreementId: number) {
    const suiteletURL = AdobeESignService.resolveManagerSuitelet({
      echoaction: 'cancelAgreement',
      recid: `${agreementId}`,
      senderid: `${runtime.getCurrentUser().id}`,
    });
    nsutils.logMayBe('cancelAgreement url', suiteletURL);
    const res = https.get({
      url: suiteletURL,
    });
    if (res.code !== HttpStatusCode.OK || !JSON.parse(res.body)?.success) {
      throw new Error(`Failed to cancel agreement ${agreementId} that was sent out for signature`);
    }
  }

  public createEUA(quoteId: number): number {
    const quote = QuoteRecord.load(quoteId);

    const tcKeys: TcKeys[] = [];
    try {
      if (quote.subscriptionPlanId) {
        const subscriptionPlan = SubscriptionPlanUtility.getSubscriptionPlanById(quote.subscriptionPlanId, true);
        if (subscriptionPlan.supportOnly) {
          tcKeys.push(TcKeys.EUA_Maintenance);
        }
      }
    } catch (e) {
      nsutils.logDebug('createEUA error', `Error while loading subscription and plan for quote ${quoteId} to check if it's support to include or not the maintenance TCs to the EUA.
Error: ${e}`);
    }

    const recipients: {
      email: string;
      role: string;
    }[] = [];
    const agreementId = quoteDao.findLastAgreementIdByType(quoteId, AgreementType.Quote);
    if (agreementId) {
      let quoteRecipients = quoteDao.findAdobeAgreementRecipients(agreementId);
      // Removing the service provider (second signer or first cc), either case the order is 2
      // If the agreement is manually created and the order is not the same, we may remove the wrong recipient
      quoteRecipients = quoteRecipients.filter(i => i.order !== 2);
      // filter out o2c email as it's automatically added to all agreements, so, removing to not be added twice
      quoteRecipients = quoteRecipients.filter(i => i.email !== this.getO2CEmail());

      // Cloning all recipients from quote and adding only the first signer, just in case to not add service provider as signer if out of order
      let signerAdded = false;
      for (const recipient of quoteRecipients) {
        if (recipient.role === AgreementRecipientType.Signer && !signerAdded) {
          recipients.push({ email: recipient.email, role: 'signer' });
          signerAdded = true;
        } else {
          recipients.push({ email: recipient.email, role: 'cc' });
        }
      }
    }

    return this.createAdobeServicesAgreement(quoteId, tcKeys, true, AgreementType.EndUserAcknowledgement, recipients);
  }
}

export default new QuoteService();
