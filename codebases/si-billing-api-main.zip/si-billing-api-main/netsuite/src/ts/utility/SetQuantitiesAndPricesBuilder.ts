import SubscriptionItemUtility from './SubscriptionItemUtility';
import * as nsutils from '../nsutils';
import { DynamicSublistWrapper } from '../models/DynamicSublistWrapper';
import { ItemType, LineType, SubscriptionLineStatus, SupportLevel } from '../types';
import { must } from '../validation';
import SubscriptionPriceUtility from './SubscriptionPriceUtility';
import { SubscriptionPlan } from '../models/SubscriptionPlan';

export class SetQuantitiesAndPricesBuilder {
  readonly itemsToUpdate: {
    code: string;
    itemType: ItemType;
    supportLevel?: SupportLevel;
    line: number;
    pricePlan: number;
  }[] = [];
  constructor(
    private readonly plan: SubscriptionPlan,
    private readonly discounts,
    private readonly items,
    private readonly skipActivation: boolean,
    private readonly trial: boolean
  ) {}

  private getDiscountToApply(itemId) {
    const addonDiscount = this.discounts.addons.find((i) => i.id === itemId);
    let discountToApply = addonDiscount ? addonDiscount.discount : this.discounts.mainItemDiscount;
    //trial subscription has 0 prices, that means will be applied 100% discount
    if (this.trial) {
      discountToApply = 1;
    }
    const freeAddonQuantity = addonDiscount && addonDiscount.freeQuantity ? addonDiscount.freeQuantity : 0;
    return { discountToApply, freeAddonQuantity }
  }

  setPricing(subPricing: DynamicSublistWrapper, subLine: DynamicSublistWrapper) {
    nsutils.logMayBe('setPricing params', { subPricing, subLine });
    const itemId = parseInt(must(subPricing.getFieldValue('item')).toString());
    const item = SubscriptionItemUtility.findItemForLine(itemId, this.plan, this.items);
    const { discountToApply, freeAddonQuantity } = this.getDiscountToApply(item?.id);
    nsutils.logMayBe('setPricing vars', {
      itemId,
      discountToApply,
      freeAddonQuantity,
      item,
    });
    const newPricePlan =
      freeAddonQuantity > 0 && item && item.quantity > freeAddonQuantity
        ? SubscriptionPriceUtility.createNewPricePlan(
            subPricing.getFieldValue('priceplan') as number,
            this.discounts.mainItemDiscount,
            freeAddonQuantity
          )
        : SubscriptionPriceUtility.applyDiscount(discountToApply, subPricing.getFieldValue('priceplan'));
    nsutils.logMayBe('setPricing newPricePlan', newPricePlan);

    if (newPricePlan) {
      subPricing.setFieldValue('priceplan', newPricePlan);
      if (!item) {
        subPricing.commit();
      }
    }

    nsutils.logMayBe('setPricing sub.create', 'check p item ' + itemId);
    if (item) {
      this.doSetPricingForItem(item, subPricing, subLine);
    }
  }

  private doSetPricingForItem(item, subPricing: DynamicSublistWrapper, subLine: DynamicSublistWrapper) {
    nsutils.logMayBe('setQuantitiesAndPrices sub.create', 'Set quantity ' + item.quantity);
    if (subPricing.getFieldValue('status') === SubscriptionLineStatus.PENDING_ACTIVATION) {
      // temporary update status to DRAFT to update quantities
      subPricing.setFieldValue('status', SubscriptionLineStatus.DRAFT);
      subLine.setFieldValue('status', SubscriptionLineStatus.DRAFT);
    }
    SubscriptionItemUtility.updateItemsToUpdate(subPricing, this.plan.items, this.itemsToUpdate);
    nsutils.logMayBe('setQuantitiesAndPrices priceplan', subPricing.getFieldValue('priceplan'));
    const lineType = LineType[subPricing.getFieldText('chargetype')];

    if (lineType === LineType.Usage) {
      subLine.setFieldValue('isincluded', true);
    } else if (item.quantity > 0) {
      subPricing.setFieldValue('quantity', item.quantity);
      subLine.setFieldValue('isincluded', true);
    }

    subPricing.commit();
    if (!this.skipActivation) {
      subLine.setFieldValue('status', SubscriptionLineStatus.PENDING_ACTIVATION);
    }
    subLine.commit();
  }
}
