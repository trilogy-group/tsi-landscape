import * as nsutils from '../nsutils';
import * as record from 'N/record';
import { DynamicSublistWrapper } from '../models/DynamicSublistWrapper';
import { SubscriptionConfiguration, SubscriptionUpdateParams } from '../models/SubscriptionParams';
import { assertNotNull, must } from '../validation';
import { BillingSchedule } from '../types';
import subscriptionDao, { SubscriptionStatusChangeReason } from '../dao/SubscriptionDao';
import subscriptionPlanDao from '../dao/SubscriptionPlanDao';
import subscriptionItemUtility from './SubscriptionItemUtility';
import subscriptionPriceUtility from './SubscriptionPriceUtility';

export class SubscriptionChangeOrderUtility {
  public createChangeOrder(subscriptionId: number, action: string, subConf: SubscriptionConfiguration) {
    nsutils.logMayBe('createChangeOrder params', { subscriptionId: subscriptionId, action: action, subConf: subConf });
    const changeOrder = record.create({
      type: record.Type.SUBSCRIPTION_CHANGE_ORDER,
      isDynamic: true,
      defaultValues: {
        action: action,
        subscription: subscriptionId,
      },
    });
    if (subConf.effectiveDate) {
      changeOrder.setValue('effectivedate', new Date(subConf.effectiveDate));
    }
    const subLines = new DynamicSublistWrapper(changeOrder, 'subline');
    const items = must(subConf.items, 'items');
    nsutils.logMayBe('createChangeOrder created', { changeOrder: changeOrder, subLines: subLines, items: items });
    return { changeOrder, subLines, items };
  }

  public createActivationChangeOrder(subscriptionId: number, subscriptionStartDate): record.Record {
    nsutils.logMayBe('createActivationChangeOrder params', {
      subscriptionId: subscriptionId,
      subscriptionStartDate: subscriptionStartDate,
    });
    const changeOrder = record.create({
      type: record.Type.SUBSCRIPTION_CHANGE_ORDER,
      isDynamic: true,
      defaultValues: {
        action: 'ACTIVATE',
        subscription: subscriptionId,
      },
    });
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    if (subscriptionStartDate && subscriptionStartDate !== today) {
      changeOrder.setValue('effectivedate', subscriptionStartDate);
    }
    changeOrder.setValue({ fieldId: 'custrecord_st_change_reason', value: SubscriptionStatusChangeReason.CUSTOMER_ACTIVATED });

    const subLines = new DynamicSublistWrapper(changeOrder, 'subline');
    nsutils.logMayBe('createActivationChangeOrder subLines', subLines);

    while (subLines.nextLine()) {
      if (subLines.getFieldValue('status') === 'PENDING_ACTIVATION') {
        subLines.setFieldValue('apply', true);
        subLines.commit();
        nsutils.logMayBe('createActivationChangeOrder subLines commit', subLines.lineNumber());
      }
    }

    nsutils.logMayBe('createActivationChangeOrder changeOrder', changeOrder);
    return changeOrder;
  }

  public terminateSubscriptionChangeOrder(subscriptionId: number, date?: Date, itemCodes?: string[], customerAction?:boolean) {
    const changeOrder = record.create({
      type: record.Type.SUBSCRIPTION_CHANGE_ORDER,
      isDynamic: true,
      defaultValues: {
        action: 'TERMINATE',
        subscription: subscriptionId,
      },
    });
    changeOrder.setValue({ fieldId: 'terminateatstartofday', value: true });
    changeOrder.setValue({ fieldId: 'custrecord_st_change_reason', value: customerAction ? SubscriptionStatusChangeReason.CUSTOMER_CANCELLED : SubscriptionStatusChangeReason.INVALID_SUBSCRIPTION });
    if (date) {
      changeOrder.setValue({ fieldId: 'effectivedate', value: date });
    }
    const subLines = new DynamicSublistWrapper(changeOrder, 'subline');
    nsutils.logMayBe('terminateSubscriptionChangeOrder subLines', subLines);
    while (subLines.nextLine()) {
      if (itemCodes && !itemCodes.find((x) => x === subLines.getFieldValue('itemdisplay'))) continue;
      if (subLines.getFieldValue('status') === 'ACTIVE') {
        subLines.setFieldValue('apply', true);
        subLines.commit();
      }
    }
    return changeOrder;
  }

  public createRenewChangeOrder(subscriptionId, values): record.Record {
    assertNotNull(subscriptionId, 'subscriptionId');
    const changeOrder = record.create({
      type: record.Type.SUBSCRIPTION_CHANGE_ORDER,
      isDynamic: true,
      defaultValues: {
        action: 'RENEW',
        subscription: subscriptionId,
      },
    });
    nsutils.setRecordValues(changeOrder, values);
    changeOrder.save();
    return changeOrder;
  }

  public createReplacementRenewChangeOrder(
    params: SubscriptionUpdateParams,
    subscriptionToReplace: record.Record
  ): record.Record {
    const parentSubscriptionId =
      subscriptionToReplace.getValue('parentsubscription') ||
      subscriptionToReplace.getValue('custrecord_parent_subscription');
    const values = {
      renewalmethod: 'CREATE_NEW_SUBSCRIPTION',
      renewalplan: params.content?.planId,
      renewalpricebook: params.content?.priceBookId,
      renewalterm: subscriptionToReplace.getValue('defaultrenewalterm'),
      subscriptiontermduration: subscriptionToReplace.getValue('initialtermduration'),
      subscriptiontermtype: subscriptionToReplace.getValue('initialtermtype'),
      subscriptiontermunits: subscriptionToReplace.getValue('initialtermunits'),
    };
    return this.createRenewChangeOrder(parentSubscriptionId, values);
  }

  public getSubscriptionIdFromRenewChangeOrder(changeOrder) {
    // it's necessary to load the record to load the renewalsteps with the new subscriptionId
    changeOrder = record.load({
      type: record.Type.SUBSCRIPTION_CHANGE_ORDER,
      id: changeOrder.getValue('id'),
    });
    return changeOrder.getSublistValue('renewalsteps', 'subscription', 0) as number;
  }
}

export default new SubscriptionChangeOrderUtility();
