import * as nsutils from '../nsutils';
import * as record from 'N/record';
import { Any, BillingSchedule, RenewalMethod, SubscriptionTermType, TermUnit } from '../types';
import { assertNotNull, assertNotNullMsg, isNotNull, must } from '../validation';
import { DynamicSublistWrapper } from '../models/DynamicSublistWrapper';
import { AddonDiscount, SubscriptionCreateParams } from '../models/SubscriptionParams';
import customerDao from '../dao/CustomerDao';
import entityDao, { EntityType } from '../dao/EntityDao';
import subscriptionDao from '../dao/SubscriptionDao';
import customerService from '../CustomerService';
import billingAccountUtility from './BillingAccountUtility';
import subscriptionChangeOrderUtility from './SubscriptionChangeOrderUtility';
import subscriptionGetUtility from './SubscriptionGetUtility';
import subscriptionItemUtility from './SubscriptionItemUtility';
import subscriptionValidateUtility from './SubscriptionValidateUtility';
import { TermDuration } from '../models/TermDuration';
import termUtility from './TermUtility';
import { SubscriptionUpdateNamePattern } from '../models/SubscriptionRecord';
import { SetQuantitiesAndPricesBuilder } from './SetQuantitiesAndPricesBuilder';
import subscriptionPlanUtility from './SubscriptionPlanUtility';
import { SubscriptionPlan } from '../models/SubscriptionPlan';
import ClassDao from '../dao/ClassDao';

export class SubscriptionCreateUtility {
  private fillSubscriptionForCreate(
    subscriptionRec: record.Record,
    params: SubscriptionCreateParams,
    opts: {
      previousSubscriptionId?: number;
      trial: boolean;
      discounts: { mainItemDiscount: number; addons: AddonDiscount[] };
      activate?: boolean;
      initialTermId?: number;
      parentSubscriptionId?: number;
    },
    subscriptionPlan: SubscriptionPlan
  ): record.Record {
    nsutils.logMayBe('fillSubscriptionForCreate params', {
      subscriptionRec: subscriptionRec,
      params: params,
      opts: opts,
    });
    assertNotNull(params.customerId, 'customerId');
    assertNotNull(params.content?.planClass, 'planClass');
    assertNotNull(params.content?.items, 'items');
    const sub = new nsutils.RecWrapper(subscriptionRec);
    nsutils.logMayBe('fillSubscriptionForCreate sub init', sub);
    const subsidiary = this.findSuitableSubsidiary(
      params.customerId,
      params.content.planClass,
      opts.previousSubscriptionId || opts.parentSubscriptionId
    );
    nsutils.logMayBe('fillSubscriptionForCreate subsidiary', subsidiary);
    customerService.addSubsidiary(params.customerId, subsidiary);

    const custAndBa = billingAccountUtility.getCustomerAndBA({
      customerId: params.customerId,
      frequency: must(params.content.frequency, 'frequency') as BillingSchedule,
      classId: params.content.planClass,
      effectiveDate: params.content.effectiveDate,
      subsidiaryId: subsidiary,
    });

    if (!opts.trial) {
      customerService.updateCustomerStatus(
        custAndBa.customerId,
        entityDao.getEntityStatusKey(EntityType.CUSTOMER, 'Closed-Won')
      );
    }

    sub.setIfDef('customer', custAndBa.customerId);
    sub.setIfDef('custrecord_subs_end_user', params.content.endUserInternalId ?? custAndBa.customerId);
    sub.setIfDef('custrecord_subs_reseller', customerDao.getInternalId(params.content.resellerId, 'resellerId'));
    sub.setIfDef(
      'custrecord_subs_distributor',
      customerDao.getInternalId(params.content.distributorId, 'distributorId')
    );
    sub.setIfDef('billingaccount', custAndBa.billingAccountId);
    if (params.content.effectiveDate) {
      sub.setIfDef('startdate', new Date(params.content.effectiveDate));
    }

    sub.setIfDef('subscriptionplan', params.content.planId);
    sub.setIfDef('pricebook', params.content.priceBookId);
    sub.setIfDef('initialterm', opts.initialTermId);
    sub.setIfDef('custrecord_istrial', opts.trial);
    sub.setIfDef('custrecord_parent_subscription', opts.parentSubscriptionId);

    this.fillContractualDocuments(subscriptionRec, sub, params.content.contractualDocumentId);

    // the initial term must be set after the subscription plan, because when the subscription plan is set, it sets the initial term automatically
    if (opts.trial) {
      termUtility.setInitialTermForTrialSubscription(params.content.trialDuration, subscriptionRec, sub);
    } else if (isNotNull(params.content.duration)) {
      termUtility.setInitialTermForNewSubscription(new TermDuration(params.content.duration, TermUnit.MONTHS), sub);
    }
    // auto renewal must be set after the term is set
    this.setAutoRenewal(sub.rec, params.content?.renewalDaysBeforeEndDate);
    this.setQuantitiesAndPrices(
      subscriptionRec,
      params.content.items,
      opts.discounts,
      subscriptionPlan,
      opts.trial,
      !opts.activate
    );
    nsutils.logMayBe('fillSubscriptionForCreate subscriptionRec', subscriptionRec);
    return subscriptionRec;
  }

  public setAutoRenewal(subscription: record.Record, renewalDays?: number) {
    const termType = SubscriptionTermType[subscription.getValue('initialtermtype') as string];

    /* Evergreen subscriptions are not auto renewed */
    if (termType === SubscriptionTermType.EVERGREEN) {
      subscription.setValue('autorenewal', false);
      return;
    }

    subscription.setValue('autorenewal', true);
    subscription.setValue('defaultrenewalmethod', RenewalMethod.CREATE_NEW_SUBSCRIPTION);
    const termId = subscription.getValue('initialterm') as number;
    subscription.setValue('defaultrenewalterm', termId);
    if (!renewalDays) {
      const startDate = new Date(subscription.getValue('startdate') as string);
      const endDate = new Date(subscription.getValue('enddate') as string);
      // Less than 4 days before renewal causes a NetSuite error on some edge cases (e.g. 18 months term)
      const renewalPeriodInDays = 3;
      renewalDays = nsutils.diffDateInDays(endDate, startDate) - renewalPeriodInDays;
    }
    subscription.setValue('advancerenewalperiodnumber', renewalDays);
    subscription.setValue('advancerenewalperiodunit', 'DAYS');
  }

  private getSubsidiaryFromClass(customerId: string, classId: number): number | null {
    const billing = customerDao.getCustomerBillingCountry(customerId);
    nsutils.logMayBe('findSuitableSubsidiary billing', billing);
    const classSubsidiaries = ClassDao.getSubsidiaries(classId);
    nsutils.logMayBe('findSuitableSubsidiary classSubsidiaries', classSubsidiaries);

    let subsidiaryId: number | null;
    switch (billing.country) {
      //United States
      case 'US':
        subsidiaryId = classSubsidiaries.domestic;
        break;
      //United Arab Emirates
      case 'AE':
        subsidiaryId =
          !billing.addr1 || billing.addr1.toLowerCase().indexOf('free zone') === -1
            ? classSubsidiaries.domestic
            : classSubsidiaries.other;
        break;
      //Germany
      case 'DE':
      //Austria ----- fallsthrough
      case 'AT':
        subsidiaryId = classSubsidiaries.german ?? classSubsidiaries.other;
        break;
      case 'JP':
        subsidiaryId = classSubsidiaries.japan ?? classSubsidiaries.other;
        break;
      default:
        subsidiaryId = classSubsidiaries.other;
        break;
    }
    return subsidiaryId;
  }

  public findSuitableSubsidiary(customerId: string, classId: number, previousSubscriptionId?: number): number {
    //check if customer have a override subsidiary
    let subsidiaryId: number | undefined | null = customerDao.findSubsidiaryOverrideForClass(customerId, classId);
    if (subsidiaryId) {
      return subsidiaryId;
    }

    //check if a subsidiary is defined as contracting entity at class level
    subsidiaryId = this.getSubsidiaryFromClass(customerId, classId);
    if (subsidiaryId) {
      return subsidiaryId;
    }

    // if subsidiaryId couldn't be found, we are going to use the same from parent
    if (isNotNull(previousSubscriptionId)) {
      subsidiaryId = subscriptionDao.findSubsidiaryId(previousSubscriptionId);
      if (subsidiaryId) {
        return subsidiaryId;
      }
    }

    throw new Error('Unable to find suitable subsidiary');
  }

  private setQuantitiesAndPrices(
    subscriptionRec: record.Record,
    items,
    discounts,
    subscriptionPlan: SubscriptionPlan,
    trial: boolean,
    skipActivation: boolean = false
  ) {
    nsutils.logMayBe('setQuantitiesAndPrices params', {
      subscriptionRec,
      items,
      discounts,
      skipActivation,
      subscriptionPlan,
      trial,
    });
    // include and set quantities for item
    const itemIds = subscriptionItemUtility.getSubItemIds(subscriptionRec).map((i) => i.id);
    const subPricing = new DynamicSublistWrapper(subscriptionRec, 'priceinterval');
    const subLine = new DynamicSublistWrapper(subscriptionRec, 'subscriptionline');
    nsutils.logMayBe('setQuantitiesAndPrices vars', {
      itemIds,
      subPricing,
    });

    const setQuantitiesAndPricesBuilder = new SetQuantitiesAndPricesBuilder(
      subscriptionPlan,
      discounts,
      items,
      skipActivation,
      trial
    );

    while (subPricing.nextLine() && subLine.nextLine()) {
      setQuantitiesAndPricesBuilder.setPricing(subPricing, subLine);
    }

    nsutils.logMayBe('setQuantitiesAndPrices subPricing itemsToUpdate', {
      subPricing: subPricing,
      itemsToUpdate: setQuantitiesAndPricesBuilder.itemsToUpdate,
    });
  }

  private terminateTrialSubscription(customerId: string, productFamilyCode: string, productVariantCode?: string): void {
    const customerEntityStatusKey = customerDao.getEntityStatus(customerId);
    const prospectKey = entityDao.getEntityStatusKey(EntityType.CUSTOMER, 'Prospect');
    // check if customer has Prospect status and terminate his subscriptions
    if (prospectKey === customerEntityStatusKey) {
      const customerSubscriptionIds = subscriptionDao.getCustomerSubscriptionIds(customerId, {
        productFamilyCode: productFamilyCode,
        productVariantCode: productVariantCode,
        statuses: ['ACTIVE'],
      });
      for (const subscriptionId of customerSubscriptionIds) {
        const terminateOrder = subscriptionChangeOrderUtility.terminateSubscriptionChangeOrder(subscriptionId.id, undefined, undefined, true);
        terminateOrder.save();
      }
    }
  }

  private needScheduleActivation(subscriptionRec, trial: boolean, activate: boolean) {
    return activate || trial;
  }

  public createSubscription(
    params: SubscriptionCreateParams,
    opts: {
      previousSubscriptionId?: number;
      trial: boolean;
      discounts: { mainItemDiscount: number; addons: AddonDiscount[] };
      activate?: boolean;
      subscriptionPlanDisplayName?: string;
      initialTermId?: number;
      parentSubscriptionId?: number;
    }
  ) {
    nsutils.logMayBe('createSubscription params', params);
    nsutils.logMayBe('createSubscription opts', opts);
    subscriptionValidateUtility.validateAndPrepareCreateData(params);
    nsutils.logMayBe('createSubscription validated and prepared params', params);

    const subscriptionPlan = subscriptionPlanUtility.getSubscriptionPlanById(must(params.content?.planId));
    subscriptionPlanUtility.addSupportPricesToItems(subscriptionPlan);

    let subscriptionRec = record.create({
      type: record.Type.SUBSCRIPTION,
      isDynamic: true,
    });
    if (opts.previousSubscriptionId) {
      subscriptionRec.setValue({
        fieldId: 'name',
        value: SubscriptionUpdateNamePattern.generateName(
          must(opts.subscriptionPlanDisplayName, 'subscriptionPlanDisplayName'),
          opts.previousSubscriptionId
        ),
      });
    }

    // skip activation if directly stated or if it is not not evergreen and not trial
    opts.activate = this.needScheduleActivation(subscriptionRec, opts.trial, opts.activate ?? false);

    subscriptionRec = this.fillSubscriptionForCreate(subscriptionRec, params, opts, subscriptionPlan);
    let sId: number;
    if (opts.activate) {
      sId = this.saveAndActivate(subscriptionRec, params.activationDate);
    } else {
      sId = subscriptionRec.save();
    }
    const oneSecond = 1000;
    nsutils.delay(oneSecond);
    const subscription = subscriptionGetUtility.getSubscriptionByIdForCustomer(
      sId,
      must(params.customerId, 'customerId')
    );
    nsutils.logMayBe('createSubscription subscription', subscription);
    return subscription;
  }

  /**
   * this method is being used only by internal methods and is basically used by e2e tests
   */
  public saveAndActivate(subscriptionRec: record.Record, activationDate?: Date): number {
    nsutils.logMayBe('saveAndActivate params', { subscriptionRec, activationDate });

    const sId = subscriptionRec.save();
    nsutils.logMayBe('saveAndActivate subscription saved', sId);
    const activateCo = subscriptionChangeOrderUtility.createActivationChangeOrder(
      sId,
      activationDate ? activationDate : subscriptionRec.getValue('startdate')
    );
    activateCo.save();
    nsutils.logMayBe('saveAndActivate subscription activated', activateCo);
    return sId;
  }

  private fillContractualDocuments(
    subscriptionRec: record.Record,
    sub: nsutils.RecWrapper,
    contractualDocumentId?: number
  ) {
    if (contractualDocumentId) {
      const currentContractualDocumentId = subscriptionRec.getValue('custrecord_contract_docs');

      if (!currentContractualDocumentId) {
        sub.setIfDef('custrecord_contract_docs', contractualDocumentId);
      }
    }
  }
}

export default new SubscriptionCreateUtility();
