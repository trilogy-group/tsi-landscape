import * as nsutils from '../nsutils';
import * as record from 'N/record';
import { GetRenewalInfoParams } from "../models/SubscriptionParams";
import subscriptionGetUtility from "./SubscriptionGetUtility";
import subscriptionValidateUtility from "./SubscriptionValidateUtility";
import subscriptionPlanUtility, { PlanCode } from './SubscriptionPlanUtility';
import { NotFoundError, ValidationError } from '../validation';
import subscriptionPlanDao from '../dao/SubscriptionPlanDao';
import { ItemCode } from './SubscriptionItemUtility';
import { ApiSubscription } from '../models/apitypes';
import { ProductTier, SupportLevel } from '../types';
import { SubscriptionIncludedItem, SubscriptionPlan } from '../models/SubscriptionPlan';

interface RenewalInfo {
  plan: {
    code: string,
    description: string,
    name?: string
  },
  items: SubscriptionIncludedItem[]
}

export class SubscriptionGetRenewalInfoUtility {
  private getRenewalPlan(activeSubscription: ApiSubscription, productTier: ProductTier,
    supportLevel: SupportLevel): SubscriptionPlan {
    // loading the active subscription plan to get the default renewal plan
    const activeSubscriptionPlan = record.load({
      type: record.Type.SUBSCRIPTION_PLAN, 
      id: activeSubscription.plan.id 
    });
    let defaultRenewalPlanId = activeSubscriptionPlan.getValue('defaultrenewalplan');
    const activeSubscriptionPlanCode = new PlanCode(activeSubscriptionPlan.getValue('displayname') as string);
    // if we don't have a default renewal plan and also the active subscription plan is legacy and it's not a valid
    // format, failing because we can't get the family and variant to search the new renewal plan
    if (!defaultRenewalPlanId && activeSubscription.plan.isLegacy && !activeSubscriptionPlanCode.isValid) {
      nsutils.sendEmail(['tsi@trilogy.com'],`Error getting renewal info for subscription ${activeSubscription.id}`,
      `Renewal plan is not defined for plan ${activeSubscription.plan.id} - ${activeSubscription.plan.code}`);
      throw new NotFoundError('Renewal plan is not defined');
    }
    // if we don't have a default renewal plan, we'll use the active subscription plan as the renewal plan
    const defaultRenewalPlan = defaultRenewalPlanId ? 
      record.load({ type: record.Type.SUBSCRIPTION_PLAN, id: defaultRenewalPlanId }) : activeSubscriptionPlan;
    defaultRenewalPlanId = parseInt(defaultRenewalPlan.getValue('id') as string);
    const planCode = defaultRenewalPlan.getValue('displayname') as string;
    const planCodeObj = new PlanCode(planCode);
    // the renewal plan code must be valid to get the family and variant from the code
    if (!planCodeObj.isValid) {
      nsutils.sendEmail(['tsi@trilogy.com'],`Error getting renewal info for subscription ${activeSubscription.id}`,
      `Renewal plan is invalid: ${defaultRenewalPlanId} - ${planCode}`);
      throw new ValidationError('Renewal plan is invalid');
    }

    const renewalSubscriptionPlanId = subscriptionPlanDao.getLatestSubscriptionPlan(
      planCodeObj.productFamilyCode, planCodeObj.productVariantCode, productTier, supportLevel, planCodeObj.isSupport
    )?.id;
    // if empty, it means doesn't exist a plan for the given product tier and support level
    if (!renewalSubscriptionPlanId) {
      nsutils.sendEmail(['tsi@trilogy.com'],`Error getting renewal info for subscription ${activeSubscription.id}`,
      `Renewal plan not found for  ${planCode} with ${productTier} and ${supportLevel}`);
      throw new NotFoundError(
        `Renewal plan not found for ${planCode} with ${productTier} and ${supportLevel}`
      );
    }

    return subscriptionPlanUtility.getSubscriptionPlanById(renewalSubscriptionPlanId);
  }

  private getRenewalItem(activeItem: SubscriptionIncludedItem, activeSubscription: ApiSubscription,
    renewalPlan: SubscriptionPlan, renewalItems): {
      item: SubscriptionIncludedItem,
      current: {
        isMainItem: boolean,
        required: boolean
      }
      new: {
        isMainItem: boolean,
        required: boolean
      }
    } {
    const renewalItem = renewalItems.find((i) => i.id === activeItem.id);
    // if no renewal item, use the same item code
    const itemCode = renewalItem?.renewCode ?? activeItem.code;
    const itemCodeObj = new ItemCode(itemCode);
    const renewalCode = itemCodeObj.getCodeWithNewSuffix(renewalPlan.productTier, renewalPlan.supportLevel);
    const renewalPlanItem = renewalPlan.items.find((i) => i.code === renewalCode);
    if (!renewalPlanItem) {
      nsutils.sendEmail(['tsi@trilogy.com'],`Error getting renewal info for subscription ${activeSubscription.id}`,
      `Renewal plan ${renewalPlan.id} - ${renewalPlan.code} does not contain item ${renewalCode}
Item on Active subscription: ${activeItem.id} - ${activeItem.code}`);
      throw new NotFoundError(`Renewal plan ${renewalPlan.code} does not contain item ${renewalCode}`);
    }
    const item = activeSubscription.items.find((i) => i.id === activeItem.id);

    // Consider the main item as the main or support main item depending on the renewal plan.
    return {
      item: {
        code: renewalCode,
        quantity: activeItem.quantity
      },
      current: {
        isMainItem: (renewalPlan.supportOnly ? item?.isSupportMainItem : item?.isMainItem) ?? false,
        required: item?.required ?? false
      },
      new: {
        isMainItem: renewalPlan.supportOnly ? renewalPlanItem.isSupportMainItem : renewalPlanItem.isMainItem,
        required: renewalPlanItem.required
      }
    };
  }

  private getRenewalItems(activeSubscription: ApiSubscription, renewalPlan: SubscriptionPlan,
    renewalItems): SubscriptionIncludedItem[] {
    const items: SubscriptionIncludedItem[] = [];
    const addonsIncluded: string[] = [];
    let mainItemIncluded = false;
    for (const includedItem of activeSubscription.includedItems) {
      const renewalItem = this.getRenewalItem(includedItem, activeSubscription, renewalPlan, renewalItems);
      // checking that main item is not included as we don't want to include twice
      // in case of having multiple required items
      if ((renewalItem.current.isMainItem || renewalItem.current.required)
        && renewalItem.new.isMainItem && !mainItemIncluded) {
        items.push(renewalItem.item);
        mainItemIncluded = true;
        continue;
      }
      // if reached this part, it means is an addon and we skip addons pointing to the main item
      if (renewalItem.new.isMainItem) {
        continue;
      }
      if (addonsIncluded.includes(renewalItem.item.code)) {
        nsutils.sendEmail(['tsi@trilogy.com'],`Error getting renewal info for subscription ${activeSubscription.id}`,
      `Subscription ${activeSubscription.id} contains multiple items for ${renewalItem.item.code}.
Renewal plan: ${renewalPlan.id} - ${renewalPlan.code}`);
        throw new NotFoundError(`Subscription contains multiple items for ${renewalItem.item.code}`);
      }
      items.push(renewalItem.item);
      addonsIncluded.push(renewalItem.item.code);
    }
    if (!mainItemIncluded) {
      nsutils.sendEmail(['tsi@trilogy.com'],`Error getting renewal info for subscription ${activeSubscription.id}`,
      `Subscription ${activeSubscription.id} does not contain main item.
Renewal plan: ${renewalPlan.id} - ${renewalPlan.code}`);
      throw new NotFoundError(`Subscription does not contain main item`);
    }
    return items;
  }

  public getRenewalInfo(params: GetRenewalInfoParams): RenewalInfo {
    const { productTier, supportLevel } = subscriptionValidateUtility.validateRenewalInfoParams(params);
    const activeSubscription = subscriptionGetUtility.getSubscriptionByIdInternal(params.subscriptionId);
    nsutils.logMayBe('getRenewalInfo activeSubscription', activeSubscription);

    const renewalPlan = this.getRenewalPlan(activeSubscription, productTier, supportLevel);
    nsutils.logMayBe('getRenewalInfo renewalPlan', renewalPlan);

    const renewalItems = subscriptionPlanDao.getRenewalItems(activeSubscription.items.map((i) => i.id));
    nsutils.logMayBe('getRenewalInfo renewalItems', renewalItems);

    return {
      plan: {
        code: renewalPlan.code,
        description: renewalPlan.description,
        name: renewalPlan.name
      },
      items: this.getRenewalItems(activeSubscription, renewalPlan, renewalItems)
    }
  }
}

export default new SubscriptionGetRenewalInfoUtility();
