import * as nsutils from '../nsutils';
import * as record from 'N/record';
import customerDao from '../dao/CustomerDao';
import subscriptionDao from '../dao/SubscriptionDao';
import subscriptionPlanDao from '../dao/SubscriptionPlanDao';
import {
  assertListNotEmpty,
  assertNotNull,
  assertTrue,
  isNotNull,
  must,
  SubscriptionNotFoundError,
} from '../validation';
import { clone, parseIntOrNull, parseMoney, roundMoney } from './GeneralUtility';
import { Any, ChargeFrequency, ProductTierUtil, SubscriptionStatus, SupportLevelUtil, TermUnit } from '../types';
import { ApiCustomerInfo, ApiSubscription, ApiSubscriptionPlan, OperationPermission } from '../models/apitypes';
import subscriptionPlanUtility from './SubscriptionPlanUtility';
import { getParentIdFromSnapshot, SubscriptionRecord } from '../models/SubscriptionRecord';
import { PlanInfo, PriceTier, PriceTierType, SubscriptionIncludedItem, SubscriptionItem, SubscriptionItemPrice,
  SubscriptionItems, SubscriptionItemWithQuantity, SubscriptionPlan, SubscriptionPlanItem } from '../models/SubscriptionPlan';
import { ItemCode } from './SubscriptionItemUtility';
import quoteDao from '../dao/QuoteDao';

export class SubscriptionGetUtility {
  public convertLinesToArray<T>(subscriptionLines: T & { [key: string]: { linenumber: number } }): Any[] {
    const keys = Object.keys(subscriptionLines);
    const items: Array<{ linenumber: number }> = [];

    keys.forEach(function (k: string) {
      if (k.indexOf('line ') === 0) {
        items.push(subscriptionLines[k]);
      }
    });

    return items;
  }

  /*
    Update prices inside r
  */
  public addSupportPriceInsideRange(supportItem: SubscriptionItem, ranges) {
    for (const itemPriceRange of ranges) {
      const supportItemIndex = supportItem.prices[0].ranges.findIndex(
        (i) => i.fromQuantity === itemPriceRange.fromQuantity
      );
      if (supportItemIndex !== -1) {
        const supportPriceRange = supportItem.prices[0].ranges.splice(supportItemIndex, 1)[0];
        itemPriceRange.price += supportPriceRange.price;
      }
    }
  }

  /**
   * Merge prices of support items to corresponding items based on code similarity.
   * Returns clone of the 'items'. Doesn't modify arguments.
   * @param items available items
   * @param supportItems support items to get prices from. ignore if not exist
   */
  public addSupportPricesToItems(
    items: SubscriptionItem[],
    supportItems?: SubscriptionItem[]
  ): SubscriptionItem[] {
    nsutils.logMayBe('addSupportPricesToItems params', { items, supportItems });
    assertNotNull(items, 'items');
    const itemsClone = clone(items);
    const supportItemsClone = isNotNull(supportItems) ? clone(supportItems) : [];

    for (const supportItem of supportItemsClone) {
      const item = itemsClone.find((i) =>
        new ItemCode(i.code).isDifferentOnlyInSuffix(new ItemCode(supportItem.code))
      );
      if (item !== undefined) {
        item.amount = roundMoney(item.amount + supportItem.amount);
        item.recuringAmount += supportItem.recuringAmount;
        item.totalIntervalValue = roundMoney(item.totalIntervalValue + supportItem.totalIntervalValue);
        this.addSupportPriceInsideRange(supportItem, item.prices[0].ranges);
        item.prices[0].ranges = item.prices[0].ranges.concat(supportItem.prices[0].ranges);
      }
    }
    nsutils.logMayBe('addSupportPricesToItems res', { itemsClone });
    return itemsClone;
  }

  private convertPrices(
    line: { discount: string, frequency: string },
    lineFields: Array<{ priceplanid: number; pricetype: string; fromquantity: number; price: number; pricingoption }>,
    pricebookid: number
  ): SubscriptionItemPrice {

    // Parse the discount percentage or default to 0 if undefined or parsing fails.
    const discountPercentage = parseFloat(line.discount) / 100 || 0;

    // Create the price tiers by converting the line fields, and applying the discount.
    const ranges: PriceTier[] = [];
    for (const lf of lineFields) {
      ranges.push({
        priceplanid: lf.priceplanid,
        type: PriceTierType[lf.pricingoption],
        fromQuantity: lf.fromquantity,
        price: lf.price * (1 - discountPercentage),
      });
    }
    return {
      type: lineFields[0].pricetype,
      frequency: line.frequency,
      pricebookid: pricebookid,
      ranges: ranges,
    };
  }

  private buildItem(params: {
    subscriptionStatus: string;
    lineTypeDict;
    lineItem;
    priceLine;
    prices;
    pricebookid: number;
    subscrPlanItems: SubscriptionPlanItem[];
  }): SubscriptionItemWithQuantity {
    nsutils.logMayBe('buildItem params', params);
    const firstLine = params.prices[0];
    const planItem = params.subscrPlanItems.find((x) => x.code === firstLine.code);
    const supportLevel = SupportLevelUtil.nameToSupportLevel(firstLine.support_level_name);
    // If the plan item is found, retrieve values from it. Else, retrieve values from the line itself:
    // - Consider an item has a support add-on item if the item has a support level.
    const options = planItem ? {
      supportLevel: planItem.supportLevel,
      productTier: planItem.productTier,
      isMainItem: planItem.isMainItem,
      isSupportMainItem: planItem.isSupportMainItem,
      isSupportAddonItem: planItem.isSupportAddonItem
    } : {
      supportLevel: supportLevel,
      productTier: ProductTierUtil.nameToProductTier(firstLine.product_tier_name),
      isMainItem: false,
      isSupportMainItem: false,
      isSupportAddonItem: !!supportLevel
    }

    const itemType = params.lineTypeDict?.[params.lineItem.subscriptionlinetype]?.name || 'Recurring';
    const item = {
      id: parseInt(params.lineItem.item),
      code: firstLine.code,
      title: firstLine.title,
      type: itemType,
      typeId: params.lineTypeDict?.[params.lineItem.subscriptionlinetype]?.key,
      desc: firstLine.description,
      minQuantity: parseInt(firstLine.minimumquantity),
      maxQuantity: parseInt(firstLine.maximumquantity),
      required: params.lineItem.isrequired === 'T',
      prices: [this.convertPrices(params.priceLine, params.prices, params.pricebookid)],
      amount: 0,
      totalIntervalValue: parseMoney(params.priceLine.totalintervalvalue),
      recuringAmount: parseMoney(params.priceLine.recurringamount),
      frequency: params.priceLine.frequency ? ChargeFrequency[params.priceLine.frequency.toPascalCase()] : undefined,
      repeatEvery: parseInt(params.priceLine.repeatevery),
      supportLevel: options.supportLevel,
      productTier: options.productTier,
      isMainItem: options.isMainItem,
      isSupportMainItem: options.isSupportMainItem,
      isSupportAddonItem: options.isSupportAddonItem,
      quantity: itemType.toLowerCase() === 'usage' ? 0 : Math.ceil(parseFloat(params.priceLine.quantity)) || 0,
      renewItemId: firstLine.renewitemid,
      renewItemCode: firstLine.renewitemcode,
    } as SubscriptionItem;

    const isIncluded = this.includeItem(params.lineItem, params.subscriptionStatus);
    if (isIncluded) {
      item.amount = this.getPriceLineAmount(params.priceLine);
    }

    const res = {
      item,
      isIncluded,
      quantity: item.quantity,
    };
    nsutils.logMayBe('buildItem res', res);
    return res;
  }

  /**
   * Extract items and plan options from subscription in desired format.
   * availableItems -  are all items which don't have support level
   *   Special case when subscription does not have items with product tier first suitable support item will be added there,
   *   sbut it still be reported in supportItems too
   * supportItems - all items which have support level
   * includedItems - items from available items with included flag
   * mainItem - main item defined by the plan code, can be undefined
   * supportItem - main support item defined by the plan code
   *
   * @param subscription subscription object
   * @param subscriptionPlanInfo plan info
   * @returns
   */
  public buildItems(
    subscription,
    plan: SubscriptionPlan
  ): {
    // mainItem and supportItem without price merge
    subscriptionItems: SubscriptionItems;
    includedItems: SubscriptionIncludedItem[];
  } {
    nsutils.logMayBe('buildItems params', { subscription, plan });
    const lineTypeDict = nsutils.asHash(nsutils.queryToJson('select * from subscriptionlinetype', []), 'key');

    let prices = this.convertLinesToArray(subscription.sublists.priceinterval);
    let lines = this.convertLinesToArray(subscription.sublists.subscriptionline);
    nsutils.logMayBe('buildItems prices', prices);

    // set 0 total interval value for not included items
    // status doesn't exist when we are building items for preview, but in these cases we can just skip
    prices.forEach((p) => {
      if (p.status && p.status.toUpperCase() === SubscriptionStatus.NOT_INCLUDED) {
        p.totalintervalvalue = 0;
      }
    });

    ({ prices, lines } = this.fixDuplicatedItems(
      prices,
      lines,
      subscription.fields.billingsubscriptionstatus.toUpperCase()
    ));
    nsutils.logMayBe('buildItems prices 2', prices);

    nsutils.logMayBe('buildItems vars', {
      prices,
      lines,
      plan,
      lineTypeDict,
    });

    const buildItemParams: {
      subscriptionStatus: string;
      lineTypeDict;
      lineItem;
      priceLine;
      prices;
      pricebookid;
      subscrPlanItems;
    } = {
      subscriptionStatus: subscription.fields.billingsubscriptionstatus,
      lineTypeDict: lineTypeDict,
      lineItem: undefined,
      priceLine: undefined,
      prices: undefined,
      pricebookid: undefined,
      subscrPlanItems: undefined,
    };

    const items: SubscriptionItemWithQuantity[] = [];
    for (let n = 0; n < prices.length; n++) {
      const p = prices[n];
      const l = lines.find((x) => x.linenumber === p.linenumber);
      if (!l) {
        throw new Error(`Couldn't find line item with linenumber=${p.linenumber}`);
      }

      const lineFields = subscriptionDao.findPricesAndItemFields(
        parseInt(p.priceplan ?? p.priceplan_display),
        parseInt(p.item)
      );
      nsutils.logMayBeIf(!lineFields || lineFields.length === 0, 'buildItems lineFields is empty', {
        n,
        priceplan: p.priceplan,
        item: p.item,
        prices,
        lines,
      });
      assertListNotEmpty(lineFields, 'Cannot find additional line fields');

      buildItemParams.lineItem = l;
      buildItemParams.priceLine = p;
      buildItemParams.prices = lineFields;
      buildItemParams.pricebookid = parseInt(subscription.fields.pricebook);
      buildItemParams.subscrPlanItems = plan.items;

      items.push(this.buildItem(buildItemParams));
    }

    // Distribute the items after fixing single included add-on items.
    this.fixSingleIncludedAddonItems(items, plan.items);
    const result = this.distributeItems(
      items,
      plan
    );

    nsutils.logMayBe('buildItems subscriptionFields', subscription.fields);

    if (!result.subscriptionItems.mainItem && result.subscriptionItems.supportItem !== undefined) {
      result.subscriptionItems.availableItems.push(result.subscriptionItems.supportItem.item);
      result.includedItems.push({
        id: result.subscriptionItems.supportItem.item.id,
        code: result.subscriptionItems.supportItem.item.code,
        quantity: result.subscriptionItems.supportItem.quantity
      });
    }

    nsutils.logMayBe('buildItems res', {
      result
    });

    return {
      subscriptionItems: result.subscriptionItems,
      includedItems: result.includedItems
    };
  }

  /**
   * Fixes the single add-on items, i.e. if only one of both license and support add-on items is included.
   * - Aligns the quantity.
   * - Sets prices and the recurring amount to 0.
   * - Includes the non-included add-on item.
   * @param {SubscriptionItemWithQuantity[]} items The array of subscription items.
   * @param {SubscriptionPlanItem[]} planItems The subscription plan items.
   */
  private fixSingleIncludedAddonItems(items: SubscriptionItemWithQuantity[], planItems: SubscriptionPlanItem[]) {

    // Loop support add-on items.
    for (const supportAddonItem of items.filter(i => i.item.isSupportAddonItem)) {

      // Find the related license add-on item.
      const supportAddonItemCode = new ItemCode(supportAddonItem.item.code);
      let licenseAddonItem = items.find((i) =>
        new ItemCode(i.item.code).isDifferentOnlyInSuffix(supportAddonItemCode)
      );

      // If there is no related add-on item and the support add-on item is included, copy the license item from the plan.
      // Set it as non-included and continue the fixing process.
      if (!licenseAddonItem && supportAddonItem.isIncluded) {
        const licensePlanItem = planItems.find((i) =>
          new ItemCode(i.code).isDifferentOnlyInSuffix(supportAddonItemCode)
        );
        if (licensePlanItem) {
          licenseAddonItem = {
            item: {...licensePlanItem,
              amount: 0,
              quantity: supportAddonItem.quantity,
              totalIntervalValue: 0,
              recuringAmount: 0,
              frequency: supportAddonItem.item.frequency,
              repeatEvery: supportAddonItem.item.repeatEvery,
            },
            quantity: supportAddonItem.quantity,
            isIncluded: false,
          };
          items.push(licenseAddonItem);
        }
      }

      // If there is no related add-on item or if both are (non-)included, continue.
      if (!licenseAddonItem || licenseAddonItem.isIncluded === supportAddonItem.isIncluded) {
        continue;
      }

      // If only one add-on item is included, include the other one, align the quantity and set prices to 0.
      const includedItem = supportAddonItem.isIncluded ? supportAddonItem : licenseAddonItem;
      const nonIncludedItem = supportAddonItem.isIncluded ? licenseAddonItem : supportAddonItem;
      nonIncludedItem.quantity = includedItem.quantity;
      nonIncludedItem.item.prices.forEach((price) => price.ranges.forEach((range) => range.price = 0));
      nonIncludedItem.item.quantity = includedItem.quantity;
      nonIncludedItem.item.recuringAmount = 0;
      nonIncludedItem.isIncluded = true;
    }
  }

  /**
   * Distributes items among the target lists of items
   * put all non-support items to availableItems
   * put all support items to supportItems
   * put all non-support and included items to includedItems
   * select main and support items
   * @param i item
   */
  private distributeItems(
    items: SubscriptionItemWithQuantity[],
    plan: SubscriptionPlan
  ): {
    subscriptionItems: SubscriptionItems;
    includedItems: SubscriptionIncludedItem[];
  } {
    nsutils.logMayBe('distributeItems params', { items, plan });

    const availableItems: SubscriptionItem[] = [];
    const supportItems: SubscriptionItem[] = [];
    const includedItems: SubscriptionIncludedItem[] = [];
    let mainItem: SubscriptionItemWithQuantity | undefined;
    let supportItem: SubscriptionItemWithQuantity | undefined;

    for (const i of items) {
      if (i.item.isSupportMainItem) {
        supportItems.push(i.item);
        supportItem = i;
        continue;
      }
      if (i.item.isSupportAddonItem) {
        supportItems.push(i.item);
        continue;
      }
      if (i.item.isMainItem) {
        mainItem = i;
      }
      if (i.isIncluded) {
        includedItems.push({ id: i.item.id, code: i.item.code, quantity: i.quantity });
      }
      availableItems.push(i.item);
    }
    nsutils.logMayBe('distributeItems res', { availableItems, supportItems, includedItems, mainItem, supportItem });
    return {
      subscriptionItems: { availableItems, supportItems, mainItem, supportItem },
      includedItems
    }
  }

  private includeItem(line, subscriptionStatus: string): boolean {

    // Define the expected status. Consider only DRAFT items for DRAFT subscriptions.
    const expectedStatus = ['ACTIVE', 'PENDING_ACTIVATION'];
    if (subscriptionStatus.toUpperCase() === 'DRAFT') {
      expectedStatus.push('DRAFT');
    }

    // Include the item if it is included and has an expected status.
    if (line.isincluded === 'T' && expectedStatus.includes(line.status.toUpperCase())) {
      return true;
    }
    return false;
  }

  /**
   * @param subscription jsoned
   */
  buildSubscription(subscription, customerId?: string): ApiSubscription {
    nsutils.logMayBe('buildSubscription params', { subscription: subscription, customerId });
    const customerEntities = this.getCustomerEntities(subscription);
    const parentSubscriptionId = getParentIdFromSnapshot(subscription);

    // Retrieve the linked quotes and related agreements.
    const quoteIds = quoteDao.findLinkedQuotes(subscription.id);
    const quoteDetails = quoteDao.getQuotes(quoteIds);
    const agreements = quoteDao.getAdobeAgreementsInfo(quoteIds);
    const quotes = quoteDetails.map(q => ({
      id: q.id,
      isSelfServe: q.isSelfServe,
      agreements: agreements.filter(agreement => agreement.parentId === q.id)
        .map(agreement => ({
          id: agreement.id,
          type: agreement.type,
          status: agreement.status
        })),
    }));

    const subscriptionPlan = subscriptionPlanUtility.getSubscriptionPlanById(
      parseInt(subscription.fields.subscriptionplan)
    );

    nsutils.logMayBe('buildSubscription plan', {
      planName: subscription.fields.subscriptionplanname
    });

    const currencyDict = nsutils.asHash(nsutils.queryToJson('select id, symbol from currency', []), 'id');
    const currency = currencyDict[subscription.fields.currency].symbol;

    const {
      subscriptionItems,
      includedItems
    } = this.buildItems(subscription, subscriptionPlan);

    nsutils.logMayBe('buildSubscription bl', { subscriptionPlan, subscriptionItems, includedItems });
    if (subscriptionPlan.isLegacyPlan) {
      (this.fixLegacySubscription(subscriptionPlan, subscriptionItems, includedItems));
    }
    nsutils.logMayBe('buildSubscription al', { subscriptionPlan, subscriptionItems, includedItems });

    const items = this.addSupportPricesToItems(subscriptionItems.availableItems, subscriptionItems.supportItems);

    nsutils.logMayBe('buildSubscription addSupportPricesToItems items', items);

    const subscriptionId = parseInt(subscription.id);
    const totalIntervalValue = items.sum((x) => x.totalIntervalValue);

    return {
      id: subscriptionId,
      status: subscription.fields.billingsubscriptionstatus,
      ...customerEntities,
      plan: {
        id: parseInt(subscription.fields.subscriptionplan),
        code: subscriptionPlan.code,
        description: subscriptionPlan.description,
        title: subscriptionPlan.name,
        productTier: subscriptionPlan.productTier,
        productTierTitle: subscriptionPlan.productTierTitle,
        supportLevel: subscriptionPlan.supportLevel,
        revenueType: subscriptionPlan.revenueType,
        isSupportOnly: subscriptionPlan.supportOnly,
        isLegacy: subscriptionPlan.isLegacyPlan,
      },
      items: items,
      includedItems: includedItems,
      term: {
        start: subscription.fields.startdate,
        end: subscription.fields.enddate,
        frequency: subscription.fields.frequency,
        nextBillCycleDate: subscription.fields.nextbillcycledate,
        initialTermDuration: subscription.fields.initialtermduration
          ? parseInt(subscription.fields.initialtermduration)
          : 0,
        initialTermUnits: TermUnit[subscription.fields.initialtermunits],
      },
      autorenewal: subscription.fields.autorenewal === 'T',
      parentSubscription: parentSubscriptionId,
      renewalNumber: subscription.fields.renewalnumber ? parseInt(subscription.fields.renewalnumber) : 0,
      totalAmount: items.sum((x) => x.amount),
      totalIntervalValue: totalIntervalValue,
      currency: currency,
      operations: this.getOperationPermissions(
        must(subscriptionPlan.isLegacyPlan),
        subscription,
        totalIntervalValue,
        parentSubscriptionId,
        customerId
      ),
      quotes: quotes,
    };
  }

  /**
   * Returns the customer entities for a given subscription.
   * It includes the customer, the distributor, the reseller and the end-user.
   * @param subscription
   * @returns An object with the customer entities.
   */
  private getCustomerEntities(subscription): {
    customer: ApiCustomerInfo,
    distributor?: ApiCustomerInfo,
    reseller?: ApiCustomerInfo,
    endUser?: ApiCustomerInfo
  } {
    // Define identifiers for each customer entity.
    const identifiers = {
      customerId: parseInt(subscription.fields.customer),
      distributorId: parseIntOrNull(subscription.fields.custrecord_subs_distributor),
      resellerId: parseIntOrNull(subscription.fields.custrecord_subs_reseller),
      endUserId: parseIntOrNull(subscription.fields.custrecord_subs_end_user),
    };

    // Load customer records into cache.
    const customerRecordsCache = {};
    const loadCustomer = (id: number | null) => {
      if (id) {
        if (!customerRecordsCache[id]) {
          customerRecordsCache[id] = customerDao.getCustomerInfo(id);
        }
        return customerRecordsCache[id];
      }
      return undefined;
    };

    // Returns the customer entities.
    return {
      customer: loadCustomer(identifiers.customerId),
      distributor: loadCustomer(identifiers.distributorId),
      reseller: loadCustomer(identifiers.resellerId),
      endUser: loadCustomer(identifiers.endUserId),
    }
  }

  private getOperationPermissions(
    isLegacyPlan: boolean,
    subscription,
    subscriptionTotalIntervalValue: number,
    parentSubscriptionId: number | undefined,
    customerId?: string
  ): OperationPermission[] {
    // When this method is used internally, customerId is undefined and we should get the correct operations
    // When the customerId is not the subscription customer, then the subscription can't be modified
    if (customerId !== undefined && customerId !== customerDao.getEntityId(subscription.fields.customer)) {
      return [];
    }

    const subscriptionStatus = subscription.fields.billingsubscriptionstatus;
    if (subscriptionStatus === SubscriptionStatus.ACTIVE) {
      return this.getOperationPermissionsForActiveSubscription(subscription, subscriptionTotalIntervalValue, isLegacyPlan);

      // DRAFT subscriptions:
    } else if (subscriptionStatus === SubscriptionStatus.DRAFT && parentSubscriptionId) {
      // For legacy DRAFT Renewal subscriptions will allow some modifications.
      if (isLegacyPlan) {
        return ['changeSuccessPlan', 'changeTerm'];
      }

      // Non-legacy DRAFT Renewal subscriptions will allow modifications, but can’t renew a draft subscription.
      return ['changeEdition', 'changeSuccessPlan', 'changeQuantity', 'changeTerm', 'changeBillingFrequency'];
    }

    return [];
  }

  private getOperationPermissionsForActiveSubscription(subscription, subscriptionTotalIntervalValue: number, isLegacyPlan: boolean): OperationPermission[] {
    // The subscription is $0 AND is not a Trial
    // : No operations are allowed.
    const isTrial = subscription.fields.custrecord_istrial === 'T';
    if (subscriptionTotalIntervalValue === 0 && !isTrial) {
      return [];
    }

    // The subscription has a processed Renewal subscription (Renewal subscriptions Status = Pending Activation)
    // : No operations are allowed.
    const renewalHistory = subscriptionDao.getRenewalHistoryOfSubscription(parseInt(subscription.id));
    if (renewalHistory.find((x) => x.status === SubscriptionStatus.PENDING_ACTIVATION)) {
      return [];
    }

    // The subscription has a Draft renewal. We will allow Renewal and not allow modifications.
    const hasDraftRenewal = !!renewalHistory.find((x) => x.status === SubscriptionStatus.DRAFT);
    if (hasDraftRenewal) {

      // The renewal is possible only if the end date is 180 days or less from today.
      const endDate = new Date(subscription.fields.enddate);
      const today = new Date();
      const daysDifference = nsutils.diffDateInDays(endDate, today);
      const MAX_DAYS_FOR_RENEWAL = 180;
      if (daysDifference > MAX_DAYS_FOR_RENEWAL) {
        return [];
      }

      // The renewal is possible only for a subset of product famillies.
      const allowedProductFamilyCodes = ['DNN', 'Tra', 'Nor'];
      const productFamilyCode = subscriptionPlanDao.getProductFamilyCode(subscription.fields.subscriptionplan);
      if (!productFamilyCode || !allowedProductFamilyCodes.includes(productFamilyCode)) {
        return [];
      }

      return ['renew'];
    }

    // For non-legacy ACTIVE subscriptions without the Draft Renewal. We will allow all modifications, but no renewal.
    if (!isLegacyPlan && !hasDraftRenewal) {
      return ['changeEdition', 'changeSuccessPlan', 'changeQuantity', 'changeTerm', 'changeBillingFrequency'];
    }

    return [];
  }

  private mapItemsToFrontView(
    items: SubscriptionItem[],
    planInfo: ApiSubscriptionPlan,
    hidePrices: boolean
  ): SubscriptionItem[] {
    items.forEach((item) => {
      item.amount = roundMoney(item.amount);
      item.totalIntervalValue = roundMoney(item.totalIntervalValue);
      if (item.isMainItem || (planInfo.isSupportOnly && item.isSupportMainItem)) {
        item.required = true;
      }
      delete (item as unknown as Any).isMainItem;
      delete (item as unknown as Any).isSupportMainItem;
      delete (item as unknown as Any).isSupportAddonItem;
      delete (item as unknown as Any).quantity;
      delete (item as unknown as Any).recuringAmount;
      delete (item as unknown as Any).frequency;
      delete (item as unknown as Any).repeatEvery;
      delete (item as unknown as Any).renewItemId;
      delete (item as unknown as Any).renewItemCode;
      if (planInfo.isLegacy) {
        item.prices = [];
        item.amount = null as unknown as number;
      }
      if (hidePrices) {
        item.prices = [];
        item.amount = null as unknown as number;
        item.totalIntervalValue = null as unknown as number;
      }
    });
    return items;
  }

  public getSubscriptionByIdForCustomer(subscriptionId, customerId: string): ApiSubscription {
    nsutils.logMayBe('getSubscriptionById params', { subscriptionId });
    const subscriptionRecord = SubscriptionRecord.load(subscriptionId, false);

    if (!subscriptionRecord.isReadableForCustomer(customerId)) {
      throw new SubscriptionNotFoundError();
    }

    let subscription = this.getSubscriptionByIdInternal(subscriptionId, customerId);

    // hide prices if customer requesting is endUser only and is not the billable customer
    const hidePrices = customerId !== subscriptionRecord.customerId;

    subscription = this.mapSubscriptionToFrontView(subscription, hidePrices);

    return subscription;
  }

  private mapSubscriptionToFrontView(subscription: ApiSubscription, hidePrices: boolean): ApiSubscription {
    nsutils.logMayBe('mapSubscriptionToFrontView params', { subscription, hidePrices });

    if (subscription.plan.isLegacy) {
      subscription.totalAmount = undefined;
    }

    subscription.items = this.mapItemsToFrontView(subscription.items, subscription.plan, hidePrices);

    //cleaning fields that are not supposed to return in the api
    subscription.totalIntervalValue = roundMoney(subscription.totalIntervalValue!);
    if (hidePrices) {
      subscription.totalAmount = undefined;
      subscription.totalIntervalValue = undefined;
    }
    subscription.plan.isSupportOnly = undefined;
    subscription.plan.isLegacy = undefined;

    subscription.term.initialTermDuration = undefined;
    subscription.term.initialTermUnits = undefined;

    nsutils.logMayBe('mapSubscriptionToFrontView res', subscription);
    return subscription;
  }

  public getSubscriptionByIdInternal(subscriptionId, customerId?: string): ApiSubscription {
    nsutils.logMayBe('getSubscriptionById params', { subscriptionId });
    const subscriptionRecord = record.load({
      type: record.Type.SUBSCRIPTION,
      id: subscriptionId,
    });
    const subscription = clone(subscriptionRecord);
    return this.buildSubscription(subscription, customerId);
  }

  public assertAndGetSubscription(subscriptionId?: number, subscription?: ApiSubscription) {
    assertTrue(!!subscriptionId || !!subscription, 'SubscriptionId or subscription must be informed');
    if (!subscription) {
      subscription = this.getSubscriptionByIdInternal(subscriptionId);
    }
    return subscription;
  }

  public checkSubscriptionCustomer(subscriptionId, customerId) {
    nsutils.logMayBe('checkSubscriptionCustomer', { subscriptionId, customerId });
    const customer = nsutils.queryFirstToJson(
      `select c.entityId, csr.subsidiary from subscription s
      inner join billingaccount ba on ba.id = s.billingaccount
      inner join customer c on c.id = ba.customer
      inner join customersubsidiaryrelationship csr on csr.entity = c.id
      where s.id=?`,
      [subscriptionId],
      { entityid: 'id', subsidiary: 'subsidiary' }
    );
    if (customer == null || customer.id !== customerId) {
      throw new Error('Subscription does not exist or is from another customer');
    }
    return customer;
  }

  public fixLegacySubscription(
    subscriptionPlanInfo: PlanInfo,
    subscriptionItems: SubscriptionItems,
    includedItems: SubscriptionIncludedItem[]
  ) {
    nsutils.logMayBe('fixLegacySubscription params', {
      subscriptionPlanInfo,
      subscriptionItems,
      includedItems,
    });

    // 2. ITD 4: If all of the revenue is allocated to the primary support item, then it’s a maintenance only Subscription,
    // and return it as a maintenance Subscription (support item with 100% price allocated should be returned, not main item)
    if (
      !subscriptionItems.mainItem?.item.amount &&
      subscriptionItems.supportItem?.item.amount &&
      subscriptionItems.supportItem?.item.amount > 0
    ) {
      this.fixLegacySupportOnlySub(
        subscriptionPlanInfo,
        subscriptionItems.availableItems,
        subscriptionItems.mainItem,
        subscriptionItems.supportItem,
        includedItems
      );
    }

    nsutils.logMayBe('fixLegacySubscription res', {
      availableItems: subscriptionItems.availableItems,
      supportItems: subscriptionItems.supportItems,
      includedItems,
      subscriptionPlanInfo
    });
  }

  public getSubscriptionRecItems(subscriptionSnapshot): {
    plan: SubscriptionPlan;
    subscriptionItems: SubscriptionItems;
  } {
    const planId = parseInt(subscriptionSnapshot.fields.subscriptionplan);
    const plan = subscriptionPlanUtility.getSubscriptionPlanById(planId);
    const { subscriptionItems } = this.buildItems(subscriptionSnapshot, plan);
    return { plan, subscriptionItems };
  }

  private getPriceLineAmount(priceLine: any): number {
    return isNotNull(priceLine.recurringamount)
      ? parseFloat(priceLine.recurringamount)
      : parseFloat(priceLine.totalintervalvalue);
  }

  /**
   * Fixes legacy subscription line items according ITD8:
   * API should sum the recurring amounts of the duplicated items together and return a single item in the API response.
   * @constructor
   * @param {Array<any>} prices - The priceinterval subscription sublist.
   * @param {Array<any>} lines - The subscriptionline subscription sublist.
   */
  private fixDuplicatedItems(
    prices: any[],
    lines: any[],
    subscriptionStatus: string
  ): { prices: Any[]; lines: Any[]; } {
    nsutils.logMayBe('fixDuplicatedItems params', {
      prices,
      lines,
      subscriptionStatus,
    });

    // Fix the duplicate non-included items.
    ({ prices, lines } = this.fixDuplicateNonIncludedItems(prices, lines));

    // Remove terminated prices lines for active line items
    // if the line item is active and we have a terminated price line, is because the termination is in future
    lines.forEach((line) => {
      if (line.status.toUpperCase() === SubscriptionStatus.ACTIVE) {
        prices = prices.remove((p) => p.linenumber === line.linenumber && p.status.toUpperCase() === SubscriptionStatus.TERMINATED);
      }
    });

    const priceGroups = prices
      // sort by start date
      .sort((a, b) =>
        nsutils.convert.toDate(a.startdate) > nsutils.convert.toDate(b.startdate)
          ? 1
          : nsutils.convert.toDate(a.startdate) < nsutils.convert.toDate(b.startdate)
          ? -1
          : 0
      )
      .groupBy((x) => x.item)
      .filter((g) => g.count > 1);

    nsutils.logMayBe('fixDuplicatedItems priceGroups', { priceGroups });

    // CLOSED items have price line active
    const statusToInclude = [SubscriptionStatus.ACTIVE];
    switch (subscriptionStatus.toUpperCase()) {
      // if the subscription is closed or terminated, but has one item with status DRAFT or PENDING_ACTIVATION
      // the subscription status will be DRAFT or PENDING_ACTIVATION
      // this is the reason to include TERMINATED for DRAFT or PENDING_ACTIVATION status
      case SubscriptionStatus.DRAFT:
        statusToInclude.push(SubscriptionStatus.DRAFT);
      // fallthrough
      case SubscriptionStatus.PENDING_ACTIVATION:
        statusToInclude.push(SubscriptionStatus.PENDING_ACTIVATION);
      // fallthrough
      case SubscriptionStatus.TERMINATED:
        statusToInclude.push(SubscriptionStatus.TERMINATED);
        break;
      default:
        break;
    }

    priceGroups.forEach((g) => {
      ({ prices, lines } = this.fixDuplicateGroup(g, prices, lines, statusToInclude, subscriptionStatus));
    });

    nsutils.logMayBe('fixDuplicatedItems res', {
      prices,
      lines,
    });

    return { prices, lines };
  }

  // return the total interval value for terminated items
  private fixDuplicateGroup(group, prices, lines, statusToInclude, subscriptionStatus):
    { prices; lines; } {
    // get the last price line for each line number, recurring amount and quantity should be based only on the last price line
    const lastPriceLines = group.groupItems.reverse().filter((item, index, self) => 
      self.findIndex(t => t.linenumber === item.linenumber) === index).sort((a, b) => a.linenumber - b.linenumber);

    // get only included items to make sure the item to aggregate will have correct status
    // and to correctly sum amounts and quantities
    const includedItems = lastPriceLines.filter(i => i.status && statusToInclude.includes(i.status.toUpperCase()));

    // we don't want to sum total interval values for draft or pending activation items when
    // the subscription is not draft or pending activation
    if (subscriptionStatus.toUpperCase() !== SubscriptionStatus.DRAFT &&
      subscriptionStatus.toUpperCase() !== SubscriptionStatus.PENDING_ACTIVATION) {
      group.groupItems = group.groupItems.remove((i) => i.status && (
        i.status.toUpperCase() === SubscriptionStatus.PENDING_ACTIVATION ||
        i.status.toUpperCase() === SubscriptionStatus.DRAFT
      ));
    }

    // get base item to aggregate, getting the first linenumber
    // doesn't cover the case when there are multiple types of frequency/repeatevery in the price items group.
    const itemToAggregate = includedItems.length > 0 ? clone(includedItems[0]) : clone(lastPriceLines[0]);
    nsutils.logMayBe('fixDuplicatedItems itemToAggregate', { itemToAggregate });

    itemToAggregate.recurringamount = roundMoney(includedItems.sum((x) => parseMoney(x.recurringamount))).toString();
    itemToAggregate.totalintervalvalue = roundMoney(
      group.groupItems.sum((x) => parseMoney(x.totalintervalvalue))
    ).toString();
    // sum quantities when recurring amount is positive and subtract when recurring amount is negative (refund)
    itemToAggregate.quantity = (includedItems
      .filter((x) => parseFloat(x.recurringamount) >= 0)
      .sum((x) => Math.ceil(parseFloat(x.quantity))) - 
      includedItems
      .filter((x) => parseFloat(x.recurringamount) < 0)
      .sum((x) => Math.ceil(parseFloat(x.quantity)))).toString();

    nsutils.logMayBe('fixDuplicatedItems itemToAggregate updated', { itemToAggregate });

    // remove price items, insert aggregated price item
    prices = prices.remove((x) => x.item === itemToAggregate.item);
    prices.push(itemToAggregate);

    // get line item corresponding to the price line
    const lineItemToAggregate = lines.find(
      (x) => x.item === itemToAggregate.item && x.linenumber === itemToAggregate.linenumber
    );
    if (!lineItemToAggregate) {
      throw Error(
        `Couldn't get line item to aggregate. item: ${itemToAggregate.item}, linenumber: ${itemToAggregate.linenumber}`
      );
    }
    // remove line items, insert aggregated line item
    lines = lines.remove((x) => x.item === lineItemToAggregate.item);
    lines.push(lineItemToAggregate);

    // total interval value is in the priceline
    return {
      prices,
      lines
    };
  }

  /**
   * Fix the duplicated non-included items.
   * - Remove the non-included items if there are duplicate items with different statuses.
   * - Remove the non-included items expect the last one if there are duplicate items with only non-included items.
   * - Else, return the original arrays.
   * @param prices The prices.
   * @param lines The lines.
   * @returns The updated prices and lines.
   */
  private fixDuplicateNonIncludedItems(prices: Any[], lines: Any[]): { prices: Any[], lines: Any[] } {

    // Find the non-included line numbers to remove for duplicate items.
    const NOT_INCLUDED = 'NOT_INCLUDED';
    const nonIncludedLineNumbersToRemove = lines
      .groupBy((x) => x.item)
      .map((g) => {

        // If there is no duplicate item, nothing to remove.
        if (g.count === 1) {
          return [];
        }

        // If there are duplicate items with items having a different status, remove all the non-included items.
        if (g.groupItems.some((x) => x.status && x.status.toUpperCase() !== NOT_INCLUDED)) {
          return g.groupItems
            .filter((x) => x.status && x.status.toUpperCase() === NOT_INCLUDED)
            .map((x) => x.linenumber);
        }

        // If there are duplicate items with only non-included items, keep the latest non-included item.
        return g.groupItems
          .map((x) => parseInt(x.linenumber)).sort((a, b) => a - b).slice(0, -1)
          .map(l => l.toString());
      })
      .reduce((a, b) => a.concat(b), []);

    // If there are non-included line numbers to remove, remove them.
    if (nonIncludedLineNumbersToRemove.length > 0) {
      return {
        prices: prices.remove((x) => nonIncludedLineNumbersToRemove.includes(x.linenumber)),
        lines: lines.remove((x) => nonIncludedLineNumbersToRemove.includes(x.linenumber)),
      }
    }

    // Else, return the original arrays.
    return { prices, lines };
  }

  private fixLegacySupportOnlySub(
    planInfo: PlanInfo,
    availableItems: SubscriptionItem[],
    mainItem: SubscriptionItemWithQuantity | undefined,
    supportItem: SubscriptionItemWithQuantity,
    includedItems: SubscriptionIncludedItem[]
  ) {
    nsutils.logMayBe('fixLegacySupportOnlySub params', {
      planInfo: planInfo,
      availableItems,
      mainItem,
      supportItem,
      includedItems,
    });

    planInfo.supportOnly = true;

    // remove main item from availableItems
    const index = availableItems.findIndex((x) => x.id === mainItem?.item.id);
    if (index > -1) {
      availableItems.splice(index, 1);
    }

    if (!availableItems.find((x) => x.id === supportItem?.item.id)) {
      availableItems.push(supportItem.item);
    }

    const mainItemIndex = includedItems.findIndex((x) => x.id === mainItem?.item.id);
    if (mainItemIndex !== -1) {
      includedItems.splice(mainItemIndex,1);
    }
    if (!includedItems.find((x) => x.id === supportItem?.item.id)) {
      includedItems.push({ id: supportItem.item.id, code: supportItem.item.code, quantity: supportItem.quantity });
    }

    nsutils.logMayBe('fixLegacySupportOnlySub res', {
      availableItems,
      includedItems,
    });
  }
}

export default new SubscriptionGetUtility();
