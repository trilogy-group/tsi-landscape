import * as nsutils from '../nsutils';
import * as record from 'N/record';
import subscriptionDao from '../dao/SubscriptionDao';
import { DynamicSublistWrapper } from '../models/DynamicSublistWrapper';
import { must } from '../validation';
import { ItemType, ProductTier, ProductTierUtil, SupportLevel, SupportLevelUtil } from '../types';
import { SubscriptionConfigurationItem } from '../models/SubscriptionParams';
import { SubscriptionPlan, SubscriptionPlanItem } from '../models/SubscriptionPlan';

export class SubscriptionItemUtility {
  public findItemCodes(subscriptionOrCO: record.Record, lineName = 'subscriptionline') {
    nsutils.logMayBe('findItemInfos params', { subscriptionOrCO: subscriptionOrCO, lineName: lineName });
    const itemStatuses = this.getSubItemIds(subscriptionOrCO, lineName);

    const planId = subscriptionOrCO.getValue('subscriptionplan') as string;
    nsutils.logMayBe('findItemInfos planId', planId);
    const itemCodes = subscriptionDao.findSubscriptionItemCodes(
      itemStatuses.map((i) => i.id),
      planId
    );
    return itemCodes.map((ic) => {
      return { ...ic, status: itemStatuses.find((is) => is.id === ic.id)?.status };
    });
  }

  public getSubItemIds(
    subscriptionRec: record.Record,
    lineName = 'subscriptionline'
  ): Array<{ id: number; status: string }> {
    const res: Array<{ id: number; status: string }> = [];
    const subLine = new DynamicSublistWrapper(subscriptionRec, lineName);
    while (subLine.nextLine()) {
      res.push({
        id: parseInt(must(subLine.getFieldValue('item')).toString()),
        status: must(subLine.getFieldValue('status')) as string,
      });
    }
    return res;
  }

  public findItemForLine(
    currentLineItemId: number,
    plan: SubscriptionPlan,
    items: SubscriptionConfigurationItem[],
  ) {
    //NOSONAR
    nsutils.logMayBe('findItemForLine params', {
      currentLineItemId: currentLineItemId,
      plan: plan,
      items: items
    });
    let item = items.find((i) => {
      const planItem = plan.items.find((ic) => ic.code === i.code);
      nsutils.logMayBe('findItemForLine planItem', planItem);
      if (!planItem) {
        throw new Error('Cannot find item with code ' + i.code);
      }
      // ignore input support items
      if (planItem.isSupportAddonItem || (!plan.supportOnly && planItem.isSupportMainItem)) {
        nsutils.logMayBe('findItemForLine ignore input support items', planItem);
        return false;
      }
      if (currentLineItemId === planItem.id) {
        return true;
      }

      return false;
    });
    nsutils.logMayBe('findItemForLine item', item);
    // when the current item is support item and it is missing in subscription create param items,
    // we need to add it and get the quantity from main item
    if (!item) {
      const thisItem = must(plan.items.find((ic) => ic.id === currentLineItemId));
      if (thisItem.isSupportMainItem || thisItem.isSupportAddonItem) {
        const planItem = plan.items.find(
          (ic) => new ItemCode(ic.code).isDifferentOnlyInSuffix(new ItemCode(thisItem.code))
        );
        nsutils.logMayBe('findItemForLine different only in suffix item code', planItem);
        if (planItem) {
          item = items.find((i) => i.code === planItem.code);
        }
      }
    }
    nsutils.logMayBe('findItemForLine res', item);
    return item;
  }

  public updateItemsToUpdate(
    subPricing: DynamicSublistWrapper,
    itemCodes: SubscriptionPlanItem[],
    itemsToUpdate: {
      code: string;
      itemType: ItemType;
      supportLevel?: SupportLevel;
      line: number;
      pricePlan: number;
    }[]
  ) {
    nsutils.logMayBe('updateItemsToUpdate params', { subPricing, itemCodes, itemsToUpdate });
    const itemCode = itemCodes.find((ic) => ic.id === parseInt(must(subPricing.getFieldValue('item')).toString()));
    nsutils.logMayBe('updateItemsToUpdate itemCode', itemCode);
    if (itemCode && itemCode.isSupportMainItem) {
      itemsToUpdate.push({
        code: itemCode.code,
        itemType: ItemType.SUPPORT,
        supportLevel: itemCode.supportLevel,
        line: subPricing.lineNumber(),
        pricePlan: subPricing.getFieldValue('priceplan') as number,
      });
    } else if (itemCode && itemCode.isMainItem) {
      itemsToUpdate.push({
        code: itemCode.code,
        itemType: ItemType.MAIN,
        line: subPricing.lineNumber(),
        pricePlan: subPricing.getFieldValue('priceplan') as number,
      });
    }
    nsutils.logMayBe('updateItemsToUpdate itemsToUpdate', itemsToUpdate);
  }
}

export default new SubscriptionItemUtility();

const ITEM_CODE_COMPONENTS = 4;
export class ItemCode {
  productCode = '';
  revenueType = '';
  itemCode = '';
  suffix = '';
  isValid = false;

  constructor(code: string) {
    if (!code) {
      return;
    }
    const parts = code.split('-');
    this.isValid = parts.length === ITEM_CODE_COMPONENTS;
    [this.productCode, this.revenueType, this.itemCode, this.suffix] = parts;
  }

  codeWOSuffix() {
    return `${this.productCode}-${this.revenueType}-${this.itemCode}`;
  }

  toString(): string {
    return `${this.productCode}-${this.revenueType}-${this.itemCode}-${this.suffix}`;
  }

  isDifferentOnlyInSuffix(other: ItemCode): boolean {
    return this.isValid && this.suffix !== other.suffix && this.codeWOSuffix() === other.codeWOSuffix();
  }

  isSupport(): boolean {
    const supportLevel = SupportLevelUtil.codeToSupportLevel(this.suffix);
    return this.isValid && !!supportLevel;
  }

  productTier(): ProductTier | undefined {
    return this.isValid ? ProductTierUtil.codeToProductTier(this.suffix) : undefined;
  }

  supportLevel(): SupportLevel | undefined {
    return this.isValid ? SupportLevelUtil.codeToSupportLevel(this.suffix) : undefined;
  }

  getCodeWithNewSuffix(productTier: ProductTier, supportLevel: SupportLevel): string {
    if (this.isSupport()) {
      return `${this.codeWOSuffix()}-${SupportLevelUtil.supportLevelToCode(supportLevel)}`;
    } else if (this.productTier()) {
      return `${this.codeWOSuffix()}-${ProductTierUtil.productTierToCode(productTier)}`;
    } else {
      return this.toString();
    }
  }
  
  /**
   * Returns True if the two codes are different only in suffix; False otherwise.
   * @param {string} code1 The first code to compare.
   * @param {string} code2 The second code to compare.
   * @returns {boolean} True if the two codes are different only in suffix; False otherwise.
   */
  static isDifferentOnlyInSuffix(code1: string, code2: string): boolean {
    const itemCode1 = new ItemCode(code1);
    const itemCode2 = new ItemCode(code2);
    return itemCode1.isDifferentOnlyInSuffix(itemCode2);
  }
}


