import * as nsutils from '../nsutils';
import SubscriptionPlanDao from '../dao/SubscriptionPlanDao';
import { SubscriptionUpdateParams } from '../models/SubscriptionParams';
import { isNotBlank, must, ValidationError } from '../validation';
import { ProductTier, ProductTierUtil, RevenueType, RevenueTypeUtils, SupportLevel, SupportLevelUtil } from '../types';
import { ListSubscriptionPlanParams, PlanInfo, Price, PriceTier, PriceTierType, SubscriptionPlan, SubscriptionPlanItem } from '../models/SubscriptionPlan';
import { ItemCode } from './SubscriptionItemUtility';

interface SubscriptionPlanQueryItem {
  id: number;
  code: string;
  title: string;
  description: string;
  isrequired: string; // T/F
  chargetypeid: number;
  chargetype: string;
  pricebookid: number;
  pricetype: string;
  frequency: string;
  currency: string;
  priceplanid: number;
  fromquantity: number;
  price: number;
  pricingoption: number;
  linenumber: number;
  maximumquantity: number;
  minimumquantity: number;
  support_level_name: string;
  product_tier_name: string;
}

const PRODUCT_TIER_PART = 4;
const SUPPORT_TIER_PART = 5;

class SubscriptionPlanItemBuilder {
  private resItemsCache: { [key: number]: SubscriptionPlanItem } = {}; //NOSONAR
  private priceItemCache = {}; //NOSONAR
  constructor(public planInfo: PlanInfo, readonly res: SubscriptionPlanItem[]) {}

  private getOrCreateResItem(item: SubscriptionPlanQueryItem, planInfo: PlanInfo) {
    let resItem: SubscriptionPlanItem = this.resItemsCache[item.id];
    if (!resItem) {
      const isSupportItem = item.code === planInfo.supportItemCode;
      const supportLevel = isSupportItem ? planInfo.supportLevel : null;
      
      const isMainItem = item.code === planInfo.mainItemCode;
      const productTier = isMainItem ? planInfo.productTier : null;

      resItem = {
        id: item.id,
        code: item.code,
        title: item.title,
        supportLevel: supportLevel,
        productTier: productTier,
        isMainItem: isMainItem,
        isSupportMainItem: isSupportItem,
        isSupportAddonItem: false,
        required: isSupportItem || isMainItem ? true : item.isrequired === 'T',
        type: item.chargetype,
        typeId: item.chargetypeid,
        desc: item.description,
        minQuantity: item.minimumquantity,
        maxQuantity: item.maximumquantity,
        prices: [],
      } as SubscriptionPlanItem;
      this.resItemsCache[item.id] = resItem;
      this.res.push(resItem);
    }
    return resItem;
  }

  private getOrCreatePriceItem(item: SubscriptionPlanQueryItem, resItem: SubscriptionPlanItem) {
    let priceItem: Price =
      this.priceItemCache[item.id + item.currency + (item.frequency === 'ONETIME' ? item.priceplanid : item.frequency)];
    if (!priceItem) {
      priceItem = <Price>{
        type: item.pricetype,
        frequency: item.frequency,
        currency: item.currency,
        pricebookid: item.pricebookid,
        ranges: [],
      };
      this.priceItemCache[
        item.id + item.currency + (item.frequency === 'ONETIME' ? item.priceplanid : item.frequency)
      ] = priceItem;
      resItem.prices.push(priceItem);
    }
    return priceItem;
  }

  buildItem(item: SubscriptionPlanQueryItem) {
    const resItem = this.getOrCreateResItem(item, this.planInfo);
    const priceItem = this.getOrCreatePriceItem(item, resItem);
    // if the pricebook is different, it means it has two prices setup for the item, currency and frequency
    // and we are only considering the first returned
    if (priceItem.pricebookid === item.pricebookid) {
      priceItem.ranges.push(<PriceTier>{
        priceplanid: item.priceplanid,
        type: PriceTierType[item.pricingoption],
        fromQuantity: item.fromquantity,
        price: item.price,
      });
    }
  }
}

export class SubscriptionPlanUtility {
  public findSubscriptionPlanAndPriceBook(planName, customerId, frequency) {
    const subscriptionPlan = SubscriptionPlanDao.getInternalIdAndSubsidiary(planName);
    if (!subscriptionPlan) {
      throw new ValidationError('Subscription plan not found or invalid', 'planCode');
    }
    const priceBookId = SubscriptionPlanDao.findPriceBook(subscriptionPlan.id, customerId, frequency);
    if (!priceBookId) {
      throw new ValidationError('No suitable pricebook for this customer, specified plan and frequency', 'planCode');
    }
    return {
      subscriptionPlanId: subscriptionPlan.id,
      priceBookId,
      subscriptionPlanClass: subscriptionPlan.class,
      subsidiaries: subscriptionPlan.subsidiaries,
    };
  }

  public isCurrentPlanChange(params: SubscriptionUpdateParams): boolean {
    nsutils.logMayBe('isCurrentPlanChange params', {
      params,
    });
    const currentPlan = nsutils.queryFirstToJson(
      `select subscriptionplanname, frequency from subscription where id=?`,
      [must(params.subscriptionId, 'subscriptionId')],
      { subscriptionplanname: 'code', frequency: 'frequency' }
    );
    if (!currentPlan) {
      throw new Error('Subscription plan does not exist');
    }

    nsutils.logMayBe('isCurrentPlanChange vars', {
      paramsPlanCode: params.content?.planCode,
      currentPlanCode: currentPlan.code,
      paramsFrequency: params.content?.frequency,
      currentFrequency: currentPlan.frequency,
    });
    const res =
      (params.content?.planCode && currentPlan.code !== params.content?.planCode) ||
      ((params.content?.frequency ? true : false) && currentPlan.frequency !== params.content?.frequency);

    nsutils.logMayBe('isCurrentPlanChange res', res);
    return res;
  }

  private getPlanInfo(planCode: string): {
    id: number;
    code: string;
    displayName: string;
  } {
    return nsutils.queryFirstToJson(`select id, itemid, displayname from subscriptionplan where itemid=?`, [planCode], {
      id: 'id',
      itemid: 'code',
      displayname: 'displayName',
    });
  }

  public validatePlan(params: SubscriptionUpdateParams): {
    id: number;
    code: string;
    displayName: string;
  } {
    const currentPlan = nsutils.queryFirstToJson(
      `select subscriptionplanname, frequency from subscription where id=?`,
      [must(params.subscriptionId, 'subscriptionId')],
      { subscriptionplanname: 'code', frequency: 'frequency' }
    );
    if (!currentPlan) {
      throw new Error('Subscription plan does not exist');
    }
    return this.getPlanInfo(currentPlan.code);
  }

  /**
   * Checks if subscription plan is legacy plan.
   * if plan code does not have -NNN version at the end, it will be considered legacy subscription
   * @param items subscription plan items
   * @returns the result of check
   */
  private isLegacyPlan(planCode: string): boolean {
    // if no main item, than this is a support only plan
    const nonLegacyPlanRegex = new RegExp(/^.*-\d{3}$/g);
    return !nonLegacyPlanRegex.test(planCode);
  }

  /**
   * Checks if the plan code is structured or not.
   * The plan code is structured as follows: XXX-YYY-ZZZ-AAA-BBB.
   * @param {string} planCode The subscription plan code.
   * @returns {boolean} Whether the plan code is structured or not.
   */
  public isStructuredCode(planCode: string): boolean {
    return RegExp(/[^-]+-[^-]+-[^-]+-[^-]+-[^-]+.*/).test(planCode);
  }

  private getMainItemCode(planCode:string):string {
    if (!planCode) {
      return '';
    }
    return planCode.split('-',PRODUCT_TIER_PART).join('-');
  }

  private getSupportItemCode(planCode:string):string {
    if (!planCode) {
      return '';
    }
    const parts = planCode.split('-',SUPPORT_TIER_PART);
    //removing product tier from code
    parts.splice(PRODUCT_TIER_PART - 1,1);
    return parts.join('-');
  }

  private isMaintenancePlan(displayName?: string) {
    const groupIndex = 1;
    if (isNotBlank(displayName)) {
      const match = displayName.match(/[^-]+-[^-]+-[^-]+-[^-]+-[^-]+-([^-]+).*/);
      if (!match || match.length <= groupIndex) {
        return false;
      }
      return match[groupIndex] === 'MNT';
    }
    return false;
  }

  private getRevenueTypeCodeFromPlanCode(planCode?: string) {
    const groupIndex = 1;
    nsutils.logMayBe('revenueType planCode', planCode);
    if (isNotBlank(planCode)) {
      const match = planCode.match(/[^-]+-([^-]+)-.+/);
      nsutils.logMayBe('revenueType match', match);
      nsutils.logMayBe('revenueType match length', match?.length);
      if (!match || match.length <= groupIndex) {
        return undefined;
      }
      return match[groupIndex];
    }
    return undefined;
  }

  private extractSupportLevelFromPlanCode(displayName?: string) {
    const groupIndex = 1;
    if (isNotBlank(displayName)) {
      const match = displayName.match(/[^-]+-[^-]+-[^-]+-[^-]+-([^-]+).*/);
      if (!match || match.length <= groupIndex) {
        return undefined;
      }
      return match[groupIndex];
    }
    return undefined;
  }

  private extractProductTierFromPlanCode(displayName?: string) {
    const groupIndex = 1;
    if (isNotBlank(displayName)) {
      const match = displayName.match(/[^-]+-[^-]+-[^-]+-([^-]+).+/);
      if (!match || match.length <= groupIndex) {
        return undefined;
      }
      return match[groupIndex];
    }
    return undefined;
  }


  private getSubscriptionPlanInfos(params: ListSubscriptionPlanParams): PlanInfo[] {
    const planInfos = SubscriptionPlanDao.getSubscriptionPlanInfos(params);
    for (const plan of planInfos) {
      // https://docs.google.com/document/d/1A9C6JUCxrR4BOOPyq7YxpXyNvpxbbOtAjPO5tqUg_ok/edit#bookmark=id.916loevi7rd

      // If the plan code is structured, retrieve details from the current plan. Else, retrieve details from the renewal plan.
      // If there is no renewal plan, rely on the default values.
      if (this.isStructuredCode(plan.code) || !plan.renewalPlanId || plan.renewalPlanId === plan.id) {
        plan.supportOnly = this.isMaintenancePlan(plan.code);
        const { productTier, mainItemCode } = this.getProductTierAndMainItemCode(plan);
        plan.productTier = productTier;
        plan.mainItemCode = mainItemCode;
        plan.supportLevel = SupportLevelUtil.codeToSupportLevel(this.extractSupportLevelFromPlanCode(plan.code)) ?? SupportLevel.Silver;
        plan.supportItemCode = this.getSupportItemCode(plan.code);
        plan.isLegacyPlan = this.isLegacyPlan(plan.code);
        const tierLabel = plan.productTier ? plan.product?.tierLabels?.[plan.productTier] : null;
        plan.productTierTitle = isNotBlank(tierLabel) ? tierLabel : plan.productTier;
        // Revenue type is being determined by the 4th and 5th letters in the subscription plan code
        // and for maintenance subscriptions, is always support
        // This is how finance also determine the revenue type
        plan.revenueType = RevenueTypeUtils.revenueTypeToName(!plan.supportOnly ?
          RevenueTypeUtils.codeToRevenueType(this.getRevenueTypeCodeFromPlanCode(plan.code)) : RevenueType.Support);
      } else if (plan.renewalPlanId) {
        // The latest version of the renewal plan is not required here.
        const renewalPlan = this.getSubscriptionPlanInfoById(plan.renewalPlanId);
        // The main and support items don't have sense in this case.
        plan.isLegacyPlan = true;
        plan.revenueType = renewalPlan.revenueType;
        plan.productTier = renewalPlan.productTier;
        plan.productTierTitle = renewalPlan.productTierTitle;
        plan.supportLevel = renewalPlan.supportLevel;
        plan.supportOnly = renewalPlan.supportOnly;
      }
    }
    return planInfos;
  }

  /**
   * Returns the product tier and the main item code for the given plan.
   * @param plan The plan info.
   * @returns The product tier and the main item code.
   */
  private getProductTierAndMainItemCode(plan: PlanInfo): { productTier: ProductTier; mainItemCode: string | undefined } {

    // If relevant, define the default main item code.
    let mainItemCode: string | undefined;
    if (!plan.supportOnly) {
      mainItemCode = this.getMainItemCode(plan.code);
    }

    // Try to deduce the product tier from the plan code.
    let productTier: ProductTier | undefined = ProductTierUtil.codeToProductTier(this.extractProductTierFromPlanCode(plan.code))

    // If the product tier cannot be determined from the plan code, try to deduce the product tier from the items.
    // Adapt consequently the main item code by replacing the product tier code.
    if (!productTier) {
      productTier = ProductTierUtil.codeToProductTier(SubscriptionPlanDao.getProductTierCodeFromItems(plan.id));
      if (productTier && mainItemCode) {
        mainItemCode = mainItemCode.replace(/[^-]+$/, ProductTierUtil.productTierToCode(productTier));
      }
    }

    // Return the product tier and the main item code. If the product tier is undefined, consider the plan as standard.
    return { productTier: productTier ?? ProductTier.Standard, mainItemCode };
  }

  /**
   * get subscription plans for the informed family and variant
   * @param params containing the family and variant to search
   * @returns the subscription plans and their items
   */
  public getSubscriptionPlans(params: ListSubscriptionPlanParams): SubscriptionPlan[] {
    const plans = this.getSubscriptionPlanInfos(params) as SubscriptionPlan[];
    for (const plan of plans){
      plan.items = this.getSubscriptionPlanItems(plan.id, plan);
    }
    return plans;
  }

  /**
   * Support items are not listed to customer and the list price must be sum to the matching item
   * Return list of supportItemCodes merged
   */
  public addSupportPricesToItems(plan: SubscriptionPlan): string[] {
    const supportItemCodes: string[] = [];
    for (const item of plan.items) {
      const itemCode = new ItemCode(item.code);
      if (!itemCode.isSupport()) {
        continue;
      }
      const matchItem = plan.items.find(i => itemCode.isDifferentOnlyInSuffix(new ItemCode(i.code)));
      if (!matchItem) {
        continue;
      }
      supportItemCodes.push(item.code);
      matchItem.prices.forEach((itemPrice) => {
        const supportPrice = item.prices.find(sp => sp.currency === itemPrice.currency && sp.frequency === itemPrice.frequency);
        if (supportPrice) {
          this.addSupportPriceInsideRange(itemPrice.ranges, supportPrice.ranges);
        }
      });
    }
    return supportItemCodes;
  }

  private addSupportPriceInsideRange(mainItemRanges: PriceTier[], supportRanges: PriceTier[]) {
    for (const itemPriceRange of mainItemRanges) {
      const supportItemIndex = supportRanges.findIndex(
        (i) => i.fromQuantity === itemPriceRange.fromQuantity
      );
      if (supportItemIndex !== -1) {
        const supportPriceRange = supportRanges[supportItemIndex];
        itemPriceRange.price += supportPriceRange.price;
      }
    }
  }

  /**
   * Get the subscription plan items for a subscription plan.
   * In options return productTier, supportLevel, main and support item codes.
   * In case of support only subscription productTier will be empty.
   * @param subscriptionPlanId the subscription plan to get the items
   * @param subscriptionPlanDisplayName the subscription plan display name
   * @returns items list nand item options
   */
  private getSubscriptionPlanItems(subscriptionPlanId: number, planInfo: PlanInfo): SubscriptionPlanItem[] {
    const sql = `
    SELECT i.id,
      i.itemid         AS code,
      i.displayname    AS title,
      i.description,
      pl.isrequired,
      slt.key          AS chargetypeid,
      slt.name         AS chargetype,
      pb.id            AS pricebookid,
      pmt.name         AS pricetype,
      frequency AS frequency,
      cur.symbol       AS currency,
      pp.id            AS priceplanid,
      pt.fromval       AS fromquantity,
      pt.value         AS price,
      pt.pricingoption,
      pl.linenumber,
      i.maximumquantity,
      i.minimumquantity,
      sl.name as support_level_name,
      ptier.name as product_tier_name
    FROM   pricebook pb
      JOIN pricebooklineinterval pl
        ON pl.pricebook = pb.id
      JOIN item i
        ON pl.item = i.id
      JOIN priceplan pp
        ON pp.id = pl.priceplan
      JOIN pricetiers pt
        ON pt.priceplan = pp.id
      JOIN pricemodeltype pmt
        ON pmt.KEY = pp.priceplantype
      JOIN currency cur
        ON pb.currency = cur.id
      JOIN subscriptionlinetype slt
        ON slt.KEY = pl.chargetype
      LEFT JOIN customlist_support_level sl
        ON sl.id=i.custitem_support_level
      LEFT JOIN customlist_product_tier ptier
        ON ptier.id=i.custitem_product_tier
    WHERE  pb.subscriptionplan = ? and pb.name NOT LIKE '%DO NOT USE%'
    ORDER  BY pl.linenumber, pricebookid, fromquantity 
    `;
    const items = nsutils.queryToJson(sql, [subscriptionPlanId]) as SubscriptionPlanQueryItem[];
    nsutils.logMayBe('getSubscriptionPlan ' + subscriptionPlanId + ' items', items);

    const res: Array<SubscriptionPlanItem> = [];

    const subscriptionPlanItemBuilder = new SubscriptionPlanItemBuilder(
      planInfo,
      res
    );

    items.forEach((item) => {
      subscriptionPlanItemBuilder.buildItem(item);
    });

    res.forEach(item => {
      const itemCode = new ItemCode(item.code);
      if (!item.isSupportMainItem && itemCode.isSupport()) {
        const match = res.find(i => itemCode.isDifferentOnlyInSuffix(new ItemCode(i.code)));
        item.isSupportAddonItem = !!match;
      }
    })

    nsutils.logMayBe('getSubscriptionPlan res', {
      items: res
    });
    return res;
  }

  public getSubscriptionPlanById(subscriptionPlanId: number, getInactive = false): SubscriptionPlan {
    return this.getSubscriptionPlans({
      subscriptionPlanId: subscriptionPlanId,
      getInactive: getInactive,
    })[0];
  }

  public getSubscriptionPlanByCode(planCode: string, getInactive = false): SubscriptionPlan {
    return this.getSubscriptionPlans({
      subscriptionPlanCode: planCode,
      getInactive: getInactive,
    })[0];
  }

  public getSubscriptionPlanInfoById(subscriptionPlanId: number, getInactive = false): PlanInfo {
    return this.getSubscriptionPlanInfos({
      subscriptionPlanId: subscriptionPlanId,
      getInactive: getInactive,
    })[0];
  }

  /**
   * Extract 2-3 parts of subscription plan display name
   * E.g. for 'XXX-YYY-ZZZ-whatever' it will return 'YYY-ZZZ'
   * @returns undefined if not found or format is wrong or code is empty
   */
  public extractPVCFromPlanCode(planCode: string) {
    const groupIndex = 1;
    if (isNotBlank(planCode)) {
      const sPvcMatch = planCode.match(/[^-]+-([^-]+-[^-]+)-.+/);
      if (!sPvcMatch || sPvcMatch.length <= groupIndex) {
        return undefined;
      }
      return sPvcMatch[groupIndex];
    }
    return undefined;
  }
}

const MIN_PLAN_CODE_COMPONENTS = 5;
export class PlanCode {
  private _productCode = '';
  private _revenueType = '';
  private _itemCode = '';
  private _productTierCode = '';
  private _supportLevelCode = '';
  private _versionCode = '';
  private _isSupport = false;
  private _isValid = false;

  constructor(public planCode: string) {
    if (!planCode) {
      return;
    }
    const parts = planCode.split('-');
    this._isValid = parts.length >= MIN_PLAN_CODE_COMPONENTS;
    [this._productCode, this._revenueType, this._itemCode, this._productTierCode, this._supportLevelCode] = parts.slice(0, MIN_PLAN_CODE_COMPONENTS);
    let versionCodePart = MIN_PLAN_CODE_COMPONENTS;
    if (parts.length > MIN_PLAN_CODE_COMPONENTS) {
      if (parts[versionCodePart] === 'MNT') {
        this._isSupport = true;
        versionCodePart += 1;
      }
      this._versionCode = parts[versionCodePart];
    }
  }

  get productFamilyCode(): string {
    return this._productCode;
  }

  get productVariantCode(): string {
    return `${this._revenueType}-${this._itemCode}`;
  }

  get isValid(): boolean {
    return this._isValid;
  }

  get isSupport(): boolean {
    return this._isSupport;
  }
}

export default new SubscriptionPlanUtility();
