import * as nsutils from '../nsutils';
import * as record from 'N/record';
import { DynamicSublistWrapper } from '../models/DynamicSublistWrapper';
import { LineType, SupportLevel, SubscriptionTermType, ChargeFrequency, SupportLevelUtil, ProductTier } from '../types';
import { supportLevelDistributionRatio, supportLevelUptick } from '../models/SupportLevel';
import * as productCatalog from '../ProductCatalog';
import { assertNotNull, assertNotNullMsg, must } from '../validation';
import { SubscriptionConfigurationItem, AddonDiscount, Discounts } from '../models/SubscriptionParams';
import subscriptionGetUtility from './SubscriptionGetUtility';
import { clone, findLast, roundMoney } from './GeneralUtility';
import subscriptionValidateUtility from './SubscriptionValidateUtility';
import subscriptionPlanUtility, { PlanCode } from './SubscriptionPlanUtility';
import { ApiSubscription } from '../models/apitypes';
import { ItemPrice, PlanInfo, Price, PriceModelType, PriceTier, PriceTierType, SubscriptionIncludedItem,
  SubscriptionItem, SubscriptionItems, SubscriptionPlan, SubscriptionPlanItem, UptickPlanItem } from '../models/SubscriptionPlan';
import subscriptionDao from '../dao/SubscriptionDao';
import subscriptionPlanDao from '../dao/SubscriptionPlanDao';
import { ItemCode } from './SubscriptionItemUtility';
import { getParentIdFromSnapshot } from '../models/SubscriptionRecord';
import { MONTHS_IN_A_YEAR } from '../models/TermDuration';

export interface UptickParams {
  isLegacySubscription: boolean;
  isSupportOnlyPlan: boolean;
  isPlanDowngrade: boolean;
  isQuantityDowngrade: boolean;
  isSameEdition: boolean;
  isDraftRenewalCreation: boolean;
  isPreview: boolean;
  isDraftUpdate: boolean;
  uptickPercent: number;
  frequency: string;
  planItems: SubscriptionPlanItem[];
  discounts?: Discounts | null;
}

export class SubscriptionPriceUtility {
  private calcPriceAmount(tierType: string, tierPrice: number, quantity: number): number {
    if (PriceTierType[PriceTierType.Rate] === tierType) {
      return tierPrice * quantity;
    } else if (PriceTierType[PriceTierType.FixedAmount] === tierType) {
      return tierPrice;
    } else {
      throw new Error('Invalid tier type');
    }
  }

  private calcTieredPriceAmount(priceRanges: PriceTier[], quantity: number) {
    let curPrice = 0;
    let prevTier: { type: string; price: number; fromQuantity: number } | null = null;
    for (const tier of priceRanges) {
      if (quantity <= tier.fromQuantity) {
        break;
      }
      if (prevTier !== null) {
        curPrice += this.calcPriceAmount(prevTier.type, prevTier.price, tier.fromQuantity - prevTier.fromQuantity);
      }
      prevTier = tier;
    }
    if (prevTier !== null) {
      curPrice += this.calcPriceAmount(prevTier.type, prevTier.price, quantity - prevTier.fromQuantity);
    }

    return curPrice;
  }

  /**
   * Calculates the price amount for the given price ranges and quantity.
   * @param {PriceTier[]} priceRanges The price ranges.
   * @param {number} quantity The quantity.
   * @returns {number} The price amount.
   */
  private calcVolumePriceAmount(priceRanges: PriceTier[], quantity: number): number {

    // Find the price tier for the given quantity.
    const tier = findLast(
      priceRanges as { type: string; price: number; fromQuantity: number }[],
      (t) => t.fromQuantity <= quantity
    );
    assertNotNullMsg(tier, 'Cannot find applicable tier');

    // Calculate the price amount and return it.
    return this.calcPriceAmount(tier.type, tier.price, quantity);
  }

  /**
   * Calculates the price amount for the given price type, price ranges and the quantity.
   * @param {string} priceType The price type.
   * @param {PriceTier[]} priceRanges The price ranges.
   * @param {number} quantity The quantity.
   * @returns {number} The price amount.
   */
  private calcPriceAmountPerType(priceType: string, priceRanges: PriceTier[], quantity: number): number {
    if (priceType === 'Tiered') {
      return this.calcTieredPriceAmount(priceRanges, quantity);
    } else if (priceType === 'Volume') {
      return this.calcVolumePriceAmount(priceRanges, quantity);
    } else {
      throw new Error(`Invalid price type ${priceType}`);
    }
  }

  public calcItemTotalPrice(
    planItem: SubscriptionPlanItem,
    uptickedPrice: UptickPlanItem | null | undefined,
    quantity: number,
    currency: string,
    frequency: string,
    durationInMonth: number,
    discounts?
  ): {
    amount: number;
    recuringAmount: number;
    totalIntervalValue: number;
    totalListPrice: number;
  } {
    nsutils.logMayBe('calcItemTotalPrice params', { planItem, uptickedPrice, quantity, currency, frequency, durationInMonth, discounts });
    if (quantity === 0) {
      return { amount: 0, recuringAmount: 0, totalIntervalValue: 0, totalListPrice: 0 };
    }

    // Get the list price and the price.
    const listPrice = planItem.prices.find(
      (p) =>
        p.currency === currency &&
        (p.frequency?.toLowerCase() === frequency?.toLowerCase() || p.frequency === 'ONETIME')
    );
    nsutils.logMayBe('calcItemTotalPrice listPrice', listPrice);
    assertNotNullMsg(listPrice, `No list prices for specified frequency: ${frequency}. Item: ${planItem.code}`);
    const price = uptickedPrice
      ? uptickedPrice.price
      : clone(listPrice);
    nsutils.logMayBe('calcItemTotalPrice price', price);
    if (discounts) {
      this.applyDiscountInTiers(planItem.code, price.ranges, discounts);
    }

    // Calculcate the price amounts.
    const amount = this.calcPriceAmountPerType(price.type, price.ranges, quantity);
    const listPriceAmount = this.calcPriceAmountPerType(listPrice.type, listPrice.ranges, quantity);
    nsutils.logMayBe('calcItemTotalPrice amount listPriceAmount', { amount, listPriceAmount });
    // Return the different amounts based on the prices.
    const getTotalPriceAmount = (priceAmount: number, priceFrequency: string) => priceFrequency === 'ONETIME'
      ? priceAmount
      : priceAmount * this.getPriceIntervalCountInTerm(ChargeFrequency[must(priceFrequency.toPascalCase())], durationInMonth);
    nsutils.logMayBe('calcItemTotalPrice getTotalPriceAmount', getTotalPriceAmount);
    return {
      amount: amount,
      recuringAmount: price.frequency === 'ONETIME' ? 0 : amount,
      totalIntervalValue: getTotalPriceAmount(amount, price.frequency),
      totalListPrice: getTotalPriceAmount(listPriceAmount, listPrice.frequency),
    };
  }

  private getPriceIntervalCountInTerm(frequency: ChargeFrequency, termInMonth: number) {
    // if no term, returns the equivalent to 1 for each frequency
    // evergreen doesn't have duration
    if (!termInMonth) {
      switch (frequency) {
        case ChargeFrequency.Monthly:
          return 1;
        case ChargeFrequency.Weekly:
          return 1 / 4;
        case ChargeFrequency.Annually:
          return 12;
        case ChargeFrequency.Quarterly:
          return 3;
        default:
          throw new Error(`Not implemented for ${frequency}`);
      }
    }
    switch (frequency) {
      case ChargeFrequency.Monthly:
        return termInMonth;
      case ChargeFrequency.Weekly:
        return termInMonth * 4;
      case ChargeFrequency.Annually:
        return termInMonth / 12;
      case ChargeFrequency.Quarterly:
        return termInMonth / 3;
      default:
        throw new Error(`Not implemented for ${frequency}`);
    }
  }

  private getDiscountPercent(listedPrice, currentPrice, allowNegativeDiscounts, itemType) {
    if (itemType === LineType.OneTime) {
      return 1;
    }
    if (listedPrice === 0) {
      return 0;
    }
    return listedPrice > currentPrice || allowNegativeDiscounts ? (listedPrice - currentPrice) / listedPrice : 0;
  }

  /**
   * Return discount for subscription update
   */
  public getDiscountForUpdate(
    termType: SubscriptionTermType,
    isDowngrade: boolean,
    subscriptionId?: number,
    subscription?: ApiSubscription
  ): Discounts {
    nsutils.logMayBe('getDiscountForUpdate params', {
      termType: termType,
      isDowngrade: isDowngrade,
      subscriptionId: subscriptionId,
      subscription: subscription,
    });
    const currentDiscounts = this.getCurrentDiscount(subscriptionId, subscription, true);
    nsutils.logMayBe('getDiscountForUpdate currentDiscounts', currentDiscounts);
    // for downgrades in evergreen subscriptios, will get list prices or negative discounts (when price is higher than list prices)
    if (isDowngrade && termType === SubscriptionTermType.EVERGREEN) {
      if (currentDiscounts.mainItemDiscount > 0) {
        currentDiscounts.mainItemDiscount = 0;
      }
      currentDiscounts.addons.forEach((discount) => {
        if (discount.discount > 0) {
          discount.discount = 0;
        }
      });
      nsutils.logMayBe('getDiscountForUpdate currentDiscounts 1', currentDiscounts);
      return currentDiscounts;
    }
    nsutils.logMayBe('getDiscountForUpdate currentDiscounts 2', currentDiscounts);
    return currentDiscounts;
  }

  public getCurrentDiscount(
    subscriptionId?: number,
    subscription?: ApiSubscription,
    allowNegativeDiscounts = false
  ): Discounts {
    nsutils.logMayBe('getCurrentDiscount params', {
      subscriptionId: subscriptionId,
      subscription: subscription,
      allowNegativeDiscounts: allowNegativeDiscounts,
    });
    subscription = subscriptionGetUtility.assertAndGetSubscription(subscriptionId, subscription);
    const { symbol: currency } = subscriptionDao.getCurrency(subscription.id);
    nsutils.logMayBe('getCurrentDiscount subscription', subscription);
    const planCode = new PlanCode(subscription.plan.code);
    const newSubscriptionPlanId = subscriptionPlanDao.getLatestSubscriptionPlan(planCode.productFamilyCode,
      planCode.productVariantCode, subscription.plan.productTier || ProductTier.Standard,
      subscription.plan.supportLevel || SupportLevel.Silver, subscription.plan.isSupportOnly || false)?.id;
    const subscriptionPlan = productCatalog.getSubscriptionPlansForCustomer({
      subscriptionPlanId: newSubscriptionPlanId || subscription.plan.id,
      getInactive: true,
    })[0];
    nsutils.logMayBe('getCurrentDiscount subscriptionPlan', subscriptionPlan);
    const discount = {
      mainItemDiscount: 0,
      addons: [] as AddonDiscount[],
    };
    for (const item of subscriptionPlan.items) {
      nsutils.logMayBe('getCurrentDiscount item', item);
      const listedRanges = item.prices.find(
        (i) => i.currency === currency
          && (i.frequency.toLowerCase() === subscription!.term.frequency.toLowerCase() || i.frequency === 'ONETIME')
      )?.ranges;
      assertNotNullMsg(
        listedRanges,
        `Price frequency not found for item ${item.code} and frequency ${subscription.term.frequency}`
      );
      nsutils.logMayBe('getCurrentDiscount listedRanges', listedRanges);
      const currentRanges = subscription.items.find((i) => i.id === item.id)?.prices[0].ranges;
      if (!currentRanges) {
        continue;
      }
      nsutils.logMayBe('getCurrentDiscount currentRanges', currentRanges);
      const includedItem = subscription.includedItems.find((i) => i.id === item.id);
      const currentQuantity = includedItem ? includedItem.quantity : 0;

      nsutils.logMayBe('getCurrentDiscount currentRanges includedItem currentQuantity', {
        currentRanges,
        includedItem,
        currentQuantity,
      });

      // don't consider the price plan set if item is not in the subscription
      if (currentQuantity === 0) {
        continue;
      }

      // Calculate the current and listed prices.
      const { currentPrice, listedPrice } = this.getPricesFromRanges(currentRanges, listedRanges, currentQuantity);

      // for OneTime item set 100% discount which effectively zeroes price for it
      const discountValue = this.getDiscountPercent(listedPrice, currentPrice, allowNegativeDiscounts, item.type);
      nsutils.logMayBe('getCurrentDiscount currentPrice listedPrice discountValue', {
        currentPrice,
        listedPrice,
        discountValue,
      });
      if (item.isMainItem || item.isSupportMainItem) {
        discount.mainItemDiscount = discountValue;
        nsutils.logMayBe('getCurrentDiscount mainItemDiscount', discountValue);
      } else {
        const addon: AddonDiscount = {
          id: item.id,
          code: item.code,
          discount: discountValue,
        };
        if (discountValue === 1) {
          addon.freeQuantity = currentQuantity;
        }
        discount.addons.push(addon);
      }
    }

    nsutils.logMayBe('getCurrentDiscount result', discount);
    return discount;
  }

  private getPriceTierFromRanges(sortedTiers: PriceTier[], quantity: number): PriceTier {
    let result;
    for (const tier of sortedTiers) {
      if (tier.fromQuantity <= quantity) {
        result = tier;
      } else {
        break;
      }
    }
    return result;
  }

  /**
   * Calculates and returns the current and listed prices.
   * @param {PriceTier[]} currentRanges The current price tiers.
   * @param {Pricetier[]} listedRanges The listed price tiers.
   * @param {number} quantity The quantity.
   * @returns The prices.
   */
  private getPricesFromRanges(currentRanges: PriceTier[], listedRanges: PriceTier[], quantity: number): {
    currentPrice: number,
    listedPrice: number,
  } {

    // Retrieve the current range and the listed range.
    const currentRange = this.getPriceTierFromRanges(currentRanges, quantity);
    const listedRange = this.getPriceTierFromRanges(listedRanges, quantity);

    // Determine how to get total price.
    // - If the price tier types are different, the rate price must be multiplied by the quantity.
    const getTotalPrice = (range: PriceTier) => range.price
      * (currentRange.type === listedRange.type || range.type === PriceTierType[PriceTierType.FixedAmount] ? 1 : quantity);

    // Return the current and listed prices.
    return {
      currentPrice: getTotalPrice(currentRange),
      listedPrice: getTotalPrice(listedRange),
    };
  }

  public createNewPricePlan(basePricePlanId: number, discount: number, freeQuantity?: number) {
    nsutils.logMayBe('createNewPricePlan params', {
      basePricePlanId: basePricePlanId,
      discount: discount,
      freeQuantity: freeQuantity,
    });
    const newPricePlanRec = record.create({
      type: record.Type.PRICE_PLAN,
      isDynamic: true,
    });
    // 100% discount, only needed to create one item with 0 value
    if (discount === 1) {
      this.createPriceTier(newPricePlanRec, 0, 0, PriceTierType.FixedAmount);
      return newPricePlanRec.save();
    }

    const pricePlanRec = record.load({
      type: record.Type.PRICE_PLAN,
      id: basePricePlanId,
      isDynamic: true,
    });
    nsutils.logMayBe('createNewPricePlan pricePlanRec', pricePlanRec);
    newPricePlanRec.setValue('priceplantype', pricePlanRec.getValue('priceplantype'));
    const priceTiers = new DynamicSublistWrapper(pricePlanRec, 'pricetiers');
    nsutils.logMayBe('createNewPricePlan priceTiers', priceTiers);
    if (freeQuantity) {
      this.createTiersWithFreeQuantity(newPricePlanRec, priceTiers, discount, freeQuantity);
    } else {
      while (priceTiers.nextLine()) {
        const listedPrice = priceTiers.getFieldValue('value') as number;
        const newPrice = this.calculatePrice(listedPrice, discount);
        this.createPriceTierFromAnother(priceTiers, newPricePlanRec, newPrice);
      }
    }
    nsutils.logMayBe('createNewPricePlan newPricePlanRec', newPricePlanRec);
    return newPricePlanRec.save();
  }

  public applyDiscount(discountPercentage: number, pricePlanId, freeQuantity?: number) {
    nsutils.logMayBe('applyDiscount params', {
      discountPercentage: discountPercentage,
      pricePlanId: pricePlanId,
      freeQuantity: freeQuantity,
    });

    assertNotNull(pricePlanId, 'pricePlanId');
    if (discountPercentage === 0 && !freeQuantity) {
      return undefined;
    }
    return this.createNewPricePlan(pricePlanId, discountPercentage, freeQuantity);
  }

  private createTiersWithFreeQuantity(pricePlanRec, priceTiers, discount: number, freeQuantity: number) {
    const tier = {
      number: 0,
      fromVal: 0,
      price: 0,
      pricingOption: 0,
    };
    while (priceTiers.nextLine()) {
      switch (tier.number) {
        case 0:
          this.setTierValues(tier, priceTiers, discount);
          tier.number = 1;
          this.createPriceTier(pricePlanRec, 0, 0, tier.pricingOption);
          break;
        case 1:
          if (freeQuantity < parseInt(priceTiers.getFieldValue('fromval')?.toString() as string)) {
            this.createPriceTier(pricePlanRec, freeQuantity, tier.price, tier.pricingOption);
            this.setTierValues(tier, priceTiers, discount);
            this.createPriceTier(pricePlanRec, tier.fromVal, tier.price, tier.pricingOption);
            tier.number = 2;
            break;
          }
          this.setTierValues(tier, priceTiers, discount);
          break;
        default:
          this.setTierValues(tier, priceTiers, discount);
          this.createPriceTier(pricePlanRec, tier.fromVal, tier.price, tier.pricingOption);
          break;
      }
    }
    if (tier.number === 1) {
      this.createPriceTier(pricePlanRec, freeQuantity, tier.price, tier.pricingOption);
    }
  }

  private setTierValues(tier, priceTiers, discount) {
    tier.fromVal = priceTiers.getFieldValue('fromval');
    tier.price = this.calculatePrice(priceTiers.getFieldValue('value'), discount);
    tier.pricingOption = priceTiers.getFieldValue('pricingoption');
  }

  private createPriceTierFromAnother(oldPriceTiers, newPricePlanRec, newPrice) {
    this.createPriceTier(
      newPricePlanRec,
      oldPriceTiers.getFieldValue('fromval'),
      newPrice,
      oldPriceTiers.getFieldValue('pricingoption')
    );
  }

  public createPriceTier(pricePlanRec, fromVal, newPrice, pricingOption) {
    pricePlanRec.selectNewLine({ sublistId: 'pricetiers' });
    pricePlanRec.setCurrentSublistValue({ sublistId: 'pricetiers', fieldId: 'fromval', value: fromVal });
    pricePlanRec.setCurrentSublistValue({ sublistId: 'pricetiers', fieldId: 'value', value: newPrice });
    pricePlanRec.setCurrentSublistValue({ sublistId: 'pricetiers', fieldId: 'pricingoption', value: pricingOption });
    pricePlanRec.commitLine({ sublistId: 'pricetiers' });
  }

  private applyDiscountInTiers(itemCode: string, tiers, discounts, negativeDiscount = false): boolean {
    nsutils.logMayBe('applyDiscountInTiers params', {
      itemCode: itemCode,
      tiers: tiers,
      discounts: discounts,
      negativeDiscount: negativeDiscount,
    });

    if (!discounts || !tiers) {
      nsutils.logMayBe('applyDiscountInTiers !discounts || !tiers', 'return false');
      return false;
    }
    const addonDiscount = discounts.addons?.find(
      (i) => i.code === itemCode || ItemCode.isDifferentOnlyInSuffix(i.code, itemCode)
    );
    const discountToApply = addonDiscount ? addonDiscount.discount : discounts.mainItemDiscount;
    if (negativeDiscount && discountToApply >= 0) {
      nsutils.logMayBe('applyDiscountInTiers negativeDiscount && discountToApply >= 0', 'return false');
      return false;
    }

    for (const tier of tiers) {
      tier.price = this.calculatePrice(tier.price, discountToApply);
    }
    nsutils.logMayBe('applyDiscountInTiers tiers', tiers);
    return true;
  }

  private calculatePrice(listedPrice: number, discount: number): number {
    const price = roundMoney(listedPrice * (1 - discount));
    nsutils.logMayBe('calculatePrice price', { price: price, listedPrice: listedPrice, discount: discount });
    return price;
  }

  public calcModifiedPrices(
    isUptickEnabled: boolean,
    isDraftRenewalCreation: boolean,
    isPreview: boolean,
    isDraftUpdate: boolean,
    newPlan: SubscriptionPlan,
    newFrequency: string,
    subscriptionItems: SubscriptionItems,
    draftItems?: SubscriptionItems,
    draftPlanInfo?: PlanInfo,
    parentSubscriptionId?: number,
    parentSubscription?: ApiSubscription,
    parentPlanInfo?: PlanInfo
  ): UptickPlanItem[] | null {
    nsutils.logMayBe('calcModifiedPrices params', {
      isUptickEnabled,
      isDraftRenewalCreation,
      isPreview,
      isDraftUpdate,
      newPlan,
      newFrequency,
      subscriptionItems,
      draftItems,
      draftPlanInfo,
      parentSubscriptionId,
      parentSubscription,
      parentPlanInfo,
    });

    let uptickPrices: UptickPlanItem[] | null = null;

    if (isUptickEnabled) {
      // calculate possible uptick
      uptickPrices = this.calcUptickPrices(
        newPlan,
        newFrequency,
        isDraftRenewalCreation,
        isPreview,
        isDraftUpdate,
        subscriptionItems,
        draftItems,
        draftPlanInfo,
        parentSubscriptionId,
        parentSubscription,
        parentPlanInfo
      );
    }
    // get subscription items

    return this.calcOneTimePrices(uptickPrices, subscriptionItems.availableItems);
  }

  public calcOneTimePrices(
    uptickPrices: UptickPlanItem[] | null,
    availableItems: SubscriptionItem[]
  ): UptickPlanItem[] | null {
    nsutils.logMayBe('calcOneTimePrices params', { uptickPrices, availableItems });
    let modifiedPrices = uptickPrices;
    // if no uptick prices and there are some ONETIME items in the subscription, create prices
    if (!modifiedPrices && availableItems.some((i) => i.prices.some((p) => p.frequency === 'ONETIME'))) {
      modifiedPrices = availableItems
        .filter((i) => i.prices.length > 0)
        .map((i) => {
          return {
            id: i.id,
            price: i.prices[0],
          };
        });
    }

    if (modifiedPrices) {
      // modify uptickPrices ONETIME items if any
      modifiedPrices
        .filter((u) => u.price.frequency === 'ONETIME')
        .forEach((u) => {
          u.price.ranges.forEach((r) => {
            r.price = 0;
          });
        });
    }

    nsutils.logMayBe('calcOneTimePrices modifiedPrices', modifiedPrices);

    return modifiedPrices;
  }

  public calcUptickPrices(
    newPlan: SubscriptionPlan,
    newFrequency: string,
    isDraftRenewalCreation: boolean,
    isPreview: boolean,
    isDraftUpdate: boolean,
    subscriptionItems: SubscriptionItems,
    draftItems?: SubscriptionItems,
    draftPlanInfo?: PlanInfo,
    parentSubscriptionId?: number,
    parentSubscription?: ApiSubscription,
    parentPlanInfo?: PlanInfo
  ): UptickPlanItem[] | null {
    nsutils.logMayBe('calcUptickPrices params', {
      newPlan,
      newFrequency,
      isDraftRenewalCreation,
      isPreview,
      isDraftUpdate,
      subscriptionItems,
      draftItems,
      draftPlanInfo,
      parentSubscriptionId,
      parentSubscription,
      parentPlanInfo,
    });

    if (!subscriptionItems.mainItem && !subscriptionItems.supportItem) {
      // ignore upticket since we need at least main or support item
      nsutils.logMayBe('calcUptickPrices no support or main item', subscriptionItems.mainItem);
      return null;
    }

    // get parent subscription if not passed
    if (!parentSubscription) {
      if (!parentSubscriptionId) {
        nsutils.logDebug('calcUptickPrices', `Not applied. No parent subscription.`);
        return null;
      } 
      parentSubscription = subscriptionGetUtility.getSubscriptionByIdInternal(parentSubscriptionId);
      parentPlanInfo = subscriptionPlanUtility.getSubscriptionPlanInfoById(parentSubscription.plan.id);
    }

    this.fixItemsForSupportLegacySubscriptions(subscriptionItems, parentSubscription);
    nsutils.logMayBe('calcUptickPrices subscriptionItems', subscriptionItems);
    nsutils.logMayBe('calcUptickPrices parentSubscription', parentSubscription);

    // Don’t consider reducing the success level as a downgrade scenario for uptick / LAMBDA-66618 
    // https://docs.google.com/document/d/1kgHkowk3oFRKKbjftrT-prw1K14fptxxNwIxt0OAF50/edit?pli=1#heading=h.qkit4s4jysrh
    // Informing same success level to not consider success level change as downgrade
    const isPlanDowngrade = subscriptionValidateUtility.isPlanDowngrade(
      parentPlanInfo!.productTier,
      newPlan.supportLevel,
      newPlan.productTier,
      newPlan.supportLevel
    );

    const isSameEdition = parentSubscription.plan.productTier === newPlan.productTier;

    nsutils.logMayBe('calcUptickPrices isSameEdition', {
      parentProductTier: parentSubscription.plan.productTier,
      newProductTier: newPlan.productTier,
    });

    const newItems: SubscriptionConfigurationItem[] = [
      {
        code: must(
          subscriptionItems.mainItem?.item.code || subscriptionItems.supportItem?.item.code,
          'support or main item'
        ),
        quantity: must(
          subscriptionItems.mainItem?.quantity || subscriptionItems.supportItem?.quantity,
          'support or main item'
        ),
      },
    ];

    const isQuantityDowngrade = subscriptionValidateUtility.isQuantityDowngrade(
      parentSubscription,
      parentPlanInfo!,
      newItems,
      newPlan
    );

    const discounts = this.getDiscounts(
      isPlanDowngrade,
      isQuantityDowngrade,
      isSameEdition,
      parentSubscription.plan.id === newPlan.id,
      parentSubscription,
      parentPlanInfo?.isLegacyPlan
    );

    const plan = clone(newPlan);
    subscriptionPlanUtility.addSupportPricesToItems(plan);
    const uptickParams: UptickParams = {
      isLegacySubscription: must(parentPlanInfo?.isLegacyPlan),
      isSupportOnlyPlan: newPlan.supportOnly,
      isPlanDowngrade: isPlanDowngrade,
      isQuantityDowngrade: isQuantityDowngrade,
      isSameEdition: isSameEdition,
      isDraftRenewalCreation: isDraftRenewalCreation,
      isPreview: isPreview,
      isDraftUpdate: isDraftUpdate,
      uptickPercent: supportLevelUptick(newPlan.supportLevel),
      frequency: newFrequency,
      planItems: plan.items,
      discounts: discounts,
    };
    nsutils.logMayBe('calcUptickPrices uptickParams', uptickParams);

    let updatedAvailableItems = subscriptionItems.availableItems;
    let updatedSupportItems = subscriptionItems.supportItems;
    nsutils.logMayBe('calcUptickPrices up1', {updatedAvailableItems: updatedAvailableItems, updatedSupportItems: updatedSupportItems});

    let uptickedPrices: UptickPlanItem[];
    try {

      // Try to get the uptick prices with the default calculation.
      uptickedPrices = this.calculateDefaultUptickPrices(
        subscriptionGetUtility.addSupportPricesToItems(updatedAvailableItems, updatedSupportItems),
        parentSubscription,
        uptickParams
      );
    } catch(e) {

      // If the calculation failed for a legacy subscription, apply the fallback calculation; else, rethrow the error.
      if (uptickParams.isLegacySubscription) {
        this.sendEmailWhenDefaultUptickCalculationFailedForLegacySubscriptions(e as Error, parentSubscription, uptickParams);
        uptickedPrices = this.calculateFallbackUptickPricesForLegacySubscriptions(parentSubscription, newPlan, uptickParams);
      } else {
        throw e;
      }
    }

    nsutils.logMayBe('calcUptickPrices uptickedPrices', uptickedPrices);
    nsutils.logMayBe('calcUptickPrices up2', {updatedAvailableItems: updatedAvailableItems, updatedSupportItems: updatedSupportItems});
    // calculating main and support items based on parent subscription because we can have different distributions in some situations
    const supportMultiplier = this.getMainAndSupportDistributionRatioForUptick(
      parentSubscription,
      must(parentPlanInfo?.isLegacyPlan),
      parentPlanInfo?.supportLevel === newPlan.supportLevel,
      newPlan,
      draftItems,
      subscriptionItems.mainItem?.item,
      subscriptionItems.supportItem?.item
    );
    nsutils.logMayBe('calcUptickPrices supportMultiplier', supportMultiplier);
    this.applyDistributionRatioToSupportItems(
      supportMultiplier,
      uptickedPrices,
      updatedSupportItems,
      updatedAvailableItems
    );
    return uptickedPrices;
  }

  // legacy subscription can have both items and still be support only
  // fixing to have the support item as available item in this case
  private fixItemsForSupportLegacySubscriptions(subscriptionItems, parentSubscription) {
    if (parentSubscription.plan.isLegacy && parentSubscription.plan.isSupportOnly) {
      subscriptionItems.availableItems = subscriptionItems.availableItems.filter(
        (p) => p.id !== subscriptionItems.mainItem?.item.id
      );
      subscriptionItems.availableItems.push(
        ...subscriptionItems.supportItems.filter((p) => p.id === subscriptionItems.supportItem?.item.id)
      );
      subscriptionItems.mainItem = null;
    }
  }

  private getDiscounts(
    isPlanDowngrade: boolean,
    isQuantityDowngrade: boolean,
    isSameEdition: boolean,
    isSamePlan: boolean,
    parentSubscription: ApiSubscription,
    isLegacyPlan = false
  ): Discounts | null {
    nsutils.logMayBe('getDiscounts params', {
      isPlanDowngrade,
      isQuantityDowngrade,
      isSameEdition,
      isSamePlan,
      parentSubscription,
    });

    // Calculcate the discounts only for required scenarios.
    let discounts: Discounts | null;
    if (isPlanDowngrade || isQuantityDowngrade || !isSameEdition || !isSamePlan) {
      discounts = this.getCurrentDiscount(undefined, parentSubscription, true);
    } else {
      discounts = null;
    }

    // Return the discounts.
    nsutils.logMayBe('getDiscounts res', discounts);
    return discounts;
  }

  /**
   * Sends an email with error and contextual details when the uptick calculation failed for a legacy subscription
   * @param {Error} error The error.
   * @param {ApiSubscription} parentSubscription The parent subscription.
   * @param {UptickParams} uptickParams The parameters for the uptick calculation.
   */
  private sendEmailWhenDefaultUptickCalculationFailedForLegacySubscriptions(error: Error, parentSubscription: ApiSubscription, uptickParams: UptickParams) {
    nsutils.sendEmail(['rp-si@trilogy.com'], 'Uptick calculation failed for a legacy subscription',
`An error happened when trying to calculate the uptick prices for the legacy subscription ${parentSubscription.id}.
The fallback approach will be applied.

ERROR DETAILS
${error}

UPTICK PARAMS
${JSON.stringify(uptickParams)}`);
  }

  /**
   * Calculates the uptick prices by carrying over the parent subscription ARR to the main or support item.
   * It represents the fallback approach for legacy subscriptions when the classical uptick calculation failed.
   * @param {ApiSubscription} parentSubscription The parent subscription.
   * @param {SubscriptionPlan} newPlan The target subscription plan.
   * @param {UptickParams} uptickParams The parameters for the uptick calculation.
   * @returns The uptick prices.
   */
  private calculateFallbackUptickPricesForLegacySubscriptions(parentSubscription: ApiSubscription, newPlan: SubscriptionPlan, uptickParams: UptickParams): UptickPlanItem[] {

    // Find the main or the support item, and its price.
    const planItemCode = newPlan.supportOnly ? newPlan.supportItemCode : newPlan.mainItemCode;
    const planItem = newPlan.items.find(i => i.code === planItemCode);
    if (!planItem) {
      throw new Error(`Cannot retrieve the main or the support item to apply the upticked ARR for the legacy subscription ${parentSubscription.id}.`);
    }
    const planItemPrice = this.findTiers(uptickParams.planItems, planItem.id, uptickParams.frequency, parentSubscription.currency);
    if (!planItemPrice) {
      throw new Error(`Cannot retrieve the main or the support item price to apply the upticked ARR for the legacy subscription ${parentSubscription.id}.`);
    }

    // Calculate the ARR for the parent subscription. Don't consider the quantity of items, as the total ARR will be carried over.
    const parentSubscriptionArr = parentSubscription.includedItems
      .map((includedItem) => must(parentSubscription.items.find((item) => item.id === includedItem.id)))
      .sum((item) => this.getItemArr(item));

    // Set the uptick price as the upticked ARR of the parent subscription. The target quantity is 1.
    const price = clone(planItemPrice);
    price.ranges.splice(1);
    const multiplier = (1 + uptickParams.uptickPercent)
        / (price.ranges[0].frequency === 'MONTHLY' ? MONTHS_IN_A_YEAR : 1);
    price.ranges[0].price = roundMoney(parentSubscriptionArr * multiplier);

    // Return the uptick prices.
    return [ { id: planItem.id, price } ];
  }

  public applyModifiedPrices(
    subscriptionRec,
    isUptickEnabled: boolean,
    isDraftRenewalCreation: boolean,
    isPreview: boolean,
    isDraftUpdate: boolean,
    draftItems?: SubscriptionItems,
    draftPlanInfo?: PlanInfo,
    parentSubscription?: ApiSubscription
  ): string {
    const subscriptionSnapshot = clone(subscriptionRec);
    nsutils.logMayBe('applyModifiedPrices params', {
      subscriptionRec,
      isUptickEnabled,
      isDraftRenewalCreation,
      isPreview,
      draftItems,
    });

    const { plan, subscriptionItems } =
      subscriptionGetUtility.getSubscriptionRecItems(subscriptionSnapshot);
    const newFrequency = subscriptionPlanDao.getFrequencyFromPriceBook(subscriptionSnapshot.fields.pricebook);
    const parentSubscriptionId = getParentIdFromSnapshot(subscriptionSnapshot);
    assertNotNull(parentSubscriptionId, 'parent subscription id');

    parentSubscription = !parentSubscription
      ? subscriptionGetUtility.getSubscriptionByIdInternal(parentSubscriptionId)
      : parentSubscription;

    const parentPlanInfo = parentSubscription
      ? subscriptionPlanUtility.getSubscriptionPlanInfoById(parentSubscription.plan.id)
      : undefined;

    const modifiedPrices = this.calcModifiedPrices(
      isUptickEnabled,
      isDraftRenewalCreation,
      isPreview,
      isDraftUpdate,
      plan,
      newFrequency,
      subscriptionItems,
      draftItems,
      draftPlanInfo,
      parentSubscriptionId,
      parentSubscription,
      parentPlanInfo
    );
    if (modifiedPrices) {
      this.applyAndSavePricePlan(subscriptionRec, modifiedPrices);
      return 'Applied';
    } else {
      return 'Not applied';
    }
  }

  private getIncludedItem(
    item: SubscriptionItem,
    subscription: ApiSubscription
  ): SubscriptionIncludedItem | undefined {

    // Try to find the included item by id.
    let includedItem = subscription.includedItems.find((i) => i.id === item.id);

    // Try to find the included item by the main item or support item (maintenance) flags.
    if (!includedItem && item.required) {
      const parentItem = subscription.items.find((i) => i.isMainItem || i.isSupportMainItem);
      if (parentItem) {
        includedItem = subscription.includedItems.find((i) => i.id === parentItem.id);
      }
    }

    // Try to find the included item by code.
    if (!includedItem) {
      const matchedItems = subscription.includedItems.filter(i => ItemCode.isDifferentOnlyInSuffix(i.code, item.code));
      if (matchedItems.length === 1) {
        includedItem = matchedItems[0];
      }
    }

    return includedItem;
  }

  private getUptickPricesForItemPriceIsHigherThanParent(
    item: SubscriptionItem,
    parentItem: SubscriptionItem,
    listPrice: ItemPrice,
    uptickParams
  ) {
    const itemPrice2 = clone(listPrice);
    // if plan downgrade, apply negative discount and apply uptick
    if (uptickParams.isPlanDowngrade) {
      // if discount is not applied is because is list prices and no uptick is necessary
      if (this.applyDiscountInTiers(item.code, itemPrice2.price.ranges, uptickParams.discounts, true)) {
        this.uptickPrices(itemPrice2.price.ranges, uptickParams.uptickPercent);
      }
      nsutils.logMayBe(
        'getUptickPricesForItem itemPrice - currentPrice > renewalListPrice && isPlanDowngrade',
        itemPrice2
      );
      return itemPrice2;
    }
    if (uptickParams.isQuantityDowngrade) {
      this.applyDiscountInTiers(item.code, itemPrice2.price.ranges, uptickParams.discounts, true);
      nsutils.logMayBe(
        'getUptickPricesForItem itemPrice - currentPrice > renewalListPrice && isQuantityDowngrade',
        itemPrice2
      );
      return itemPrice2;
    }
    const res = {
      id: item.id,
      price: parentItem.prices[0],
    };
    nsutils.logMayBe(
      'getUptickPricesForItem itemPrice - currentPrice > renewalListPrice && !isPlanDowngrade && !isQuantityDowngrade',
      res
    );
    return res;
  }

  private getUptickPricesForItemNotIncludedInParent(
    item: SubscriptionItem,
    listPrice: ItemPrice,
    planItemPrice: Price,
    uptickParams: UptickParams
  ) {
    // if is addon item
    if (!(item.isMainItem || item.isSupportMainItem)) {

      //list prices if is downgrade and discounts are not negative
      if ((uptickParams.isPlanDowngrade || uptickParams.isQuantityDowngrade) && (!uptickParams.discounts || uptickParams.discounts.mainItemDiscount >= 0)) {
        nsutils.logMayBe('getUptickPricesForItem itemPrice - params.isPlanDowngrade || params.isQuantityDowngrade', {});
        return listPrice;
      }

      const itemPrice = clone(listPrice);
      if (this.applyDiscountInTiers(item.code, itemPrice.price.ranges, uptickParams.discounts)) {
        this.uptickPrices(itemPrice.price.ranges, uptickParams.uptickPercent);
      }

      // For a legacy subscription, don't cap by the list price.
      if (!uptickParams.isLegacySubscription) {
        itemPrice.price.ranges = this.getTiersCappedByListPrice(itemPrice.price.ranges, planItemPrice.ranges);
      }

      nsutils.logMayBe('getUptickPricesForItemNotIncludedInParent addon item', itemPrice);
      return itemPrice;
    } else {
      // return list prices
      nsutils.logMayBe('getUptickPricesForItemNotIncludedInParent - for main or support item - list price', listPrice);
      return listPrice;
    }
  }

  // this is the current uptick process (based on checking list prices in several scenarios)
  // https://docs.google.com/document/d/1kBC4oogRhdDQnxICQYgQSCviiXKYdXLX0T3Q48gvGGg/edit
  private getUptickPricesForItem(
    item: SubscriptionItem,
    parentSubscription: ApiSubscription,
    uptickParams: UptickParams
  ): ItemPrice {
    const parentIncludedItem = this.getIncludedItem(item, parentSubscription);
    const planItemPrice = this.findTiers(uptickParams.planItems, item.id, uptickParams.frequency, parentSubscription.currency);
    const listPrice = {
      id: item.id,
      price: planItemPrice,
    } as ItemPrice;

    // if item is not included in parent subscription
    if (!parentIncludedItem) {
      assertNotNullMsg(
        planItemPrice,
        `Price frequency not found for item id ${item.id} (code: ${item.code}) and frequency ${uptickParams.frequency}`
      );
      // if is a new addon item, apply discount and uptick, else return list prices
      return this.getUptickPricesForItemNotIncludedInParent(item, listPrice, planItemPrice, uptickParams);
    }

    const parentItem = must(
      parentSubscription.items.find((i) => i.id === parentIncludedItem.id),
      'parentItem'
    );
    let itemPrice = {
      id: item.id,
      price: clone(parentItem.prices[0]),
    };
    if (!planItemPrice || planItemPrice.ranges[0].price === 0) {
      this.uptickPrices(itemPrice.price.ranges, uptickParams.uptickPercent);
      return itemPrice;
    }

    const currentPrice = this.calcPriceAmountPerType(parentItem.prices[0].type, parentItem.prices[0].ranges, parentIncludedItem.quantity);
    const renewalListPrice = this.calcPriceAmountPerType(listPrice.price.type, listPrice.price.ranges, parentIncludedItem.quantity);
    nsutils.logMayBe('getUptickPricesForItem currentPrice renewalListPrice', { currentPrice, renewalListPrice });

    // if current price is higher, keep the current price if not plan downgrade
    if (currentPrice > renewalListPrice) {
      return this.getUptickPricesForItemPriceIsHigherThanParent(item, parentItem, listPrice, uptickParams);
    }

    if (uptickParams.isPlanDowngrade || uptickParams.isQuantityDowngrade) {
      nsutils.logMayBe('getUptickPricesForItem itemPrice - params.isPlanDowngrade || params.isQuantityDowngrade', {});
      return listPrice;
    }

    // if edition is not the same, use list prices and apply same discount
    if (!uptickParams.isSameEdition) {
      itemPrice = clone(listPrice);
      this.applyDiscountInTiers(item.code, itemPrice.price.ranges, uptickParams.discounts);
    }

    nsutils.logMayBe('getUptickPricesForItem edition itemPrice before uptick', itemPrice);

    this.uptickPrices(itemPrice.price.ranges, uptickParams.uptickPercent);

    // For a legacy subscription, don't cap by the list price.
    if (planItemPrice && !uptickParams.isLegacySubscription) {
      itemPrice.price.ranges = this.getTiersCappedByListPrice(itemPrice.price.ranges, planItemPrice.ranges);
    }

    nsutils.logMayBe('getUptickPricesForItem itemPrice', itemPrice);
    return itemPrice;
  }

  // apply the renewal codes to the items and merges the items that have the same code
  private applyRenewalCodes(parentSubscription: ApiSubscription) {
    nsutils.logMayBe('applyRenewalCodes parentSubscription', parentSubscription);

    // keep only the included items, non included items don't impact the prices
    parentSubscription.items = parentSubscription.items.filter((item) =>
      parentSubscription.includedItems.find((i) => i.id === item.id)
    );

    if (!parentSubscription.items) {
      return;
    }

    const itemsChanged = this.assignRenewItemCode(parentSubscription);
    nsutils.logMayBe('applyRenewalCodes itemsChanged', itemsChanged);

    const { newItems, mergedItemIds } = this.mergeItems(parentSubscription);
    nsutils.logMayBe('applyRenewalCodes mergeItems', { newItems,  mergedItemIds });

    // fix the quantity and the code in the included items
    parentSubscription.includedItems.forEach((item) => {
      const newItem = newItems.find((i) => i.id === item.id);
      if (newItem) {
        item.code = newItem.code;
        item.quantity = newItem.quantity;
      }
    });
    nsutils.logMayBe('applyRenewalCodes parentSubscription.includedItems', parentSubscription.includedItems);

    // remove the merged items from the included items
    parentSubscription.includedItems = parentSubscription.includedItems.filter(
      (item) => !mergedItemIds.find((i) => i === item.id)
    );
    nsutils.logMayBe('applyRenewalCodes parentSubscription.includedItems2', parentSubscription.includedItems);

    // fix the ids in the new parent items
    // doing only now because the ids can only be changed after the included items are removed
    this.fixIdsForNewItems(parentSubscription, newItems, itemsChanged);
    nsutils.logMayBe('applyRenewalCodes newParentItems3', newItems);

    parentSubscription.items = newItems;
  }

  // assigns the renew item code to the code and returns the items that have changed
  private assignRenewItemCode(parentSubscription: ApiSubscription): { oldId: number, newId: number }[] {
    const itemsChanged: { oldId: number, newId: number }[] = [];
    parentSubscription.items.forEach((item) => {
      if (item.renewItemCode) {
        itemsChanged.push({
          oldId: item.id,
          newId: must(item.renewItemId)
        });
        item.code = item.renewItemCode;
      }
    });
    return itemsChanged;
  }

  // merges the items that have the same code summing amounts and quantity
  // it returns the new items merged, this items will be the new items in the subscription
  // the merged item ids are the ids of items merged that can be removed from the subscription
  private mergeItems(parentSubscription: ApiSubscription): {
    newItems: SubscriptionItem[],
    mergedItemIds: number[],
  } {
    const newItems: SubscriptionItem[] = [];
    const mergedItemIds: number[] = [];
    // merged unique items will contain the merged items to calculate the correct price later
    const mergedUniqueItems: SubscriptionItem[] = [];
    parentSubscription.items.forEach((item) => {
      const existingItem = newItems.find((i) =>
        new ItemCode(i.code).codeWOSuffix() === new ItemCode(item.code).codeWOSuffix()
      );
      if (existingItem) {
        existingItem.amount += item.amount;
        existingItem.totalIntervalValue += item.totalIntervalValue;
        existingItem.recuringAmount += item.recuringAmount;
        // we don't want to change the quantity of main and support items
        if (!existingItem.isMainItem && !existingItem.isSupportMainItem) {
          if (item.recuringAmount >= 0) {
            existingItem.quantity += item.quantity;
          } else {
            existingItem.quantity -= item.quantity;
          }
        }
        mergedItemIds.push(item.id);
        if (!mergedUniqueItems.find((i) => i.id === existingItem.id)) {
          mergedUniqueItems.push(existingItem);
        }
      } else {
        newItems.push(item);
      }
    });

    this.calculatePriceForMergedItems(mergedUniqueItems);
    return { newItems, mergedItemIds };
  }

  private calculatePriceForMergedItems(mergedUniqueItems: SubscriptionItem[]): void {
    mergedUniqueItems.forEach((item) => {
      const firstRange = item.prices[0].ranges[0];
      switch (firstRange.type) {
        case PriceTierType[PriceTierType.Rate]:
          item.prices[0].ranges[0].price = item.quantity > 0 ?
            item.recuringAmount / item.quantity : item.recuringAmount;
          break;
        case PriceTierType[PriceTierType.FixedAmount]:
          item.prices[0].ranges[0].price = item.recuringAmount;
          break;
        default:
          throw new Error(`Price model type ${firstRange.type} not supported`);
      }
      item.prices[0].ranges.splice(1);
    });
  }

  private fixIdsForNewItems(parentSubscription: ApiSubscription, newItems: SubscriptionItem[],
    itemsChanged: { oldId: number, newId: number }[]): void {
    newItems.forEach((item) => {
      const changedItem = itemsChanged.find((i) => i.oldId === item.id);
      if (changedItem) {
        const includedItem = parentSubscription.includedItems.find((i) => i.id === item.id);
        if (includedItem) {
          includedItem.id = changedItem.newId;
        }
        item.id = changedItem.newId;
      }
    });
  }

  private calculateDefaultUptickPrices(
    subscriptionItems: SubscriptionItem[],
    parentSubscription: ApiSubscription,
    uptickParams: UptickParams
  ): UptickPlanItem[] {
    nsutils.logMayBe('calculateDefaultUptickPrices params', {
      subscriptionItems,
      parentSubscription,
      uptickParams,
    });

    this.applyRenewalCodes(parentSubscription);
    nsutils.logMayBe('calculateDefaultUptickPrices parentSubscription', parentSubscription);

    // Calculate the uptick prices for each item.
    const prices: {
      id: number;
      price: Price;
    }[] = [];
    for (const item of subscriptionItems) {
      prices.push(this.getUptickPricesForItem(item, parentSubscription, uptickParams));
    }
    nsutils.logMayBe('calculateDefaultUptickPrices prices', prices);

    // For a legacy subscription, carry over the ARR of any missing items to the main/support item price.
    if (uptickParams.isLegacySubscription) {
      this.carryOverMissingItemsArrForLegacySubscriptions(subscriptionItems, parentSubscription, uptickParams, prices);
    }
    nsutils.logMayBe('calculateDefaultUptickPrices prices2', prices);

    return prices;
  }

  private findTiers(
    planItems: SubscriptionPlanItem[],
    itemId: number,
    frequency: string,
    currency: string
  ): Price | undefined {
    const planItem = planItems.find((i) => i.id === itemId);
    return planItem?.prices.find(
      (i) => (i.frequency.toLowerCase() === frequency.toLowerCase() || i.frequency === 'ONETIME') && i.currency === currency
    );
  }

  /**
   * Carries over the ARR of missing items to the default upticked prices for a legacy subscriptions.
   * @param {SubscriptionItem} planItems The items of the renewal subscriptions.
   * @param {ApiSubscription} parentSubscription The parent subscription.
   * @param {UptickParams} uptickParams The parameters for the uptick calculation.
   * @param {UptickPlanItem[]} uptickedPrices The upticked prices for the items.
   */
  private carryOverMissingItemsArrForLegacySubscriptions(
    subscriptionItems: SubscriptionItem[],
    parentSubscription: ApiSubscription,
    uptickParams: UptickParams,
    uptickedPrices: UptickPlanItem[],
  ) {
    const parentItemsNotInPlan = this.filterParentItemsNotInPlan(parentSubscription, uptickParams);
    nsutils.logMayBe('carryOverMissingItemsArr parentItemsNotInPlan', parentItemsNotInPlan);
    // now filtering by items and getting the total missing arr
    const missingItemsArr = parentSubscription.items
      .filter((parentItem) => parentItemsNotInPlan.find((item) => item.id === parentItem.id))
      .sum(i => this.getItemArr(i));
    nsutils.logMayBe('carryOverMissingItemsArr missingItemsArr', missingItemsArr);

    if (missingItemsArr > 0) {

      // Determine the main/support item, and retrieve the default upticked price.
      const item = subscriptionItems.find(i => uptickParams.isSupportOnlyPlan ? i.isSupportMainItem : i.isMainItem);
      if (!item) {
        throw new Error(`Cannot retrieve the item for adding the ARR of the missing items in the new subscription plan.`);
      }
      const uptickedPrice = uptickedPrices.find(p => p.id === item.id);
      if (!uptickedPrice) {
        throw new Error(`Cannot find the upticked price for the item ${item.id}.`);
      }
      nsutils.logMayBe('carryOverMissingItemsArr uptickedPrice', uptickedPrice);

      // Add the upticked ARR of the missing items to the upticked price.
      const multiplier = (1 + uptickParams.uptickPercent)
        / (uptickedPrice.price.frequency === 'MONTHLY' ? MONTHS_IN_A_YEAR : 1)
        / (item.prices[0].ranges[0].type === PriceTierType[PriceTierType.Rate] ? item.quantity : 1);
      nsutils.logMayBe('carryOverMissingItemsArr multiplier', multiplier);
      uptickedPrice.price.ranges[0].price += missingItemsArr * multiplier;
      nsutils.logMayBe('carryOverMissingItemsArr uptickedPrice2', uptickedPrice);
    }
}

  private filterParentItemsNotInPlan(
    parentSubscription: ApiSubscription,
    uptickParams: UptickParams
  ): SubscriptionIncludedItem[] {
    // Consider only parent items which are not included in the renewal plan items.
    // comparing the codes, because ids can be different when product tier/support level is changed
    return parentSubscription.includedItems.filter((parentItem) => {
      // item already included
      if (uptickParams.planItems.find((planItem) =>
        new ItemCode(planItem.code).codeWOSuffix() === new ItemCode(parentItem.code).codeWOSuffix()
      )) {
        return false
      }
      const item = parentSubscription.items.find((i) => i.id === parentItem.id);
      // main items are already added to the main item
      return !(item?.isMainItem || item?.isSupportMainItem);
    });
  }

  /**
   * Returns the ARR of a subscription item.
   * @param {SubscriptionItem} item The subscription item.
   * @returns {number} The ARR amount.
   */
  private getItemArr(item: SubscriptionItem): number {
    // Get the recuring amount invoiced;
    //   Then, multiply by the interval count for one year based on the frequency;
    //   Then, divide by how often the recurring invoices are generated.
    return roundMoney(item.recuringAmount
      * this.getPriceIntervalCountInTerm(item.frequency, MONTHS_IN_A_YEAR)
      / (item.repeatEvery ?? 1)
    );
  }

  private applyAndSavePricePlan(subscriptionRec, items) {
    nsutils.logMayBe('applyAndSavePricePlan params', { subscriptionRec: subscriptionRec, items: items });
    const itemsSubscription = new DynamicSublistWrapper(subscriptionRec, 'priceinterval');
    nsutils.logMayBe('applyAndSavePricePlan itemsSubscription', itemsSubscription);
    const currency = subscriptionRec.getValue('currency') as number;
    while (itemsSubscription.nextLine()) {
      const itemid = parseInt(itemsSubscription.getFieldValue('item') as string);
      const price = items.find((i) => i.id === itemid)?.price;
      if (!price) {
        continue;
      }
      const priceplan = this.createUptickPricePlan(price, currency);
      nsutils.logMayBe('applyAndSavePricePlan priceplan', priceplan);
      itemsSubscription.setFieldValue('priceplan', priceplan);
      itemsSubscription.commit();
      nsutils.logMayBe('applyAndSavePricePlan updated itemsSubscription', itemsSubscription);
    }
  }

  private uptickPrices(tiers: PriceTier[], uptickValue: number) {
    nsutils.logMayBe('uptickPrices params', { tiers, uptickValue });
    for (const tier of tiers) {
      tier.price = tier.price * (1 + uptickValue);
    }
    nsutils.logMayBe('uptickPrices res', { tiers });
  }

  private createTierCappedByListPrice(
    subscriptionTier: PriceTier,
    listedTier: PriceTier,
    quantity: number
  ): PriceTier {
    if (listedTier.price <= subscriptionTier.price) {
      return {
        priceplanid: listedTier.priceplanid,
        type: listedTier.type,
        fromQuantity: quantity,
        price: listedTier.price,
      };
    } else {
      return {
        priceplanid: subscriptionTier.priceplanid,
        type: subscriptionTier.type,
        fromQuantity: quantity,
        price: subscriptionTier.price,
      };
    }
  }

  private getTiersCappedByListPrice(
    subscriptionTiers: PriceTier[],
    listedTiers: PriceTier[]
  ): PriceTier[] {
    nsutils.logMayBe('getTiersCappedByListPrice params', {
      subscriptionTiers: subscriptionTiers,
      listedTiers: listedTiers,
    });
    const tiers: PriceTier[] = [];
    let subscriptionIndex = 0;
    let listedIndex = 0;
    while (subscriptionIndex < subscriptionTiers.length || listedIndex < listedTiers.length) {
      // if the listed tier has less quantity, check against the subscription tier applicable to same quantity
      if (
        subscriptionIndex >= subscriptionTiers.length ||
        subscriptionTiers[subscriptionIndex].fromQuantity > listedTiers[listedIndex].fromQuantity
      ) {
        const subscriptionTier = this.getPriceTierFromRanges(subscriptionTiers, listedTiers[listedIndex].fromQuantity);
        tiers.push(
          this.createTierCappedByListPrice(
            subscriptionTier,
            listedTiers[listedIndex],
            listedTiers[listedIndex].fromQuantity
          )
        );
        listedIndex++;
      }
      // if the subscription tier has less quantity, check against the listed tier applicable to same quantity
      else if (
        listedIndex >= listedTiers.length ||
        subscriptionTiers[subscriptionIndex].fromQuantity < listedTiers[listedIndex].fromQuantity
      ) {
        const listedTier = this.getPriceTierFromRanges(listedTiers, subscriptionTiers[subscriptionIndex].fromQuantity);
        tiers.push(
          this.createTierCappedByListPrice(
            subscriptionTiers[subscriptionIndex],
            listedTier,
            subscriptionTiers[subscriptionIndex].fromQuantity
          )
        );
        subscriptionIndex++;
      } else if (subscriptionTiers[subscriptionIndex].fromQuantity === listedTiers[listedIndex].fromQuantity) {
        tiers.push(
          this.createTierCappedByListPrice(
            subscriptionTiers[subscriptionIndex],
            listedTiers[listedIndex],
            listedTiers[listedIndex].fromQuantity
          )
        );
        subscriptionIndex++;
        listedIndex++;
      }
    }
    nsutils.logMayBe('getTiersCappedByListPrice tiers', tiers);
    return tiers;
  }

  private createUptickPricePlan(price: Price, currency: number) {
    nsutils.logMayBe('createUptickPricePlan params', price);
    const newPricePlanRec = record.create({
      type: record.Type.PRICE_PLAN,
      isDynamic: true,
    });
    newPricePlanRec.setValue('currency', currency);
    newPricePlanRec.setValue('priceplantype', PriceModelType[price.type]);
    for (const tier of price.ranges) {
      this.createPriceTier(newPricePlanRec, tier.fromQuantity, tier.price, PriceTierType[tier.type]);
    }
    nsutils.logMayBe('createUptickPricePlan save', {});
    return newPricePlanRec.save();
  }

  private getMainAndSupportDistributionRatioForUptick(
    parentSubscription: ApiSubscription,
    parentPlanInfoIsLegacy: boolean,
    isSameSupportLevel: boolean,
    newPlan: SubscriptionPlan,
    draftItems?: SubscriptionItems,
    mainItem?: SubscriptionItem,
    supportItem?: SubscriptionItem
  ): number {
    nsutils.logMayBe('getMainAndSupportDistributionRatioForUptick params', {
      parentSubscription: parentSubscription, 
      parentPlanInfoIsLegacy: parentPlanInfoIsLegacy,
      isSameSupportLevel: isSameSupportLevel,
      newPlanItems: newPlan.items,
      draftItems: draftItems,
      mainItem: mainItem,
      supportItem: supportItem
    });
    // if support or main item doesn't exist returning default ratio for the plan because we may have support addon items
    if (!supportItem || !mainItem) {
      return supportLevelDistributionRatio(newPlan.supportLevel);
    }

    // different support level need to get the distribution ratio for the new support level
    if (!isSameSupportLevel) {
      // legacy plans don't have list prices, getting the default distribution ratio
      if (parentPlanInfoIsLegacy) {
        const supportLevel = SupportLevelUtil.nameToSupportLevel(newPlan.supportLevel);
        return supportLevelDistributionRatio(supportLevel as SupportLevel);
      }

      // non legacy plans have the list prices with distribution set, getting from the list price to make sure cents will match what is setup
      // getting main and support price from same currency and frequency of subscription
      const planMainItemRanges = newPlan.items.firstOrUndefined(i => i.isMainItem)?.prices.
        firstOrUndefined(i => i.frequency === parentSubscription.term.frequency && i.currency === parentSubscription.currency)?.ranges;
      const planSupportItemRanges = newPlan.items.firstOrUndefined(i => i.isSupportMainItem)?.prices.
        firstOrUndefined(i => i.frequency === parentSubscription.term.frequency && i.currency === parentSubscription.currency)?.ranges;
      if (planMainItemRanges && planSupportItemRanges) {
        const mainItemQuantity = mainItem?.quantity ?? 1;
        return this.getSupportMultiplierFromRanges(planMainItemRanges, planSupportItemRanges, mainItemQuantity);
      }
    }

    let parentSubscriptionItems: SubscriptionItems;
    // Distribution ration for legacy subscription is calculated based on current draft
    if (parentPlanInfoIsLegacy && draftItems) {
      parentSubscriptionItems = draftItems;
    } else {
    // For new subscription plans, apply the same distribution existent in the parent subscription
      const parentSubscriptionRecord = clone(
        record.load({
          type: record.Type.SUBSCRIPTION,
          id: parentSubscription.id,
        })
      );
      const parentSubscriptionPlan = subscriptionPlanUtility.getSubscriptionPlanById(
        parseInt(parentSubscriptionRecord.fields.subscriptionplan)
      );
      const { subscriptionItems } = subscriptionGetUtility.buildItems(
        parentSubscriptionRecord,
        parentSubscriptionPlan
      );
      parentSubscriptionItems = subscriptionItems;
    }

    assertNotNull(parentSubscriptionItems.mainItem);
    // If supportItem doesn't exist in the parent, get the default distribution for the support level
    if (parentSubscriptionItems.supportItem) {
      return this.getSupportMultiplierFromRanges(parentSubscriptionItems.mainItem.item.prices[0].ranges, 
        parentSubscriptionItems.supportItem.item.prices[0].ranges, parentSubscriptionItems.mainItem.quantity);
    }

    const supLevel = SupportLevelUtil.nameToSupportLevel(newPlan.supportLevel);
    return supportLevelDistributionRatio(supLevel as SupportLevel);
  }

  private getSupportMultiplierFromRanges(mainItemRanges: PriceTier[], supportItemRanges: PriceTier[], quantity: number) {
    const mainItemPrice = this.getPriceTierFromRanges(mainItemRanges, quantity).price;
    const supportItemPrice = this.getPriceTierFromRanges(supportItemRanges, quantity).price;
    const totalPrice = mainItemPrice + supportItemPrice;
    return supportItemPrice / totalPrice;
  }

  private applyDistributionRatioToSupportItems(
    supportMultiplier: number,
    uptickedPrices,
    supportItems: SubscriptionItem[],
    availableItems: SubscriptionItem[]
  ) {
    nsutils.logMayBe('applyDistributionRatioToSupportItems params', {
      supportMultiplier,
      uptickedPrices,
      supportItems,
      availableItems
    });

    for (const supportItem of supportItems) {
      const match = availableItems.find(i => new ItemCode(supportItem.code).isDifferentOnlyInSuffix(new ItemCode(i.code)));
      if (!match) {
        if (availableItems.find(i => supportItem.id === i.id)) {
          //item is available and doesn't need to split
          continue;
        }
        throw new Error(`Match item not found for support item ${supportItem.code}`);
      }

      const newPrice = uptickedPrices.find((i) => i.id === match.id).price;
      nsutils.logMayBe('applyDistributionRatioToSupportItems newMainPrice', newPrice);

      const newSupportPrice = {
        type: newPrice.type,
        frequency: newPrice.frequency,
        currency: newPrice.currency,
        ranges: [] as PriceTier[],
      };
      nsutils.logMayBe('applyDistributionRatioToSupportItems newSupportPrice', newSupportPrice);
      for (const tier of newPrice.ranges) {
        const price = tier.price;
        const supportItemPrice = roundMoney(price * supportMultiplier);
        tier.price = price - supportItemPrice;
        newSupportPrice.ranges.push({
          priceplanid: tier.id,
          type: tier.type,
          fromQuantity: tier.fromQuantity,
          price: supportItemPrice,
        });
      }
      uptickedPrices.push({
        id: supportItem.id,
        price: newSupportPrice,
      });
    }
    nsutils.logMayBe('applyDistributionRatioToSupportItems uptickedPrices', uptickedPrices);
  }
}

export default new SubscriptionPriceUtility();
