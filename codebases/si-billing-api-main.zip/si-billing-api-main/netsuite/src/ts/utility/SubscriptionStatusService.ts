import * as nsutils from '../nsutils';
import BillingAccountDao from '../dao/BillingAccountDao';
import { SubscriptionRecord, SubscriptionUpdateNamePattern } from '../models/SubscriptionRecord';
import { SubscriptionLineStatus, SubscriptionStatus, SubscriptionTermType } from '../types';
import { isNull, must, ValidationError } from '../validation';
import SubscriptionChangeOrderUtility from './SubscriptionChangeOrderUtility';
import SubscriptionValidateUtility from './SubscriptionValidateUtility';
export class SubscriptionStatusService {
  /**
   * Activate subscribtion which is in DRAFT or PENDING_ACTIVATION status.
   * Request accepted quote and contractual docs set which should be done in quote accept method.
   * @throw Error if no contractual docs set or status is wrong
   */
  activate(subscription: SubscriptionRecord) {
    if (
      (subscription.status !== SubscriptionStatus.DRAFT &&
        subscription.status !== SubscriptionStatus.PENDING_ACTIVATION) ||
      (subscription.initialTermType !== SubscriptionTermType.EVERGREEN && isNull(subscription.contractDocs))
    ) {
      throw new ValidationError(`Subscription is not eligible for activation`, 'subscriptionId');
    }

    this.changeItemsToPendingActivation(subscription);

    let activationDate = subscription.startDate;
    let terminationDate = new Date();
    // if matches pattern, it's an update
    if (SubscriptionUpdateNamePattern.matches(subscription.name)) {
      // for updates, the new subscription will begin on the day it's accepted
      activationDate = new Date();
      if (subscription.initialTermType === SubscriptionTermType.EVERGREEN) {
        const currentSubscriptionId = must(SubscriptionUpdateNamePattern.getUpdateSubscriptionId(subscription.name));
        // downgrades on evergreen subscriptions became active on next billing cycle
        // https://docs.google.com/document/d/1er4EKdCZ-TTdO2mqTP6ysAvYR865qDmGNzw7eBp2t7o/edit#bookmark=id.99v2c75mc0qe
        if (SubscriptionValidateUtility.isDowngradeBySubscriptionIds(currentSubscriptionId, subscription.id)) {
          const nextBillCycleDate = must(BillingAccountDao.nextBillCycleDate(subscription.billingAccount));
          activationDate = nextBillCycleDate;
        }
      }
      // termination happens on the same day of activation because termination is being set to terminate in the start of the day
      terminationDate = new Date(activationDate);
    }

    const activateCo = SubscriptionChangeOrderUtility.createActivationChangeOrder(subscription.id, activationDate);
    activateCo.save();
    if (SubscriptionUpdateNamePattern.matches(subscription.name)) {
      const co = SubscriptionChangeOrderUtility.terminateSubscriptionChangeOrder(
        must(SubscriptionUpdateNamePattern.getUpdateSubscriptionId(subscription.name), 'previousSubscriptionId'),
        terminationDate,
        undefined,
        false
      );
      co.save();
    }
  }

  internalActivate(subscriptionId) {
    const subscription = SubscriptionRecord.load(subscriptionId);
    this.changeItemsToPendingActivation(subscription);
    const activateCo = SubscriptionChangeOrderUtility.createActivationChangeOrder(subscription.id, subscription.startDate);
    activateCo.save();
  }

  private changeItemsToPendingActivation(subscription: SubscriptionRecord) {
    subscription.processSubscriptionLines((iter) => {
      while (iter.nextLine()) {
        nsutils.logMayBe('processUpdate', {
          itemid: iter.line().itemId,
          status: iter.line().status,
          included: iter.line().included,
        });
        if (iter.line().included) {
          iter.line().status = SubscriptionLineStatus.PENDING_ACTIVATION;
          iter.commit();
        }
      }
    });
    subscription.save();
  }
}

export default new SubscriptionStatusService();
