import * as nsutils from '../nsutils';
import * as record from 'N/record';
import { DynamicSublistWrapper } from '../models/DynamicSublistWrapper';
import { RenewParams, SubscriptionUpdateParams, zeroDiscounts } from '../models/SubscriptionParams';
import { SubscriptionRecord } from '../models/SubscriptionRecord';
import { TermDuration } from '../models/TermDuration';
import { Any, BillingSchedule, HandlerResponse, SubscriptionStatus, TermUnit } from '../types';
import { assertNotNull, isNotNull, must } from '../validation';
import billingAccountUtility from './BillingAccountUtility';
import subscriptionChangeOrderUtility from './SubscriptionChangeOrderUtility';
import subscriptionGetUtility from './SubscriptionGetUtility';
import subscriptionItemUtility from './SubscriptionItemUtility';
import subscriptionPlanUtility from './SubscriptionPlanUtility';
import subscriptionPriceUtility from './SubscriptionPriceUtility';
import subscriptionCreateUtility from './SubscriptionCreateUtility';
import subscriptionValidateUtility from './SubscriptionValidateUtility';
import termUtility from './TermUtility';
import SubscriptionDao from '../dao/SubscriptionDao';
import { ProductIntegration } from '../ProductIntegration';
import { clone } from './GeneralUtility';
import { SubscriptionItems, SubscriptionPlan } from '../models/SubscriptionPlan';
import SubscriptionUtility from './SubscriptionUtility';

export class SubscriptionUpdateUtility {
  private renewDraftSubscription(
    params: RenewParams,
    subscriptionRec: record.Record,
    draftItems?: SubscriptionItems,
    draftPlan?: SubscriptionPlan
  ) {
    nsutils.logMayBe('renewDraftSubscription params', {
      params,
      subscriptionRec,
      draftItems,
      draftPlan,
    });
    assertNotNull(params.subscriptionId, 'subscriptionId');
    assertNotNull(params.customerId, 'customerId');
    assertNotNull(params.content?.items, 'items');
    const planId = subscriptionRec.getValue('subscriptionplan') as number;
    const subscriptionPlan = subscriptionPlanUtility.getSubscriptionPlanById(planId);

    const custAndBa = billingAccountUtility.getCustomerAndBA({
      customerId: params.customerId,
      frequency: must(params.content.frequency, 'frequency') as BillingSchedule,
      classId: must(params.content.planClass, 'planClass'),
      effectiveDate: params.content.effectiveDate,
      subsidiaryId: subscriptionRec.getValue('subsidiary') as number,
    });
    if (
      params.planChange &&
      parseInt(subscriptionRec.getValue('billingaccount') as string) !== parseInt(custAndBa.billingAccountId)
    ) {
      subscriptionRec.setValue('billingaccount', custAndBa.billingAccountId);
      const planAndPriceBook = subscriptionPlanUtility.findSubscriptionPlanAndPriceBook(
        params.content.planCode,
        params.customerId,
        params.content.frequency
      );
      subscriptionRec.setValue('pricebook', planAndPriceBook.priceBookId);
      subscriptionRec.setValue('defaultrenewalplan', planAndPriceBook.subscriptionPlanId);
    }

    if (isNotNull(params.content.duration)) {
      const sub = new nsutils.RecWrapper(subscriptionRec);
      termUtility.setInitialTerm(new TermDuration(params.content.duration, TermUnit.MONTHS), sub);
    }
    // auto renewal must be set after the term is set
    subscriptionCreateUtility.setAutoRenewal(subscriptionRec, params.content?.renewalDaysBeforeEndDate);

    const subPricing = new DynamicSublistWrapper(subscriptionRec, 'priceinterval');
    const subLine = new DynamicSublistWrapper(subscriptionRec, 'subscriptionline');
    while (subPricing.nextLine() && subLine.nextLine()) {
      const itemId = parseInt(must(subPricing.getFieldValue('item'), 'item').toString());

      const item = subscriptionItemUtility.findItemForLine(
        itemId,
        subscriptionPlan,
        params.content.items
      );
      if (item && item.quantity > 0) {
        subLine.setFieldValue('isincluded', true);
        subPricing.setFieldValue('quantity', item.quantity);
        subPricing.commit();
        subLine.commit();
      } else {
        subLine.setFieldValue('isincluded', false);
        subLine.setFieldValue('status', 'NOT_INCLUDED');
        subLine.commit();
      }
    }

    const pi = ProductIntegration.getProductIntegration(params.productFamilyCode, params.productVariantCode);
    subscriptionPriceUtility.applyModifiedPrices(
      subscriptionRec,
      pi.isUptickEnabled,
      false,
      false,
      true,
      draftItems,
      draftPlan
    );
    subscriptionRec.save();
    const oneSecond = 1000;
    nsutils.delay(oneSecond);
    return subscriptionGetUtility.getSubscriptionByIdForCustomer(params.subscriptionId, params.customerId);
  }

  private upgradePlan(
    params: SubscriptionUpdateParams,
    activate: boolean,
    subscriptionPlanDisplayName: string,
    subscriptionRec: SubscriptionRecord,
    isDowngrade: boolean
  ) {
    const discountsToApply = subscriptionRec.isTrial
      ? zeroDiscounts
      : subscriptionPriceUtility.getDiscountForUpdate(
          subscriptionRec.initialTermType,
          isDowngrade,
          params.subscriptionId
        );
    const newSubscription = subscriptionCreateUtility.createSubscription(params, {
      trial: false,
      discounts: discountsToApply,
      previousSubscriptionId: must(params.subscriptionId, 'subscriptionId'),
      activate: activate,
      subscriptionPlanDisplayName: subscriptionPlanDisplayName,
      initialTermId: subscriptionRec.isTrial ? undefined : subscriptionRec.initialTermId,
    });

    // shortcut for creating subscriptions for e2e
    if (activate) {
      const co = subscriptionChangeOrderUtility.terminateSubscriptionChangeOrder(
        must(params.subscriptionId, 'subscriptionId'),
        undefined,
        undefined,
        false
      );
      co.save();
    }

    return newSubscription;
  }

  public update(
    params: SubscriptionUpdateParams,
    subscriptionRec: SubscriptionRecord,
    activate: boolean = false
  ): HandlerResponse {
    assertNotNull(params.subscriptionId, 'subscriptionId');
    assertNotNull(params.content?.planId, 'planId');
    assertNotNull(params.content?.planCode, 'planCode');
    assertNotNull(params.content?.items, 'items');

    const planId = subscriptionRec.rec.getValue('subscriptionplan') as number;
    const currentPlanInfo = subscriptionPlanUtility.getSubscriptionPlanInfoById(planId);
    const newPlanInfo = subscriptionPlanUtility.getSubscriptionPlanInfoById(params.content?.planId);

    const { isDowngrade } = subscriptionValidateUtility.validateUpdateActive(
      params.subscriptionId,
      params.content?.duration,
      currentPlanInfo,
      newPlanInfo,
      params.content?.items,
      subscriptionRec.initialTermType
    );

    const planInfo = subscriptionPlanUtility.validatePlan(params);
    if (!subscriptionRec.isTrial) {
      params.content.effectiveDate = subscriptionRec.rec.getValue('startdate')?.toString();
    }
    params.activationDate = new Date();

    // remove all existing draft updates and related quotes
    for (const sId of SubscriptionDao.findUpdates(subscriptionRec.id, SubscriptionStatus.DRAFT)) {
      SubscriptionUtility.deleteDraftSubscription(sId);
    }
    const res = this.upgradePlan(params, activate, planInfo.displayName, subscriptionRec, isDowngrade);
    return { content: res };
  }

  public renew(params: SubscriptionUpdateParams, subscription: SubscriptionRecord): HandlerResponse {
    nsutils.logMayBe('renew params', params);
    assertNotNull(params.customerId, 'customerId');
    assertNotNull(params.subscriptionId, 'subscriptionId');
    assertNotNull(params.content?.planClass, 'planClass');
    assertNotNull(params.content?.planCode, 'planCode');
    assertNotNull(params.content?.items, 'items');
    subscriptionValidateUtility.validateDuration(params);
    const renewParams: RenewParams = params;
    assertNotNull(renewParams.content, 'content');
    renewParams.planChange = subscriptionPlanUtility.isCurrentPlanChange(params) === true;

    const subscriptionApi = subscriptionGetUtility.getSubscriptionByIdInternal(params.subscriptionId);
    const currentPlanId = SubscriptionDao.getSubscriptionPlanId(params.subscriptionId);
    const currentPlanInfo = subscriptionPlanUtility.getSubscriptionPlanInfoById(currentPlanId);
    const newPlanInfo = subscriptionPlanUtility.getSubscriptionPlanInfoById(must(params.content?.planId));

    renewParams.isDowngrade = subscriptionValidateUtility.isDowngrade(
      subscriptionApi,
      params.content?.items,
      currentPlanInfo,
      newPlanInfo
    );

    const subscriptionSnapshot = clone(subscription.rec);
    const { plan: draftPlan, subscriptionItems: draftItems } =
      subscriptionGetUtility.getSubscriptionRecItems(subscriptionSnapshot);
    nsutils.logMayBe('renew subscriptionSnapshot', subscriptionSnapshot);

    const newSubsidiary = subscriptionCreateUtility.findSuitableSubsidiary(params.customerId, params.content.planClass, subscriptionApi.parentSubscription);
    const differentSubsidiary = newSubsidiary !== subscription.subsidiary;

    nsutils.logMayBe('renew renewParams', renewParams);
    // if plan is changed is necessary to create a new renew subscription and delete the old renew subscription
    if (renewParams.planChange || differentSubsidiary) {
      SubscriptionUtility.deleteDraftSubscription(params.subscriptionId);
      const parentSubscription = SubscriptionRecord.load(must(subscriptionApi.parentSubscription,'parent subscription'));
      let subscriptionId: number;
      // when subsidiary of parent subscription is different of new subsidiary we can't use renewal order and need to create a new subscription
      if (parentSubscription.subsidiary !== newSubsidiary) {
        parentSubscription.automaticallyInitiateRenewalProcess = false;
        parentSubscription.save();
        renewParams.content.effectiveDate = subscriptionSnapshot.fields.startdate;
        const opts = {
          trial: false,
          discounts: zeroDiscounts,
          parentSubscriptionId: parentSubscription.id,
        } as Any;
        if (!renewParams.content.duration) {
          opts.initialTermId = parentSubscription.defaultRenewalTerm;
        }
        subscriptionId = subscriptionCreateUtility.createSubscription(renewParams, opts).id;
      } else {
        const changeOrder = subscriptionChangeOrderUtility.createReplacementRenewChangeOrder(params, subscription.rec);
        subscriptionId = subscriptionChangeOrderUtility.getSubscriptionIdFromRenewChangeOrder(changeOrder);
        if (!subscriptionId) {
          throw new Error(
            `An error happened when trying to renewing the subscription. Check the renew order in the subscription to ${params.subscriptionId}`
          );
        }
      }

      // Reload the new subscription, by preserving the sales rep ID if defined.
      const salesRepId = subscription.salesRepId;
      subscription = SubscriptionRecord.load(subscriptionId);
      if (salesRepId) {
        subscription.salesRepId = salesRepId;
      }

      renewParams.subscriptionId = subscriptionId;
      SubscriptionUtility.changeSubscriptionQuoteLinks(params.subscriptionId, subscriptionId);
    }
    return {
      content: this.renewDraftSubscription(renewParams, subscription.rec, draftItems, draftPlan),
    };
  }
}

export default new SubscriptionUpdateUtility();
