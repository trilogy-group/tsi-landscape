import * as nsutils from '../nsutils';
import * as record from 'N/record';
import { assertNotNull, assertNotNullMsg, must } from '../validation';

export class SubscriptionUsageUtility {
  createUsage(usageParam: {
    subscriptionId: number;
    itemCode: string;
    quantity: number;
    usageDate: string;
    lineNumber?: number;
  }): number {
    const usageRecord = record.create({
      type: record.Type.USAGE,
      isDynamic: true,
    });

    usageRecord.setValue({ fieldId: 'usagesubscription', value: must(usageParam.subscriptionId, `subscriptionId`) });
    const subscriptionLineRes = nsutils.queryToJson(
      `select sl.id, sl.linenumber from subscriptionline sl 
      join item i on i.id=sl.item where sl.subscription=? and i.itemid=?`,
      [usageParam.subscriptionId, usageParam.itemCode]
    );

    let subscriptionLineId;
    if (subscriptionLineRes.length > 1) {
      assertNotNull(usageParam.lineNumber, 'lineNumber');
      subscriptionLineId = subscriptionLineRes.find((v) => v.linenumber === usageParam.lineNumber)?.id;
    } else if (subscriptionLineRes.length === 1) {
      subscriptionLineId = subscriptionLineRes[0]?.id;
    }

    assertNotNullMsg(subscriptionLineId, 'Item not found');

    usageRecord.setValue({ fieldId: 'usagesubscriptionline', value: subscriptionLineId });
    usageRecord.setValue({ fieldId: 'usagequantity', value: must(usageParam.quantity) });
    usageRecord.setValue({ fieldId: 'usagedate', value: new Date(usageParam.usageDate) });
    return usageRecord.save();
  }
}

export default new SubscriptionUsageUtility();
