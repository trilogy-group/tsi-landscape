import * as record from 'N/record';
import * as search from 'N/search';
import QuoteDao from '../dao/QuoteDao';
import ContractualDocumentsDao from '../dao/ContractualDocumentsDao';
import SubscriptionDao from '../dao/SubscriptionDao';
import { SubscriptionRecord } from '../models/SubscriptionRecord';
import { CONTRACTUAL_DOCUMENTS_RECORD_TYPE } from '../models/ContractualDocumentsRecord';
import QuoteService from './QuoteService';
import { QuoteRecord } from '../models/QuoteRecord';
import { GetSubscriptionsToSyncParams } from '../models/SubscriptionParams';
import { Any } from '../types';
import ClassDao from '../dao/ClassDao';
import { convert } from '../nsutils';

export class SubscriptionUtility {
  getSubscriptionsToSync(params: GetSubscriptionsToSyncParams): {
    subscriptions: {
      id: number;
      class: string;
    }[],
    nextSearchDate: string,
    subscriptionSearch?: Any[]
  } {
    const classIds = ClassDao.getClassIds(params.classes);
    const dateToSearch = convert.toDateTimeSearch(new Date(params.sinceDate));
    
    // datecreated is only available in search
    const subscriptionSearch = search.create({
      type: 'subscription',
      filters: [
        ['datecreated', search.Operator.AFTER, dateToSearch],
        'AND',
        ['class', 'anyof', classIds],
      ],
      columns: [
        'internalid',
        search.createColumn({ name: 'datecreated', sort: search.Sort.ASC })
      ]
    });
    const subscriptionResults: Any = [];
    subscriptionSearch.run().each((result) => {
      subscriptionResults.push({
        id: result.getValue({name: 'internalid'}),
        datecreated: result.getValue({name: 'datecreated'})
      });
      return true;
    });

    // in case there are no subscriptions to sync return empty array and the same date for next sync
    if (subscriptionResults.length === 0) {
      return {
        subscriptions: [],
        nextSearchDate: dateToSearch
      };
    }

    // we only want to sync renewals (subscriptions with a parent) that are not prime
    // it's not possible to filter direct in the search because this are custom fields and
    // search doesn't support custom fields in filters
    // and we also need to return the full class name to log
    const subscriptions = SubscriptionDao.getSubscriptionsToSync(subscriptionResults.map(s => s.id));

    // get last date to be used in the next call
    const nextSearchDate = new Date(subscriptionResults[subscriptionResults.length - 1].datecreated);
    // add 1 minute to avoid getting the same subscription in the next call
    nextSearchDate.setMinutes(nextSearchDate.getMinutes() + 1);
    return {
      subscriptions,
      nextSearchDate: convert.toDateTimeSearch(nextSearchDate),
      subscriptionSearch: subscriptionResults
    };
  }

  public deleteDraftSubscription(subscriptionId: number) {
    // delete quotes linked by transaction line
    const quotesLinkedByTransactionLine = QuoteDao.findHardLinkedQuotes(subscriptionId);
    for (const quoteId of quotesLinkedByTransactionLine) {
      QuoteService.deleteQuote(quoteId);
    }

    // get contractual documents to delete
    const contractualDocumentsIds = ContractualDocumentsDao.findContractualDocumentsForSubscription(subscriptionId);
    // clean contractual documents fields set on subscriptions to be possible to delete the contractual documents
    const subscriptionIds = SubscriptionDao.findSubscriptionIdsByContractualDocumentsIds(contractualDocumentsIds);
    for (const subId of subscriptionIds) {
      const sub = SubscriptionRecord.load(subId);
      sub.contractDocs = null;
      sub.save();
    }

    // delete contractual documents
    for (const contractualDocumentsId of contractualDocumentsIds) {
      record.delete({ type: CONTRACTUAL_DOCUMENTS_RECORD_TYPE, id: contractualDocumentsId });
    }
    record.delete({ type: record.Type.SUBSCRIPTION, id: subscriptionId });
  }

  public changeSubscriptionQuoteLinks(oldSubscriptionId: number, newSubscriptionId: number) {
    const quotesLinkedByCustomField = QuoteDao.findSoftLinkedQuotes(oldSubscriptionId);
    for (const quoteId of quotesLinkedByCustomField) {
      const quote = QuoteRecord.load(quoteId);
      quote.subscriptionId = newSubscriptionId;
      quote.save();
    }
  }
}

export default new SubscriptionUtility();
