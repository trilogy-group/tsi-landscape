import * as nsutils from '../nsutils';
import {
  GetRenewalInfoParams,
  SubscriptionConfigurationItem,
  SubscriptionCreateParams,
  SubscriptionCreateParamsNoQuantityReq,
  SubscriptionUpdateParams,
  SubscriptionUpdateParamsNoQuantityReq,
} from '../models/SubscriptionParams';
import { assertNotNull, must, SubscriptionNotFoundError, ValidationError } from '../validation';
import subscriptionDao from '../dao/SubscriptionDao';
import subscriptionGetUtility from './SubscriptionGetUtility';
import subscriptionPlanUtility from './SubscriptionPlanUtility';
import { TermDuration } from '../models/TermDuration';
import {
  ProductTier,
  ProductTierUtil,
  SubscriptionStatus,
  SubscriptionTermType,
  SupportLevel,
  SupportLevelUtil,
  TermUnit,
} from '../types';
import { ApiSubscription } from '../models/apitypes';
import { PlanInfo } from '../models/SubscriptionPlan';
import { SubscriptionRecord } from '../models/SubscriptionRecord';

export class SubscriptionValidateUtility {
  public validateSubscriptionItems(params: SubscriptionUpdateParams) {
    assertNotNull(params.content?.items, 'items');
    assertNotNull(params.content.planId, 'planId');
    if (!Array.isArray(params.content.items) || params.content.items.length === 0) {
      throw new Error('Subscription items must be informed');
    }

    const items = nsutils.queryToJson(
      `SELECT i.id as id, i.itemid as code, sm.isrequired, i.custitem_support_level as supportlevel
        FROM subscriptionPlanMember sm
        INNER JOIN item i on i.id = sm.item
        WHERE subscriptionplan = ?`,
      [params.content.planId]
    );

    // validate all items are part of subscription plan
    for (const paramItem of params.content.items) {
      const item = items.find((i) => i.code === paramItem.code);
      if (!item) {
        throw new Error(`Cannot find item with code ${paramItem.code} in plan`);
      }
      paramItem.id = item.id;
    }

    // validate required items in subscription are present
    const requiredItems = items.filter((i) => i.isrequired === 'T' && i.supportlevel === null);
    for (const item of requiredItems) {
      const paramItem = params.content.items.find((i) => i.code === item.code);
      if (!paramItem) {
        throw new Error(`Required item ${item.code} is not present`);
      }
      if (paramItem.quantity < 1) {
        throw new Error(`Required item ${item.code} must have quantity > 0`);
      }
    }
  }

  validateDurationGreaterOrEqualToInitialTerm(term: TermDuration, sub: nsutils.RecWrapper) {
    const initialTerm = new TermDuration(
      sub.rec.getValue({ fieldId: 'initialtermduration' }) as number,
      TermUnit[sub.rec.getValue({ fieldId: 'initialtermunits' }) as string]
    );
    if (term.isLessThan(initialTerm)) {
      throw new ValidationError(`Duration is less than default ${initialTerm.toString()}`, 'duration');
    }
  }

  public validateAndPrepareCreateData(params: SubscriptionCreateParams) {
    assertNotNull(params.customerId, 'customerId');
    this.validateAndPrepareData(params);
    this.validateSubscriptionItems(params);
  }

  public validateAndPrepareUpdateData(params: SubscriptionUpdateParamsNoQuantityReq) {
    assertNotNull(params.subscriptionId, 'subscriptionId');
    subscriptionGetUtility.checkSubscriptionCustomer(params.subscriptionId, params.customerId);
    this.validateAndPrepareData(params);
  }

  public validateUpdateActive(
    subscriptionId: number,
    duration,
    currentPlanInfo: PlanInfo,
    newPlanInfo: PlanInfo,
    newItems: SubscriptionConfigurationItem[],
    termType: SubscriptionTermType
  ): { isDowngrade: boolean } {
    assertNotNull(subscriptionId, 'subscriptionId');
    assertNotNull(currentPlanInfo, 'currentPlanInfo');
    assertNotNull(newPlanInfo, 'newPlanInfo');
    assertNotNull(newItems, 'newItems');

    if (duration) {
      throw new Error(`Duration can't be changed for an active subscription`);
    }

    if (currentPlanInfo.isLegacyPlan) {
      throw new ValidationError('Updates for the legacy subscriptions are not supported', 'subscriptionId');
    }

    // when there already exists a pending activation subscription with the update name pattern, it means that the subscription
    // is already activated, but the effective date is in the future and we can't update this subscription before that
    if (subscriptionDao.findUpdates(subscriptionId, SubscriptionStatus.PENDING_ACTIVATION).length > 0) {
      throw new Error(`This subscription can not be updated. Please contact sales.`);
    }

    if (
      this.isPlanDowngrade(
        currentPlanInfo.productTier,
        currentPlanInfo.supportLevel,
        newPlanInfo.productTier,
        newPlanInfo.supportLevel
      )
    ) {
      if (termType === SubscriptionTermType.EVERGREEN) {
        return { isDowngrade: true };
      }
      throw new Error(`It's not possible to downgrade an active subscription`);
    }

    const currentSubscription = subscriptionGetUtility.getSubscriptionByIdInternal(subscriptionId);

    if (this.isQuantityDowngrade(currentSubscription, currentPlanInfo, newItems, newPlanInfo)) {
      if (termType === SubscriptionTermType.EVERGREEN) {
        return { isDowngrade: true };
      }
      throw new Error(`It's not possible to reduce quantity in an active subscription`);
    }
    return { isDowngrade: false };
  }

  public validateDuration(params: SubscriptionUpdateParams) {
    if (params.content?.duration !== undefined && params.content?.duration !== null) {
      const subscriptionPlan = subscriptionPlanUtility.getSubscriptionPlanByCode(must(params.content.planCode,'planCode'));
      const termDuration = new TermDuration(params.content.duration, TermUnit.MONTHS);
      const planTermDuration = new TermDuration(
        subscriptionPlan.initialterm.duration,
        TermUnit[subscriptionPlan.initialterm.unit]
      );
      if (termDuration.isLessThan(planTermDuration)) {
        throw new ValidationError(
          `Duration is less than default term for subscription plan. Default term: ${planTermDuration.toString()}`,
          'duration'
        );
      }
    }
  }

  public isDowngradeBySubscriptionIds(currentSubscriptionId: number, newSubscriptionId: number): boolean {
    const currentSubscription = subscriptionGetUtility.getSubscriptionByIdInternal(currentSubscriptionId);
    const currentPlanInfo = subscriptionPlanUtility.getSubscriptionPlanInfoById(currentSubscription.plan.id);
    const newSubscription = subscriptionGetUtility.getSubscriptionByIdInternal(newSubscriptionId);
    const newPlanInfo = subscriptionPlanUtility.getSubscriptionPlanInfoById(newSubscription.plan.id);
    return this.isDowngrade(currentSubscription, newSubscription.includedItems, currentPlanInfo, newPlanInfo);
  }

  public isDowngrade(
    currentSubscription: ApiSubscription,
    newItems: SubscriptionConfigurationItem[],
    currentPlanInfo: PlanInfo,
    newPlanInfo: PlanInfo
  ): boolean {
    return (
      this.isPlanDowngrade(
        currentPlanInfo.productTier,
        currentPlanInfo.supportLevel,
        newPlanInfo.productTier,
        newPlanInfo.supportLevel
      ) || this.isQuantityDowngrade(currentSubscription, currentPlanInfo, newItems, newPlanInfo)
    );
  }

  public isPlanDowngrade(
    currentProductTier?: ProductTier,
    currentSupportLevel?: SupportLevel,
    newProductTier?: ProductTier,
    newSupportLevel?: SupportLevel
  ): boolean {
    nsutils.logMayBe('isPlanDowngrade params', {
      currentProductTier,
      currentSupportLevel,
      newProductTier,
      newSupportLevel,
    });

    const currentProductTierNum = currentProductTier ? ProductTierUtil.productTierToNumber(currentProductTier) : 0;
    const currentSupportLevelNum = currentSupportLevel ? SupportLevelUtil.supportLevelToNumber(currentSupportLevel) : 0;
    const newProductTierNum = newProductTier
      ? ProductTierUtil.productTierToNumber(newProductTier)
      : currentProductTierNum;
    const newSupportLevelNum = newSupportLevel
      ? SupportLevelUtil.supportLevelToNumber(newSupportLevel)
      : currentSupportLevelNum;

    nsutils.logMayBe('isPlanDowngrade vars', {
      currentProductTierNum,
      currentSupportLevelNum,
      newProductTierNum,
      newSupportLevelNum,
    });

    const result = newProductTierNum < currentProductTierNum || newSupportLevelNum < currentSupportLevelNum;
    nsutils.logMayBe('isPlanDowngrade result', result);
    return result;
  }

  public isQuantityDowngrade(
    currentSubscription: ApiSubscription,
    currentPlanInfo: PlanInfo,
    newItems: SubscriptionConfigurationItem[],
    newPlanInfo: PlanInfo
  ) {
    nsutils.logMayBe('isQuantityDowngrade params', { currentSubscription, currentPlanInfo, newItems, newPlanInfo });

    assertNotNull(currentSubscription, 'currentSubscription');
    assertNotNull(currentPlanInfo, 'currentPlanInfo');
    assertNotNull(newItems, 'items');
    assertNotNull(newPlanInfo, 'newPlanInfo');
    const mainItem = currentSubscription.items.find(
      (i) =>
        i.code === (currentPlanInfo.supportOnly ? currentPlanInfo.supportItemCode : currentPlanInfo.mainItemCode)
    );
    const currentQuantity = currentSubscription.includedItems.find((i) => i.id === mainItem?.id)?.quantity;
    if (currentQuantity) {
      const newQuantity = newItems.find(
        (i) => i.code === (newPlanInfo.supportOnly ? newPlanInfo.supportItemCode : newPlanInfo.mainItemCode)
      )?.quantity;
      if (!newQuantity || newQuantity < currentQuantity) {
        nsutils.logMayBe('isQuantityDowngrade res', true);
        return true;
      }
    }
    nsutils.logMayBe('isQuantityDowngrade res', false);
    return false;
  }

  public validateSuspension(params: SubscriptionUpdateParams) {
    assertNotNull(params.subscriptionId, 'subscriptionId');
    if (params.content?.items?.find((i) => i.quantity === 0)) {
      const cos = subscriptionDao.findTodaysCO(params.subscriptionId, ['ACTIVATE', 'REACTIVATE', 'SUSPEND']);
      if (cos.length > 0) {
        throw new Error(
          'It is not possible to update quantity to 0 on the same day of activation, reactivation or suspension'
        );
      }
    }
  }

  public validateActiveSubscriptionHasNoDrafts(subscriptionId: number, status: SubscriptionStatus) {
    if (status === SubscriptionStatus.ACTIVE) {
      const renewalHistory = subscriptionDao.getRenewalHistoryOfSubscription(subscriptionId);
      if (renewalHistory.length > 0) {
        throw new Error(
          'Subscription can not be modified because renewal is already generated. Please contact support for further assistance.'
        );
      }
    }
  }

  private validateAndPrepareData(params: SubscriptionCreateParamsNoQuantityReq) {
    assertNotNull(params.content, 'content');
    assertNotNull(params.content.planCode, 'planCode');
    assertNotNull(params.content.frequency, 'frequency');
    const planAndPriceBook = subscriptionPlanUtility.findSubscriptionPlanAndPriceBook(
      params.content.planCode,
      params.customerId,
      params.content.frequency
    );
    params.content.planId = planAndPriceBook.subscriptionPlanId;
    params.content.planClass = planAndPriceBook.subscriptionPlanClass;
    params.content.priceBookId = planAndPriceBook.priceBookId;
  }

  public validateRenewalInfoParams(params: GetRenewalInfoParams): {
    productTier: ProductTier;
    supportLevel: SupportLevel;
  } {
    const productTier = ProductTierUtil.nameToProductTier(params.productTier);
    if (!productTier) {
      throw new ValidationError('Invalid Product Tier');
    }
    const supportLevel = SupportLevelUtil.nameToSupportLevel(params.supportLevel);
    if (!supportLevel) {
      throw new ValidationError('Invalid Support Level');
    }
    const subscriptionRecord = SubscriptionRecord.load(must(params.subscriptionId,'subscriptionId'), false);
    if (subscriptionRecord.customerId !== params.customerId) {
      throw new SubscriptionNotFoundError();
    }
    return { productTier, supportLevel };
  }
}

export default new SubscriptionValidateUtility();
