import * as record from 'N/record';
import * as nsutils from '../nsutils';
import SubscriptionDao from '../dao/SubscriptionDao';
import { TermUnit } from '../types';
import { TermDuration } from '../models/TermDuration';
import { assertNotNullMsg, ValidationError } from '../validation';
import subscriptionValidateUtility from '../utility/SubscriptionValidateUtility';

export class TermUtility {
  private createStandardTerm(duration: number, unit: TermUnit) {
    const subscriptionTerm = record.create({
      type: 'subscriptionterm',
      isDynamic: true,
    });
    const values = {
      name: `${duration} ${unit}`,
      subscriptiontermduration: duration,
      subscriptiontermunit: unit,
    };
    nsutils.setRecordValues(subscriptionTerm, values);
    subscriptionTerm.save();
    return subscriptionTerm;
  }

  public findOrCreateStandardTerm(term: TermDuration): number {
    let existingTerm = SubscriptionDao.findStandardTerm(term.duration, term.units);
    if (!existingTerm) {
      existingTerm = this.createStandardTerm(term.duration, term.units);
    }
    return existingTerm.id;
  }

  public setInitialTerm(term: TermDuration, sub: nsutils.RecWrapper) {
    sub.setIfDef('initialterm', this.findOrCreateStandardTerm(term));
  }

  public setInitialTermForTrialSubscription(duration, subscriptionRec: record.Record, sub: nsutils.RecWrapper) {
    nsutils.logMayBe('setInitialTermForTrialSubscription params', {
      duration: duration,
      subscriptionRec: subscriptionRec,
      sub: sub,
    });

    assertNotNullMsg(duration, 'trialDuration is not set in the Trial Subscription Config in the product integration');
    const defaultTerm = subscriptionRec.getValue('defaultrenewalterm');
    this.setInitialTerm(new TermDuration(duration, TermUnit.DAYS), sub);
    // when initialterm is set, automatically change defaultrenewalterm, here it's changing back the original defaultrenewalterm
    sub.setIfDef('defaultrenewalterm', defaultTerm);
  }

  public setInitialTermForNewSubscription(term: TermDuration, sub: nsutils.RecWrapper) {
    nsutils.logMayBe('setInitialTermForNewSubscription params', { term: term, sub: sub });
    if ('EVERGREEN' === sub.rec.getValue('initialtermtype')) {
      throw new ValidationError('Evergreen subscription does not support duration', 'duration');
    }
    subscriptionValidateUtility.validateDurationGreaterOrEqualToInitialTerm(term, sub);
    this.setInitialTerm(term, sub);
  }
}

export default new TermUtility();
