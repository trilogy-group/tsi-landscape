import { convert } from './nsutils';

const HTTP_400 = 400;
const HTTP_404 = 404;

export class ValidationError extends Error {
  fieldName?: string;
  status = HTTP_400;
  constructor(message: string, fieldName?: string) {
    super(message);
    this.fieldName = fieldName;
  }
}

export class NotFoundError extends ValidationError {
  status = HTTP_404;
}
export class SubscriptionNotFoundError extends NotFoundError {
  constructor() {
    super('Subscription not found or it is from another customer', 'subscriptionId');
  }
}
export class QuoteNotFoundError extends NotFoundError {
  constructor() {
    super('Quote not found or it is from another customer', 'quoteId');
  }
}

/**
 * checks if value is not null and not undefined
 * @param val val to be checked
 * @returns true if is not null and false otherwise
 */
export function isNotNull<T>(val: T): val is NonNullable<T> {
  return val !== undefined && val !== null;
}

/**
 * checks if value is null or undefined
 * @param val val to be checked
 */
export function isNull<T>(val: T) {
  return val === undefined || val === null;
}

/**
 * checks if a string is not empty
 * @param val string to be checked
 * @returns true if is not blank or false otherwise
 */
export function isNotBlank(val?: string | null): val is string {
  return isNotNull(val) && val.trim().length > 0;
}

/**
 * asserts value is not null or undefined
 * @param val to be checked
 * @param fieldName name of the field to have in the error message if it fails
 */
export function assertNotNull<T>(val: T | null | undefined, fieldName?: string): asserts val is T {
  if (val === undefined || val === null) {
    throw new ValidationError(`${fieldName || 'value'} is mandatory`);
  }
}

/**
 * asserts value is not null or undefined and throw a custom message
 * @param val to be checked
 * @param msg to thrown if it fails
 */
export function assertNotNullMsg<T>(val: T | null | undefined, msg: string): asserts val is T {
  if (val === undefined || val === null) {
    throw new Error(msg);
  }
}

/**
 * assert the value exists
 * @param val to be checked
 * @param fieldName name of the field to have in the error message if it fails
 * @returns the value
 */
export function must<T>(val: T | null | undefined, fieldName?: string): T {
  if (val === undefined || val === null) {
    throw new ValidationError(`${fieldName || 'value'} is mandatory`);
  } else {
    return val;
  }
}

/**
 * assert the value exists and is zero or positive
 * @param val to be checked
 * @param fieldName name of the field to have in the error message if it fails
 */
export function assertNonNegative(val: number | null | undefined, fieldName?: string): asserts val is number {
  if (val === undefined || val === null || Number.isNaN(val) || val < 0) {
    throw new ValidationError(`${fieldName || 'value'} is mandatory and should be non-negative`);
  }
}

/**
 * Assert the list informed is not empty
 * @param val list to be checked
 * @param msg error message if is empty
 */
export function assertListNotEmpty<T>(val: T[] | null | undefined, msg: string): asserts val is T[] {
  if (!val || val.length === 0) {
    throw new Error(msg);
  }
}

/**
 * asserts condition needs to be true
 * @param condition condition to be checked
 * @param message error message to be thrown if condition is false
 */
export function assertTrue(condition: boolean, message?: string) {
  if (!condition) {
    throw new ValidationError(`${message}`);
  }
}

/**
 * asserts string is valid NetSuite date - DD-MMM-YYYY
 * @param val to be checked
 * @param fieldName name of the field to have in the error message if it fails
 */
export function assertNsDate(val: string, fieldName?: string) {
  const parsed = convert.toDate(val);

  if (typeof parsed === 'string' && val === parsed) {
    throw new ValidationError(`Failed to parse ${fieldName || 'value'}. Expected format is DD-MMM-YYYY.`);
  }
}
