module.exports = {
	defaultProjectFolder: "dist",
	commands: {}
};
