import { FieldType } from 'N/ui/serverWidget';
import { beforeLoad } from '../src/ts/events/AgreementEvent';
import { QuoteRecord } from '../src/ts/models/QuoteRecord';
import * as record from 'N/record';
import * as redirect from 'N/redirect';

describe('beforeLoad', () => {
  let contextMock: any;
  let formMock: any;

  beforeEach(() => {
    formMock = {
      getButton: jest.fn(),
      removeButton: jest.fn(),
      addButton: jest.fn(),
      addField: jest.fn(() => { return formMock.field }),
      field: { defaultValue: null },
    };

    contextMock = {
      type: 'view',
      newRecord: {
        getValue: jest.fn()
      },
      form: formMock,
      UserEventType: {
        VIEW: 'view',
      },
    };
  });

  it('should return early if the user event type is not VIEW', () => {
    contextMock.type = 'create'; // Simulate a different event type

    beforeLoad(contextMock);

    expect(formMock.getButton).not.toHaveBeenCalled();
    expect(formMock.removeButton).not.toHaveBeenCalled();
    expect(formMock.addButton).not.toHaveBeenCalled();
    expect(formMock.addField).not.toHaveBeenCalled();
  });

  it('should return early if the agreement type is filled in', () => {
    contextMock.newRecord.getValue.mockReturnValue('someAgreementType');

    beforeLoad(contextMock);

    expect(formMock.getButton).not.toHaveBeenCalled();
    expect(formMock.removeButton).not.toHaveBeenCalled();
    expect(formMock.addButton).not.toHaveBeenCalled();
    expect(formMock.addField).not.toHaveBeenCalled();
  });

  it('should return early if the "Send For Signature" button is undefined', () => {
    formMock.getButton.mockReturnValue(undefined);

    beforeLoad(contextMock);

    expect(formMock.getButton).toHaveBeenCalledWith({ id: 'custpage_send_button' });
    expect(formMock.removeButton).not.toHaveBeenCalled();
    expect(formMock.addButton).not.toHaveBeenCalled();
    expect(formMock.addField).not.toHaveBeenCalled();
  });

  it('should replace the "Send For Signature" button and add the error message script field', () => {
    const sendForSignatureBtnMock = {};
    formMock.getButton.mockReturnValue(sendForSignatureBtnMock);

    beforeLoad(contextMock);

    expect(formMock.getButton).toHaveBeenCalledWith({ id: 'custpage_send_button' });
    expect(formMock.removeButton).toHaveBeenCalledWith({ id: 'custpage_send_button' });
    expect(formMock.addButton).toHaveBeenCalledWith({
      id: 'custpage_send_error_button',
      label: 'Send For Signature',
      functionName: 'showErrorMessage',
    });
    expect(formMock.addField).toHaveBeenCalledWith({
      id: 'custpage_script_field_empty_agreement_type',
      label: 'Script Field',
      type: FieldType.INLINEHTML,
    });

    expect(formMock.field.defaultValue).toContain('Agreement Type is empty');
  });
});

describe('setExpirationDays', () => {
  let contextMock: any;
  let newRecordMock: any;

  beforeEach(() => {
    newRecordMock = {
      getValue: jest.fn(),
      id: 123,
    };

    contextMock = {
      type: 'view',
      newRecord: newRecordMock,
      UserEventType: {
        VIEW: 'view',
      },
    };
  });

  afterEach(() => {
    jest.clearAllMocks();
  });

  it('should return early if the agreement is not in draft status', () => {
    newRecordMock.getValue.mockImplementation((key) => {
      switch (key) {
        case 'custrecord_echosign_status': 
          return '2'; // Simulate a non draft status
        case 'custrecord_agreement_type':
          return 'someAgreementType';
        default:
          return null;
      }
    });

    beforeLoad(contextMock);

    expect(record.submitFields).not.toHaveBeenCalled();
    expect(redirect.toRecord).not.toHaveBeenCalled();
  });

  it('should return early if the agreement is not created from a quote', () => {
    newRecordMock.getValue.mockImplementation((key) => {
      switch (key) {
        case 'custrecord_echosign_status': 
          return '1'; // Simulate a draft status
        case 'custrecord_echosign_parent_type':
          return 'invoice'; // Simulate a quote parent type
        case 'custrecord_agreement_type':
          return 'someAgreementType';
        default:
          return null;
      }
    });

    beforeLoad(contextMock);

    expect(record.submitFields).not.toHaveBeenCalled();
    expect(redirect.toRecord).not.toHaveBeenCalled();
  });

  it('should return early if the expiration days is today', () => {
    newRecordMock.getValue.mockImplementation((key) => {
      switch (key) {
        case 'custrecord_echosign_status': 
          return '1'; // Simulate a draft status
        case 'custrecord_echosign_parent_type':
          return 'estimate'; // Simulate a quote parent type
        case 'custrecord_echosign_days_until_deadline':
          return 5; // Simulate 5 expiration days
        case 'custrecord_agreement_type':
          return 'someAgreementType';
        default:
          return null;
      }
    });
    const today = new Date();
    today.setHours(0,0,0,0);
    jest.spyOn(QuoteRecord, 'load').mockReturnValueOnce({ expirationDate: today } as any); // Simulate a quote expiring in 5 days

    beforeLoad(contextMock);

    expect(record.submitFields).not.toHaveBeenCalled();
    expect(redirect.toRecord).not.toHaveBeenCalled();
  });

  it('should return early if the expiration days are already set to the same value', () => {
    newRecordMock.getValue.mockImplementation((key) => {
      switch (key) {
        case 'custrecord_echosign_status': 
          return '1'; // Simulate a draft status
        case 'custrecord_echosign_parent_type':
          return 'estimate'; // Simulate a quote parent type
        case 'custrecord_echosign_days_until_deadline':
          return 5; // Simulate 5 expiration days
        case 'custrecord_agreement_type':
          return 'someAgreementType';
        default:
          return null;
      }
    });
    const in5Days = new Date();
    in5Days.setHours(0,0,0,0);
    in5Days.setDate(in5Days.getDate() + 5);
    jest.spyOn(QuoteRecord, 'load').mockReturnValueOnce({ expirationDate: in5Days } as any); // Simulate a quote expiring in 5 days

    beforeLoad(contextMock);

    expect(record.submitFields).not.toHaveBeenCalled();
    expect(redirect.toRecord).not.toHaveBeenCalled();
  });

  it('should set the expiration days and redirect to the agreement record', () => {
    newRecordMock.getValue.mockImplementation((key) => {
      switch (key) {
        case 'custrecord_echosign_status': 
          return '1'; // Simulate a draft status
        case 'custrecord_echosign_parent_type':
          return 'estimate'; // Simulate a quote parent type
        case 'custrecord_echosign_days_until_deadline':
          return 10; // Simulate 10 expiration days
        case 'custrecord_agreement_type':
          return 'someAgreementType';
        default:
          return null;
      }
    });
    const in5Days = new Date();
    in5Days.setHours(0,0,0,0);
    in5Days.setDate(in5Days.getDate() + 5);
    jest.spyOn(QuoteRecord, 'load').mockReturnValueOnce({ expirationDate: in5Days } as any); // Simulate a quote expiring in 5 days

    beforeLoad(contextMock);

    expect(record.submitFields).toHaveBeenCalledWith({
      type: 'customrecord_echosign_agreement',
      id: newRecordMock.id,
      values: {
        custrecord_echosign_days_until_deadline: 5,
      },
    });
    expect(redirect.toRecord).toHaveBeenCalledWith({
      type: 'customrecord_echosign_agreement',
      id: newRecordMock.id,
    });
  });
});