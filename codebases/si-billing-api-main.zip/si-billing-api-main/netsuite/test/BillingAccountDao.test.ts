import billingAccountDao from '../src/ts/dao/BillingAccountDao'
import * as nsutils from '../src/ts/nsutils'
import * as query from 'N/query';
import * as record from 'N/record';
import { BillingSchedule } from '../src/ts/types';

describe('BillingAccountDao', () => {

  beforeEach(() => {
    jest.restoreAllMocks()
    jest.spyOn(nsutils, 'queryToJson')
    jest.spyOn(nsutils, 'queryFirstToJson')
    jest.spyOn(nsutils, 'queryFirstAsMap')
  })

  it('getBillingScheduleId', () => {
    (nsutils.queryFirstAsMap as any).mockReturnValueOnce({id: 1});
    (nsutils.queryFirstAsMap as any).mockReturnValueOnce({id: 1});
    billingAccountDao.getBillingScheduleId(BillingSchedule.ANNUALLY);

    expect(nsutils.queryFirstAsMap).toBeCalledWith(expect.stringContaining('select id from billingschedule'), ['Annual Billing'])

    billingAccountDao.getBillingScheduleId(BillingSchedule.MONTHLY);

    expect(nsutils.queryFirstAsMap).toBeCalledWith(expect.stringContaining('select id from billingschedule'), ['Monthly Billing'])
  })

  it('getBillingScheduleId not found', () => {
    expect(() => billingAccountDao.getBillingScheduleId(BillingSchedule.ANNUALLY)).toThrow();

    (nsutils.queryFirstAsMap as any).mockReturnValueOnce({});
    expect(() => billingAccountDao.getBillingScheduleId(BillingSchedule.ANNUALLY)).toThrow();
  })

})