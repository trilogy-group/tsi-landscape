import { beforeSubmit } from '../src/ts/events/ContractReviewEvent';
import * as record from 'N/record';

const customerId = 'testCustId';
const customerName = 'testCustName';
const planName = 'testPlanName';

describe('ContractReviewEvent', () => {
  beforeEach(() => {
    // Clear all instances and calls to constructor and all methods:
    jest.clearAllMocks();
  });

  it('calls load function of record module twice when the context type is CREATE', () => {
    const context: any = {
      type: 'create',
      newRecord: { setValue: jest.fn(), getValue: jest.fn().mockReturnValue('testSubId') },
      UserEventType: {
        CREATE: 'create'
      }
    };
    
    jest.spyOn(record, 'load').mockImplementationOnce(() => {
      return { getValue: jest.fn().mockImplementation((field) => field === 'customer' ? customerId : planName) } as any;
    });

    jest.spyOn(record, 'load').mockImplementationOnce(() => {
      return { getValue: jest.fn().mockReturnValue(customerName) } as any;
    });

    beforeSubmit(context);
    // Expect that the record.load has been called twice, once for the subscription and once for the customer
    expect(record.load).toHaveBeenCalledTimes(2);
  });

  it('calls load function of record module twice when the context type is EDIT and subscription IDs differ', () => {
    const context: any = {
      type: 'edit',
      newRecord: { setValue: jest.fn(), getValue: jest.fn().mockReturnValue('newID') },
      oldRecord: { getValue: jest.fn().mockReturnValue('oldID') },
      UserEventType: {
        CREATE: 'create',
        EDIT: 'edit'
      }
    };
    
    jest.spyOn(record, 'load').mockImplementationOnce(() => {
      return { getValue: jest.fn().mockImplementation((field) => field === 'customer' ? customerId : planName) } as any;
    });

    jest.spyOn(record, 'load').mockImplementationOnce(() => {
      return { getValue: jest.fn().mockReturnValue(customerName) } as any;
    });

    beforeSubmit(context);
    // Expect that the record.load has been called twice, once for the subscription and once for the customer
    expect(record.load).toHaveBeenCalledTimes(2);
  });

  it('does not call load function of record module when the context type is EDIT and subscription IDs are same', () => {
    const context: any = {
      type: 'edit',
      newRecord: { setValue: jest.fn(), getValue: jest.fn().mockReturnValue('sameID') },
      oldRecord: { getValue: jest.fn().mockReturnValue('sameID') },
      UserEventType: {
        CREATE: 'create',
        EDIT: 'edit'
      }
    };
    
    beforeSubmit(context);

    // Expect that the record.load has not been called
    expect(record.load).not.toHaveBeenCalled();
  });
});
