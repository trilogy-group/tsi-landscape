// ContractualDocumentsEvent.test.ts
import * as record from 'N/record';
import { beforeSubmit } from '../src/ts/events/ContractualDocumentsEvent';
import { ContractualDocumentsRecord } from '../src/ts/models/ContractualDocumentsRecord';
import { QuoteRecord } from '../src/ts/models/QuoteRecord';
import QuoteService from '../src/ts/utility/QuoteService';

jest.mock('../src/ts/models/ContractualDocumentsRecord', () => {
    return {
        ContractualDocumentsRecord: jest.fn().mockImplementation((rec: record.Record, isDynamic: boolean) => rec)
    };
});
jest.mock('../src/ts/models/QuoteRecord');
jest.mock('../src/ts/utility/QuoteService');

describe('beforeSubmit', () => {
    let contextMock: any;
    let contractualDocumentsMock: any;
    let quoteMock: any;

    beforeEach(() => {
        contractualDocumentsMock = {
            id: 1,
            quote: 11,
        };

        quoteMock = {
            id: 11,
            customForm: 21,
        };
        (QuoteRecord.load as jest.Mock).mockReturnValue(quoteMock);

        contextMock = {
            type: 'create',
            newRecord: contractualDocumentsMock,
            UserEventType: {
                CREATE: 'create',
                EDIT: 'edit',
            },
        };
    });

    afterEach(() => {
        jest.clearAllMocks();
    });

    it('should return early if the user event type is not CREATE or EDIT', () => {
        contextMock.type = 'view';

        beforeSubmit(contextMock);

        expect(ContractualDocumentsRecord).not.toHaveBeenCalled();
    });

    it('should not set the ESW paper checkbox if the related quote is not found', () => {
        contractualDocumentsMock.quote = null;

        beforeSubmit(contextMock);

        expect(ContractualDocumentsRecord).toHaveBeenCalledWith(contractualDocumentsMock, false);
        expect(QuoteRecord.load).not.toHaveBeenCalled();
    });
  
    it('should set the ESW paper checkbox based on the custom form of the related quote', () => {
        const isEwsPaper = true;
        (QuoteService.isESWForm as jest.Mock).mockReturnValue(isEwsPaper);

        beforeSubmit(contextMock);

        expect(QuoteRecord.load).toHaveBeenCalledWith(contractualDocumentsMock.quote);
        expect(QuoteService.isESWForm).toHaveBeenCalledWith(quoteMock.customForm);
        expect(contractualDocumentsMock.isESWPaper).toBe(isEwsPaper);
    });

    it('should not set the link to contract PDF if already defined', () => {
        contractualDocumentsMock.linkToContractPDF = 'test.pdf';

        beforeSubmit(contextMock);

        expect(ContractualDocumentsRecord).toHaveBeenCalledWith(contractualDocumentsMock, false);
        expect(QuoteService.getSignedDocUrlFromQuote).not.toHaveBeenCalled();
    });

    it('should set the link to contract PDF from quote agreement if undefined', () => {
        contractualDocumentsMock.linkToContractPDF = null;
        const linkToContractPDF = 'test.pdf';
        (QuoteService.getSignedDocUrlFromQuote as jest.Mock).mockReturnValue(linkToContractPDF);

        beforeSubmit(contextMock);

        expect(QuoteService.getSignedDocUrlFromQuote).toHaveBeenCalledWith(contractualDocumentsMock.quote);
        expect(contractualDocumentsMock.linkToContractPDF).toBe(linkToContractPDF);
    });
});
