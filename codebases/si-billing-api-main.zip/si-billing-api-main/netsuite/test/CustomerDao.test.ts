import customerDao from '../src/ts/dao/CustomerDao'
import * as nsutils from '../src/ts/nsutils'
import * as query from 'N/query';
import * as record from 'N/record';
import { BillingSchedule } from '../src/ts/types';

describe('npm', () => {

  beforeEach(() => {
    jest.restoreAllMocks()
    jest.spyOn(nsutils, 'queryToJson')
    jest.spyOn(nsutils, 'queryFirstToJson')
    jest.spyOn(nsutils, 'queryFirstAsMap')
  })

  it('getInternalId', () => {
    (nsutils.queryFirstAsMap as any).mockReturnValueOnce({id: 1});
    let res = customerDao.getInternalId("TestCustomer");
    expect(res).toBe(1);

    (nsutils.queryFirstAsMap as any).mockReturnValueOnce({});
    expect(() => customerDao.getInternalId("TestCustomer")).toThrow();

    (nsutils.queryFirstAsMap as any).mockReturnValueOnce(undefined);
    expect(() => customerDao.getInternalId("TestCustomer")).toThrow();

    res = customerDao.getInternalId(undefined);
    expect(res).toBe(undefined);

    res = customerDao.getInternalId(null as any);
    expect(res).toBe(undefined);
  })

  it('getCustomerInfo should return undefined if the customer ID is null', () => {
    // Arrange
    const customerInternalId = null;

    // Act
    const result = customerDao.getCustomerInfo(customerInternalId);

    // Assert
    expect(result).toBeUndefined();
  });

  it('getCustomerInfo should delete shipping address if it is the same than the billing address', () => {
    // Arrange
    const customerInternalId = 1;
    jest.spyOn(nsutils, 'queryFirstToJson')
      .mockReturnValueOnce({ // customer info
        address: { id: 11 },
        shippingAddress: { id: 11 },
      })
      .mockReturnValueOnce({ // address
        country: 'US', 
      });

    // Act
    const result = customerDao.getCustomerInfo(customerInternalId);

    // Assert
    expect(result).toBeDefined();
    expect(result?.address).toBeDefined();
    expect(result?.shippingAddress).toBeUndefined();
  });

  it('getCustomerInfo should load primary contact and its address if defined', () => {
    // Arrange
    const customerInternalId = 1;
    jest.spyOn(nsutils, 'queryFirstToJson')
      .mockReturnValueOnce({}) // customer info
      .mockReturnValueOnce({ // primary contact
        billingAddress: { id: 12 },      
      })
      .mockReturnValueOnce({ // address
        country: 'US',
      });

    // Act
    const result = customerDao.getCustomerInfo(customerInternalId);

    // Assert
    expect(result).toBeDefined();
    expect(result?.primaryContact?.billingAddress).toBeDefined();
  });

  it('getEntityStatus', () => {
    (nsutils.queryFirstAsMap as any).mockReturnValueOnce({id: 1, entitystatus: 2});
    let res = customerDao.getEntityStatus("TestCustomer");
    expect(res).toBe(2);

    (nsutils.queryFirstAsMap as any).mockReturnValueOnce({});
    expect(() => customerDao.getEntityStatus("TestCustomer")).toThrow();

    (nsutils.queryFirstAsMap as any).mockReturnValueOnce(undefined);
    expect(() => customerDao.getEntityStatus("TestCustomer")).toThrow();

    expect(() => customerDao.getEntityStatus(null as any)).toThrow();
  })


  it('findCustomerAndBa', () => {
    (nsutils.queryFirstToJson as any).mockReturnValueOnce({id: 42})
    
    const res = customerDao.findCustomerAndBa({classId: 1, customerId: 'TestCustomer', subsidiaryId: 2, frequency: BillingSchedule.MONTHLY });
    
    expect(res).toStrictEqual({id: 42})
  })

  it('getCustomerSubsidiary', () => {
    (query.runSuiteQL as any).mockReturnValueOnce({results: [{asMap: ()=>({subsidiary: 22, isprimarysub: 'T'})}]})
    
    const res = customerDao.getCustomerSubsidiaries('TestCustomer');
    
    expect(res).toStrictEqual([{subsidiaryId: '22', primary: true}])
  })

  it('getPrimaryCurrency should return the customer currency', () => {
    // Arrange
    const customerId = '101';
    const currency = { id: '1', symbol: 'USD' };
    jest.spyOn(nsutils, 'queryFirstAsMap').mockReturnValueOnce(currency);

    // Act
    const result = customerDao.getPrimaryCurrency(customerId);

    // Assert
    expect(result).toStrictEqual(currency);
  });
})