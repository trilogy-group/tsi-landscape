import SubscriptionDao from '../src/ts/dao/SubscriptionDao';
import { QuoteRecord } from '../src/ts/models/QuoteRecord';
import { SubscriptionRecord } from '../src/ts/models/SubscriptionRecord';
import * as CustomerMemo from '../src/ts/events/CustomerMemo';
import * as log from 'N/log';

describe('CustomerMemo/beforeSubmit', () => {
  var mockContext : any;

  beforeEach(() => {
    jest.clearAllMocks();

    jest.spyOn(SubscriptionRecord, 'load').mockReturnValue({
      customerMemo: 'Subscription memo',
    } as any);

    mockContext = {
      type: 'create',
      newRecord: {
        getValue: jest.fn(),
        getSublistValue: jest.fn(),
        setValue: jest.fn(),
      },
      UserEventType: {
        CREATE: 'create'
      },
    } as any;
  });

  test('does not modify memo if subscription ID is missing', () => {
    mockContext.newRecord.getSublistValue.mockReturnValueOnce(undefined);

    CustomerMemo.beforeSubmit(mockContext);

    expect(mockContext.newRecord.setValue).not.toHaveBeenCalled();
  });

  test('does not modify memo if record type is not custinvc', () => {
    mockContext.newRecord.getValue.mockReturnValueOnce('not-custinvc');

    CustomerMemo.beforeSubmit(mockContext);

    expect(mockContext.newRecord.setValue).not.toHaveBeenCalled();
  });

  test('does not modify memo if memo already contains subscription memo', () => {
    mockContext.newRecord.getSublistValue.mockReturnValueOnce('123');
    mockContext.newRecord.getValue.mockReturnValueOnce('Subscription memo');

    CustomerMemo.beforeSubmit(mockContext);

    expect(mockContext.newRecord.setValue).not.toHaveBeenCalled();
  });

  test('appends subscription memo to memo if not already present', () => {
    mockContext.newRecord.getSublistValue.mockReturnValueOnce('123');
    mockContext.newRecord.getValue.mockReturnValueOnce('custinvc');
    mockContext.newRecord.getValue.mockReturnValueOnce('Original memo');
    const expectedMemo = 'Original memo\r\nSubscription memo';

    CustomerMemo.beforeSubmit(mockContext);

    expect(mockContext.newRecord.setValue).toHaveBeenCalledWith('custbody_customer_memo', expectedMemo);
  });

  test('logs error if subscription load fails', () => {
    mockContext.newRecord.getSublistValue.mockReturnValueOnce('123');
    mockContext.newRecord.getValue.mockReturnValueOnce('custinvc');
    const error = new Error('Failed to load subscription');
    jest.spyOn(SubscriptionRecord, 'load').mockImplementationOnce(() => { throw error; });
    jest.spyOn(log, 'error').mockImplementationOnce(jest.fn());

    CustomerMemo.beforeSubmit(mockContext);

    expect(log.error).toHaveBeenCalledWith({ title: 'CustomerMemo/beforeSubmit', details: 'Failed to copy customer memo from subscription 123. Error: Failed to load subscription' });
  });

  it('addStringIfNotPresent', () => {
    expect(CustomerMemo.addStringIfNotPresent(null, null)).toBeNull();
    expect(CustomerMemo.addStringIfNotPresent(null, 'a')).toBe('a');
    expect(CustomerMemo.addStringIfNotPresent('a', null)).toBe('a');
    expect(CustomerMemo.addStringIfNotPresent('a', 'a')).toBe('a');
    expect(CustomerMemo.addStringIfNotPresent('a', 'b')).toBe('a\r\nb');
    expect(CustomerMemo.addStringIfNotPresent('a\r\nb', 'b')).toBe('a\r\nb');
    expect(CustomerMemo.addStringIfNotPresent('a\r\nb', 'c')).toBe('a\r\nb\r\nc');
  });
});

//Generate the following jest unit tests for the afterSubmit function
//
//1. do nothing is event properties do not match
//2. do nothing is subscription is undefined in the new record
//3. do nothing if signed quote not found
//4. do nothing if line items header text is not defined or blank
//5. keep subscription customer memo unmodified if it already contains text from quote's line items header text 
//6. append quote's line items header text to subscription customer memo
//7. log error if exception is thrown
//
//

jest.mock('../src/ts/dao/SubscriptionDao', () => ({ 
  findSignedQuoteId: jest.fn().mockReturnValue(789) 
}));

describe('CustomerMemo.afterSubmit', () => {

  let context;
  let quoteRecord;
  let subscriptionRecord;
  const defGetValue = (fieldId) => {
    switch (fieldId) {
      case 'type': return 'SubscriptionChangeOrder';
      case 'action': return 'activate';
      case 'subscriptionchangeorderstatus': return 'active';
      case 'subscription': return '123';
      default: return null;
    }
  };  

  beforeEach(() => {
    context = {
      type: 'create',
      UserEventType: {
        CREATE: 'create'
      },
      newRecord: {
        getValue: jest.fn(defGetValue),
        id: '456',
      }
    };

    quoteRecord = {
      load: jest.fn(),
      lineItemsHeaderText: null
    };
    jest.spyOn(QuoteRecord, 'load').mockImplementation(() => quoteRecord);

    subscriptionRecord = {
      load: jest.fn(),
      save: jest.fn(),
      customerMemo: '',
      rec: {
        setValue: jest.fn(),
      }
    };
    jest.spyOn(SubscriptionRecord, 'load').mockImplementation(() => subscriptionRecord);
  });

  afterEach(() => {
    jest.restoreAllMocks();
  });

  test('should do nothing if event properties do not match', () => {
    context.type = 'delete';
    const logDebug = jest.spyOn(log, 'debug').mockImplementationOnce(jest.fn());
    CustomerMemo.afterSubmit(context);
    expect(logDebug).toHaveBeenCalledWith({ title: 'CustomerMemo/shouldTransferQuoteToSub', details: 'RecType: subscriptionchangeorder, op: delete' });
    expect(context.newRecord.getValue).not.toHaveBeenCalledWith('subscription');
  });

  test('should do nothing if subscription is undefined in the new record', () => {
    context.newRecord.getValue = jest.fn((fieldId) => fieldId === 'subscription' ? null : defGetValue(fieldId));
    const logDebug = jest.spyOn(log, 'debug').mockImplementationOnce(jest.fn());

    CustomerMemo.afterSubmit(context);

    expect(logDebug.mock.calls.pop()).toEqual([{ title: 'CustomerMemo/afterSubmit', details: 'Subscription Id is not set for change order 456' }]);
    expect(SubscriptionDao.findSignedQuoteId).not.toBeCalled();
  });

  test('should do nothing if signed quote not found', () => {
    jest.spyOn(SubscriptionDao, 'findSignedQuoteId').mockReturnValueOnce(null);

    CustomerMemo.afterSubmit(context);

    expect(quoteRecord.load).not.toBeCalled();
  });

  test('should do nothing if line items header text is not defined or blank', () => {
    CustomerMemo.afterSubmit(context);

    expect(subscriptionRecord.save).not.toBeCalled();
  });

  test('should keep subscription customer memo unmodified if it already contains text from quote\'s line items header text', () => {
    
    quoteRecord.lineItemsHeaderText = 'Quote memo';
    subscriptionRecord.customerMemo = 'Subscription memo\r\nQuote memo';

    CustomerMemo.afterSubmit(context);

    expect(subscriptionRecord.save).not.toBeCalled();
  });

  test('should append quote\'s line items header text to subscription customer memo', () => {
    quoteRecord.lineItemsHeaderText = 'Quote memo1';
    subscriptionRecord.customerMemo = 'Subscription memo1';
    
    CustomerMemo.afterSubmit(context);

    expect(subscriptionRecord.customerMemo).toEqual('Subscription memo1\r\nQuote memo1');
    expect(subscriptionRecord.save).toBeCalled();
  });
    
  test('should log error if exception is thrown', () => {
    const errorMessage = 'something went wrong';
    const error = new Error(errorMessage);
    const subId = parseInt(context.newRecord.getValue('subscription') as string);
    jest.spyOn(SubscriptionDao, 'findSignedQuoteId').mockImplementationOnce(() => { throw error; });
    const logError = jest.spyOn(log, 'error').mockImplementationOnce(jest.fn());

    CustomerMemo.afterSubmit(context);
    expect(logError).toHaveBeenCalledWith({ title: 'CustomerMemo/afterSubmit', details: `Failed to copy customer memo from quote (subId: ${subId}). ${error}`});
    expect(subscriptionRecord.save).not.toBeCalled();
  });
});
