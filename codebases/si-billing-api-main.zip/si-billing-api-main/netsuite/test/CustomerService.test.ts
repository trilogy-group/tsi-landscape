
import customerService from '../src/ts/CustomerService';
import * as nsutils from '../src/ts/nsutils';
import * as record from 'N/record';
import * as file from 'N/file';
import billingAccountDao from '../src/ts/dao/BillingAccountDao';
import customerDao from '../src/ts/dao/CustomerDao';
import { BillingSchedule } from '../src/ts/types';
import { RecordDynamicMock } from './SublistMock';
import { clone } from '../src/ts/utility/GeneralUtility';
import SubscriptionDao from '../src/ts/dao/SubscriptionDao';
import EntityDao from '../src/ts/dao/EntityDao';
import { ProductIntegration } from '../src/ts/ProductIntegration';
import * as render from 'N/render';
import { HandlerResponse } from '../src/ts/types';

function spyPrivate(obj: any, methodName: string, impl?: any) {
  const f = jest.spyOn(Object.getPrototypeOf(obj), methodName)
  if (impl) {
    return f.mockImplementation(impl);
  }
  return f;
}

// expose private methods
function exposePrivate(obj): any {
  //tbd bind
  return Object.getPrototypeOf(obj);
}

describe('CustomerService', () => {
  beforeEach(() => {
    jest.restoreAllMocks()
    jest.spyOn(nsutils, 'queryToJson')
    jest.spyOn(nsutils, 'queryFirstToJson')
    jest.spyOn(nsutils, 'queryFirstAsMap')
    spyPrivate(customerService, 'getCustomerByEntityId')
    jest.spyOn(billingAccountDao, 'getBillingScheduleId').mockReturnValue(220);
  })

  it('createBillingAccount', () => {
    const ba = customerService.createBillingAccount({classId: 1, customerId: '123', subsidiaryId: 2, frequency: BillingSchedule.MONTHLY, effectiveDate: new Date().toISOString().split('T')[0] });

    expect(ba).toMatchObject({
      id: 1,
      customer: '123',
      billingschedule: 220,
      class: 1,
      department: 2
    })
  })

  it('upsertCustomer should throw an error when a mandatory field is missing', () => {
    // Arrange
    const initialParams: any = {
      productFamilyCode: 'DNN',
      productVariantCode: 'OP-Pro',
      content: {},
    };

    const tests = [
      { update: (p: any) => delete p.productFamilyCode, expected: { message: 'productFamilyCode is mandatory' } },
      { update: (p: any) => delete p.productVariantCode, expected: { message: 'productVariantCode is mandatory' } },
      { update: (p: any) => delete p.content, expected: { message: 'body is mandatory' } },
    ];
    const upsertMethods = [ customerService.createCustomer, customerService.updateCustomer ];
    for (const test of tests) {      
      const params = clone(initialParams);
      test.update(params);

      for (const method of upsertMethods) {

        // Act
        const action = () => method.call(customerService, params);
  
        // Assert
        expect(action).toThrowError(test.expected.message);
      }
    }
  });

  it('updateCustomer should throw an error when a mandatory field is missing or invalid', () => {
    // Arrange
    const initialParams: any = {
      productFamilyCode: 'DNN',
      productVariantCode: 'OP-Pro',
      content: {
        companyName: 'My Company',
        primaryContact: {
          name: {
            firstName: 'John',
            lastName: 'Smith',
          },
        },
      },
    };

    const tests = [
      { update: () => {}, expected: { prefix: 'The following fields are missing: ', fields: [ 'id', 'currency' ] } },
      {
        update: (p: any) => { p.isPartialContent = true; p.content.id = null; p.content.currency = null; },
        expected: { prefix: 'The following fields cannot be emptied: ', fields: [ 'id', 'currency' ] } },
    ];
    for (const test of tests) {      
      const params = clone(initialParams);
      test.update(params);

      // Act
      const action = () => customerService.updateCustomer(params);

      // Assert
      expect(action).toThrowError(test.expected.prefix + test.expected.fields.join(', '));
    }
  });

  it('upsertCustomer should throw an error when a field for an individual is missing or invalid', () => {
    // Arrange
    const defaultParams: any = {
      productFamilyCode: 'DNN',
      productVariantCode: 'OP-Pro',
      content: {
        id: '101',
        currency: 'USD',
        individual: true,
        individualName: {
          firstName: 'John',
          lastName: 'Smith',
        },
      },
    };

    const tests = [
      {
        update: (p: any) => { delete p.content.individualName.firstName; delete p.content.individualName.lastName },
        expected: { prefix: 'The following fields are missing: ', fields: [ 'individualName.firstName', 'individualName.lastName' ] }
      },
      {
        methods: [ customerService.updateCustomer ],
        update: (p: any) => { p.isPartialContent = true; p.content.individualName.firstName = null; p.content.individualName.lastName = null; },
        expected: { prefix: 'The following fields cannot be emptied: ', fields: [ 'individualName.firstName', 'individualName.lastName' ] }
      },
      {
        update: (p: any) => p.content.primaryContact = { name: p.content.individualName },
        expected: { message: 'An individual customer cannot have a contact.' }
      },
    ];
    const upsertMethods = [ customerService.createCustomer, customerService.updateCustomer ];
    for (const test of tests) {
      const params = clone(defaultParams);
      test.update(params);

      for (const method of upsertMethods ?? test.methods) {

        // Act
        const action = () => method.call(customerService, params);
  
        // Assert
        expect(action).toThrowError(test.expected.message ?? test.expected.prefix + test.expected.fields.join(', '));
      }
    }
  });

  it('upsertCustomer should throw an error when a field for an company is missing or invalid', () => {
    // Arrange
    const defaultParams: any = {
      productFamilyCode: 'DNN',
      productVariantCode: 'OP-Pro',
      content: {
        id: '101',
        currency: 'USD',
        companyName: 'My Company',
        primaryContact: {
          name: {            
            firstName: 'John',
            lastName: 'Smith',
          }
        },
        address: {
          country: 'US',
        },
        shippingAddress: {
          country: 'US',
        },
      },
    };
    
    const tests = [
      {
        update: (p: any) => {
          delete p.content.companyName;
          delete p.content.primaryContact;
          delete p.content.address.country;
          delete p.content.shippingAddress.country;
        },
        expected: {
          prefix: 'The following fields are missing: ',
          fields: [ 'companyName', 'primaryContact',  'address.country', 'shippingAddress.country' ],
        },
      },
      {
        update: (p: any) => p.content.primaryContact = {},
        expected: {
          prefix: 'The following fields are missing: ',
          fields: [ 'primaryContact.name.firstName', 'primaryContact.name.lastName' ],
        },
      },
      {
        methods: [ customerService.updateCustomer ],
        update: (p: any) => {
          p.isPartialContent = true;
          p.content.companyName = null;
          p.content.primaryContact = null;
          p.content.address.country = null;
          p.content.shippingAddress.country = null;
        },
        expected: {
          prefix: 'The following fields cannot be emptied: ',
          fields: [ 'companyName', 'primaryContact',  'address.country', 'shippingAddress.country' ],
        },
      },
      {
        methods: [ customerService.updateCustomer ],
        update: (p: any) => {
          p.isPartialContent = true;
          p.content.primaryContact.name.firstName = null;
          p.content.primaryContact.name.lastName = null;
        },
        expected: {
          prefix: 'The following fields cannot be emptied: ',
          fields: [ 'primaryContact.name.firstName', 'primaryContact.name.lastName' ],
        },
      },
    ];
    const upsertMethods = [ customerService.createCustomer, customerService.updateCustomer ];
    for (const test of tests) {
      const params = clone(defaultParams);
      test.update(params);

      for (const method of test.methods ?? upsertMethods) {

        // Act
        const action = () => method.call(customerService, params);
  
        // Assert
        expect(action).toThrowError(test.expected.prefix + test.expected.fields.join(', '));
      }
    }
  });

  it('createCustomer should throw an error when a user cannot create a new customer', () => {
    // Arrange
    const params: any = {
      productFamilyCode: 'DNN',
      productVariantCode: 'OP-Pro',
      customerId: '101',
      content: {
        individual: true,
        individualName: {
          firstName: 'John',
          lastName: 'Smith',
        },
      },
    };

    // Act
    const action = () => customerService.createCustomer(params);

    // Assert
    expect(action).toThrowError(`The customer '${params.customerId}' cannot create a new customer`);
  });

  it('updateCustomer should throw an error when a user cannot update another customer', () => {
    // Arrange
    const params: any = {
      productFamilyCode: 'DNN',
      productVariantCode: 'OP-Pro',
      customerId: '101',
      content: {
        id: '102',
        currency: 'USD',
        individual: true,
        individualName: {
          firstName: 'John',
          lastName: 'Smith',
        },
      },
    };

    // Act
    const action = () => customerService.updateCustomer(params);

    // Assert
    expect(action).toThrowError(`The customer '${params.customerId}' cannot update information of the customer '${params.content.id}'`);
  });

  it('updateCustomer should throw an error when a user cannot partially update another customer', () => {
    // Arrange
    const params: any = {
      productFamilyCode: 'DNN',
      productVariantCode: 'OP-Pro',
      customerId: '101',
      isPartialContent: true,
      content: {
        id: '102',
      },
    };
    jest.spyOn(SubscriptionDao, 'isEndUserInDraftSubscriptions').mockReturnValueOnce(false);

    // Act
    const action = () => customerService.updateCustomer(params);

    // Assert
    expect(action).toThrowError(`The customer '${params.customerId}' cannot update information of the customer '${params.content.id}'`);
  });

  it('updateCustomer should throw an error when a user update forbidden fields from another customer', () => {
    // Arrange
    const params: any = {
      productFamilyCode: 'DNN',
      productVariantCode: 'OP-Pro',
      customerId: '101',
      isPartialContent: true,
      content: {
        id: '102',
        email: 'john.smith@trilogy.fake',
      },
    };
    jest.spyOn(SubscriptionDao, 'isEndUserInDraftSubscriptions').mockReturnValueOnce(true);

    // Act
    const action = () => customerService.updateCustomer(params);

    // Assert
    expect(action).toThrowError(`A customer can only update the shipping address of a related end-user.`);
  });

  it('createCustomer should throw an error when a currency cannot be find', () => {
    // Arrange
    const params: any = {
      productFamilyCode: 'DNN',
      productVariantCode: 'OP-Pro',
      content: {
        currency: 'XXX',
        individual: true,
        individualName: {
          firstName: 'John',
          lastName: 'Smith',
        },
      },
    };
    const customer: any = {
      findSublistLineWithValue: jest.fn().mockReturnValue(-1),
      save: jest.fn().mockReturnValue('101'),
      setValue: jest.fn(),
    };
    jest.spyOn(record, 'create').mockReturnValueOnce(customer);
    jest.spyOn(EntityDao, 'getEntityStatusKey').mockReturnValueOnce({});
    const productIntegration: any = {
      newCustomerSubsidiaryId: 201,
    };
    jest.spyOn(ProductIntegration, 'getProductIntegration').mockReturnValueOnce(productIntegration);
    jest.spyOn(nsutils, 'queryFirstAsMap')
      .mockReturnValueOnce(null);

    // Act
    const action = () => customerService.createCustomer(params);

    // Assert
    expect(action).toThrowError(`Cannot find currency by code ${params.content.currency}`);
  });

  it('createCustomer should create an individual', () => {
    // Arrange
    const params: any = {
      productFamilyCode: 'DNN',
      productVariantCode: 'OP-Pro',
      content: {
        currency: 'USD',
        individual: true,
        individualName: {
          firstName: 'John',
          lastName: 'Smith',
        },
      },
    };
    const customer: any = {
      findSublistLineWithValue: jest.fn().mockReturnValue(-1),
      save: jest.fn().mockReturnValue('101'),
      setValue: jest.fn(),
    };
    jest.spyOn(record, 'create').mockReturnValueOnce(customer);
    jest.spyOn(EntityDao, 'getEntityStatusKey').mockReturnValueOnce({});
    const productIntegration: any = {
      newCustomerSubsidiaryId: 201,
    };
    jest.spyOn(ProductIntegration, 'getProductIntegration').mockReturnValueOnce(productIntegration);
    const currency: any = {
      id: 301,
    };
    const customerResult: any = {
      entityid: '1001',
    }
    jest.spyOn(nsutils, 'queryFirstAsMap')
      .mockReturnValueOnce(currency)
      .mockReturnValueOnce(customerResult);

    // Act
    const result = customerService.createCustomer(params);

    // Assert
    expect(result?.content).toBe(customerResult.entityid);
  });

  it('createCustomer should create a company', () => {
    // Arrange
    const params: any = {
      productFamilyCode: 'DNN',
      productVariantCode: 'OP-Pro',
      content: {
        currency: 'USD',
        companyName: 'My Company',
        primaryContact: {
          email: 'john.smith@trilogy.fake',
          name: {
            firstName: 'John',
            lastName: 'Smith',
          },
        },
        address: {
          country: 'US',
        },
        shippingAddress: {
          country: 'US',
        },
      },
    };
    const address: any = {
      save: jest.fn().mockReturnValue('501'),
      setValue: jest.fn(),
    };
    const customer: any = {
      findSublistLineWithValue: jest.fn().mockReturnValue(-1),
      getLineCount: jest.fn().mockReturnValue(0),
      getSublistSubrecord: jest.fn().mockReturnValueOnce(address),
      getValue: jest.fn(),
      insertLine: jest.fn(),
      setSublistValue: jest.fn(),
      save: jest.fn().mockReturnValue('101'),
      setValue: jest.fn(),
    };
    const contact: any = {
      setValue: jest.fn(),
      save: jest.fn().mockReturnValue('301'),
    };
    jest.spyOn(record, 'create')
      .mockReturnValueOnce(customer)
      .mockReturnValueOnce(contact);
    jest.spyOn(record, 'load').mockReturnValueOnce(customer);
    jest.spyOn(EntityDao, 'getEntityStatusKey').mockReturnValueOnce({});
    const productIntegration: any = {
      newCustomerSubsidiaryId: 201,
    };
    jest.spyOn(ProductIntegration, 'getProductIntegration').mockReturnValueOnce(productIntegration);
    const currency: any = {
      id: 301,
    };
    const customerResult: any = {
      entityid: '1001',
    }
    jest.spyOn(nsutils, 'queryFirstAsMap')
      .mockReturnValueOnce(currency)
      .mockReturnValueOnce(customerResult)
      .mockReturnValueOnce(null) // don't match any contact based on entity ID
      .mockReturnValueOnce(null); // don't match any contact based on the email

    // Act
    const result = customerService.createCustomer(params);

    // Assert
    expect(result?.content).toBe(customerResult.entityid);
  });

  it('updateCustomer should throw an error when the customer cannot be found', () => {
    // Arrange
    const params: any = {
      productFamilyCode: 'DNN',
      productVariantCode: 'OP-Pro',
      content: {
        id: '1001',
        currency: 'USD',
        companyName: 'My Company',
        primaryContact: {
          email: 'john.smith@trilogy.fake',
          name: {
            firstName: 'John',
            lastName: 'Smith',
          },
        },
      },
    };
    jest.spyOn(nsutils, 'queryFirstAsMap').mockReturnValueOnce(null);

    // Act
    const action = () => customerService.updateCustomer(params);

    // Assert
    expect(action).toThrowError('Customer not found');
  });

  it('updateCustomer should update a customer', () => {
    // Arrange
    const params: any = {
      productFamilyCode: 'DNN',
      productVariantCode: 'OP-Pro',
      content: {
        id: '1001',
        currency: 'USD',
        companyName: 'My Company',
        primaryContact: {
          email: 'john.smith@trilogy.fake',
          name: {
            firstName: 'John',
            lastName: 'Smith',
          },
        },
        address: {
          country: 'CA',
        },
        shippingAddress: {
          country: 'BE',
        },
      },
    };
    const address: any = {
      save: jest.fn().mockReturnValue('501'),
      setValue: jest.fn(),
    };
    const shippingAddress: any = {
      save: jest.fn().mockReturnValue('502'),
      setValue: jest.fn(),
    };
    const customer: any = {
      findSublistLineWithValue: jest.fn()
        .mockReturnValueOnce(0) // billing address is already created
        .mockReturnValue(-1),
      getLineCount: jest.fn().mockReturnValue(0),
      getSublistSubrecord: jest.fn()
        .mockReturnValueOnce(address)
        .mockReturnValueOnce(shippingAddress),
      getValue: jest.fn(),
      insertLine: jest.fn(),
      setSublistValue: jest.fn(),
      save: jest.fn().mockReturnValue('101'),
      setValue: jest.fn(),
    };
    const contact: any = {
      setValue: jest.fn(),
      save: jest.fn().mockReturnValue('301'),
    };
    jest.spyOn(record, 'load')
      .mockReturnValueOnce(customer)
      .mockReturnValueOnce(contact)
      .mockReturnValueOnce(customer);
    const customerResult: any = {
      id: '101',
      entityid: params.content.id,
    }
    const currency: any = {
      id: 301,
    };
    const contactResult: any = {
      id: '301',
    };
    jest.spyOn(nsutils, 'queryFirstAsMap')
      .mockReturnValueOnce(customerResult)
      .mockReturnValueOnce(currency)
      .mockReturnValueOnce(contactResult);

    // Act
    const result = customerService.updateCustomer(params);

    // Assert
    expect(result?.content).toBe(customerResult.entityid);
  });

  it('updateCustomer should partially update a end-user', () => {
    // Arrange
    const params: any = {
      productFamilyCode: 'DNN',
      productVariantCode: 'OP-Pro',
      customerId: '1002',
      isPartialContent: true,
      content: {
        id: '1001',
        shippingAddress: {
          country: 'BE',
        },
      },
    };
    jest.spyOn(SubscriptionDao, 'isEndUserInDraftSubscriptions').mockReturnValueOnce(true);
    const shippingAddress: any = {
      save: jest.fn().mockReturnValue('502'),
      setValue: jest.fn(),
    };
    const customer: any = {
      findSublistLineWithValue: jest.fn()
        .mockReturnValueOnce(-1) // billing address is not set
        .mockReturnValueOnce(0), // shipping address is already created
      getLineCount: jest.fn().mockReturnValue(0),
      getSublistSubrecord: jest.fn()
        .mockReturnValueOnce(shippingAddress),
      getValue: jest.fn(),
      insertLine: jest.fn(),
      setSublistValue: jest.fn(),
      save: jest.fn().mockReturnValue('101'),
      setValue: jest.fn(),
    };
    jest.spyOn(record, 'load')
      .mockReturnValueOnce(customer);

    // Act
    const result = customerService.updateCustomer(params);

    // Assert
    expect(result?.content).toBe(params.content.id);
  });

  it('updateCustomer should match contact based on email if there is no match based on entity ID', () => {
    // Arrange
    const params: any = {
      productFamilyCode: 'DNN',
      productVariantCode: 'OP-Pro',
      content: {
        id: '1001',
        currency: 'USD',
        companyName: 'My Company',
        primaryContact: {
          email: 'john.smith@trilogy.fake',
          name: {
            firstName: 'John',
            lastName: 'Smith',
          },
        },
      },
    };
    const customer: any = {
      findSublistLineWithValue: jest.fn().mockReturnValue(-1),
      save: jest.fn().mockReturnValue('101'),
      getValue: jest.fn(),
      setValue: jest.fn(),
    };
    const contact: any = {
      setValue: jest.fn(),
      save: jest.fn().mockReturnValue('301'),
    };
    jest.spyOn(record, 'load')
      .mockReturnValueOnce(customer)
      .mockReturnValueOnce(contact)
      .mockReturnValueOnce(customer);
    const customerResult: any = {
      id: '101',
      entityid: params.content.id,
    }
    const currency: any = {
      id: 301,
    };
    const contactResult: any = {
      id: '301',
    };
    jest.spyOn(nsutils, 'queryFirstAsMap')
      .mockReturnValueOnce(customerResult)
      .mockReturnValueOnce(currency)
      .mockReturnValueOnce(null) // don't match any contact based on entity ID
      .mockReturnValueOnce(contactResult);

    // Act
    const result = customerService.updateCustomer(params);

    // Assert
    expect(result?.content).toBe(customerResult.entityid);
  });

  describe('upsertSublistAddresses', () => {
    let mockCustomerRecord;

    function expectToHaveBeenCalledWith(actual: any, calls: any[]) {
      expect(actual).toHaveBeenCalledTimes(calls.length);
      calls.forEach((call, index) => {
        expect(actual).toHaveBeenNthCalledWith(index + 1, expect.objectContaining(call));
      });
    }

    beforeEach(() => {
      mockCustomerRecord = {
        findSublistLineWithValue: jest.fn().mockReturnValue(-1),
        getLineCount: jest.fn(),
        getSublistSubrecord: jest.fn().mockReturnValue({
          getValue: jest.fn().mockImplementation(() => 'fake'),
          setValue: jest.fn(),
        }),
        insertLine: jest.fn(),
        setSublistValue: jest.fn(),
        save: jest.fn(),
      };
      jest.spyOn(record, 'load').mockReturnValue(mockCustomerRecord);
      jest.spyOn(record, 'create').mockReturnValue(mockCustomerRecord);
    });

    it('should update existing addresses when the addresses exist', () => {
      // Arrange
      const billingAddress = { country: 'US' };
      const shippingAddress = { country: 'CA' };
      mockCustomerRecord.getLineCount.mockReturnValue(2);
      mockCustomerRecord.getSublistSubrecord
        .mockReturnValueOnce({ getValue: jest.fn().mockImplementation((attr) => billingAddress[attr]) }) // billing address - match
        .mockReturnValueOnce({ getValue: jest.fn().mockImplementation((attr) => billingAddress[attr]) }) // shipping address - no match
        .mockReturnValueOnce({ getValue: jest.fn().mockImplementation((attr) => shippingAddress[attr]) }); // shipping address - match

      // Act
      customerService['upsertSublistAddresses'](mockCustomerRecord, billingAddress, shippingAddress);

      // Assert
      expect(mockCustomerRecord.insertLine).not.toHaveBeenCalled();
      expectToHaveBeenCalledWith(mockCustomerRecord.setSublistValue, [
        { fieldId: 'defaultbilling', line: 0, value: true },
        { fieldId: 'defaultshipping', line: 1, value: true },
      ]);
    });

    it('should create new addresses when the addresses does not exist', () => {
      // Arrange
      const billingAddress = { country: 'US' };
      const shippingAddress = { country: 'CA' };
      mockCustomerRecord.getLineCount
        .mockReturnValueOnce(2) // billing address
        .mockReturnValueOnce(3); // shipping address

      // Act
      customerService['upsertSublistAddresses'](mockCustomerRecord, billingAddress, shippingAddress);

      // Assert
      expectToHaveBeenCalledWith(mockCustomerRecord.insertLine, [
        { line: 2 },
        { line: 3 },
      ]);
      expectToHaveBeenCalledWith(mockCustomerRecord.setSublistValue, [
        { fieldId: 'defaultbilling', line: 2, value: true },
        { fieldId: 'defaultshipping', line: 3, value: true },
      ]);
    });

    it('should remove the default flags when the addresses are null', () => {
      // Arrange
      const billingAddress = null;
      const shippingAddress = null;
      mockCustomerRecord.findSublistLineWithValue
        .mockReturnValueOnce(0) // billing address
        .mockReturnValueOnce(1); // shipping address

      // Act
      customerService['upsertSublistAddresses'](mockCustomerRecord, billingAddress, shippingAddress);

      // Assert
      expectToHaveBeenCalledWith(mockCustomerRecord.setSublistValue, [
        { fieldId: 'defaultbilling', line: 0, value: false },
        { fieldId: 'defaultshipping', line: 1, value: false },
      ]);
    });

    it('should not change addresses when the addresses are undefined', () => {
      // Arrange
      const billingAddress = undefined;
      const shippingAddress = undefined;

      // Act
      customerService['upsertSublistAddresses'](mockCustomerRecord, billingAddress, shippingAddress);

      // Assert
      expect(mockCustomerRecord.insertLine).not.toHaveBeenCalled();
      expect(mockCustomerRecord.setSublistValue).not.toHaveBeenCalled();
    });

    it('should unset the shipping address when the shipping address is the same as billing address', () => {
      // Arrange
      const billingAddress = { country: 'US' };
      const shippingAddress = billingAddress;
      mockCustomerRecord.getLineCount.mockReturnValueOnce(0); // billing address

      // Act
      customerService['upsertSublistAddresses'](mockCustomerRecord, billingAddress, shippingAddress);

      // Assert
      expectToHaveBeenCalledWith(mockCustomerRecord.insertLine, [
        { line: 0 },
      ]);
      expectToHaveBeenCalledWith(mockCustomerRecord.setSublistValue, [
        { fieldId: 'defaultbilling', line: 0, value: true },
        { fieldId: 'defaultshipping', line: 0, value: true },
      ]);
    });

    it('should set the shipping address as the billing address when the shipping address is undefined but exists and was the billing address', () => {
      // Arrange
      const billingAddress = { country: 'US' };
      const shippingAddress = undefined;
      mockCustomerRecord.findSublistLineWithValue.mockReturnValue(0); // billing and shipping addresses
      mockCustomerRecord.getLineCount.mockReturnValueOnce(1); // billing address

      // Act
      customerService['upsertSublistAddresses'](mockCustomerRecord, billingAddress, shippingAddress);

      // Assert
      expectToHaveBeenCalledWith(mockCustomerRecord.insertLine, [
        { line: 1 },
      ]);
      expectToHaveBeenCalledWith(mockCustomerRecord.setSublistValue, [
        { fieldId: 'defaultbilling', line: 1, value: true },
        { fieldId: 'defaultshipping', line: 1, value: true },
      ]);
    });
  });

  it('searchCustomer', () => {
    exposePrivate(customerService).getCustomerByEntityId.mockReturnValueOnce({ id: '123' })
    const res = customerService.searchCustomer({
      content: {
        firstName: 'Test',
        lastName: 'Test',
        email: "test@example.com",
        companyName: 'TestCompany'
      }
    });

    expect(res).toStrictEqual({ content: [{ id: '123' }] })
  })

  it('getCustomer', () => {
    (nsutils.queryFirstToJson as any).mockReturnValueOnce({ id: 'TestCustomer', firstName: 'FirstName' });
    (record.load as any).mockReturnValueOnce({
      getValue: () => 'test link'
    });

    const cust = customerService.getCustomer({ customerId: 'TestCustomer' });

    expect(cust).toStrictEqual({
      content: {
        id: 'TestCustomer',
        firstName: 'FirstName',
        individualName: undefined,
        stripeCustomerAccountLink: 'test link',
        primaryContact: {},
      },
    });
  })

  it('getCustomerStatus', () => {
    (nsutils.queryFirstToJson as any).mockReturnValueOnce({ name: 'Closed-Won' })
    const cust = customerService.getStatus({ customerId: 'TestCustomer' });

    expect(cust).toStrictEqual({
      content: 'Closed-Won'
    });
  })

  it('getCustomer with same billing/shipping address', () => {
    (nsutils.queryFirstToJson as any)
      .mockReturnValueOnce({
        id: 'TestCustomer',
        address: { id: 1 },
        shippingAddress: { id: 1 },
      })
      .mockReturnValueOnce({
        country: 'US',
      });
    (record.load as any).mockReturnValueOnce({
      getValue: () => 'test link'
    });

    const cust = customerService.getCustomer({ customerId: 'TestCustomer' });

    expect(cust).toStrictEqual({
      content: {
        id: 'TestCustomer',
        individualName: undefined,
        stripeCustomerAccountLink: 'test link',
        primaryContact: {},
        address: { country: 'US' },
      },
    });
  });

  it('getCustomer with different billing/shipping addresses', () => {
    (nsutils.queryFirstToJson as any)
      .mockReturnValueOnce({
        id: 'TestCustomer',
        address: { id: 1, country: 'US'},
        shippingAddress: { id: 2, country: 'CA' },
      })
      .mockReturnValueOnce({
        country: 'US',
      })
      .mockReturnValueOnce({
        country: 'CA',
      });
    (record.load as any).mockReturnValueOnce({
      getValue: () => 'test link'
    });

    const cust = customerService.getCustomer({ customerId: 'TestCustomer' });

    expect(cust).toStrictEqual({
      content: {
        id: 'TestCustomer',
        individualName: undefined,
        stripeCustomerAccountLink: 'test link',
        primaryContact: {},
        address: { country: 'US' },
        shippingAddress: { country: 'CA' },
      },
    });
  });

  it('addSubsidiary', () => {
    const mockCustomer = new RecordDynamicMock(
      {
        submachine: [{subsidiary: 1}]
      }, 
      {});
    jest.spyOn(customerService, 'getCustomerRecord').mockReturnValueOnce(mockCustomer as any)

    customerService.addSubsidiary('TestCDustomer', 2);

    expect(mockCustomer.sublists['submachine'][0]).toEqual(expect.objectContaining({subsidiary: 2}))
  })

  it('addSubsidiary already exist', () => {
    const mockCustomer = new RecordDynamicMock(
      {
        submachine: [{subsidiary: 1}]
      }, 
      {});
    jest.spyOn(customerService, 'getCustomerRecord').mockReturnValueOnce(mockCustomer as any)

    customerService.addSubsidiary('TestCDustomer', 1);

    expect(mockCustomer.sublists['submachine'].length).toEqual(1)
    expect(mockCustomer.sublists['submachine'][0]).toEqual(expect.objectContaining({subsidiary: 1}))
  })

  it('getLatestSignedQuote should return the contents of the latest signed quote file when is signed', () => {
    jest.spyOn(customerDao, 'getInternalId').mockReturnValueOnce(1)
    jest.spyOn(customerDao, 'getInternalId').mockReturnValueOnce(2)
    jest.spyOn(nsutils, 'queryToJson').mockReturnValueOnce([{
      agreementId: 1,
      linkType: 'contractualDocuments',
      agreementStatus: 'Signed'
    }]);
    jest.spyOn(record, 'load').mockReturnValueOnce({
      getValue: () => { return 'testValue' }
    } as any);
    const spyFile = jest.spyOn(file, 'load');
    const params = { customerId: '123', content: { endUserId: '456' }};
    const response = customerService.getLatestSignedQuote(params);
    
    expect(spyFile).toHaveBeenCalledWith({ id: 'testValue' });
    expect(response).toEqual({ content: 'testfilecontent' });
  });

  it('getLatestSignedQuote should return the contents of the latest signed quote file when have contract link', () => {
    jest.spyOn(customerDao, 'getInternalId').mockReturnValueOnce(1)
    jest.spyOn(record, 'load').mockReturnValueOnce({
      getValue: () => { return 1 }
    } as any);
    jest.spyOn(nsutils, 'queryToJson').mockReturnValueOnce([{
      agreementId: 1,
      linkType: 'contractualDocuments',
      contractualDocumentsLink: 'https://netsuite.com/files?id=11&h=456'
    }]);
    const spyFile = jest.spyOn(file, 'load');

    const params = { customerId: '123'};
    const response = customerService.getLatestSignedQuote(params);
    expect(spyFile).toHaveBeenCalledWith({ id: 11 });
    expect(response).toEqual({ content: 'testfilecontent' });
  });

  it('getLatestSignedQuote should return error if customer is reseller and no end user was informed', () => {
    jest.spyOn(customerDao, 'getInternalId').mockReturnValueOnce(1)
    jest.spyOn(record, 'load').mockReturnValueOnce({
      getValue: () => { return 2 }
    } as any);
    const params = { customerId: '123'};
    expect(() => {
      customerService.getLatestSignedQuote(params);
    }).toThrow('Customer is Reseller/Distributor and end user was not provided.');
  });

  it('getLatestSignedQuote should return error not found when no signed quote is found', () => {
    jest.spyOn(customerDao, 'getInternalId').mockReturnValue(1)
    jest.spyOn(nsutils, 'queryToJson').mockReturnValueOnce([]);

    const params = { customerId: '123', content: { endUserId: '456' }};
    expect(() => {
      customerService.getLatestSignedQuote(params);
    }).toThrow('No signed quote found');
  });

  describe('getStatement', () => {
    it('should return a PDF statement for a valid customer ID and start date', () => {
      // Arrange
      const customerId = '123';
      const startDate = '01-JAN-2021';
      const mockInternalId = 456;
      const mockStatementContent = 'PDF_CONTENT';

      const params = {
        customerId: customerId,
        content: { startDate: startDate }
      };

      const expectedStatementParams: render.StatementOptions = {
        entityId: mockInternalId,
        printMode: render.PrintMode.PDF,
        startDate: startDate
      };

      const getSpy = jest.spyOn(customerDao, 'getInternalId').mockReturnValue(mockInternalId);

      // Act
      const response: HandlerResponse = customerService.getStatement(params);

      // Assert
      expect(getSpy).toHaveBeenCalledWith(customerId);
      expect(render.statement).toHaveBeenCalledWith(expectedStatementParams);
      expect(response).toEqual({ content: 'TestFileContent' });
    });

    it('should throw an error if the customer ID is not found', () => {
      // Arrange
      const customerId = 'invalid_id';
      const params = {
        customerId: customerId
      };

      jest.spyOn(customerDao, 'getInternalId').mockReturnValue(undefined);

      // Act & Assert
      expect(() => {
        customerService.getStatement(params);
      }).toThrow('Customer not found');
    });

    it('should return a PDF statement for a valid customer ID without a start date', () => {
      // Arrange
      const customerId = '789';
      const mockInternalId = 1011;
      const mockStatementContent = 'PDF_CONTENT_NO_START_DATE';

      const params = {
        customerId: customerId
      };

      const expectedStatementParams: render.StatementOptions = {
        entityId: mockInternalId,
        printMode: render.PrintMode.PDF
      };

      const spyGet = jest.spyOn(customerDao,'getInternalId').mockReturnValue(mockInternalId);
      
      // Act
      const response: HandlerResponse = customerService.getStatement(params);

      // Assert
      expect(spyGet).toHaveBeenCalledWith(customerId);
      expect(render.statement).toHaveBeenCalledWith(expectedStatementParams);
      expect(response).toEqual({ content: 'TestFileContent' });
    });
  });
})