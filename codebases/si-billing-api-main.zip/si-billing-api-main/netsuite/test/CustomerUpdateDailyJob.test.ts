import * as record from 'N/record';
import * as query from 'N/query';
import * as nsutils from '../src/ts/nsutils';
import { execute } from '../src/ts/events/CustomerUpdateDailyJob';

describe('updatePlatinumSubscriptions', () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  it('calls job execution', () => {
    (query.runSuiteQL as any).mockReturnValueOnce({ asMappedResults: () => [{ id: '1' }, { id: '2' }]});
    (query.runSuiteQL as any).mockReturnValueOnce({ asMappedResults: () => [{ id: '3' }, { id: '4' }]});
    (query.runSuiteQL as any).mockReturnValueOnce({ asMappedResults: () => [{ id: '5' }, { id: '6' }]});
    (query.runSuiteQL as any).mockReturnValueOnce({ asMappedResults: () => [{ id: '7' }, { id: '8' }]});
    (query.runSuiteQL as any).mockReturnValueOnce({ asMappedResults: () => [{ id: '9', arr: 12 }, { id: '10', arr: 12 }, { id: '11', arr: null }]});

    jest.spyOn(nsutils, 'logDebug').mockImplementation(() => {});

    const submitFieldsMock = jest.fn();
    (record.submitFields as any).mockImplementation((params) => {
      if (['2','4','6','8'].includes(params.id)) {
        throw new Error('Error updating customer');
      }
      submitFieldsMock(params);
    });

    execute(undefined);
    expect(record.submitFields).toHaveBeenCalledTimes(11);
    expect(submitFieldsMock).toHaveBeenCalledTimes(7);

    expect(record.submitFields).toHaveBeenCalledWith({
      type: 'customer',
      id: '1',
      values: {
        custentity_has_active_subscription: true,
      },
    });
    expect(record.submitFields).toHaveBeenCalledWith({
      type: 'customer',
      id: '2',
      values: {
        custentity_has_active_subscription: true,
      },
    });

    expect(record.submitFields).toHaveBeenCalledWith({
      type: 'customer',
      id: '3',
      values: {
        custentity_has_active_subscription: false,
      },
    });
    expect(record.submitFields).toHaveBeenCalledWith({
      type: 'customer',
      id: '4',
      values: {
        custentity_has_active_subscription: false,
      },
    });

    expect(record.submitFields).toHaveBeenCalledWith({
      type: 'customer',
      id: '5',
      values: {
        custentity_platinum_customer: true,
      },
    });
    expect(record.submitFields).toHaveBeenCalledWith({
      type: 'customer',
      id: '6',
      values: {
        custentity_platinum_customer: true,
      },
    });

    expect(record.submitFields).toHaveBeenCalledWith({
      type: 'customer',
      id: '7',
      values: {
        custentity_platinum_customer: false,
      },
    });
    expect(record.submitFields).toHaveBeenCalledWith({
      type: 'customer',
      id: '8',
      values: {
        custentity_platinum_customer: false,
      },
    });
    expect(record.submitFields).toHaveBeenCalledWith({
      type: 'customer',
      id: '9',
      values: {
        custentity_arr: 12,
      },
    });
    expect(record.submitFields).toHaveBeenCalledWith({
      type: 'customer',
      id: '10',
      values: {
        custentity_arr: 12,
      },
    });
    expect(record.submitFields).toHaveBeenCalledWith({
      type: 'customer',
      id: '11',
      values: {
        custentity_arr: null,
      },
    });
    expect(nsutils.logDebug).toHaveBeenCalledWith('Has Active Subscription Updated to true', 'Customer IDs: 1');
    expect(nsutils.logDebug).toHaveBeenCalledWith('Has Active Subscription Updated to false', 'Customer IDs: 3');
    expect(nsutils.logDebug).toHaveBeenCalledWith('Platinum Customer Updated to true', 'Customer IDs: 5');
    expect(nsutils.logDebug).toHaveBeenCalledWith('Platinum Customer Updated to false', 'Customer IDs: 7');
    expect(nsutils.logDebug).toHaveBeenCalledWith(
      'Error Updating Customer Has Active Subscription field to true',
      'Customer ID: 2, Error: Error: Error updating customer'
    );
    expect(nsutils.logDebug).toHaveBeenCalledWith(
      'Error Updating Customer Has Active Subscription field to false',
      'Customer ID: 4, Error: Error: Error updating customer'
    );
    expect(nsutils.logDebug).toHaveBeenCalledWith(
      'Error Updating Customer Platinum Customer field to true',
      'Customer ID: 6, Error: Error: Error updating customer'
    );
    expect(nsutils.logDebug).toHaveBeenCalledWith(
      'Error Updating Customer Platinum Customer field to false',
      'Customer ID: 8, Error: Error: Error updating customer'
    );
    expect(nsutils.logDebug).toHaveBeenCalledWith('ARR Updated to 12', 'Customer IDs: 9,10');
    expect(nsutils.logDebug).toHaveBeenCalledWith('ARR Updated to null', 'Customer IDs: 11');
  });
});