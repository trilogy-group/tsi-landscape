import { clone, tryParseNsDate } from '../src/ts/utility/GeneralUtility';

describe('GeneralUtility', () => {
  beforeEach(() => {
    jest.restoreAllMocks();
  });

  it('clone', () => {
    const obj1 = {
      key1: 'val1',
      key2: 'val2',
      key3: 'internalVal3',
    };

    const obj2 = null;
    expect(clone(obj1)).toStrictEqual({ key1: 'val1', key2: 'val2', key3: 'internalVal3' });
    expect(clone(obj2)).toBeNull();
  });

  it('max', () => {
    const arr = [1, 5, 3, 1, 2, 4, 5];
    const emptyArr = [];

    expect(arr.max((x) => x)).toBe(5);

    expect(() => {
      emptyArr.max((x) => x);
    }).toThrowError('source contains no elements');
  });

  it('sum', () => {
    const arr = [
      { key: 1, value: 1 },
      { key: 2, value: 2 },
      { key: 1, value: 3 },
      { key: 2, value: 4 },
      { key: 3, value: 5 },
      { key: 1, value: 6 },
    ];

    expect(arr.sum((x) => x.value)).toBe(21);

    arr.splice(0, 6);

    expect(arr.sum((x) => x.value)).toBe(0);

    const arrWithUndefinedItems = [
      { key: 1, value: 1 },
      { key: 2, value: undefined },
      { key: 1 },
      { key: 2, value: 4 },
      { key: 3, value: null },
      { key: 1, value: 6 },
    ];

    expect(arrWithUndefinedItems.sum((x) => x.value)).toBe(11);
  });

  const arrWithUndefinedItems = [
    { key: 1, value: 1 },
    { key: 2, value: undefined },
    { key: 1 },
    { key: 2, value: 4 },
    { key: 3, value: null },
    { key: 1, value: 6 },
  ];

  expect(arrWithUndefinedItems.sum((x) => x.value)).toBe(11);

  it('groupBy', () => {
    const arr = [
      { key: 1, value: '1' },
      { key: 2, value: '2' },
      { key: 1, value: '1.1' },
      { key: 2, value: '2.1' },
      { key: 3, value: '3' },
      { key: 1, value: '1.2' },
      { key: '1', value: "'1'.2" },
    ];
    const groups = arr.groupBy((x) => x.key);
    expect(groups).toStrictEqual([
      {
        key: 1,
        count: 3,
        groupItems: [
          { key: 1, value: '1' },
          { key: 1, value: '1.1' },
          { key: 1, value: '1.2' },
        ],
      },
      {
        key: 2,
        count: 2,
        groupItems: [
          { key: 2, value: '2' },
          { key: 2, value: '2.1' },
        ],
      },
      { key: 3, count: 1, groupItems: [{ key: 3, value: '3' }] },
      {
        key: '1',
        count: 1,
        groupItems: [{ key: '1', value: "'1'.2" }],
      },
    ]);

    const emptyArr = [];
    expect(() => {
      emptyArr.max((x) => x);
    }).toThrowError('source contains no elements');
  });

  it('remove', () => {
    const arr = [
      { key: 1, value: '1' },
      { key: 1, value: '1.1' },
      { key: 1, value: '1.2' },
      { key: 2, value: '2' },
      { key: 2, value: '2.1' },
      { key: 3, value: '3' },
      { key: 1, value: '1.3' },
      { key: '1', value: "'1'.2" },
    ];

    const removed = arr.remove((x) => x.key === 1);
    expect(removed).toStrictEqual([
      { key: 2, value: '2' },
      { key: 2, value: '2.1' },
      { key: 3, value: '3' },
      { key: '1', value: "'1'.2" },
    ]);

    const emptyArr = [{ key: 2, value: '2' }];
    emptyArr.splice(0, 1);
    const removedEmpty = emptyArr.remove((x) => x.key === 1);
    expect(removedEmpty).toStrictEqual([]);
  });

  it('firstOrUndefined', () => {
    const arr = [
      { key: 1, value: '1' },
      { key: 1, value: '1.1' },
      { key: 1, value: '1.2' },
      { key: 2, value: '2' },
      { key: 2, value: '2.1' },
      { key: 3, value: '3' },
      { key: 1, value: '1.3' },
      { key: '1', value: "'1'.2" },
    ];

    let actual = arr.firstOrUndefined((x) => x.key === 3);
    expect(actual).toStrictEqual({ key: 3, value: '3' });
    actual = arr.firstOrUndefined((x) => x.key === 4);
    expect(actual).toBeUndefined();
    actual = arr.firstOrUndefined();
    expect(actual).toStrictEqual({ key: 1, value: '1' });

    const emptyArr = [{ key: 2, value: '2' }];
    emptyArr.splice(0, 1);
    let removedEmpty = emptyArr.firstOrUndefined((x) => x.key === 1);
    expect(removedEmpty).toBeUndefined();
    removedEmpty = emptyArr.firstOrUndefined();
    expect(removedEmpty).toBeUndefined();
  });

  it('toPascalCase', () => {
    expect('removed'.toPascalCase()).toStrictEqual('Removed');
    expect('REMOVED'.toPascalCase()).toStrictEqual('Removed');
    expect('Removed'.toPascalCase()).toStrictEqual('Removed');
    expect(''.toPascalCase()).toStrictEqual('');
  });

  it('parse NetSuite date', () => {
    const dateStr1 = '10-Jan-2024';
    expect(tryParseNsDate(dateStr1)).toStrictEqual(new Date(2024, 0, 10));
    const dateStr2 = '11-Jun-2023';
    expect(tryParseNsDate(dateStr2)).toStrictEqual(new Date(2023, 5, 11));
  });

  it('addDays', () => {
    const date1 = tryParseNsDate('11-Jun-2023')!;
    const date2 = tryParseNsDate('30-Jun-2023')!;

    date1.addDays(1);
    date2.addDays(1);
    expect(date1).toStrictEqual(tryParseNsDate('12-Jun-2023'));
    expect(date2).toStrictEqual(tryParseNsDate('01-Jul-2023'));
  });
});
