import invoiceService from '../src/ts/InvoicesService';
import invoiceDao from '../src/ts/dao/InvoiceDao';
import { FindInvoicesParams } from '../src/ts/InvoicesService';
import * as nsutils from '../src/ts/nsutils';
import * as query from 'N/query';
import * as record from 'N/record';
import { SubscriptionRecord } from '../src/ts/models/SubscriptionRecord';
import { SubscriptionRecordMock } from './mocks/SubscriptionRecordMock';
import CustomerDao from '../src/ts/dao/CustomerDao';
import { RecordDynamicMock } from './SublistMock';
import { OrderType } from '../src/ts/types';

describe('InvoiceService', () => {
  beforeEach(() => {
    jest.restoreAllMocks();
    jest.spyOn(nsutils, 'queryToJson');
    jest.spyOn(nsutils, 'queryFirstToJson');
    jest.spyOn(nsutils, 'queryFirstAsMap');
    jest.spyOn(invoiceDao, 'findInvoiceInternalId');
  });
  it('findInvoices', () => {
    const params = {
      customerId: 'TestCustomer',
      startDate: '1/1/2021',
      endDate: '1/1/2022',
      subscriptionId: '42',
    } as FindInvoicesParams;
    invoiceService.findInvoices(params);

    expect((query.runSuiteQL as any).mock.calls.length).toBe(1);
    expect((query.runSuiteQL as any).mock.calls[0][0].query).toContain(` as stripeInvoicePaymentLink,
    i.tranid,
    i.trandate as date,
    i.duedate,
    i.status as statuscode,
    tr_stat_dict.name as statustitle,
    cur.symbol as currency,
    i.foreigntotal,
    i.taxtotal,`);
  });

  it('downloadInvoice', () => {
    (nsutils.queryFirstAsMap as any).mockReturnValueOnce({ id: 1 });
    const params = { customerId: 'TestCustomer', content: { invoiceNumber: '123' } };
    const res = invoiceService.downloadInvoice(params);

    expect(res).toStrictEqual({ content: 'TestFileContent' });
  });

  it('downloadInvoice no such number', () => {
    const params = { customerId: 'TestCustomer', content: { invoiceNumber: '123' } };

    expect(() => {
      invoiceService.downloadInvoice(params);
    }).toThrow(expect.objectContaining({ status: 404 }));
  });

  it('generatePaymentLink', () => {
    (nsutils.queryToJson as any).mockReturnValueOnce([{ stripeInvoicePaymentLink: 'payment' }]);
    const params = { customerId: 'TestCustomer', content: { invoiceNumber: '123' } };
    const res = invoiceService.generatePaymentLink(params);
    expect(res).toEqual(expect.objectContaining({ content: { type: 'stripeUrl', url: 'payment' } }));
  });

  it('generatePaymentLink', () => {
    (nsutils.queryToJson as any).mockReturnValueOnce([]);
    const params = { customerId: 'TestCustomer', content: { invoiceNumber: '123' } };

    expect(() => {
      invoiceService.generatePaymentLink(params);
    }).toThrow(expect.objectContaining({ status: 404 }));
  });

  it('createInvoiceFromSubscription', () => {
    jest.spyOn(SubscriptionRecord, 'load').mockReturnValueOnce(new SubscriptionRecordMock({}, []) as any);
    jest.spyOn(Object.getPrototypeOf(invoiceService), 'doFindInvoices').mockReturnValueOnce([]);
    jest.spyOn(CustomerDao, 'getInternalId').mockReturnValueOnce(1);
    const invoiceMock = new RecordDynamicMock([], {});
    jest.spyOn(record, 'create').mockReturnValueOnce(invoiceMock as any);
    invoiceService.createInvoiceFromSubscription({ customerId: 'TEST', content: { subscriptionId: 1 } });

    expect(invoiceMock.fields).toEqual(
      expect.objectContaining({
        taxdetailsoverride: true,
        custbody_end_user: 1,
        custbody_order_type: OrderType.New,
      })
    );
  });
});
