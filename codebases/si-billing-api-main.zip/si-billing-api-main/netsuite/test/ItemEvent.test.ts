import { beforeSubmit } from '../src/ts/events/ItemEvent';
import * as nsutils from '../src/ts/nsutils';

describe('ItemEvent', () => {
  beforeEach(() => {
    jest.restoreAllMocks();
  });

  it('does not throw an error when the type is not "item"', () => {
    const context: any = {
      newRecord: { getValue: jest.fn().mockReturnValue('otherType') }
    };

    // Expect that no error is thrown
    expect(() => beforeSubmit(context)).not.toThrow();
  });

  it('does not throw an error when "custitem_renew_with" is not provided', () => {
    const context: any = {
      newRecord: { 
        getValue: (key) => {
          switch (key) {
            case 'type': return 'item';
            case 'custitem_renew_with': return undefined;
          }
        }
      }
    }

    // Expect that no error is thrown
    expect(() => beforeSubmit(context)).not.toThrow();
  });

  it('throws an error when "custitem_renew_with" refers to a Subscription Plan', () => {
    const context: any = {
      newRecord: { getValue: jest.fn().mockReturnValue('item') }
    };
    jest.spyOn(nsutils, 'queryFirstToJson').mockReturnValueOnce({ itemtype: 'SubscriPlan' }); 
    expect(() => beforeSubmit(context)).toThrowError('Not possible to save a Subscription Plan in the RENEW WITH field. Choose another item.');
  });
});