import { clone } from '../src/ts/utility/GeneralUtility';
import * as productCatalog from '../src/ts/ProductCatalog';
import * as nsutils from '../src/ts/nsutils';
import SubscriptionPlanDao from '../src/ts/dao/SubscriptionPlanDao';

describe('ProductCatalog', () => {
  function spyPrivate(obj: any, methodName: string, impl?: any) {
    const f = jest.spyOn(Object.getPrototypeOf(obj), methodName);
    if (impl) {
      return f.mockImplementation(impl);
    }
    return f;
  }

  // expose private methods
  function exposePrivate(obj): any {
    //tbd bind
    return Object.getPrototypeOf(obj);
  }

  beforeEach(() => {
    jest.restoreAllMocks();
    jest.spyOn(nsutils, 'queryToJson');
    jest.spyOn(nsutils, 'queryFirstToJson');
    jest.spyOn(nsutils, 'queryFirstAsMap');
  });

  it('getLatestSubscriptionPlanCode should throw an error if a mandatory param is missing', () => {
    // Arrange
    const params = {
      productFamilyCode: "DNN",
      productVariantCode: "OP-Cus",
      productTier: "Enterprise",
      supportLevel: "Platinum",
      isSupport: false,
    };
    const tests = [
      { deleteField: (params: any) => delete params.productFamilyCode, fieldName: 'productFamilyCode' },
      { deleteField: (params: any) => delete params.productVariantCode, fieldName: 'productVariantCode' },
      { deleteField: (params: any) => delete params.productTier, fieldName: 'productTier' },
      { deleteField: (params: any) => delete params.supportLevel, fieldName: 'supportLevel' },
      { deleteField: (params: any) => delete params.isSupport, fieldName: 'isSupport' },
    ];
    for (const test of tests) {
      const failedParams = clone(params);
      test.deleteField(failedParams);

      // Act
      const action = () => productCatalog.getLatestSubscriptionPlanCode(failedParams);

      // Assert
      expect(action).toThrowError(`${test.fieldName} is mandatory`);
    }
  });

  it('getLatestSubscriptionPlanCode should throw an error if an input param is invalid', () => {
    // Arrange
    const params = {
      productFamilyCode: "DNN",
      productVariantCode: "OP-Cus",
      productTier: "Enterprise",
      supportLevel: "Platinum",
      isSupport: false,
    };
    const tests = [
      { updateField: (params: any, value: string) => params.productTier = value, label: 'product tier' },
      { updateField: (params: any, value: string) => params.supportLevel = value, label: 'support level' },
    ];
    for (const test of tests) {
      const failedParams = clone(params);
      const unexpectedValue = 'unexpected';
      test.updateField(failedParams, unexpectedValue);

      // Act
      const action = () => productCatalog.getLatestSubscriptionPlanCode(failedParams);

      // Assert
      expect(action).toThrowError(`Invalid ${test.label}: ${unexpectedValue}`);
    }
  });

  it('getLatestSubscriptionPlanCode should throw an error if no subscription plan is found', () => {
    // Arrange
    const params = {
      productFamilyCode: "DNN",
      productVariantCode: "OP-Cus",
      productTier: "Enterprise",
      supportLevel: "Platinum",
      isSupport: false,
    };
    jest.spyOn(SubscriptionPlanDao, 'getLatestSubscriptionPlan').mockReturnValueOnce(undefined);

    // Act
    const action = () => productCatalog.getLatestSubscriptionPlanCode(params);

    // Assert
    expect(action).toThrowError(`Subscription plan not found for the given parameters`);
  });

  it('getLatestSubscriptionPlanCode should return the latest subscription plan code', () => {
    // Arrange
    const params = {
      productFamilyCode: "DNN",
      productVariantCode: "OP-Cus",
      productTier: "Enterprise",
      supportLevel: "Platinum",
      isSupport: false,
    };
    const plan = {
      id: 1,
      displayname: 'DNN-OP-Cus-ENT-PLA-002',
      itemid: 'DNN CustomerCloud EVOQ, ENTERPRISE EDITION, PLATINUM SUCCESS-002',
    };
    jest.spyOn(SubscriptionPlanDao, 'getLatestSubscriptionPlan').mockReturnValueOnce(plan);

    // Act
    const result = productCatalog.getLatestSubscriptionPlanCode(params) as any;

    // Assert
    expect(result?.content).toBeDefined();
    expect(result.content).toBe(plan.itemid);
  });

  it('listProducts simple', () => {
    (nsutils.queryToJson as any).mockReturnValueOnce([{ family: { code: 'TES' } }]);
    const res = productCatalog.listProducts({ productFamilyCode: 'TES', productVariantCode: 'SA' });

    expect(res).toStrictEqual({
      content: [{ family: { code: 'TES' } }],
    });
  });

  it('listProducts-', () => {
    (nsutils.queryToJson as any).mockReturnValueOnce([
      { name: 'Test Standard Silver', product: {}, code: 'TES-SA-Cus-STA-SIL-MNT' },
    ]);
    const res = productCatalog.listSubscriptionPlans({ productFamilyCode: 'TES', productVariantCode: 'SA' });
    
    expect(res).toStrictEqual({
      content: [
        {
          _ns_displayname: 'TES-SA-Cus-STA-SIL-MNT',
          code: 'Test Standard Silver',
          supportLevel: 'Silver',
          productTier: 'Standard',
          productTierTitle: 'Standard',
          revenueType: 'Support',
          product: {},
          supportOnly: true,
          items: [
            {
              id: undefined,
              code: undefined,
              title: undefined,
              required: true,
              supportLevel: null,
              type: undefined,
              typeId: undefined,
              desc: undefined,
              minQuantity: undefined,
              maxQuantity: undefined,
              productTier: 'Standard',
              prices: [
                {
                  type: undefined,
                  frequency: undefined,
                  currency: undefined,
                  pricebookid: undefined,
                  ranges: [{ priceplanid: undefined, type: undefined, fromQuantity: undefined, price: undefined }],
                },
              ],
            },
          ],
        },
      ],
    });
  });

  it('listSubscriptionPlans-', () => {
    (nsutils.queryToJson as any).mockReturnValueOnce([{ name: 'Test Subscription Plan', code: 'XXX-SA-CUS-STA-SIL' }]);
    (nsutils.queryToJson as any).mockReturnValueOnce([
      { id: 1, code: 'XXX-SA-CUS-SIL', isrequired: 'T', support_level_name: 'Silver' },
      {
        id: 2,
        code: 'XXX-SA-CUS-STA',
        isrequired: 'T',
        product_tier_name: 'Standard',
        currency: 'USD',
        frequency: 'MONTHLY',
      },
    ]);
    const res = productCatalog.listSubscriptionPlans({
      customerId: '42',
      maxResults: 100,
      productFamilyCode: 'TestPFC',
      productVariantCode: 'TestPVC',
      subscriptionPlanId: 1,
      subscriptionPlanCode: 'test',
    });

    expect((res as any).content).toEqual(
      expect.arrayContaining([
        expect.objectContaining({
          code: 'Test Subscription Plan',
          items: [
            {
              code: 'XXX-SA-CUS-STA',
              desc: undefined,
              id: 2,
              maxQuantity: undefined,
              minQuantity: undefined,
              required: true,
              supportLevel: null,
              title: undefined,
              type: undefined,
              productTier: 'Standard',
              revenueType: undefined,
              prices: [
                {
                  currency: 'USD',
                  frequency: 'MONTHLY',
                  type: undefined,
                  ranges: [
                    {
                      type: undefined,
                      fromQuantity: undefined,
                      price: undefined,
                    },
                  ],
                },
              ],
            },
          ],
          productTier: 'Standard',
          supportOnly: false,
          productTierTitle: 'Standard',
          revenueType: 'SaaS',
          supportLevel: 'Silver',
        }),
      ])
    );
  });

  it('listSubscriptionPlans support only', () => {
    (nsutils.queryToJson as any).mockReturnValueOnce([
      { name: 'Test Subscription Plan', code: 'XXX-SA-CUS-PRO-SIL-MNT' },
    ]);
    (nsutils.queryToJson as any).mockReturnValueOnce([
      { id: 1, code: 'XXX-SA-CUS-SIL', isrequired: 'T', support_level_name: 'Silver'},
    ]);
    (nsutils.queryToJson as any).mockReturnValueOnce([
      { name: 'Test Subscription Plan', code: 'XXX-SA-CUS-PRO-SIL-MNT' },
    ]);
    const res = productCatalog.listSubscriptionPlans({
      customerId: '42',
      maxResults: 100,
      productFamilyCode: 'TestPFC',
      productVariantCode: 'TestPVC',
      subscriptionPlanId: 1,
      subscriptionPlanCode: 'test',
    });

    expect((res as any).content).toEqual(
      expect.arrayContaining([
        expect.objectContaining({
          code: 'Test Subscription Plan',
          items: [
            {
              code: 'XXX-SA-CUS-SIL',
              desc: undefined,
              id: 1,
              maxQuantity: undefined,
              minQuantity: undefined,
              required: true,
              supportLevel: 'Silver',
              title: undefined,
              type: undefined,
              productTier: null,
              prices: [
                {
                  currency: undefined,
                  frequency: undefined,
                  type: undefined,
                  ranges: [
                    {
                      type: undefined,
                      fromQuantity: undefined,
                      price: undefined,
                    },
                  ],
                },
              ],
            },
          ],
          productTier: 'Professional',
          productTierTitle: 'Professional',
          supportOnly: true,
          revenueType: 'Support',
          supportLevel: 'Silver',
        }),
      ])
    );
  });
});
