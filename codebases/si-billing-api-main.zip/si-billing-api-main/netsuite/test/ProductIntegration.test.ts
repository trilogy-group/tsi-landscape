import * as nsutils from '../src/ts/nsutils';
import * as productIntegration from '../src/ts/ProductIntegrationGetter';
describe('ProductCatalog', () => {
  beforeEach(() => {
    jest.restoreAllMocks();
    jest.spyOn(nsutils, 'queryToJson');
  });

  it('getProductIntegration', () => {
    (nsutils.queryToJson as any).mockReturnValueOnce([{ family: { code: 'TES' } }]);
    productIntegration.getProductIntegration({ productFamilyCode: 'pfc', productVariantCode: 'pvc' });

    expect(nsutils.queryToJson as any).toBeCalledWith(
      expect.stringContaining('custrecordproductvariantcode='),
      expect.anything(),
      expect.anything()
    );

    productIntegration.getProductIntegration({ productFamilyCode: 'pfc' });
    expect(nsutils.queryToJson as any).toBeCalledWith(
      expect.stringContaining('custrecordproductvariantcode is null'),
      expect.anything(),
      expect.anything()
    );
  });
});
