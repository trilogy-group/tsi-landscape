import * as ProductNotificationEvent from '../src/ts/events/ProductNotificationEvent';
import * as https from 'N/https';
import * as record from 'N/record';
import * as nsutils from '../src/ts/nsutils';
import sgu from '../src/ts/utility/SubscriptionGetUtility';
import { ProductIntegration } from '../src/ts/ProductIntegration';
import { RecordDynamicMock } from './SublistMock';

describe('ProductNotificationEvent', () => {
  beforeEach(() => {
    jest.restoreAllMocks();
    jest.spyOn(nsutils, 'queryToJson');
    jest.spyOn(nsutils, 'queryFirstToJson');
    jest.spyOn(nsutils, 'queryFirstAsMap');
    jest.spyOn(sgu, 'buildSubscription');
    jest.spyOn(ProductIntegration, 'findBySubscriptionPlanName');
  });

  it('afterSubmit', () => {
    const testProductIntegration = new ProductIntegration();
    testProductIntegration.notification = { auth: { username: 'test', password: 'test' }, url: 'example.com' };
    testProductIntegration.family = { code: 'TST', title: 'Test' };
    (ProductIntegration.findBySubscriptionPlanName as any).mockImplementation(() => testProductIntegration);
    (record.load as any).mockImplementation(() => new RecordDynamicMock({}, []) as any);
    (sgu.buildSubscription as any).mockImplementation(() => ({ id: 555 }));

    ProductNotificationEvent.afterSubmit({
      newRecord: {
        type: record.Type.SUBSCRIPTION_CHANGE_ORDER,
        fields: {
          subscription: 1,
          action: 'ACTIVATE',
        },
      },
      type: null,
      oldRecord: null,
      UserEventType: null,
    } as any); //EntryPoints.UserEvent.beforeSubmitContext

    expect((https.post as any).mock.calls.length).toBe(1); // Ensure that an HTTP call is made
  });
});
