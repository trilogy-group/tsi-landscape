import * as QuoteEvent from '../src/ts/events/QuoteEvent';
import * as record from 'N/record';
import { ProductIntegration } from '../src/ts/ProductIntegration';
import { SubscriptionRecord } from '../src/ts/models/SubscriptionRecord';
import SubscriptionPlanUtility from '../src/ts/utility/SubscriptionPlanUtility';
import { SupportLevel, TermUnit } from '../src/ts/types';
import * as nsutils from '../src/ts/nsutils';

describe('QuoteEvent', () => {
  const context = {
    type: 'create',
    newRecord: {
      getValue: jest.fn().mockImplementation(field => {
        switch(field) {
          case 'type': 
            return 'estimate';
          case 'custbody_related_subscription': 
            return 25;
          default:
            return 1;
        }
      }),
      setValue: jest.fn(),
      getSublistValue: jest.fn().mockReturnValue(25),
    },
    UserEventType: {
      CREATE: 'create'
    }
  } as any;
  
  const contextSetListPrices = {
    type: 'create',
    newRecord: {
      getValue: jest.fn().mockImplementation(field => { 
        switch(field) {
          case 'type': 
            return 'estimate';
          case 'nluser': 
            return '672750';
          case 'custbody_related_subscription': 
            return 25;
          case 'currencysymbol':
            return 'USD';
          case 'startdate':
            return '01-Jan-2023';
            case 'enddate':
              return '31-Dec-2023';
          default:
            return 1;
        }
      }),
      setValue: jest.fn(),
      getSublistValue: jest.fn().mockReturnValue(25),
      setSublistValue: jest.fn().mockImplementation(),
    },
    UserEventType: {
      CREATE: 'create'
    }
  } as any;

  beforeEach(() => {
    jest.clearAllMocks();
    jest.spyOn(SubscriptionRecord, 'load').mockReturnValue({
      subscriptionPlanId: 1,
      currencySymbol: 'USD',
      initialTermDuration: 1,
      initialTermUnits: TermUnit.YEARS
    } as any);
    jest.spyOn(SubscriptionPlanUtility, 'getSubscriptionPlanById').mockReturnValue({
      id: 1,
      supportLevel: SupportLevel.Gold
    } as any);
    jest.spyOn(ProductIntegration, 'getBySubscriptionPlanIdOrDefault').mockReturnValue({
      id: 1
    } as any);
  });
  
  it('should not set quote_clauses if type is not CREATE', () => {
    context.type = 'edit';

    QuoteEvent.beforeSubmit(context);
    expect(context.newRecord.setValue).not.toHaveBeenCalled();
    context.type = 'create';
  });

  it('should not set quote_clauses if record type is not estimate', () => {
    QuoteEvent.beforeSubmit({
      type: 'create',
      newRecord: {
        getValue: jest.fn().mockReturnValue('subscription')
      },
      UserEventType: {
        CREATE: 'create'
      }
    } as any);
    expect(context.newRecord.setValue).not.toHaveBeenCalled();
  });

  it('should not set quote_clauses if support level is platinum', () => {
    jest.spyOn(SubscriptionPlanUtility, 'getSubscriptionPlanById').mockReturnValue({
      supportLevel: SupportLevel.Platinum
    } as any);

    QuoteEvent.beforeSubmit(context);
    expect(context.newRecord.setValue).not.toHaveBeenCalled();
  });

  it('should not set quote_clauses if product integration record is not found', () => {
    jest.spyOn(ProductIntegration, 'getBySubscriptionPlanIdOrDefault').mockReturnValue(undefined);

    QuoteEvent.beforeSubmit(context);
    expect(context.newRecord.setValue).not.toHaveBeenCalled();
  });

  it('should set quote_clauses subscriptionplanid', () => {
    (record.load as any).mockReturnValue({
      getValue: jest.fn().mockReturnValue([1,2]),
    });

    QuoteEvent.beforeSubmit(context);
    expect(context.newRecord.setValue).toHaveBeenCalled();
  });

  it('should set quote_clauses from items', () => {
    const context2 = {
      type: 'create',
      newRecord: {
        getValue: jest.fn().mockImplementation(field => {
          switch(field) {
            case 'type': 
              return 'estimate';
            case 'custbody_related_subscription': 
              return 25;
            default:
              return undefined;
          }
        }),
        setValue: jest.fn(),
        getSublistValue: jest.fn().mockImplementation((sublist, field, number) => {
          switch(number) {
            case 0:
              return 'DNN-SA-STA-STA';
            case 1:
              return 'DNN-SA-STA-GOL';
          }
        }),
      },
      UserEventType: {
        CREATE: 'create'
      }
    } as any;

    (record.load as any).mockReturnValue({
      getValue: jest.fn().mockReturnValue([1,2]),
    });

    QuoteEvent.beforeSubmit(context2);
    expect(context2.newRecord.setValue).toHaveBeenCalled();
  });

  it('should set quote_clauses only support item', () => {
    const context2 = {
      type: 'create',
      newRecord: {
        getValue: jest.fn().mockImplementation(field => {
          switch(field) {
            case 'type': 
              return 'estimate';
            case 'custbody_related_subscription': 
              return 25;
            default:
              return undefined;
          }
        }),
        setValue: jest.fn(),
        getSublistValue: jest.fn().mockImplementation((sublist, field, number) => {
          switch(number) {
            case 0:
              return 'DNN-SA-STA-GOL';
          }
        }),
      },
      UserEventType: {
        CREATE: 'create'
      }
    } as any;

    (record.load as any).mockReturnValue({
      getValue: jest.fn().mockReturnValue([1,2]),
    });

    QuoteEvent.beforeSubmit(context2);
    expect(context2.newRecord.setValue).toHaveBeenCalled();
  });

  it('should set quote_clauses no support item', () => {
    const context2 = {
      type: 'create',
      newRecord: {
        getValue: jest.fn().mockImplementation(field => {
          switch(field) {
            case 'type': 
              return 'estimate';
            case 'custbody_related_subscription': 
              return 25;
            default:
              return undefined;
          }
        }),
        setValue: jest.fn(),
        getSublistValue: jest.fn().mockImplementation((sublist, field, number) => {
          switch(number) {
            case 0:
              return 'DNN-SA-STA-STA';
          }
        }),
      },
      UserEventType: {
        CREATE: 'create'
      }
    } as any;

    (record.load as any).mockReturnValue({
      getValue: jest.fn().mockReturnValue([1,2]),
    });

    QuoteEvent.beforeSubmit(context2);
    expect(context2.newRecord.setValue).toHaveBeenCalled();
  });

  it('should set quote_clauses invalid first item', () => {
    const context2 = {
      type: 'create',
      newRecord: {
        getValue: jest.fn().mockImplementation(field => {
          switch(field) {
            case 'type': 
              return 'estimate';
            case 'custbody_related_subscription': 
              return 25;
            default:
              return undefined;
          }
        }),
        setValue: jest.fn(),
        getSublistValue: jest.fn().mockImplementation((sublist, field, number) => {
          switch(number) {
            case 0:
              return 'not valid';
            case 1:
              return 'DNN-SA-STA-GOL';
          }
        }),
      },
      UserEventType: {
        CREATE: 'create'
      }
    } as any;

    (record.load as any).mockReturnValue({
      getValue: jest.fn().mockReturnValue([1,2]),
    });

    QuoteEvent.beforeSubmit(context2);
    expect(context2.newRecord.setValue).toHaveBeenCalled();
  });

  it('should send error email if exception is thrown', () => {
    (record.load as any).mockImplementation(() => {
      throw new Error('Some error');
    });
    const sendEmail = jest.spyOn(nsutils, 'sendEmail').mockImplementation();

    expect(() => {
      QuoteEvent.beforeSubmit(context);
    }).toThrowError('An error happened on the Quote Event script. Please, create a lambda ticket with the print of the screen before saving. Error: Some error');
    expect(sendEmail).toHaveBeenCalledWith(['rp-si@trilogy.com'], 'Quote Event script error - Ackowledgment Clauses',
    `An error happened on the quote event creation trigger for subscription 25. Quote is not created.
Error: Some error`);
  });

  it('should not set prices for an empty quote', () => {
    // to skip set aknowledgment clauses method
    jest.spyOn(SubscriptionPlanUtility, 'getSubscriptionPlanById').mockReturnValue({
      supportLevel: SupportLevel.Platinum
    } as any);

    QuoteEvent.beforeSubmit(contextSetListPrices);

    expect(contextSetListPrices.newRecord.setSublistValue).not.toHaveBeenCalled();
  });

  it('should skip subscription plan item when setting list prices', () => {
    // to skip set aknowledgment clauses method
    jest.spyOn(SubscriptionPlanUtility, 'getSubscriptionPlanById').mockReturnValue({
      supportLevel: SupportLevel.Platinum
    } as any);

    contextSetListPrices.newRecord.getLineCount = jest.fn().mockReturnValue(1);
    contextSetListPrices.newRecord.getSublistValue = jest.fn().mockImplementation((sublistId, fieldId, line) => { 
      switch(fieldId) {
        case 'subscription': 
          return 25;
        case 'itemtype': 
          return 'SubscriPlan';
      }
    });

    QuoteEvent.beforeSubmit(contextSetListPrices);

    expect(contextSetListPrices.newRecord.setSublistValue).not.toHaveBeenCalled();
  });

  it('should set list rate and discount for an item from the subscription plan', () => {
    jest.spyOn(SubscriptionPlanUtility, 'getSubscriptionPlanById').mockReturnValue({
      supportLevel: SupportLevel.Platinum,
      items: [{ id: 1, 
        prices:[{
          type: "Volume",
          frequency: "ANNUALLY",
          currency: "USD",
          pricebookid: 17594,
          ranges:[{
            priceplanid: 5233563,
            type: "Rate",
            fromQuantity: 0,
            price: 100.00
          }]
        }]
      }]
    } as any);

    contextSetListPrices.newRecord.getLineCount = jest.fn().mockReturnValue(1);
    contextSetListPrices.newRecord.getSublistValue = jest.fn().mockImplementation((sublistId, fieldId, line) => { 
      switch(fieldId) {
        case 'subscription': 
          return 25;
        case 'itemtype': 
          return 'NonInvtPart';
        case 'item':
          return '1';
        case 'rate':
          return 50.00;
        case 'quantity':
          return 1;
        case 'priceintervalfrequency':
          return 'Annually'
      }
    });

    QuoteEvent.beforeSubmit(contextSetListPrices);

    expect(contextSetListPrices.newRecord.setSublistValue).toHaveBeenCalledTimes(2);
    expect(contextSetListPrices.newRecord.setSublistValue).toHaveBeenCalledWith('item', 'custcol_list_rate', 0, 100);
    expect(contextSetListPrices.newRecord.setSublistValue).toHaveBeenCalledWith('item', 'custcol_inline_discount', 0, 50);
  });

  it('should set list price as current rate and discount as 0 when item is not in the subscirption plan', () => {
    jest.spyOn(SubscriptionPlanUtility, 'getSubscriptionPlanById').mockReturnValue({
      supportLevel: SupportLevel.Platinum,
      items: [{ id: 1, 
        prices:[{
          type: "Volume",
          frequency: "ANNUALLY",
          currency: "USD",
          pricebookid: 17594,
          ranges:[{
            priceplanid: 5233563,
            type: "Rate",
            fromQuantity: 0,
            price: 100.00
          }]
        }]
      }]
    } as any);

    contextSetListPrices.newRecord.getLineCount = jest.fn().mockReturnValue(1);
    contextSetListPrices.newRecord.getSublistValue = jest.fn().mockImplementation((sublistId, fieldId, line) => { 
      switch(fieldId) {
        case 'subscription': 
          return 25;
        case 'itemtype': 
          return 'NonInvtPart';
        case 'item':
          return '2';
        case 'rate':
          return 50.00;
        case 'quantity':
          return 1;
        case 'priceintervalfrequency':
          return 'Annually'
      }
    });

    QuoteEvent.beforeSubmit(contextSetListPrices);

    expect(contextSetListPrices.newRecord.setSublistValue).toHaveBeenCalledTimes(2);
    expect(contextSetListPrices.newRecord.setSublistValue).toHaveBeenCalledWith('item', 'custcol_list_rate', 0, 50.00);
    expect(contextSetListPrices.newRecord.setSublistValue).toHaveBeenCalledWith('item', 'custcol_inline_discount', 0, 0);
  });

  it('should set list price as current rate and discount as 0 when list price is less than current rate', () => {
    jest.spyOn(SubscriptionPlanUtility, 'getSubscriptionPlanById').mockReturnValue({
      supportLevel: SupportLevel.Platinum,
      items: [{ id: 1, 
        prices:[{
          type: "Volume",
          frequency: "ANNUALLY",
          currency: "USD",
          pricebookid: 17594,
          ranges:[{
            priceplanid: 5233563,
            type: "Rate",
            fromQuantity: 0,
            price: 100.00
          }]
        }]
      }]
    } as any);

    contextSetListPrices.newRecord.getLineCount = jest.fn().mockReturnValue(1);
    contextSetListPrices.newRecord.getSublistValue = jest.fn().mockImplementation((sublistId, fieldId, line) => { 
      switch(fieldId) {
        case 'subscription': 
          return 25;
        case 'itemtype': 
          return 'NonInvtPart';
        case 'item':
          return '1';
        case 'rate':
          return 150.00;
        case 'quantity':
          return 1;
        case 'priceintervalfrequency':
          return 'Annually'
      }
    });
    contextSetListPrices.newRecord.getValue = jest.fn().mockImplementation(field => { 
      switch(field) {
        case 'type': 
          return 'estimate';
        case 'nluser': 
          return '672750';
        case 'custbody_related_subscription': 
          return 25;
        case 'currencysymbol':
          return 'USD';
        case 'startdate':
          return '20-Jan-2023';
          case 'enddate':
            return '15-Dec-2023';
        default:
          return 1;
      }
    });
    QuoteEvent.beforeSubmit(contextSetListPrices);

    expect(contextSetListPrices.newRecord.setSublistValue).toHaveBeenCalledTimes(2);
    expect(contextSetListPrices.newRecord.setSublistValue).toHaveBeenCalledWith('item', 'custcol_list_rate', 0, 150.00);
    expect(contextSetListPrices.newRecord.setSublistValue).toHaveBeenCalledWith('item', 'custcol_inline_discount', 0, 0);
  });

  it('should send email signature image not found', () => {
    (record.load as any).mockReturnValue({
      getValue: jest.fn().mockImplementation(field => {
        switch(field) {
          case 'custentity_signature':
            return undefined;
          case 'entityid':
            return 'Employee';
          case 'name':
            return 'Subsidiary name';
          default:
            return [1,2];
        }
      }),
    });
    const sendEmail = jest.spyOn(nsutils, 'sendEmail').mockImplementation();
    QuoteEvent.beforeSubmit(context);
    expect(sendEmail).toHaveBeenCalledWith(['rp-si@trilogy.com'], 'Quote Event - Employee Signature Image not found',
    `The employee signature image was not found for Employee when generating quote for subscription 25.
He is the signatory for subsidiary 1 - Subsidiary name.`);
  });
});
