import { beforeLoad } from '../src/ts/events/QuoteLoadEvent';

describe('beforeLoad', () => {
    let contextMock: any;

    beforeEach(() => {
        contextMock = {
            type: 'view',
            newRecord: {
                getValue: jest.fn().mockReturnValue('estimate'),
            },
            UserEventType: {
                VIEW: 'view',
            },
            form: {
                clientScriptModulePath: '',
                addButton: jest.fn(),
            },
        };
    });

    afterEach(() => {
        jest.clearAllMocks();
    });

    it('should return early if the user event type is not VIEW', () => {
        contextMock.type = 'create';

        beforeLoad(contextMock);

        expect(contextMock.form.clientScriptModulePath).toBe('');
        expect(contextMock.form.addButton).not.toHaveBeenCalled();
    });

    it('should return early if the record type is not estimate', () => {
        contextMock.newRecord.getValue.mockReturnValue('invoice');

        beforeLoad(contextMock);

        expect(contextMock.form.clientScriptModulePath).toBe('');
        expect(contextMock.form.addButton).not.toHaveBeenCalled();
    });

    it('should set the client script module path to QuoteCreateEUAScript.js', () => {
        beforeLoad(contextMock);

        expect(contextMock.form.clientScriptModulePath).toBe('/SuiteScripts/si/main/utility/QuoteCreateEUAScript.js');
    });

    it('should add a custom button to the form', () => {
        beforeLoad(contextMock);

        expect(contextMock.form.addButton).toHaveBeenCalledWith({
            id: 'custpage_create_adobe_agreement',
            label: 'Create EUA',
            functionName: 'createEUA',
        });
    });
});