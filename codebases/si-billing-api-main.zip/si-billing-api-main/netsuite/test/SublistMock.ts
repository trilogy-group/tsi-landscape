export class RecordDynamicMock {
  sublists: Map<string, any[]>;
  fields: Map<string, any>;
  curLines: Map<string, number>;

  constructor(sublists, fields) {
    this.sublists = sublists;
    this.fields = fields;
    this.curLines = {} as Map<string, number>;
  }

  findSublistLineWithValue(options: { sublistId: string; fieldId: string; value; }) {
    return this.sublists[options.sublistId].findIndex(i => i.getValue(options.fieldId) === options.value);
  }

  getSublistValue(sublistId: string, fieldId: string, lineNumber: number) {
    return this.sublists[sublistId][lineNumber].getValue(fieldId);
  }

  getLineCount(param: { sublistId: string }) {
    return this.sublists[param.sublistId].length;
  }
  setValue(opts: { fieldId: string; value: any } | string, val?) {
    if (typeof opts === 'string') {
      this.fields[opts] = val;
    } else {
      this.fields[opts.fieldId] = opts.value;
    }
  }
  getValue(opts: { fieldId: string } | string) {
    if (typeof opts === 'string') {
      return this.fields[opts];
    } else {
      return this.fields[opts.fieldId];
    }
  }
  save() {
    return 1;
  }
  selectLine(opts: { sublistId: string; line: number }) {
    this.curLines[opts.sublistId] = opts.line;
  }
  getCurrentSublistValue(opts: { sublistId: string; fieldId: string }) {
    return this.sublists[opts.sublistId][this.curLines[opts.sublistId] || 0][opts.fieldId];
  }
  getCurrentSublistText(opts: { sublistId: string; fieldId: string }) {
    return this.sublists[opts.sublistId][this.curLines[opts.sublistId] || 0][opts.fieldId];
  }
  setCurrentSublistValue(opts: { sublistId: string; fieldId: string; value: any }) {
    this.sublists[opts.sublistId][this.curLines[opts.sublistId] || 0][opts.fieldId] = opts.value;
  }
  commitLine() {}

  selectNewLine(opts: { sublistId: string }) {
    this.curLines[opts.sublistId] = (this.curLines[opts.sublistId] || -1) + 1;
    this.sublists[opts.sublistId]?.push({});
  }
}
