import * as nsutils from '../src/ts/nsutils';
import * as record from 'N/record';
import * as search from 'N/search';
import { RecordDynamicMock } from './SublistMock';
import { Subscription, testables } from '../src/ts/Subscription';
import { supportLevelDistributionRatio, supportLevelUptick } from '../src/ts/models/SupportLevel';
import billingAccountDao from '../src/ts/dao/BillingAccountDao';
import customerDao from '../src/ts/dao/CustomerDao';
import entityDao from '../src/ts/dao/EntityDao';
import subscriptionPlanDao from '../src/ts/dao/SubscriptionPlanDao';
import subscriptionDao from '../src/ts/dao/SubscriptionDao';
import customerService from '../src/ts/CustomerService';
import subscriptionCreateUtility from '../src/ts/utility/SubscriptionCreateUtility';
import subscriptionGetUtility from '../src/ts/utility/SubscriptionGetUtility';
import subscriptionItemUtility, { ItemCode } from '../src/ts/utility/SubscriptionItemUtility';
import subscriptionPlanUtility from '../src/ts/utility/SubscriptionPlanUtility';
import subscriptionPriceUtility from '../src/ts/utility/SubscriptionPriceUtility';
import subscriptionValidateUtility from '../src/ts/utility/SubscriptionValidateUtility';
import subscriptionUtility from '../src/ts/utility/SubscriptionUtility';
import {
  ContractualDocumentType,
  ContractualDocumentTypeUtils,
  OperationUtils,
  ProductTier,
  SubscriptionLineStatus,
  SubscriptionStatus,
  SubscriptionTermType,
  SupportLevel,
  SupportLevelUtil,
  TermUnit,
} from '../src/ts/types';
import { SubscriptionRecord } from '../src/ts/models/SubscriptionRecord';
import { SubscriptionRecordMock } from './mocks/SubscriptionRecordMock';
import SubscriptionGetUtility from '../src/ts/utility/SubscriptionGetUtility';
import { ProductIntegration } from '../src/ts/ProductIntegration';
import { SubscriptionConfiguration, SubscriptionCreateParams } from '../src/ts/models/SubscriptionParams';
import SubscriptionChangeOrderUtility from '../src/ts/utility/SubscriptionChangeOrderUtility';
import { clone } from '../src/ts/utility/GeneralUtility';
import FileService, { Folder } from '../src/ts/utility/FileService';
import ContractualDocumentsService from '../src/ts/utility/ContractualDocumentsService';
import ClassDao from '../src/ts/dao/ClassDao';

function spyPrivate(obj: any, methodName: string, impl?: any) {
  const f = jest.spyOn(Object.getPrototypeOf(obj), methodName);
  if (impl) {
    return f.mockImplementation(impl);
  }
  return f;
}

// expose private methods
function exposePrivate(obj): any {
  //tbd bind
  return Object.getPrototypeOf(obj);
}

function getISODate(date?: Date) {
  if (!date) {
    date = new Date();
  }
  return date.toISOString().split('T')[0];
}

describe('Subscription', () => {
  beforeEach(() => {
    jest.clearAllMocks();
    jest.restoreAllMocks();
    jest.spyOn(nsutils, 'queryToJson');
    jest.spyOn(nsutils, 'queryFirstToJson');
    jest.spyOn(nsutils, 'queryFirstAsMap');
    jest.spyOn(subscriptionPlanUtility, 'extractPVCFromPlanCode').mockReturnValue('SA-Cus');
    jest.spyOn(ProductIntegration, 'findProductIntegration');
    jest.spyOn(ProductIntegration, 'findByClass');
    jest.spyOn(subscriptionPlanUtility, 'getSubscriptionPlanById');
    jest.spyOn(subscriptionGetUtility, 'getSubscriptionByIdInternal');
    jest.spyOn(subscriptionGetUtility, 'getSubscriptionByIdForCustomer');
    jest.spyOn(subscriptionDao, 'findItemCodes');
    jest.spyOn(subscriptionDao, 'findSubscriptionItemCodes');
    jest.spyOn(subscriptionDao, 'getRenewalHistoryOfSubscription');
    jest.spyOn(subscriptionItemUtility, 'findItemCodes');
    spyPrivate(subscriptionGetUtility, 'buildItems');
    spyPrivate(subscriptionGetUtility, 'convertLinesToArray');
    spyPrivate(subscriptionGetUtility, 'getSubscriptionRecItems');
    jest.spyOn(subscriptionPlanUtility, 'findSubscriptionPlanAndPriceBook');
    spyPrivate(subscriptionValidateUtility, 'validateSubscriptionItems');
    spyPrivate(subscriptionCreateUtility, 'findSuitableSubsidiary').mockReturnValue(1);
    jest.spyOn(Subscription, 'create');
    jest.spyOn(record, 'load');
    jest.spyOn(customerService, 'createBillingAccount');
    jest.spyOn(customerService, 'addSubsidiary').mockImplementation(() => {});
    jest.spyOn(customerDao, 'getInternalId').mockReturnValue(1);
    jest.spyOn(billingAccountDao, 'getBillingScheduleId').mockReturnValue(1);
    jest
      .spyOn(subscriptionPlanDao, 'getInternalIdAndSubsidiary')
      .mockReturnValue({ id: 1, subsidiaries: ['1'], class: 1 });
    jest.spyOn(subscriptionPlanDao, 'findPriceBook').mockReturnValue(1);
    spyPrivate(subscriptionPlanUtility, 'getPlanInfo').mockReturnValue({
      id: 1,
      code: 'TEST',
      displayName: 'DNNE-SA-CUS-STA-SIL-001',
    });

  });

  it('findItemForLine should return proper items', () => {
    const items = [{ code: 'SOC-SA-USR-STD' }, { code: 'SOC-SA-USR-SIL' }, { code: 'SOC-SA-MED-STD' }];
    const plan = {
      items: [
        { id: 234, code: 'SOC-SA-USR-STD', isMainItem: true },
        { id: 345, code: 'SOC-SA-USR-SIL', supportLevel: SupportLevel.Silver, isSupportMainItem: true },
        { id: 456, code: 'SOC-SA-MED-STD' },
      ],
    };

    let item = testables.findItemForLine(345, plan, items);
    expect(item).toStrictEqual({ code: 'SOC-SA-USR-STD' });

    item = testables.findItemForLine(234, plan, items);
    expect(item).toStrictEqual({ code: 'SOC-SA-USR-STD' });

    item = testables.findItemForLine(456, plan, items);
    expect(item).toStrictEqual({ code: 'SOC-SA-MED-STD' });
  });

  it('findItemForLine throws error if not found', () => {
    const items = [{ code: 'SOC-SA-USR-STD1' }, { code: 'SOC-SA-USR-SIL' }, { code: 'SOC-SA-MED-STD' }];
    const plan = {
      items: [
        { id: 234, code: 'SOC-SA-USR-STD', isMainItem: true },
        { id: 345, code: 'SOC-SA-USR-SIL', supportLevel: SupportLevel.Silver, isSupportItem: true },
        { id: 456, code: 'SOC-SA-MED-STD' },
      ],
    };

    expect(() => {
      testables.findItemForLine(345, plan, items);
    }).toThrowError('Cannot find item with code SOC-SA-USR-STD1');
  });

  it('findItemForLine support only plan', () => {
    const items = [
      {
        code: 'DNNR-SA-Cus-PLA',
        quantity: 4,
        id: 87291,
      },
    ];
    const planItems = [
      {
        id: 87291,
        code: 'DNNR-SA-Cus-PLA',
        title: 'DNNR Platinum Support',
        supportLevel: 'Platinum',
        productTier: null,
        revenueType: 'SaaS',
        isSupportMainItem: true,
        isSupportAddonItem: false,
        isMainItem: false,
        required: true,
        type: 'Recurring',
        typeId: 2,
        desc: '',
        minQuantity: null,
        maxQuantity: null,
        prices: [
          {
            type: 'Tiered',
            frequency: 'ANNUALLY',
            currency: 'USD',
            pricebookid: 13265,
            ranges: [
              {
                priceplanid: 4838343,
                type: 'Rate',
                fromQuantity: 0,
                price: 40,
              },
            ],
          },
        ],
      },
      {
        id: 87387,
        code: 'DNNR-SA-Cus-ADDPLA',
        title: 'DNNR Addon Platinum',
        supportLevel: null,
        productTier: null,
        revenueType: 'SaaS',
        isSupportMainItem: false,
        isSupportAddonItem: false,
        isMainItem: false,
        required: false,
        type: 'Recurring',
        typeId: 2,
        desc: '',
        minQuantity: null,
        maxQuantity: null,
        prices: [
          {
            type: 'Tiered',
            frequency: 'ANNUALLY',
            currency: 'USD',
            pricebookid: 13265,
            ranges: [
              {
                priceplanid: 4838344,
                type: 'Rate',
                fromQuantity: 0,
                price: 25,
              },
            ],
          },
        ],
      },
    ];

    const item = testables.findItemForLine(87387, { items: planItems }, items, true);
    expect(item).toBeUndefined();
  });

  it('create', () => {
    const lastMonth = new Date();
    lastMonth.setMonth(lastMonth.getMonth() - 1);
    const subsToCreate: SubscriptionConfiguration = {
      planCode: 'TestPlan',
      frequency: 'monthly',
      duration: 200,
      items: [
        {
          code: 'TES-SA-IT1-STA',
          quantity: 42,
        },
      ],
      effectiveDate: getISODate(lastMonth),
      contractualDocumentId: 3,
    };

    const createParams: SubscriptionCreateParams = {
      productFamilyCode: 'TES',
      productVariantCode: 'SA',
      customerId: 'TestCustomerId',
      content: subsToCreate,
    };

    (subscriptionPlanUtility.getSubscriptionPlanById as any).mockReturnValue({
      items: [
        {
          code: 'TES-SA-IT1-STA',
          id: 321,
          required: true,
          productTier: ProductTier.Standard,
          isMainItem: true,
          isSupportItem: false,
          prices: [
            {
              type: 'Tiered',
              frequency: 'ANNUALLY',
              currency: 'USD',
              ranges: [
                {
                  type: 'Rate',
                  fromQuantity: 0,
                  price: 1000,
                },
              ],
            },
          ],
        },
        {
          code: 'TES-SA-IT1-SIL',
          id: 322,
          supportLevel: SupportLevel.Silver,
          isMainItem: false,
          isSupportItem: true,
          prices: [
            {
              type: 'Tiered',
              frequency: 'ANNUALLY',
              currency: 'USD',
              ranges: [
                {
                  type: 'Rate',
                  fromQuantity: 0,
                  price: 200,
                },
              ],
            },
          ],
        },
      ],
      supportLevel: SupportLevel.Silver,
      productTier: ProductTier.Standard,
      revenueType: 'Saas',
      mainItemCode: 'TES-SA-IT1-STA',
      supportItemCode: 'TES-SA-IT1-SIL',
      supportOnly: false,
      isLegacyPlan: false,
    });
    jest.spyOn(customerDao, 'findCustomerAndBa').mockReturnValueOnce({ customerId: 'TestCustomer' });
    (subscriptionDao.findSubscriptionItemCodes as any).mockReturnValue([
      { code: 'TES-SA-IT1-STA', id: 321, required: true },
      { code: 'TES-SA-IT1-SIL', id: 322, supportLevel: SupportLevel.Silver },
    ]);
    (ProductIntegration.findByClass as any).mockReturnValueOnce([
      { nsClass: { id: 1, name: 'USD', fullname: 'Dollar' } },
    ]);
    jest.spyOn(customerDao, 'getEntityStatus').mockReturnValueOnce(1);
    jest.spyOn(entityDao, 'getEntityStatusKey').mockReturnValueOnce(1);
    jest.spyOn(subscriptionDao, 'getCustomerSubscriptionIds').mockReturnValue([{ id: 1 }, { id: 2 }]);
    jest.spyOn(customerDao, 'getCustomerSubsidiaries').mockReturnValueOnce([{ subsidiaryId: '22', primary: true }]);
    jest
      .spyOn(subscriptionPlanUtility, 'findSubscriptionPlanAndPriceBook')
      .mockReturnValue({ subscriptionPlanId: 1, subscriptionPlanClass: 1, priceBookId: 1, subsidiaries: ['22'] });
    exposePrivate(subscriptionValidateUtility).validateSubscriptionItems.mockImplementation(() => {});
    jest.spyOn(subscriptionPriceUtility, 'applyDiscount').mockReturnValue(1);

    const subscriptionRecord = new RecordDynamicMock(
      {
        subscriptionline: [
          { item: 321, status: 'DRAFT', isrequired: true },
          { item: 322, status: 'DRAFT' },
        ],
        priceinterval: [
          { item: 321, status: 'DRAFT' },
          { item: 322, status: 'DRAFT' },
        ],
      },
      {
        initialtermduration: 6,
        initialtermunits: 'MONTHS',
      }
    );

    const testPricePlan = new RecordDynamicMock(
      {
        pricetiers: [
          { fromval: 0, value: 12, pricingoption: 'RATE' },
          { fromval: 10, value: 9, pricingoption: 'RATE' },
          { fromval: 30, value: 6, pricingoption: 'RATE' },
        ],
      },
      {}
    );

    const testActivateChangeOrder = new RecordDynamicMock(
      {
        subline: [
          { item: 321, status: 'DRAFT', quantity: 0, isrequired: true },
          { item: 322, status: 'DRAFT', quantity: 0 },
        ],
      },
      {}
    );

    (record.create as any).mockImplementation((opts) => {
      if (opts.type === record.Type.SUBSCRIPTION) {
        return subscriptionRecord;
      } else if (opts.type === record.Type.PRICE_PLAN) {
        return testPricePlan;
      } else if (opts.type === record.Type.SUBSCRIPTION_CHANGE_ORDER) {
        return testActivateChangeOrder;
      } else {
        return new RecordDynamicMock({}, {});
      }
    });
    (record.load as any).mockImplementation((opts) => {
      if (opts.type === record.Type.SUBSCRIPTION) {
        return subscriptionRecord;
      } else if (opts.type === record.Type.PRICE_PLAN) {
        return testPricePlan;
      } else if (opts.type === record.Type.SUBSCRIPTION_CHANGE_ORDER) {
        return testActivateChangeOrder;
      } else {
        return new RecordDynamicMock({}, {});
      }
    });
    jest.spyOn(subscriptionGetUtility, 'getSubscriptionByIdForCustomer').mockReturnValueOnce('Test' as any);
    Subscription.create(createParams);
  });

  it('fillSubscriptionForCreate error on empty content', () => {
    const createParams = {
      productFamilyCode: 'TES',
      productVariantCode: 'SA',
      customerId: 'TestCustomerId',
      content: {
        planClass: 1,
      },
    };

    jest.spyOn(customerDao, 'findCustomerAndBa').mockReturnValueOnce({ customerId: 'TestCustomer' });
    (subscriptionDao.findItemCodes as any).mockReturnValueOnce([{ code: 'TES-SA-IT1', id: 321 }]);
    (ProductIntegration.findProductIntegration as any).mockReturnValueOnce([
      { nsClass: { id: 1, name: 'USD', fullname: 'Dollar' } },
    ]);

    const testSubscriptionRecord = {
      fields: {
        customer: '123',
      },
      sublists: {
        priceinterval: {},
        subscriptionline: {},
      },
      getLineCount: () => {
        return 1;
      },
      setValue: () => {},
      save: () => {},
      selectLine: () => {},
      getCurrentSublistValue: (p) => {
        return p.fieldId === 'item' ? 321 : {};
      },
      setCurrentSublistValue: () => {},
      commitLine: () => {},
    };

    expect(() => {
      exposePrivate(subscriptionCreateUtility).fillSubscriptionForCreate(testSubscriptionRecord, createParams);
    }).toThrowError('items is mandatory');
  });

  it('fillSubscriptionForCreate error on customer not found', () => {
    const subsToCreate = {
      planCode: 'TestPlan',
      frequency: 'monthly',
      items: [
        {
          code: 'TES-SA-IT1',
          quantity: 42,
        },
      ],
      planClass: 1,
    };
    const createParams = {
      productFamilyCode: 'TES',
      productVariantCode: 'SA',
      customerId: 'TestCustomerId',
      content: subsToCreate,
    };

    jest.spyOn(customerDao, 'findCustomerAndBa').mockReturnValueOnce(null);
    (subscriptionDao.findItemCodes as any).mockReturnValueOnce([{ code: 'TES-SA-IT1', id: 321 }]);
    (ProductIntegration.findProductIntegration as any).mockReturnValueOnce([
      { nsClass: { id: 1, name: 'USD', fullname: 'Dollar' } },
    ]);

    const testSubscriptionRecord = {
      fields: {
        customer: '123',
      },
      sublists: {
        priceinterval: {},
        subscriptionline: {},
      },
      getLineCount: () => {
        return 1;
      },
      setValue: () => {},
      save: () => {},
      selectLine: () => {},
      getCurrentSublistValue: (p) => {
        return p.fieldId === 'item' ? 321 : {};
      },
      setCurrentSublistValue: () => {},
      commitLine: () => {},
    };

    expect(() => {
      exposePrivate(subscriptionCreateUtility).fillSubscriptionForCreate(testSubscriptionRecord, createParams, {});
    }).toThrowError('customer not found');
  });

  it('fillSubscription error on incompatible classes', () => {
    const subsToCreate = {
      planCode: 'TestPlan',
      frequency: 'monthly',
      items: [
        {
          code: 'TES-SA-IT1',
          quantity: 42,
        },
      ],
      planClass: 1,
    };
    const createParams = {
      productFamilyCode: 'TES',
      productVariantCode: 'SA',
      customerId: 'TestCustomerId',
      content: subsToCreate,
    };

    jest.spyOn(customerDao, 'findCustomerAndBa').mockReturnValueOnce({ customerId: 123 });
    (subscriptionDao.findItemCodes as any).mockReturnValueOnce([{ code: 'TES-SA-IT1', id: 321 }]);
    (ProductIntegration.findProductIntegration as any).mockReturnValueOnce([
      { nsClass: { id: 1, name: 'USD', fullname: 'Dollar' } },
    ]);
    jest.spyOn(customerService, 'createBillingAccount').mockImplementationOnce(() => {
      throw new Error('Invalid field value 223 for the following field: class');
    });

    const testSubscriptionRecord = {
      fields: {
        customer: '123',
      },
      sublists: {
        priceinterval: {},
        subscriptionline: {},
      },
      getLineCount: () => {
        return 1;
      },
      setValue: () => {},
      save: () => {},
      selectLine: () => {},
      getCurrentSublistValue: (p) => {
        return p.fieldId === 'item' ? 321 : {};
      },
      setCurrentSublistValue: () => {},
      commitLine: () => {},
    };

    expect(() => {
      exposePrivate(subscriptionCreateUtility).fillSubscriptionForCreate(testSubscriptionRecord, createParams, {});
    }).toThrowError('Customer is incompatible with this product');
  });

  it('update', () => {
    const subsToUpdate = {
      planCode: 'TestPlan',
      frequency: 'MONTHLY',
      items: [
        {
          code: 'TES-SA-IT1-STA',
          quantity: 43,
        },
        {
          code: 'TES-SA-IT2-SIL',
          quantity: 11,
        },
      ],
    };

    exposePrivate(subscriptionGetUtility).buildItems.mockReturnValueOnce({
      terms: {
        hekko: 'a',
      },
      availableItems: [
        {
          amount: 1,
          code: 'TES-SA-IT1-STA',
          desc: 'TestDescription',
          id: 321,
          prices: [
            {
              currency: 'USD',
              frequency: 'MONTHLY',
              ranges: [{ fromQuantity: 0, price: 1, type: 'Volume' }],
              type: undefined,
            },
          ],
          productTier: 'Standard',
          required: true,
          revenueType: 'SaaS',
          supportLevel: 'Silver',
          title: undefined,
          type: 'Recurring',
        },
        {
          amount: 0,
          code: 'TES-SA-IT2-SIL',
          desc: 'TestDescription',
          id: 322,
          prices: [{ currency: 'USD', frequency: 'MONTHLY', ranges: [], type: undefined }],
          productTier: undefined,
          required: true,
          revenueType: undefined,
          supportLevel: 'Silver',
          title: undefined,
          type: 'Recurring',
        },
      ],
      includedItems: [
        { code: 'TES-SA-IT1-STA', id: 321, quantity: 2 },
        { code: 'TES-SA-IT2-SIL', id: 322, quantity: 2 },
      ],
      supportItems: [],
      mainItem: {
        amount: 1,
        code: 'TES-SA-IT2-SIL',
        desc: 'TestDescription',
        id: 322,
        prices: [
          {
            currency: 'USD',
            frequency: 'MONTHLY',
            ranges: [{ fromQuantity: 0, price: 1, type: 'Volume' }],
            type: undefined,
          },
        ],
        productTier: 'Professional',
        required: true,
        revenueType: 'SaaS',
        supportLevel: 'Silver',
        title: undefined,
        type: 'Recurring',
      },
      planOptions: {
        productTier: 'Professional',
        revenueType: 'SaaS',
        supportLevel: 'Silver',
        isLegacyPlan: false,
      },
      supportItem: {
        amount: 0,
        code: 'TES-SA-IT2-SIL',
        desc: 'TestDescription',
        id: 322,
        prices: [{ currency: 'USD', frequency: 'MONTHLY', ranges: [], type: undefined }],
        productTier: undefined,
        required: true,
        revenueType: undefined,
        supportLevel: 'Silver',
        title: undefined,
        type: 'Recurring',
      },
    });

    const updateParams = {
      productFamilyCode: 'TES',
      productVariantCode: 'SA',
      customerId: 'TestCustomerId',
      subscriptionId: 123,
      content: subsToUpdate,
    };
    jest.spyOn(subscriptionPlanUtility, 'getSubscriptionPlanById').mockReturnValue({
      items: [
        {
          code: 'TES-SA-IT1-STA',
          id: 321,
          required: true,
          productTier: ProductTier.Standard,
          prices: [
            {
              currency: 'USD',
              frequency: 'MONTHLY',
              ranges: [{ fromQuantity: 0, price: 1, type: 'Volume', priceplanid: 1 }],
              type: undefined,
            },
          ],
        } as any,
        {
          code: 'TES-SA-IT2-SIL',
          id: 322,
          supportLevel: SupportLevel.Silver,
          prices: [
            {
              currency: 'USD',
              frequency: 'MONTHLY',
              ranges: [{ fromQuantity: 0, price: 1, type: 'Volume' }],
              type: undefined,
            },
          ],
        },
      ],
      supportLevel: SupportLevel.Silver,
      productTier: ProductTier.Standard,
      revenueType: 'Saas',
      mainItemCode: 'TES-SA-IT1-STA',
      supportItemCode: 'TES-SA-IT2-SIL',
      supportOnly: false,
      code: 'TES-SA-IT1-STA-SIL-001',
      name: 'asd asd asd',
      isLegacyPlan: false,
      initialterm: {
        duration: 1,
        unit: 'YEARS',
      },
    } as any);
    jest.spyOn(subscriptionPlanUtility, 'isCurrentPlanChange').mockReturnValueOnce(false);
    jest.spyOn(customerDao, 'findCustomerAndBa').mockReturnValueOnce({ customerId: 'TestCustomer' });
    (subscriptionDao.findSubscriptionItemCodes as any).mockReturnValue([
      { code: 'TES-SA-IT1-STA', id: 321, required: true },
      { code: 'TES-SA-IT2-SIL', id: 322, supportLevel: SupportLevel.Silver },
    ]);
    (subscriptionDao.findItemCodes as any).mockReturnValueOnce([
      { code: 'TES-SA-IT1-STA', id: 321 },
      { code: 'TES-SA-IT2-SIL', id: 322 },
    ]);
    (subscriptionDao.getRenewalHistoryOfSubscription as any).mockReturnValue([]);

    (subscriptionItemUtility.findItemCodes as any).mockReturnValueOnce([
      { code: 'TES-SA-IT1-STA', id: 321, status: 'ACTIVE' },
      { code: 'TES-SA-IT2-SIL', id: 322, status: 'NOT_INCLUDED' },
    ]);
    jest
      .spyOn(ProductIntegration, 'findProductIntegration')
      .mockReturnValueOnce({ nsClass: { id: 1, name: 'USD', fullname: 'Dollar' }, isUptickEnabled: true });
    jest.spyOn(customerDao, 'getEntityStatus').mockReturnValueOnce(1);
    jest.spyOn(entityDao, 'getEntityStatusKey').mockReturnValueOnce(2);
    jest.spyOn(subscriptionValidateUtility, 'validateAndPrepareUpdateData').mockImplementation((params) => {
      if (!params.content) {
        params.content = { planClass: 1 };
      }
      params.content.planId = 1;
      params.content.planClass = 1;
    });
    jest.spyOn(subscriptionValidateUtility, 'validateAndPrepareCreateData').mockImplementation(() => {});
    jest.spyOn(subscriptionValidateUtility, 'validateUpdateActive').mockReturnValue({ isDowngrade: false });
    jest.spyOn(subscriptionPriceUtility, 'applyDiscount').mockReturnValue(1);
    jest
      .spyOn(subscriptionGetUtility, 'getSubscriptionByIdInternal')
      .mockReturnValue({ status: 'ACTIVE', plan: { id: 1 } } as any);
    const testSubscriptionRecord = {
      fields: {
        customer: '123',
        startdate: '2020-01-01',
        enddate: '2021-01-01',
        frequency: 'MONTHLY',
        billingsubscriptionstatus: 'ACTIVE',
      },
      sublists: {
        priceinterval: {},
        subscriptionline: {},
      },
      getLineCount: () => {
        return 1;
      },
      setValue: () => {},
      save: () => {},
      selectLine: () => {},
      selectNewLine: () => {},
      getCurrentSublistValue: (p) => {
        return p.fieldId === 'item' ? '322' : {};
      },
      getCurrentSublistText: () => {
        return 'Recurring';
      },
      getValue: () => {
        return 'ACTIVE';
      },
      setCurrentSublistValue: () => {},
      commitLine: () => {},
    };

    (record.create as any).mockReturnValue(testSubscriptionRecord);
    jest.spyOn(record, 'load').mockReturnValue(testSubscriptionRecord as any);
    jest.spyOn(subscriptionGetUtility, 'getSubscriptionByIdForCustomer').mockReturnValueOnce('Test' as any);
    jest.spyOn(record, 'create').mockReturnValue(testSubscriptionRecord as any);
    jest.spyOn(subscriptionGetUtility, 'getSubscriptionByIdForCustomer').mockReturnValueOnce('Test' as any);
    jest.spyOn(subscriptionValidateUtility, 'validateSubscriptionItems').mockImplementation(() => {});
    jest.spyOn(subscriptionGetUtility, 'getSubscriptionRecItems').mockReturnValue({
      planId: 1,
      planItems: [],
      planInfo: {
        isSupportOnlyPlan: false,
      },
      subscriptionItems: {
        availableItems: [],
        supportItems: [],
        mainItem: undefined,
        supportItem: undefined,
      },
    } as any);
    jest.spyOn(subscriptionValidateUtility, 'validateUpdateActive').mockReturnValue({ isDowngrade: false });
    jest.spyOn(subscriptionGetUtility, 'getSubscriptionByIdForCustomer').mockReturnValueOnce('Test' as any);
    const res = Subscription.updateOrRenew(updateParams);
    expect(res).toStrictEqual(expect.anything());
  });

  it('update changing plan', () => {
    const subsToUpdate = {
      planCode: 'TestPlan',
      frequency: 'MONTHLY',
      items: [
        {
          code: 'TES-SA-IT1-STA',
          quantity: 43,
        },
        {
          code: 'TES-SA-IT2-SIL',
          quantity: 11,
        },
      ],
    };

    const updateParams = {
      productFamilyCode: 'TES',
      productVariantCode: 'SA',
      customerId: 'TestCustomerId',
      subscriptionId: 123,
      content: subsToUpdate,
    };
    (subscriptionPlanUtility.getSubscriptionPlanById as any).mockReturnValue({
      items: [
        {
          code: 'TES-SA-IT1-STA',
          id: 321,
          required: true,
          productTier: ProductTier.Standard,
          prices: [
            {
              currency: 'USD',
              frequency: 'MONTHLY',
              ranges: [{ fromQuantity: 0, price: 1, type: 'Volume' }],
              type: undefined,
            },
          ],
        },
        {
          code: 'TES-SA-IT2-SIL',
          id: 322,
          supportLevel: SupportLevel.Silver,
          prices: [
            {
              currency: 'USD',
              frequency: 'MONTHLY',
              ranges: [{ fromQuantity: 0, price: 1, type: 'Volume' }],
              type: undefined,
            },
          ],
        },
      ],
      supportLevel: SupportLevel.Silver,
      productTier: ProductTier.Standard,
      revenueType: 'Saas',
      mainItemCode: 'TES-SA-IT1-STA',
      supportItemCode: 'TES-SA-IT2-SIL',
      supportOnly: false,
    });
    jest.spyOn(customerDao, 'findCustomerAndBa').mockReturnValueOnce({ customerId: 'TestCustomer' });
    (subscriptionDao.findSubscriptionItemCodes as any).mockReturnValue([
      { code: 'TES-SA-IT1-STA', id: 321, isrequired: true },
      { code: 'TES-SA-IT1-SIL', id: 322, supportLevel: SupportLevel.Silver },
    ]);
    (subscriptionDao.getRenewalHistoryOfSubscription as any).mockReturnValue([]);
    (subscriptionItemUtility.findItemCodes as any).mockReturnValueOnce([
      { code: 'TES-SA-IT1-STA', id: 321, status: 'ACTIVE' },
      { code: 'TES-SA-IT2-SIL', id: 322, status: 'NOT_INCLUDED' },
    ]);
    jest
      .spyOn(ProductIntegration, 'findProductIntegration')
      .mockReturnValueOnce({ nsClass: { id: 1, name: 'USD', fullname: 'Dollar' }, isUptickEnabled: true });
    jest.spyOn(customerDao, 'getEntityStatus').mockReturnValueOnce(1);
    jest.spyOn(entityDao, 'getEntityStatusKey').mockReturnValueOnce(2);
    jest.spyOn(subscriptionValidateUtility, 'validateAndPrepareUpdateData').mockImplementation((params) => {
      if (!params.content) {
        params.content = { planClass: 1 };
      }
      params.content.planId = 1;
      params.content.planClass = 1;
    });
    jest.spyOn(subscriptionValidateUtility, 'validateAndPrepareCreateData').mockImplementation(() => {});
    jest.spyOn(subscriptionValidateUtility, 'validateUpdateActive').mockReturnValue({ isDowngrade: false });
    jest
      .spyOn(subscriptionGetUtility, 'getSubscriptionByIdInternal')
      .mockReturnValue({ status: 'ACTIVE', plan: { id: 1 } } as any);
    const testSubscriptionRecord = {
      fields: {
        customer: '123',
        startdate: '2020-01-01',
        enddate: '2021-01-01',
        frequency: 'MONTHLY',
        billingsubscriptionstatus: 'ACTIVE',
      },
      sublists: {
        priceinterval: {},
        subscriptionline: {},
      },
      getLineCount: () => {
        return 1;
      },
      setValue: () => {},
      save: () => {},
      selectLine: () => {},
      getCurrentSublistValue: (p) => {
        return p.fieldId === 'item' ? '321' : {};
      },
      getCurrentSublistText: (p) => {
        return p.fieldId === 'item' ? '321' : {};
      },
      getValue: () => {
        return 'ACTIVE';
      },
      setCurrentSublistValue: () => {},
      commitLine: () => {},
    };

    (record.create as any).mockReturnValue(testSubscriptionRecord);
    jest.spyOn(record, 'load').mockReturnValue(testSubscriptionRecord as any);
    jest.spyOn(subscriptionGetUtility, 'getSubscriptionByIdForCustomer').mockReturnValueOnce('Test' as any);
    jest.spyOn(record, 'create').mockReturnValue(testSubscriptionRecord as any);
    jest.spyOn(subscriptionGetUtility, 'getSubscriptionByIdForCustomer').mockReturnValueOnce('Test' as any);
    jest.spyOn(subscriptionValidateUtility, 'validateSubscriptionItems').mockImplementation(() => {});
    jest.spyOn(subscriptionGetUtility, 'getSubscriptionRecItems').mockReturnValue({
      planId: 1,
      planItems: [],
      planInfo: {
        isSupportOnlyPlan: false,
      },
      subscriptionItems: {
        availableItems: [],
        supportItems: [],
        mainItem: undefined,
        supportItem: undefined,
      },
    } as any);
    jest.spyOn(subscriptionValidateUtility, 'validateUpdateActive').mockReturnValue({ isDowngrade: false });
    jest.spyOn(subscriptionGetUtility, 'getSubscriptionByIdForCustomer').mockReturnValueOnce('Test' as any);
    Subscription.updateOrRenew(updateParams);
  });

  it('renewSamePlan', () => {
    const subsToUpdate = {
      frequency: 'MONTHLY',
      items: [
        {
          code: 'TES-SA-IT1-STA',
          quantity: 43,
        },
        {
          code: 'TES-SA-IT2-SIL',
          quantity: 11,
        },
      ],
      planCode: 'test',
      planId: 1,
      duration: 15,
    };

    const updateParams = {
      productFamilyCode: 'TES',
      productVariantCode: 'SA',
      customerId: 'TestCustomerId',
      subscriptionId: 123,
      content: subsToUpdate,
    };
    (subscriptionPlanUtility.getSubscriptionPlanById as any).mockReturnValue({
      items: [
        {
          code: 'TES-SA-IT1-STA',
          id: 321,
          required: true,
          productTier: ProductTier.Standard,
          prices: [
            {
              currency: 'USD',
              frequency: 'MONTHLY',
              ranges: [{ fromQuantity: 0, price: 1, type: 'Volume' }],
              type: undefined,
            },
          ],
        },
        {
          code: 'TES-SA-IT2-SIL',
          id: 322,
          supportLevel: SupportLevel.Silver,
          prices: [
            {
              currency: 'USD',
              frequency: 'MONTHLY',
              ranges: [{ fromQuantity: 0, price: 1, type: 'Volume' }],
              type: undefined,
            },
          ],
        },
      ],
      supportLevel: SupportLevel.Silver,
      productTier: ProductTier.Standard,
      revenueType: 'Saas',
      mainItemCode: 'TES-SA-IT1-STA',
      supportItemCode: 'TES-SA-IT2-SIL',
      supportOnly: false,
    });
    jest.spyOn(customerDao, 'findCustomerAndBa').mockReturnValueOnce({ customerId: 'TestCustomer' });
    (subscriptionDao.findItemCodes as any).mockReturnValueOnce([
      { code: 'TES-SA-IT1-STA', id: 321 },
      { code: 'TES-SA-IT2-SIL', id: 322 },
    ]);
    (subscriptionItemUtility.findItemCodes as any).mockReturnValueOnce([
      { code: 'TES-SA-IT1-STA', id: 321, status: 'DRAFT' },
      { code: 'TES-SA-IT2-SIL', id: 322, status: 'NOT_INCLUDED' },
    ]);
    jest
      .spyOn(ProductIntegration, 'findProductIntegration')
      .mockReturnValueOnce({ nsClass: { id: 1, name: 'USD', fullname: 'Dollar' }, isUptickEnabled: true });
    jest.spyOn(subscriptionPlanUtility, 'isCurrentPlanChange').mockReturnValueOnce(false);
    jest.spyOn(subscriptionValidateUtility, 'validateAndPrepareUpdateData').mockImplementation((params: any) => {
      params.content.planClass = 1;
    });
    jest.spyOn(subscriptionValidateUtility, 'isDowngrade').mockReturnValueOnce(false);
    jest.spyOn(subscriptionPriceUtility, 'applyModifiedPrices').mockImplementation(() => '');
    jest.spyOn(subscriptionPlanUtility, 'getSubscriptionPlans').mockReturnValue([
      {
        initialterm: {
          duration: 1,
          unit: 'YEARS',
        },
        items: [
          {
            code: 'TES-SA-IT1-STA',
            id: 321,
            prices: [
              {
                currency: 'USD',
                frequency: 'MONTHLY',
                ranges: [{ fromQuantity: 0, price: 1, type: 'Volume' }],
                type: undefined,
              },
            ],
          },
          {
            code: 'TES-SA-IT2-SIL',
            id: 322,
            prices: [
              {
                currency: 'USD',
                frequency: 'MONTHLY',
                ranges: [{ fromQuantity: 0, price: 1, type: 'Volume' }],
                type: undefined,
              },
            ],
          },
        ],
      },
    ] as any);
    jest
      .spyOn(subscriptionGetUtility, 'getSubscriptionByIdInternal')
      .mockReturnValue({ status: 'DRAFT', plan: { id: 1 }, parentSubscription: 1 } as any);
    const testSubscriptionRecord = {
      fields: {
        customer: '123',
        billingsubscriptionstatus: 'DRAFT',
      },
      sublists: {
        priceinterval: {},
        subscriptionline: {},
      },
      getLineCount: () => {
        return 1;
      },
      setValue: () => {},
      save: () => {},
      selectLine: () => {},
      getCurrentSublistValue: (p) => {
        return p.fieldId === 'item' ? '321' : {};
      },
      getValue: (p) => {
        switch (p) {
          case 'id':
          case 'subsidiary':
            return 1;
          default:
            return 'DRAFT';
        }
      },
      setCurrentSublistValue: () => {},
      commitLine: () => {},
    };

    jest.spyOn(record, 'load').mockReturnValue(testSubscriptionRecord as any); // one for load to update and one for load to serialize
    jest.spyOn(subscriptionGetUtility, 'getSubscriptionByIdForCustomer').mockReturnValue({ id: 1 } as any);
    jest.spyOn(record, 'create').mockReturnValue(testSubscriptionRecord as any);
    jest.spyOn(subscriptionValidateUtility, 'validateSubscriptionItems').mockImplementation(() => {});
    jest.spyOn(subscriptionGetUtility, 'getSubscriptionRecItems').mockReturnValue({
      planId: 1,
      planItems: [],
      planInfo: {
        isSupportOnlyPlan: false,
      },
      subscriptionItems: {
        availableItems: [],
        supportItems: [],
        mainItem: undefined,
        supportItem: undefined,
      },
    } as any);
    jest.spyOn(subscriptionValidateUtility, 'validateUpdateActive').mockReturnValue({ isDowngrade: false });
    Subscription.updateOrRenew(updateParams);
  });

  it('renewDifferentPlan', () => {
    const subsToUpdate = {
      frequency: 'MONTHLY',
      items: [
        {
          code: 'TES-SA-IT1-STA',
          quantity: 43,
        },
        {
          code: 'TES-SA-IT2-SIL',
          quantity: 11,
        },
      ],
      planCode: 'test',
      planId: 1,
    };

    const updateParams = {
      productFamilyCode: 'TES',
      productVariantCode: 'SA',
      customerId: 'TestCustomerId',
      subscriptionId: 123,
      content: subsToUpdate,
    };
    (subscriptionPlanUtility.getSubscriptionPlanById as any).mockReturnValue({
      items: [
        {
          code: 'TES-SA-IT1-STA',
          id: 321,
          required: true,
          productTier: ProductTier.Standard,
          prices: [
            {
              currency: 'USD',
              frequency: 'MONTHLY',
              ranges: [{ fromQuantity: 0, price: 1, type: 'Volume' }],
              type: undefined,
            },
          ],
        },
        {
          code: 'TES-SA-IT2-SIL',
          id: 322,
          supportLevel: SupportLevel.Silver,
          prices: [
            {
              currency: 'USD',
              frequency: 'MONTHLY',
              ranges: [{ fromQuantity: 0, price: 1, type: 'Volume' }],
              type: undefined,
            },
          ],
        },
      ],
      supportLevel: SupportLevel.Silver,
      productTier: ProductTier.Standard,
      revenueType: 'Saas',
      mainItemCode: 'TES-SA-IT1-STA',
      supportItemCode: 'TES-SA-IT2-SIL',
      supportOnly: false,
    });
    jest.spyOn(customerDao, 'findCustomerAndBa').mockReturnValue({ customerId: 'TestCustomer' });
    (subscriptionDao.findItemCodes as any).mockReturnValueOnce([{ code: 'TES-SA-IT1-STA', id: 321 }]);
    (subscriptionItemUtility.findItemCodes as any).mockReturnValueOnce([
      { code: 'TES-SA-IT1-STA', id: 321, status: 'DRAFT' },
      { code: 'TES-SA-IT2-SIL', id: 322, status: 'NOT_INCLUDED' },
    ]);
    jest.spyOn(subscriptionPlanUtility, 'isCurrentPlanChange').mockReturnValueOnce(true);
    jest.spyOn(subscriptionValidateUtility, 'validateAndPrepareUpdateData').mockImplementation((params: any) => {
      params.content.planClass = 1;
    });
    jest
      .spyOn(ProductIntegration, 'findProductIntegration')
      .mockReturnValueOnce({ nsClass: { id: 1, name: 'USD', fullname: 'Dollar' }, isUptickEnabled: true });
    jest.spyOn(subscriptionValidateUtility, 'isDowngrade').mockReturnValueOnce(true);
    jest.spyOn(subscriptionPriceUtility, 'applyModifiedPrices').mockImplementation(() => '');
    jest
      .spyOn(subscriptionGetUtility, 'getSubscriptionByIdInternal')
      .mockReturnValue({ id: 1, status: 'DRAFT', plan: { id: 1 }, parentSubscription: 1 } as any);
    const testRecord = {
      fields: {
        customer: '123',
        billingsubscriptionstatus: 'DRAFT',
      },
      sublists: {
        priceinterval: {},
        subscriptionline: {},
      },
      getLineCount: () => {
        return 1;
      },
      setValue: () => {},
      save: () => {},
      selectLine: () => {},
      getCurrentSublistValue: (p) => {
        return p.fieldId === 'item' ? '321' : {};
      },
      getValue: (p) => {
        if (typeof p !== 'string') p = p.fieldId;
        switch (p) {
          case 'billingsubscriptionstatus':
            return 'DRAFT';
          case 'startdate': {
            const threeDaysAhead = new Date();
            threeDaysAhead.setUTCHours(72, 0, 0, 0);
            return threeDaysAhead;
          }
          default:
            return 'string';
        }
      },
      setCurrentSublistValue: () => {},
      commitLine: () => {},
      getSublistValue: () => '1',
      getCurrentSublistText: () => '1',
    };

    (record.create as any).mockReturnValue(testRecord);
    jest.spyOn(record, 'load').mockReturnValue(testRecord as any);
    jest.spyOn(subscriptionGetUtility, 'getSubscriptionByIdForCustomer').mockReturnValue({ id: 1 } as any);
    jest.spyOn(record, 'create').mockReturnValue(testRecord as any);
    jest.spyOn(subscriptionValidateUtility, 'validateSubscriptionItems').mockImplementation(() => {});
    jest.spyOn(subscriptionGetUtility, 'getSubscriptionRecItems').mockReturnValue({
      planId: 1,
      planItems: [],
      planInfo: {
        isSupportOnlyPlan: false,
      },
      subscriptionItems: {
        availableItems: [],
        supportItems: [],
        mainItem: undefined,
        supportItem: undefined,
      },
    } as any);
    jest.spyOn(subscriptionValidateUtility, 'validateUpdateActive').mockReturnValue({ isDowngrade: false });
    Subscription.updateOrRenew(updateParams);
  });

  it('renewDifferentPlan same subsidiary', () => {
    const subsToUpdate = {
      frequency: 'MONTHLY',
      items: [
        {
          code: 'TES-SA-IT1-STA',
          quantity: 43,
        },
        {
          code: 'TES-SA-IT2-SIL',
          quantity: 11,
        },
      ],
      planCode: 'test',
      planId: 1,
    };

    const updateParams = {
      productFamilyCode: 'TES',
      productVariantCode: 'SA',
      customerId: 'TestCustomerId',
      subscriptionId: 123,
      content: subsToUpdate,
    };
    (subscriptionPlanUtility.getSubscriptionPlanById as any).mockReturnValue({
      items: [
        {
          code: 'TES-SA-IT1-STA',
          id: 321,
          required: true,
          productTier: ProductTier.Standard,
          prices: [
            {
              currency: 'USD',
              frequency: 'MONTHLY',
              ranges: [{ fromQuantity: 0, price: 1, type: 'Volume' }],
              type: undefined,
            },
          ],
        },
        {
          code: 'TES-SA-IT2-SIL',
          id: 322,
          supportLevel: SupportLevel.Silver,
          prices: [
            {
              currency: 'USD',
              frequency: 'MONTHLY',
              ranges: [{ fromQuantity: 0, price: 1, type: 'Volume' }],
              type: undefined,
            },
          ],
        },
      ],
      supportLevel: SupportLevel.Silver,
      productTier: ProductTier.Standard,
      revenueType: 'Saas',
      mainItemCode: 'TES-SA-IT1-STA',
      supportItemCode: 'TES-SA-IT2-SIL',
      supportOnly: false,
    });
    jest.spyOn(customerDao, 'findCustomerAndBa').mockReturnValue({ customerId: 'TestCustomer' });
    (subscriptionDao.findItemCodes as any).mockReturnValueOnce([{ code: 'TES-SA-IT1-STA', id: 321 }]);
    (subscriptionItemUtility.findItemCodes as any).mockReturnValueOnce([
      { code: 'TES-SA-IT1-STA', id: 321, status: 'DRAFT' },
      { code: 'TES-SA-IT2-SIL', id: 322, status: 'NOT_INCLUDED' },
    ]);
    jest.spyOn(subscriptionPlanUtility, 'isCurrentPlanChange').mockReturnValueOnce(true);
    jest.spyOn(subscriptionValidateUtility, 'validateAndPrepareUpdateData').mockImplementation((params: any) => {
      params.content.planClass = 1;
    });
    jest
      .spyOn(ProductIntegration, 'findProductIntegration')
      .mockReturnValueOnce({ nsClass: { id: 1, name: 'USD', fullname: 'Dollar' }, isUptickEnabled: true });
    jest.spyOn(subscriptionValidateUtility, 'isDowngrade').mockReturnValueOnce(true);
    jest.spyOn(subscriptionPriceUtility, 'applyModifiedPrices').mockImplementation(() => '');
    jest
      .spyOn(subscriptionGetUtility, 'getSubscriptionByIdInternal')
      .mockReturnValue({ id: 1, status: 'DRAFT', plan: { id: 1 }, parentSubscription: 1 } as any);
    const testRecord = {
      fields: {
        customer: '123',
        billingsubscriptionstatus: 'DRAFT',
      },
      sublists: {
        priceinterval: {},
        subscriptionline: {},
      },
      getLineCount: () => {
        return 1;
      },
      setValue: () => {},
      save: () => {},
      selectLine: () => {},
      getCurrentSublistValue: (p) => {
        return p.fieldId === 'item' ? '321' : {};
      },
      getValue: (p) => {
        if (typeof p !== 'string') p = p.fieldId;
        switch (p) {
          case 'billingsubscriptionstatus':
            return 'DRAFT';
          case 'startdate': {
            const threeDaysAhead = new Date();
            threeDaysAhead.setUTCHours(72, 0, 0, 0);
            return threeDaysAhead;
          }
          case 'subsidiary':
            return 1;
          default:
            return 'string';
        }
      },
      setCurrentSublistValue: () => {},
      commitLine: () => {},
      getSublistValue: () => '1',
      getCurrentSublistText: () => '1',
    };

    (record.create as any).mockReturnValue(testRecord);
    jest.spyOn(record, 'load').mockReturnValue(testRecord as any);
    jest.spyOn(subscriptionGetUtility, 'getSubscriptionByIdForCustomer').mockReturnValue({ id: 1 } as any);
    jest.spyOn(record, 'create').mockReturnValue(testRecord as any);
    jest.spyOn(subscriptionValidateUtility, 'validateSubscriptionItems').mockImplementation(() => {});
    jest.spyOn(subscriptionGetUtility, 'getSubscriptionRecItems').mockReturnValue({
      planId: 1,
      planItems: [],
      planInfo: {
        isSupportOnlyPlan: false,
      },
      subscriptionItems: {
        availableItems: [],
        supportItems: [],
        mainItem: undefined,
        supportItem: undefined,
      },
    } as any);
    jest.spyOn(subscriptionValidateUtility, 'validateUpdateActive').mockReturnValue({ isDowngrade: false });
    Subscription.updateOrRenew(updateParams);
  });

  it('isCurrentPlanChange true', () => {
    jest.spyOn(nsutils, 'queryFirstToJson').mockReturnValueOnce({ code: 'TES-SA-IT1-STA-001', frequency: 'MONTHLY' });
    const subsToUpdate = {
      subscriptionId: 123,
      content: {
        frequency: 'MONTHLY',
        items: [
          {
            code: 'TES-SA-IT1-STA',
            quantity: 43,
          },
          {
            code: 'TES-SA-IT2-SIL',
            quantity: 11,
          },
        ],
        planCode: 'test',
      },
    };

    const res = subscriptionPlanUtility.isCurrentPlanChange(subsToUpdate);
    expect(res).toBe(true);
  });

  it('isCurrentPlanChange false', () => {
    jest.spyOn(nsutils, 'queryFirstToJson').mockReturnValueOnce({ code: 'test', frequency: 'MONTHLY' });
    const subsToUpdate = {
      subscriptionId: 123,
      content: {
        frequency: 'MONTHLY',
        items: [
          {
            code: 'TES-SA-IT1-STA',
            quantity: 43,
          },
          {
            code: 'TES-SA-IT2-SIL',
            quantity: 11,
          },
        ],
        planCode: 'test',
      },
    };

    const res = subscriptionPlanUtility.isCurrentPlanChange(subsToUpdate);
    expect(res).toBe(false);
  });

  it('isCurrentPlanChange no plan', () => {
    jest.spyOn(nsutils, 'queryFirstToJson').mockReturnValueOnce(null);
    const subsToUpdate = {
      subscriptionId: 123,
      content: {
        frequency: 'MONTHLY',
        items: [
          {
            code: 'TES-SA-IT1-STA',
            quantity: 43,
          },
          {
            code: 'TES-SA-IT2-SIL',
            quantity: 11,
          },
        ],
        planCode: 'TES-SA-IT1-STA-001',
      },
    };

    const t = () => subscriptionPlanUtility.isCurrentPlanChange(subsToUpdate);
    expect(t).toThrowError('Subscription plan does not exist');
  });

  it('renew removing addon', () => {
    const subsToUpdate = {
      frequency: 'MONTHLY',
      items: [
        {
          code: 'TES-SA-IT1-STA',
          quantity: 43,
        },
        {
          code: 'TES-SA-IT2-SIL',
          quantity: 0,
        },
      ],
      planCode: 'test',
      planId: 1,
    };

    const updateParams = {
      productFamilyCode: 'TES',
      productVariantCode: 'SA',
      customerId: 'TestCustomerId',
      subscriptionId: 123,
      content: subsToUpdate,
    };
    (subscriptionPlanUtility.getSubscriptionPlanById as any).mockReturnValue({
      items: [
        {
          code: 'TES-SA-IT1-STA',
          id: 321,
          required: true,
          productTier: ProductTier.Standard,
          prices: [
            {
              currency: 'USD',
              frequency: 'MONTHLY',
              ranges: [{ fromQuantity: 0, price: 1, type: 'Volume' }],
              type: undefined,
            },
          ],
        },
        {
          code: 'TES-SA-IT2-SIL',
          id: 322,
          supportLevel: SupportLevel.Silver,
          prices: [
            {
              currency: 'USD',
              frequency: 'MONTHLY',
              ranges: [{ fromQuantity: 0, price: 1, type: 'Volume' }],
              type: undefined,
            },
          ],
        },
      ],
      supportLevel: SupportLevel.Silver,
      productTier: ProductTier.Standard,
      revenueType: 'Saas',
      mainItemCode: 'TES-SA-IT1-STA',
      supportItemCode: 'TES-SA-IT2-SIL',
      supportOnly: false,
    });
    jest.spyOn(customerDao, 'findCustomerAndBa').mockReturnValueOnce({ customerId: 'TestCustomer' });
    (subscriptionDao.findItemCodes as any).mockReturnValueOnce([
      { code: 'TES-SA-IT1-STA', id: 321 },
      { code: 'TES-SA-IT2-SIL', id: 322 },
    ]);
    (subscriptionDao.getRenewalHistoryOfSubscription as any).mockReturnValue([]);
    (subscriptionItemUtility.findItemCodes as any).mockReturnValueOnce([
      { code: 'TES-SA-IT1-STA', id: 321, status: 'DRAFT' },
      { code: 'TES-SA-IT2-SIL', id: 322, status: 'DRAFT' },
    ]);
    jest
      .spyOn(ProductIntegration, 'findProductIntegration')
      .mockReturnValueOnce({ nsClass: { id: 1, name: 'USD', fullname: 'Dollar' }, isUptickEnabled: true });
    jest.spyOn(subscriptionPlanUtility, 'isCurrentPlanChange').mockReturnValueOnce(false);
    jest.spyOn(subscriptionValidateUtility, 'validateAndPrepareUpdateData').mockImplementation((params: any) => {
      params.content.planClass = 1;
    });
    jest.spyOn(subscriptionValidateUtility, 'isDowngrade').mockReturnValueOnce(false);
    jest.spyOn(subscriptionPriceUtility, 'applyModifiedPrices').mockImplementation(() => '');
    jest.spyOn(subscriptionGetUtility, 'getSubscriptionByIdInternal').mockReturnValue({
      status: 'DRAFT',
      plan: { id: 1 },
      includedItems: [
        { code: 'TES-SA-IT1-STA', quantity: 1 },
        { code: 'TES-SA-IT2-SIL', quantity: 1 },
      ],
    } as any);
    const testSubscriptionRecord = {
      fields: {
        customer: '123',
        billingsubscriptionstatus: 'ACTIVE',
      },
      sublists: {
        priceinterval: {},
        subscriptionline: {},
      },
      getLineCount: () => {
        return 1;
      },
      setValue: () => {},
      save: () => {},
      selectLine: () => {},
      getCurrentSublistValue: (p) => {
        return p.fieldId === 'item' ? '322' : {};
      },
      getCurrentSublistText: () => {
        return 'Recurring';
      },
      getValue: () => {
        return 'DRAFT';
      },
      setCurrentSublistValue: () => {},
      commitLine: () => {},
    };

    jest.spyOn(record, 'load').mockReturnValue(testSubscriptionRecord as any);
    jest.spyOn(record, 'create').mockReturnValue(testSubscriptionRecord as any);
    jest.spyOn(subscriptionGetUtility, 'getSubscriptionByIdForCustomer').mockReturnValueOnce('Test' as any);
    jest.spyOn(subscriptionValidateUtility, 'validateSubscriptionItems').mockImplementation(() => {});
    jest.spyOn(subscriptionGetUtility, 'getSubscriptionRecItems').mockReturnValue({
      planId: 1,
      planItems: [],
      planInfo: {
        isSupportOnlyPlan: false,
      },
      subscriptionItems: {
        availableItems: [],
        supportItems: [],
        mainItem: undefined,
        supportItem: undefined,
      },
    } as any);
    jest.spyOn(subscriptionValidateUtility, 'validateUpdateActive').mockReturnValue({ isDowngrade: false });
    const res = Subscription.updateOrRenew(updateParams);
    expect(res).toStrictEqual(expect.anything());
  });

  it('invalidUpdate', () => {
    const subsToUpdate = {
      frequency: 'MONTHLY',
      items: [
        {
          code: 'TES-SA-IT1-STA',
          quantity: 43,
        },
        {
          code: 'TES-SA-IT2-SIL',
          quantity: 11,
        },
      ],
      planCode: 'test',
    };

    const updateParams = {
      productFamilyCode: 'TES',
      productVariantCode: 'SA',
      customerId: 'TestCustomerId',
      subscriptionId: 123,
      content: subsToUpdate,
    };

    const testSubscriptionRecord = {
      fields: {
        customer: '123',
        billingsubscriptionstatus: 'PENDING_ACTIVATION',
      },
      sublists: {
        priceinterval: {},
        subscriptionline: {},
      },
      getLineCount: () => {
        return 1;
      },
      setValue: () => {},
      save: () => {},
      selectLine: () => {},
      getCurrentSublistValue: (p) => {
        return p.fieldId === 'item' ? '321' : {};
      },
      status: () => SubscriptionStatus.PENDING_ACTIVATION,
      getValue: () => {
        return 'PENDING_ACTIVATION';
      },
      setCurrentSublistValue: () => {},
      commitLine: () => {},
    };

    jest.spyOn(subscriptionValidateUtility, 'validateAndPrepareUpdateData').mockImplementation((params: any) => {
      params.content.planClass = 1;
      params.content.planId = 1;
    });
    jest.spyOn(subscriptionValidateUtility, 'validateAndPrepareCreateData').mockImplementation(() => {});

    jest.spyOn(subscriptionGetUtility, 'getSubscriptionByIdInternal').mockReturnValue({
      status: 'PENDING_ACTIVATION',
      plan: { id: 1 },
      items: [],
      includedItems: [
        { code: 'TES-SA-IT1-STA', quantity: 1 },
        { code: 'TES-SA-IT2-SIL', quantity: 1 },
      ],
    } as any);
    jest.spyOn(record, 'load').mockReturnValue(testSubscriptionRecord as any);
    jest.spyOn(subscriptionGetUtility, 'getSubscriptionRecItems').mockReturnValue({
      planId: 1,
      planItems: subsToUpdate.items,
      planInfo: {
        isSupportOnlyPlan: false,
      },
      subscriptionItems: {
        availableItems: [],
        supportItems: [],
        mainItem: undefined,
        supportItem: undefined,
      },
    } as any);
    jest.spyOn(subscriptionValidateUtility, 'validateUpdateActive').mockReturnValue({ isDowngrade: false });
    jest
      .spyOn(nsutils, 'queryToJson')
      .mockReturnValue([{ code: 'TES-SA-IT2-SIL' }, { code: 'TES-SA-IT1-STA', isrequired: 'T', supportlevel: null }]);
    expect(() => {
      Subscription.updateOrRenew(updateParams);
    }).toThrowError('Not possible to use this method in subscription with status PENDING_ACTIVATION');
  });

  it('invalidCustomer', () => {
    const subsToUpdate = {
      frequency: 'MONTHLY',
      items: [
        {
          code: 'TES-SA-IT1-STA',
          quantity: 43,
        },
        {
          code: 'TES-SA-IT2-SIL',
          quantity: 11,
        },
      ],
      planCode: 'test',
    };

    const updateParams = {
      productFamilyCode: 'TES',
      productVariantCode: 'SA',
      customerId: 'TestCustomerId',
      subscriptionId: 123,
      content: subsToUpdate,
    };

    jest.spyOn(nsutils, 'queryFirstToJson').mockReturnValueOnce({ id: 'TestAnotherCustomerId' });
    jest
      .spyOn(subscriptionGetUtility, 'getSubscriptionByIdInternal')
      .mockReturnValue({ status: 'ACTIVE', plan: { id: 1 } } as any);
    expect(() => {
      Subscription.updateOrRenew(updateParams);
    }).toThrowError('Subscription does not exist or is from another customer');
  });

  it('invalidItems', () => {
    const subsToUpdate = {
      frequency: 'MONTHLY',
      items: [
        {
          code: 'TES-SA-IT1-STA',
          quantity: 43,
        },
      ],
      planCode: 'test',
    };

    const updateParams = {
      productFamilyCode: 'TES',
      productVariantCode: 'SA',
      customerId: 'TestCustomerId',
      subscriptionId: 123,
      content: subsToUpdate,
    };

    jest.spyOn(subscriptionGetUtility, 'checkSubscriptionCustomer').mockReturnValueOnce({ entityid: 1, subsidiary: 1 });
    jest.spyOn(nsutils, 'queryToJson').mockReturnValueOnce([{ code: 'test' }]);
    jest
      .spyOn(subscriptionGetUtility, 'getSubscriptionByIdInternal')
      .mockReturnValue({ status: 'ACTIVE', plan: { id: 1 } } as any);
    jest.spyOn(record, 'load').mockReturnValue({
      id: 1,
      sublists: { priceinterval: [], subscriptionline: [] },
      fields: { subscriptionplan: 1, billingsubscriptionstatus: 'ACTIVE', customer: 1 },
      getValue: () => {
        return 'ACTIVE';
      },
      getSublistValue: () => 1,
    } as any);
    expect(() => {
      Subscription.updateOrRenew(updateParams);
    }).toThrowError('Cannot find item with code TES-SA-IT1-STA in plan');
  });

  it('requiredItemNotInformed', () => {
    const subsToUpdate = {
      frequency: 'MONTHLY',
      items: [
        {
          code: 'TES-SA-IT1-STA',
          quantity: 43,
        },
      ],
      planCode: 'test',
    };

    const updateParams = {
      productFamilyCode: 'TES',
      productVariantCode: 'SA',
      customerId: 'TestCustomerId',
      subscriptionId: 123,
      content: subsToUpdate,
    };

    jest.spyOn(subscriptionGetUtility, 'checkSubscriptionCustomer').mockReturnValueOnce({ entityid: 1, subsidiary: 1 });
    jest
      .spyOn(nsutils, 'queryToJson')
      .mockReturnValue([{ code: 'TES-SA-IT1-STA' }, { code: 'test', isrequired: 'T', supportlevel: null }]);
    jest
      .spyOn(subscriptionGetUtility, 'getSubscriptionByIdInternal')
      .mockReturnValue({ status: 'ACTIVE', plan: { id: 1 } } as any);
    jest.spyOn(record, 'load').mockReturnValue({
      id: 1,
      sublists: { priceinterval: [], subscriptionline: [] },
      fields: { subscriptionplan: 1 },
      getValue: () => {
        return 'ACTIVE';
      },
      getSublistValue: () => 1,
    } as any);
    jest.spyOn(subscriptionGetUtility, 'getSubscriptionRecItems').mockReturnValue({
      planId: 1,
      planItems: subsToUpdate.items,
      planInfo: {
        isSupportOnlyPlan: false,
      },
      subscriptionItems: {
        availableItems: [],
        supportItems: [],
        mainItem: undefined,
        supportItem: undefined,
      },
    } as any);
    jest.spyOn(subscriptionValidateUtility, 'validateUpdateActive').mockReturnValue({ isDowngrade: false });

    expect(() => {
      Subscription.updateOrRenew(updateParams);
    }).toThrowError('Required item test is not present');
  });

  it('emptyItems', () => {
    const subsToUpdate = {
      frequency: 'MONTHLY',
      items: [],
      planCode: 'test',
    };

    const updateParams = {
      productFamilyCode: 'TES',
      productVariantCode: 'SA',
      customerId: 'TestCustomerId',
      subscriptionId: 123,
      content: subsToUpdate,
    };

    jest.spyOn(subscriptionGetUtility, 'checkSubscriptionCustomer').mockReturnValueOnce({ entityid: 1, subsidiary: 1 });
    jest
      .spyOn(subscriptionGetUtility, 'getSubscriptionByIdInternal')
      .mockReturnValue({ status: 'ACTIVE', plan: { id: 1 } } as any);

    jest.spyOn(record, 'load').mockReturnValue({
      id: 1,
      sublists: { priceinterval: [], subscriptionline: [] },
      fields: { subscriptionplan: 1, billingsubscriptionstatus: 'ACTIVE', customer: 1 },
      getValue: () => {
        return 'ACTIVE';
      },
      getSublistValue: () => 1,
    } as any);

    expect(() => {
      Subscription.updateOrRenew(updateParams);
    }).toThrowError('Subscription items must be informed');
  });

  it('convertLinesToArray', () => {
    const res = exposePrivate(subscriptionGetUtility).convertLinesToArray({
      'line 1': { linenumber: 1 },
      'line 2': { linenumber: 2 },
      'line 3': { linenumber: 3 },
    });

    expect(res).toStrictEqual([{ linenumber: 1 }, { linenumber: 2 }, { linenumber: 3 }]);
  });

  it('convertPrices', () => {
    const res = exposePrivate(subscriptionGetUtility).convertPrices({ frequency: 'monthly' }, [
      { fromquantity: 0, price: 1, pricetype: 'volume', pricingoption: -101 },
      { fromquantity: 5, price: 10, pricetype: 'volume', pricingoption: -102 },
    ]);
    expect(res).toStrictEqual({
      type: 'volume',
      frequency: 'monthly',
      pricebookid: undefined,
      ranges: [
        { priceplanid: undefined, fromQuantity: 0, price: 1, type: 'Rate' },
        { priceplanid: undefined, fromQuantity: 5, price: 10, type: 'FixedAmount' },
      ],
    });
  });

  it('convertPrices should return discounted prices when a discount is defined', () => {
    // Arrange
    const line = { discount: "10.00%", frequency: 'ANNUALLY' };
    const lineFields = [
      { priceplanid: 201, pricetype: 'Volume', fromquantity: 0, price: 100, pricingoption: -101 },
      { priceplanid: 202, pricetype: 'Volume', fromquantity: 500, price: 80, pricingoption: -101 },
    ];
    const pricebookid = 101;

    // Act
    const result = subscriptionGetUtility['convertPrices'](line, lineFields, pricebookid);

    // Assert
    expect(result).toStrictEqual({
      type: 'Volume',
      frequency: 'ANNUALLY',
      pricebookid: 101,
      ranges: [
        { priceplanid: 201, fromQuantity: 0, price: 90, type: 'Rate' },
        { priceplanid: 202, fromQuantity: 500, price: 72, type: 'Rate' },
      ],
    });
  });

  it('buildItems-', () => {
    (nsutils.queryToJson as any).mockReturnValue([
      { key: 2, name: 'Recurring' },
      { key: 3, name: 'Usage' },
    ]);
    jest.spyOn(subscriptionDao, 'findPricesAndItemFields').mockReturnValueOnce([
      {
        id: 42,
        code: 'SOT-SA-BA-BAS',
        description: 'TestDescription',
        type: 'testType',
      },
    ]);
    jest.spyOn(subscriptionDao, 'findPricesAndItemFields').mockReturnValueOnce([
      {
        id: 43,
        code: 'SOT-SA-BA-SIL',
        support_level_name: 'Silver',
        description: 'TestDescription',
        type: 'testType',
      },
    ]);
    jest.spyOn(subscriptionDao, 'findPricesAndItemFields').mockReturnValueOnce([
      {
        id: 44,
        code: 'SOT-SA-USG-USG',
        description: 'TestDescription',
        type: 'testType',
      },
    ]);
    const subscriptionPlan = {
      supportLevel: SupportLevel.Silver,
      productTier: ProductTier.Standard,
      revenueType: 'Saas',
      mainItemCode: 'SOT-SA-BA-BAS',
      supportItemCode: 'SOT-SA-BA-SIL',
      supportOnly: false,
      isLegacyPlan: false,
      code: 'SOT-SA-BA-BAS-SIL-001',
      name: 'Some Plan Name',
      initialterm: {
        duration: 1,
        unit: 'YEARS',
      } as any,
      items: [
        {
          code: 'SOT-SA-BA-BAS',
          id: 42,
          required: true,
          productTier: ProductTier.Standard,
          isMainItem: true,
          isSupportMainItem: false,
          isSupportAddonItem: false,
        } as any,
        {
          code: 'SOT-SA-BA-SIL',
          id: 43,
          supportLevel: SupportLevel.Silver,
          isMainItem: false,
          isSupportMainItem: true,
          isSupportAddonItem: false,
        } as any,
        {
          code: 'SOT-SA-USG-USG',
          id: 44,
          isMainItem: false,
          isSupportMainItem: false,
          isSupportAddonItem: false,
        } as any,
      ],
    };
    const res = subscriptionGetUtility.buildItems(
      {
        fields: {
          billingsubscriptionstatus: 'ACTIVE',
          customer: '123',
        },
        sublists: {
          priceinterval: {
            'line 1': { linenumber: 1, item: '42', recurringamount: 1, quantity: '1', status: 'ACTIVE', totalintervalvalue: 1 },
            'line 2': { linenumber: 2, item: '43', recurringamount: 2, quantity: '1', status: 'ACTIVE', totalintervalvalue: 2 },
            'line 3': { linenumber: 3, item: '44', quantity: '1', status: 'ACTIVE', totalintervalvalue: 3, recurringamount: 3 },
            'line 4': { linenumber: 4, item: '44', quantity: '1', status: 'NOT_INCLUDED', totalintervalvalue: 3, recurringamount: 3 },
          },
          subscriptionline: {
            'line 1': {
              linenumber: 1,
              item: '42',
              isincluded: 'T',
              isrequired: 'T',
              status: 'ACTIVE',
              quantity: '2',
              subscriptionlinetype: 2,
            },
            'line 2': {
              linenumber: 2,
              item: '43',
              isincluded: 'F',
              supportlevelid: 22,
              quantity: '2',
              isrequired: 'T',
              status: 'ACTIVE',
            },
            'line 3': {
              linenumber: 3,
              item: '44',
              isincluded: 'T',
              isrequired: 'F',
              quantity: '2',
              status: 'ACTIVE',
              subscriptionlinetype: 3,
            },
            'line 4': {
              linenumber: 4,
              item: '44',
              isincluded: 'F',
              isrequired: 'F',
              quantity: '2',
              status: 'NOT_INCLUDED'
            },
          },
        },
      },
      subscriptionPlan as any
    );

    expect(res).toEqual({
      subscriptionItems: {
        availableItems: [
          {
            id: 42,
            code: 'SOT-SA-BA-BAS',
            type: 'Recurring',
            typeId: 2,
            desc: 'TestDescription',
            minQuantity: NaN,
            maxQuantity: NaN,
            required: true,
            prices: [
              {
                frequency: undefined,
                pricebookid: NaN,
                ranges: [
                  {
                    fromQuantity: undefined,
                    price: NaN,
                    priceplanid: undefined,
                    type: undefined,
                  },
                ],
                type: undefined,
              },
            ],
            amount: 1,
            productTier: 'Standard',
            isMainItem: true,
            isSupportMainItem: false,
            isSupportAddonItem: false,
            supportLevel: undefined,
            title: undefined,
            frequency: undefined,
            quantity: 1,
            recuringAmount: 1,
            repeatEvery: NaN,
            totalIntervalValue: 1,
          },
          {
            id: 44,
            code: 'SOT-SA-USG-USG',
            type: 'Usage',
            typeId: 3,
            desc: 'TestDescription',
            minQuantity: NaN,
            maxQuantity: NaN,
            productTier: undefined,
            required: false,
            supportLevel: undefined,
            title: undefined,
            prices: [
              {
                frequency: undefined,
                pricebookid: NaN,
                ranges: [
                  {
                    fromQuantity: undefined,
                    price: NaN,
                    priceplanid: undefined,
                    type: undefined,
                  },
                ],
                type: undefined,
              },
            ],
            amount: 3,
            isMainItem: false,
            isSupportMainItem: false,
            isSupportAddonItem: false,
            frequency: undefined,
            quantity: 0,
            recuringAmount: 3,
            repeatEvery: NaN,
            totalIntervalValue: 3,
          },
        ],
        supportItems: [
          {
            id: 43,
            code: 'SOT-SA-BA-SIL',
            type: 'Recurring',
            desc: 'TestDescription',
            minQuantity: NaN,
            maxQuantity: NaN,
            required: true,
            prices: [
              {
                frequency: undefined,
                pricebookid: NaN,
                type: undefined,
                ranges: [
                  {
                    fromQuantity: undefined,
                    price: NaN,
                    priceplanid: undefined,
                    type: undefined,
                  },
                ],
              },
            ],
            amount: 0,
            productTier: undefined,
            title: undefined,
            typeId: undefined,
            supportLevel: 'Silver',
            isMainItem: false,
            isSupportMainItem: true,
            isSupportAddonItem: false,
            frequency: undefined,
            quantity: 1,
            recuringAmount: 2,
            repeatEvery: NaN,
            totalIntervalValue: 2,
          },
        ],
        mainItem: {
          item: {
            id: 42,
            code: 'SOT-SA-BA-BAS',
            type: 'Recurring',
            typeId: 2,
            desc: 'TestDescription',
            minQuantity: NaN,
            maxQuantity: NaN,
            required: true,
            prices: [
              {
                frequency: undefined,
                pricebookid: NaN,
                ranges: [
                  {
                    fromQuantity: undefined,
                    price: NaN,
                    priceplanid: undefined,
                    type: undefined,
                  },
                ],
                type: undefined,
              },
            ],
            amount: 1,
            productTier: 'Standard',
            isMainItem: true,
            isSupportMainItem: false,
            isSupportAddonItem: false,
            supportLevel: undefined,
            title: undefined,
            quantity: 1,
            frequency: undefined,
            recuringAmount: 1,
            repeatEvery: NaN,
            totalIntervalValue: 1,
          },
          quantity: 1,
          isIncluded: true,
        },
        supportItem: {
          item: {
            id: 43,
            code: 'SOT-SA-BA-SIL',
            type: 'Recurring',
            desc: 'TestDescription',
            minQuantity: NaN,
            maxQuantity: NaN,
            required: true,
            prices: [
              {
                frequency: undefined,
                pricebookid: NaN,
                ranges: [
                  {
                    fromQuantity: undefined,
                    price: NaN,
                    priceplanid: undefined,
                    type: undefined,
                  },
                ],
                type: undefined,
              },
            ],
            amount: 0,
            isMainItem: false,
            isSupportMainItem: true,
            isSupportAddonItem: false,
            supportLevel: 'Silver',
            title: undefined,
            productTier: undefined,
            typeId: undefined,
            quantity: 1,
            frequency: undefined,
            recuringAmount: 2,
            repeatEvery: NaN,
            totalIntervalValue: 2,
          },
          quantity: 1,
          isIncluded: false,
        },
      },
      includedItems: [
        {
          id: 42,
          code: 'SOT-SA-BA-BAS',
          quantity: 1,
        },
        {
          id: 44,
          code: 'SOT-SA-USG-USG',
          quantity: 0,
        },
      ]
    });
  });

  it('buildItems 2', () => {
    (nsutils.queryToJson as any).mockReturnValueOnce([
      { name: 'One Time', key: 1 },
      { name: 'Recurring', key: 2 },
      { name: 'Usage', key: 3 },
      { name: 'Commit Plus Overage', key: 4 },
    ]);
    jest.spyOn(subscriptionDao, 'findPricesAndItemFields').mockReturnValueOnce([
      {
        id: 84628,
        code: 'DNNE-SA-Cus-PRO',
        title: 'DNNE Customer Cloud EVOQ Content',
        description: null,
        pricetype: 'Volume',
        priceplanid: 4830552,
        fromquantity: 0,
        price: 13,
        pricingoption: -101,
        maximumquantity: null,
        minimumquantity: null,
        support_level_name: null,
        product_tier_name: 'Professional',
      },
    ]);
    jest.spyOn(subscriptionDao, 'findPricesAndItemFields').mockReturnValueOnce([
      {
        id: 84629,
        code: 'DNNE-SA-Cus-GOL',
        title: 'DNNE Gold Support',
        description: null,
        pricetype: 'Volume',
        priceplanid: 4830553,
        fromquantity: 0,
        price: 7,
        pricingoption: -101,
        maximumquantity: null,
        minimumquantity: null,
        support_level_name: 'Gold',
        product_tier_name: null,
      },
    ]);

    const subscriptionPlan = {
      productTier: ProductTier.Professional,
      mainItemCode: 'DNNE-SA-Cus-PRO',
      revenueType: 'SaaS',
      supportLevel: SupportLevel.Gold,
      supportItemCode: 'DNNE-SA-Cus-GOL',
      supportOnly: false,
      isLegacyPlan: false,
      code: 'DNNE-SA-Cus-PRO-GOL-001',
      name: 'Some Plan Name',
      initialterm: {
        duration: 1,
        unit: 'YEARS',
      } as any,
      items: [
        {
          id: 84628,
          code: 'DNNE-SA-Cus-PRO',
          title: 'DNNE Customer Cloud EVOQ Content',
          isSupportMainItem: false,
          isSupportAddonItem: false,
          isMainItem: true,
          required: true,
          type: 'Recurring',
          typeId: 2,
          desc: '',
          minQuantity: 0,
          maxQuantity: 999999,
          prices: [
            {
              type: 'Volume',
              frequency: 'ANNUALLY',
              currency: 'USD',
              pricebookid: 10614,
              ranges: [
                {
                  priceplanid: 4612895,
                  type: 'Rate',
                  fromQuantity: 0,
                  price: 20,
                },
              ],
            },
          ],
        },
        {
          id: 84629,
          code: 'DNNE-SA-Cus-GOL',
          title: 'DNNE Gold Support',
          supportLevel: SupportLevel.Gold,
          isSupportMainItem: true,
          isSupportAddonItem: false,
          isMainItem: false,
          required: true,
          type: 'Recurring',
          typeId: 2,
          desc: '',
          minQuantity: 0,
          maxQuantity: 999999,
          prices: [
            {
              type: 'Volume',
              frequency: 'ANNUALLY',
              currency: 'USD',
              pricebookid: 10614,
              ranges: [
                {
                  priceplanid: 4612896,
                  type: 'Rate',
                  fromQuantity: 0,
                  price: 0,
                },
              ],
            },
          ],
        },
      ],
    };
    const subscription = {
      id: '998178',
      type: 'subscription',
      isDynamic: false,
      fields: {
        idnumber: '569547',
        renewalnumber: '0',
        rootsubscription: '998178',
        subscriptionplan: '84643',
        _eml_nkey_: '4914352_SB1~661478~3~N',
        startdate: '29-Mar-2022',
        type: 'subscription',
        nextbillcycledate: '26-Mar-2022',
        frequency: 'ANNUALLY',
        alignchargewithsub: 'T',
        autorenewal: 'T',
        billingsubscriptionstatus: 'DRAFT',
        advancerenewalperiodnumber: '120',
        custrecord_isautorenewal: 'F',
        id: '998178',
        hasfuturedatedactivation: 'F',
        initialterm: '1',
        entryformquerystring: 'e=T&id=998178',
        currencyforba: '1',
        defaultrenewalterm: '1',
        subsidiary: '22',
        enddate: '28-Mar-2023',
        name: 'DNNE Cloud EVOQ CONTENT GOLD - 29-Mar-2022 - 6',
        initialtermduration: '12',
        wfinstances: '',
        initialtermunits: 'MONTHS',
        advancerenewalperiodunit: 'DAYS',
        subscriptionplanname: 'DNNE Cloud EVOQ CONTENT GOLD',
        origidnumber: '569547',
        initialtermtype: 'STANDARD',
        nsapiCT: '1648565411716',
        sys_id: '9192885706758204',
        isextendedtoevergreen: 'F',
        billingaccount: '689808',
        otherrecordnumber: '569547',
        currency: '1',
        subscriptionrevision: '0',
        department: '2',
        class: '863',
        pricebook: '10614',
        templatestored: 'T',
        billingaccountstartdate: '26-Mar-2022',
        defaultrenewalmethod: 'CREATE_NEW_SUBSCRIPTION',
        lastmodifieddate: '29-Mar-2022 9:50 am',
        defaultrenewalplan: '84643',
        billingschedule: '221',
        subsidiaryforba: '22',
        custrecord_subs_end_user: '677591',
        estimatedrevrecenddate: '',
        customform: '141',
        wassubscriptioneveractivated: 'F',
        nextrenewalstartdate: '29-Mar-2023',
        customer: '677591',
      },
      sublists: {
        priceinterval: {
          currentline: {
            catalogtype: 'ADD_ON',
            chargetype: '',
            discount: '',
            frequency: '',
            groupid: '',
            id: '',
            item: '',
            linenumber: '',
            multiplierline: '',
            price: '',
            priceplan: '',
            priceplanbutton: '',
            prorateby: '',
            proratebyoption: '',
            quantity: '',
            recurringamount: '',
            repeatevery: '',
            startdate: '',
            startoffsetunit: 'MONTH',
            startoffsetvalue: '',
            status: '',
            subscriptionplanline: '',
            subscriptionplanlinenumber: '',
            sys_id: '-9192885723718387',
            sys_parentid: '9192885706758204',
            totalintervalvalue: '',
            '#': '3',
          },
          'line 1': {
            catalogtype: 'REQUIRED',
            chargetype: '2',
            discount: null,
            frequency: 'ANNUALLY',
            groupid: '5082016',
            id: '5076969',
            item: '84628',
            item_display: 'DNNE-SA-Cus-PRO',
            linenumber: '1',
            multiplierline: null,
            multiplierline_display: null,
            price: 'From 0: $13.00<br>',
            priceplan: '4830352',
            priceplan_display: '4830352',
            priceplanbutton:
              '<div><a id="pricePlanEdit" href="javascript:billing.subscription.machine.pbli.client.popupPricePlanWindow(null, 2, false)" class="iconpencil"></a></div>',
            prorateby: 'DAY',
            proratebyoption: '1',
            quantity: '5',
            recurringamount: '65.00',
            repeatevery: '1',
            startdate: '29-Mar-2022',
            startoffsetunit: 'MONTH',
            startoffsetvalue: '1',
            status: 'ACTIVE',
            subscriptionplanline: '21630',
            subscriptionplanlinenumber: '1',
            sys_id: '9192885706817806',
            sys_parentid: '9192885706758204',
            totalintervalvalue: '65.00',
          },
          'line 2': {
            catalogtype: 'REQUIRED',
            chargetype: '2',
            discount: null,
            frequency: 'ANNUALLY',
            groupid: '5082017',
            id: '5076970',
            item: '84629',
            item_display: 'DNNE-SA-Cus-GOL',
            linenumber: '2',
            multiplierline: null,
            multiplierline_display: null,
            price: 'From 0: $7.00<br>',
            priceplan: '4830353',
            priceplan_display: '4830353',
            priceplanbutton:
              '<div><a id="pricePlanEdit" href="javascript:billing.subscription.machine.pbli.client.popupPricePlanWindow(null, 2, false)" class="iconpencil"></a></div>',
            prorateby: 'DAY',
            proratebyoption: '1',
            quantity: '5',
            recurringamount: '35.00',
            repeatevery: '1',
            startdate: '29-Mar-2022',
            startoffsetunit: 'MONTH',
            startoffsetvalue: '1',
            status: 'ACTIVE',
            subscriptionplanline: '21629',
            subscriptionplanlinenumber: '2',
            sys_id: '9192885706795128',
            sys_parentid: '9192885706758204',
            totalintervalvalue: '35.00',
          },
        },
        subscriptionline: {
          currentline: {
            billingmode: '',
            catalogtype: 'ADD_ON',
            class: '',
            department: '',
            discount: '',
            enddate: '',
            includeinrenewal: 'F',
            isincluded: 'T',
            isrequired: 'F',
            item: '',
            linenumber: '',
            location: '',
            planitem: '',
            prorateenddate: 'F',
            proratestartdate: 'F',
            quantity: '',
            recurrencestartdate: '',
            revrecoption: '',
            startdate: '',
            status: 'DRAFT',
            subscriptionline: '',
            subscriptionlinetype: '',
            sys_id: '-9192885723626707',
            sys_parentid: '9192885706758204',
            terminationdate: '',
            '#': '3',
          },
          'line 1': {
            billingmode: 'IN_ADVANCE',
            catalogtype: 'REQUIRED',
            class: '863',
            class_display: 'Other : DNNE',
            department: '2',
            department_display: 'Sales',
            discount: '0.00%',
            enddate: '28-Mar-2023',
            includeinrenewal: 'T',
            isincluded: 'T',
            isrequired: 'T',
            item: '84628',
            item_display: 'DNNE-SA-Cus-CON',
            linenumber: '1',
            location: null,
            location_display: null,
            planitem: '21630',
            prorateenddate: 'T',
            proratestartdate: 'T',
            quantity: '5',
            recurrencestartdate: '29-Mar-2022',
            revrecoption: 'OVER_TERM',
            startdate: '29-Mar-2022',
            status: 'ACTIVE',
            subscriptionline: '5169697',
            subscriptionlinetype: '2',
            sys_id: '9192885706857641',
            sys_parentid: '9192885706758204',
            terminationdate: null,
          },
          'line 2': {
            billingmode: 'IN_ADVANCE',
            catalogtype: 'REQUIRED',
            class: '863',
            class_display: 'Other : DNNE',
            department: '2',
            department_display: 'Sales',
            discount: '0.00%',
            enddate: '28-Mar-2023',
            includeinrenewal: 'T',
            isincluded: 'T',
            isrequired: 'T',
            item: '84629',
            item_display: 'DNNE-SA-Cus-GOL',
            linenumber: '2',
            location: null,
            location_display: null,
            planitem: '21629',
            prorateenddate: 'T',
            proratestartdate: 'T',
            quantity: '5',
            recurrencestartdate: '29-Mar-2022',
            revrecoption: 'OVER_TERM',
            startdate: '29-Mar-2022',
            status: 'ACTIVE',
            subscriptionline: '5169696',
            subscriptionlinetype: '2',
            sys_id: '9192885706837258',
            sys_parentid: '9192885706758204',
            terminationdate: null,
          },
        },
      },
    };
    const res = subscriptionGetUtility.buildItems(subscription, subscriptionPlan as any);

    expect(res).toEqual({
      subscriptionItems: {
        availableItems: [
          {
            id: 84628,
            code: 'DNNE-SA-Cus-PRO',
            title: 'DNNE Customer Cloud EVOQ Content',
            type: 'Recurring',
            typeId: 2,
            desc: null,
            minQuantity: NaN,
            maxQuantity: NaN,
            required: true,
            productTier: undefined,
            revenueType: undefined,
            quantity: 5,
            supportLevel: undefined,
            prices: [
              {
                type: 'Volume',
                frequency: 'ANNUALLY',
                pricebookid: 10614,
                ranges: [
                  {
                    priceplanid: 4830552,
                    type: 'Rate',
                    fromQuantity: 0,
                    price: 13,
                  },
                ],
              },
            ],
            amount: 65,
            isMainItem: true,
            isSupportMainItem: false,
            isSupportAddonItem: false,
            frequency: 'Annually',
            recuringAmount: 65,
            repeatEvery: 1,
            totalIntervalValue: 65,
          },
        ],
        supportItems: [
          {
            id: 84629,
            code: 'DNNE-SA-Cus-GOL',
            title: 'DNNE Gold Support',
            type: 'Recurring',
            typeId: 2,
            desc: null,
            minQuantity: NaN,
            maxQuantity: NaN,
            required: true,
            productTier: undefined,
            revenueType: undefined,
            quantity: 5,
            prices: [
              {
                type: 'Volume',
                frequency: 'ANNUALLY',
                pricebookid: 10614,
                ranges: [
                  {
                    priceplanid: 4830553,
                    type: 'Rate',
                    fromQuantity: 0,
                    price: 7,
                  },
                ],
              },
            ],
            amount: 35,
            supportLevel: 'Gold',
            isMainItem: false,
            isSupportMainItem: true,
            isSupportAddonItem: false,
            frequency: 'Annually',
            recuringAmount: 35,
            repeatEvery: 1,
            totalIntervalValue: 35,
          },
        ],
        supportItem: {
          item: {
            id: 84629,
            code: 'DNNE-SA-Cus-GOL',
            title: 'DNNE Gold Support',
            type: 'Recurring',
            typeId: 2,
            desc: null,
            minQuantity: NaN,
            maxQuantity: NaN,
            productTier: undefined,
            revenueType: undefined,
            required: true,
            quantity: 5,
            prices: [
              {
                type: 'Volume',
                frequency: 'ANNUALLY',
                pricebookid: 10614,
                ranges: [
                  {
                    priceplanid: 4830553,
                    type: 'Rate',
                    fromQuantity: 0,
                    price: 7,
                  },
                ],
              },
            ],
            amount: 35,
            supportLevel: 'Gold',
            isMainItem: false,
            isSupportMainItem: true,
            isSupportAddonItem: false,
            frequency: 'Annually',
            recuringAmount: 35,
            repeatEvery: 1,
            totalIntervalValue: 35,
          },
          isIncluded: true,
          quantity: 5,
        },
        mainItem: {
          item: {
            id: 84628,
            code: 'DNNE-SA-Cus-PRO',
            title: 'DNNE Customer Cloud EVOQ Content',
            type: 'Recurring',
            typeId: 2,
            desc: null,
            minQuantity: NaN,
            maxQuantity: NaN,
            required: true,
            productTier: undefined,
            revenueType: undefined,
            quantity: 5,
            supportLevel: undefined,
            prices: [
              {
                type: 'Volume',
                frequency: 'ANNUALLY',
                pricebookid: 10614,
                ranges: [
                  {
                    priceplanid: 4830552,
                    type: 'Rate',
                    fromQuantity: 0,
                    price: 13,
                  },
                ],
              },
            ],
            amount: 65,
            isMainItem: true,
            isSupportMainItem: false,
            isSupportAddonItem: false,
            frequency: 'Annually',
            recuringAmount: 65,
            repeatEvery: 1,
            totalIntervalValue: 65,
          },
          quantity: 5,
          isIncluded: true,
        },
      },

      includedItems: [
        {
          id: 84628,
          code: 'DNNE-SA-Cus-PRO',
          quantity: 5,
        },
      ]
    });
  });

  it('buildItems_errOnFieldsAbsence', () => {
    jest.spyOn(subscriptionDao, 'findPricesAndItemFields').mockReturnValueOnce([]);
    expect(() => {
      exposePrivate(subscriptionGetUtility).buildItems(
        {
          fields: {
            billingsubscriptionstatus: 'ACTIVE',
            customer: '123',
          },
          sublists: {
            priceinterval: { 'line 1': { linenumber: 1, status: 'ACTIVE' } },
            subscriptionline: { 'line 1': { linenumber: 1, item: '42', isincluded: 'T', status: 'ACTIVE' } },
          },
        },
        { undefined: 'typename' },
        { undefined: 'USD' }
      );
    }).toThrowError('Cannot find additional line fields');
  });

  it('buildItems_supportLevel', () => {
    (nsutils.queryToJson as any).mockReturnValue([{ key: 2, name: 'Recurring' }]);
    jest.spyOn(subscriptionDao, 'findPricesAndItemFields').mockReturnValueOnce([
      {
        id: 43,
        code: 'DNN-SA-BA-STA',
        product_tier_name: 'Standard',
        description: 'TestDescription',
        type: 'testType',
      },
    ]);
    jest.spyOn(subscriptionDao, 'findPricesAndItemFields').mockReturnValueOnce([
      {
        id: 42,
        code: 'DNN-SA-BA-SIL',
        support_level_name: 'Silver',
        description: 'TestDescription',
        type: 'testType',
      },
    ]);

    const subscriptionPlan = {
      supportLevel: SupportLevel.Silver,
      productTier: ProductTier.Standard,
      revenueType: '',
      mainItemCode: 'DNN-SA-BA-STA',
      supportItemCode: 'DNN-SA-BA-SIL',
      supportOnly: false,
      isLegacyPlan: false,
      code: 'DNNE-SA-BA-STA-SIL-001',
      name: 'Some Plan Name',
      initialterm: {
        duration: 1,
        unit: 'YEARS',
      } as any,
      items: [
        { code: 'DNN-SA-BA-STA', id: 43, required: true, isMainItem: true, productTier: ProductTier.Standard } as any,
        { code: 'DNN-SA-BA-SIL', id: 42, supportLevel: SupportLevel.Silver, isSupportMainItem: true } as any,
      ],
    };
    const res = subscriptionGetUtility.buildItems(
      {
        fields: {
          billingsubscriptionstatus: 'ACTIVE',
          customer: '123',
        },
        sublists: {
          priceinterval: {
            'line 1': { linenumber: 1, item: '43', quantity: '1', totalintervalvalue: 0, status: 'ACTIVE' },
            'line 2': { linenumber: 2, code: '42', quantity: '1', totalintervalvalue: 0, status: 'ACTIVE' }
          },
          subscriptionline: {
            'line 1': {
              linenumber: 1,
              item: '43',
              isincluded: 'T',
              isrequired: 'T',
              quantity: '1',
              status: 'ACTIVE',
            },
            'line 2': {
              linenumber: 2,
              item: '42',
              isincluded: 'T',
              isrequired: 'T',
              subscriptionlinetype: 2,
              quantity: '1',
              status: 'ACTIVE',
              supportlevelid: 22,
            },
          },
        },
      },
      subscriptionPlan as any
    );

    expect(res).toEqual({
      subscriptionItems: {
        availableItems: [
          {
            id: 43,
            isMainItem: true,
            isSupportMainItem: undefined,
            isSupportAddonItem: undefined,
            code: 'DNN-SA-BA-STA',
            type: 'Recurring',
            desc: 'TestDescription',
            minQuantity: NaN,
            maxQuantity: NaN,
            required: true,
            supportLevel: undefined,
            title: undefined,
            typeId: undefined,
            quantity: 1,
            prices: [
              {
                frequency: undefined,
                pricebookid: NaN,
                type: undefined,
                ranges: [
                  {
                    fromQuantity: undefined,
                    priceplanid: undefined,
                    price: NaN,
                    type: undefined,
                  },
                ],
              },
            ],
            amount: 0,
            productTier: 'Standard',
            frequency: undefined,
            recuringAmount: null,
            repeatEvery: NaN,
            totalIntervalValue: 0,
          },
        ],
        supportItems: [
          {
            id: 42,
            isMainItem: undefined,
            isSupportMainItem: true,
            isSupportAddonItem: undefined,
            code: 'DNN-SA-BA-SIL',
            type: 'Recurring',
            desc: 'TestDescription',
            minQuantity: NaN,
            maxQuantity: NaN,
            required: true,
            productTier: undefined,
            title: undefined,
            typeId: 2,
            quantity: 1,
            prices: [
              {
                frequency: undefined,
                pricebookid: NaN,
                type: undefined,
                ranges: [
                  {
                    fromQuantity: undefined,
                    priceplanid: undefined,
                    price: NaN,
                    type: undefined,
                  },
                ],
              },
            ],
            amount: 0,
            supportLevel: 'Silver',
            frequency: undefined,
            recuringAmount: null,
            repeatEvery: NaN,
            totalIntervalValue: 0,
          },
        ],
        supportItem: {
          item: {
            id: 42,
            isMainItem: undefined,
            isSupportMainItem: true,
            isSupportAddonItem: undefined,
            code: 'DNN-SA-BA-SIL',
            type: 'Recurring',
            desc: 'TestDescription',
            minQuantity: NaN,
            maxQuantity: NaN,
            required: true,
            productTier: undefined,
            title: undefined,
            typeId: 2,
            quantity: 1,
            prices: [
              {
                frequency: undefined,
                pricebookid: NaN,
                type: undefined,
                ranges: [
                  {
                    fromQuantity: undefined,
                    priceplanid: undefined,
                    price: NaN,
                    type: undefined,
                  },
                ],
              },
            ],
            amount: 0,
            supportLevel: 'Silver',
            frequency: undefined,
            recuringAmount: null,
            repeatEvery: NaN,
            totalIntervalValue: 0,
          },
          isIncluded: true,
          quantity: 1,
        },
        mainItem: {
          item: {
            id: 43,
            isMainItem: true,
            isSupportMainItem: undefined,
            isSupportAddonItem: undefined,
            code: 'DNN-SA-BA-STA',
            type: 'Recurring',
            desc: 'TestDescription',
            minQuantity: NaN,
            maxQuantity: NaN,
            required: true,
            supportLevel: undefined,
            title: undefined,
            typeId: undefined,
            quantity: 1,
            prices: [
              {
                frequency: undefined,
                pricebookid: NaN,
                type: undefined,
                ranges: [
                  {
                    fromQuantity: undefined,
                    priceplanid: undefined,
                    price: NaN,
                    type: undefined,
                  },
                ],
              },
            ],
            amount: 0,
            productTier: 'Standard',
            frequency: undefined,
            recuringAmount: null,
            repeatEvery: NaN,
            totalIntervalValue: 0,
          },
          isIncluded: true,
          quantity: 1,
        },
      },

      includedItems: [
        {
          id: 43,
          code: 'DNN-SA-BA-STA',
          quantity: 1,
        },
      ]
    });
  });

  it('buildItems 441925', () => {
    (nsutils.queryToJson as any).mockReturnValueOnce([
      { name: 'One Time', key: 1 },
      { name: 'Recurring', key: 2 },
      { name: 'Usage', key: 3 },
      { name: 'Commit Plus Overage', key: 4 },
    ]);
    jest.spyOn(subscriptionDao, 'findPricesAndItemFields').mockReturnValueOnce([
      {
        id: 61513,
        code: 'GEN-OP-SUB-SIL',
        title: 'GENSYM MAINTENANCE STANDARD SUPPORT',
        description: 'GENSYM MAINTENANCE STANDARD SUPPORT\r\n',
        pricetype: 'Volume',
        priceplanid: 3094978,
        fromquantity: 0,
        price: 0,
        pricingoption: -101,
        maximumquantity: null,
        minimumquantity: null,
        support_level_name: 'Silver',
        product_tier_name: null,
      },
    ]);
    jest.spyOn(subscriptionDao, 'findPricesAndItemFields').mockReturnValueOnce([
      {
        id: 61512,
        code: 'GEN-OP-SUB-STA',
        title: 'GENSYM SUBSCRIPTION Standard',
        description: 'GENSYM SUBSCRIPTION Standard',
        pricetype: 'Volume',
        priceplanid: 3094976,
        fromquantity: 0,
        price: 180393.48,
        pricingoption: -101,
        maximumquantity: null,
        minimumquantity: null,
        support_level_name: null,
        product_tier_name: 'Standard',
      },
    ]);
    const buildItemsParams = {
      subscription: {
        id: '441925',
        type: 'subscription',
        isDynamic: false,
        fields: {
          idnumber: '324128',
          renewalnumber: '0',
          rootsubscription: '441925',
          externalid: '5786775-1',
          subscriptionplan: '61612',
          _eml_nkey_: '4914352_SB1~755596~1207~N',
          startdate: '1-Oct-2019',
          type: 'subscription',
          nextbillcycledate: '1-Oct-2022',
          frequency: 'ANNUALLY',
          alignchargewithsub: 'T',
          autorenewal: 'T',
          billingsubscriptionstatus: 'ACTIVE',
          advancerenewalperiodnumber: '1094',
          custrecord_isautorenewal: 'F',
          id: '441925',
          custrecord_istrial: 'F',
          hasfuturedatedactivation: 'F',
          initialterm: '3',
          custrecord_subs_ship_to_tier: '1',
          firstcodate: '1-Oct-2019',
          entryformquerystring: 'e=T&id=441925',
          currencyforba: '1',
          defaultrenewalterm: '3',
          defaultrenewalpricebook: '7400',
          lastcodate: '8-Jul-2021',
          subsidiary: '34',
          enddate: '30-Sep-2022',
          name: '2974 ISO New England 2019 Subscription Renewal -..',
          initialtermduration: '36',
          wfinstances: '',
          initialtermunits: 'MONTHS',
          advancerenewalperiodunit: 'DAYS',
          custrecord_subs_bill_to_tier: '1',
          subscriptionplanname: 'GENSYM SUBSCRIPTION STANDARD SUPPORT',
          origidnumber: '324128',
          initialtermtype: 'STANDARD',
          nsapiCT: '1651571741693',
          sys_id: '12199219930715307',
          isextendedtoevergreen: 'F',
          billingaccount: '292075',
          otherrecordnumber: '324128',
          currency: '1',
          subscriptionrevision: '4',
          department: '2',
          class: '25',
          pricebook: '7400',
          templatestored: 'T',
          billingaccountstartdate: '1-Oct-2019',
          lastbillcycledate: '1-Oct-2021',
          defaultrenewalmethod: 'CREATE_NEW_SUBSCRIPTION',
          lastmodifieddate: '1-Sep-2021 3:19 am',
          defaultrenewalplan: '61612',
          billingschedule: '154',
          custrecord_customer_po: '26718-0-OEM',
          lastbilldate: '1-Sep-2021',
          subsidiaryforba: '34',
          custrecord_subs_end_user: '5810',
          customform: '-10060',
          wassubscriptioneveractivated: 'T',
          customer: '5810',
        },
        sublists: {
          priceinterval: {
            currentline: {
              catalogtype: 'ADD_ON',
              chargetype: '',
              discount: '',
              frequency: '',
              groupid: '',
              id: '',
              item: '',
              linenumber: '',
              multiplierline: '',
              price: '',
              priceplan: '',
              priceplanbutton: '',
              prorateby: '',
              proratebyoption: '',
              quantity: '',
              recurringamount: '',
              repeatevery: '',
              startdate: '',
              startoffsetunit: 'MONTH',
              startoffsetvalue: '',
              status: '',
              subscriptionplanline: '',
              subscriptionplanlinenumber: '',
              sys_id: '-12199219943932963',
              sys_parentid: '12199219930715307',
              totalintervalvalue: '',
              '#': '5',
            },
            'line 1': {
              catalogtype: 'OPTIONAL',
              chargetype: '2',
              discount: '0.00%',
              frequency: 'ANNUALLY',
              groupid: '3262755',
              id: '3254917',
              item: '61512',
              item_display: 'GEN-OP-SUB-STA',
              linenumber: '1',
              multiplierline: null,
              multiplierline_display: null,
              price: 'From 0: $180,393.48<br>',
              priceplan: '3094976',
              priceplanbutton:
                '<div><a id="pricePlanEdit" href="javascript:billing.subscription.machine.pbli.client.popupPricePlanWindow(null, 2, false)" class="iconpencil"></a></div>',
              prorateby: 'DAY',
              proratebyoption: '1',
              quantity: '1',
              recurringamount: '180393.48',
              repeatevery: '1',
              startdate: '1-Oct-2019',
              startoffsetunit: 'YEAR',
              startoffsetvalue: '1',
              status: 'ACTIVE',
              subscriptionplanline: '13641',
              subscriptionplanlinenumber: '1',
              sys_id: '12199219930812565',
              sys_parentid: '12199219930715307',
              totalintervalvalue: '541180.44',
            },
            'line 2': {
              catalogtype: 'OPTIONAL',
              chargetype: '2',
              discount: '0.00%',
              frequency: 'ANNUALLY',
              groupid: '3262756',
              id: '3254918',
              item: '61513',
              item_display: 'GEN-OP-SUB-SIL',
              linenumber: '2',
              multiplierline: null,
              multiplierline_display: null,
              price: 'From 0: $0.00<br>',
              priceplan: '3094978',
              priceplanbutton:
                '<div><a id="pricePlanEdit" href="javascript:billing.subscription.machine.pbli.client.popupPricePlanWindow(null, 2, false)" class="iconpencil"></a></div>',
              prorateby: 'DAY',
              proratebyoption: '1',
              quantity: '1',
              recurringamount: '0.00',
              repeatevery: '1',
              startdate: '1-Oct-2019',
              startoffsetunit: 'YEAR',
              startoffsetvalue: '1',
              status: 'ACTIVE',
              subscriptionplanline: '13640',
              subscriptionplanlinenumber: '2',
              sys_id: '12199219930792991',
              sys_parentid: '12199219930715307',
              totalintervalvalue: '0.00',
            },
            'line 3': {
              catalogtype: 'ADD_ON',
              chargetype: '2',
              discount: '0.00%',
              frequency: 'ANNUALLY',
              groupid: '3262757',
              id: '3254919',
              item: '61512',
              item_display: 'GEN-OP-SUB-STA',
              linenumber: '3',
              multiplierline: null,
              multiplierline_display: null,
              price: 'From 0: $-180,393.48<br>',
              priceplan: '3147276',
              priceplanbutton:
                '<div><a id="pricePlanEdit" href="javascript:billing.subscription.machine.pbli.client.popupPricePlanWindow(null, 2, false)" class="iconpencil"></a></div>',
              prorateby: 'DAY',
              proratebyoption: '1',
              quantity: '1',
              recurringamount: '-180393.48',
              repeatevery: '1',
              startdate: '1-Oct-2019',
              startoffsetunit: 'MONTH',
              startoffsetvalue: '1',
              status: 'ACTIVE',
              subscriptionplanline: null,
              subscriptionplanlinenumber: '3',
              sys_id: '12199219930773129',
              sys_parentid: '12199219930715307',
              totalintervalvalue: '-180393.48',
            },
            'line 4': {
              catalogtype: 'ADD_ON',
              chargetype: '2',
              discount: '0.00%',
              frequency: 'ANNUALLY',
              groupid: '3264200',
              id: '3256226',
              item: '61512',
              item_display: 'GEN-OP-SUB-STA',
              linenumber: '3',
              multiplierline: null,
              multiplierline_display: null,
              price: 'From 0: $0.00<br>',
              priceplan: '3158287',
              priceplanbutton:
                '<div><a id="pricePlanEdit" href="javascript:billing.subscription.machine.pbli.client.popupPricePlanWindow(null, 2, false)" class="iconpencil"></a></div>',
              prorateby: 'DAY',
              proratebyoption: '1',
              quantity: '1',
              recurringamount: '0.00',
              repeatevery: '1',
              startdate: '1-Oct-2020',
              startoffsetunit: 'MONTH',
              startoffsetvalue: '1',
              status: 'ACTIVE',
              subscriptionplanline: null,
              subscriptionplanlinenumber: '3',
              sys_id: '12199219930750783',
              sys_parentid: '12199219930715307',
              totalintervalvalue: '0.00',
            },
          },
          subscriptionline: {
            currentline: {
              billingmode: '',
              catalogtype: 'ADD_ON',
              class: '',
              department: '',
              discount: '',
              enddate: '',
              includeinrenewal: 'F',
              isincluded: 'T',
              isrequired: 'F',
              item: '',
              linenumber: '',
              location: '',
              planitem: '',
              prorateenddate: 'F',
              proratestartdate: 'F',
              quantity: '',
              recurrencestartdate: '',
              revrecoption: '',
              startdate: '',
              status: 'DRAFT',
              subscriptionline: '',
              subscriptionlinetype: '',
              sys_id: '-12199219943839390',
              sys_parentid: '12199219930715307',
              terminationdate: '',
              '#': '4',
            },
            'line 1': {
              billingmode: 'IN_ADVANCE',
              catalogtype: 'OPTIONAL',
              class: '25',
              class_display: 'Acquisitions : IgniteTech : IgniteTech Product : Gensym Product',
              department: '2',
              department_display: 'Sales',
              discount: '0.00%',
              enddate: '30-Sep-2022',
              includeinrenewal: 'T',
              isincluded: 'T',
              isrequired: 'F',
              item: '61512',
              item_display: 'GEN-OP-SUB-STA',
              linenumber: '1',
              location: null,
              location_display: null,
              planitem: '13641',
              prorateenddate: 'F',
              proratestartdate: 'F',
              quantity: '1',
              recurrencestartdate: '1-Oct-2019',
              revrecoption: 'OVER_TERM',
              startdate: '1-Oct-2019',
              status: 'ACTIVE',
              subscriptionline: '3336207',
              subscriptionlinetype: '2',
              sys_id: '12199219930873646',
              sys_parentid: '12199219930715307',
              terminationdate: null,
            },
            'line 2': {
              billingmode: 'IN_ADVANCE',
              catalogtype: 'OPTIONAL',
              class: '25',
              class_display: 'Acquisitions : IgniteTech : IgniteTech Product : Gensym Product',
              department: '2',
              department_display: 'Sales',
              discount: '0.00%',
              enddate: '30-Sep-2022',
              includeinrenewal: 'T',
              isincluded: 'T',
              isrequired: 'F',
              item: '61513',
              item_display: 'GEN-OP-SUB-SIL',
              linenumber: '2',
              location: null,
              location_display: null,
              planitem: '13640',
              prorateenddate: 'F',
              proratestartdate: 'F',
              quantity: '1',
              recurrencestartdate: '1-Oct-2019',
              revrecoption: 'OVER_TERM',
              startdate: '1-Oct-2019',
              status: 'ACTIVE',
              subscriptionline: '3336206',
              subscriptionlinetype: '2',
              sys_id: '12199219930854063',
              sys_parentid: '12199219930715307',
              terminationdate: null,
            },
            'line 3': {
              billingmode: 'IN_ADVANCE',
              catalogtype: 'ADD_ON',
              class: '25',
              class_display: 'Acquisitions : IgniteTech : IgniteTech Product : Gensym Product',
              department: '2',
              department_display: 'Sales',
              discount: '0.00%',
              enddate: '30-Sep-2022',
              includeinrenewal: 'F',
              isincluded: 'T',
              isrequired: 'F',
              item: '61512',
              item_display: 'GEN-OP-SUB-STA',
              linenumber: '3',
              location: null,
              location_display: null,
              planitem: null,
              prorateenddate: 'F',
              proratestartdate: 'F',
              quantity: '1',
              recurrencestartdate: '1-Oct-2019',
              revrecoption: 'OVER_TERM',
              startdate: '1-Oct-2019',
              status: 'ACTIVE',
              subscriptionline: '3336205',
              subscriptionlinetype: '2',
              sys_id: '12199219930832494',
              sys_parentid: '12199219930715307',
              terminationdate: null,
            },
          },
        },
      },
      plan: {
        supportOnly: false,
        code: 'GEN-OP-SUB-STA-SIL',
        name: 'GENSYM SUBSCRIPTION STANDARD SUPPORT',
        isLegacyPlan: true,
        productTier: ProductTier.Standard,
        mainItemCode: 'GEN-OP-SUB-STA',
        revenueType: 'On-Premise',
        supportLevel: SupportLevel.Silver,
        supportItemCode: 'GEN-OP-SUB-SIL',
        initialterm: {
          duration: 1,
          unit: 'YEARS',
        },
        items: [
          {
            id: 61512,
            code: 'GEN-OP-SUB-STA',
            title: 'GENSYM SUBSCRIPTION Standard',
            supportLevel: undefined,
            productTier: ProductTier.Standard,
            revenueType: 'On-Premise',
            isSupportMainItem: false,
            isSupportAddonItem: false,
            isMainItem: true,
            required: true,
            type: 'Recurring',
            typeId: 2,
            desc: 'GENSYM SUBSCRIPTION Standard',
            minQuantity: 0,
            maxQuantity: 999,
            prices: [
              {
                type: 'Volume',
                frequency: 'ANNUALLY',
                currency: 'USD',
                pricebookid: 7400,
                ranges: [
                  {
                    priceplanid: 3157481,
                    type: 'Rate',
                    fromQuantity: 0,
                    price: 0,
                  },
                ],
              },
              {
                type: 'Volume',
                frequency: 'ANNUALLY',
                currency: 'EUR',
                pricebookid: 7401,
                ranges: [
                  {
                    priceplanid: 3157483,
                    type: 'Rate',
                    fromQuantity: 0,
                    price: 0,
                  },
                ],
              },
              {
                type: 'Volume',
                frequency: 'ANNUALLY',
                currency: 'JPY',
                pricebookid: 7934,
                ranges: [
                  {
                    priceplanid: 3281992,
                    type: 'Rate',
                    fromQuantity: 0,
                    price: 0,
                  },
                ],
              },
            ],
          },
          {
            id: 61513,
            code: 'GEN-OP-SUB-SIL',
            title: 'GENSYM MAINTENANCE STANDARD SUPPORT',
            supportLevel: SupportLevel.Silver,
            productTier: undefined,
            revenueType: 'On-Premise',
            isSupportMainItem: true,
            isSupportAddonItem: false,
            isMainItem: false,
            required: true,
            type: 'Recurring',
            typeId: 2,
            desc: 'GENSYM MAINTENANCE STANDARD SUPPORT\r\n',
            minQuantity: 0,
            maxQuantity: 999,
            prices: [
              {
                type: 'Volume',
                frequency: 'ANNUALLY',
                currency: 'USD',
                pricebookid: 7400,
                ranges: [
                  {
                    priceplanid: 3157482,
                    type: 'Rate',
                    fromQuantity: 0,
                    price: 0,
                  },
                ],
              },
              {
                type: 'Volume',
                frequency: 'ANNUALLY',
                currency: 'EUR',
                pricebookid: 7401,
                ranges: [
                  {
                    priceplanid: 3157484,
                    type: 'Rate',
                    fromQuantity: 0,
                    price: 0,
                  },
                ],
              },
              {
                type: 'Volume',
                frequency: 'ANNUALLY',
                currency: 'JPY',
                pricebookid: 7934,
                ranges: [
                  {
                    priceplanid: 3281993,
                    type: 'Rate',
                    fromQuantity: 0,
                    price: 0,
                  },
                ],
              },
            ],
          },
        ],
      },
    };
    const res = subscriptionGetUtility.buildItems(buildItemsParams.subscription, buildItemsParams.plan as any);

    expect(res).toEqual({
      subscriptionItems: {
        availableItems: [
          {
            id: 61512,
            code: 'GEN-OP-SUB-STA',
            title: 'GENSYM SUBSCRIPTION Standard',
            type: 'Recurring',
            typeId: 2,
            desc: 'GENSYM SUBSCRIPTION Standard',
            minQuantity: NaN,
            maxQuantity: NaN,
            required: false,
            prices: [
              {
                type: 'Volume',
                frequency: 'ANNUALLY',
                pricebookid: 7400,
                ranges: [{ priceplanid: 3094976, type: 'Rate', fromQuantity: 0, price: 180393.48 }],
              },
            ],
            amount: 180393.48,
            totalIntervalValue: 360786.96,
            recuringAmount: 180393.48,
            frequency: 'Annually',
            repeatEvery: 1,
            productTier: 'Standard',
            supportLevel: undefined,
            isMainItem: true,
            isSupportMainItem: false,
            isSupportAddonItem: false,
            quantity: 2,
          },
        ],
        supportItems: [
          {
            id: 61513,
            code: 'GEN-OP-SUB-SIL',
            title: 'GENSYM MAINTENANCE STANDARD SUPPORT',
            type: 'Recurring',
            typeId: 2,
            desc: 'GENSYM MAINTENANCE STANDARD SUPPORT\r\n',
            minQuantity: NaN,
            maxQuantity: NaN,
            required: false,
            prices: [
              {
                type: 'Volume',
                frequency: 'ANNUALLY',
                pricebookid: 7400,
                ranges: [{ priceplanid: 3094978, type: 'Rate', fromQuantity: 0, price: 0 }],
              },
            ],
            amount: 0,
            totalIntervalValue: 0,
            recuringAmount: 0,
            frequency: 'Annually',
            repeatEvery: 1,
            productTier: undefined,
            supportLevel: 'Silver',
            isMainItem: false,
            isSupportMainItem: true,
            isSupportAddonItem: false,
            quantity: 1,
          },
        ],
        mainItem: {
          item: {
            id: 61512,
            code: 'GEN-OP-SUB-STA',
            title: 'GENSYM SUBSCRIPTION Standard',
            type: 'Recurring',
            typeId: 2,
            desc: 'GENSYM SUBSCRIPTION Standard',
            minQuantity: NaN,
            maxQuantity: NaN,
            required: false,
            prices: [
              {
                type: 'Volume',
                frequency: 'ANNUALLY',
                pricebookid: 7400,
                ranges: [{ priceplanid: 3094976, type: 'Rate', fromQuantity: 0, price: 180393.48 }],
              },
            ],
            amount: 180393.48,
            totalIntervalValue: 360786.96,
            recuringAmount: 180393.48,
            frequency: 'Annually',
            repeatEvery: 1,
            productTier: 'Standard',
            supportLevel: undefined,
            isMainItem: true,
            isSupportMainItem: false,
            isSupportAddonItem: false,
            quantity: 2,
          },
          isIncluded: true,
          quantity: 2,
        },
        supportItem: {
          item: {
            id: 61513,
            code: 'GEN-OP-SUB-SIL',
            title: 'GENSYM MAINTENANCE STANDARD SUPPORT',
            type: 'Recurring',
            typeId: 2,
            desc: 'GENSYM MAINTENANCE STANDARD SUPPORT\r\n',
            minQuantity: NaN,
            maxQuantity: NaN,
            required: false,
            prices: [
              {
                type: 'Volume',
                frequency: 'ANNUALLY',
                pricebookid: 7400,
                ranges: [{ priceplanid: 3094978, type: 'Rate', fromQuantity: 0, price: 0 }],
              },
            ],
            amount: 0,
            totalIntervalValue: 0,
            recuringAmount: 0,
            frequency: 'Annually',
            repeatEvery: 1,
            supportLevel: 'Silver',
            productTier: undefined,
            isMainItem: false,
            isSupportMainItem: true,
            isSupportAddonItem: false,
            quantity: 1,
          },
          isIncluded: true,
          quantity: 1,
        },
      },
      includedItems: [{ id: 61512, code: 'GEN-OP-SUB-STA', quantity: 2 }]
    });
  });
  it('get', () => {
    jest.spyOn(subscriptionGetUtility, 'getSubscriptionByIdForCustomer').mockReturnValueOnce('Test' as any);
    const res = Subscription.get({ subscriptionId: 1, customerId: 'Test' });

    expect(res).toStrictEqual({ content: 'Test' });
  });

  it('findForCustomer', () => {
    (nsutils.queryToJson as any).mockReturnValueOnce([{ id: 42 }]);
    (subscriptionGetUtility.getSubscriptionByIdForCustomer as any).mockImplementationOnce((id) =>
      id === 42 ? 'Test' : ''
    );

    const res = Subscription.findForCustomer({
      customerId: 'TestCustomer',
      productFamilyCode: 'TST',
      statuses: ['ACTIVE', 'DRAFT'],
    });

    expect(res).toStrictEqual({ content: ['Test'] });
  });

  it('findItemCodes', () => {
    (nsutils.queryToJson as any).mockReturnValueOnce([{ id: 42 }]);

    const res = subscriptionDao.findItemCodes([]);

    expect(res).toStrictEqual([{ id: 42 }]);
  });

  it('utility findItemCodes', () => {
    (nsutils.queryToJson as any).mockReturnValueOnce([{ id: 42 }]);
    jest.spyOn(subscriptionItemUtility, 'getSubItemIds').mockReturnValueOnce([{ id: 42, status: 'ACTIVE' }]);
    const subscriptionRecord = {
      getValue: () => {},
    } as any;
    jest.spyOn(subscriptionRecord, 'getValue').mockReturnValueOnce('1234');
    const res = subscriptionItemUtility.findItemCodes(subscriptionRecord);

    expect(res).toStrictEqual([{ id: 42, status: 'ACTIVE' }]);
  });

  it('startTrial 1', () => {
    jest.spyOn(subscriptionDao, 'getCustomerSubscriptionIds').mockReturnValueOnce([]);
    (ProductIntegration.findProductIntegration as any).mockReturnValueOnce({
      trialSubscriptionConfig: `{"planCode": "testcode"}`,
    });
    (Subscription.create as any).mockReturnValueOnce({});
    Subscription.startTrial({
      productFamilyCode: 'TES',
      productVariantCode: 'SA',
      customerId: 'TestCustomer',
    });

    expect(Subscription.create).toBeCalledWith(
      {
        content: { planCode: 'testcode' },
        productFamilyCode: 'TES',
        productVariantCode: 'SA',
        customerId: 'TestCustomer',
      },
      true
    );
  });

  it('startTrial 2', () => {
    jest.spyOn(subscriptionDao, 'getCustomerSubscriptionIds').mockReturnValueOnce([]);

    (ProductIntegration.findProductIntegration as any).mockReturnValueOnce({
      trialSubscriptionConfig: `{"planCode": "TestPlan", "frequency": "monthly", "trialDuration":15, "items": [{"code": "TES-SA-IT1-STA", "quantity":1}]}`,
    });
    jest.spyOn(customerDao, 'findCustomerAndBa').mockReturnValueOnce({ customerId: 'TestCustomer' });

    (subscriptionDao.findSubscriptionItemCodes as any).mockReturnValue([
      { code: 'TES-SA-IT1-STA', id: 321, required: true },
      { code: 'TES-SA-IT1-SIL', id: 322, supportLevel: SupportLevel.Silver },
    ]);

    (subscriptionPlanUtility.getSubscriptionPlanById as any).mockReturnValue({
      items: [
        {
          code: 'TES-SA-IT1-STA',
          id: 321,
          required: true,
          prices: [
            {
              type: 'Tiered',
              frequency: 'ANNUALLY',
              currency: 'USD',
              ranges: [
                {
                  type: 'Rate',
                  fromQuantity: 0,
                  price: 1000,
                },
              ],
            },
          ],
        },
        {
          code: 'TES-SA-IT1-SIL',
          id: 322,
          supportLevel: SupportLevel.Silver,
          prices: [
            {
              type: 'Tiered',
              frequency: 'ANNUALLY',
              currency: 'USD',
              ranges: [
                {
                  type: 'Rate',
                  fromQuantity: 0,
                  price: 200,
                },
              ],
            },
          ],
        },
      ],
      supportLevel: SupportLevel.Silver,
      productTier: ProductTier.Standard,
      revenueType: '',
      mainItemCode: 'TES-SA-IT1-STA',
      supportItemCode: 'TES-SA-IT1-SIL',
      supportOnly: false,
    });

    jest.spyOn(nsutils, 'queryFirstToJson').mockReturnValueOnce(null);
    (ProductIntegration.findByClass as any).mockReturnValueOnce([
      { nsClass: { id: 1, name: 'USD', fullname: 'Dollar' } },
    ]);
    jest.spyOn(subscriptionValidateUtility, 'validateAndPrepareCreateData').mockImplementation((params: any) => {
      params.content.planClass = 1;
      params.content.planId = 1;
    });
    jest.spyOn(subscriptionPriceUtility, 'applyDiscount').mockReturnValue(1);

    const subscriptionRecord = new RecordDynamicMock(
      {
        subscriptionline: [
          { item: 321, status: 'DRAFT', required: true },
          { item: 322, status: 'DRAFT' },
        ],
        priceinterval: [
          { item: 321, status: 'DRAFT' },
          { item: 322, status: 'DRAFT' },
        ],
      },
      {}
    );

    const testPricePlan = new RecordDynamicMock(
      {
        pricetiers: [
          { fromval: 0, value: 12, pricingoption: 'RATE' },
          { fromval: 10, value: 9, pricingoption: 'RATE' },
          { fromval: 30, value: 6, pricingoption: 'RATE' },
        ],
      },
      {}
    );

    const testActivateChangeOrder = new RecordDynamicMock(
      {
        subline: [
          { item: 321, status: 'DRAFT', quantity: 0, required: true },
          { item: 322, status: 'DRAFT', quantity: 0 },
        ],
      },
      {}
    );

    (record.create as any).mockImplementation((opts) => {
      if (opts.type === record.Type.SUBSCRIPTION) {
        return subscriptionRecord;
      } else if (opts.type === record.Type.PRICE_PLAN) {
        return testPricePlan;
      } else if (opts.type === record.Type.SUBSCRIPTION_CHANGE_ORDER) {
        return testActivateChangeOrder;
      } else {
        return new RecordDynamicMock({}, {});
      }
    });

    (record.load as any).mockImplementation((opts) => {
      if (opts.type === record.Type.SUBSCRIPTION) {
        return subscriptionRecord;
      } else if (opts.type === record.Type.PRICE_PLAN) {
        return testPricePlan;
      } else if (opts.type === record.Type.SUBSCRIPTION_CHANGE_ORDER) {
        return testActivateChangeOrder;
      } else {
        return new RecordDynamicMock({}, {});
      }
    });
    jest.spyOn(subscriptionGetUtility, 'getSubscriptionByIdForCustomer').mockReturnValueOnce('Test' as any);
    Subscription.startTrial({
      productFamilyCode: 'TES',
      productVariantCode: 'SA',
      customerId: 'TestCustomer',
    });
  });

  it('supportLevelDistributionRatio', () => {
    expect(supportLevelDistributionRatio(SupportLevel.Silver)).toBe(0.16666666666666669);
    expect(supportLevelDistributionRatio(SupportLevel.Gold)).toBe(0.25925925925925926);
    expect(supportLevelDistributionRatio(SupportLevel.Platinum)).toBe(0.3103448275862069);
    expect(supportLevelDistributionRatio(undefined as unknown as SupportLevel)).toBe(0);
  });

  it('supportLevelUptick', () => {
    expect(supportLevelUptick(SupportLevel.Silver)).toBe(0.25);
    expect(supportLevelUptick(SupportLevel.Gold)).toBe(0.35);
    expect(supportLevelUptick(SupportLevel.Platinum)).toBe(0.45);
    expect(supportLevelUptick(undefined as unknown as SupportLevel)).toBe(0.25);
  });

  it('supportLevel conversion', () => {
    expect(SupportLevelUtil.nameToSupportLevel('Silver')).toBe(SupportLevel.Silver);
    expect(SupportLevelUtil.nameToSupportLevel('SILVER')).toBe(SupportLevel.Silver);
    expect(SupportLevelUtil.nameToSupportLevel('sILVER')).toBe(SupportLevel.Silver);
    expect(SupportLevelUtil.nameToSupportLevel('Gold')).toBe(SupportLevel.Gold);
    expect(SupportLevelUtil.nameToSupportLevel('Platinum')).toBe(SupportLevel.Platinum);
  });

  it('buildSubscription 1', () => {
    (subscriptionPlanUtility.getSubscriptionPlanById as any).mockReturnValueOnce({
      items: [
        {
          code: 'TES-SA-IT1-STA',
          id: 321,
          required: true,
          productTier: ProductTier.Standard,
          isMainItem: true,
          isSupportItem: false,
        },
        { code: 'TES-SA-IT1-SIL', id: 322, supportLevel: SupportLevel.Silver, isMainItem: false, isSupportItem: true },
      ],
      supportLevel: SupportLevel.Silver,
      productTier: ProductTier.Standard,
      revenueType: 'Saas',
      mainItemCode: 'SOT-SA-BA-BAS',
      supportItemCode: 'SOT-SA-BA-SIL',
      supportOnly: false,
      isLegacyPlan: false,
    });
    exposePrivate(subscriptionGetUtility).buildItems.mockReturnValueOnce({
      subscriptionItems: {
        availableItems: [
          {
            amount: 1,
            code: 'SOT-SA-BA-BAS',
            desc: 'TestDescription',
            id: 42,
            prices: [
              {
                currency: 'USD',
                frequency: 'MONTHLY',
                ranges: [{ fromQuantity: 0, price: 1, type: 'Volume' }],
                type: undefined,
              },
            ],
            productTier: 'Professional',
            required: true,
            revenueType: 'SaaS',
            supportLevel: 'Silver',
            title: undefined,
            type: 'Recurring',
          },
          {
            amount: 0,
            code: 'SOT-SA-BA-SIL',
            desc: 'TestDescription',
            id: 43,
            prices: [{ currency: 'USD', frequency: 'MONTHLY', ranges: [], type: undefined }],
            productTier: undefined,
            required: true,
            revenueType: undefined,
            supportLevel: 'Silver',
            title: undefined,
            type: 'Recurring',
          },
        ],
        supportItems: [],
        mainItem: {
          item: {
            amount: 1,
            code: 'SOT-SA-BA-BAS',
            desc: 'TestDescription',
            id: 42,
            prices: [
              {
                currency: 'USD',
                frequency: 'MONTHLY',
                ranges: [{ fromQuantity: 0, price: 1, type: 'Volume' }],
                type: undefined,
              },
            ],
            productTier: 'Professional',
            required: true,
            revenueType: 'SaaS',
            supportLevel: 'Silver',
            title: undefined,
            type: 'Recurring',
          },
        },
        supportItem: {
          amount: 0,
          code: 'SOT-SA-BA-SIL',
          desc: 'TestDescription',
          id: 43,
          prices: [{ currency: 'USD', frequency: 'MONTHLY', ranges: [], type: undefined }],
          productTier: undefined,
          required: true,
          revenueType: undefined,
          supportLevel: 'Silver',
          title: undefined,
          type: 'Recurring',
        },
      },
      includedItems: [
        { code: 'SOT-SA-BA-BAS', id: 42, quantity: 2, amount: 1 },
        { code: 'SOT-SA-BA-SIL', id: 43, quantity: 2, amount: 2 },
      ],
    });
    const res = subscriptionGetUtility.buildSubscription({
      fields: {
        customer: '123',
        parentsubscription: '1',
        billingsubscriptionstatus: 'ACTIVE'
      },
      sublists: {
        priceinterval: { 'line 1': { linenumber: 1 } },
        subscriptionline: { 'line 1': { linenumber: 1, item: '42', isincluded: 'F', supportlevelid: 22 } },
      },
    });
    expect(res).toEqual(expect.objectContaining({ renewalNumber: 0 }));
  });

  it('buildSubscription 2', () => {
    (subscriptionPlanUtility.getSubscriptionPlanById as any).mockReturnValueOnce({
      items: [
        {
          code: 'TES-SA-IT1-STA',
          id: 321,
          required: true,
          productTier: ProductTier.Standard,
          isMainItem: true,
          isSupportItem: false,
        },
        { code: 'TES-SA-IT1-SIL', id: 322, supportLevel: SupportLevel.Silver, isMainItem: false, isSupportItem: true },
      ],
      supportLevel: SupportLevel.Silver,
      productTier: ProductTier.Standard,
      revenueType: 'Saas',
      mainItemCode: 'SOT-SA-BA-BAS',
      supportItemCode: 'SOT-SA-BA-SIL',
      supportOnly: false,
      isLegacyPlan: true,
    });
    exposePrivate(subscriptionGetUtility).buildItems.mockReturnValueOnce({
      subscriptionItems: {
        availableItems: [
          {
            amount: 1,
            code: 'SOT-SA-BA-BAS',
            desc: 'TestDescription',
            id: 42,
            prices: [
              {
                currency: 'USD',
                frequency: 'MONTHLY',
                ranges: [{ fromQuantity: 0, price: 1, type: 'Volume' }],
                type: undefined,
              },
            ],
            productTier: 'Professional',
            required: true,
            revenueType: 'SaaS',
            supportLevel: 'Silver',
            title: undefined,
            type: 'Recurring',
          },
          {
            amount: 0,
            code: 'SOT-SA-BA-SIL',
            desc: 'TestDescription',
            id: 43,
            prices: [{ currency: 'USD', frequency: 'MONTHLY', ranges: [], type: undefined }],
            productTier: undefined,
            required: true,
            revenueType: undefined,
            supportLevel: 'Silver',
            title: undefined,
            type: 'Recurring',
          },
        ],
        supportItems: [],
        mainItem: {
          item: {
            amount: 1,
            code: 'SOT-SA-BA-BAS',
            desc: 'TestDescription',
            id: 42,
            prices: [
              {
                currency: 'USD',
                frequency: 'MONTHLY',
                ranges: [{ fromQuantity: 0, price: 1, type: 'Volume' }],
                type: undefined,
              },
            ],
            productTier: 'Professional',
            required: true,
            revenueType: 'SaaS',
            supportLevel: 'Silver',
            title: undefined,
            type: 'Recurring',
          },
        },
        supportItem: {
          amount: 0,
          code: 'SOT-SA-BA-SIL',
          desc: 'TestDescription',
          id: 43,
          prices: [{ currency: 'USD', frequency: 'MONTHLY', ranges: [], type: undefined }],
          productTier: undefined,
          required: true,
          revenueType: undefined,
          supportLevel: 'Silver',
          title: undefined,
          type: 'Recurring',
        },
      },
      includedItems: [
        { code: 'SOT-SA-BA-BAS', id: 42, quantity: 2, amount: 1 },
        { code: 'SOT-SA-BA-SIL', id: 43, quantity: 2, amount: 2 },
      ],
    });
    const res = subscriptionGetUtility.buildSubscription({
      fields: {
        customer: '123',
        custrecord_parent_subscription: '1',
        billingsubscriptionstatus: 'ACTIVE'
      },
      sublists: {
        priceinterval: { 'line 1': { linenumber: 1 } },
        subscriptionline: { 'line 1': { linenumber: 1, item: '42', isincluded: 'F', supportlevelid: 22 } },
      },
    });
    expect(res).toEqual(expect.objectContaining({ renewalNumber: 0 }));
  });

  it('buildSubscription renewalNumber', () => {
    exposePrivate(subscriptionGetUtility).buildItems.mockReturnValueOnce({
      subscriptionItems: {
        availableItems: [
          {
            amount: 1,
            code: 'SOT-SA-BA-BAS',
            desc: 'TestDescription',
            id: 42,
            prices: [
              {
                currency: 'USD',
                frequency: 'MONTHLY',
                ranges: [{ fromQuantity: 0, price: 1, type: 'Volume' }],
                type: undefined,
              },
            ],
            productTier: 'Professional',
            required: true,
            revenueType: 'SaaS',
            supportLevel: 'Silver',
            title: undefined,
            type: 'Recurring',
          },
          {
            amount: 0,
            code: 'SOT-SA-BA-SIL',
            desc: 'TestDescription',
            id: 43,
            prices: [{ currency: 'USD', frequency: 'MONTHLY', ranges: [], type: undefined }],
            productTier: undefined,
            required: true,
            revenueType: undefined,
            supportLevel: 'Silver',
            title: undefined,
            type: 'Recurring',
          },
        ],
        supportItems: [],
        mainItem: {
          item: {
            amount: 1,
            code: 'SOT-SA-BA-BAS',
            desc: 'TestDescription',
            id: 42,
            prices: [
              {
                currency: 'USD',
                frequency: 'MONTHLY',
                ranges: [{ fromQuantity: 0, price: 1, type: 'Volume' }],
                type: undefined,
              },
            ],
            productTier: 'Professional',
            required: true,
            revenueType: 'SaaS',
            supportLevel: 'Silver',
            title: undefined,
            type: 'Recurring',
          },
        },
        supportItem: {
          amount: 0,
          code: 'SOT-SA-BA-SIL',
          desc: 'TestDescription',
          id: 43,
          prices: [{ currency: 'USD', frequency: 'MONTHLY', ranges: [], type: undefined }],
          productTier: undefined,
          required: true,
          revenueType: undefined,
          supportLevel: 'Silver',
          title: undefined,
          type: 'Recurring',
        },
      },
      includedItems: [
        { code: 'SOT-SA-BA-BAS', id: 42, quantity: 2 },
        { code: 'SOT-SA-BA-SIL', id: 43, quantity: 2 },
      ],
    });
    (subscriptionPlanUtility.getSubscriptionPlanById as any).mockReturnValueOnce({
      items: [
        {
          code: 'TES-SA-IT1-STA',
          id: 321,
          required: true,
          productTier: ProductTier.Standard,
          isMainItem: true,
          isSupportItem: false,
        },
        { code: 'TES-SA-IT1-SIL', id: 322, supportLevel: SupportLevel.Silver, isMainItem: false, isSupportItem: true },
      ],
      productTier: ProductTier.Standard,
      isLegacyPlan: false,
    });
    const res = exposePrivate(subscriptionGetUtility).buildSubscription({
      fields: {
        customer: '123',
        renewalnumber: 33,
        billingsubscriptionstatus: 'ACTIVE'
      },
      sublists: {
        priceinterval: { 'line 1': { linenumber: 1 } },
        subscriptionline: { 'line 1': { linenumber: 1, item: '42', isincluded: 'F', supportlevelid: 22 } },
      },
    });
    expect(res).toEqual(expect.objectContaining({ renewalNumber: 33 }));
  });

  /**
   * Create initial data for the subscription.preveiew tests
   */
  function preparePreviewTest(): void {
    const testItems = [
      {
        id: 75865,
        code: 'SOT-SA-USE-STA',
        required: true,
        type: 'Recurring',
        prices: [
          {
            type: 'Tiered',
            frequency: 'MONTHLY',
            currency: 'USD',
            ranges: [
              {
                type: 'Rate',
                fromQuantity: 0,
                price: 14.99,
              },
            ],
          },
          {
            type: 'Tiered',
            frequency: 'ANNUALLY',
            currency: 'USD',
            ranges: [
              {
                type: 'FixedAmount',
                fromQuantity: 0,
                price: 1000,
              },
              {
                type: 'Rate',
                fromQuantity: 1000,
                price: 12,
              },
            ],
          },
        ],
      },
      {
        id: 75865,
        code: 'SOT-SA-USE-GOL',
        SupportLevel: SupportLevel.Gold,
        required: true,
        type: 'Recurring',
        prices: [
          {
            type: 'Tiered',
            frequency: 'MONTHLY',
            currency: 'USD',
            ranges: [
              {
                type: 'Rate',
                fromQuantity: 0,
                price: 3.00,
              },
            ],
          },
          {
            type: 'Tiered',
            frequency: 'ANNUALLY',
            currency: 'USD',
            ranges: [
              {
                type: 'FixedAmount',
                fromQuantity: 0,
                price: 200,
              },
              {
                type: 'Rate',
                fromQuantity: 1000,
                price: 2.4,
              },
            ],
          },
        ],
      },
      {
        id: 75869,
        code: 'SOT-SA-MED-STA',
        required: false,
        type: 'Recurring',
        prices: [
          {
            type: 'Tiered',
            frequency: 'MONTHLY',
            currency: 'USD',
            ranges: [
              {
                type: 'Rate',
                fromQuantity: 0,
                price: 5,
              },
            ],
          },
          {
            type: 'Volume',
            frequency: 'ANNUALLY',
            currency: 'USD',
            ranges: [
              {
                type: 'Rate',
                fromQuantity: 0,
                price: 5,
              },
              {
                type: 'Rate',
                fromQuantity: 1000,
                price: 4,
              },
            ],
          },
        ],
      },
      {
        id: 75869,
        code: 'SOT-SA-MED-GOL',
        supportLevel: SupportLevel.Gold,
        required: false,
        type: 'Recurring',
        prices: [
          {
            type: 'Tiered',
            frequency: 'MONTHLY',
            currency: 'USD',
            ranges: [
              {
                type: 'Rate',
                fromQuantity: 0,
                price: 1,
              },
            ],
          },
          {
            type: 'Volume',
            frequency: 'ANNUALLY',
            currency: 'USD',
            ranges: [
              {
                type: 'Rate',
                fromQuantity: 0,
                price: 1,
              },
              {
                type: 'Rate',
                fromQuantity: 1000,
                price: 0.8,
              },
            ],
          },
        ],
      },
    ];

    (subscriptionPlanUtility.getSubscriptionPlanById as any).mockReturnValue({
      items: testItems,
      supportOnly: false,
      initialterm: {
        duration: 1,
        unit: 'YEARS',
      },
      code: 'TestPlan',
      supportLevel: SupportLevel.Gold
    });
    (nsutils.queryFirstAsMap as any).mockReturnValueOnce({ id: 321 });
    jest.spyOn(subscriptionDao, 'getCurrency').mockReturnValueOnce({ id: 1, symbol: 'USD' });
    jest.spyOn(subscriptionGetUtility, 'checkSubscriptionCustomer').mockImplementation(() => {});
    jest
      .spyOn(subscriptionPlanUtility, 'findSubscriptionPlanAndPriceBook')
      .mockReturnValue({ subscriptionPlanId: 1, subscriptionPlanClass: 1, priceBookId: 1, subsidiaries: ['22'] });
    jest.spyOn(subscriptionPriceUtility, 'getCurrentDiscount').mockReturnValueOnce(undefined as any);
    jest.spyOn(subscriptionGetUtility, 'getSubscriptionByIdInternal').mockReturnValue({
      status: 'ACTIVE',
      plan: { id: 1 },
      term: { initialTermDuration: 1, initialTermUnits: TermUnit.YEARS },
    } as any);
    jest.spyOn(subscriptionValidateUtility, 'validateSubscriptionItems').mockImplementation(() => {});
    jest.spyOn(record, 'load').mockReturnValue({
      id: 1,
      sublists: { priceinterval: [], subscriptionline: [] },
      fields: { subscriptionplan: 1 },
      getValue: (s) => {
        switch (s) {
          case 'initialtermtype':
            return SubscriptionTermType.STANDARD;
          case 'initialtermduration':
            return 1;
          case 'initialtermunits':
            return TermUnit.YEARS;
          default:
            return 'ACTIVE';
        }
      },
      getSublistValue: () => 1,
    } as any);
    jest.spyOn(subscriptionGetUtility, 'getSubscriptionRecItems').mockReturnValue({
      planId: 1,
      planItems: testItems,
      planInfo: {
        isSupportOnlyPlan: false,
        initialTermDuration: 1,
        initialTermUnits: TermUnit.YEARS,
      },
      subscriptionItems: {
        availableItems: [],
        supportItems: [],
        mainItem: undefined,
        supportItem: undefined,
      },
    } as any);
    jest.spyOn(subscriptionValidateUtility, 'validateUpdateActive').mockReturnValue({ isDowngrade: false });
  }

  it('preview-', () => {
    preparePreviewTest();
    (nsutils.queryFirstToJson as any).mockReturnValueOnce({itemid: 1});
    jest.spyOn(OperationUtils, 'callAndGetContent').mockReturnValueOnce({totalAmount: 5000});
    const res = Subscription.preview({
      subscriptionId: 1,
      customerId: 'TestCustomer',
      content: {
        planCode: 'TestPlan',
        planId: 1,
        frequency: 'ANNUALLY',
        items: [
          {
            code: 'SOT-SA-USE-STA',
            quantity: 1000,
          },
          {
            code: 'SOT-SA-MED-STA',
            quantity: 1005,
          },
        ],
      },
    });

    expect(res).toStrictEqual({
      content: {
        frequency: 'ANNUALLY',
        totalAmount: 6024,
        items: [
          {
            code: 'SOT-SA-USE-STA',
            quantity: 1000,
            amount: 1200,
            title: undefined,
          },
          {
            code: 'SOT-SA-MED-STA',
            quantity: 1005,
            amount: 4824,
            title: undefined,
          },
        ],
        successPlanPremium: 1024,
        totalListPrice: 6024
      },
    });
  });

  it('preview with zero quantity', () => {
    // Check that zero-quantity items are ignored
    preparePreviewTest();
    const res = Subscription.preview({
      subscriptionId: 1,
      customerId: 'TestCustomer',
      content: {
        planCode: 'TestPlan',
        planId: 1,
        frequency: 'ANNUALLY',
        items: [
          {
            code: 'SOT-SA-USE-STA',
            quantity: 1000,
          },
          {
            code: 'SOT-SA-MED-STA',
            quantity: 0,
          },
        ],
      },
    });

    expect(res).toStrictEqual({
      content: {
        frequency: 'ANNUALLY',
        totalAmount: 1200,
        items: [
          {
            code: 'SOT-SA-USE-STA',
            quantity: 1000,
            amount: 1200,
            title: undefined,
          },
        ],
        successPlanPremium: 0,
        totalListPrice: 1200
      },
    });
  });

  it('preview discount renewal', () => {
    const testItems = [
      {
        id: 75865,
        code: 'SOT-SA-USE-STA',
        required: true,
        type: 'Recurring',
        typeId: 1,
        prices: [
          {
            type: 'Tiered',
            frequency: 'MONTHLY',
            currency: 'USD',
            ranges: [
              {
                priceplanid: 1,
                type: 'Rate',
                fromQuantity: 0,
                price: 14.99,
              },
            ],
          },
          {
            type: 'Tiered',
            frequency: 'ANNUALLY',
            currency: 'USD',
            ranges: [
              {
                priceplanid: 1,
                type: 'FixedAmount',
                fromQuantity: 0,
                price: 1000,
              },
              {
                priceplanid: 2,
                type: 'Rate',
                fromQuantity: 1000,
                price: 12,
              },
            ],
          },
        ],
      },
      {
        id: 75869,
        code: 'SOT-SA-MED-STA',
        required: false,
        type: 'Recurring',
        typeId: 1,
        prices: [
          {
            type: 'Tiered',
            frequency: 'MONTHLY',
            currency: 'USD',
            ranges: [
              {
                priceplanid: 1,
                type: 'Rate',
                fromQuantity: 0,
                price: 5,
              },
            ],
          },
          {
            type: 'Volume',
            frequency: 'ANNUALLY',
            currency: 'USD',
            ranges: [
              {
                priceplanid: 1,
                type: 'Rate',
                fromQuantity: 0,
                price: 5,
              },
              {
                priceplanid: 2,
                type: 'Rate',
                fromQuantity: 1000,
                price: 4,
              },
            ],
          },
        ],
      },
    ];

    (subscriptionPlanUtility.getSubscriptionPlanById as any).mockReturnValue({
      items: testItems,
      supportOnly: false,
    });
    (nsutils.queryFirstAsMap as any).mockReturnValueOnce({ id: 321 });
    jest.spyOn(subscriptionDao, 'getCurrency').mockReturnValueOnce({ id: 1, symbol: 'USD' });
    jest.spyOn(subscriptionValidateUtility, 'validateAndPrepareUpdateData').mockImplementation(() => {});
    jest.spyOn(subscriptionPriceUtility, 'getCurrentDiscount').mockReturnValueOnce(undefined as any);
    jest.spyOn(subscriptionGetUtility, 'getSubscriptionByIdInternal').mockReturnValue({
      id: 1,
      plan: { id: 1 },
      term: {
        start: '11-Jun-2023',
        end: '11-Jun-2024',
        initialTermDuration: 1,
        initialTermUnits: TermUnit.YEARS,
      },
      status: 'DRAFT',
      fields: { subscriptionplan: 1 },
      parentSubscription: { id: 2 },
    } as any);
    jest.spyOn(subscriptionValidateUtility, 'isDowngrade').mockReturnValue(false);
    jest.spyOn(subscriptionPriceUtility, 'calcModifiedPrices').mockReturnValue(null);
    jest
      .spyOn(ProductIntegration, 'getProductIntegration')
      .mockReturnValue({ nsClass: { id: 1, name: 'USD', fullname: 'Dollar' }, isUptickEnabled: true });

    jest.spyOn(record, 'load').mockReturnValue({
      id: 1,
      sublists: { priceinterval: [], subscriptionline: [] },
      fields: { subscriptionplan: 1 },
      getValue: () => {
        return 'ACTIVE';
      },
      getSublistValue: () => 1,
    } as any);
    jest.spyOn(subscriptionValidateUtility, 'validateSubscriptionItems').mockImplementation(() => {});
    jest.spyOn(record, 'load').mockReturnValue({
      id: 1,
      sublists: { priceinterval: [], subscriptionline: [] },
      fields: { subscriptionplan: 1 },
      getValue: () => {
        return 'ACTIVE';
      },
      getSublistValue: () => 1,
    } as any);
    jest.spyOn(subscriptionGetUtility, 'getSubscriptionRecItems').mockReturnValue({
      planId: 1,
      planItems: testItems,
      planInfo: {
        isSupportOnlyPlan: false,
      },
      subscriptionItems: {
        availableItems: [],
        supportItems: [],
        mainItem: undefined,
        supportItem: undefined,
      },
    } as any);
    jest.spyOn(subscriptionValidateUtility, 'validateUpdateActive').mockReturnValue({ isDowngrade: false });
    const res = Subscription.preview({
      subscriptionId: 1,
      customerId: 'TestCustomer',
      content: {
        planCode: 'TestPlan',
        frequency: 'ANNUALLY',
        items: [
          {
            code: 'SOT-SA-USE-STA',
            quantity: 1000,
          },
          {
            code: 'SOT-SA-MED-STA',
            quantity: 1005,
          },
        ],
      },
    });

    expect(res).toEqual({
      content: {
        frequency: 'ANNUALLY',
        totalAmount: 5020,
        items: [
          {
            code: 'SOT-SA-USE-STA',
            quantity: 1000,
            amount: 1000,
            title: undefined,
          },
          {
            code: 'SOT-SA-MED-STA',
            quantity: 1005,
            amount: 4020,
            title: undefined,
          },
        ],
        successPlanPremium: 0,
        totalListPrice: 5020
      },
    });
  });

  it('preview invalid subscription', () => {
    (subscriptionPlanUtility.getSubscriptionPlanById as any).mockReturnValue({
      items: [
        {
          code: 'SOT-SA-USE-STA',
          id: 321,
          required: true,
          prices: [
            {
              type: 'Tiered',
              frequency: 'ANNUALLY',
              currency: 'USD',
              ranges: [
                {
                  type: 'Rate',
                  fromQuantity: 0,
                  price: 1000,
                },
              ],
            },
          ],
        },
        {
          code: 'SOT-SA-MED-STA',
          id: 322,
          supportLevel: SupportLevel.Silver,
          prices: [
            {
              type: 'Tiered',
              frequency: 'ANNUALLY',
              currency: 'USD',
              ranges: [
                {
                  type: 'Rate',
                  fromQuantity: 0,
                  price: 200,
                },
              ],
            },
          ],
        },
      ],
      supportOnly: false,
    });
    (nsutils.queryFirstAsMap as any).mockReturnValueOnce({ id: 321 });
    jest.spyOn(subscriptionValidateUtility, 'validateAndPrepareUpdateData').mockImplementation(() => {});
    jest
      .spyOn(subscriptionGetUtility, 'getSubscriptionByIdInternal')
      .mockReturnValue({ plan: { id: 1 }, status: 'TERMINATED' } as any);
    jest.spyOn(subscriptionValidateUtility, 'validateSubscriptionItems').mockImplementation(() => {});
    jest.spyOn(record, 'load').mockReturnValue({
      id: 1,
      sublists: { priceinterval: [], subscriptionline: [] },
      fields: { subscriptionplan: 1 },
      getValue: () => {
        return 'ACTIVE';
      },
      getSublistValue: () => 1,
    } as any);
    jest.spyOn(subscriptionGetUtility, 'getSubscriptionRecItems').mockReturnValue({
      planId: 1,
      planItems: [],
      planInfo: {
        isSupportOnlyPlan: false,
      },
      subscriptionItems: {
        availableItems: [],
        supportItems: [],
        mainItem: undefined,
        supportItem: undefined,
      },
    } as any);
    jest.spyOn(subscriptionValidateUtility, 'validateUpdateActive').mockReturnValue({ isDowngrade: false });
    expect(() => {
      Subscription.preview({
        subscriptionId: 1,
        customerId: 'TestCustomer',
        content: {
          planCode: 'TestPlan',
          frequency: 'ANNUALLY',
          items: [
            {
              code: 'SOT-SA-USE-STA',
              quantity: 1000,
            },
            {
              code: 'SOT-SA-MED-STA',
              quantity: 1005,
            },
          ],
        },
      });
    }).toThrowError('Not possible to use this method in subscription with status TERMINATED');
  });

  it('createDraftRenewal', () => {
    const params = {
      subscriptionId: 1,
      customerId: '1',
    };
    jest.spyOn(record, 'load').mockReturnValue({
      getValue: () => {
        return 'ACTIVE';
      },
      getSublistValue: () => 1,
    } as any);
    (record.create as any).mockReturnValue({
      getValue: () => 1,
      setValue: () => {},
      save: () => {},
    });
    jest.spyOn(subscriptionGetUtility, 'getSubscriptionByIdInternal').mockReturnValue('Test' as any);
    // (subscriptionGetUtility.getSubscriptionByIdInternal as any).mockReturnValue('Test');
    const res = Subscription.createDraftRenewal(params);
    expect(res).toStrictEqual({ content: 'Test' });
  });

  it('modifyPrice', () => {
    let line = 0;
    jest.spyOn(record, 'load').mockReturnValueOnce({
      getLineCount: () => 2,
      getCurrentSublistValue: (a) => {
        switch (a.fieldId) {
          case 'status':
            line++;
            if (line == 1) {
              return 'ACTIVE';
            }
            return 'DRAFT';
          case 'item':
            return line.toString();
        }
      },
      setCurrentSublistValue: () => {},
      commitLine: () => {},
      save: () => {},
      selectLine: () => {},
    } as any);
    (record.create as any).mockReturnValueOnce({
      getLineCount: () => 1,
      getCurrentSublistValue: () => 1,
      setCurrentSublistValue: () => {},
      commitLine: () => {},
      save: () => {},
      selectLine: () => {},
      setValue: () => {},
    });
    jest.spyOn(subscriptionPriceUtility, 'applyDiscount').mockReturnValue(1);

    const res = Subscription.modifyPrice({ subscriptionId: 1, reducePercentage: 0.5, effectiveDate: getISODate() });
    expect(res).toStrictEqual({
      content: true,
    });
  });

  it('applyNewPlanOnExistingSubscription', () => {
    const subscriptionRec = {
      fields: {
        subscriptionplan: '',
        currency: '',
      },
      sublists: {
        priceinterval: {
          'line 1': {
            item_display: 'b',
          },
          'line 2': {
            item_display: 'a',
          },
        },
        subscriptionline: {
          'line 1': {
            item_display: 'b',
          },
          'line 2': {
            item_display: 'a',
          },
        },
      },
    };
    Object.getPrototypeOf(Subscription).applyNewPlanOnExistingSubscription(
      1,
      [{ code: 'a', quantity: 2, id: 1 }],
      [
        {
          id: 1,
          code: 'a',
          typeId: 1,
          prices: [
            {
              ranges: [
                {
                  priceplanid: 1,
                  price: 1,
                },
              ],
            },
          ],
        },
      ],
      1,
      'ANNUALLY',
      subscriptionRec
    );
    expect(subscriptionRec.fields.subscriptionplan).toBe('1');
  });

  it('updateStatus', async () => {
    jest
      .spyOn(SubscriptionGetUtility, 'getSubscriptionByIdForCustomer')
      .mockReturnValueOnce({ content: { id: 1 } } as any);
    const sr = new SubscriptionRecordMock(
      {
        endUser: 1,
        status: SubscriptionStatus.DRAFT,
        contractDocs: 1,
      },
      [{ included: true, status: SubscriptionLineStatus.DRAFT }]
    ) as any;
    jest.spyOn(SubscriptionRecord, 'load').mockReturnValueOnce(sr);
    Subscription.updateStatus({
      customerId: '1',
      subscriptionId: 1,
      content: {
        status: SubscriptionStatus.ACTIVE,
      },
    });
    expect(sr).toEqual(
      expect.objectContaining({
        lines: expect.arrayContaining([
          {
            included: true,
            status: 'PENDING_ACTIVATION',
          },
        ]),
      })
    );
  });

  it('SupportLevel conversion', async () => {
    const a = SupportLevel['Silver'] as unknown;
    expect(a).toBe(SupportLevel.Silver);
  });

  it('internalDeleteDraftSubscription', () => {
    jest.spyOn(SubscriptionRecord, 'load').mockReturnValueOnce(
      new SubscriptionRecordMock(
        {
          status: SubscriptionStatus.ACTIVE,
        },
        []
      ) as any
    );
    let result = Subscription.internalDeleteDraftSubscription({
      subscriptionId: 1,
    });
    expect(result).toEqual({
      content: {
        success: false,
        error: 'You cannot delete this subscription. The subscription is not in draft status.',
      },
    });

    jest.spyOn(SubscriptionRecord, 'load').mockReturnValueOnce(
      new SubscriptionRecordMock(
        {
          status: SubscriptionStatus.DRAFT,
        },
        [{
          status: 'ACTIVE'
        }]
      ) as any
    );
    result = Subscription.internalDeleteDraftSubscription({
      subscriptionId: 1,
    });
    expect(result).toEqual({
      content: {
        success: false,
        error: 'You cannot delete this subscription. The subscription has an activation or termination change order.',
      },
    });

    jest.spyOn(SubscriptionRecord, 'load').mockReturnValue(
      new SubscriptionRecordMock(
        {
          status: SubscriptionStatus.DRAFT,
        },
        []
      ) as any
    );
    result = Subscription.internalDeleteDraftSubscription({
      subscriptionId: 1,
    });
    expect(result).toEqual({
      content: {
        success: true,
      },
    });

    jest.spyOn(SubscriptionRecord, 'load').mockReturnValueOnce(
      new SubscriptionRecordMock(
        {
          status: SubscriptionStatus.DRAFT,
        },
        []
      ) as any
    );
    jest.spyOn(subscriptionUtility, 'deleteDraftSubscription').mockImplementationOnce(() => {
      throw new Error('test error');
    });
    result = Subscription.internalDeleteDraftSubscription({
      subscriptionId: 1,
    });
    expect(result).toEqual({
      content: {
        success: false,
        error: 'test error',
      },
    });
  });

  it('ItemCode', () => {
    const code = new ItemCode('TES-SA-TES-STA');

    expect(code.codeWOSuffix()).toBe('TES-SA-TES');
    expect(code.toString()).toBe('TES-SA-TES-STA');
    expect(code.isDifferentOnlyInSuffix(new ItemCode('TES-SA-TES-SIL'))).toBeTruthy();
    expect(code.isSupport()).toBe(false);
  });

  it('getQuantityFromItemOrFromExistingSubscription', () => {
    const newItem = {
      code: 'DNNE-SA-Cus-STA',
    };
    const supportItem = {
      code: 'DNNE-SA-Cus-SIL',
    };
    const addonItem = {
      code: 'DNNE-SA-Sub-ADD',
    };
    const newPlan = {
      items: [
        {
          code: 'DNNE-SA-Cus-STA',
          isMainItem: true,
        },
        {
          code: 'DNNE-SA-Cus-SIL',
          isMainItem: false,
          isSupportMainItem: true,
        },
        {
          code: 'DNNE-SA-Sub-ADD',
          isMainItem: false,
          isSupportMainItem: false,
        },
      ],
    };
    const subscriptionItems = [
      {
        code: 'DNNE-SA-Cus-STA',
        isMainItem: true,
        quantity: 10,
      },
      {
        code: 'DNNE-SA-Cus-SIL',
        isSupportMainItem: true,
        quantity: 5,
      },
      {
        code: 'DNNE-SA-Sub-ADD',
        isMainItem: false,
        isSupportMainItem: false,
        quantity: 7,
      },
    ];
    const invalidSubscriptionItems = [
      {
        code: 'DNNE-SA-Cus-STA',
        quantity: 10,
      },
    ];
    let res = exposePrivate(Subscription).getQuantityFromItemOrFromExistingSubscription(
      newItem,
      newPlan,
      subscriptionItems
    );
    expect(res).toBe(10);

    expect(() => {
      exposePrivate(Subscription).getQuantityFromItemOrFromExistingSubscription(
        newItem,
        newPlan,
        invalidSubscriptionItems
      );
    }).toThrowError('quantity of the main item with code DNNE-SA-Cus-STA was not found in the subscription');

    res = exposePrivate(Subscription).getQuantityFromItemOrFromExistingSubscription(
      supportItem,
      newPlan,
      subscriptionItems
    );
    expect(res).toBe(5);

    res = exposePrivate(Subscription).getQuantityFromItemOrFromExistingSubscription(supportItem, newPlan, [
      subscriptionItems[0],
    ]);
    expect(res).toBe(10);

    expect(() => {
      exposePrivate(Subscription).getQuantityFromItemOrFromExistingSubscription(
        supportItem,
        newPlan,
        invalidSubscriptionItems
      );
    }).toThrowError('quantity of the support item with code DNNE-SA-Cus-SIL was not found in the subscription');

    res = exposePrivate(Subscription).getQuantityFromItemOrFromExistingSubscription(
      addonItem,
      newPlan,
      subscriptionItems
    );
    expect(res).toBe(7);

    expect(() => {
      exposePrivate(Subscription).getQuantityFromItemOrFromExistingSubscription(
        addonItem,
        newPlan,
        invalidSubscriptionItems
      );
    }).toThrowError('quantity of the item with code DNNE-SA-Sub-ADD was not found in the subscription');
  });

  it('internalActivate', () => {
    (record.load as any).mockImplementation(() => {
      return new RecordDynamicMock({ subscriptionline: [] }, {});
    });
    (record.create as any).mockImplementation(() => {
      return new RecordDynamicMock({ subline: [] }, {});
    });
    const res = Subscription.internalActivate({ subscriptionId: 1 });
    expect(res).toEqual({ content: true });
  });

  it('setPrice', () => {
    (record.load as any).mockImplementation(() => {
      return new RecordDynamicMock(
        {
          priceinterval: [
            { status: 'PENDING_ACTIVATION' },
            { status: 'DRAFT', item: '1' },
            { status: 'DRAFT', item: '2' },
          ],
        },
        {}
      );
    });
    (record.create as any).mockImplementation(() => {
      return new RecordDynamicMock({ pricetiers: [] }, {});
    });
    jest.spyOn(nsutils, 'queryToJson').mockReturnValue([{ id: 1, code: 'SA' }]);

    const res = Subscription.internalSetPrice({ subscriptionId: 1, items: [{ code: 'SA', price: 1 }] });
    expect(res).toEqual({ content: true });
  });

  it('auto renewal evergreen', () => {
    const sub = new RecordDynamicMock(
      {},
      {
        initialtermtype: 'EVERGREEN',
      }
    ) as any;
    subscriptionCreateUtility.setAutoRenewal(sub);
    expect(sub.fields.autorenewal).toBe(false);
  });

  it('internalCreateRenewalChangeOrder should create a renewal change order with all parameters', () => {
    const params = {
      subscriptionId: 12,
      renewalMethod: 'Auto-Renew',
      modificationType: 'Renewal',
      renewalTerm: 12,
      subline: 'Basic',
      renewalPlan: 123,
      renewalPriceBook: 123,
      customer: 123,
      billingAccount: 123
    };
    const createRenewChangeOrder = jest.spyOn(SubscriptionChangeOrderUtility, 'createRenewChangeOrder').mockImplementation(() => {
      return {
        id: 1
      } as any
    });
    const response = Subscription.internalCreateRenewalChangeOrder(params);
    expect(createRenewChangeOrder).toHaveBeenCalledWith(
      12,
      {
        renewalmethod: 'Auto-Renew',
        modificationtype: 'Renewal',
        renewalterm: 12,
        subline: 'Basic',
        renewalplan: 123,
        renewalpricebook: 123,
        customer: 123,
        billingaccount: 123
      }
    );
    expect(response).toEqual({
      content: {
        changeOrderId: 1
      }
    });
  });

  it('internalCreateRenewalChangeOrder should not add optional parameters if not provided', () => {
    const params = {
      subscriptionId: 12,
      renewalMethod: 'Auto-Renew',
      modificationType: 'Renewal',
      renewalTerm: 12,
      subline: 'Basic'
    };
    const createRenewChangeOrder = jest.spyOn(SubscriptionChangeOrderUtility, 'createRenewChangeOrder').mockImplementation(() => {
      return {
        id: 1
      } as any
    });
    const response = Subscription.internalCreateRenewalChangeOrder(params);
    expect(createRenewChangeOrder).toHaveBeenCalledWith(
      12,
      {
        renewalmethod: 'Auto-Renew',
        modificationtype: 'Renewal',
        renewalterm: 12,
        subline: 'Basic'
      }
    );
    expect(response).toEqual({
      content: {
        changeOrderId: 1
      }
    });
  });

  it('internalGetItems should return empty array when subscription record has no items', () => {
    const mockSubscriptionId = '123';
    const params = { subscriptionId: mockSubscriptionId } as any;

    const mockSubscriptionRecord = {
      fields: { subscriptionplan: '1' },
      sublists: { priceinterval: [], subscriptionline: [] },
    };

    jest.spyOn(record,'load').mockReturnValue(mockSubscriptionRecord as any);
    jest.spyOn(subscriptionPlanUtility,'getSubscriptionPlanById').mockReturnValue({} as any);

    const response = Subscription.internalGetItems(params) as any;
    expect(response.content.items).toEqual([]);
  });

  it('internalGetItems should set the first item as the main item when no main item is found', () => {
    const mockSubscriptionId = '123';
    const params = { subscriptionId: mockSubscriptionId } as any;
  
    const mockSubscriptionRecord = {
      fields: { subscriptionplan: '1' },
      sublists: {
        priceinterval: {
          'line 1': { linenumber: 1, item_display: 'code1', recurringamount: 10, frequency: 'ANNUALLY', repeatevery: 1 },
          'line 2': { linenumber: 2, item_display: 'code2', recurringamount: 10, frequency: 'ANNUALLY', repeatevery: 1 }
        },
        subscriptionline: []
      },
    }
  
    jest.spyOn(record,'load').mockReturnValue(mockSubscriptionRecord as any);
    jest.spyOn(subscriptionPlanUtility,'getSubscriptionPlanById').mockReturnValue({} as any);
  
    const response = Subscription.internalGetItems(params) as any;
    expect(response.content.items[0].isMainItem).toEqual(true);
  });

  it('internalGetItems should properly format the item', () => {
    const mockSubscriptionId = '123';
    const params = { subscriptionId: mockSubscriptionId } as any;
  
    const mockSubscriptionRecord = {
      fields: { subscriptionplan: '1' },
      sublists: { priceinterval: { 
        'line 1': { linenumber: 1, item_display: 'part1-part2-part3-STA', recurringamount: 100.00457, startdate: '1-May-2023', status: 'ACTIVE', frequency: 'ANNUALLY', repeatevery: 1 },
        'line 2': { linenumber: 1, item_display: 'part1-part2-part3-STA', recurringamount: 20, startdate: '1-May-2022', frequency: 'ANNUALLY', repeatevery: 1 },
        'line 3': { linenumber: 2, item_display: 'pr1-pr2-pr3-PLA', recurringamount: 0, frequency: 'WEEKLY', repeatevery: 1 },
        'line 4': { linenumber: 3, item_display: 'part1-part2-part3-STA', recurringamount: 30, status: 'ACTIVE', frequency: 'MONTHLY', repeatevery: 3 },
        'line 5': { linenumber: 4, item_display: 'part1-part2-part3-SIL', recurringamount: -30, status: 'ACTIVE',frequency: 'MONTHLY', repeatevery: 3 },
        'line 6': { linenumber: 5, item_display: 'pr1-pr2-pr3-PLA', recurringamount: 0, frequency: 'WEEKLY', repeatevery: 1 },
      },
      subscriptionline: []},
    };
  
    jest.spyOn(record,'load').mockReturnValue(mockSubscriptionRecord as any);
    jest.spyOn(subscriptionPlanUtility,'getSubscriptionPlanById').mockReturnValue({} as any);
  
    const response = Subscription.internalGetItems(params) as any;
    const expectedBundleCode = 'part1-part2-part3-STA-SIL';
    const expectedARR = 100.00;
    const expectedSupportBundleCode = 'pr1-pr2-pr3-STA-PLA-MNT';

    expect(response.content.items[0].bundleCode).toEqual(expectedBundleCode);
    expect(response.content.items[0].ARR).toEqual(expectedARR);
    expect(response.content.items[0].isSupportItem).toBeUndefined();
    expect(response.content.items[0].isSupportMainItem).toBeUndefined();
    expect(response.content.items[0].productTier).toBeUndefined();
    expect(response.content.items[0].supportLevel).toBeUndefined();
    expect(response.content.items[0].lineNumber).toBeUndefined();

    expect(response.content.items[1].bundleCode).toEqual(expectedSupportBundleCode);
  });

  it('changeSubscriptionQuoteLinks', () => {
    jest.spyOn(nsutils, 'queryToJson').mockReturnValueOnce([1,2]);
    const mockLoad = jest.spyOn(record,'load').mockReturnValue({
      setValue: () => {},
      save: () => {}
    } as any);
    const mockFn = jest.spyOn(subscriptionUtility,'changeSubscriptionQuoteLinks');
    const response = Subscription.changeQuoteLink({
      oldSubscriptionId: 3,
      newSubscriptionId: 4,
    });
    expect(mockFn).toHaveBeenCalledTimes(1);
    expect(mockFn).toHaveBeenCalledWith(3, 4);
    expect(mockLoad).toHaveBeenCalledTimes(2);
    expect(response).toEqual({ content: true });
  });

  it('findSuitableSubsidiary should return the correct subsidiary ID', () => {
    // Arrange
    const params = {
      customerId: 11,
      classId: 21,
      parentSubscriptionId: 31,
    };
    const entityId = '11';
    jest.spyOn(customerDao, 'getEntityId').mockReturnValue('11');
    const subsidiaryId = 1;
    jest.spyOn(subscriptionCreateUtility, 'findSuitableSubsidiary').mockReturnValue(subsidiaryId);

    // Act
    const result = Subscription.findSuitableSubsidiary(params);

    // Assert
    expect(customerDao.getEntityId).toHaveBeenCalledWith(params.customerId);
    expect(subscriptionCreateUtility.findSuitableSubsidiary).toHaveBeenCalledWith(entityId, params.classId, params.parentSubscriptionId);
    expect(result).toEqual({ content: { subsidiaryId: subsidiaryId } });
  });

  it('findSuitableSubsidiary should throw an error when customer is not found', () => {
    // Arrange
    const params = {
      customerId: 11,
      classId: 21,
      parentSubscriptionId: 31,
    };
    jest.spyOn(customerDao, 'getEntityId').mockReturnValue(undefined);

    // Act
    const action = () => Subscription.findSuitableSubsidiary(params);

    // Assert
    expect(action).toThrowError(`Customer with id ${params.customerId} not found`);
    expect(customerDao.getEntityId).toHaveBeenCalledWith(params.customerId);
    expect(subscriptionCreateUtility.findSuitableSubsidiary).not.toHaveBeenCalled();
  });

  it('uploadContractualDocument should throw an error if a mandatory param is missing', () => {
    // Arrange
    const params = {
      customerId: "101",
      subscriptionId: 201,
      content: {
        type: ContractualDocumentType.PurchaseOrder,
        filename: "test.pdf",
        contents: "my-file-content-base64",
      }
    };
    const tests = [
      { deleteField: (params: any) => delete params.customerId, fieldName: 'customerId' },
      { deleteField: (params: any) => delete params.subscriptionId, fieldName: 'subscriptionId' },
      { deleteField: (params: any) => delete params.content.type, fieldName: 'type' },
      { deleteField: (params: any) => delete params.content.filename, fieldName: 'filename' },
      { deleteField: (params: any) => delete params.content.contents, fieldName: 'contents' },
    ];
    for (const test of tests) {
      const failedParams = clone(params);
      test.deleteField(failedParams);
    
      // Act
      const action = () => Subscription.uploadContractualDocument(failedParams);

      // Assert
      expect(action).toThrowError(`${test.fieldName} is mandatory`);
    }
  });

  it('uploadContractualDocument should throw an error if the document type is not supported', () => {
    // Arrange
    const params = {
      customerId: "101",
      subscriptionId: 201,
      content: {
        type: "not-supported" as ContractualDocumentType,
        filename: "test.pdf",
        contents: "my-file-content-base64",
      }
    };

    // Act
    const action = () => Subscription.uploadContractualDocument(params);

    // Assert
    expect(action).toThrowError(`Contractual document type not supported`);
  });

  it('uploadContractualDocument should throw an error if the file is not a PDF file', () => {
    // Arrange
    const params = {
      customerId: "101",
      subscriptionId: 201,
      content: {
        type: ContractualDocumentType.PurchaseOrder,
        filename: "test.unexpected",
        contents: "my-file-content-base64",
      }
    };

    // Act
    const action = () => Subscription.uploadContractualDocument(params);

    // Assert
    expect(action).toThrowError(`Contractual document must be PDF file`);
  });

  it('uploadContractualDocument should throw an error if the subscription is not writable for the customer', () => {
    // Arrange
    const params = {
      customerId: "101",
      subscriptionId: 201,
      content: {
        type: ContractualDocumentType.PurchaseOrder,
        filename: "test.pdf",
        contents: "my-file-content-base64",
      }
    };
    const subscriptionRec = {
      isWritableForCustomer: () => false,
    } as any;
    jest.spyOn(SubscriptionRecord, 'load').mockReturnValueOnce(subscriptionRec);

    // Act
    const action = () => Subscription.uploadContractualDocument(params);

    // Assert
    expect(action).toThrowError("Subscription not found or it is from another customer");
  });

  it('uploadContractualDocument should throw an error if the contractual documents does not exist', () => {
    // Arrange
    const params = {
      customerId: "101",
      subscriptionId: 201,
      content: {
        type: ContractualDocumentType.PurchaseOrder,
        filename: "test.pdf",
        contents: "my-file-content-base64",
      }
    };
    const subscriptionRec = {
      contractDocs: undefined,
      isWritableForCustomer: () => true,
    } as any;
    jest.spyOn(SubscriptionRecord, 'load').mockReturnValueOnce(subscriptionRec);

    // Act
    const action = () => Subscription.uploadContractualDocument(params);

    // Assert
    expect(action).toThrowError("Contractual documents not found");
  });

  it('uploadContractualDocument should throw an error if the document type is already attached as contractual document', () => {
    // Arrange
    const params = {
      customerId: "101",
      subscriptionId: 201,
      content: {
        type: ContractualDocumentType.PurchaseOrder,
        filename: "test.pdf",
        contents: "my-file-content-base64",
      }
    };
    const subscriptionRec = {
      contractDocs: 301,
      isWritableForCustomer: () => true,
    } as any;
    jest.spyOn(SubscriptionRecord, 'load').mockReturnValueOnce(subscriptionRec);
    jest.spyOn(ContractualDocumentsService, 'containsDocumentType').mockReturnValueOnce(true);

    // Act
    const action = () => Subscription.uploadContractualDocument(params);

    // Assert
    expect(action).toThrowError("Contractual document type already attached");
  });

  it('uploadContractualDocument should upload the file and attach it as contractual document', () => {
    // Arrange
    const params = {
      customerId: "101",
      subscriptionId: 201,
      content: {
        type: ContractualDocumentType.PurchaseOrder,
        filename: "test.pdf",
        contents: "my-file-content-base64",
      }
    };
    const subscriptionRec = {
      contractDocs: 301,
      isWritableForCustomer: () => true,
    } as any;
    jest.spyOn(SubscriptionRecord, 'load').mockReturnValueOnce(subscriptionRec);
    const prefix = ContractualDocumentTypeUtils.documentTypeToPrefix(params.content.type);
    jest.spyOn(ContractualDocumentsService, 'containsDocumentType').mockReturnValueOnce(false);
    const fileId = 401;
    jest.spyOn(FileService, 'uploadFile').mockReturnValueOnce(fileId);
    const successResponse = { content: { success: true }};
    jest.spyOn(OperationUtils, 'callAndGetContent').mockReturnValueOnce(successResponse);

    // Act
    const result = Subscription.uploadContractualDocument(params) as any;

    // Assert
    expect(result?.content).toBeDefined();
    expect(result.content.contractualDocumentsId).toEqual(subscriptionRec.contractDocs);
    expect(result.content.fileId).toEqual(fileId);
    expect(FileService.uploadFile).toHaveBeenCalledWith({
      filename: `${prefix}${params.content.filename}`,
      contents: params.content.contents,
      folder: Folder.Agreement,
    });
    expect(OperationUtils.callAndGetContent).toHaveBeenCalledWith(expect.anything(), expect.anything(), {
      contractualDocumentsId: subscriptionRec.contractDocs,
      fileId: fileId,
      signedQuote: false,
    });
  });

  it('getSubscriptionsToSync returns empty array and the same date for next sync when there are no subscriptions to sync', () => {
    const dateToSearch = '2022-01-01 00:00:00';
    const params = {
      classes: 'class1,class2',
      sinceDate: dateToSearch
    };
    const exptectedDate = '1-Jan-2022 12:00 am';
    const classIds = [{id: 1}, {id: 2}];
    

    jest.spyOn(nsutils, 'queryToJson').mockReturnValueOnce(classIds);
    const createfn = jest.spyOn(search, 'create').mockReturnValueOnce({
      run: jest.fn().mockReturnValueOnce({
        each: jest.fn()
      })
    } as any);
    const classfn = jest.spyOn(ClassDao, 'getClassIds');
    const result = Subscription.getSubscriptionsToSync(params);

    expect(classfn).toHaveBeenCalledWith(params.classes);
    expect(createfn).toHaveBeenCalledWith({
      type: 'subscription',
      filters: [
        ['datecreated', search.Operator.AFTER, exptectedDate],
        'AND',
        ['class', 'anyof', [1, 2]],
      ],
      columns: [
        'internalid',
        search.createColumn({ name: 'datecreated', sort: search.Sort.ASC })
      ]
    });
    expect(result).toEqual({
      content: {
        subscriptions: [],
        nextSearchDate: exptectedDate
      }
    });
  });

  it('getSubscriptionsToSync returns subscriptions and the next search date when there are subscriptions to sync', () => {
    const dateToSearch = '2022-01-01 00:00:00';
    const params = {
      classes: 'class1,class2',
      sinceDate: dateToSearch
    };
    const exptectedDate = '1-Jan-2022 12:00 am';
    const classIds = [{id: 1}, {id: 2}];
  
    const subscriptionResults = [
      { 
        getValue: (input) => {
          switch (input.name) {
            case 'internalid':
              return 3;
            case 'datecreated':
              return '1-Jan-2022 10:00 am';
          }
        }
      },
      { 
        getValue: (input) => {
          switch (input.name) {
            case 'internalid':
              return 4;
            case 'datecreated':
              return '1-Jan-2022 11:00 am';
          }
        }
      }
    ];
  
    const subscriptions = [
      { id: 3, class: 'class1' }
    ];
  
    jest.spyOn(nsutils, 'queryToJson').mockReturnValueOnce(classIds);
    const createfn = jest.spyOn(search, 'create').mockReturnValueOnce({
      run: jest.fn().mockReturnValueOnce({
        each: jest.fn().mockImplementationOnce((callback) => {
          subscriptionResults.forEach(callback);
        })
      })
    } as any);
    jest.spyOn(nsutils, 'queryToJson').mockReturnValueOnce(subscriptions);
    const classfn = jest.spyOn(ClassDao, 'getClassIds');
    const getSubscriptionsToSyncFn = jest.spyOn(subscriptionDao, 'getSubscriptionsToSync');

    const result = Subscription.getSubscriptionsToSync(params);
  
    expect(classfn).toHaveBeenCalledWith(params.classes);
    expect(createfn).toHaveBeenCalledWith({
      type: 'subscription',
      filters: [
        ['datecreated', search.Operator.AFTER, exptectedDate],
        'AND',
        ['class', 'anyof', [1, 2]],
      ],
      columns: [
        'internalid',
        search.createColumn({ name: 'datecreated', sort: search.Sort.ASC })
      ]
    });
    expect(getSubscriptionsToSyncFn).toHaveBeenCalledWith([3, 4]);
    expect(result).toEqual({
      content: {
        subscriptions,
        nextSearchDate: '1-Jan-2022 11:01 am',
        subscriptionSearch: [
          { id: 3, datecreated: '1-Jan-2022 10:00 am' },
          { id: 4, datecreated: '1-Jan-2022 11:00 am' }
        ]
      }
    });
  });

  it('getARR should calculate ARR correctly active', () => {
    const subscription = {
      fields: {
        subscriptionplan: '456',
      },
      sublists: {
        priceinterval: [
          { status: 'ACTIVE', recurringamount: 100, startdate: '1-Jan-2022', linenumber: 1, frequency: 'ANNUALLY', repeatevery: 1 },
          { status: 'NOT_INCLUDED', recurringamount: 200, startdate: '1-Jan-2022', linenumber: 2, frequency: 'ANNUALLY', repeatevery: 1 },
          { status: 'ACTIVE', recurringamount: 300, startdate: '1-Jan-2022', linenumber: 3, frequency: 'ANNUALLY', repeatevery: 1 },
        ],
        subscriptionline: [],
      },
    };
  
    jest.spyOn(subscriptionGetUtility, 'convertLinesToArray').mockReturnValueOnce(subscription.sublists.priceinterval);
    jest.spyOn(subscriptionPlanUtility, 'getSubscriptionPlanById').mockReturnValueOnce({} as any);
    const result =  Object.getPrototypeOf(Subscription).getARR(subscription);
    expect(result).toBe(400);
  });

  it('getARR should calculate ARR correctly terminated lines in future', () => {
    const subscription = {
      fields: {
        subscriptionplan: '456',
      },
      sublists: {
        priceinterval: [
          { status: 'ACTIVE', recurringamount: 100, startdate: '1-Jan-2022', linenumber: 1, frequency: 'ANNUALLY', repeatevery: 1 },
          { status: 'TERMINATED', recurringamount: 0, startdate: '31-Jan-2022', linenumber: 1, frequency: 'ANNUALLY', repeatevery: 1 },
        ],
        subscriptionline: [
          { linenumber: 1, status: 'ACTIVE' }
        ],
      },
    };
  
    jest.spyOn(subscriptionGetUtility, 'convertLinesToArray').mockReturnValueOnce(subscription.sublists.priceinterval);
    jest.spyOn(subscriptionGetUtility, 'convertLinesToArray').mockReturnValueOnce(subscription.sublists.subscriptionline);
    jest.spyOn(subscriptionPlanUtility, 'getSubscriptionPlanById').mockReturnValueOnce({} as any);
    const result =  Object.getPrototypeOf(Subscription).getARR(subscription);
    expect(result).toBe(100);
  });

  it('getARR should return null for non active subscriptions', () => {
    const subscription = {
      fields: {
        subscriptionplan: '456',
      },
      sublists: {
        priceinterval: [
          { status: 'DRAFT', recurringamount: 100, startdate: '1-Jan-2022', linenumber: 1, frequency: 'ANNUALLY', repeatevery: 1 },
          { status: 'NOT_INCLUDED', recurringamount: 200, startdate: '1-Jan-2022', linenumber: 2, frequency: 'ANNUALLY', repeatevery: 1 },
          { status: 'PENDING_ACTIVATION', recurringamount: 300, startdate: '1-Jan-2022', linenumber: 3, frequency: 'ANNUALLY', repeatevery: 1 },
        ],
        subscriptionline: [],
      },
    };
  
    jest.spyOn(subscriptionGetUtility, 'convertLinesToArray').mockReturnValueOnce(subscription.sublists.priceinterval);
    jest.spyOn(subscriptionPlanUtility, 'getSubscriptionPlanById').mockReturnValueOnce({} as any);
    const result =  Object.getPrototypeOf(Subscription).getARR(subscription);
    expect(result).toBe(null);
  });

  it('calculateAndSaveARR', () => {
    const subscriptionId = 123;
    const subscription = {
      id: subscriptionId,
      setValue: jest.fn(),
      save: jest.fn(),
    } as any;
    jest.spyOn(record, 'load').mockReturnValueOnce(subscription);
    spyPrivate(Subscription, 'getARR').mockReturnValueOnce(1000);
    Subscription.calculateAndSaveARRExposed({ subscriptionId });
    expect(subscription.setValue).toHaveBeenCalledWith({
      fieldId: 'custrecord_arr',
      value: 1000,
    });
    expect(subscription.save).toHaveBeenCalled();
  });
});