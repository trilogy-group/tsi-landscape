import { Subscription } from '../src/ts/Subscription';
import { afterSubmit } from '../src/ts/events/SubscriptionChangeOrderEvent';
import * as nsutils from '../src/ts/nsutils';

describe('SubscriptionChangeOrderEvent', () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  it('should return early if action is RENEW and renewalMethod is CREATE_NEW_SUBSCRIPTION', () => {
    const context = {
      newRecord: {
        getValue: ( p: {fieldId: string} ) => {
          if (p.fieldId === 'action') {
            return 'RENEW';
          }
          if (p.fieldId === 'renewalmethod') {
            return 'CREATE_NEW_SUBSCRIPTION';
          }
        },
      },
    } as any;
    const calculateAndSaveARRMock = jest.spyOn(Subscription, 'calculateAndSaveARR');
    const sendEmail = jest.spyOn(nsutils, 'sendEmail');
    afterSubmit(context);
    expect(calculateAndSaveARRMock).not.toHaveBeenCalled();
    expect(sendEmail).not.toHaveBeenCalled();
  });

  it('should send email if subscriptionId is not set', () => {
    const context = {
      newRecord: {
        getValue: jest.fn().mockReturnValue(undefined),
      },
      oldRecord: {
        getValue: jest.fn().mockReturnValue(undefined),
      },
    } as any;
    const sendEmail = jest.spyOn(nsutils, 'sendEmail');
    
    afterSubmit(context);
    expect(sendEmail).toHaveBeenCalledTimes(1);
    expect(sendEmail).toHaveBeenCalledWith(
      ['rp-si@trilogy.com'],
      'Subscription Change Order without subscription',
      'Subscription Id is not set for change order undefined'
    );
  });

  it('should send email with new record subscriptionId when it\'s there', () => {
    const context = {
      newRecord: {
        getValue: ( p: {fieldId: string} ) => {
          switch (p.fieldId) {
            case 'id':
              return 10;
            default:
              return undefined;
          }
        }
      },
      oldRecord: {
        getValue: jest.fn().mockReturnValue(undefined),
      },
    } as any;
    const sendEmail = jest.spyOn(nsutils, 'sendEmail');
    
    afterSubmit(context);
    expect(sendEmail).toHaveBeenCalledTimes(1);
    expect(sendEmail).toHaveBeenCalledWith(
      ['rp-si@trilogy.com'],
      'Subscription Change Order without subscription',
      'Subscription Id is not set for change order 10'
    );
  });

  it('should call Subscription.calculateAndSaveARR with the correct subscriptionId', () => {
    const subscriptionId = 123;
    const context = {
      newRecord: {
        getValue: jest.fn().mockReturnValue(subscriptionId),
      },
    } as any;
    const calculateAndSaveARRMock = jest.spyOn(Subscription, 'calculateAndSaveARR').mockReturnValue(undefined);
    const sendEmail = jest.spyOn(nsutils, 'sendEmail');

    afterSubmit(context);

    expect(sendEmail).not.toHaveBeenCalled();
    expect(calculateAndSaveARRMock).toHaveBeenCalledTimes(1);
    expect(calculateAndSaveARRMock).toHaveBeenCalledWith(subscriptionId);
  });
});