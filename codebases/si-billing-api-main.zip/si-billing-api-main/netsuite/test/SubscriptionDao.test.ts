import { OperationContext } from '../src/ts/models/OperationContext';
import SubscriptionDao from '../src/ts/dao/SubscriptionDao'
import * as nsutils from '../src/ts/nsutils'

describe('SubscriptionDao', () => {

  beforeEach(() => {
    jest.restoreAllMocks();
    jest.spyOn(nsutils, 'queryToJson');
    jest.spyOn(nsutils, 'queryFirstAsMap');
  })

  it('findPricesAndItemFields', () => {
    const retData = [{id: 1, code: 'TES', title:'Test Item'}];
    (nsutils.queryToJson as any).mockReturnValueOnce(retData)
    const res = SubscriptionDao.findPricesAndItemFields(1, 1)

    expect(res).toStrictEqual(retData)
  })

  it('getCustomerSubscriptionIds', () => {
    (nsutils.queryToJson as any).mockReturnValueOnce([{id: 42}])
    
    const res = SubscriptionDao.getCustomerSubscriptionIds('TestCustomer', { productFamilyCode: 'DNNT', statuses: ['ACTIVE', 'DRAFT'], isTrial: true, maxResults: 10} );
    
    expect(res).toStrictEqual([{id: 42}])
  })

  it('findSubscriptionIdsForCustomer_emptyStatus', () => {
    (nsutils.queryToJson as any).mockReturnValueOnce([{id: 42}])
    
    const res = SubscriptionDao.getCustomerSubscriptionIds('TestCustomer', {productFamilyCode: 'DNNT'});
    
    expect(res).toStrictEqual([{id: 42}])
  })

  it('findTodaysCO', () => {
    (nsutils.queryToJson as any).mockReturnValueOnce([{id: 1}])
    
    const res = SubscriptionDao.findTodaysCO(123, ['ACTIVE']);
    
    expect(res).toStrictEqual([{id: 1}])
  })

  it('getCurrentItems', () => {
    (nsutils.queryToJson as any).mockReturnValueOnce([
      {linenumber: 1, id: 4},
      {linenumber: 1, id: 1},
      {linenumber: 2, id: 5},
      {linenumber: 2, id: 2},
      {linenumber: 3, id: 6},
      {linenumber: 3, id: 3}
      ])
    
    const res = SubscriptionDao.getCurrentItems(123);
    
    expect(res).toStrictEqual([
      {linenumber: 1, id: 4},
      {linenumber: 2, id: 5},
      {linenumber: 3, id: 6},
    ])
  })

  it('findSignedQuoteId', () => {
    (nsutils.queryFirstAsMap as any).mockReturnValueOnce(
      {tid: 1, aid: 4}
    );
    const res = SubscriptionDao.findSignedQuoteId(123);
    expect(res).toBe(1);
  })

  it('isEndUserInDraftSubscriptions', () => {
    // Arrange
    const context = new OperationContext({
      customerId: '101',
      productFamilyCode: '',
      productVariantCode: '',
    });
    const endUserId = '102';
    jest.spyOn(nsutils, 'queryFirstToJson').mockReturnValueOnce({ count: '1' });

    // Act
    const result = SubscriptionDao.isEndUserInDraftSubscriptions(context, endUserId);

    // Assert
    expect(result).toBe(true);
    expect(nsutils.queryFirstToJson).toHaveBeenCalledWith(expect.anything(), expect.arrayContaining([
      endUserId,
      context.productFamilyCode,
      context.customerId,
      context.productVariantCode,
    ]));
  });

  it('getCurrency should return the subscription currency', () => {
    // Arrange
    const subscriptionId = 101;
    const currency = { id: '1', symbol: 'USD' };
    jest.spyOn(nsutils, 'queryFirstAsMap').mockReturnValueOnce(currency);

    // Act
    const result = SubscriptionDao.getCurrency(subscriptionId);

    // Assert
    expect(result).toStrictEqual(currency);
  });
})