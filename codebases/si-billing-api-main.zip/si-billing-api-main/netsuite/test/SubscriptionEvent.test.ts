import * as SubscriptionEvent from '../src/ts/events/SubscriptionEvent';
import * as record from 'N/record';
import * as nsutils from '../src/ts/nsutils';

describe('SubscriptionEvent', () => {
    const mockedSerial1 = '112233';
    const mockedSerial2 = '445566';
    let mockedLoadedRecord;

    function mockInputRecord(fields: Record<string, string>) {
        return {
            getValue: jest.fn().mockImplementation(field => {
                if (field === 'type') {
                    return 'subscription';
                }
                return fields[field] ?? null;
            }),
            toJSON: jest.fn().mockImplementation(() => ({ fields })),
            setValue: jest.fn(),
        }
    }

    function mockStoredRecord() {
        const mockedRecord = {
            setValue: jest.fn(),
            save: jest.fn(),
        }
        jest.spyOn(record, 'load').mockReturnValue(mockedRecord as any);
        return mockedRecord;
    }

    function mockContext(type: string, newFields: Record<string, string>, oldFields?: Record<string, string>): any {
        return {
            type,
            newRecord: mockInputRecord(newFields),
            oldRecord: oldFields ? mockInputRecord(oldFields) : undefined,
            UserEventType: {
                CREATE: 'create',
                EDIT: 'edit',
            }
        };
    }

    beforeEach(() => {
        jest.clearAllMocks();
    });

    it('should set Serial/License Number if event type is CREATE', () => {
        jest.spyOn(nsutils, 'queryFirstToJson').mockReturnValue({
            serial: mockedSerial1,
        } as any);

        const createContext = mockContext('create', { parentsubscription: '1' });
        const mockedStoredRecord = mockStoredRecord();

        SubscriptionEvent.afterSubmit(createContext);
        expect(mockedStoredRecord.setValue).toHaveBeenCalledWith('custrecord_serial_or_license_number', mockedSerial1);
        expect(mockedStoredRecord.save).toHaveBeenCalled();
    });

    it('should set Serial/License Number if event type is EDIT', () => {
        jest.spyOn(nsutils, 'queryFirstToJson').mockReturnValue({
            serial: mockedSerial2,
        } as any);


        const editContext = mockContext('edit', { parentsubscription: '1' }, { parentsubscription: '2' });
        const mockedStoredRecord = mockStoredRecord();

        SubscriptionEvent.afterSubmit(editContext);
        expect(mockedStoredRecord.setValue).toHaveBeenCalledWith('custrecord_serial_or_license_number', mockedSerial2);
        expect(mockedStoredRecord.save).toHaveBeenCalled();
    });

    it('should not set Serial/License Number if event type is not CREATE or EDIT', () => {
        const deleteContext = mockContext('delete', { parentsubscription: mockedSerial1 });
        const mockedStoredRecord = mockStoredRecord();

        SubscriptionEvent.afterSubmit(deleteContext);
        expect(mockedStoredRecord.setValue).not.toHaveBeenCalled();
        expect(mockedStoredRecord.save).not.toHaveBeenCalled();
    });
});
