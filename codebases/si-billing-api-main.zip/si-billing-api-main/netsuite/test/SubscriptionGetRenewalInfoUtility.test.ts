import * as nsutils from '../src/ts/nsutils';
import * as record from 'N/record';
import { ProductTier, SupportLevel } from '../src/ts/types';
import subscriptionGetRenewalInfoUtility from '../src/ts/utility/SubscriptionGetRenewalInfoUtility';
import { SubscriptionRecord } from '../src/ts/models/SubscriptionRecord';
import SubscriptionGetUtility from '../src/ts/utility/SubscriptionGetUtility';
import SubscriptionPlanDao from '../src/ts/dao/SubscriptionPlanDao';
import SubscriptionPlanUtility from '../src/ts/utility/SubscriptionPlanUtility';
import { Subscription as subscriptionOps } from '../src/ts/Subscription';

describe('SubscriptionGetRenewalInfoUtility', () => {
  beforeEach(() => {
    jest.restoreAllMocks();
  });

  it('Invalid Product Tier', () => {
    const params = {
      customerId: '123',
      subscriptionId: 456,
      productTier: 'Invalid Product Tier',
      supportLevel: SupportLevel.Gold
    }
    expect(() => subscriptionGetRenewalInfoUtility.getRenewalInfo(params)).toThrowError('Invalid Product Tier');
  });

  it('Invalid Support Level', () => {
    const params = {
      customerId: '123',
      subscriptionId: 456,
      productTier: ProductTier.Enterprise,
      supportLevel: 'Invalid Support Level'
    }
    expect(() => subscriptionGetRenewalInfoUtility.getRenewalInfo(params)).toThrowError('Invalid Support Level');
  });

  it('Subscription from another customer', () => {
    const params = {
      customerId: '123',
      subscriptionId: 456,
      productTier: ProductTier.Enterprise,
      supportLevel: SupportLevel.Platinum
    }
    jest.spyOn(SubscriptionRecord, 'load').mockReturnValueOnce({
      customerId: '789'
    } as any)
    expect(() => subscriptionGetRenewalInfoUtility.getRenewalInfo(params)).toThrowError('Subscription not found or it is from another customer');
  });

  it('Renewal Plan not defined', () => {
    const params = {
      customerId: '123',
      subscriptionId: 456,
      productTier: ProductTier.Enterprise,
      supportLevel: SupportLevel.Platinum
    };
    jest.spyOn(SubscriptionRecord, 'load').mockReturnValueOnce({
      customerId: '123'
    } as any);
    jest.spyOn(SubscriptionGetUtility, 'getSubscriptionByIdInternal').mockReturnValueOnce({
      plan: {
        id: 789,
        isLegacy: true,
      }
    } as any);
    // mock load active subscription plan
    jest.spyOn(record, 'load').mockReturnValueOnce({
      getValue: (key: string) => {
        switch (key) {
          case 'defaultrenewalplan':
            return undefined;
          case 'displayname':
            return 'Random Name';
          default:
            return undefined;
        }
      }
    } as any);

    expect(() => subscriptionGetRenewalInfoUtility.getRenewalInfo(params)).toThrowError('Renewal plan is not defined');
  });

  it('Renewal Plan is invalid', () => {
    const params = {
      customerId: '123',
      subscriptionId: 456,
      productTier: ProductTier.Enterprise,
      supportLevel: SupportLevel.Platinum
    };
    jest.spyOn(SubscriptionRecord, 'load').mockReturnValueOnce({
      customerId: '123'
    } as any);
    jest.spyOn(SubscriptionGetUtility, 'getSubscriptionByIdInternal').mockReturnValueOnce({
      plan: {
        id: 789,
        isLegacy: true,
      }
    } as any);
    // mock load active subscription plan
    jest.spyOn(record, 'load').mockReturnValueOnce({
      getValue: (key: string) => {
        switch (key) {
          case 'defaultrenewalplan':
            return '11';
          case 'displayname':
            return 'Random Name';
          default:
            return undefined;
        }
      }
    } as any);
    // mock load default renewal plan
    jest.spyOn(record, 'load').mockReturnValueOnce({
      getValue: (key: string) => {
        switch (key) {
          case 'id':
            return '11';
          case 'displayname':
            return 'Random Name';
          default:
            return undefined;
        }
      }
    } as any);

    expect(() => subscriptionGetRenewalInfoUtility.getRenewalInfo(params)).toThrowError('Renewal plan is invalid');
  });

  it('Renewal Plan not found for product tier and support level', () => {
    const params = {
      customerId: '123',
      subscriptionId: 456,
      productTier: ProductTier.Enterprise,
      supportLevel: SupportLevel.Platinum
    };
    jest.spyOn(SubscriptionRecord, 'load').mockReturnValueOnce({
      customerId: '123'
    } as any);
    jest.spyOn(SubscriptionGetUtility, 'getSubscriptionByIdInternal').mockReturnValueOnce({
      plan: {
        id: 789,
        isLegacy: true,
      }
    } as any);
    // mock load active subscription plan
    jest.spyOn(record, 'load').mockReturnValueOnce({
      getValue: (key: string) => {
        switch (key) {
          case 'defaultrenewalplan':
            return undefined;
          case 'displayname':
            return 'DNN-OP-Cus-ENT-SIL';
          case 'id':
            return '11';
          default:
            return undefined;
        }
      }
    } as any);
    
    jest.spyOn(SubscriptionPlanDao, 'getLatestSubscriptionPlan').mockReturnValueOnce(undefined);

    expect(() => subscriptionGetRenewalInfoUtility.getRenewalInfo(params)).toThrowError('Renewal plan not found for DNN-OP-Cus-ENT-SIL with Enterprise and Platinum');
  });

  it('Subscription with multiple addon items - 1', () => {
    const params = {
      customerId: '123',
      subscriptionId: 456,
      productTier: ProductTier.Enterprise,
      supportLevel: SupportLevel.Platinum
    };
    jest.spyOn(SubscriptionRecord, 'load').mockReturnValueOnce({
      customerId: '123'
    } as any);
    jest.spyOn(SubscriptionGetUtility, 'getSubscriptionByIdInternal').mockReturnValueOnce({
      plan: {
        id: 789,
        isLegacy: true,
      },
      items: [
        { id: 13, code: 'DNN-OP-Cus-ADD', isMainItem: false },
        { id: 13, code: 'DNN-OP-Cus-ADD', isMainItem: false }
      ],
      includedItems: [
        { id: 13, code: 'DNN-OP-Cus-ADD', quantity: 1 },
        { id: 13, code: 'DNN-OP-Cus-ADD', quantity: 1 }
      ]
    } as any);
    // mock load active subscription plan
    jest.spyOn(record, 'load').mockReturnValueOnce({
      getValue: (key: string) => {
        switch (key) {
          case 'defaultrenewalplan':
            return undefined;
          case 'displayname':
            return 'DNN-OP-Cus-ENT-SIL';
          case 'id':
            return '11';
          default:
            return undefined;
        }
      }
    } as any);
    jest.spyOn(SubscriptionPlanDao, 'getLatestSubscriptionPlan').mockReturnValueOnce({
      id: 12
    } as any);
    jest.spyOn(SubscriptionPlanUtility, 'getSubscriptionPlanById').mockReturnValueOnce({
      items: [
        { id: 13, code: 'DNN-OP-Cus-ADD', isMainItem: false }
      ]
    } as any);
    jest.spyOn(nsutils, 'queryToJson').mockReturnValueOnce([
      {id: 13, code: 'DNN-OP-Cus-ADD', renewId: undefined, renewCode: undefined }
    ]);

    expect(() => subscriptionGetRenewalInfoUtility.getRenewalInfo(params)).toThrowError('Subscription contains multiple items for DNN-OP-Cus-ADD');
  });

  it('Subscription with multiple addon items - 2', () => {
    const params = {
      customerId: '123',
      subscriptionId: 456,
      productTier: ProductTier.Enterprise,
      supportLevel: SupportLevel.Platinum
    };
    jest.spyOn(SubscriptionRecord, 'load').mockReturnValueOnce({
      customerId: '123'
    } as any);
    jest.spyOn(SubscriptionGetUtility, 'getSubscriptionByIdInternal').mockReturnValueOnce({
      plan: {
        id: 789,
        isLegacy: true,
      },
      items: [
        { id: 14, code: 'DNN-OP-TE-SIL', isMainItem: false },
        { id: 15, code: 'DNN-OP-TF-SIL', isMainItem: false }
      ],
      includedItems: [
        { id: 14, code: 'DNN-OP-TE-SIL', quantity: 1 },
        { id: 15, code: 'DNN-OP-TF-SIL', quantity: 1 }
      ]
    } as any);
    // mock load active subscription plan
    jest.spyOn(record, 'load').mockReturnValueOnce({
      getValue: (key: string) => {
        switch (key) {
          case 'defaultrenewalplan':
            return undefined;
          case 'displayname':
            return 'DNN-OP-Cus-ENT-SIL';
          case 'id':
            return '11';
          default:
            return undefined;
        }
      }
    } as any);
    jest.spyOn(SubscriptionPlanDao, 'getLatestSubscriptionPlan').mockReturnValueOnce({
      id: 12
    } as any);
    jest.spyOn(SubscriptionPlanUtility, 'getSubscriptionPlanById').mockReturnValueOnce({
      code: 'DNN-OP-Cus-ENT-PLA',
      productTier: ProductTier.Enterprise,
      supportLevel: SupportLevel.Platinum,
      items: [
        { id: 18, code: 'DNN-OP-TE-PLA', isMainItem: false }
      ]
    } as any);
    jest.spyOn(nsutils, 'queryToJson').mockReturnValueOnce([
      {id: 14, code: 'DNN-OP-TE-SIL', renewId: undefined, renewCode: undefined },
      {id: 15, code: 'DNN-OP-TF-SIL', renewId: 14, renewCode: 'DNN-OP-TE-SIL' }
    ]);

    expect(() => subscriptionGetRenewalInfoUtility.getRenewalInfo(params)).toThrowError('Subscription contains multiple items for DNN-OP-TE-PLA');
  });

  it('Renewal plan does not contain item', () => {
    const params = {
      customerId: '123',
      subscriptionId: 456,
      productTier: ProductTier.Enterprise,
      supportLevel: SupportLevel.Platinum
    };
    jest.spyOn(SubscriptionRecord, 'load').mockReturnValueOnce({
      customerId: '123'
    } as any);
    jest.spyOn(SubscriptionGetUtility, 'getSubscriptionByIdInternal').mockReturnValueOnce({
      plan: {
        id: 789,
        isLegacy: true,
      },
      items: [
        { id: 14, code: 'DNN-OP-TE-SIL', isMainItem: false },
        { id: 15, code: 'DNN-OP-TF-SIL', isMainItem: false }
      ],
      includedItems: [
        { id: 14, code: 'DNN-OP-TE-SIL', quantity: 1 },
        { id: 15, code: 'DNN-OP-TF-SIL', quantity: 1 }
      ]
    } as any);
    // mock load active subscription plan
    jest.spyOn(record, 'load').mockReturnValueOnce({
      getValue: (key: string) => {
        switch (key) {
          case 'defaultrenewalplan':
            return undefined;
          case 'displayname':
            return 'DNN-OP-Cus-ENT-SIL';
          case 'id':
            return '11';
          default:
            return undefined;
        }
      }
    } as any);
    jest.spyOn(SubscriptionPlanDao, 'getLatestSubscriptionPlan').mockReturnValueOnce({
      id: 12
    } as any);
    jest.spyOn(SubscriptionPlanUtility, 'getSubscriptionPlanById').mockReturnValueOnce({
      code: 'DNN-OP-Cus-ENT-PLA',
      productTier: ProductTier.Enterprise,
      supportLevel: SupportLevel.Platinum,
      items: [
        { id: 13, code: 'DNN-OP-Cus-ADD', isMainItem: false }
      ]
    } as any);
    jest.spyOn(nsutils, 'queryToJson').mockReturnValueOnce([
      {id: 14, code: 'DNN-OP-TE-SIL', renewId: undefined, renewCode: undefined },
      {id: 15, code: 'DNN-OP-TF-SIL', renewId: undefined, renewCode: undefined }
    ]);

    expect(() => subscriptionGetRenewalInfoUtility.getRenewalInfo(params)).toThrowError('Renewal plan DNN-OP-Cus-ENT-PLA does not contain item DNN-OP-TE-PLA');
  });

  it('Subscription does not contain main item', () => {
    const params = {
      customerId: '123',
      subscriptionId: 456,
      productTier: ProductTier.Enterprise,
      supportLevel: SupportLevel.Platinum
    };
    jest.spyOn(SubscriptionRecord, 'load').mockReturnValueOnce({
      customerId: '123'
    } as any);
    jest.spyOn(SubscriptionGetUtility, 'getSubscriptionByIdInternal').mockReturnValueOnce({
      plan: {
        id: 789,
        isLegacy: true,
      },
      items: [
        { id: 14, code: 'DNN-OP-TE-SIL', isMainItem: false },
        { id: 15, code: 'DNN-OP-TF-SIL', isMainItem: false }
      ],
      includedItems: [
        { id: 14, code: 'DNN-OP-TE-SIL', quantity: 1 },
        { id: 15, code: 'DNN-OP-TF-SIL', quantity: 1 }
      ]
    } as any);
    // mock load active subscription plan
    jest.spyOn(record, 'load').mockReturnValueOnce({
      getValue: (key: string) => {
        switch (key) {
          case 'defaultrenewalplan':
            return undefined;
          case 'displayname':
            return 'DNN-OP-Cus-ENT-SIL-MNT';
          case 'id':
            return '11';
          default:
            return undefined;
        }
      }
    } as any);
    jest.spyOn(SubscriptionPlanDao, 'getLatestSubscriptionPlan').mockReturnValueOnce({
      id: 12
    } as any);
    jest.spyOn(SubscriptionPlanUtility, 'getSubscriptionPlanById').mockReturnValueOnce({
      code: 'DNN-OP-Cus-ENT-PLA-MNT',
      productTier: ProductTier.Enterprise,
      supportLevel: SupportLevel.Platinum,
      items: [
        { id: 20, code: 'DNN-OP-Cus-PLA', isMainItem: true },
        { id: 18, code: 'DNN-OP-TE-PLA', isMainItem: false },
        { id: 19, code: 'DNN-OP-TF-PLA', isMainItem: false },
      ]
    } as any);
    jest.spyOn(nsutils, 'queryToJson').mockReturnValueOnce([
      {id: 14, code: 'DNN-OP-TE-SIL', renewId: undefined, renewCode: undefined },
      {id: 15, code: 'DNN-OP-TF-SIL', renewId: undefined, renewCode: undefined }
    ]);

    expect(() => subscriptionGetRenewalInfoUtility.getRenewalInfo(params)).toThrowError('Subscription does not contain main item');
  });

  it('Renewal info for non-maintenance subscription', () => {
    const params = {
      customerId: '123',
      subscriptionId: 456,
      productTier: ProductTier.Enterprise,
      supportLevel: SupportLevel.Platinum
    };
    jest.spyOn(SubscriptionRecord, 'load').mockReturnValueOnce({
      customerId: '123'
    } as any);
    jest.spyOn(SubscriptionGetUtility, 'getSubscriptionByIdInternal').mockReturnValueOnce({
      plan: {
        id: 789,
        isLegacy: true
      },
      items: [
        { id: 23, code: 'DNN-OP-Cus-PRO', isMainItem: true },
        { id: 24, code: 'DNN-OP-TE-PRO', isMainItem: false },
        { id: 25, code: 'DNN-OP-TF-PRO', isMainItem: false }
      ],
      includedItems: [
        { id: 23, code: 'DNN-OP-Cus-PRO', quantity: 4 },
        { id: 24, code: 'DNN-OP-TE-PRO', quantity: 5 },
        { id: 25, code: 'DNN-OP-TF-PRO', quantity: 6 }
      ]
    } as any);
    // mock load active subscription plan
    jest.spyOn(record, 'load').mockReturnValueOnce({
      getValue: (key: string) => {
        switch (key) {
          case 'defaultrenewalplan':
            return undefined;
          case 'displayname':
            return 'DNN-OP-Cus-PRO-SIL';
          case 'id':
            return '31';
          default:
            return undefined;
        }
      }
    } as any);
    jest.spyOn(SubscriptionPlanDao, 'getLatestSubscriptionPlan').mockReturnValueOnce({
      id: 12
    } as any);
    jest.spyOn(SubscriptionPlanUtility, 'getSubscriptionPlanById').mockReturnValueOnce({
      code: 'DNN-OP-Cus-ENT-PLA',
      description: 'Subscription Plan Description',
      name: 'Subscription Plan Name',
      productTier: ProductTier.Enterprise,
      supportLevel: SupportLevel.Platinum,
      items: [
        { id: 33, code: 'DNN-OP-Cus-ENT', isMainItem: true },
        { id: 34, code: 'DNN-OP-TE-ENT', isMainItem: false },
        { id: 35, code: 'DNN-OP-TF-ENT', isMainItem: false },
      ]
    } as any);
    jest.spyOn(nsutils, 'queryToJson').mockReturnValueOnce([
      {id: 23, code: 'DNN-OP-Cus-PRO', renewId: undefined, renewCode: undefined },
      {id: 24, code: 'DNN-OP-TE-PRO', renewId: undefined, renewCode: undefined },
      {id: 25, code: 'DNN-OP-TF-PRO', renewId: undefined, renewCode: undefined }
    ]);

    const result =  subscriptionGetRenewalInfoUtility.getRenewalInfo(params);
    expect(result).toEqual(expect.objectContaining({
      plan: {
        code: 'DNN-OP-Cus-ENT-PLA',
        description: 'Subscription Plan Description',
        name: 'Subscription Plan Name'
      },
      items: [
        { code: 'DNN-OP-Cus-ENT', quantity: 4 },
        { code: 'DNN-OP-TE-ENT', quantity: 5 },
        { code: 'DNN-OP-TF-ENT', quantity: 6 },
      ]
    }));
  });

  it('Renewal info addon not part of new plan', () => {
    const params = {
      customerId: '123',
      subscriptionId: 456,
      productTier: ProductTier.Enterprise,
      supportLevel: SupportLevel.Platinum
    };
    jest.spyOn(SubscriptionRecord, 'load').mockReturnValueOnce({
      customerId: '123'
    } as any);
    jest.spyOn(SubscriptionGetUtility, 'getSubscriptionByIdInternal').mockReturnValueOnce({
      plan: {
        id: 789,
        isLegacy: true
      },
      items: [
        { id: 23, code: 'DNN-OP-Cus-PRO', isMainItem: true },
        { id: 24, code: 'DNN-OP-TE-PRO', isMainItem: false },
        { id: 25, code: 'DNN-OP-TF-PRO', isMainItem: false }
      ],
      includedItems: [
        { id: 23, code: 'DNN-OP-Cus-PRO', quantity: 4 },
        { id: 24, code: 'DNN-OP-TE-PRO', quantity: 5 },
        { id: 25, code: 'DNN-OP-TF-PRO', quantity: 6 }
      ]
    } as any);
    // mock load active subscription plan
    jest.spyOn(record, 'load').mockReturnValueOnce({
      getValue: (key: string) => {
        switch (key) {
          case 'defaultrenewalplan':
            return undefined;
          case 'displayname':
            return 'DNN-OP-Cus-PRO-SIL';
          case 'id':
            return '31';
          default:
            return undefined;
        }
      }
    } as any);
    jest.spyOn(SubscriptionPlanDao, 'getLatestSubscriptionPlan').mockReturnValueOnce({
      id: 12
    } as any);
    jest.spyOn(SubscriptionPlanUtility, 'getSubscriptionPlanById').mockReturnValueOnce({
      code: 'DNN-OP-Cus-ENT-PLA',
      description: 'Subscription Plan Description',
      name: 'Subscription Plan Name',
      productTier: ProductTier.Enterprise,
      supportLevel: SupportLevel.Platinum,
      items: [
        { id: 33, code: 'DNN-OP-Cus-ENT', isMainItem: true },
        { id: 34, code: 'DNN-OP-TE-ENT', isMainItem: false }
      ]
    } as any);
    jest.spyOn(nsutils, 'queryToJson').mockReturnValueOnce([
      {id: 23, code: 'DNN-OP-Cus-PRO', renewId: undefined, renewCode: undefined },
      {id: 24, code: 'DNN-OP-TE-PRO', renewId: undefined, renewCode: undefined },
      {id: 25, code: 'DNN-OP-TF-PRO', renewId: 23, renewCode: 'DNN-OP-Cus-PRO' }
    ]);

    const result =  subscriptionGetRenewalInfoUtility.getRenewalInfo(params);
    expect(result).toEqual(expect.objectContaining({
      plan: {
        code: 'DNN-OP-Cus-ENT-PLA',
        description: 'Subscription Plan Description',
        name: 'Subscription Plan Name'
      },
      items: [
        { code: 'DNN-OP-Cus-ENT', quantity: 4 },
        { code: 'DNN-OP-TE-ENT', quantity: 5 }
      ]
    }));
  });

  it('Subscription with main item not set as main item, but required', () => {
    const params = {
      customerId: '123',
      subscriptionId: 456,
      productTier: ProductTier.Enterprise,
      supportLevel: SupportLevel.Platinum
    };
    jest.spyOn(SubscriptionRecord, 'load').mockReturnValueOnce({
      customerId: '123'
    } as any);
    jest.spyOn(SubscriptionGetUtility, 'getSubscriptionByIdInternal').mockReturnValueOnce({
      plan: {
        id: 789,
        isLegacy: true
      },
      items: [
        { id: 23, code: 'DNN-OP-Cus-PRO', isMainItem: false, required: true },
        { id: 24, code: 'DNN-OP-TE-PRO', isMainItem: false },
        { id: 25, code: 'DNN-OP-TF-PRO', isMainItem: false }
      ],
      includedItems: [
        { id: 23, code: 'DNN-OP-Cus-PRO', quantity: 4 },
        { id: 24, code: 'DNN-OP-TE-PRO', quantity: 5 },
        { id: 25, code: 'DNN-OP-TF-PRO', quantity: 6 }
      ]
    } as any);
    // mock load active subscription plan
    jest.spyOn(record, 'load').mockReturnValueOnce({
      getValue: (key: string) => {
        switch (key) {
          case 'defaultrenewalplan':
            return undefined;
          case 'displayname':
            return 'DNN-OP-Cus-PRO-SIL';
          case 'id':
            return '31';
          default:
            return undefined;
        }
      }
    } as any);
    jest.spyOn(SubscriptionPlanDao, 'getLatestSubscriptionPlan').mockReturnValueOnce({
      id: 12
    } as any);
    jest.spyOn(SubscriptionPlanUtility, 'getSubscriptionPlanById').mockReturnValueOnce({
      code: 'DNN-OP-Cus-ENT-PLA',
      description: 'Subscription Plan Description',
      name: 'Subscription Plan Name',
      productTier: ProductTier.Enterprise,
      supportLevel: SupportLevel.Platinum,
      items: [
        { id: 33, code: 'DNN-OP-Cus-ENT', isMainItem: true },
        { id: 34, code: 'DNN-OP-TE-ENT', isMainItem: false },
        { id: 35, code: 'DNN-OP-TF-ENT', isMainItem: false }
      ]
    } as any);
    jest.spyOn(nsutils, 'queryToJson').mockReturnValueOnce([
      {id: 23, code: 'DNN-OP-Cus-PRO', renewId: undefined, renewCode: undefined },
      {id: 24, code: 'DNN-OP-TE-PRO', renewId: undefined, renewCode: undefined },
      {id: 25, code: 'DNN-OP-TF-PRO', renewId: undefined, renewCode: undefined }
    ]);

    const result =  subscriptionGetRenewalInfoUtility.getRenewalInfo(params);
    expect(result).toEqual(expect.objectContaining({
      plan: {
        code: 'DNN-OP-Cus-ENT-PLA',
        description: 'Subscription Plan Description',
        name: 'Subscription Plan Name'
      },
      items: [
        { code: 'DNN-OP-Cus-ENT', quantity: 4 },
        { code: 'DNN-OP-TE-ENT', quantity: 5 },
        { code: 'DNN-OP-TF-ENT', quantity: 6 }
      ]
    }));
  });

  it('Renewal info for maintenance subscription', () => {
    const params = {
      customerId: '123',
      subscriptionId: 456,
      productTier: ProductTier.Enterprise,
      supportLevel: SupportLevel.Platinum
    };
    jest.spyOn(SubscriptionRecord, 'load').mockReturnValueOnce({
      customerId: '123'
    } as any);
    jest.spyOn(SubscriptionGetUtility, 'getSubscriptionByIdInternal').mockReturnValueOnce({
      plan: {
        id: 789,
        isLegacy: true,
      },
      items: [
        { id: 13, code: 'DNN-OP-Cus-SIL', isMainItem: false, isSupportMainItem: true },
        { id: 14, code: 'DNN-OP-TE-SIL', isMainItem: false },
        { id: 15, code: 'DNN-OP-TF-SIL', isMainItem: false }
      ],
      includedItems: [
        { id: 13, code: 'DNN-OP-Cus-SIL', quantity: 1 },
        { id: 14, code: 'DNN-OP-TE-SIL', quantity: 2 },
        { id: 15, code: 'DNN-OP-TF-SIL', quantity: 3 }
      ]
    } as any);
    // mock load active subscription plan
    jest.spyOn(record, 'load').mockReturnValueOnce({
      getValue: (key: string) => {
        switch (key) {
          case 'defaultrenewalplan':
            return undefined;
          case 'displayname':
            return 'DNN-OP-Cus-ENT-SIL-MNT';
          case 'id':
            return '11';
          default:
            return undefined;
        }
      }
    } as any);
    jest.spyOn(SubscriptionPlanDao, 'getLatestSubscriptionPlan').mockReturnValueOnce({
      id: 12
    } as any);
    jest.spyOn(SubscriptionPlanUtility, 'getSubscriptionPlanById').mockReturnValueOnce({
      code: 'DNN-OP-Cus-ENT-PLA-MNT',
      description: 'Subscription Plan Description',
      name: 'Subscription Plan Name',
      productTier: ProductTier.Enterprise,
      supportLevel: SupportLevel.Platinum,
      supportOnly: true,
      items: [
        { id: 20, code: 'DNN-OP-Cus-PLA', isMainItem: false, isSupportMainItem: true },
        { id: 18, code: 'DNN-OP-TE-PLA', isMainItem: false },
        { id: 19, code: 'DNN-OP-TF-PLA', isMainItem: false },
      ]
    } as any);
    jest.spyOn(nsutils, 'queryToJson').mockReturnValueOnce([
      {id: 13, code: 'DNN-OP-Cus-SIL', renewId: undefined, renewCode: undefined },
      {id: 14, code: 'DNN-OP-TE-SIL', renewId: undefined, renewCode: undefined },
      {id: 15, code: 'DNN-OP-TF-SIL', renewId: undefined, renewCode: undefined }
    ]);

    const result =  subscriptionOps.getRenewalInfo(params);
    expect(result).toEqual(expect.objectContaining({
      content: {
        plan: {
          code: 'DNN-OP-Cus-ENT-PLA-MNT',
          description: 'Subscription Plan Description',
          name: 'Subscription Plan Name'
        },
        items: [
          { code: 'DNN-OP-Cus-PLA', quantity: 1 },
          { code: 'DNN-OP-TE-PLA', quantity: 2 },
          { code: 'DNN-OP-TF-PLA', quantity: 3 },
        ]
      }
    }));
  });
});
