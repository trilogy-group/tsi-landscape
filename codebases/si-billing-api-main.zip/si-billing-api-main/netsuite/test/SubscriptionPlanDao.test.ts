import subscriptionPlanDao from '../src/ts/dao/SubscriptionPlanDao';
import * as nsutils from '../src/ts/nsutils';
import { BillingSchedule, ProductTier, ProductTierUtil, SupportLevel } from '../src/ts/types';

describe('SubscriptionPlanDao', () => {

  beforeEach(() => {
    jest.restoreAllMocks()
    jest.spyOn(nsutils, 'queryToJson')
    jest.spyOn(nsutils, 'queryFirstToJson')
    jest.spyOn(nsutils, 'queryFirstAsMap')
  })

  it('getInternalIdAndSubsidiary', () => {
    subscriptionPlanDao.getInternalIdAndSubsidiary("PlanName")

    expect(nsutils.queryFirstToJson).toBeCalledWith(expect.stringContaining('select id, subsidiary, class from subscriptionplan'), ['PlanName'], expect.anything())
  })

  it('getInternalIdAndSubsidiary undefined', () => {
    let res = subscriptionPlanDao.getInternalIdAndSubsidiary(undefined)

    expect(res).toBe(undefined)

    res = subscriptionPlanDao.getInternalIdAndSubsidiary(null as any)

    expect(res).toBe(undefined)
  })

  it('findPriceBook', () => {
    subscriptionPlanDao.findPriceBook(1, 'TestCustomer', BillingSchedule.MONTHLY)

    expect(nsutils.queryFirstAsMap).toBeCalledWith(expect.stringContaining('SELECT pb.id'), [1, 'TestCustomer', BillingSchedule.MONTHLY])
  })

  it('getItemIds', () => {
    subscriptionPlanDao.getItemIds(['code']);

    expect(nsutils.queryToJson).toBeCalledWith(expect.stringContaining('SELECT id'), ['code'])
  })

  it('getItems', () => {
    const res = subscriptionPlanDao.getItems();
    expect(res).toBeUndefined();
  })

  it('getFrequencyFromPriceBook', () => {
    subscriptionPlanDao.getFrequencyFromPriceBook(1);

    expect(nsutils.queryFirstToJson).toBeCalledWith(expect.stringContaining('SELECT frequency'), [1])
  })

  it('getLatestSubscriptionPlan with no maintenance plan', () => {
    // Arrange
    const productFamilyCode = 'DNN';
    const productVariantCode = 'OP-Cus';
    const productTier = ProductTier.Professional;
    const supportLevel = SupportLevel.Gold;
    const isSupport = false; 
    const displaynamePrefix = 'DNN-OP-Cus-PRO-GOL';
    const plan = { displayname: `${displaynamePrefix}-001` };
    jest.spyOn(nsutils, 'queryFirstToJson').mockReturnValueOnce(plan);

    // Act
    const result = subscriptionPlanDao.getLatestSubscriptionPlan(productFamilyCode, productVariantCode, productTier, supportLevel, isSupport);

    // Assert
    expect(result).toBeDefined();
    expect(result).toEqual(plan);
    expect(nsutils.queryFirstToJson).toHaveBeenCalledWith(
      expect.anything(),
      expect.arrayContaining([ `${displaynamePrefix}-%` ])
    );
  });

  it('getLatestSubscriptionPlan with maintenance plan', () => {
    // Arrange
    const productFamilyCode = 'Aur';
    const productVariantCode = 'OP-Ent';
    const productTier = ProductTier.Enterprise;
    const supportLevel = SupportLevel.Platinum;
    const isSupport = true; 
    const displaynamePrefix = 'Aur-OP-Ent-ENT-PLA-MNT';
    const plan = { displayname: `${displaynamePrefix}-002` };
    jest.spyOn(nsutils, 'queryFirstToJson').mockReturnValueOnce(plan);

    // Act
    const result = subscriptionPlanDao.getLatestSubscriptionPlan(productFamilyCode, productVariantCode, productTier, supportLevel, isSupport);

    // Assert
    expect(result).toBeDefined();
    expect(result).toEqual(plan);
    expect(nsutils.queryFirstToJson).toHaveBeenCalledWith(
      expect.anything(),
      expect.arrayContaining([ `${displaynamePrefix}-%` ])
    );
  });

  it('getProductTierCodeFromItems with no matching items', () => {
    // Arrange
    const subscriptionPlanId = 123;
    const queryResult = undefined;
    jest.spyOn(nsutils, 'queryFirstToJson').mockReturnValueOnce(queryResult);

    // Act
    const result = subscriptionPlanDao.getProductTierCodeFromItems(subscriptionPlanId);

    // Assert
    expect(result).toBeUndefined();
  });

  it('getProductTierCodeFromItems with at least one matching item', () => {
    // Arrange
    const subscriptionPlanId = 123;
    const queryResult = { itemsuffix: 'XXX' };
    jest.spyOn(nsutils, 'queryFirstToJson').mockReturnValueOnce(queryResult);
    const productTierCodes = Object.values(ProductTier).map(ProductTierUtil.productTierToCode);

    // Act
    const result = subscriptionPlanDao.getProductTierCodeFromItems(subscriptionPlanId);

    // Assert
    expect(result).toBeDefined();
    expect(result).toBe(queryResult.itemsuffix);
    expect(nsutils.queryFirstToJson).toHaveBeenCalledWith(
      expect.anything(),
      expect.arrayContaining([ subscriptionPlanId, ...productTierCodes ]),
    );
  });

  it('getProductFamilyCode should return undefined when there is no match', () => {
    // Arrange
    const subscriptionPlanId = 123;
    const queryResult = undefined;
    jest.spyOn(nsutils, 'queryFirstToJson').mockReturnValueOnce(queryResult);

    // Act
    const result = subscriptionPlanDao.getProductFamilyCode(subscriptionPlanId);

    // Assert
    expect(result).toBeUndefined();
  });

  it('getProductFamilyCode should return product family code when there is a match', () => {
    // Arrange
    const subscriptionPlanId = 123;
    const queryResult = { pfc: 'XXX' };
    jest.spyOn(nsutils, 'queryFirstToJson').mockReturnValueOnce(queryResult);

    // Act
    const result = subscriptionPlanDao.getProductFamilyCode(subscriptionPlanId);

    // Assert
    expect(result).toBeDefined();
    expect(result).toBe(queryResult.pfc);
    expect(nsutils.queryFirstToJson).toHaveBeenCalledWith(
      expect.anything(),
      expect.arrayContaining([ subscriptionPlanId ]),
    );
  });
})
