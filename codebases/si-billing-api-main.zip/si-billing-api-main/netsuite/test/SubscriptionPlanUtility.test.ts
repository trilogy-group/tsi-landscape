import SubscriptionPlanDao from '../src/ts/dao/SubscriptionPlanDao';
import * as nsutils from '../src/ts/nsutils';
import { ProductTier, ProductTierUtil, SupportLevel } from '../src/ts/types';
import subscriptionPlanUtility from '../src/ts/utility/SubscriptionPlanUtility';

describe('SubscriptionPlanUtility', () => {
  beforeEach(() => {
    jest.restoreAllMocks();
    jest.spyOn(nsutils, 'queryToJson');
    jest.spyOn(nsutils, 'queryFirstToJson');
    jest.spyOn(nsutils, 'queryFirstAsMap');
  });

  it('getSubscriptionPlan maintenance plan only', () => {
    jest.spyOn(nsutils, 'queryToJson').mockReturnValueOnce([{
      code: 'DNNE-SA-Cus-STA-SIL-MNT-001',
      name: 'DNNE Std Silver Sup'
    }]);
    jest.spyOn(nsutils, 'queryToJson').mockReturnValueOnce([
      {
        id: 84627,
        code: 'DNNE-SA-Cus-SIL',
        title: 'DNNE Silver Support',
        description: null,
        isrequired: 'T',
        chargetypeid: 2,
        chargetype: 'Recurring',
        pricebookid: 11956,
        pricetype: 'Volume',
        frequency: 'ANNUALLY',
        currency: 'USD',
        priceplanid: 4702673,
        fromquantity: 0,
        price: 30,
        pricingoption: -101,
        linenumber: 1,
        maximumquantity: null,
        minimumquantity: null,
        support_level_name: 'Silver',
        product_tier_name: null,
      },
      {
        id: 84627,
        code: 'DNNE-SA-Cus-SIL',
        title: 'DNNE Silver Support',
        description: null,
        isrequired: 'T',
        chargetypeid: 2,
        chargetype: 'Recurring',
        pricebookid: 11957,
        pricetype: 'Volume',
        frequency: 'MONTHLY',
        currency: 'USD',
        priceplanid: 4702677,
        fromquantity: 0,
        price: 35,
        pricingoption: -101,
        linenumber: 1,
        maximumquantity: null,
        minimumquantity: null,
        support_level_name: 'Silver',
        product_tier_name: null,
      },
      {
        id: 84636,
        code: 'DNNE-SA-Add-BAS',
        title: 'DNNE Addon',
        description: null,
        isrequired: 'F',
        chargetypeid: 2,
        chargetype: 'Recurring',
        pricebookid: 11956,
        pricetype: 'Volume',
        frequency: 'ANNUALLY',
        currency: 'USD',
        priceplanid: 4702674,
        fromquantity: 0,
        price: 15,
        pricingoption: -101,
        linenumber: 2,
        maximumquantity: null,
        minimumquantity: null,
        support_level_name: null,
        product_tier_name: null,
      },
      {
        id: 84636,
        code: 'DNNE-SA-Add-BAS',
        title: 'DNNE Addon',
        description: null,
        isrequired: 'F',
        chargetypeid: 2,
        chargetype: 'Recurring',
        pricebookid: 11957,
        pricetype: 'Volume',
        frequency: 'MONTHLY',
        currency: 'USD',
        priceplanid: 4702678,
        fromquantity: 0,
        price: 20,
        pricingoption: -101,
        linenumber: 2,
        maximumquantity: null,
        minimumquantity: null,
        support_level_name: null,
        product_tier_name: null,
      },
      {
        id: 85876,
        code: 'DNNE-SA-OT-PT',
        title: 'PERPETUAL',
        description: null,
        isrequired: 'F',
        chargetypeid: 1,
        chargetype: 'One Time',
        pricebookid: 11956,
        pricetype: 'Volume',
        frequency: 'ONETIME',
        currency: 'USD',
        priceplanid: 4702675,
        fromquantity: 0,
        price: 12500,
        pricingoption: -102,
        linenumber: 3,
        maximumquantity: null,
        minimumquantity: null,
        support_level_name: null,
        product_tier_name: null,
      },
      {
        id: 85876,
        code: 'DNNE-SA-OT-PT',
        title: 'PERPETUAL',
        description: null,
        isrequired: 'F',
        chargetypeid: 1,
        chargetype: 'One Time',
        pricebookid: 11957,
        pricetype: 'Volume',
        frequency: 'ONETIME',
        currency: 'USD',
        priceplanid: 4702679,
        fromquantity: 0,
        price: 12500,
        pricingoption: -102,
        linenumber: 3,
        maximumquantity: null,
        minimumquantity: null,
        support_level_name: null,
        product_tier_name: null,
      },
      {
        id: 85877,
        code: 'DNNE-SA-OT-GRI',
        title: 'GRINDING',
        description: null,
        isrequired: 'F',
        chargetypeid: 1,
        chargetype: 'One Time',
        pricebookid: 11956,
        pricetype: 'Volume',
        frequency: 'ONETIME',
        currency: 'USD',
        priceplanid: 4702676,
        fromquantity: 0,
        price: 12000,
        pricingoption: -102,
        linenumber: 4,
        maximumquantity: null,
        minimumquantity: null,
        support_level_name: null,
        product_tier_name: null,
      },
      {
        id: 85877,
        code: 'DNNE-SA-OT-GRI',
        title: 'GRINDING',
        description: null,
        isrequired: 'F',
        chargetypeid: 1,
        chargetype: 'One Time',
        pricebookid: 11957,
        pricetype: 'Volume',
        frequency: 'ONETIME',
        currency: 'USD',
        priceplanid: 4702680,
        fromquantity: 0,
        price: 12000,
        pricingoption: -102,
        linenumber: 4,
        maximumquantity: null,
        minimumquantity: null,
        support_level_name: null,
        product_tier_name: null,
      },
    ]);

    const subscriptionPlan = subscriptionPlanUtility.getSubscriptionPlanById(1);
    expect(subscriptionPlan).toEqual(expect.objectContaining({
      isLegacyPlan: false,
      supportOnly: true,
      code: 'DNNE-SA-Cus-STA-SIL-MNT-001',
      revenueType: 'Support',
      supportItemCode: 'DNNE-SA-Cus-SIL',
      supportLevel: 'Silver',
      productTier: 'Standard',
      name: 'DNNE Std Silver Sup',
    }));
    expect(subscriptionPlan.items).toStrictEqual([
      {
        code: 'DNNE-SA-Cus-SIL',
        desc: null,
        id: 84627,
        maxQuantity: null,
        minQuantity: null,
        isMainItem: false,
        isSupportMainItem: true,
        isSupportAddonItem: false,
        productTier: null,
        prices: [
          {
            currency: 'USD',
            frequency: 'ANNUALLY',
            pricebookid: 11956,
            ranges: [
              {
                fromQuantity: 0,
                priceplanid: 4702673,
                price: 30,
                type: 'Rate',
              },
            ],
            type: 'Volume',
          },
          {
            currency: 'USD',
            frequency: 'MONTHLY',
            pricebookid: 11957,
            ranges: [
              {
                fromQuantity: 0,
                priceplanid: 4702677,
                price: 35,
                type: 'Rate',
              },
            ],
            type: 'Volume',
          },
        ],
        required: true,
        supportLevel: 'Silver',
        title: 'DNNE Silver Support',
        type: 'Recurring',
        typeId: 2,
      },
      {
        code: 'DNNE-SA-Add-BAS',
        desc: null,
        id: 84636,
        maxQuantity: null,
        minQuantity: null,
        isMainItem: false,
        isSupportMainItem: false,
        isSupportAddonItem: false,
        productTier: null,
        prices: [
          {
            currency: 'USD',
            frequency: 'ANNUALLY',
            type: 'Volume',
            pricebookid: 11956,
            ranges: [
              {
                fromQuantity: 0,
                priceplanid: 4702674,
                price: 15,
                type: 'Rate',
              },
            ],
          },
          {
            currency: 'USD',
            frequency: 'MONTHLY',
            type: 'Volume',
            pricebookid: 11957,
            ranges: [
              {
                fromQuantity: 0,
                priceplanid: 4702678,
                price: 20,
                type: 'Rate',
              },
            ],
          },
        ],
        required: false,
        supportLevel: null,
        title: 'DNNE Addon',
        type: 'Recurring',
        typeId: 2,
      },
      {
        code: 'DNNE-SA-OT-PT',
        desc: null,
        id: 85876,
        maxQuantity: null,
        minQuantity: null,
        isMainItem: false,
        isSupportMainItem: false,
        isSupportAddonItem: false,
        productTier: null,
        prices: [
          {
            currency: 'USD',
            frequency: 'ONETIME',
            type: 'Volume',
            pricebookid: 11956,
            ranges: [
              {
                fromQuantity: 0,
                priceplanid: 4702675,
                price: 12500,
                type: 'FixedAmount',
              },
            ],
          },
          {
            currency: 'USD',
            frequency: 'ONETIME',
            type: 'Volume',
            pricebookid: 11957,
            ranges: [
              {
                fromQuantity: 0,
                priceplanid: 4702679,
                price: 12500,
                type: 'FixedAmount',
              },
            ],
          },
        ],
        required: false,
        supportLevel: null,
        title: 'PERPETUAL',
        type: 'One Time',
        typeId: 1,
      },
      {
        code: 'DNNE-SA-OT-GRI',
        desc: null,
        id: 85877,
        maxQuantity: null,
        minQuantity: null,
        isMainItem: false,
        isSupportMainItem: false,
        isSupportAddonItem: false,
        productTier: null,
        prices: [
          {
            currency: 'USD',
            frequency: 'ONETIME',
            type: 'Volume',
            pricebookid: 11956,
            ranges: [
              {
                fromQuantity: 0,
                priceplanid: 4702676,
                price: 12000,
                type: 'FixedAmount',
              },
            ],
          },
          {
            currency: 'USD',
            frequency: 'ONETIME',
            type: 'Volume',
            pricebookid: 11957,
            ranges: [
              {
                fromQuantity: 0,
                priceplanid: 4702680,
                price: 12000,
                type: 'FixedAmount',
              },
            ],
          },
        ],
        required: false,
        supportLevel: null,
        title: 'GRINDING',
        type: 'One Time',
        typeId: 1,
      },
    ]);
  });

  it('getSubscriptionPlan regular plan 2', () => {
    jest.spyOn(nsutils, 'queryToJson').mockReturnValueOnce([{
      code: 'DNNE-SA-Cus-PRO-GOL-001',
      name: 'DNNE Std Gold Sup',
      initialterm: {
        duration: 1,
        unit: 'YEARS'
      }
    }]);

    jest.spyOn(nsutils, 'queryToJson').mockReturnValueOnce([
      {
        id: 84628,
        code: 'DNNE-SA-Cus-PRO',
        title: 'DNNE Customer Cloud EVOQ Content',
        description: null,
        isrequired: 'T',
        chargetypeid: 2,
        chargetype: 'Recurring',
        pricebookid: 10614,
        pricetype: 'Volume',
        frequency: 'ANNUALLY',
        currency: 'USD',
        priceplanid: 4612895,
        fromquantity: 0,
        price: 20,
        pricingoption: -101,
        linenumber: 1,
        maximumquantity: null,
        minimumquantity: null,
        support_level_name: null,
        product_tier_name: 'Professional',
      },
      {
        id: 84629,
        code: 'DNNE-SA-Cus-GOL',
        title: 'DNNE Gold Support',
        description: null,
        isrequired: 'T',
        chargetypeid: 2,
        chargetype: 'Recurring',
        pricebookid: 10614,
        pricetype: 'Volume',
        frequency: 'ANNUALLY',
        currency: 'USD',
        priceplanid: 4612896,
        fromquantity: 0,
        price: 0,
        pricingoption: -101,
        linenumber: 2,
        maximumquantity: null,
        minimumquantity: null,
        support_level_name: 'Gold',
        product_tier_name: null,
      },
    ]);

    const subscriptionPlan = subscriptionPlanUtility.getSubscriptionPlanById(1);
    expect(subscriptionPlan.items).toStrictEqual([
      {
        id: 84628,
        code: 'DNNE-SA-Cus-PRO',
        title: 'DNNE Customer Cloud EVOQ Content',
        supportLevel: null,
        productTier: 'Professional',
        isMainItem: true,
        isSupportMainItem: false,
        isSupportAddonItem: false,
        required: true,
        type: 'Recurring',
        typeId: 2,
        desc: null,
        minQuantity: null,
        maxQuantity: null,
        prices: [
          {
            type: 'Volume',
            frequency: 'ANNUALLY',
            currency: 'USD',
            pricebookid: 10614,
            ranges: [
              {
                priceplanid: 4612895,
                type: 'Rate',
                fromQuantity: 0,
                price: 20,
              },
            ],
          },
        ],
      },
      {
        id: 84629,
        code: 'DNNE-SA-Cus-GOL',
        title: 'DNNE Gold Support',
        supportLevel: 'Gold',
        productTier: null,
        isMainItem: false,
        isSupportMainItem: true,
        isSupportAddonItem: false,
        required: true,
        type: 'Recurring',
        typeId: 2,
        desc: null,
        minQuantity: null,
        maxQuantity: null,
        prices: [
          {
            type: 'Volume',
            frequency: 'ANNUALLY',
            currency: 'USD',
            pricebookid: 10614,
            ranges: [
              {
                priceplanid: 4612896,
                type: 'Rate',
                fromQuantity: 0,
                price: 0,
              },
            ],
          },
        ],
      },
    ]);
    expect(subscriptionPlan).toEqual(expect.objectContaining({
      productTier: 'Professional',
      mainItemCode: 'DNNE-SA-Cus-PRO',
      revenueType: 'SaaS',
      code: 'DNNE-SA-Cus-PRO-GOL-001',
      supportLevel: 'Gold',
      supportItemCode: 'DNNE-SA-Cus-GOL',
      supportOnly: false,
      isLegacyPlan: false,
      name: 'DNNE Std Gold Sup',
      initialterm: expect.objectContaining({
          duration: 1,
          unit: 'YEARS'
      }),
    }));
  });

  it('getSubscriptionPlan regular plan 1', () => {
    jest.spyOn(nsutils, 'queryToJson').mockReturnValueOnce([{
      code: 'DNNE-SA-Cus-PRO-SIL-001',
      name: 'DNNE Std Silver Sup',
      initialterm: {
        duration: 1,
        unit: 'YEARS'
      }
    }]);
    jest.spyOn(nsutils, 'queryToJson').mockReturnValueOnce([
      {
        id: 84628,
        code: 'DNNE-SA-Cus-PRO',
        title: 'DNNE Customer Cloud EVOQ Content',
        description: null,
        isrequired: 'T',
        chargetypeid: 2,
        chargetype: 'Recurring',
        pricebookid: 10614,
        pricetype: 'Volume',
        frequency: 'ANNUALLY',
        currency: 'USD',
        priceplanid: 4612895,
        fromquantity: 0,
        price: 20,
        pricingoption: -101,
        linenumber: 1,
        maximumquantity: null,
        minimumquantity: null,
        support_level_name: null,
        product_tier_name: 'Professional',
      },
      {
        id: 84629,
        code: 'DNNE-SA-Cus-SIL',
        title: 'DNNE Silver Support',
        description: null,
        isrequired: 'T',
        chargetypeid: 2,
        chargetype: 'Recurring',
        pricebookid: 10614,
        pricetype: 'Volume',
        frequency: 'ANNUALLY',
        currency: 'USD',
        priceplanid: 4612896,
        fromquantity: 0,
        price: 0,
        pricingoption: -101,
        linenumber: 2,
        maximumquantity: null,
        minimumquantity: null,
        support_level_name: 'Silver',
        product_tier_name: null,
      },
    ]);
    const subscriptionPlan = subscriptionPlanUtility.getSubscriptionPlanById(1);
    expect(subscriptionPlan.items).toStrictEqual([
      {
        id: 84628,
        code: 'DNNE-SA-Cus-PRO',
        title: 'DNNE Customer Cloud EVOQ Content',
        supportLevel: null,
        required: true,
        type: 'Recurring',
        typeId: 2,
        desc: null,
        minQuantity: null,
        maxQuantity: null,
        isMainItem: true,
        isSupportMainItem: false,
        isSupportAddonItem: false,
        productTier: 'Professional',
        prices: [
          {
            type: 'Volume',
            frequency: 'ANNUALLY',
            currency: 'USD',
            pricebookid: 10614,
            ranges: [{ priceplanid: 4612895, type: 'Rate', fromQuantity: 0, price: 20 }],
          },
        ],
      },
      {
        id: 84629,
        code: 'DNNE-SA-Cus-SIL',
        title: 'DNNE Silver Support',
        supportLevel: 'Silver',
        required: true,
        type: 'Recurring',
        typeId: 2,
        desc: null,
        minQuantity: null,
        maxQuantity: null,
        isMainItem: false,
        isSupportMainItem: true,
        isSupportAddonItem: false,
        productTier: null,
        prices: [
          {
            type: 'Volume',
            frequency: 'ANNUALLY',
            currency: 'USD',
            pricebookid: 10614,
            ranges: [{ priceplanid: 4612896, type: 'Rate', fromQuantity: 0, price: 0 }],
          },
        ],
      },
    ]);
    expect(subscriptionPlan).toEqual(expect.objectContaining({
      productTier: 'Professional',
      mainItemCode: 'DNNE-SA-Cus-PRO',
      revenueType: 'SaaS',
      supportLevel: 'Silver',
      code: 'DNNE-SA-Cus-PRO-SIL-001',
      supportItemCode: 'DNNE-SA-Cus-SIL',
      supportOnly: false,
      isLegacyPlan: false,
      name: 'DNNE Std Silver Sup',
      initialterm: {
        duration: 1,
        unit: 'YEARS'
      }
    }));
  });

  it('getSubscriptionPlan plan 3', () => {
    jest.spyOn(nsutils, 'queryToJson').mockReturnValueOnce([{
      code: 'DNNR-SA-Cus-STA-PLA-MNT-001',
      name: 'DNNR Std Platinum Sup',
      initialterm: {
        duration: 1,
        unit: 'YEARS'
      }
    }]);
    jest.spyOn(nsutils, 'queryToJson').mockReturnValueOnce([
      {
        id: 87291,
        code: 'DNNR-SA-Cus-PLA',
        title: 'DNNR Platinum Support',
        description: null,
        isrequired: 'F',
        chargetypeid: 2,
        chargetype: 'Recurring',
        pricebookid: 13265,
        pricetype: 'Tiered',
        frequency: 'ANNUALLY',
        currency: 'USD',
        priceplanid: 4838343,
        fromquantity: 0,
        price: 40,
        pricingoption: -101,
        linenumber: 1,
        maximumquantity: null,
        minimumquantity: null,
        support_level_name: null,
        product_tier_name: null,
      },
      {
        id: 87387,
        code: 'DNNR-SA-Cus-ADDPLA',
        title: 'DNNR Addon Platinum',
        description: null,
        isrequired: 'F',
        chargetypeid: 2,
        chargetype: 'Recurring',
        pricebookid: 13265,
        pricetype: 'Tiered',
        frequency: 'ANNUALLY',
        currency: 'USD',
        priceplanid: 4838344,
        fromquantity: 0,
        price: 25,
        pricingoption: -101,
        linenumber: 2,
        maximumquantity: null,
        minimumquantity: null,
        support_level_name: 'Platinum',
        product_tier_name: null,
      },
    ]);
    const subscriptionPlan = subscriptionPlanUtility.getSubscriptionPlanById(1);
    expect(subscriptionPlan.items).toStrictEqual([
      {
        id: 87291,
        code: 'DNNR-SA-Cus-PLA',
        title: 'DNNR Platinum Support',
        supportLevel: 'Platinum',
        productTier: null,
        isMainItem: false,
        isSupportMainItem: true,
        isSupportAddonItem: false,
        required: true,
        type: 'Recurring',
        typeId: 2,
        desc: null,
        minQuantity: null,
        maxQuantity: null,
        prices: [
          {
            type: 'Tiered',
            frequency: 'ANNUALLY',
            currency: 'USD',
            pricebookid: 13265,
            ranges: [
              {
                priceplanid: 4838343,
                type: 'Rate',
                fromQuantity: 0,
                price: 40,
              },
            ],
          },
        ],
      },
      {
        id: 87387,
        code: 'DNNR-SA-Cus-ADDPLA',
        title: 'DNNR Addon Platinum',
        supportLevel: null,
        productTier: null,
        isMainItem: false,
        isSupportMainItem: false,
        isSupportAddonItem: false,
        required: false,
        type: 'Recurring',
        typeId: 2,
        desc: null,
        minQuantity: null,
        maxQuantity: null,
        prices: [
          {
            type: 'Tiered',
            frequency: 'ANNUALLY',
            currency: 'USD',
            pricebookid: 13265,
            ranges: [
              {
                priceplanid: 4838344,
                type: 'Rate',
                fromQuantity: 0,
                price: 25,
              },
            ],
          },
        ],
      },
    ]);
    expect(subscriptionPlan).toEqual(expect.objectContaining({
      revenueType: 'Support',
      supportLevel: 'Platinum',
      productTier: 'Standard',
      code: 'DNNR-SA-Cus-STA-PLA-MNT-001',
      supportItemCode: 'DNNR-SA-Cus-PLA',
      supportOnly: true,
      isLegacyPlan: false,
      name: 'DNNR Std Platinum Sup',
      initialterm: {
        duration: 1,
        unit: 'YEARS'
      }
    }));
  });

  it('extractProductTierFromPlanCode', () => {
    expect(Object.getPrototypeOf(subscriptionPlanUtility).extractProductTierFromPlanCode('DNNE-SA-Cus-BAS-Gold')).toBe('BAS');
    expect(Object.getPrototypeOf(subscriptionPlanUtility).extractProductTierFromPlanCode('DNNE-SA-Cus-EG-SIL')).toBe('EG');
    expect(Object.getPrototypeOf(subscriptionPlanUtility).extractProductTierFromPlanCode('DNNR-SA-Cus-PRO-PLA-SUP-001')).toBe('PRO');
  });

  it('extractSupportLevelFromPlanCode', () => {
    expect(Object.getPrototypeOf(subscriptionPlanUtility).extractSupportLevelFromPlanCode('DNNE-SA-Cus-BAS-Gold')).toBe('Gold');
    expect(Object.getPrototypeOf(subscriptionPlanUtility).extractSupportLevelFromPlanCode('DNNE-SA-Cus-EG-SIL')).toBe('SIL');
    expect(Object.getPrototypeOf(subscriptionPlanUtility).extractSupportLevelFromPlanCode('DNNR-SA-Cus-PRO-PLA-SUP-001')).toBe('PLA');
  });

  it('extractPVCFromPlanCode', () => {
    expect(subscriptionPlanUtility.extractPVCFromPlanCode('DNNE-SA-Cus-BAS-Gold')).toBe('SA-Cus');
    expect(subscriptionPlanUtility.extractPVCFromPlanCode('DNNE')).toBeUndefined();
    expect(subscriptionPlanUtility.extractPVCFromPlanCode('')).toBeUndefined();
  });

  it('getProductTierAndMainItemCode should deduce the product tier from the plan code when available in the plan code', () => {
    // Arrange
    const productTier = ProductTier.Enterprise;
    const productTierCode = ProductTierUtil.productTierToCode(productTier);
    const plan = {
      id: 1,
      code: `DNNE-SA-Cus-${productTierCode}-GOL`,
      supportOnly: false,
    };

    // Act
    const result = Object.getPrototypeOf(subscriptionPlanUtility).getProductTierAndMainItemCode(plan);

    // Assert
    expect(result).toStrictEqual({ productTier, mainItemCode: `DNNE-SA-Cus-${productTierCode}` });
  });

  it('getProductTierAndMainItemCode should deduce the product tier from the items when unavailable in the plan code but available in the items', () => {
    // Arrange
    const productTier = ProductTier.Professional;
    const productTierCode = ProductTierUtil.productTierToCode(productTier);
    const plan = {
      id: 1,
      code: 'DNNE-SA-Cus-XXX-GOL',
      supportOnly: false,
    };
    jest.spyOn(SubscriptionPlanDao, 'getProductTierCodeFromItems').mockReturnValueOnce(productTierCode)

    // Act
    const result = Object.getPrototypeOf(subscriptionPlanUtility).getProductTierAndMainItemCode(plan);

    // Assert
    expect(SubscriptionPlanDao.getProductTierCodeFromItems).toHaveBeenCalledWith(plan.id);
    expect(result).toStrictEqual({ productTier, mainItemCode: `DNNE-SA-Cus-${productTierCode}` });
  });

  it('getProductTierAndMainItemCode should return the default product tier when unavailable in the plan code and in the items', () => {
    // Arrange
    const defaultProductTier = ProductTier.Standard;
    const productTierCode = undefined;
    const plan = {
      id: 1,
      code: 'DNNE-SA-Cus-XXX-GOL',
      supportOnly: false,
    };
    jest.spyOn(SubscriptionPlanDao, 'getProductTierCodeFromItems').mockReturnValueOnce(productTierCode)

    // Act
    const result = Object.getPrototypeOf(subscriptionPlanUtility).getProductTierAndMainItemCode(plan);

    // Assert
    expect(SubscriptionPlanDao.getProductTierCodeFromItems).toHaveBeenCalledWith(plan.id);
    expect(result).toStrictEqual({ productTier: defaultProductTier, mainItemCode: `DNNE-SA-Cus-XXX` });
  });

  it('getProductTierAndMainItemCode should not return the main item code when the plan is support only', () => {
    // Arrange
    const productTier = ProductTier.Professional;
    const productTierCode = ProductTierUtil.productTierToCode(productTier);
    const plan = {
      id: 1,
      code: 'DNNE-SA-Cus-XXX-GOL',
      supportOnly: true,
    };
    jest.spyOn(SubscriptionPlanDao, 'getProductTierCodeFromItems').mockReturnValueOnce(productTierCode)

    // Act
    const result = Object.getPrototypeOf(subscriptionPlanUtility).getProductTierAndMainItemCode(plan);

    // Assert
    expect(SubscriptionPlanDao.getProductTierCodeFromItems).toHaveBeenCalledWith(plan.id);
    expect(result).toStrictEqual({ productTier: productTier, mainItemCode: undefined });
  });

  it('getSubscriptionPlanInfos should return current plan details when the plan code is structured', () => {
    // Arrange
    const params = {};
    const planInfos = [
      { code: 'DNN-OP-Pro-PRO-GOL-001' },
    ] as any[];
    jest.spyOn(SubscriptionPlanDao, 'getSubscriptionPlanInfos').mockReturnValueOnce(planInfos);

    // Act
    const result = subscriptionPlanUtility['getSubscriptionPlanInfos'](params);

    // Assert
    expect(result).toBeDefined();
    expect(result.length).toBe(1);
    expect(result[0]).toEqual(expect.objectContaining({
      supportOnly: false,
      productTier: ProductTier.Professional,
      mainItemCode: 'DNN-OP-Pro-PRO',
      supportLevel: SupportLevel.Gold,
      supportItemCode: 'DNN-OP-Pro-GOL',
      isLegacyPlan: false,
      productTierTitle: ProductTier.Professional.toString(),
      revenueType: 'On-Premise',
    }));
  });

  it('getSubscriptionPlanInfos should return renewal plan details when the plan code is not structured and renewal plan is defined', () => {
    // Arrange
    const params = {};
    const planInfos = [
      { code: 'unexpected', renewalPlanId: 102 },
    ] as any[];
    jest.spyOn(SubscriptionPlanDao, 'getSubscriptionPlanInfos').mockReturnValueOnce(planInfos);
    const renewalPlan = {
      revenueType: 'Support',
      productTier: ProductTier.Professional,
      productTierTitle: ProductTier.Professional.toString(),
      supportLevel: SupportLevel.Platinum,
      supportOnly: true,
    } as any;
    jest.spyOn(subscriptionPlanUtility, 'getSubscriptionPlanInfoById').mockReturnValueOnce(renewalPlan);

    // Act
    const result = subscriptionPlanUtility['getSubscriptionPlanInfos'](params);

    // Assert
    expect(result).toBeDefined();
    expect(result.length).toBe(1);
    expect(result[0]).toEqual(expect.objectContaining(renewalPlan));
  });

  it('getSubscriptionPlanInfos should return default plan details when the plan code is not structured and renewal plan is undefined', () => {
    // Arrange
    const params = {};
    const planInfos = [
      { code: 'unexpected', renewalPlanId: undefined },
    ] as any[];
    jest.spyOn(SubscriptionPlanDao, 'getSubscriptionPlanInfos').mockReturnValueOnce(planInfos);

    // Act
    const result = subscriptionPlanUtility['getSubscriptionPlanInfos'](params);

    // Assert
    expect(result).toBeDefined();
    expect(result.length).toBe(1);
    expect(result[0]).toEqual(expect.objectContaining({
      supportOnly: false,
      productTier: ProductTier.Standard,
      mainItemCode: planInfos[0].code,
      supportLevel: SupportLevel.Silver,
      supportItemCode: planInfos[0].code,
      isLegacyPlan: true,
      productTierTitle: ProductTier.Standard.toString(),
      revenueType: undefined,
    }));
  });
});
