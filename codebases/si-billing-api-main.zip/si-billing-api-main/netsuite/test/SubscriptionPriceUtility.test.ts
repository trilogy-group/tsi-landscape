import * as record from 'N/record';
import * as nsutils from '../src/ts/nsutils';
import subscriptionPriceUtility, { UptickParams } from '../src/ts/utility/SubscriptionPriceUtility';
import subscriptionGetUtility from '../src/ts/utility/SubscriptionGetUtility';
import SubscriptionPlanUtility from '../src/ts/utility/SubscriptionPlanUtility';
import { ChargeFrequency, ProductTier, SupportLevel } from '../src/ts/types';
import subscriptionValidateUtility from '../src/ts/utility/SubscriptionValidateUtility';
import { clone, roundMoney } from '../src/ts/utility/GeneralUtility';
import { MONTHS_IN_A_YEAR } from '../src/ts/models/TermDuration';
import { PriceTierType } from '../src/ts/models/SubscriptionPlan';
import { ApiSubscription } from '../src/ts/models/apitypes';

describe('subscriptionPriceUtility', () => {
  beforeEach(() => {
    jest.restoreAllMocks();
  });

  it('getCurrentDiscount', () => {
    (jest.spyOn(subscriptionGetUtility, 'getSubscriptionByIdInternal') as any).mockReturnValueOnce({
      term: { frequency: 'ANNUALLY' },
      plan: { id: 1 },
      items: [
        {
          id: 1,
          required: true,
          isMainItem: true,
          prices: [
            {
              frequency: 'ANNUALLY',
              ranges: [{ fromQuantity: 0, price: 5 }],
            },
          ],
        },
        {
          id: 2,
          prices: [
            {
              frequency: 'ANNUALLY',
              ranges: [{ fromQuantity: 0, price: 15 }],
            },
          ],
        },
        {
          id: 3,
          prices: [
            {
              frequency: 'ANNUALLY',
              ranges: [{ fromQuantity: 0, price: 20 }],
            },
          ],
        },
        {
          id: 4,
          prices: [
            {
              frequency: 'ANNUALLY',
              ranges: [{ fromQuantity: 0, price: 0 }],
            },
          ],
        },
      ],
      includedItems: [
        { id: 1, quantity: 2 },
        { id: 2, quantity: 3 },
        { id: 4, quantity: 3 },
      ],
    });
    (jest.spyOn(SubscriptionPlanUtility, 'getSubscriptionPlans') as any).mockReturnValueOnce([
      {
        name: 'something',
        items: [
          {
            id: 1,
            code: 'test1',
            required: true,
            isMainItem: true,
            prices: [
              {
                frequency: 'ANNUALLY',
                ranges: [{ fromQuantity: 0, price: 10 }],
              },
            ],
          },
          {
            id: 2,
            code: 'test2',
            prices: [
              {
                frequency: 'ANNUALLY',
                ranges: [{ fromQuantity: 0, price: 20 }],
              },
            ],
          },
          {
            id: 3,
            code: 'test3',
            prices: [
              {
                frequency: 'ANNUALLY',
                ranges: [{ fromQuantity: 0, price: 30 }],
              },
            ],
          },
          {
            id: 4,
            code: 'test4',
            prices: [
              {
                frequency: 'ANNUALLY',
                ranges: [{ fromQuantity: 0, price: 5 }],
              },
            ],
          },
        ],
      },
    ]);

    const res = subscriptionPriceUtility.getCurrentDiscount(1);
    expect(res).toStrictEqual({
      mainItemDiscount: 0.5,
      addons: [
        { id: 2, code: 'test2', discount: 0.25 },
        { id: 4, code: 'test4', discount: 1, freeQuantity: 3 },
      ],
    });
  });

  it('getCurrentDiscount validation', () => {
    expect(() => {
      subscriptionPriceUtility.getCurrentDiscount();
    }).toThrowError('SubscriptionId or subscription must be informed');
  });

  it('getPricesFromRanges should keep prices when the price tier types are identical', () => {
    // Arrange
    const currentRanges = [
      {
        type: PriceTierType[PriceTierType.FixedAmount],
        price: 8,
        fromQuantity: 0,
      }
    ];
    const listedRanges = [
      {
        type: PriceTierType[PriceTierType.FixedAmount],
        price: 10,
        fromQuantity: 0,
      }
    ];
    const quantity = 5;

    // Act
    const result = Object.getPrototypeOf(subscriptionPriceUtility).getPricesFromRanges(currentRanges, listedRanges, quantity);

    // Assert
    expect(result).toBeDefined();
    expect(result.currentPrice).toBe(currentRanges[0].price);
    expect(result.listedPrice).toBe(listedRanges[0].price);
  });

  it('getPricesFromRanges should multiplied the rate price by the quantity when the price tier types are different', () => {
    // Arrange
    const currentRanges = [
      {
        type: PriceTierType[PriceTierType.Rate],
        price: 1,
        fromQuantity: 0,
      }
    ];
    const listedRanges = [
      {
        type: PriceTierType[PriceTierType.FixedAmount],
        price: 10,
        fromQuantity: 0,
      }
    ];
    const quantity = 8;

    // Act
    const result = Object.getPrototypeOf(subscriptionPriceUtility).getPricesFromRanges(currentRanges, listedRanges, quantity);

    // Assert
    expect(result).toBeDefined();
    expect(result.currentPrice).toBe(currentRanges[0].price * quantity);
    expect(result.listedPrice).toBe(listedRanges[0].price);
  });

  it('applyDiscountInTiers', () => {
    const res = Object.getPrototypeOf(subscriptionPriceUtility).applyDiscountInTiers(
      1,
      undefined,
      {
        mainItemDiscount: 0.2,
      },
      true
    );
    expect(res).toBe(false);
  });

  it('applyDiscount', () => {
    (record.load as any).mockReturnValueOnce({
      getLineCount: () => 1,
      selectLine: () => {},
      getCurrentSublistValue: () => 10,
      getValue: () => 1,
    });
    let newValue;
    (record.create as any).mockReturnValueOnce({
      selectNewLine: () => {},
      setCurrentSublistValue: (a) => {
        if (a.fieldId === 'value') {
          newValue = a.value;
        }
      },
      commitLine: () => {},
      save: () => newValue,
      setValue: () => {},
    });

    const res = subscriptionPriceUtility.applyDiscount(0.4, 1);
    expect(res).toBe(6);
  });

  it('createNewPricePlan zero', () => {
    (record.create as any).mockReturnValueOnce({
      selectNewLine: () => {},
      setCurrentSublistValue: () => {},
      commitLine: () => {},
      save: () => 1,
    });

    const res = subscriptionPriceUtility.createNewPricePlan(1, 1);
    expect(res).toBe(1);
  });

  it('createNewPricePlan freeQuantity', () => {
    (record.create as any).mockReturnValueOnce({
      selectNewLine: () => {},
      setCurrentSublistValue: () => {},
      commitLine: () => {},
      save: () => 1,
      setValue: () => {},
    });
    let line = 0;
    (record.load as any).mockReturnValueOnce({
      getLineCount: () => 4,
      selectLine: () => {},
      getCurrentSublistValue: (f) => {
        if (f.fieldId === 'fromval') {
          switch (line) {
            case 0:
              line++;
              return 0;
            case 1:
              line++;
              return 1;
          }
        }
        return 10;
      },
      getValue: () => 1,
    });

    const res = subscriptionPriceUtility.createNewPricePlan(1, 0.5, 3);
    expect(res).toBe(1);
  });

  it('createNewPricePlan freeQuantity 1 tier', () => {
    (record.create as any).mockReturnValueOnce({
      selectNewLine: () => {},
      setCurrentSublistValue: () => {},
      commitLine: () => {},
      save: () => 1,
      setValue: () => {},
    });
    (record.load as any).mockReturnValueOnce({
      getLineCount: () => 1,
      selectLine: () => {},
      getCurrentSublistValue: () => 10,
      getValue: () => 1,
    });

    const res = subscriptionPriceUtility.createNewPricePlan(1, 0.5, 3);
    expect(res).toBe(1);
  });

  it('calcItemTotalPrice', () => {
    const item1 = {
      id: 75865,
      code: 'SOT-SA-USE-STA',
      required: true,
      type: 'Recurring',
      typeId: 1,
      title: 'title',
      desc: 'desc',
      minQuantity: 0,
      maxQuantity: 9999,
      isSupportMainItem: false,
      isSupportAddonItem: false,
      isMainItem: true,
      prices: [
        {
          type: 'Tiered',
          frequency: 'ANNUALLY',
          currency: 'USD',
          pricebookid: 1,
          ranges: [
            {
              priceplanid: 1,
              type: 'FixedAmount',
              fromQuantity: 0,
              price: 1000,
            },
            {
              priceplanid: 2,
              type: 'Rate',
              fromQuantity: 1000,
              price: 12,
            },
          ],
        },
      ],
    };

    const item2 = {
      id: 75869,
      code: 'SOT-SA-MED-STA',
      required: false,
      type: 'Recurring',
      typeId: 1,
      title: 'title',
      desc: 'desc',
      minQuantity: 0,
      maxQuantity: 9999,
      isSupportMainItem: false,
      isSupportAddonItem: false,
      isMainItem: true,
      prices: [
        {
          type: 'Volume',
          frequency: 'ANNUALLY',
          currency: 'USD',
          pricebookid: 1,
          ranges: [
            {
              priceplanid: 1,
              type: 'Rate',
              fromQuantity: 0,
              price: 5,
            },
            {
              priceplanid: 2,
              type: 'Rate',
              fromQuantity: 1000,
              price: 4,
            },
          ],
        },
      ],
    };

    const item3 = {
      id: 75869,
      code: 'SOT-SA-MED-STA',
      required: false,
      type: 'Recurring',
      typeId: 1,
      title: 'title',
      desc: 'desc',
      minQuantity: 0,
      maxQuantity: 9999,
      isSupportMainItem: false,
      isSupportAddonItem: false,
      isMainItem: true,
      prices: [
        {
          type: 'Tiered',
          frequency: 'MONTHLY',
          currency: 'USD',
          pricebookid: 1,
          ranges: [
            {
              priceplanid: 1,
              type: 'Rate',
              fromQuantity: 0,
              price: 5,
            },
            {
              priceplanid: 2,
              type: 'Rate',
              fromQuantity: 1000,
              price: 4,
            },
          ],
        },
      ],
    };

    const item4_invalidRangeType = {
      id: 75869,
      code: 'SOT-SA-MED-STA',
      required: false,
      type: 'Recurring',
      typeId: 1,
      title: 'title',
      desc: 'desc',
      minQuantity: 0,
      maxQuantity: 9999,
      isSupportMainItem: false,
      isSupportAddonItem: false,
      isMainItem: true,
      prices: [
        {
          type: 'Invalid',
          frequency: 'MONTHLY',
          currency: 'USD',
          pricebookid: 1,
          ranges: [
            {
              priceplanid: 1,
              type: 'Invalid',
              fromQuantity: 0,
              price: 5,
            },
          ],
        },
      ],
    };

    let res = subscriptionPriceUtility.calcItemTotalPrice(
      JSON.parse(JSON.stringify(item1)),
      null,
      100,
      'USD',
      'ANNUALLY',
      12,
      { mainItemDiscount: 0.75 }
    );
    expect(res).toStrictEqual({ amount: 250, recuringAmount: 250, totalIntervalValue: 250, totalListPrice: 1000 });

    res = subscriptionPriceUtility.calcItemTotalPrice(
      JSON.parse(JSON.stringify(item1)),
      null,
      300,
      'USD',
      'ANNUALLY',
      12,
      {
        mainItemDiscount: 0.75,
        addons: [{ id: 75865, code: 'SOT-SA-USE-STA', discount: 0.2 }],
      }
    );
    expect(res).toStrictEqual({ amount: 800, recuringAmount: 800, totalIntervalValue: 800, totalListPrice: 1000 });

    res = subscriptionPriceUtility.calcItemTotalPrice(item1, null, 1, 'USD', 'ANNUALLY', 12);
    expect(res).toStrictEqual({ amount: 1000, recuringAmount: 1000, totalIntervalValue: 1000, totalListPrice: 1000 });

    res = subscriptionPriceUtility.calcItemTotalPrice(item1, null, 10, 'USD', 'ANNUALLY', 12);
    expect(res).toStrictEqual({ amount: 1000, recuringAmount: 1000, totalIntervalValue: 1000, totalListPrice: 1000 });

    res = subscriptionPriceUtility.calcItemTotalPrice(item1, null, 999, 'USD', 'ANNUALLY', 12);
    expect(res).toStrictEqual({ amount: 1000, recuringAmount: 1000, totalIntervalValue: 1000, totalListPrice: 1000 });

    res = subscriptionPriceUtility.calcItemTotalPrice(item1, null, 1000, 'USD', 'ANNUALLY', 12);
    expect(res).toStrictEqual({ amount: 1000, recuringAmount: 1000, totalIntervalValue: 1000, totalListPrice: 1000 });

    res = subscriptionPriceUtility.calcItemTotalPrice(item1, null, 1001, 'USD', 'ANNUALLY', 12);
    expect(res).toStrictEqual({ amount: 1012, recuringAmount: 1012, totalIntervalValue: 1012, totalListPrice: 1012 });

    res = subscriptionPriceUtility.calcItemTotalPrice(item1, null, 1010, 'USD', 'ANNUALLY', 12);
    expect(res).toStrictEqual({ amount: 1120, recuringAmount: 1120, totalIntervalValue: 1120, totalListPrice: 1120 });

    res = subscriptionPriceUtility.calcItemTotalPrice(item2, null, 1, 'USD', 'ANNUALLY', 12);
    expect(res).toStrictEqual({ amount: 5, recuringAmount: 5, totalIntervalValue: 5, totalListPrice: 5 });

    res = subscriptionPriceUtility.calcItemTotalPrice(item2, null, 10, 'USD', 'ANNUALLY', 12);
    expect(res).toStrictEqual({ amount: 50, recuringAmount: 50, totalIntervalValue: 50, totalListPrice: 50 });

    res = subscriptionPriceUtility.calcItemTotalPrice(item2, null, 999, 'USD', 'ANNUALLY', 12);
    expect(res).toStrictEqual({ amount: 4995, recuringAmount: 4995, totalIntervalValue: 4995, totalListPrice: 4995 });

    res = subscriptionPriceUtility.calcItemTotalPrice(item2, null, 1000, 'USD', 'ANNUALLY', 12);
    expect(res).toStrictEqual({ amount: 4000, recuringAmount: 4000, totalIntervalValue: 4000, totalListPrice: 4000 });

    res = subscriptionPriceUtility.calcItemTotalPrice(item2, null, 1001, 'USD', 'ANNUALLY', 12);
    expect(res).toStrictEqual({ amount: 4004, recuringAmount: 4004, totalIntervalValue: 4004, totalListPrice: 4004 });

    res = subscriptionPriceUtility.calcItemTotalPrice(item2, null, 1010, 'USD', 'ANNUALLY', 12);
    expect(res).toStrictEqual({ amount: 4040, recuringAmount: 4040, totalIntervalValue: 4040, totalListPrice: 4040 });

    res = subscriptionPriceUtility.calcItemTotalPrice(item3, null, 1, 'USD', 'MONTHLY', 1);
    expect(res).toStrictEqual({ amount: 5, recuringAmount: 5, totalIntervalValue: 5, totalListPrice: 5 });

    res = subscriptionPriceUtility.calcItemTotalPrice(item3, null, 10, 'USD', 'MONTHLY', 1);
    expect(res).toStrictEqual({ amount: 50, recuringAmount: 50, totalIntervalValue: 50, totalListPrice: 50 });

    res = subscriptionPriceUtility.calcItemTotalPrice(item3, null, 999, 'USD', 'MONTHLY', 1);
    expect(res).toStrictEqual({ amount: 4995, recuringAmount: 4995, totalIntervalValue: 4995, totalListPrice: 4995 });

    res = subscriptionPriceUtility.calcItemTotalPrice(item3, null, 1000, 'USD', 'MONTHLY', 1);
    expect(res).toStrictEqual({ amount: 5000, recuringAmount: 5000, totalIntervalValue: 5000, totalListPrice: 5000 });

    res = subscriptionPriceUtility.calcItemTotalPrice(item3, null, 1001, 'USD', 'MONTHLY', 1);
    expect(res).toStrictEqual({ amount: 5004, recuringAmount: 5004, totalIntervalValue: 5004, totalListPrice: 5004 });

    res = subscriptionPriceUtility.calcItemTotalPrice(item3, null, 1010, 'USD', 'MONTHLY', 1);
    expect(res).toStrictEqual({ amount: 5040, recuringAmount: 5040, totalIntervalValue: 5040, totalListPrice: 5040 });

    res = subscriptionPriceUtility.calcItemTotalPrice(item3, null, 0, 'USD', 'MONTHLY', 1);
    expect(res).toStrictEqual({ amount: 0, recuringAmount: 0, totalIntervalValue: 0, totalListPrice: 0 });

    expect(() => {
      subscriptionPriceUtility.calcItemTotalPrice(item4_invalidRangeType, null, 1000, 'USD', 'MONTHLY', 1);
    }).toThrowError('Invalid price type Invalid');
  });

  it('calculateDefaultUptickPrices item not found', () => {
    (jest.spyOn(Object.getPrototypeOf(subscriptionPriceUtility), 'findTiers') as any).mockReturnValue(undefined);
    const subscriptionItems = [
      {
        id: 1,
        code: 'A',
        prices: [
          {
            ranges: [
              {
                fromQuantity: 0,
                price: 5,
              },
            ],
          },
        ],
      },
    ];
    const parentSubscription = {
      items: [
        {
          id: 3,
          required: true,
          prices: [
            {
              ranges: [
                {
                  fromQuantity: 0,
                  price: 20,
                },
              ],
            },
          ],
        },
      ],
      includedItems: [
        {
          id: 3,
          quantity: 5,
        },
      ],
    };
    const params = {
      isDowngrade: true,
      subscriptionPlan: {
        items: [],
      },
      uptickPercent: 0.25,
    };
    expect(() => {
      Object.getPrototypeOf(subscriptionPriceUtility).calculateDefaultUptickPrices(
        subscriptionItems,
        parentSubscription,
        params
      );
    }).toThrowError('Price frequency not found for item id 1 (code: A) and frequency undefined');
  });

  it('calculateDefaultUptickPrices 1', () => {
    const subscriptionItems = [
      {
        id: 2,
        required: true,
        prices: [
          {
            frequency: 'ANNUALLY',
            ranges: [
              {
                type: "Rate",
                fromQuantity: 0,
                price: 10,
              },
            ],
          },
        ],
      },
      {
        id: 4,
        prices: [
          {
            frequency: 'ANNUALLY',
            ranges: [
              {
                type: "Rate",
                fromQuantity: 0,
                price: 10,
              },
            ],
          },
        ],
      },
    ];
    const parentSubscription = {
      items: [
        {
          id: 3,
          required: true,
          prices: [
            {
              frequency: 'ANNUALLY',
              ranges: [
                {
                  type: "Rate",
                  fromQuantity: 0,
                  price: 20,
                },
              ],
            },
          ],
        },
        {
          id: 4,
          prices: [
            {
              frequency: 'ANNUALLY',
              ranges: [
                {
                  type: "Rate",
                  fromQuantity: 0,
                  price: 5,
                },
              ],
            },
          ],
        },
      ],
      includedItems: [
        {
          id: 3,
          quantity: 5,
        },
        {
          id: 4,
          quantity: 7,
        },
      ],
    };

    const params: UptickParams = {
      isLegacySubscription: false,
      isSupportOnlyPlan: false,
      isPlanDowngrade: true,
      isQuantityDowngrade: false,
      isSameEdition: true,
      isPreview: true,
      isDraftUpdate: false,
      uptickPercent: 0.25,
      frequency: 'ANNUALLY',
      planItems: [
        {
          id: 2,
          required: true,
          prices: [
            {
              frequency: 'ANNUALLY',
              ranges: [
                {
                  type: "Rate",
                  fromQuantity: 0,
                  price: 30,
                },
              ],
            },
          ],
        },
        {
          id: 4,
          prices: [
            {
              frequency: 'ANNUALLY',
              ranges: [
                {
                  type: "Rate",
                  fromQuantity: 0,
                  price: 40,
                },
              ],
            },
          ],
        },
      ] as any,
      isDraftRenewalCreation: false,
    };
    const res = Object.getPrototypeOf(subscriptionPriceUtility).calculateDefaultUptickPrices(
      subscriptionItems,
      parentSubscription,
      params
    );
    expect(res).toEqual(
      expect.objectContaining([
        {
          id: 2,
          price: {
            frequency: 'ANNUALLY',
            ranges: [
              {
                fromQuantity: 0,
                price: 30,
                type: "Rate"
              },
            ],
          },
        },
        {
          id: 4,
          price: {
            frequency: 'ANNUALLY',
            ranges: [
              {
                fromQuantity: 0,
                price: 40,
                type: "Rate"
              },
            ],
          },
        },
      ])
    );
  });

  it('calculateDefaultUptickPrices 2', () => {
    const subscriptionItems = [
      {
        id: 1,
        code: 'DNN-OP-CUS-STA',
        prices: [
          {
            type: "Tiered",
            ranges: [
              {
                fromQuantity: 0,
                price: 5,
                type: "Rate"
              },
            ],
          },
        ],
      },
      {
        id: 2,
        code: 'DNN-TE-CUS-ADD',
        required: true,
        prices: [
          {
            type: "Tiered",
            ranges: [
              {
                fromQuantity: 0,
                price: 10,
                type: "Rate"
              },
            ],
          },
        ],
      },
      {
        id: 4,
        code: 'DNN-TE-BAS-ADD',
        prices: [
          {
            type: "Tiered",
            ranges: [
              {
                fromQuantity: 0,
                price: 10,
                type: "Rate"
              },
            ],
          },
        ],
      },
    ];
    const parentSubscription = {
      items: [
        {
          id: 3,
          code: 'DNN-OP-CUS-PRO',
          required: true,
          isMainItem: true,
          prices: [
            {
              type: "Tiered",
              ranges: [
                {
                  fromQuantity: 0,
                  price: 20,
                  type: "Rate"
                },
              ],
            },
          ],
        },
        {
          id: 4,
          code: 'DNN-TE-BAS-ADD',
          prices: [
            {
              type: "Tiered",
              ranges: [
                {
                  fromQuantity: 0,
                  price: 5,
                  type: "Rate"
                },
              ],
            },
          ],
        },
      ],
      includedItems: [
        {
          id: 3,
          code: 'DNN-OP-CUS-PRO',
          quantity: 5,
        },
        {
          id: 4,
          code: 'DNN-TE-BAS-ADD',
          quantity: 7,
        },
      ],
    };
    const params: UptickParams = {
      isLegacySubscription: false,
      isSupportOnlyPlan: false,
      isPlanDowngrade: false,
      isQuantityDowngrade: false,
      isSameEdition: true,
      isPreview: true,
      isDraftUpdate: false,
      uptickPercent: 0.25,
      frequency: 'ANNUALLY',
      planItems: [
        {
          id: 1,
          code: 'DNN-OP-CUS-STA',
          prices: [
            {
              type: "Tiered",
              frequency: 'ANNUALLY',
              ranges: [
                {
                  fromQuantity: 0,
                  price: 15,
                  type: "Rate"
                },
              ],
            },
          ],
        },
        {
          id: 2,
          code: 'DNN-TE-CUS-ADD',
          required: true,
          prices: [
            {
              type: "Tiered",
              frequency: 'ANNUALLY',
              ranges: [
                {
                  fromQuantity: 0,
                  price: 30,
                  type: "Rate"
                },
              ],
            },
          ],
        },
        {
          id: 4,
          code: 'DNN-TE-BAS-ADD',
          prices: [
            {
              type: "Tiered",
              frequency: 'ANNUALLY',
              ranges: [
                {
                  fromQuantity: 0,
                  price: 40,
                  type: "Rate"
                },
              ],
            },
          ],
        },
      ] as any,
      isDraftRenewalCreation: false,
    };
    const res = Object.getPrototypeOf(subscriptionPriceUtility).calculateDefaultUptickPrices(
      subscriptionItems,
      parentSubscription,
      params,
      { item: subscriptionItems[0], isIncluded: true, quantity: 1 }
    );
    expect(res).toStrictEqual([
      {
        id: 1,
        price: {
          type: "Tiered",
          ranges: [
            {
              fromQuantity: 0,
              price: 15,
              priceplanid: undefined,
              type: "Rate"
            },
          ],
        },
      },
      {
        id: 2,
        price: {
          type: "Tiered",
          ranges: [
            {
              priceplanid: undefined,
              fromQuantity: 0,
              price: 25,
              type: "Rate"
            },
          ],
        },
      },
      {
        id: 4,
        price: {
          type: "Tiered",
          ranges: [
            {
              priceplanid: undefined,
              fromQuantity: 0,
              price: 6.25,
              type: "Rate"
            },
          ],
        },
      },
    ]);
  });

  it('calculateDefaultUptickPrices downgrade', () => {
    const subscriptionItems = [
      {
        id: 1,
        code: 'DNN-OP-CUS-STA',
        prices: [
          {
            type: "Tiered",
            frequency: 'ANNUALLY',
            ranges: [
              {
                fromQuantity: 0,
                price: 5,
                type: "Rate"
              },
            ],
          },
        ],
      },
      {
        id: 2,
        code: 'DNN-TE-CUS-ADD',
        required: true,
        prices: [
          {
            type: "Tiered",
            frequency: 'ANNUALLY',
            ranges: [
              {
                fromQuantity: 0,
                price: 10,
                type: "Rate"
              },
            ],
          },
        ],
      },
      {
        id: 4,
        code: 'DNN-TE-BAS-ADD',
        prices: [
          {
            type: "Tiered",
            frequency: 'ANNUALLY',
            ranges: [
              {
                fromQuantity: 0,
                price: 10,
                type: "Rate"
              },
            ],
          },
        ],
      },
    ];
    const parentSubscription = {
      items: [
        {
          id: 3,
          code: 'DNN-OP-CUS-PRO',
          required: true,
          isMainItem: true,
          prices: [
            {
              type: "Tiered",
              frequency: 'ANNUALLY',
              ranges: [
                {
                  fromQuantity: 0,
                  price: 10,
                  type: "Rate"
                },
              ],
            },
          ],
        },
        {
          id: 4,
          code: 'DNN-TE-BAS-ADD',
          prices: [
            {
              type: "Tiered",
              frequency: 'ANNUALLY',
              ranges: [
                {
                  fromQuantity: 0,
                  price: 80,
                  type: "Rate"
                },
              ],
            },
          ],
        },
      ],
      includedItems: [
        {
          id: 3,
          code: 'DNN-OP-CUS-PRO',
          quantity: 5,
        },
        {
          id: 4,
          code: 'DNN-TE-BAS-ADD',
          quantity: 7,
        },
      ],
    };
    const params = {
      mainItem: {
        item: {
          id: 1,
        },
      },
      isPlanDowngrade: true,
      isQuantityDowngrade: false,
      isSameEdition: false,
      uptickPercent: 0.25,
      frequency: 'ANNUALLY',
      planItems: [
        {
          id: 1,
          code: 'DNN-OP-CUS-STA',
          prices: [
            {
              type: "Tiered",
              frequency: 'ANNUALLY',
              ranges: [
                {
                  fromQuantity: 0,
                  price: 10,
                  type: "Rate"
                },
              ],
            },
          ],
        },
        {
          id: 2,
          code: 'DNN-TE-CUS-ADD',
          required: true,
          prices: [
            {
              type: "Tiered",
              frequency: 'ANNUALLY',
              ranges: [
                {
                  fromQuantity: 0,
                  price: 20,
                  type: "Rate"
                },
              ],
            },
          ],
        },
        {
          id: 4,
          code: 'DNN-TE-BAS-ADD',
          prices: [
            {
              type: "Tiered",
              frequency: 'ANNUALLY',
              ranges: [
                {
                  fromQuantity: 0,
                  price: 20,
                  type: "Rate"
                },
              ],
            },
          ],
        },
      ],
      discounts: {
        mainItemDiscount: -0.4,
        addons: [],
      },
      legacyPriceMultiplier: 1,
    };
    const res = Object.getPrototypeOf(subscriptionPriceUtility).calculateDefaultUptickPrices(
      subscriptionItems,
      parentSubscription,
      params
    );
    expect(res).toStrictEqual([
      {
        id: 1,
        price: {
          type: "Tiered",
          frequency: 'ANNUALLY',
          ranges: [
            {
              fromQuantity: 0,
              price: 10,
              type: "Rate"
            },
          ],
        },
      },
      {
        id: 2,
        price: {
          type: "Tiered",
          frequency: 'ANNUALLY',
          ranges: [
            {
              fromQuantity: 0,
              price: 20,
              type: "Rate"
            },
          ],
        },
      },
      {
        id: 4,
        price: {
          type: "Tiered",
          frequency: 'ANNUALLY',
          ranges: [
            {
              fromQuantity: 0,
              price: 20,
              type: "Rate"
            },
          ],
        },
      },
    ]);
  });

  it('calculateDefaultUptickPrices should not carry over ARR of missing items for a non-legacy subscription', () => {
    // Arrange
    const mock = mockForCalculateDefaultUptickPrices(false);

    // Act
    const result = mock.action();

    // Assert
    expect(result).toBeDefined();
    expect(Object.getPrototypeOf(subscriptionPriceUtility).carryOverMissingItemsArrForLegacySubscriptions).not.toHaveBeenCalled();
  });

  it('calculateDefaultUptickPrices should carry over ARR of missing items for a legacy subscription', () => {
    // Arrange
    const mock = mockForCalculateDefaultUptickPrices(true);

    // Act
    const result = mock.action();

    // Assert
    expect(result).toBeDefined();
    expect(Object.getPrototypeOf(subscriptionPriceUtility).carryOverMissingItemsArrForLegacySubscriptions).toHaveBeenCalled();
  });

  function mockForCalculateDefaultUptickPrices(isLegacySubscription?: boolean): {
    action: () => any,
  } {
    const subscriptionItems = [
      { id: 1, code: 'A' }
    ];
    const parentSubscription = {
      items: [],
      includedItems: [],
    };
    const uptickParams = {
      isLegacySubscription: isLegacySubscription ?? false,
    };
    const overridenMethods = [
      { name: 'getUptickPricesForItem' },
      { name: 'carryOverMissingItemsArrForLegacySubscriptions' },
    ];
    for (const method of overridenMethods) {
      jest.spyOn(Object.getPrototypeOf(subscriptionPriceUtility), method.name).mockImplementation(() => {});
    }
    return {
      action: () => Object.getPrototypeOf(subscriptionPriceUtility)
        .calculateDefaultUptickPrices(subscriptionItems, parentSubscription, uptickParams),
    };
  }

  it('getUptickPricesForItem', () => {
    const { item, parentSubscription, params } = {
      item: {
        id: 84628,
        code: 'DNNE-SA-Cus-CON',
        title: 'DNNE Customer Cloud EVOQ Content',
        type: 'Recurring',
        typeId: 2,
        desc: null,
        minQuantity: null,
        maxQuantity: null,
        required: true,
        prices: [
          {
            type: 'Volume',
            frequency: 'ANNUALLY',
            currency: 'USD',
            pricebookid: 10611,
            ranges: [{ priceplanid: 4612895, type: 'Rate', fromQuantity: 0, price: 20 }],
          },
        ],
        amount: 1,
        supportLevel: null,
        productTier: 'Professional',
        revenueType: 'SaaS',
      },
      parentSubscription: {
        id: 964576,
        status: 'ACTIVE',
        customer: {
          id: '1718647672',
          firstName: 'E2E',
          lastName: 'E2Ev - 1646226115605',
          email: 'e2e.1646226115605@example.com',
          companyName: 'E2E Company 1646226115605',
        },
        distributor: null,
        reseller: null,
        endUser: {
          id: '1718647672',
          firstName: 'E2E',
          lastName: 'E2Ev - 1646226115605',
          email: 'e2e.1646226115605@example.com',
          companyName: 'E2E Company 1646226115605',
        },
        plan: {
          id: 84641,
          code: 'DNNE Customer Cloud EVOQ BASIC',
          title: null,
          productTier: 'Standard',
          productTierTitle: 'Standard',
          supportLevel: 'Silver',
          revenueType: 'SaaS',
          isTrial: false,
        },
        items: [
          {
            id: 84626,
            code: 'DNNE-SA-Cus-BAS',
            title: 'DNNE Customer Cloud EVOQ Basic',
            type: 'Recurring',
            typeId: 2,
            desc: null,
            minQuantity: null,
            maxQuantity: null,
            required: true,
            prices: [
              {
                type: 'Volume',
                frequency: 'ANNUALLY',
                currency: 'USD',
                pricebookid: 10611,
                ranges: [
                  { priceplanid: 4774085, type: 'Rate', fromQuantity: 0, price: 2 },
                  { priceplanid: 4774085, type: 'Rate', fromQuantity: 10, price: 1.8 },
                ],
              },
            ],
            amount: 4,
            supportLevel: null,
            productTier: 'Standard',
            revenueType: 'SaaS',
          },
        ],
        includedItems: [{ id: 84626, code: 'DNNE-SA-Cus-BAS', quantity: 2 }],
        term: { start: '2-Mar-2022', end: '1-Mar-2023', frequency: 'ANNUALLY' },
        autorenewal: true,
        renewalNumber: 0,
        totalAmount: 4,
        currency: 'USD'
      },
      params: {
        isSamePlan: false,
        isPlanDowngrade: false,
        isQuantityDowngrade: false,
        isSameEdition: false,
        uptickPercent: 0.35,
        frequency: 'ANNUALLY',
        planItems: [
          {
            id: 84628,
            code: 'DNNE-SA-Cus-CON',
            title: 'DNNE Customer Cloud EVOQ Content',
            supportLevel: null,
            required: true,
            type: 'Recurring',
            typeId: 2,
            desc: null,
            minQuantity: null,
            maxQuantity: null,
            prices: [
              {
                type: 'Volume',
                frequency: 'ANNUALLY',
                currency: 'USD',
                pricebookid: 10614,
                ranges: [{ priceplanid: 4612895, type: 'Rate', fromQuantity: 0, price: 20 }],
              },
            ],
          },
        ],
        discounts: { mainItemDiscount: 0.8, addons: [] },
        legacyPriceMultiplier: 1,
      },
    };
    const res = Object.getPrototypeOf(subscriptionPriceUtility).getUptickPricesForItem(
      item,
      parentSubscription,
      params
    );
    expect(res).toStrictEqual({
      id: 84628,
      price: {
        type: 'Volume',
        frequency: 'ANNUALLY',
        currency: 'USD',
        pricebookid: 10614,
        ranges: [{ priceplanid: 4612895, type: 'Rate', fromQuantity: 0, price: 5.4 }],
      },
    });
  });

  it('getUptickPricesForItem - renew with a different plan, having the same edition and same success level', () => {
    const params = {
      item: {
        id: 84626,
        code: 'DNNE-SA-Cus-BAS',
        title: 'DNNE Customer Cloud EVOQ Basic',
        type: 'Recurring',
        typeId: 2,
        desc: null,
        minQuantity: null,
        maxQuantity: null,
        required: true,
        prices: [
          {
            type: 'Volume',
            frequency: 'ANNUALLY',
            currency: 'USD',
            pricebookid: 10621,
            ranges: [{ priceplanid: 4779008, type: 'Rate', fromQuantity: 0, price: 22 }],
          },
        ],
        amount: 2,
        totalIntervalValue: 2,
        recuringAmount: 2,
        frequency: 'Annually',
        repeatEvery: 1,
        supportLevel: null,
        productTier: 'Standard',
        revenueType: 'SaaS',
        isMainItem: true,
        isSupportItem: false,
        quantity: 2,
      },
      parentSubscription: {
        id: 1112769,
        status: 'ACTIVE',
        customer: {
          id: '1718651811',
          firstName: 'E2E',
          lastName: 'E2Ev - 1654351788253',
          email: 'e2e.1654351788253@example.com',
          phone: '1234567',
          companyName: 'E2E Company 1654351788253',
        },
        distributor: null,
        reseller: null,
        endUser: {
          id: '1718651811',
          firstName: 'E2E',
          lastName: 'E2Ev - 1654351788253',
          email: 'e2e.1654351788253@example.com',
          phone: '1234567',
          companyName: 'E2E Company 1654351788253',
        },
        plan: {
          id: 84650,
          code: 'DNNE-SA-Cus-BAS-Add-001',
          title: 'DNNE Customer EVOQ BASIC Addon',
          productTier: 'Standard',
          productTierTitle: 'Standard',
          supportLevel: 'Silver',
          revenueType: 'SaaS',
          isTrial: false,
          isSupportOnly: false,
          isLegacy: false,
        },
        items: [
          {
            id: 84626,
            code: 'DNNE-SA-Cus-BAS',
            title: 'DNNE Customer Cloud EVOQ Basic',
            type: 'Recurring',
            typeId: 2,
            desc: null,
            minQuantity: null,
            maxQuantity: null,
            required: true,
            prices: [
              {
                type: 'Volume',
                frequency: 'ANNUALLY',
                currency: 'USD',
                pricebookid: 10621,
                ranges: [{ priceplanid: 5041357, type: 'Rate', fromQuantity: 0, price: 6 }],
              },
            ],
            amount: 12,
            totalIntervalValue: 12,
            recuringAmount: 12,
            frequency: 'Annually',
            repeatEvery: 1,
            supportLevel: null,
            productTier: 'Standard',
            revenueType: 'SaaS',
            isMainItem: true,
            isSupportItem: false,
            quantity: 2,
          },
          {
            id: 84636,
            code: 'DNNE-SA-Add-BAS',
            title: 'DNNE Addon',
            type: 'Recurring',
            typeId: 2,
            desc: null,
            minQuantity: null,
            maxQuantity: null,
            required: false,
            prices: [
              {
                type: 'Volume',
                frequency: 'ANNUALLY',
                currency: 'USD',
                pricebookid: 10621,
                ranges: [{ priceplanid: 5041359, type: 'Rate', fromQuantity: 0, price: 9 }],
              },
            ],
            amount: 9,
            totalIntervalValue: 9,
            recuringAmount: 9,
            frequency: 'Annually',
            repeatEvery: 1,
            supportLevel: null,
            productTier: null,
            revenueType: 'SaaS',
            isMainItem: false,
            isSupportItem: false,
            quantity: 1,
          },
        ],
        includedItems: [
          { id: 84626, code: 'DNNE-SA-Cus-BAS', quantity: 2 },
          { id: 84636, code: 'DNNE-SA-Add-BAS', quantity: 1 },
        ],
        term: { start: '4-Jun-2022', end: '3-Jun-2023', frequency: 'ANNUALLY', nextBillCycleDate: '4-Jun-2022' },
        autorenewal: true,
        renewalNumber: 0,
        totalAmount: 21,
        totalIntervalValue: 21,
        operations: ['renew'],
      },
      uptickParams: {
        isLegacySubscription: false,
        isSamePlan: false,
        isPlanDowngrade: false,
        isQuantityDowngrade: false,
        isSameEdition: true,
        isDraftRenewalCreation: false,
        isPreview: true,
        isDraftUpdate: false,
        uptickPercent: 0.25,
        frequency: 'ANNUALLY',
        planItems: [
          {
            id: 84626,
            code: 'DNNE-SA-Cus-BAS',
            title: 'DNNE Customer Cloud EVOQ Basic',
            supportLevel: null,
            productTier: 'Standard',
            revenueType: 'SaaS',
            isSupportItem: false,
            isMainItem: true,
            required: true,
            type: 'Recurring',
            typeId: 2,
            desc: null,
            minQuantity: null,
            maxQuantity: null,
            prices: [
              {
                type: 'Volume',
                frequency: 'ANNUALLY',
                currency: 'USD',
                pricebookid: 12460,
                ranges: [{ priceplanid: 4779008, type: 'Rate', fromQuantity: 0, price: 22 }],
              },
            ],
          },
          {
            id: 84627,
            code: 'DNNE-SA-Cus-SIL',
            title: 'DNNE Silver Support',
            supportLevel: 'Silver',
            productTier: null,
            revenueType: 'SaaS',
            isSupportItem: true,
            isMainItem: false,
            required: true,
            type: 'Recurring',
            typeId: 2,
            desc: null,
            minQuantity: null,
            maxQuantity: null,
            prices: [
              {
                type: 'Volume',
                frequency: 'ANNUALLY',
                currency: 'USD',
                pricebookid: 12460,
                ranges: [{ priceplanid: 4779009, type: 'Rate', fromQuantity: 0, price: 0 }],
              },
            ],
          },
          {
            id: 86580,
            code: 'DNNE-SA-Add2-BAS',
            title: 'DNNE Addon',
            supportLevel: null,
            productTier: null,
            revenueType: 'SaaS',
            isSupportItem: false,
            isMainItem: false,
            required: false,
            type: 'Recurring',
            typeId: 2,
            desc: null,
            minQuantity: null,
            maxQuantity: null,
            prices: [
              {
                type: 'Volume',
                frequency: 'ANNUALLY',
                currency: 'USD',
                pricebookid: 12460,
                ranges: [{ priceplanid: 4779010, type: 'Rate', fromQuantity: 0, price: 20 }],
              },
            ],
          },
        ],
        discounts: { mainItemDiscount: 0.5, addons: [{ id: 84636, code: 'DNNE-SA-Add-BAS', discount: 0.4 }] },
      },
    };

    const res = Object.getPrototypeOf(subscriptionPriceUtility).getUptickPricesForItem(
      params.item,
      params.parentSubscription,
      params.uptickParams
    );
    const expected = {
      id: 84626,
      price: {
        type: 'Volume',
        frequency: 'ANNUALLY',
        currency: 'USD',
        pricebookid: 10621,
        ranges: [
          {
            priceplanid: 5041357,
            type: 'Rate',
            fromQuantity: 0,
            price: 7.5,
          },
        ],
      },
    };
    expect(res).toStrictEqual(expected);
  });
  it('addSupportPricesToItems', () => {
    const { items, supportItems } = {
      items: [
        {
          id: 84629,
          code: 'DNNE-SA-Cus-GOL',
          title: 'DNNE Gold Support',
          type: 'Recurring',
          typeId: 2,
          desc: null,
          minQuantity: null,
          maxQuantity: null,
          required: true,
          prices: [
            {
              type: 'Volume',
              frequency: 'ANNUALLY',
              currency: 'USD',
              pricebookid: 10612,
              ranges: [{ priceplanid: 4612896, type: 'Rate', fromQuantity: 0, price: 0 }],
            },
          ],
          amount: 1,
          supportLevel: 'Gold',
          productTier: null,
          revenueType: 'SaaS',
        },
      ],
      supportItems: [
        {
          id: 84629,
          code: 'DNNE-SA-Cus-GOL',
          title: 'DNNE Gold Support',
          type: 'Recurring',
          typeId: 2,
          desc: null,
          minQuantity: null,
          maxQuantity: null,
          required: true,
          prices: [
            {
              type: 'Volume',
              frequency: 'ANNUALLY',
              currency: 'USD',
              pricebookid: 10612,
              ranges: [{ priceplanid: 4612896, type: 'Rate', fromQuantity: 0, price: 0 }],
            },
          ],
          amount: 1,
          supportLevel: 'Gold',
          productTier: null,
          revenueType: 'SaaS',
        },
      ],
    };
    const res = Object.getPrototypeOf(subscriptionGetUtility).addSupportPricesToItems(items, supportItems);
    expect(res).toStrictEqual([
      {
        id: 84629,
        code: 'DNNE-SA-Cus-GOL',
        title: 'DNNE Gold Support',
        type: 'Recurring',
        typeId: 2,
        desc: null,
        minQuantity: null,
        maxQuantity: null,
        required: true,
        prices: [
          {
            type: 'Volume',
            frequency: 'ANNUALLY',
            currency: 'USD',
            pricebookid: 10612,
            ranges: [{ priceplanid: 4612896, type: 'Rate', fromQuantity: 0, price: 0 }],
          },
        ],
        amount: 1,
        supportLevel: 'Gold',
        productTier: null,
        revenueType: 'SaaS',
      },
    ]);
  });

  it('applyDiscountInTiers should apply the discount to the addon item when the codes are equal', () => {
    // Arrange
    const { itemCode, tiers, discounts, negativeDiscount } = {
      itemCode: 'DNNE-SA-Add-BPRO',
      tiers: [{ priceplanid: 4779010, type: 'Rate', fromQuantity: 0, price: 20 }],
      discounts: { mainItemDiscount: 0.5, addons: [{ id: 84636, code: 'DNNE-SA-Add-PRO', discount: 0.4 }] },
      negativeDiscount: false,
    };

    // Act
    const res = Object.getPrototypeOf(subscriptionPriceUtility).applyDiscountInTiers(
      itemCode,
      tiers,
      discounts,
      negativeDiscount
    );

    // Assert
    expect(res).toBe(true);
    expect(tiers[0].price).toBe(12);
  });

  it('applyDiscountInTiers should apply the discount to the addon item when the codes are different only in suffix', () => {
    // Arrange
    const { itemCode, tiers, discounts, negativeDiscount } = {
      itemCode: 'DNNE-SA-Add-ENT',
      tiers: [{ priceplanid: 4779010, type: 'Rate', fromQuantity: 0, price: 20 }],
      discounts: { mainItemDiscount: 0.5, addons: [{ id: 84636, code: 'DNNE-SA-Add-PRO', discount: 0.4 }] },
      negativeDiscount: false,
    };

    // Act
    const res = Object.getPrototypeOf(subscriptionPriceUtility).applyDiscountInTiers(
      itemCode,
      tiers,
      discounts,
      negativeDiscount
    );

    // Assert
    expect(res).toBe(true);
    expect(tiers[0].price).toBe(12);
  });

  it('getUptickPricesForItemNotIncludedInParent', () => {
    const item = {
      code: 'DNNE-SA-Sub-ADD'
    };
    const listPrice = 10;
    const planItemPrice = 5;
    const uptickParams = {
      isPlanDowngrade: true,
      discounts: {
        mainItemDiscount: 0.5
      }
    }
    const res = Object.getPrototypeOf(subscriptionPriceUtility).getUptickPricesForItemNotIncludedInParent(item, listPrice, planItemPrice, uptickParams);
    expect(res).toBe(10);
  });

  it('getMainAndSupportDistributionRatioForUptick', () => {
    const parentSubscription = {
      currency: 'USD',
      term: {
        frequency: 'ANNUALLY'
      }
    }
    const items = [{
      isMainItem: true,
      prices: [{
        frequency: 'ANNUALLY',
        currency: 'USD',
        ranges: [{
          fromQuantity: 0,
          price: 7
        }]
      }]
    },
    {
      isSupportMainItem: true,
      prices: [{
        frequency: 'ANNUALLY',
        currency: 'USD',
        ranges: [{
          fromQuantity: 0,
          price: 3
        }]
      }]
    }];
    const draftItems = {
      availableItems: items,
      mainItem: {}
    }
    const newPlan = {
      supportLevel: 'Silver',
      items: items
    }
    let res = Object.getPrototypeOf(subscriptionPriceUtility).getMainAndSupportDistributionRatioForUptick({}, true, false, newPlan, undefined, {}, {});
    expect(res).toBeCloseTo(0.1667,4);

    res = Object.getPrototypeOf(subscriptionPriceUtility).getMainAndSupportDistributionRatioForUptick(parentSubscription, false, false, newPlan, undefined, {}, {});
    expect(res).toBeCloseTo(0.3,4);

    res = Object.getPrototypeOf(subscriptionPriceUtility).getMainAndSupportDistributionRatioForUptick(parentSubscription, true, true, newPlan, draftItems, {}, {});
    expect(res).toBeCloseTo(0.1667,4);
  });

  it('applyDistributionRatioToSupportItems', () => {
    const supportItems = [{
      id: 1,
      code: 'DNNE-SA-bla-SIL'
    }];
    const availableItems = [{
      id: 2,
      code: 'DNNE-SA-Cus-STA'
    }];
    expect(() => {
      Object.getPrototypeOf(subscriptionPriceUtility).applyDistributionRatioToSupportItems(0.2,[],supportItems, availableItems);
    }).toThrowError('Match item not found for support item DNNE-SA-bla-SIL');
  });

  it('getPriceIntervalCountInTerm returns 1 for monthly frequency and no term', () => {
    const result = Object.getPrototypeOf(subscriptionPriceUtility).getPriceIntervalCountInTerm(ChargeFrequency.Monthly, 0);
    expect(result).toBe(1);
  });

  it('getPriceIntervalCountInTerm returns 1/4 for weekly frequency and no term', () => {
    const result = Object.getPrototypeOf(subscriptionPriceUtility).getPriceIntervalCountInTerm(ChargeFrequency.Weekly, 0);
    expect(result).toBe(1 / 4);
  });

  it('getPriceIntervalCountInTerm returns 12 for annually frequency and no term', () => {
    const result = Object.getPrototypeOf(subscriptionPriceUtility).getPriceIntervalCountInTerm(ChargeFrequency.Annually, 0);
    expect(result).toBe(12);
  });

  it('getPriceIntervalCountInTerm returns 3 for quarterly frequency and no term', () => {
    const result = Object.getPrototypeOf(subscriptionPriceUtility).getPriceIntervalCountInTerm(ChargeFrequency.Quarterly, 0);
    expect(result).toBe(3);
  });

  it('throws an error for an unsupported frequency-', () => {
    expect(() => Object.getPrototypeOf(subscriptionPriceUtility).getPriceIntervalCountInTerm('unsupported' as ChargeFrequency, 0)).toThrowError(
      'Not implemented for unsupported'
    );
  });

  it('getPriceIntervalCountInTerm returns the term in months for monthly frequency', () => {
    const result = Object.getPrototypeOf(subscriptionPriceUtility).getPriceIntervalCountInTerm(ChargeFrequency.Monthly, 6);
    expect(result).toBe(6);
  });

  it('getPriceIntervalCountInTerm returns the term in months times 4 for weekly frequency', () => {
    const result = Object.getPrototypeOf(subscriptionPriceUtility).getPriceIntervalCountInTerm(ChargeFrequency.Weekly, 6);
    expect(result).toBe(6 * 4);
  });

  it('getPriceIntervalCountInTerm returns the term in months divided by 12 for annually frequency', () => {
    const result = Object.getPrototypeOf(subscriptionPriceUtility).getPriceIntervalCountInTerm(ChargeFrequency.Annually, 24);
    expect(result).toBe(24 / 12);
  });

  it('getPriceIntervalCountInTerm returns the term in months divided by 4 for quarterly frequency', () => {
    const result = Object.getPrototypeOf(subscriptionPriceUtility).getPriceIntervalCountInTerm(ChargeFrequency.Quarterly, 24);
    expect(result).toBe(24 / 3);
  });

  it('throws an error for an unsupported frequency', () => {
    expect(() => Object.getPrototypeOf(subscriptionPriceUtility).getPriceIntervalCountInTerm('unsupported' as ChargeFrequency, 6)).toThrowError(
      'Not implemented for unsupported'
    );
  });

  it('calcUptickPrices should use default uptick prices when the calculation succeeds', () => {
    // Arrange
    const mock = mockForCalcUptickPrices();

    // Act
    const result = mock.action();

    // Assert
    expect(Object.getPrototypeOf(subscriptionPriceUtility).calculateDefaultUptickPrices).toHaveBeenCalled();
    expect(result).toBeDefined();
  });

  it('calcUptickPrices should throw error when the default calculation fails for a non-legacy subscription', () => {
    // Arrange
    const errorMessage = 'FAKE ERROR';
    const mock = mockForCalcUptickPrices(errorMessage, false);

    // Act
    const action = mock.action;

    // Assert
    expect(action).toThrowError(errorMessage);
    expect(Object.getPrototypeOf(subscriptionPriceUtility).calculateDefaultUptickPrices).toHaveBeenCalled();
  });

  it('calcUptickPrices should use fallback uptick prices when the default calculation fails for a legacy subscription', () => {
    // Arrange
    const mock = mockForCalcUptickPrices('FAKE ERROR', true);

    // Action
    const result = mock.action();

    // Assert
    expect(Object.getPrototypeOf(subscriptionPriceUtility).calculateDefaultUptickPrices).toHaveBeenCalled();
    expect(Object.getPrototypeOf(subscriptionPriceUtility).sendEmailWhenDefaultUptickCalculationFailedForLegacySubscriptions).toHaveBeenCalled();
    expect(Object.getPrototypeOf(subscriptionPriceUtility).calculateFallbackUptickPricesForLegacySubscriptions).toHaveBeenCalled();
    expect(result).toBeDefined();
  });

  function mockForCalcUptickPrices(errorMessage?: string, isLegacyPlan?: boolean): {
    action: () => any[] | null,
  } {
    const newPlan = {
      productTier: ProductTier.Standard,
      supportLevel: SupportLevel.Silver,
    } as any;
    const newFrequency = 'ANNUALLY';
    const isDraftRenewalCreation = false;
    const isPreview = true;
    const isDraftUpdate = false;
    const mainItem = {
      code: 'A',
      quantity: 1,
    };
    const subscriptionItems = {
      availableItems: [ mainItem ],
      mainItem: {
        item: mainItem,
        quantity: 1,
      },
    } as any;
    const draftItems = undefined;
    const draftPlanInfo = undefined;
    const parentSubscriptionId = 1;
    const parentSubscription = {
      items: [ mainItem ],
      includedItems: [ mainItem ],
      plan: {
        productTier: ProductTier.Standard,
      }
    } as any;
    const parentPlanInfo = {
      items: [ mainItem ],
      productTier: ProductTier.Standard,
      isLegacyPlan: isLegacyPlan ?? false,
    } as any;
    const overriddenMethods = [
      { scope: Object.getPrototypeOf(subscriptionPriceUtility), name: 'fixItemsForSupportLegacySubscriptions' },
      { scope: Object.getPrototypeOf(subscriptionValidateUtility), name: 'isPlanDowngrade', implementation: () => false },
      { scope: Object.getPrototypeOf(subscriptionValidateUtility), name: 'isQuantityDowngrade', implementation: () => false },
      { scope: Object.getPrototypeOf(subscriptionPriceUtility), name: 'getDiscounts', implementation: () => undefined },
      { scope: Object.getPrototypeOf(SubscriptionPlanUtility), name: 'addSupportPricesToItems' },
      { scope: Object.getPrototypeOf(subscriptionPriceUtility), name: 'calculateDefaultUptickPrices',
        implementation: errorMessage
          ? () => { throw new Error(errorMessage); }
          : () => []
      },
      { scope: Object.getPrototypeOf(subscriptionPriceUtility), name: 'getMainAndSupportDistributionRatioForUptick', implementation: () => 1 },
      { scope: Object.getPrototypeOf(subscriptionPriceUtility), name: 'applyDistributionRatioToSupportItems', implementation: () => {} },
      { scope: Object.getPrototypeOf(subscriptionPriceUtility), name: 'sendEmailWhenDefaultUptickCalculationFailedForLegacySubscriptions' },
      { scope: Object.getPrototypeOf(subscriptionPriceUtility), name: 'calculateFallbackUptickPricesForLegacySubscriptions', implementation: () => [] },
    ];
    for (const method of overriddenMethods) {
      jest.spyOn(method.scope, method.name).mockImplementation(method.implementation ?? (() => {}));
    }

    return {
      action: () => subscriptionPriceUtility.calcUptickPrices(
        newPlan, newFrequency,
        isDraftRenewalCreation, isPreview, isDraftUpdate,
        subscriptionItems,
        draftItems, draftPlanInfo,
        parentSubscriptionId, parentSubscription, parentPlanInfo
      ),
    }
  }

  it('sendEmailWhenDefaultUptickCalculationFailedForLegacySubscriptions', () => {
    // Arrange
    const error: Error = {
      name: 'FAKE ERROR',
      message: 'This is a fake error message for testing purpose.'
    };
    const parentSubscription = {
      id: 101,
    };
    const uptickParams = {
      property1: true,
      property2: 'value2',
    };
    jest.spyOn(nsutils, 'sendEmail').mockImplementation(() => {});

    // Act
    Object.getPrototypeOf(subscriptionPriceUtility)
      .sendEmailWhenDefaultUptickCalculationFailedForLegacySubscriptions(error, parentSubscription, uptickParams);

    // Assert
    const expecteBody =
`An error happened when trying to calculate the uptick prices for the legacy subscription ${parentSubscription.id}.
The fallback approach will be applied.

ERROR DETAILS
${error}

UPTICK PARAMS
${JSON.stringify(uptickParams)}`;
    expect(nsutils.sendEmail).toHaveBeenCalledWith(
      expect.arrayContaining(['rp-si@trilogy.com']),
      'Uptick calculation failed for a legacy subscription',
      expecteBody,
    )
  });

  it('calculateFallbackUptickPricesForLegacySubscriptions should throw an error when there is no main or support item', () => {
    // Arrange
    const parentSubscription = {
      id: 101,
    };
    const newPlan = {
      supportOnly: true,
      items: [],
    };
    const uptickParams = {};

    // Act
    const action = () => Object.getPrototypeOf(subscriptionPriceUtility)
      .calculateFallbackUptickPricesForLegacySubscriptions(parentSubscription, newPlan, uptickParams);

    // Assert
    expect(action).toThrowError(`Cannot retrieve the main or the support item to apply the upticked ARR for the legacy subscription ${parentSubscription.id}.`);
  });

  it('calculateFallbackUptickPricesForLegacySubscriptions should throw an error when there is no price related to the main or support item', () => {
    // Arrange
    const parentSubscription = {
      id: 101,
    };
    const mainItem = {
      code: 'A',
    };
    const newPlan = {
      supportOnly: false,
      items: [ mainItem ],
      mainItemCode: mainItem.code,
    };
    const uptickParams = {};
    jest.spyOn(Object.getPrototypeOf(subscriptionPriceUtility), 'findTiers').mockReturnValueOnce(null);

    // Act
    const action = () => Object.getPrototypeOf(subscriptionPriceUtility)
      .calculateFallbackUptickPricesForLegacySubscriptions(parentSubscription, newPlan, uptickParams);

    // Assert
    expect(action).toThrowError(`Cannot retrieve the main or the support item price to apply the upticked ARR for the legacy subscription ${parentSubscription.id}.`);
  });

  it('calculateFallbackUptickPricesForLegacySubscriptions should return the ARR on the main item as fallback uptick prices with an annually frequency', () => {
    // Arrange
    const parentSubscription = {
      id: 101,
      items: [
        { id: 1, code: 'A', recuringAmount: 1200, frequency: ChargeFrequency.Annually, repeatEvery: 1 },
        { id: 2, code: 'B', recuringAmount: 600, frequency: ChargeFrequency.Annually, repeatEvery: 1 },
      ],
      includedItems: [
        { id: 1, code: 'A' },
        { id: 2, code: 'B' },
      ]
    };
    const mainItem = parentSubscription.items[0];
    const newPlan = {
      supportOnly: false,
      items: [ mainItem ],
      mainItemCode: mainItem.code,
    };
    const uptickParams = {
      uptickPercent: 0.45,
    };
    jest.spyOn(Object.getPrototypeOf(subscriptionPriceUtility), 'findTiers').mockReturnValueOnce({
      ranges: [
        {
          frequency: 'ANNUALLY',
          price: undefined,
        },
      ],
    });

    // Act
    const result = Object.getPrototypeOf(subscriptionPriceUtility)
      .calculateFallbackUptickPricesForLegacySubscriptions(parentSubscription, newPlan, uptickParams);

    // Assert
    expect(result).toBeDefined();
    expect(result.length).toBe(1);
    expect(result[0].id).toBe(mainItem.id);
    expect(result[0].price).toBeDefined();
    const expectedPrice = roundMoney(parentSubscription.items.sum(i => i.recuringAmount) * (1 + uptickParams.uptickPercent));
    expect(result[0].price.ranges[0].price).toBe(expectedPrice);
  });

  it('calculateFallbackUptickPricesForLegacySubscriptions should return the ARR on the main item as fallback uptick prices with a monthly frequency', () => {
    // Arrange
    const parentSubscription = {
      id: 101,
      items: [
        { id: 1, code: 'A', recuringAmount: 1200, frequency: ChargeFrequency.Monthly, repeatEvery: 2 },
        { id: 2, code: 'B', recuringAmount: 600, frequency: ChargeFrequency.Monthly, repeatEvery: 2 },
      ],
      includedItems: [
        { id: 1, code: 'A' },
        { id: 2, code: 'B' },
      ]
    };
    const mainItem = parentSubscription.items[0];
    const newPlan = {
      supportOnly: false,
      items: [ mainItem ],
      mainItemCode: mainItem.code,
    };
    const uptickParams = {
      uptickPercent: 0.45,
    };
    jest.spyOn(Object.getPrototypeOf(subscriptionPriceUtility), 'findTiers').mockReturnValueOnce({
      ranges: [
        {
          frequency: 'MONTHLY',
          price: undefined,
        },
      ],
    });

    // Act
    const result = Object.getPrototypeOf(subscriptionPriceUtility)
      .calculateFallbackUptickPricesForLegacySubscriptions(parentSubscription, newPlan, uptickParams);

    // Assert
    expect(result).toBeDefined();
    expect(result.length).toBe(1);
    expect(result[0].id).toBe(mainItem.id);
    expect(result[0].price).toBeDefined();
    const expectedPrice = roundMoney(parentSubscription.items.sum(i => i.recuringAmount / i.repeatEvery) * (1 + uptickParams.uptickPercent));
    expect(result[0].price.ranges[0].price).toBe(expectedPrice);
  });

  it('carryOverMissingItemsArrForLegacySubscriptions should do nothing when the ARR of the missing items equals to zero', () => {
    // Arrange
    const mock = mockForCarryOverMissingItemsArrForLegacySubscriptions();

    // Act
    mock.action();

    // Assert
    for (let i = 0; i < 2; i++) {
      expect(mock.uptickedPrices[i].price.ranges[0].price).toBe(mock.initialUptickedPrices[i].price.ranges[0].price);
    }
  });

  it('carryOverMissingItemsArrForLegacySubscriptions should throw an error when there is no main item', () => {
    // Arrange
    const mock = mockForCarryOverMissingItemsArrForLegacySubscriptions();
    mock.subscriptionItems.find(i => i.isMainItem).isMainItem = false;
    mock.parentSubscription.items.find(i => i.id === 3).recuringAmount = 120;
    mock.uptickParams.isSupportOnlyPlan = false;

    // Act
    const action = mock.action;

    // Assert
    expect(action).toThrowError(`Cannot retrieve the item for adding the ARR of the missing items in the new subscription plan.`);
  });

  it('carryOverMissingItemsArrForLegacySubscriptions should throw an error when there is no support main item', () => {
    // Arrange
    const mock = mockForCarryOverMissingItemsArrForLegacySubscriptions();
    mock.subscriptionItems.find(i => i.isSupportMainItem).isSupportMainItem = false;
    mock.parentSubscription.items.find(i => i.id === 3).recuringAmount = 120;
    mock.uptickParams.isSupportOnlyPlan = true;

    // Act
    const action = mock.action;

    // Assert
    expect(action).toThrowError(`Cannot retrieve the item for adding the ARR of the missing items in the new subscription plan.`);
  });

  it('carryOverMissingItemsArrForLegacySubscriptions should throw an error when there is no upticked price for the main or support item', () => {
    // Arrange
    const mock = mockForCarryOverMissingItemsArrForLegacySubscriptions();
    mock.parentSubscription.items.find(i => i.id === 3).recuringAmount = 120;
    mock.uptickedPrices.length = 0;

    // Act
    const action = mock.action;

    // Assert
    expect(action).toThrowError(`Cannot find the upticked price for the item ${mock.subscriptionItems.find(i => i.isMainItem).id}.`);
  });

  it('carryOverMissingItemsArrForLegacySubscriptions should add the ARR of the missing items to the main item with an annually frequency and rate', () => {
    // Arrange
    const mock = mockForCarryOverMissingItemsArrForLegacySubscriptions();
    const additionalValue = 240;
    const quantity = 2;
    mock.subscriptionItems.forEach(i => {
      i.prices[0].ranges[0].type = PriceTierType[PriceTierType.Rate];
      i.quantity = quantity;
    });
    mock.parentSubscription.items.find(i => i.id === 3).recuringAmount = additionalValue;

    // Act
    mock.action();

    // Assert
    const expectedAdditionalValue = additionalValue * (1 + mock.uptickParams.uptickPercent) / quantity;
    expect(mock.uptickedPrices[0].price.ranges[0].price).toBe(mock.initialUptickedPrices[0].price.ranges[0].price + expectedAdditionalValue);
  });

  it('carryOverMissingItemsArrForLegacySubscriptions should add the ARR of the missing items to the main item with a monthly frequency and fixed amount', () => {
    // Arrange
    const mock = mockForCarryOverMissingItemsArrForLegacySubscriptions();
    const additionalValue = 240;
    const quantity = 2;
    mock.subscriptionItems.forEach(i => {
      i.prices[0].ranges[0].type = PriceTierType[PriceTierType.FixedAmount];
      i.quantity = quantity;
    });
    mock.parentSubscription.items.find(i => i.id === 3).recuringAmount = additionalValue;
    mock.uptickedPrices.forEach(p => {
      p.price.frequency = 'MONTHLY';
    });

    // Act
    mock.action();

    // Assert
    const expectedAdditionalValue = additionalValue * (1 + mock.uptickParams.uptickPercent) / MONTHS_IN_A_YEAR;
    expect(mock.uptickedPrices[0].price.ranges[0].price).toBe(mock.initialUptickedPrices[0].price.ranges[0].price + expectedAdditionalValue);
  });

  it('carryOverMissingItemsArrForLegacySubscriptions should add the ARR of the missing items to the main item with items matching on code', () => {
    // Arrange
    const mock = mockForCarryOverMissingItemsArrForLegacySubscriptions();
    const additionalValue = 240;
    mock.parentSubscription.items.find(i => i.id === 3).recuringAmount = additionalValue;
    mock.uptickedPrices.forEach(p => {
      p.price.frequency = 'MONTHLY';
    });

    // Act
    mock.action();

    // Assert
    const expectedAdditionalValue = additionalValue * (1 + mock.uptickParams.uptickPercent) / MONTHS_IN_A_YEAR;
    expect(mock.uptickedPrices[0].price.ranges[0].price).toBe(mock.initialUptickedPrices[0].price.ranges[0].price + expectedAdditionalValue);
  });

  function mockForCarryOverMissingItemsArrForLegacySubscriptions(): {
    action: () => void,
    subscriptionItems: any[],
    parentSubscription: any,
    uptickParams: any,
    uptickedPrices: any[],
    initialUptickedPrices: any[],
    defaultItem: any,
  } {
    const defaultItem = {
      prices: [
        {
          ranges: [
            {},
          ],
        },
      ],
    };
    const subscriptionItems = [
      {...defaultItem, id: 1, code: 'DNN-OP-CUS-STA', isMainItem: true },
      {...defaultItem, id: 2, code: 'DNN-OP-CUS-SIL', isSupportMainItem: true },
    ];
    const parentSubscription = {
      items: [
        { id: 1, code: 'DNN-OP-CUS-STA', recuringAmount: 1200, frequency: ChargeFrequency.Annually, repeatEvery: 1 },
        { id: 2, code: 'DNN-OP-CUS-SIL', recuringAmount: 600, frequency: ChargeFrequency.Annually, repeatEvery: 1 },
        { id: 3, code: 'DNN-TE-CUS-ADD', recuringAmount: 0, frequency: ChargeFrequency.Annually, repeatEvery: 1 },
      ],
      includedItems: [
        { id: 1, code: 'DNN-OP-CUS-STA' },
        { id: 2, code: 'DNN-OP-CUS-SIL' },
        { id: 3, code: 'DNN-TE-CUS-ADD' },
      ],
    };
    const uptickParams = {
      isSupportOnlyPlan: false,
      uptickPercent: 0.25,
      isLegacySubscription: true,
      planItems: [
        { id: 1, code: 'DNN-OP-CUS-STA' },
        { id: 2, code: 'DNN-OP-CUS-SIL' },
      ]
    };
    const uptickedPrices = [
      { id: 1, price: { frequency: 'ANNUALLY', ranges: [{ price: 1500 }] } },
      { id: 2, price: { frequency: 'ANNUALLY', ranges: [{ price: 750 }] } },
    ];
    const initialUptickedPrices = clone(uptickedPrices);
    return {
      action: () => Object.getPrototypeOf(subscriptionPriceUtility)
        .carryOverMissingItemsArrForLegacySubscriptions(subscriptionItems, parentSubscription, uptickParams, uptickedPrices),
      subscriptionItems,
      parentSubscription,
      uptickParams,
      uptickedPrices,
      initialUptickedPrices,
      defaultItem,
    }
  }

  it('getItemArr should return the ARR of a subscription item', () => {
    // Arrange
    const tests = [
      { item: { recuringAmount: 100, frequency: ChargeFrequency.Annually, repeatEvery: 1 }, expected: 100 },
      { item: { recuringAmount: 100, frequency: ChargeFrequency.Annually, repeatEvery: 2 }, expected: 50 },
      { item: { recuringAmount: 100, frequency: ChargeFrequency.Monthly, repeatEvery: 1 }, expected: 1200 },
      { item: { recuringAmount: 100, frequency: ChargeFrequency.Monthly, repeatEvery: 3 }, expected: 400 },
      { item: { recuringAmount: 100, frequency: ChargeFrequency.Quarterly, repeatEvery: 1 }, expected: 400 },
      { item: { recuringAmount: 100, frequency: ChargeFrequency.Quarterly, repeatEvery: 2 }, expected: 200 },
      { item: { recuringAmount: 100, frequency: ChargeFrequency.Weekly, repeatEvery: 1 }, expected: 4800 },
      { item: { recuringAmount: 100, frequency: ChargeFrequency.Weekly, repeatEvery: 2 }, expected: 2400 },
    ];
    for (const test of tests) {

      // Act
      const result = Object.getPrototypeOf(subscriptionPriceUtility).getItemArr(test.item);

      // Assert
      expect(result).toBe(test.expected);
    }
  });

  it("getDiscounts should return no discounts when the discounts are not calculcated", () => {
    // Arrange
    const isPlanDowngrade = false;
    const isQuantityDowngrade = false;
    const isSameEdition = true;
    const isSamePlan = true;
    const parentSubscription = {};

    // Act
    const result = Object.getPrototypeOf(subscriptionPriceUtility)
      .getDiscounts(isPlanDowngrade, isQuantityDowngrade, isSameEdition, isSamePlan, parentSubscription);

    // Assert
    expect(result).toBeNull();
  });

  it("getDiscounts should return the current discounts when the discounts are calculcated", () => {
    // Arrange
    const isPlanDowngrade = false;
    const isQuantityDowngrade = false;
    const isSameEdition = false;
    const isSamePlan = false;
    const parentSubscription = {};
    const discounts = {
      mainItemDiscount: 0.5,
      addons: [],
    }
    jest.spyOn(Object.getPrototypeOf(subscriptionPriceUtility), 'getCurrentDiscount').mockReturnValueOnce(discounts);

    // Act
    const result = Object.getPrototypeOf(subscriptionPriceUtility)
      .getDiscounts(isPlanDowngrade, isQuantityDowngrade, isSameEdition, isSamePlan, parentSubscription);

    // Assert
    expect(Object.getPrototypeOf(subscriptionPriceUtility).getCurrentDiscount).toHaveBeenCalled();
    expect(result).toBe(discounts);
  });

  it('applyRenewalCodes', () => {
    const parentSubscription = {
      items: [
        {
          id: 1,
          code: 'DNN-OP-CUS-STA',
          amount: 20,
          totalIntervalValue: 20,
          recuringAmount: 20,
          isMainItem: true,
          isSupportMainItem: false,
          quantity: 2,
          prices: [
            {
              ranges: [
                {
                  type: 'Rate',
                  price: 10,
                  fromQuantity: 0
                },
              ],
            },
          ],
        },
        {
          id: 2,
          code: 'DNN-OP-BAS-ADD',
          amount: 60,
          totalIntervalValue: 60,
          recuringAmount: 60,
          isMainItem: false,
          isSupportMainItem: false,
          quantity: 3,
          prices: [
            {
              ranges: [
                {
                  type: 'FixedAmount',
                  price: 20,
                  fromQuantity: 0,
                },
              ],
            },
          ],
          renewItemId: 1,
          renewItemCode: 'DNN-OP-CUS-STA',
        },
        {
          id: 3,
          code: 'DNN-TE-CUS-ADD',
          amount: 15,
          totalIntervalValue: 15,
          recuringAmount: 15,
          isMainItem: false,
          isSupportMainItem: false,
          quantity: 4,
          prices: [
            {
              ranges: [
                {
                  type: 'FixedAmount',
                  price: 15,
                  fromQuantity: 0,
                },
              ],
            },
          ],
          renewItemId: 6,
          renewItemCode: 'DNN-TE-BAS-ADD',
        },
        {
          id: 4,
          code: 'DNN-TE-CUS2-ADD',
          amount: 200,
          totalIntervalValue: 200,
          recuringAmount: 200,
          isMainItem: false,
          isSupportMainItem: false,
          quantity: 1,
          prices: [
            {
              ranges: [
                {
                  type: 'FixedAmount',
                  price: 200,
                  fromQuantity: 0,
                },
              ],
            },
          ],
          renewItemId: 6,
          renewItemCode: 'DNN-TE-BAS-ADD',
        },
        {
          id: 5,
          code: 'DNN-TE-CUS3-ADD',
          amount: -150,
          totalIntervalValue: -150,
          recuringAmount: -150,
          isMainItem: false,
          isSupportMainItem: false,
          quantity: 3,
          prices: [
            {
              ranges: [
                {
                  type: 'FixedAmount',
                  price: -150,
                  fromQuantity: 0,
                },
              ],
            },
          ],
          renewItemId: 6,
          renewItemCode: 'DNN-TE-BAS-ADD',
        },
      ],
      includedItems: [
        {
          id: 1,
          code: 'DNN-OP-CUS-STA',
          quantity: 2,
        },
        {
          id: 2,
          code: 'DNN-OP-BAS-ADD',
          quantity: 3,
        },
        {
          id: 3,
          code: 'DNN-TE-CUS-ADD',
          quantity: 4,
        },
        {
          id: 4,
          code: 'DNN-TE-CUS2-ADD',
          quantity: 1,
        },
        {
          id: 5,
          code: 'DNN-TE-CUS3-ADD',
          quantity: 2,
        },
      ],
    };

    Object.getPrototypeOf(subscriptionPriceUtility).applyRenewalCodes(parentSubscription as any);

    expect(parentSubscription.items).toEqual([
      {
        id: 1,
        code: 'DNN-OP-CUS-STA',
        amount: 80,
        totalIntervalValue: 80,
        recuringAmount: 80,
        isMainItem: true,
        isSupportMainItem: false,
        quantity: 2,
        prices: [
          {
            ranges: [
              {
                type: 'Rate',
                price: 40,
                fromQuantity: 0,
              },
            ],
          },
        ]
      },
      {
        id: 6,
        code: 'DNN-TE-BAS-ADD',
        amount: 65,
        totalIntervalValue: 65,
        recuringAmount: 65,
        isMainItem: false,
        isSupportMainItem: false,
        quantity: 2,
        prices: [
          {
            ranges: [
              {
                type: 'FixedAmount',
                price: 65,
                fromQuantity: 0,
              },
            ],
          },
        ],
        renewItemId: 6,
        renewItemCode: 'DNN-TE-BAS-ADD',
      },
    ]);

    expect(parentSubscription.includedItems).toEqual([
      {
        id: 1,
        code: 'DNN-OP-CUS-STA',
        quantity: 2,
      },
      {
        id: 6,
        code: 'DNN-TE-BAS-ADD',
        quantity: 2,
      },
    ]);
  });
});