import {
  SubscriptionLine,
  SubscriptionRecord,
  SubscriptionUpdateNamePattern,
} from '../src/ts/models/SubscriptionRecord';
import { RevenueType, SubscriptionLineStatus, SubscriptionStatus, SubscriptionTermType } from '../src/ts/types';
import SubscriptionPlanUtility from '../src/ts/utility/SubscriptionPlanUtility';
import { RecordDynamicMock } from './SublistMock';
import * as record from 'N/record';
import * as nsutils from '../src/ts/nsutils';

describe('SubscriptionRecord', () => {
  it('it', () => {
    jest.spyOn(SubscriptionPlanUtility, 'getSubscriptionPlanById').mockReturnValueOnce({
      code: 'DNNE-SA-Cus-STA-SIL-001',
      supportOnly: false,
      revenueType: 'SaaS'
    } as any);
    const sr = new SubscriptionRecord(
      new RecordDynamicMock(
        { subscriptionline: [{ isincluded: true, isrequired: true, status: 'DRAFT', item: 1 }] },
        {
          billingsubscriptionstatus: 'DRAFT',
          id: 1,
          initialtermtype: 'STANDARD',
          billingaccount: 2,
          custrecord_contract_docs: '3',
          custrecord_subs_end_user: '4',
          startdate: new Date(1),
          subsidiary: '1',
          subscriptionPlanId: '1'
        }
      ) as any,
      true
    );
    expect(sr.billingAccount).toEqual(2);
    expect(sr.status).toEqual(SubscriptionStatus.DRAFT);
    expect(sr.initialTermType).toEqual(SubscriptionTermType.STANDARD);
    expect(sr.id).toEqual(1);
    expect(sr.contractDocs).toEqual(3);
    expect(sr.endUserInternalId).toEqual(4);
    expect(sr.startDate).toEqual(new Date(1));
    expect(sr.subscriptionPlanCode).toEqual('DNNE-SA-Cus-STA-SIL-001');
    expect(sr.isMaintenance).toEqual(false);
    expect(sr.revenueType).toEqual(RevenueType.SaaS);
    const lines = sr.processSubscriptionLines((i) => {
      const res: SubscriptionLine[] = [];
      while (i.nextLine()) {
        res.push(i.line());
      }
      return res;
    });
    expect(lines[0].status).toEqual(SubscriptionLineStatus.DRAFT);
    expect(sr.subsidiary).toEqual(1);
  });

  it('SubscriptionUpdateNamePattern', () => {
    const name = SubscriptionUpdateNamePattern.generateName('test', 123);

    expect(SubscriptionUpdateNamePattern.matches(name)).toBeTruthy();
    expect(SubscriptionUpdateNamePattern.getUpdateSubscriptionId(name)).toStrictEqual(123);
  });

  it('SubscriptionUpdateNamePattern invalid', () => {
    expect(() => {
      SubscriptionUpdateNamePattern.generateName('test', NaN);
    }).toThrow();

    expect(SubscriptionUpdateNamePattern.matches('test - update - 333')).not.toBeTruthy();
  });

  it('getCurrencySymbol', () => {
    jest.spyOn(record, 'load').mockReturnValue({
      getValue: () => 1
    } as any);
    jest.spyOn(nsutils, 'queryFirstToJson').mockReturnValue({ symbol: "USD" });
    const sr = SubscriptionRecord.load(1);
    expect(sr.currencySymbol).toBe("USD");
    expect(sr.currencySymbol).toBe("USD");
  })
});
