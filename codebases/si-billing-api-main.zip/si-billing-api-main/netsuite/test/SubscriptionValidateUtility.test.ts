import * as nsutils from '../src/ts/nsutils';
import subscriptionValidateUtility from '../src/ts/utility/SubscriptionValidateUtility';
import subscriptionGetUtility from '../src/ts/utility/SubscriptionGetUtility';
import subscriptionDao from '../src/ts/dao/SubscriptionDao';
import { ProductTier, SubscriptionTermType, SupportLevel, TermUnit } from '../src/ts/types';
import { ApiSubscription } from '../src/ts/models/apitypes';
import SubscriptionPlanUtility from '../src/ts/utility/SubscriptionPlanUtility';

describe('SubscriptionValidateUtility', () => {
  beforeEach(() => {
    jest.restoreAllMocks();
  });

  it('validateUpdateActive productTier', () => {
    jest.spyOn(nsutils, 'queryFirstToJson').mockReturnValueOnce({ subscriptionplan: 1 });
    jest.spyOn(subscriptionDao, 'findUpdates').mockReturnValueOnce([]);

    expect(() =>
      subscriptionValidateUtility.validateUpdateActive(
        1,
        null,
        {
          productTier: ProductTier.Professional,
          supportLevel: SupportLevel.Gold,
          code: 'DNNE-SA-Cus-PRO-GOL-001',
          name: 'Some PRO Plan Name',
          supportOnly: false,
          isLegacyPlan: false,
          initialterm: {
            duration: 1,
            unit: 'YEARS'
          }
        } as any,
        {
          productTier: ProductTier.Standard,
          supportLevel: SupportLevel.Gold,
          code: 'DNNE-SA-Cus-STA-GOL-001',
          name: 'Some STA Plan Name',
          supportOnly: false,
          isLegacyPlan: false,
          initialterm: {
            duration: 1,
            unit: 'YEARS'
          }
        } as any,
        [],
        SubscriptionTermType.STANDARD
      )
    ).toThrowError(`It's not possible to downgrade an active subscription`);
  });

  it('validateUpdateActive supportLevel', () => {
    jest.spyOn(nsutils, 'queryFirstToJson').mockReturnValueOnce({ subscriptionplan: 1 });
    jest.spyOn(subscriptionDao, 'findUpdates').mockReturnValueOnce([]);

    expect(() =>
      subscriptionValidateUtility.validateUpdateActive(
        1,
        null,
        {
          productTier: ProductTier.Professional,
          supportLevel: SupportLevel.Gold,
          code: 'DNNE-SA-Cus-PRO-GOL-001',
          name: 'Some PRO GOL Plan Name',
          supportOnly: false,
          isLegacyPlan: false,
          initialterm: {
            duration: 1,
            unit: 'YEARS'
          }
        } as any,
        {
          productTier: ProductTier.Professional,
          supportLevel: SupportLevel.Silver,
          code: 'DNNE-SA-Cus-PRO-SIL-001',
          name: 'Some PRO SIL Plan Name',
          supportOnly: false,
          isLegacyPlan: false,
          initialterm: {
            duration: 1,
            unit: 'YEARS'
          }
        } as any,
        [],
        SubscriptionTermType.STANDARD
      )
    ).toThrowError(`It's not possible to downgrade an active subscription`);
  });

  it('validateUpdateActive equal no error', () => {
    jest.spyOn(nsutils, 'queryFirstToJson').mockReturnValueOnce({ subscriptionplan: 1 });
    jest.spyOn(subscriptionDao, 'findUpdates').mockReturnValueOnce([]);

    jest.spyOn(Object.getPrototypeOf(subscriptionGetUtility), 'getSubscriptionByIdInternal').mockReturnValueOnce({});
    jest.spyOn(Object.getPrototypeOf(subscriptionValidateUtility), 'isQuantityDowngrade').mockReturnValueOnce(false);

    subscriptionValidateUtility.validateUpdateActive(
      1,
      null,
      {
        productTier: ProductTier.Professional,
        supportLevel: SupportLevel.Gold,
        code: 'DNNE-SA-Cus-PRO-GOL-001',
        supportOnly: false,
        isLegacyPlan: false,
        name: 'Some Plan Name',
        initialterm: {
          duration: 1,
          unit: 'YEARS'
        }
      } as any,
      {
        productTier: ProductTier.Professional,
        supportLevel: SupportLevel.Gold,
        code: 'DNNE-SA-Cus-PRO-GOL-001',
        name: 'Some Plan Name',
        supportOnly: false,
        isLegacyPlan: false,
        initialterm: {
          duration: 1,
          unit: 'YEARS'
        }
      } as any,
      [],
      SubscriptionTermType.STANDARD
    );
  });

  it('validateUpdateActive upgrading no error', () => {
    jest.spyOn(nsutils, 'queryFirstToJson').mockReturnValueOnce({ subscriptionplan: 1 });
    jest.spyOn(subscriptionDao, 'findUpdates').mockReturnValueOnce([]);

    jest.spyOn(Object.getPrototypeOf(subscriptionGetUtility), 'getSubscriptionByIdInternal').mockReturnValueOnce({});
    jest.spyOn(Object.getPrototypeOf(subscriptionValidateUtility), 'isQuantityDowngrade').mockReturnValueOnce(false);
    (jest.spyOn(SubscriptionPlanUtility, 'getSubscriptionPlans') as any).mockReturnValueOnce([
      {
        id: 1,
        items: [
          {
            required: true,
            code: 'Test Item',
          },
        ],
      },
    ]);

    //subscriptionId: number, newPlanCode: string, duration, newItems?: SubscriptionConfigurationItem[]
    //{ subscriptionId: 1, content: { planId: 1 }})
    subscriptionValidateUtility.validateUpdateActive(
      1,
      null,
      {
        productTier: ProductTier.Professional,
        supportLevel: SupportLevel.Gold,
        code: 'DNNE-SA-Cus-PRO-GOL-001',
        name: 'Some PRO Plan Name',
        supportOnly: false,
        isLegacyPlan: false,
        initialterm: {
          duration: 1,
          unit: 'YEARS'
        }
      } as any,
      {
        productTier: ProductTier.Enterprise,
        supportLevel: SupportLevel.Platinum,
        code: 'DNNE-SA-Cus-ENT-PLA-001',
        name: 'Some ENT Plan Name',
        supportOnly: false,
        isLegacyPlan: false,
        initialterm: {
          duration: 1,
          unit: 'YEARS'
        }
      } as any,
      [],
      SubscriptionTermType.STANDARD
    );
  });

  it('validateUpdateActive quantity downgrade', () => {
    jest.spyOn(Object.getPrototypeOf(subscriptionValidateUtility), 'isPlanDowngrade').mockReturnValueOnce(false);
    jest.spyOn(subscriptionDao, 'findUpdates').mockReturnValueOnce([]);
    (jest.spyOn(subscriptionGetUtility, 'getSubscriptionByIdInternal') as any).mockReturnValueOnce({
      items: [
        {
          id: 1,
          required: true,
        },
      ],
      includedItems: [
        {
          id: 1,
          quantity: 2,
        },
      ],
    });
    (jest.spyOn(SubscriptionPlanUtility, 'getSubscriptionPlans') as any).mockReturnValueOnce([
      {
        id: 1,
        items: [
          {
            required: true,
            code: 'Test Item',
          },
        ],
      },
    ]);

    expect(() =>
      subscriptionValidateUtility.validateUpdateActive(
        1,
        null,
        {
          productTier: ProductTier.Standard,
          supportLevel: SupportLevel.Silver,
          code: 'DNNE-SA-Cus-STA-SIL-001',
          name: 'Some Plan Name',
          supportOnly: false,
          isLegacyPlan: false,
          initialterm: {
            duration: 1,
            unit: 'YEARS'
          }
        } as any,
        {
          productTier: ProductTier.Standard,
          supportLevel: SupportLevel.Silver,
          code: 'DNNE-SA-Cus-STA-SIL-001',
          name: 'Some Plan Name',
          supportOnly: false,
          isLegacyPlan: false,
          initialterm: {
            duration: 1,
            unit: 'YEARS'
          }
        } as any,
        [
          {
            code: 'Test Item',
            quantity: 1,
          },
        ],
        SubscriptionTermType.STANDARD
      )
    ).toThrowError(`It's not possible to reduce quantity in an active subscription`);
  });

  it('isQuantityDowngrade', () => {
    jest.spyOn(Object.getPrototypeOf(subscriptionValidateUtility), 'isPlanDowngrade').mockReturnValueOnce(false);
    const newItems = [
      {
        code: 'Test Item',
        quantity: 2,
      },
    ];
    const currentSubscription: ApiSubscription = {
      items: [
        {
          id: 1,
          required: true,
        },
      ],
      includedItems: [
        {
          id: 1,
          quantity: 2,
        },
      ],
    } as any;
    //public isQuantityDowngrade(currentSubscription: ApiSubscription, newItems: SubscriptionConfigurationItem[], newSubscriptionPlan: SubscriptionPlan) {
    const res = subscriptionValidateUtility.isDowngrade(
      currentSubscription,
      newItems,
      {
        productTier: ProductTier.Standard,
        supportLevel: SupportLevel.Silver,
        code: 'DNNE-SA-Cus-STA-SIL-001',
        name: 'Some Plan Name',
        supportOnly: false,
        mainItemCode: 'Test Item',
        isLegacyPlan: false,
        initialterm: {
          duration: 1,
          unit: 'YEARS'
        }
      } as any,
      {
        productTier: ProductTier.Standard,
        supportLevel: SupportLevel.Silver,
        code: 'DNNE-SA-Cus-STA-SIL-001',
        name: 'Some Plan Name',
        supportOnly: false,
        mainItemCode: 'Test Item',
        isLegacyPlan: false,
        initialterm: {
          duration: 1,
          unit: 'YEARS'
        }
      } as any
    );
    expect(res).toBe(false);
  });

  it('isQuantityDowngrade true', () => {
    jest.spyOn(Object.getPrototypeOf(subscriptionValidateUtility), 'isPlanDowngrade').mockReturnValueOnce(false);
    const newItems = [
      {
        code: 'Test Item',
        quantity: 1,
      },
    ];
    const currentSubscription = {
      items: [
        {
          code: 'Test Item',
          id: 1,
          required: true,
        },
      ],
      includedItems: [
        {
          code: 'Test Item',
          id: 1,
          quantity: 2,
        },
      ],
    } as any;

    const res = subscriptionValidateUtility.isDowngrade(
      currentSubscription,
      newItems,
      {
        productTier: ProductTier.Standard,
        supportLevel: SupportLevel.Silver,
        code: 'DNNE-SA-Cus-STA-SIL-001',
        name: 'Some Plan Name',
        supportOnly: false,
        mainItemCode: 'Test Item',
        isLegacyPlan: false,
        initialterm: {
          duration: 1,
          unit: 'YEARS'
        }
      } as any,
      {
        productTier: ProductTier.Standard,
        supportLevel: SupportLevel.Silver,
        code: 'DNNE-SA-Cus-STA-SIL-001',
        name: 'Some Plan Name',
        supportOnly: false,
        mainItemCode: 'Test Item',
        isLegacyPlan: false,
        initialterm: {
          duration: 1,
          unit: 'YEARS'
        }
      } as any
    );
    expect(res).toBe(true);
  });

  it('validateSuspension existing activation', () => {
    const params: any = {
      subscriptionId: 1,
      content: {
        items: [
          {
            code: 'test',
            quantity: 0,
          },
        ],
      },
    };
    jest.spyOn(subscriptionDao, 'findTodaysCO').mockReturnValue([1]);
    expect(() => subscriptionValidateUtility.validateSuspension(params)).toThrowError(
      'It is not possible to update quantity to 0 on the same day of activation, reactivation or suspension'
    );
  });

  it('validateUpdateActive term reduction', () => {
    jest.spyOn(Object.getPrototypeOf(subscriptionValidateUtility), 'isPlanDowngrade').mockReturnValueOnce(false);
    jest.spyOn(Object.getPrototypeOf(subscriptionValidateUtility), 'isQuantityDowngrade').mockReturnValueOnce(false);
    (jest.spyOn(subscriptionGetUtility, 'getSubscriptionByIdInternal') as any).mockReturnValueOnce({
      term: {
        start: '1-Jan-2021',
        end: '31-Dec-2021',
      },
    });

    expect(() =>
      subscriptionValidateUtility.validateUpdateActive(
        1,
        11,
        {
          productTier: ProductTier.Professional,
          supportLevel: SupportLevel.Gold,
          code: 'DNNE-SA-Cus-PRO-GOL-001',
          name: 'Some PRO GOL Plan Name',
          supportOnly: false,
          isLegacyPlan: false,
          initialterm: {
            duration: 1,
            unit: 'YEARS'
          }
        } as any,
        {
          productTier: ProductTier.Enterprise,
          supportLevel: SupportLevel.Platinum,
          code: 'DNNE-SA-Cus-ENT-PLA-001',
          name: 'Some ENT PLA Plan Name',
          supportOnly: false,
          isLegacyPlan: false,
          initialterm: {
            duration: 1,
            unit: 'YEARS'
          }
        } as any,
        [],
        SubscriptionTermType.STANDARD
      )
    ).toThrowError(`Duration can't be changed for an active subscription`);
  });

  it('validateUpdateActive no duration', () => {
    jest.spyOn(Object.getPrototypeOf(subscriptionValidateUtility), 'isPlanDowngrade').mockReturnValueOnce(false);
    jest.spyOn(Object.getPrototypeOf(subscriptionValidateUtility), 'isQuantityDowngrade').mockReturnValueOnce(false);
    jest.spyOn(subscriptionDao, 'findUpdates').mockReturnValueOnce([]);
    (jest.spyOn(subscriptionGetUtility, 'getSubscriptionByIdInternal') as any).mockReturnValueOnce({
      term: {
        start: '1-Jan-2021',
        end: '31-Dec-2021',
      },
    });

    subscriptionValidateUtility.validateUpdateActive(
      1,
      null,
      {
        productTier: ProductTier.Professional,
        supportLevel: SupportLevel.Gold,
        code: 'DNNE-SA-Cus-PRO-GOL-001',
        name: 'Some PRO GOL Plan Name',
        supportOnly: false,
        isLegacyPlan: false,
        initialterm: {
          duration: 1,
          unit: 'YEARS'
        }
      } as any,
      {
        productTier: ProductTier.Enterprise,
        supportLevel: SupportLevel.Platinum,
        code: 'DNNE-SA-Cus-ENT-PLA-001',
        name: 'Some ENT PLA Plan Name',
        supportOnly: false,
        isLegacyPlan: false,
        initialterm: {
          duration: 1,
          unit: 'YEARS'
        }
      } as any,
      [],
      SubscriptionTermType.STANDARD
    );
  });

  it('validateDuration', () => {
    jest.spyOn(SubscriptionPlanUtility, 'getSubscriptionPlanByCode').mockReturnValueOnce({
        initialterm: {
          duration: 1,
          unit: 'YEARS',
        },
      } as any);
    expect(() =>
      subscriptionValidateUtility.validateDuration({
        content: {
          planCode: 'anything',
          duration: 11,
        },
      })
    ).toThrowError('Duration is less than default term for subscription plan. Default term: 1 YEARS');
  });
});
