import * as validateProductIntegrationRecord from '../src/ts/events/ValidateProductIntegrationRecord';
import subscriptionPlanUtility from '../src/ts/utility/SubscriptionPlanUtility';
import * as nsutils from '../src/ts/nsutils';
import { ProductTier, SupportLevel, TermUnit } from '../src/ts/types';

const item1 = {
  id: 1,
  required: true,
  desc: 'Item1 desc',
  type: '',
  typeId: 1,
  title: 'Item1',
  prices: [],
  code: 'item1',
  minQuantity: 1,
  maxQuantity: 5,
  isSupportItem: false,
  isMainItem: true,
};

const item2 = {
  id: 2,
  required: false,
  desc: 'Item2 desc',
  type: '',
  typeId: 1,
  title: 'Item2',
  prices: [],
  code: 'item2',
  minQuantity: 2,
  maxQuantity: 10,
  isSupportItem: true,
  isMainItem: false,
};

describe('ValidateProductIntegrationRecord', () => {
  it('validateTrialSubscriptionConfig valid', () => {
    jest.spyOn(subscriptionPlanUtility, 'getSubscriptionPlanById').mockReturnValueOnce({
      items: [item1, item2]
    } as any);
    validateProductIntegrationRecord.validateTrialSubscriptionConfig(
      JSON.stringify({
        planCode: 'TestPlan',
        frequency: 'MONTHLY',
        trialDuration: 2,
        items: [
          {
            code: 'item1',
            quantity: 1,
          },
          {
            code: 'item2',
            quantity: 2,
          },
        ],
      })
    );
  });

  it('validateTrialSubscriptionConfig itemvalidation', () => {
    jest.spyOn(subscriptionPlanUtility, 'getSubscriptionPlanById').mockReturnValue({
      items: [item1, item2]
    } as any);

    expect(() => {
      validateProductIntegrationRecord.validateTrialSubscriptionConfig(
        JSON.stringify({
          planCode: 'TestPlan',
          frequency: 'MONTHLY',
          trialDuration: 2,
          items: [
            {
              code: 'item1',
              quantity: 1,
            },
            {
              code: 'item3',
              quantity: 2,
            },
          ],
        })
      );
    }).toThrowError(`Item 'item3' does not exist in plan`);

    expect(() => {
      validateProductIntegrationRecord.validateTrialSubscriptionConfig(
        JSON.stringify({
          planCode: 'TestPlan',
          frequency: 'MONTHLY',
          trialDuration: 2,
          items: [
            {
              code: 'item1',
              quantity: '',
            },
            {
              code: 'item2',
              quantity: 2,
            },
          ],
        })
      );
    }).toThrowError(`Invalid quantity on item 'item1'`);

    expect(() => {
      validateProductIntegrationRecord.validateTrialSubscriptionConfig(
        JSON.stringify({
          planCode: 'TestPlan',
          frequency: 'MONTHLY',
          trialDuration: 2,
          items: [
            {
              code: 'item1',
            },
            {
              code: 'item2',
              quantity: 2,
            },
          ],
        })
      );
    }).toThrowError(`Invalid quantity on item 'item1'`);

    expect(() => {
      validateProductIntegrationRecord.validateTrialSubscriptionConfig(
        JSON.stringify({
          planCode: 'TestPlan',
          frequency: 'MONTHLY',
          trialDuration: 2,
          items: [
            {
              code: 'item1',
              quantity: -1,
            },
            {
              code: 'item2',
              quantity: 2,
            },
          ],
        })
      );
    }).toThrowError(`Invalid quantity on item 'item1'`);

    expect(() => {
      validateProductIntegrationRecord.validateTrialSubscriptionConfig(
        JSON.stringify({
          planCode: 'TestPlan',
          frequency: 'MONTHLY',
          trialDuration: 2,
          items: [
            {
              code: 'item1',
              quantity: 0,
            },
            {
              code: 'item2',
              quantity: 2,
            },
          ],
        })
      );
    }).toThrowError(`Quantity is less than minimum 1 on item 'item1'`);

    expect(() => {
      validateProductIntegrationRecord.validateTrialSubscriptionConfig(
        JSON.stringify({
          planCode: 'TestPlan',
          frequency: 'MONTHLY',
          trialDuration: 2,
          items: [
            {
              code: 'item1',
              quantity: 6,
            },
            {
              code: 'item2',
              quantity: 2,
            },
          ],
        })
      );
    }).toThrowError(`Quantity is greater than maximum 5 on item 'item1'`);

    expect(() => {
      validateProductIntegrationRecord.validateTrialSubscriptionConfig(
        JSON.stringify({
          planCode: 'TestPlan',
          frequency: 'MONTHLY',
          trialDuration: 2,
          items: [
            {
              code: 'item2',
              quantity: 2,
            },
          ],
        })
      );
    }).toThrowError(`Item item1 is required`);
  });

  it('validateTrialSubscriptionConfig errors', () => {
    jest.spyOn(subscriptionPlanUtility, 'getSubscriptionPlanById').mockReturnValueOnce({
      items: [item1, item2]
    } as any);

    jest.spyOn(nsutils, 'queryFirstAsMap').mockReturnValueOnce(null);
    expect(() => {
      validateProductIntegrationRecord.validateTrialSubscriptionConfig(
        JSON.stringify({
          planCode: 'TestPlan',
          frequency: 'MONTHLY',
          trialDuration: 2,
          items: [
            {
              code: 'item1',
              quantity: 1,
            },
            {
              code: 'item3',
              quantity: 2,
            },
          ],
        })
      );
    }).toThrowError(`No such subscription plan TestPlan`);

    expect(() => {
      validateProductIntegrationRecord.validateTrialSubscriptionConfig(
        JSON.stringify({
          planCode: 'TestPlan',
          frequency: 'MONTHLY',
          trialDuration: -2,
          items: [
            {
              code: 'item1',
              quantity: 1,
            },
            {
              code: 'item3',
              quantity: 2,
            },
          ],
        })
      );
    }).toThrowError(`trialDuration should be positive integer`);

    expect(() => {
      validateProductIntegrationRecord.validateTrialSubscriptionConfig(
        JSON.stringify({
          planCode: 'TestPlan',
          frequency: 'MONTHLY',
          trialDuration: '2',
          items: [
            {
              code: 'item1',
              quantity: 1,
            },
            {
              code: 'item3',
              quantity: 2,
            },
          ],
        })
      );
    }).toThrowError(`trialDuration should be positive integer`);

    expect(() => {
      validateProductIntegrationRecord.validateTrialSubscriptionConfig(
        JSON.stringify({
          planCode: 'TestPlan',
          frequency: 'TEST',
          trialDuration: 2,
          items: [
            {
              code: 'item1',
              quantity: 1,
            },
            {
              code: 'item3',
              quantity: 2,
            },
          ],
        })
      );
    }).toThrowError(`Empty or invalid frequency 'TEST'`);
  });
});
