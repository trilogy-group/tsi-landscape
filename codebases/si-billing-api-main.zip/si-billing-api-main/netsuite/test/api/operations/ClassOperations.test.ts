import * as record from 'N/record';
import ClassDao from '../../../src/ts/dao/ClassDao';
import classOps, { UpdateClassParams } from '../../../src/ts/api/operations/ClassOperations';

describe('ClassOperations', () => {
    beforeEach(() => {
      jest.restoreAllMocks();
    });
  
    it('update with missing class name', () => {
        // Arrange
        const params: any = {};

        // Act
        const action = () => classOps.update(params);

        // Assert
        expect(action).toThrowError('className is missing');
    });
  
    it('update with same renewal manager values should not update it', () => {
        // Arrange
        const params: UpdateClassParams = {
            className: 'Test',
            renewalManagerId: '201',
        };
        const classRecord: any = {
            id: 101,
            custrecord_renewal_manager: '201',
            getValue: (args) => classRecord[args.fieldId],
            setValue: (args) => classRecord[args.fieldId] = args.value,
            save: () => {},
        };
        jest.spyOn(ClassDao, 'getClassId').mockReturnValueOnce(classRecord.id);
        jest.spyOn(record, 'load').mockReturnValueOnce(classRecord);
        jest.spyOn(classRecord, 'setValue');

        // Act
        const result = classOps.update(params);

        // Assert
        expect(result).toBeDefined();
        expect(classRecord.setValue).not.toHaveBeenCalled();
    });
  
    it('update with different renewal manager values should update it', () => {
        // Arrange
        const params: UpdateClassParams = {
            className: 'Test',
            renewalManagerId: '202',
        };
        const classRecord: any = {
            id: 101,
            custrecord_renewal_manager: '201',
            getValue: (args) => classRecord[args.fieldId],
            setValue: (args) => classRecord[args.fieldId] = args.value,
            save: () => {},
        };
        jest.spyOn(ClassDao, 'getClassId').mockReturnValueOnce(classRecord.id);
        jest.spyOn(record, 'load').mockReturnValueOnce(classRecord);
        jest.spyOn(classRecord, 'setValue');

        // Act
        const result = classOps.update(params);

        // Assert
        expect(result).toBeDefined();
        expect(classRecord.setValue).toHaveBeenCalled();
        expect(classRecord.custrecord_renewal_manager).toBe(params.renewalManagerId);
    });
  
    it('update with undefined renewal manager should remove it', () => {
        // Arrange
        const params: UpdateClassParams = {
            className: 'Test',
            renewalManagerId: undefined,
        };
        const classRecord: any = {
            id: 101,
            custrecord_renewal_manager: '201',
            getValue: (args) => classRecord[args.fieldId],
            setValue: (args) => classRecord[args.fieldId] = args.value,
            save: () => {},
        };
        jest.spyOn(ClassDao, 'getClassId').mockReturnValueOnce(classRecord.id);
        jest.spyOn(record, 'load').mockReturnValueOnce(classRecord);
        jest.spyOn(classRecord, 'setValue');

        // Act
        const result = classOps.update(params);

        // Assert
        expect(result).toBeDefined();
        expect(classRecord.setValue).toHaveBeenCalled();
        expect(classRecord.custrecord_renewal_manager).toBe(null);
    });
});
