import QuoteOperations, { GenerateQuoteParams, QuoteOrderType } from '../../../src/ts/api/operations/QuoteOperations';
import SubscriptionDao from '../../../src/ts/dao/SubscriptionDao';
import QuoteDao, { QuoteEntityStatus, TcKeys } from '../../../src/ts/dao/QuoteDao';
import * as record from 'N/record';
import * as render from 'N/render';
import * as https from 'N/https';
import { RecordDynamicMock } from '../../SublistMock';
import QuoteService from '../../../src/ts/utility/QuoteService';
import ContractualDocumentsService from '../../../src/ts/utility/ContractualDocumentsService';
import { SubscriptionRecord } from '../../../src/ts/models/SubscriptionRecord';
import { OperationContext } from '../../../src/ts/models/OperationContext';
import AdobeESignService from '../../../src/ts/utility/AdobeESignService';
import { BillingSchedule, QuoteBillingSchedule, OperationUtils } from '../../../src/ts/types';
import * as nsutils from '../../../src/ts/nsutils';
import SubscriptionPlanUtility from '../../../src/ts/utility/SubscriptionPlanUtility';
import SubsidiaryDao from '../../../src/ts/dao/SubsidiaryDao';
import SubscriptionCreateUtility from '../../../src/ts/utility/SubscriptionCreateUtility';
import { clone } from '../../../src/ts/utility/GeneralUtility';
import { SubscriptionNotFoundError } from '../../../src/ts/validation';
import { QuoteRecord } from '../../../src/ts/models/QuoteRecord';
import CustomerService from '../../../src/ts/CustomerService';

describe('QuoteOperations', () => {
  beforeEach(() => {
    jest.restoreAllMocks();
    jest.spyOn(OperationContext, 'fromParams').mockReturnValue({
      productIntegration: {
        id: 1,
      },
    } as any);
  });

  it('createQuote customer is not enduser', () => {
    jest.spyOn(SubscriptionDao, 'getInfoForQuote').mockReturnValueOnce({
      startDate: new Date(),
      endDate: new Date(),
      endUserId: '3',
      endUserInternalId: 3,
      customerId: '2',
      customerInternalId: 2,
    } as any);
    const rWMock = new RecordDynamicMock({ item: [] }, {});
    const quoteMock = new RecordDynamicMock({
      addressbook: [new RecordDynamicMock({}, { defaultshipping: true, addressbookaddress_key: 1 })]
    }, { duedate: new Date(), currency: 2 });
    jest.spyOn(record, 'create').mockReturnValueOnce(rWMock as any);
    jest.spyOn(render, 'transaction').mockReturnValueOnce({ save: () => 1 } as any);
    jest
      .spyOn(Object.getPrototypeOf(QuoteService), 'getTermsAndConditionsForQuote')
      .mockReturnValue([TcKeys.OnPremise]);
    jest.spyOn(record, 'load').mockReturnValue(quoteMock as any);
    jest.spyOn(AdobeESignService, 'createTemporaryAgreement').mockReturnValueOnce(1);
    jest.spyOn(SubscriptionRecord, 'load').mockReturnValueOnce({ id: 1, currency: 2 } as any);
    QuoteOperations.createQuote({
      subscriptionId: 1,
      orderType: QuoteOrderType.Quote,
      customerId: '2',
      productFamilyCode: 'DNNE',
      quoteLineStartDates: [
        {
          line: "DNNE-OP-TUL-STA",
          startDate: "15-Jul-2033"
        }
      ],
      quoteLineEndDates: [
        {
          line: "DNNE-OP-TUL-STA",
          endDate: "14-Jul-2014"
        }
      ],
    });

    expect(rWMock.fields).toEqual(
      expect.objectContaining({
        custbody_end_user: 3,
        entity: 2,
        custbody_order_type: 1,
        custbody_renewal_terms: 1,
        probability: 100,
        currency: 2,
      })
    );
  });

  it('createQuote distributor', () => {
    const rWMock = createQuoteWithDistributor();
    expect(rWMock.fields).toEqual(
      expect.objectContaining({
        custbody_end_user: 3,
        entity: 2,
        custbody_order_type: 1,
        custbody_renewal_terms: 1,
        probability: 100,
      })
    );
  });

  it('createQuote list rate set', () => {
    const rWMock = createQuoteWithDistributor();
    expect(rWMock.sublists["item"][0].custcol_list_rate).toEqual(0);
  });

  it('createQuote reseller', () => {
    jest.spyOn(SubscriptionDao, 'getInfoForQuote').mockReturnValueOnce({
      startDate: new Date(),
      endDate: new Date(),
      endUserId: '3',
      endUserInternalId: 3,
      customerId: '2',
      customerInternalId: 2,
    } as any);
    const rWMock = new RecordDynamicMock({ item: [] }, {});
    const quoteMock = new RecordDynamicMock({
      addressbook: [new RecordDynamicMock({}, { defaultshipping: true, addressbookaddress_key: 1 })]
    }, {
      duedate: new Date(),
      custrecord_subs_reseller: 1
    });
    jest.spyOn(record, 'create').mockReturnValueOnce(rWMock as any);
    jest.spyOn(render, 'transaction').mockReturnValueOnce({ save: () => 1 } as any);
    jest
      .spyOn(Object.getPrototypeOf(QuoteService), 'getTermsAndConditionsForQuote')
      .mockReturnValue([TcKeys.OnPremise]);
    jest.spyOn(record, 'load').mockReturnValue(quoteMock as any);
    jest.spyOn(AdobeESignService, 'createTemporaryAgreement').mockReturnValueOnce(1);
    jest.spyOn(SubscriptionRecord, 'load').mockReturnValueOnce({ id: 1, customerInternalId: 1, isMaintenance: true } as any);
    jest.spyOn(render, 'create').mockReturnValueOnce({
      addRecord: () => { },
      setTemplateById: () => { },
      renderAsPdf: () => {
        return {
          folder: 1,
          name: 'a',
          save: () => { }
        } as any
      },
    } as any)
    QuoteOperations.createQuote({
      subscriptionId: 1,
      orderType: QuoteOrderType.Quote,
      customerId: '2',
      productFamilyCode: 'DNNE',
    });
    expect(rWMock.fields).toEqual(
      expect.objectContaining({
        custbody_end_user: 3,
        entity: 2,
        custbody_order_type: 1,
        custbody_renewal_terms: 1,
        probability: 100,
      })
    );
  });

  it('download', () => {
    jest.spyOn(QuoteDao, 'findQuoteInfo').mockReturnValueOnce({
      previewAgId: 1,
      endUserId: '3',
      endUserInternalId: 3,
      customerId: '2',
      customerInternalId: 2,
    } as any);
    jest.spyOn(QuoteDao, 'findLastAdobeAgreementInfo').mockReturnValueOnce({
      name: 'testfile',
      files: [42],
    } as any);
    jest
      .spyOn(Object.getPrototypeOf(AdobeESignService), 'triggerRefreshAdobeESignAccessToken')
      .mockImplementationOnce(() => { });
    jest.spyOn(https, 'get').mockReturnValueOnce({ code: 200, body: 'testFileContent' } as any);

    const res = QuoteOperations.download({
      quoteId: 1,
      customerId: '2',
    });
    expect(res).toEqual({ content: 'testFileContent' });
  });

  it('acceptQuote', () => {
    jest.spyOn(QuoteDao, 'findQuoteInfo').mockReturnValueOnce({
      previewAgId: 1,
      endUserId: '3',
      endUserInternalId: 3,
      customerId: '2',
      status: QuoteEntityStatus.Proposal,
      subscriptionId: 4
    } as any);
    jest.spyOn(render, 'transaction').mockReturnValueOnce({ getContents: () => 'pdfcontent' } as any);
    jest.spyOn(QuoteDao, 'findLastAdobeAgreementInfo').mockReturnValueOnce({
      name: 'testfile',
      files: [42],
    } as any);
    jest.spyOn(QuoteDao, 'findAdobeAgreementRecipients').mockReturnValueOnce([]);
    jest.spyOn(https, 'get').mockReturnValueOnce({ code: 200, body: '{ "success": true }' } as any);
    jest.spyOn(SubscriptionRecord, 'load').mockReturnValueOnce({
      subsidiary: 1,
      save: () => { }
    } as any);
    const ccdSpy = jest.spyOn(ContractualDocumentsService, 'create');
    const sfsSpy = jest.spyOn(QuoteService, 'sendForSignature');

    const res = QuoteOperations.acceptQuote({
      quoteId: 1,
      customerId: '2',
      content: {
        acceptor: {
          name: 'acceptorName',
          jobTitle: 'acceptorJobTitle',
          email: 'acceptor@email.com',
          phone: '111-11111-111',
        },
        ccEmail: 'cc@email.com',
        clientInfo: {
          ipAddress: '127.0.0.1',
          userAgent: 'userAgent',
        },
      },
    });
    expect(ccdSpy).toBeCalled();
    expect(sfsSpy).toBeCalled();
  });

  it('acceptQuote no subscription', () => {
    jest.spyOn(QuoteDao, 'findQuoteInfo').mockReturnValueOnce({
      previewAgId: 1,
      endUserId: '3',
      endUserInternalId: 3,
      customerId: '2',
      status: QuoteEntityStatus.Proposal,
    } as any);

    expect(() => {
      QuoteOperations.acceptQuote({
        quoteId: 1,
        customerId: '2',
        content: {
          acceptor: {
            name: 'acceptorName',
            jobTitle: 'acceptorJobTitle',
            email: 'acceptor@email.com',
            phone: '111-11111-111',
          },
          ccEmail: 'cc@email.com',
          clientInfo: {
            ipAddress: '127.0.0.1',
            userAgent: 'userAgent',
          },
        },
      });
    }).toThrowError('Quote is not linked to any subscription');
  });

  it('quoteName Renewal', () => {
    const res = QuoteOperations.getQuoteName({
      orderType: QuoteOrderType.Renewal,
    },
      {
        startDate: new Date('2020-01-01 00:00:00'),
        renewalNumber: '1',
        productClass: 'The Group:test Product',
        endUserCompanyName: 'endUserCompanyName',
      });
    expect(res).toEqual('endUserCompanyName - test - Renewal - 01_2020 - 1');
  });

  it('quoteName New sale', () => {
    const res = QuoteOperations.getQuoteName({
      orderType: QuoteOrderType.Quote,
    },
      {
        startDate: new Date('2020-01-01 00:00:00'),
        renewalNumber: '1',
        productClass: 'The Group:test Product',
        endUserCompanyName: 'endUserCompanyName',
      });
    expect(res).toEqual('endUserCompanyName - test - New sale - 01_2020 - 1');
  });

  it('quoteName No Order Type', () => {
    const res = QuoteOperations.getQuoteName({
      orderType: undefined,
    },
      {
        startDate: new Date('2020-01-01 00:00:00'),
        renewalNumber: '1',
        productClass: 'The Group:test Product',
        endUserCompanyName: 'endUserCompanyName',
      });
    expect(res).toEqual('endUserCompanyName - test - 01_2020 - 1');
  });

  it('quoteName no renewal number', () => {
    const res = QuoteOperations.getQuoteName({
      orderType: QuoteOrderType.Quote,
    },
      {
        startDate: new Date('2020-01-01 00:00:00'),
        renewalNumber: '',
        productClass: 'The Group:test Product',
        endUserCompanyName: 'endUserCompanyName',
      });
    expect(res).toEqual('endUserCompanyName - test - New sale - 01_2020');
  });

  it('quoteName no product class', () => {
    const res = QuoteOperations.getQuoteName({
      orderType: QuoteOrderType.Quote,
    },
      {
        startDate: new Date('2020-01-01 00:00:00'),
        renewalNumber: '',
        productClass: '',
        endUserCompanyName: 'endUserCompanyName',
      });
    expect(res).toEqual('endUserCompanyName -  - New sale - 01_2020');
  });

  it('quoteDueDate expiry', () => {
    const res = QuoteOperations.getDueDate('1-Jan-2020',
      new Date('2020-01-01'));
    expect(res).toEqual(nsutils.convert.toDate('1-Jan-2020'));
  });

  it('quoteDueDate 7', () => {
    const res = QuoteOperations.getDueDate(undefined,
      new Date('2020-01-01'));
    const dueDate = new Date();
    dueDate.setDate(dueDate.getDate() + 7);
    expect(nsutils.diffDateInDays(dueDate, res)).toEqual(0);
  });
  it('quoteDueDate 30', () => {
    const res = QuoteOperations.getDueDate(undefined,
      new Date('2120-01-01')
    );
    const dueDate = new Date();
    dueDate.setDate(dueDate.getDate() + 30);
    expect(nsutils.diffDateInDays(dueDate, res)).toEqual(0);
  });

  it('quoteBillingSchedule Montly long', () => {
    const res = QuoteOperations.getBillingSchedule(
      {
        startDate: new Date('2020-01-01'),
        endDate: new Date('2120-12-31'),
        frequency: BillingSchedule.MONTHLY,
      });
    expect(res).toEqual(QuoteBillingSchedule.MONTHLY_DUE_AT_START);
  });

  it('quoteBillingSchedule Quarterly', () => {
    const res = QuoteOperations.getBillingSchedule(
      {
        startDate: new Date('2020-01-01'),
        endDate: new Date('2020-12-31'),
        frequency: BillingSchedule.QUARTERLY,
      });
    expect(res).toEqual(QuoteBillingSchedule.QUARTERLY_DUE_AT_START);
  });

  it('quoteBillingSchedule Monthly', () => {
    const res = QuoteOperations.getBillingSchedule(
      {
        startDate: new Date('2020-01-01'),
        endDate: new Date('2021-12-31'),
        frequency: BillingSchedule.MONTHLY,
      });
    expect(res).toEqual(QuoteBillingSchedule.MONTHLY_DUE_AT_START);
  });
  it('quoteBillingSchedule Annually', () => {
    const res = QuoteOperations.getBillingSchedule(
      {
        startDate: new Date('2020-01-01'),
        endDate: new Date('2021-12-31'),
        frequency: BillingSchedule.ANNUALLY,
      });
    expect(res).toEqual(QuoteBillingSchedule.ANNUALLY_DUE_AT_START);
  });
  it('quoteBillingSchedule Annually Full', () => {
    const res = QuoteOperations.getBillingSchedule(
      {
        startDate: new Date('2020-01-01'),
        endDate: new Date('2020-12-31'),
        frequency: BillingSchedule.ANNUALLY,
      });
    expect(res).toEqual(QuoteBillingSchedule.FULL_UPON_SIGNATURE);
  });

  it('quoteBillingSchedule Monthly short', () => {
    const res = QuoteOperations.getBillingSchedule(
      {
        startDate: new Date('2020-01-01'),
        endDate: new Date('2020-12-31'),
        frequency: BillingSchedule.MONTHLY,
      });
    expect(res).toEqual(QuoteBillingSchedule.MONTHLY_DUE_AT_START);
  });

  it('cancelAgreement', () => {
    jest.spyOn(QuoteService, 'cancelAgreement').mockImplementation(() => { });
    const res = QuoteOperations.cancelAgreement({
      agreementId: 1
    }) as any;
    expect(res.content.success).toBe(true);
  });

  it('sendAgreementForSignature', () => {
    jest.spyOn(record, 'load').mockReturnValueOnce({
      setValue: () => { },
      save: () => { }
    } as any);
    jest.spyOn(QuoteService, 'sendAgreementForSignature').mockImplementation(() => { });
    const res = QuoteOperations.sendAgreementForSignature({
      agreementId: 1
    }) as any;
    expect(res.content.success).toBe(true);
  });

  it('setContractualDocumentsInfo should return an error message if Customer and End user are different', () => {
    const params: GenerateQuoteParams = {
      subscriptionId: 1,
    };
    jest.spyOn(record, 'load').mockReturnValueOnce(new RecordDynamicMock({}, {
      customer: '1',
      custrecord_subs_end_user: '2'
    }) as any);

    const result = QuoteOperations.setContractualDocumentsInfo(params) as any;
    expect(result.content.message).toEqual('Customer and End user are different');
  });

  it('setContractualDocumentsInfo should return an error message if subscription is without parent', () => {
    const params: GenerateQuoteParams = {
      subscriptionId: 1,
    };
    jest.spyOn(record, 'load').mockReturnValueOnce(new RecordDynamicMock({}, {
      customer: '2',
      custrecord_subs_end_user: '2',
    }) as any);

    const result = QuoteOperations.setContractualDocumentsInfo(params) as any;
    expect(result.content.message).toEqual('Subscription doesn\'t have a parent subscription');
  });

  it('setContractualDocumentsInfo should return a response with correct values', () => {
    const params: GenerateQuoteParams = {
      subscriptionId: 1,
    };
    jest.spyOn(record, 'load').mockReturnValueOnce(new RecordDynamicMock({}, {
      customer: '2',
      custrecord_subs_end_user: '2',
      subscriptionplanname: 'SubscriptionPlanName',
      subsidiary: 1,
      parentsubscription: 1
    }) as any);
    jest.spyOn(SubscriptionPlanUtility, 'getSubscriptionPlanById').mockReturnValueOnce({
      supportOnly: false,
      revenueType: 'hosted'
    } as any);

    jest.spyOn(QuoteService, 'setSignedQuotesToContractualDocuments').mockReturnValueOnce({
      contractualDocumentIdsChanged: [1, 2],
      message: 'message',
      found: true,
    });
    jest.spyOn(SubsidiaryDao, 'getSubsidiaryName').mockReturnValueOnce('subsidiaryName');

    const result = QuoteOperations.setContractualDocumentsInfo(params);
    expect(result).toEqual({
      content: {
        contractualDocumentIdsChanged: '1,2',
        message: 'message',
        found: true
      },
    });
  });

  it('createQuote unlinked', () => {
    const rWMock = createUnlinkedQuote();
    expect(rWMock.fields).toEqual(
      expect.objectContaining({
        currency: 1,
        custbody_line_items_footer_text: "footer",
        custbody_line_items_header_text: "header",
        custbody_end_user: 3,
      })
    );
  });

  it('createSelfServeQuote should throw an error if a mandatory param is missing', () => {
    // Arrange
    const mock = mockCreateSelfServeQuote();

    const testCases = [
      { deleteField: (params: any) => delete params.productFamilyCode, fieldName: 'productFamilyCode' },
      { deleteField: (params: any) => delete params.productVariantCode, fieldName: 'productVariantCode' },
      { deleteField: (params: any) => delete params.customerId, fieldName: 'customerId' },
      { deleteField: (params: any) => delete params.content, fieldName: 'content' },
      { deleteField: (params: any) => delete params.content.subscriptionId, fieldName: 'content.subscriptionId' },
      { deleteField: (params: any) => delete params.content.planCode, fieldName: 'content.planCode' },
      { deleteField: (params: any) => delete params.content.frequency, fieldName: 'content.frequency' },
      { deleteField: (params: any) => delete params.content.duration, fieldName: 'content.duration' },
      { deleteField: (params: any) => delete params.content.items, fieldName: 'content.items' },
    ];
    testCases.forEach(({ deleteField, fieldName }) => {
      const params = clone(mock.params);
      deleteField(params);

      // Act
      const action =  () => QuoteOperations.createSelfServeQuote(params);

      // Assert
      expect(action).toThrowError(`${fieldName} is mandatory`);
    });
  });

  it('createSelfServeQuote should throw an error if the subscription is not writable for the given customer', () => {
    // Arrange
    const mock = mockCreateSelfServeQuote();
    mock.subscription.isWritableForCustomer = (customerId: string) => false;

    // Act
    const action =  () => QuoteOperations.createSelfServeQuote(mock.params);

    // Assert
    expect(action).toThrowError(new SubscriptionNotFoundError().message);
  });

  it('createSelfServeQuote should throw an error if the subscription is not a renewal subscription', () => {
    // Arrange
    const mock = mockCreateSelfServeQuote();
    mock.subscription.parentId = undefined;

    // Act
    const action =  () => QuoteOperations.createSelfServeQuote(mock.params);

    // Assert
    expect(action).toThrowError('The subscription is not a renewal subscription.');
  });

  it('createSelfServeQuote should throw an error if the subscription plan does not match the operation context', () => {
    // Arrange
    const mock = mockCreateSelfServeQuote();
    mock.subscriptionPlan.product.variant.code = 'UNEXPECTED';

    // Act
    const action =  () => QuoteOperations.createSelfServeQuote(mock.params);

    // Assert
    expect(action).toThrowError(
      `The subscription plan '${mock.subscriptionPlan.code}' does not match `
      + `the product family '${mock.operationContext.productFamilyCode}' `
      + `and the product variant '${mock.operationContext.productVariantCode}'.`
    );
  });

  it('createSelfServeQuote should create a self-serve quote with valid parameters', () => {
    // Arrange
    const testCases = [
      { startDateOffset: 40, expected: { expiryOffset: 30, terms: 'Net 30' }},
      { startDateOffset: 20, expected: { expiryOffset: 7, terms: 'Due on receipt' }},
    ];
    testCases.forEach(({ startDateOffset, expected }) => {
      let unlinkedQuoteParams;
      const mock = mockCreateSelfServeQuote(startDateOffset, (params) => unlinkedQuoteParams = params);
      const initialRecipientsLength = mock.params.content.recipients.length;

      // Act
      const result = QuoteOperations.createSelfServeQuote(mock.params);
  
      // Assert
      expect('content' in result).toBeTruthy();
      const resultContent = (result as any).content;
      expect(resultContent?.id).toBe(mock.createUnlinkedQuoteContent.id);
      const expectedExpiry = new Date();
      expectedExpiry.setDate(expectedExpiry.getDate() + expected.expiryOffset);
      expectedExpiry.setHours(0, 0, 0, 0); // force start date in the locale timezone
      expect(unlinkedQuoteParams.expiry).toBe(expectedExpiry.toDateString());
      expect(unlinkedQuoteParams.terms).toBe(expected.terms);
      expect(mock.params.content.recipients.length).toBe(initialRecipientsLength + 3); // split + sales rep + renewal manager
    });
  });

  it('getQuoteType should throw an error if a mandatory param is missing', () => {
    // Arrange
    const params = {};

    // Act
    const action = () => QuoteOperations.getQuoteType(params as any);

    // Assert
    expect(action).toThrowError('quoteId is mandatory');
  });

  it('getQuoteType should return the quote type', () => {
    // Arrange
    const params = {
      quoteId: 101,
    };
    const quote = {
      customForm: 201,
    };
    jest.spyOn(QuoteRecord, 'load').mockReturnValueOnce(quote as any);
    const quoteType = "quote-type";
    jest.spyOn(QuoteService, 'getQuoteType').mockReturnValueOnce(quoteType);

    // Act
    const result = QuoteOperations.getQuoteType(params);

    // Assert
    expect((result as any)?.content).toBeDefined();
    expect((result as any).content?.quoteType).toEqual(quoteType);
    expect(QuoteService.getQuoteType).toBeCalledWith(quote.customForm);
  });
});

function createQuoteWithDistributor() {
  jest.spyOn(SubscriptionDao, 'getInfoForQuote').mockReturnValueOnce({
    startDate: new Date(),
    endDate: new Date(),
    endUserId: '3',
    endUserInternalId: 3,
    customerId: '2',
    customerInternalId: 2,
  } as any);
  const rWMock = new RecordDynamicMock({ item: [] }, {});
  const quoteMock = new RecordDynamicMock({
    addressbook: []
  }, {
    duedate: new Date(),
    custrecord_subs_distributor: 1
  });
  jest.spyOn(record, 'create').mockReturnValueOnce(rWMock as any);
  jest.spyOn(render, 'transaction').mockReturnValueOnce({ save: () => 1 } as any);
  jest
    .spyOn(Object.getPrototypeOf(QuoteService), 'getTermsAndConditionsForQuote')
    .mockReturnValue([TcKeys.OnPremise]);
  jest.spyOn(record, 'load').mockReturnValue(quoteMock as any);
  jest.spyOn(AdobeESignService, 'createTemporaryAgreement').mockReturnValueOnce(1);
  jest.spyOn(SubscriptionRecord, 'load').mockReturnValueOnce({ id: 1 } as any);
  QuoteOperations.createQuote({
    subscriptionId: 1,
    orderType: QuoteOrderType.Quote,
    customerId: '2',
    productFamilyCode: 'DNNE',
  });
  return rWMock;
}

function createUnlinkedQuote() {
  const rWMock = new RecordDynamicMock({ item: [] }, {});
  const quoteMock = new RecordDynamicMock({
    addressbook: []
  }, {
    duedate: new Date(),
    custrecord_subs_distributor: 1
  });
  jest.spyOn(CustomerService, 'addSubsidiary').mockImplementation(() => {});
  jest.spyOn(record, 'create').mockReturnValueOnce(rWMock as any);
  jest.spyOn(render, 'transaction').mockReturnValueOnce({ save: () => 1 } as any);
  jest
    .spyOn(Object.getPrototypeOf(QuoteService), 'getTermsAndConditionsForQuote')
    .mockReturnValue([TcKeys.OnPremise]);
  jest.spyOn(record, 'load').mockReturnValue(quoteMock as any);
  jest.spyOn(QuoteService, 'createAdobeServicesAgreement').mockReturnValue(1);
  jest.spyOn(SubscriptionRecord, 'load').mockReturnValueOnce({ id: 1 } as any);
  jest.spyOn(nsutils, 'queryFirstToJson').mockReturnValue(
    {
      endUserId: '3',
      endUserInternalId: 3,
      endUserCompanyName: 'company',
      productClass: 'test Product',
      subscriptionPlanId: 1,
      id: 1,
    }
  );
  QuoteOperations.createUnlinkedQuote({
    orderType: QuoteOrderType.Quote,
    customerId: '2',
    productFamilyCode: 'DNNE',
    startdate: "27-Apr-2024",
    enddate: "26-Apr-2025",
    endUserInternalId: 914979,
    distributorInternalId: undefined,
    resellerInternalId: undefined,
    currency: "USD",
    planId: 109989,
    frequency: "ANNUALLY",
    subsidiary: "22",
    relatedSubscriptionId: 1,
    items: [
      {
        item: 63220,
        quantity: 2,
        rate: 240,
        amount: 480,
        listRate: 2400
      }
    ],
    expiry: "17-May-2023",
    salesRepId: 662988,
    lineItemsHeaderText: 'header',
    lineItemsFooterText: 'footer',
    recipients: [
      {
        email: "celestine.huels54@gmail.com.invalid",
        role: "signer"
      },
      {
        email: "oj.enabosi@trilogy.com.invalid",
        role: "cc"
      }
    ]
  });
  return rWMock;
}

function mockCreateSelfServeQuote(startDateOffset: number = 40, assignUnlinkedQuoteParams?: (params: any) => any): { 
  operationContext: any, 
  subscription: any,
  subscriptionPlan: any,
  createUnlinkedQuoteContent: any,
  params: any,
} {
  const operationContext = {
    productFamilyCode: "DNN",
    productVariantCode: "OP-Cus",
    customerId: "customer-1",
    productIntegration: {
      nsClass: {
        id: 5001,
        renewalManagerId: 3001,
      },
    },
  };
  jest.spyOn(OperationContext, 'fromParams').mockReturnValueOnce(operationContext as any);
  const subscription = {
    id: 1002,
    parentId: 1001,
    startDate: new Date(),
    endUserInternalId: 2001,
    distributorInternalId: undefined,
    resellerInternalId: undefined,
    currencySymbol: 'USD',
    salesRepId: 3002,
    isWritableForCustomer: (customerId: string) => true,
  };
  subscription.startDate.setDate(subscription.startDate.getDate() + startDateOffset);
  subscription.startDate.setHours(0, 0, 0, 0); // force start date in the locale timezone
  jest.spyOn(SubscriptionRecord, 'load').mockReturnValueOnce(subscription as any);
  const subscriptionPlan = {
    id: 6000,
    code: 'DNN-OP-Cus-STA-SIL-002',
    items: [
      { id: 6001, code: "DNN-OP-Cus-STA" },
      { id: 6002, code: "DNN-OP-Cus-SIL" },
      { id: 6003, code: "DNN-TE-Dom-ADD" },
      { id: 6004, code: "DNN-TE-Dom-SIL" },
      { id: 6005, code: "DNN-TE-Sub-ADD" },
      { id: 6006, code: "DNN-TE-Sub-SIL" },
      { id: 6007, code: "DNN-OP-Dev-ADD" },
      { id: 6008, code: "DNN-OP-Dev-SIL" },
    ],
    product: {
      family: {
        code: 'DNN',
      },
      variant: {
        code: 'OP-Cus',
      },
    },
  };
  jest.spyOn(SubscriptionPlanUtility, 'getSubscriptionPlanByCode').mockReturnValueOnce(subscriptionPlan as any);
  jest.spyOn(SubscriptionCreateUtility, 'findSuitableSubsidiary').mockReturnValueOnce(3001);
  const previewContent = {
    items: [
      { code: "DNN-OP-Cus-STA", quantity: 1, amount: 800 },
      { code: "DNN-OP-Cus-SIL", quantity: 1, amount: 200 },
      { code: "DNN-TE-Dom-ADD", quantity: 2, amount: 640 },
      { code: "DNN-TE-Dom-SIL", quantity: 2, amount: 160 },
      { code: "DNN-TE-Sub-ADD", quantity: 3, amount: 480 },
      { code: "DNN-TE-Sub-SIL", quantity: 3, amount: 120 },
    ],
  };
  const createUnlinkedQuoteContent = { id: 4001 };
  jest.spyOn(OperationUtils, 'callAndGetContent')
    .mockReturnValueOnce(previewContent) // first call
    .mockImplementationOnce((_this: any, _operation: any, params: any) => {
      if (assignUnlinkedQuoteParams) assignUnlinkedQuoteParams(params);
      return createUnlinkedQuoteContent;
    }); // second call
  jest.spyOn(nsutils, 'queryFirstToJson')
    .mockReturnValueOnce({ email: 'sales.rep@trilogy.com.invalid' }) // first call: sales rep
    .mockReturnValueOnce({ email: 'renewal.manager@trilogy.com.invalid' }); // second call: renewal manager
  const params = { ...operationContext,
    content: {
      subscriptionId: 1,
      recipients: [
        { "email": "signer@customer.com.invalid", "role": "signer" },
        { "email": "first-cc@customer.com.invalid", "role": "cc" },
        { "email": "second-cc@customer.com.invalid", "role": "cc" },
        { "email": "third-cc@customer.com.invalid ; fourth-cc@customer.com.invalid ;", "role": "cc" },
      ],
      planCode: "DNN CustomerCloud EVOQ, STANDARD EDITION, GOLD SUCCESS-002",
      frequency: "ANNUALLY",
      duration: 12,
      items: [
        { code: "DNN-OP-Cus-STA", quantity: 1 },
        { code: "DNN-TE-Dom-ADD", quantity: 2 },
        { code: "DNN-TE-Sub-ADD", quantity: 3 },
        { code: "DNN-OP-Dev-ADD", quantity: 0 ,}
      ]
    }
  };
  jest.spyOn(nsutils.convert, 'toDateText').mockImplementation((d: Date) => {
    d.setHours(0, 0, 0, 0); // force start date in the locale timezone
    return d.toDateString();
  });

  return {
    operationContext,
    subscription,
    subscriptionPlan,
    createUnlinkedQuoteContent,
    params,
  }
}