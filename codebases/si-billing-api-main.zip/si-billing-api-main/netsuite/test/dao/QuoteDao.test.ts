import QuoteDao from '../../src/ts/dao/QuoteDao';
import * as nsutils from '../../src/ts/nsutils';
import * as record from 'N/record';
import { RecordDynamicMock } from '../SublistMock';

describe('QuoteDao', () => {
  it('getQuotes should return an empty array if there is no quote ID', () => {
    // Arrange
    const quoteIds = [];

    // Act
    const result = QuoteDao.getQuotes(quoteIds);

    // Assert
    expect(result).toBeDefined();
    expect(result.length).toEqual(0);
  });

  it('getQuotes should return quote details', () => {
    // Arrange
    const quoteIds = [ 1, 2, 3 ];
    const quotes = quoteIds.map(id => ({ id } as any));
    jest.spyOn(nsutils, 'queryToJson').mockReturnValueOnce(quotes);

    // Act
    const result = QuoteDao.getQuotes(quoteIds);

    // Assert
    expect(result).toBeDefined();
    expect(result.length).toEqual(3);
    result.forEach((q, i) => expect(q).toMatchObject(quotes[i]));
  });

  it('findLastAdobeAgreementInfo', () => {
    jest.spyOn(nsutils, 'queryToJson').mockReturnValueOnce([{ id: 1, custrecord_echosign_agreement: 2 }]);
    jest.spyOn(record, 'load').mockImplementationOnce((params: any): any => {
      if (params.id === 1) {
        return new RecordDynamicMock([], { custrecord_echosign_file: 42 }) as any;
      }
    });
    const agreementInfo = QuoteDao.findLastAdobeAgreementInfo(1);
    expect(agreementInfo).toEqual({ files: [42], id: 2 });
  });

  it('getAdobeAgreementsInfo should return an empty array if there is no quote ID', () => {
    // Arrange
    const quoteIds = [];

    // Act
    const result = QuoteDao.getAdobeAgreementsInfo(quoteIds);

    // Assert
    expect(result).toBeDefined();
    expect(result.length).toEqual(0);
  });

  it('getAdobeAgreementsInfo should return agreement details', () => {
    // Arrange
    const quoteIds = [ 1, 2, 3 ];
    const agreements = [
      { parentId: 1, id: 11, type: 'Quote', status: 'Draft' },
      { parentId: 1, id: 12, type: 'End User Agreement', status: 'Draft' },
      { parentId: 2, id: 21, type: 'Quote', status: 'Out For Signature' },
    ];
    jest.spyOn(nsutils, 'queryToJson').mockReturnValueOnce(agreements);

    // Act
    const result = QuoteDao.getAdobeAgreementsInfo(quoteIds);

    // Assert
    expect(result).toBeDefined();
    expect(result).toEqual(agreements);
  });

  it('addAgreementRecipient', () => {
    jest.spyOn(nsutils, 'queryToJson').mockReturnValueOnce([{ id: 2, company: 1 }]);
    jest.spyOn(record, 'create').mockImplementationOnce((params: any): any => {
      return new RecordDynamicMock([], {}) as any;
    });
    QuoteDao.addAgreementRecipient(1, 'customer@test.com', false, 1, 0);
  });

  it('findLinkedQuotes', () => {
    // Arrange
    const subscriptionId = 1;
    const hardLinkedQuotes = [ 11 ];
    const softLinkedQuotes = [ 12, 13 ];
    jest.spyOn(QuoteDao, 'findHardLinkedQuotes').mockReturnValueOnce(hardLinkedQuotes);
    jest.spyOn(QuoteDao, 'findSoftLinkedQuotes').mockReturnValueOnce(softLinkedQuotes);

    // Act
    const result = QuoteDao.findLinkedQuotes(subscriptionId);

    // Assert
    expect(result).toBeDefined();
    expect(result).toEqual([ ...hardLinkedQuotes, ...softLinkedQuotes ]);
  });

  it('getQuoteTermId', () => {
    jest.spyOn(nsutils, 'queryFirstToJson').mockReturnValueOnce({ id:1 });
    const id = QuoteDao.getTermId('Net 30');
    expect(id).toBe(1);
  });
});
