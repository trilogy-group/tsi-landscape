import * as main from '../src/ts/main'
import { NotFoundError, ValidationError } from '../src/ts/validation';

describe('main', () => {
  it('Router throws error 500 for an unhandled error', () => {
    expect(
      () => main.post({op: 'unknown'})
    ).toThrow(
      expect.objectContaining({ name: '500' })
    );
  });

  it('Router throws error 400 for a validation error', () => {
    const errorMessage = 'Something is wrong';
    let router = new main.Router();
    router.op('test', (_req) => { throw new ValidationError(errorMessage, 'somefield'); });
    
    expect(
      () => router.run({op: 'test'})
    ).toThrow(
      expect.objectContaining({ name: '400', message: errorMessage })
    );
  });

  it('Router throws error 404 for a Not Found error', () => {
    const errorMessage = 'Record not found';
    let router = new main.Router();
    router.op('test', (_req) => { throw new NotFoundError(errorMessage); });
    
    expect(
      () => router.run({op: 'test'})
    ).toThrow(
      expect.objectContaining({ name: '404', message: errorMessage })
    );
  });
});
