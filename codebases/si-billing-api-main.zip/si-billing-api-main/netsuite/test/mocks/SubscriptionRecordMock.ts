import { SublistIterator } from '../../src/ts/models/DynamicSublistWrapper';
import { SubscriptionLine } from '../../src/ts/models/SubscriptionRecord';

class SublistIteratorMock<T> {
  data: any[];
  curIndex: number;
  curLine: any;

  constructor(data: T[]) {
    this.data = data;
    this.curIndex = 0;
  }
  nextLine(): boolean {
    const res = this.curIndex < this.data.length;
    this.curLine = this.data[this.curIndex];
    this.curIndex++;
    return res;
  }
  line(): T {
    return this.curLine;
  }
  getFieldValue(fieldId) {
    return this.curLine[fieldId];
  }

  commit() {}
}

export class SubscriptionRecordMock {
  lines;
  constructor(fields, lines) {
    Object.assign(this as any, fields);
    this.lines = lines;
  }

  isWritableForCustomer(customerId: string) {
    return true;
  }

  isReadableForCustomer(customerId: string) {
    return true;
  }

  processSubscriptionLines<T>(f: (sublist: SublistIterator<SubscriptionLine>) => T): T {
    return f(new SublistIteratorMock<T>(this.lines) as any);
  }

  processSublist<T>(sublistId: string, f: (sublist: SublistIterator<T>) => T): T {
    return f(new SublistIteratorMock<T>(this.lines) as any);
  }

  save() {}
}
