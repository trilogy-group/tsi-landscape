import { OperationContext } from '../../src/ts/models/OperationContext';
import { ProductIntegration } from '../../src/ts/ProductIntegration';

describe('OperationContext', () => {
  it('productIntegrationCache', () => {
    const ctx = new OperationContext({
      customerId: 'TestCustomer',
      productFamilyCode: 'DNNE',
      productVariantCode: 'SA-Cus',
    });
    jest.spyOn(ProductIntegration, 'findProductIntegration').mockReturnValueOnce(1 as any);
    jest.spyOn(ProductIntegration, 'findProductIntegration').mockReturnValueOnce(2 as any);
    const pi = ctx.productIntegration;
    expect(pi).toEqual(1);
  });
});
