import { TermUnit } from "../../src/ts/types"
import { TermDuration } from "../../src/ts/models/TermDuration"

describe('TermDuration', () => {
  it('isLessThan', () => {
    expect(new TermDuration(1, TermUnit.DAYS).isLessThan(new TermDuration(2, TermUnit.DAYS)))
    .toBeTruthy();
    expect(new TermDuration(1, TermUnit.DAYS).isLessThan(new TermDuration(1, TermUnit.WEEKS)))
    .toBeTruthy();
    expect(new TermDuration(1, TermUnit.DAYS).isLessThan(new TermDuration(1, TermUnit.MONTHS)))
    .toBeTruthy();
    expect(new TermDuration(1, TermUnit.DAYS).isLessThan(new TermDuration(1, TermUnit.YEARS)))
    .toBeTruthy();
    expect(() => new TermDuration(1, 'INVALID' as any).isLessThan(new TermDuration(1, TermUnit.YEARS)))
    .toThrowError('Invalid unit');
  });

  it('toString', () => {
    expect(new TermDuration(1, TermUnit.DAYS).toString()).toEqual('1 DAYS');
  });
});
