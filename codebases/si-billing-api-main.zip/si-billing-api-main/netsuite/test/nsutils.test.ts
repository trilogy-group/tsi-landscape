import * as record from 'N/record';
import * as log from 'N/log';
import * as nsutils from '../src/ts/nsutils';
import { ProductIntegration } from '../src/ts/ProductIntegration';

describe('nsutils', () => {
  beforeEach(() => {
    jest.restoreAllMocks();
    jest.spyOn(nsutils, 'queryToJson');
    jest.spyOn(nsutils, 'queryFirstToJson');
    jest.spyOn(nsutils, 'queryFirstAsMap');
  });

  it('mapNested', () => {
    const res = nsutils.mapNested(
      {
        key1: 'val1',
        key2: 'val2',
        key3: 'internalVal3',
      },
      {
        key1: 'mkey1',
        key2: { key: 'mkey2', f: (v) => 'transformed' + v },
        key3: 'internal.key',
      }
    );

    expect(res).toStrictEqual({ mkey1: 'val1', mkey2: 'transformedval2', internal: { key: 'internalVal3' } });
  });

  it('asHash', () => {
    const res = nsutils.asHash(
      [
        { key1: 'c1v1', key2: 'c1v2' },
        { key1: 'c2v1', key2: 'c2v2' },
      ],
      'key1'
    );

    expect(res).toStrictEqual({
      c1v1: { key1: 'c1v1', key2: 'c1v2' },
      c2v1: { key1: 'c2v1', key2: 'c2v2' },
    });
  });

  it('setRecordValues', () => {
    const testRecord = record.create({
      type: record.Type.SUBSCRIPTION_CHANGE_ORDER,
      isDynamic: true,
      defaultValues: {
        action: 'RENEW',
        subscription: 1,
      },
    });
    const values = {
      renewalmethod: 'CREATE_NEW_SUBSCRIPTION',
      renewalPlan: '123',
    };
    nsutils.setRecordValues(testRecord, values);
    expect(testRecord).toEqual({
      id: 1,
      renewalmethod: 'CREATE_NEW_SUBSCRIPTION',
      renewalPlan: '123',
    });
  });

  it('findProdutIntegration', () => {
    (nsutils.queryToJson as any).mockReturnValueOnce([
      {
        classname: 'TestClass',
        custrecordsecret: 'secret',
      },
    ]);
    ProductIntegration.findProductIntegration('TestPFC', 'TestPVC');
  });

  it('chunkSubstr should return the same string if string is short', () => {
    const inputStr = '1234567890abcdefghij12345';
    const chunks = nsutils.chunkSubstr(inputStr, 30);

    expect(chunks.length).toEqual(1);
    expect(chunks[0]).toEqual(inputStr);
  });

  it('chunkSubstr should break long string by chunks', () => {
    const inputStr = '1234567890abcdefghij12345';
    const chunks = nsutils.chunkSubstr(inputStr, 10);

    expect(chunks.length).toEqual(3);
    expect(chunks[0]).toEqual('1234567890');
    expect(chunks[1]).toEqual('abcdefghij');
    expect(chunks[2]).toEqual('12345');
  });

  it('logDebug should not break the string message', () => {
    const logDebugSpy = jest.spyOn(log, 'debug').mockImplementation();
    const inputStr = '1234567890abcdefghij12345';

    // act
    nsutils.logDebug('title', inputStr);

    // assert
    expect(logDebugSpy).toHaveBeenCalled();
    expect(logDebugSpy).toBeCalledTimes(1);
    expect(logDebugSpy).toHaveBeenNthCalledWith(1, 'title', inputStr);
  });

  it('logDebug should break the string message', () => {
    const logDebugSpy = jest.spyOn(log, 'debug').mockImplementation();
    const inputStr: any = new Array(8000).join('1');

    // act
    nsutils.logDebug('title', inputStr);

    // assert
    expect(logDebugSpy).toHaveBeenCalled();
    expect(logDebugSpy).toBeCalledTimes(3);
    expect(logDebugSpy).toHaveBeenNthCalledWith(3, 'title 2', '1');
  });

  it('logDebug should break the object log message', () => {
    const logDebugSpy = jest.spyOn(log, 'debug').mockImplementation();
    const inputStr: any = new Array(7990).join('1');

    // act
    nsutils.logDebug('title', { value: inputStr });

    // assert
    expect(logDebugSpy).toHaveBeenCalled();
    expect(logDebugSpy).toBeCalledTimes(3);
    expect(logDebugSpy).toHaveBeenNthCalledWith(3, 'title 2', '1"}');
  });

  it('logMayBe logs', () => {
    const logDebugSpy = jest.spyOn(log, 'debug').mockImplementation();
    const logStr = 'logStr';

    // act
    nsutils.logMayBe('something', logStr);

    // assert
    expect(logDebugSpy).toHaveBeenCalled();
    expect(logDebugSpy).toBeCalledTimes(1);
    expect(logDebugSpy).toHaveBeenCalledWith('something', logStr);
  });

  it("logMayBe don't logs", () => {
    const logDebugSpy = jest.spyOn(log, 'debug').mockImplementation();
    const logStr = 'logStr';

    // act
    nsutils.logMayBe('not something', logStr);

    // assert
    expect(logDebugSpy).toBeCalledTimes(0);
  });

  it('logMayBeIf logs', () => {
    const logDebugSpy = jest.spyOn(log, 'debug').mockImplementation();
    const logStr = 'logStr';

    // act
    nsutils.logMayBeIf(true, 'something', logStr);

    // assert
    expect(logDebugSpy).toHaveBeenCalled();
    expect(logDebugSpy).toBeCalledTimes(1);
    expect(logDebugSpy).toHaveBeenCalledWith('something', logStr);
  });

  it("logMayBeIf don't logs", () => {
    const logDebugSpy = jest.spyOn(log, 'debug').mockImplementation();
    const logStr = 'logStr';

    // act
    nsutils.logMayBeIf(false, 'something', logStr);

    // assert
    expect(logDebugSpy).toBeCalledTimes(0);
  });

  it('getProductIntegrationOrDefault', () => {
    const pi = { family: { code: 'TES' } } as ProductIntegration;

    (nsutils.queryToJson as any).mockReturnValue([pi]);
    const res = ProductIntegration.getProductIntegrationOrDefault('pfc', 'pvc');

    expect(res).toBe(pi);
  });

  it('getBySubscriptionPlanIdOrDefault', () => {
    const pi = { family: { code: 'TES' } } as ProductIntegration;

    (nsutils.queryFirstToJson as any).mockReturnValue(pi);
    const res = ProductIntegration.getBySubscriptionPlanIdOrDefault(1243);

    expect(res).toBe(pi);
  });

  it('getProductIntegration successfull', () => {
    const pi = { family: { code: 'TES' } } as ProductIntegration;

    (nsutils.queryToJson as any).mockReturnValue([pi]);
    const res = ProductIntegration.getProductIntegration('pfc', 'pvc');

    expect(res).toBe(pi);
  });

  it('getProductIntegration unsuccessfull', () => {
    (nsutils.queryToJson as any).mockReturnValue([]);
    const t = () => {
      ProductIntegration.getProductIntegration('pfc', 'pvc');
    };
    expect(t).toThrowError('Cannot find product integration');
  });
});
