import { onRequest } from '../src/ts/suitelet';
import * as https from 'N/https';
import * as redirect from 'N/redirect';
import QuoteService from '../src/ts/utility/QuoteService';

describe('Suitelet', () => {
  beforeEach(() => {
    // Clear all instances and calls to constructor and all methods:
    jest.clearAllMocks();
  });

  it('calls QuoteService.createEUA and redirect.toRecord when request method is GET and op is createEUA', () => {
    const context: any = {
      request: {
        method: https.Method.GET,
        parameters: {
          op: 'createEUA',
          quoteId: 1
        }
      },
      response: {
        write: jest.fn()
      }
    };

    const createEUA = jest.spyOn(QuoteService, 'createEUA');
    createEUA.mockReturnValueOnce(2);
    jest.spyOn(redirect, 'toRecord').mockImplementationOnce(() => {});

    onRequest(context);

    expect(createEUA).toHaveBeenCalledWith(1);
    expect(redirect.toRecord).toHaveBeenCalledWith({
      type: 'customrecord_echosign_agreement',
      id: 2
    });
  });

  it('writes "Invalid request" when request method is GET and op is not createEUA', () => {
    const context: any = {
      request: {
        method: https.Method.GET,
        parameters: {
          op: 'testOp',
          quoteId: 'testQuoteId'
        }
      },
      response: {
        write: jest.fn()
      }
    };

    onRequest(context);

    expect(context.response.write).toHaveBeenCalledWith({
      output: '<html><body><h1>Invalid request</h1></body></html>'
    });
  });

  it('writes "Invalid request" when request method is not GET', () => {
    const context: any = {
      request: {
        method: https.Method.POST,
        parameters: {
          op: 'createEUA',
          quoteId: 'testQuoteId'
        }
      },
      response: {
        write: jest.fn()
      }
    };

    onRequest(context);

    expect(context.response.write).toHaveBeenCalledWith({
      output: '<html><body><h1>Invalid request</h1></body></html>'
    });
  });
});