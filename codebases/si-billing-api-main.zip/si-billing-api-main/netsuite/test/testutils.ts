export function spyPrivate(obj: any, methodName: string, impl?: any) {
  const f = jest.spyOn(Object.getPrototypeOf(obj), methodName)
  if (impl) {
    return f.mockImplementation(impl);
  }
  return f;
}

// expose private methods
export function exposePrivate(obj): any {
  return Object.getPrototypeOf(obj);
}