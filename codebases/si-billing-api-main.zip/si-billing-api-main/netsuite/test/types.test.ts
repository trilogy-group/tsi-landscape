import {
  ContractualDocumentType, ContractualDocumentTypeUtils,
  OperationUtils,
  ProductTier, ProductTierUtil,
  RevenueType, RevenueTypeUtils,
  SupportLevel, SupportLevelUtil,
  TypedHandlerResponse
} from '../src/ts/types';

describe('types', () => {
  it('OperationUtils callAndGetContent', () => {
    // Arrange
    const _this = {
      fakeSumOperation: function(params: { a: number, b: number}): TypedHandlerResponse<number> {
        return { content: params.a + params.b };
      },
    };
    const params = { a: 1, b: 2 };

    // Act
    const result = OperationUtils.callAndGetContent(_this, _this.fakeSumOperation, params);

    // Assert
    expect(result).toBe(params.a + params.b);
  });
  
  it('SupportLevelUtil codeToSupportLevel', () => {
    expect(SupportLevelUtil.codeToSupportLevel('SIL')).toBe(SupportLevel.Silver);
    expect(SupportLevelUtil.codeToSupportLevel('GOL')).toBe(SupportLevel.Gold);
    expect(SupportLevelUtil.codeToSupportLevel('PLA')).toBe(SupportLevel.Platinum);
    expect(SupportLevelUtil.codeToSupportLevel('PLL')).toBeUndefined();
  });

  it('SupportLevelUtil supportLevelToCode', () => {
    expect(SupportLevelUtil.supportLevelToCode(SupportLevel.Silver)).toBe('SIL');
    expect(SupportLevelUtil.supportLevelToCode(SupportLevel.Gold)).toBe('GOL');
    expect(SupportLevelUtil.supportLevelToCode(SupportLevel.Platinum)).toBe('PLA');
    expect(
      () => SupportLevelUtil.supportLevelToCode('undefined' as SupportLevel)
    ).toThrowError("Couldn't convert");
  });

  it('SupportLevelUtil nameToLevel', () => {
    expect(SupportLevelUtil.supportLevelToNumber(SupportLevel.Silver)).toBe(1);
    expect(SupportLevelUtil.supportLevelToNumber(SupportLevel.Gold)).toBe(2);
    expect(SupportLevelUtil.supportLevelToNumber(SupportLevel.Platinum)).toBe(3);
    const t = () => {
      SupportLevelUtil.supportLevelToNumber('Wood' as SupportLevel);
    };
    expect(t).toThrowError("Couldn't convert");
  });

  it('ProductTierUtil codeToProductTier', () => {
    expect(ProductTierUtil.codeToProductTier('STA')).toBe(ProductTier.Standard);
    expect(ProductTierUtil.codeToProductTier('PRO')).toBe(ProductTier.Professional);
    expect(ProductTierUtil.codeToProductTier('ENT')).toBe(ProductTier.Enterprise);
    expect(ProductTierUtil.codeToProductTier('PLL')).toBeUndefined();
  });

  it('ProductTier tostring', () => {
    expect(ProductTier.Standard.toString()).toBe('Standard');
    expect(ProductTier.Professional.toString()).toBe('Professional');
    expect(ProductTier.Enterprise.toString()).toBe('Enterprise');
  });

  it('ProductTierUtil productTierToCode', () => {
    expect(ProductTierUtil.productTierToCode(ProductTier.Standard)).toBe('STA');
    expect(ProductTierUtil.productTierToCode(ProductTier.Professional)).toBe('PRO');
    expect(ProductTierUtil.productTierToCode(ProductTier.Enterprise)).toBe('ENT');
    expect(
      () => ProductTierUtil.productTierToCode('undefined' as ProductTier)
    ).toThrowError("Couldn't convert");
  });

  it('ProductTierUtil nameToLevel', () => {
    expect(ProductTierUtil.productTierToNumber(ProductTier.Standard)).toBe(1);
    expect(ProductTierUtil.productTierToNumber(ProductTier.Professional)).toBe(2);
    expect(ProductTierUtil.productTierToNumber(ProductTier.Enterprise)).toBe(3);
    const t = () => {
      ProductTierUtil.productTierToNumber('Wood' as ProductTier);
    };
    expect(t).toThrowError("Couldn't convert");
  });

  it('RevenueTypeUtils nameToRevenueType', () => {
    expect(RevenueTypeUtils.nameToRevenueType('Hosted')).toBe(RevenueType.Hosted);
    expect(RevenueTypeUtils.nameToRevenueType('On-Premise')).toBe(RevenueType.OnPremise);
    expect(RevenueTypeUtils.nameToRevenueType('SaaS')).toBe(RevenueType.SaaS);
    expect(RevenueTypeUtils.nameToRevenueType('Professional Services')).toBe(RevenueType.ProfessionalServices);
    expect(RevenueTypeUtils.nameToRevenueType('Support')).toBe(RevenueType.Support);
    expect(RevenueTypeUtils.nameToRevenueType('Other')).toBeUndefined();
  });

  it('ContractualDocumentTypeUtils hasValue', () => {
    expect(ContractualDocumentTypeUtils.hasValue(ContractualDocumentType.PurchaseOrder)).toEqual(true);
    expect(ContractualDocumentTypeUtils.hasValue("undefined-value" as ContractualDocumentType)).toEqual(false);
  });

  it('ContractualDocumentTypeUtils documentTypeToPrefix', () => {
    expect(ContractualDocumentTypeUtils.documentTypeToPrefix(ContractualDocumentType.PurchaseOrder)).toEqual("PO-");
    const undefinedDocumentType = "undefined-value" as ContractualDocumentType;
    expect(() => ContractualDocumentTypeUtils.documentTypeToPrefix(undefinedDocumentType)).toThrowError(`The contractual document type '${undefinedDocumentType}' is not supported`);
  });
});
