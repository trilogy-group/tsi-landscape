import * as record from 'N/record';
import { onAction } from '../src/ts/uptick/uptick';
import subscriptionGetUtility from '../src/ts/utility/SubscriptionGetUtility';
import subscriptionPriceUtility from '../src/ts/utility/SubscriptionPriceUtility';
import subscriptionValidateUtility from '../src/ts/utility/SubscriptionValidateUtility';
import subscriptionPlanUtility from '../src/ts/utility/SubscriptionPlanUtility';
import subscriptionPlanDao from '../src/ts/dao/SubscriptionPlanDao';
import { ProductIntegration } from '../src/ts/ProductIntegration';
import { ProductTier, SupportLevel, TermUnit } from '../src/ts/types';

describe('uptick', () => {
  beforeEach(() => {
    jest.restoreAllMocks();
  });
  it('uptick applied', () => {
    jest
      .spyOn(ProductIntegration, 'getBySubscriptionPlanIdOrDefault')
      .mockReturnValue({ nsClass: { id: 1, name: 'USD', fullname: 'Dollar' }, isUptickEnabled: true });

    jest.spyOn(subscriptionGetUtility, 'getSubscriptionByIdInternal').mockReturnValue({
      plan: {
        id: 1,
      },
      term: {
        frequency: 'ANNUALLY',
      },
      includedItems: [
        {
          id: 1,
          code: 'A',
          quantity: 1,
        },
      ],
      items: [
        {
          id: 1,
          code: 'A',
          frequency: 'Annually',
          prices: [
            {
              ranges: [
                {
                  fromQuantity: 0,
                  price: 10,
                },
              ],
            },
          ],
        },
      ],
    } as any);
    jest.spyOn(subscriptionPlanUtility, 'getSubscriptionPlanById').mockReturnValue({
      items: [{
          id: 1,
          code: 'DNNE-SA-Cus-SIL',
          desc: '',
          maxQuantity: 10,
          minQuantity: 0,
          isMainItem: false,
          isSupportItem: true,
          productTier: ProductTier.Standard,
          revenueType: 'SaaS',
          prices: [
            {
              currency: 'USD',
              frequency: 'ANNUALLY',
              pricebookid: 11956,
              ranges: [
                {
                  fromQuantity: 0,
                  priceplanid: 4702673,
                  price: 30,
                  type: 'Rate',
                },
              ],
              type: 'Volume',
            },
            {
              currency: 'USD',
              frequency: 'MONTHLY',
              pricebookid: 11957,
              ranges: [
                {
                  fromQuantity: 0,
                  priceplanid: 4702677,
                  price: 35,
                  type: 'Rate',
                },
              ],
              type: 'Volume',
            },
          ],
          required: true,
          title: 'DNNE Silver Support',
          type: 'Recurring',
          typeId: 2,
        },
      ],
      supportLevel: SupportLevel.Silver,
      productTier: ProductTier.Standard,
      revenueType: '',
      code: 'DNNE-SA-Cus-PRO-SIL-001',
      supportOnly: false,
      isLegacyPlan: false,
      name: 'Some Plan Name',
      initialterm: {
        duration: 1,
        unit: 'YEARS'
      }
    } as any);
    jest.spyOn(subscriptionGetUtility, 'buildItems').mockReturnValue({
      subscriptionItems: {
        availableItems: [
          {
            id: 1,
            code: 'DNNE-SA-Cus-SIL',
            prices: [
              {
                frequency: 'ANNUALLY',
                ranges: [
                  {
                    fromQuantity: 0,
                    type: 'Rate',
                    price: 1,
                  },
                  {
                    fromQuantity: 2,
                    type: 'Rate',
                    price: 2,
                  },
                  {
                    fromQuantity: 5,
                    type: 'Rate',
                    price: 5,
                  },
                ],
              },
            ],
          },
        ],
        supportItems: [
          {
            id: 1,
            code: 'DNNE-SA-Cus-SIL',
            prices: [
              {
                frequency: 'ANNUALLY',
                ranges: [
                  {
                    fromQuantity: 0,
                    type: 'Rate',
                    price: 1,
                  },
                  {
                    fromQuantity: 2,
                    type: 'Rate',
                    price: 2,
                  },
                  {
                    fromQuantity: 5,
                    type: 'Rate',
                    price: 5,
                  },
                ],
              },
            ],
          },
        ],
        supportItem: { item: { code: 'DNNE-SA-Cus-SIL' }, quantity: 1 },
      },
      planOptions: { supportLevel: 'Silver' },
    } as any);
    jest.spyOn(subscriptionPlanDao, 'getFrequencyFromPriceBook').mockReturnValue('ANNUALLY');
    jest.spyOn(subscriptionPlanUtility, 'getSubscriptionPlans').mockReturnValue([
      {
        name: 'something',
        items: [
          {
            id: 1,
            prices: [
              {
                frequency: 'ANNUALLY',
                ranges: [
                  {
                    fromQuantity: 0,
                    type: 'Rate',
                    price: 1,
                  },
                  {
                    fromQuantity: 1,
                    type: 'Rate',
                    price: 3,
                  },
                  {
                    fromQuantity: 7,
                    type: 'Rate',
                    price: 7,
                  },
                ],
              },
            ],
          },
        ],
      },
    ] as any);
    (record.create as any).mockReturnValue({
      setValue: () => {},
      save: () => {},
      selectNewLine: () => {},
      setCurrentSublistValue: () => {},
      commitLine: () => {},
    });
    (record.load as any).mockReturnValue({
      getValue: () => {},
      getLineCount: () => 1,
      selectLine: () => {},
      getCurrentSublistValue: () => 1,
    });
    jest.spyOn(subscriptionValidateUtility, 'isPlanDowngrade').mockReturnValue(false);
    const params = {
      newRecord: {
        getLineCount: () => 1,
        selectLine: () => {},
        getCurrentSublistValue: (value) => {
          switch (value.fieldId) {
            case 'frequency':
              return 'ANNUALLY';
            default:
              return 1;
          }
        },
        setCurrentSublistValue: () => {},
        commitLine: () => {},
        fields: {
          frequency: 'ANNUALLY',
          subscriptionplan: '1',
          parentsubscription: '1'
        },
        getValue: () => 1,
      },
    };
    const res = onAction(params);
    expect(res).toBe('Applied');
  });

  it('support level without uptick', () => {
    const params = {
      newRecord: {
        fields: {
          subscriptionplan: '1',
          parentsubscription: '1'
        },
        getLineCount: () => 1,
        selectLine: () => {},
        getCurrentSublistValue: () => 'ANNUALLY',
      },
    };
    jest.spyOn(subscriptionGetUtility, 'getSubscriptionByIdInternal').mockReturnValue({
      plan: {
        id: 1,
      },
      term: {
        frequency: 'ANNUALLY',
      },
    } as any);
    jest.spyOn(subscriptionPlanUtility, 'getSubscriptionPlanById').mockReturnValue({
      items: [{
          id: 1,
          code: 'DNNE-SA-Cus-SIL',
          desc: '',
          maxQuantity: 10,
          minQuantity: 0,
          isMainItem: false,
          isSupportItem: true,
          productTier: ProductTier.Standard,
          revenueType: 'SaaS',
          prices: [
            {
              currency: 'USD',
              frequency: 'ANNUALLY',
              pricebookid: 11956,
              ranges: [
                {
                  fromQuantity: 0,
                  priceplanid: 4702673,
                  price: 30,
                  type: 'Rate',
                },
              ],
              type: 'Volume',
            },
            {
              currency: 'USD',
              frequency: 'MONTHLY',
              pricebookid: 11957,
              ranges: [
                {
                  fromQuantity: 0,
                  priceplanid: 4702677,
                  price: 35,
                  type: 'Rate',
                },
              ],
              type: 'Volume',
            },
          ],
          required: true,
          title: 'DNNE Silver Support',
          type: 'Recurring',
          typeId: 2,
        },
      ],
      supportLevel: SupportLevel.Silver,
      productTier: ProductTier.Standard,
      revenueType: '',
      code: 'DNNE-SA-Cus-PRO-SIL-001',
      supportOnly: false,
      isLegacyPlan: false,
      name: 'Some Plan Name',
      initialterm: {
        duration: 1,
        unit: 'YEARS'
      }
    } as any);
    // jest.spyOn(subscriptionGetUtility, 'buildItems').mockReturnValue({
    //   availableItems: [{ code: 'DNNE-SA-AA-BB', prices: [] }],
    //   supportItem: { item: { code: 'DNNE-SA-Cus-CON' } },
    //   planOptions: {
    //     supportLevel: 'Other',
    //   },
    // } as any);
    jest.spyOn(subscriptionGetUtility, 'buildItems').mockReturnValue({
      subscriptionItems: {
        availableItems: [
          {
            id: 1,
            code: 'DNNE-SA-AA-BB',
            prices: [
              {
                frequency: 'ANNUALLY',
                ranges: [
                  {
                    fromQuantity: 0,
                    type: 'Rate',
                    price: 1,
                  },
                  {
                    fromQuantity: 2,
                    type: 'Rate',
                    price: 2,
                  },
                  {
                    fromQuantity: 5,
                    type: 'Rate',
                    price: 5,
                  },
                ],
              },
            ],
          },
        ],
        supportItem: { item: { code: 'A' }, quantity: 1 },
      },
      planOptions: { supportLevel: 'Silver' },
    } as any);
    jest.spyOn(subscriptionPlanUtility, 'getSubscriptionPlans').mockReturnValue([{ supportLevel: 'Other' }] as any);
    const res = onAction(params);
    expect(res).toBe('Not applied');
  });

  it('uptick different plan', () => {
    const params = {
      newRecord: {
        fields: {
          subscriptionplan: '1',
        },
      },
    };
    jest.spyOn(subscriptionGetUtility, 'getSubscriptionByIdInternal').mockReturnValue({
      plan: {
        id: 2,
      },
    } as any);
    const res = onAction(params);
    expect(res).toBe('Not applied. New subscription have different plan from parent subscription.');
  });

  it('uptick different frequency', () => {
    const params = {
      newRecord: {
        fields: {
          subscriptionplan: '1',
        },
        getLineCount: () => 1,
        selectLine: () => {},
        getCurrentSublistValue: () => 'ANNUALLY',
      },
    };
    jest.spyOn(subscriptionGetUtility, 'getSubscriptionByIdInternal').mockReturnValue({
      plan: {
        id: 1,
      },
      term: {
        frequency: 'MONTHLY',
      },
    } as any);
    const res = onAction(params);
    expect(res).toBe('Not applied. New subscription have different frequency from parent subscription.');
  });

  it('getMainAndSupportDistributionRatioForUptick', () => {
    const itemsUpticked = [
      {
        id: 1,
        price: {
          type: 'Volume',
          frequency: 'ANNUALLY',
          currency: 'USD',
          ranges: [
            {
              fromQuantity: 0,
              type: 'Rate',
              price: 12,
            },
          ],
        },
      },
    ];
    const mainItem = {
      id: 1,
      code: 'DNNE-SA-Cus-STA',
      quantity: 2,
      amount: 0,
      prices: [
        {
          ranges: [
            {
              fromQuantity: 0,
              type: 'Rate',
              price: 10,
            },
          ],
        },
      ],
    };
    const supportItem = {
      id: 2,
      code: 'DNNE-SA-Cus-SIL',
      prices: [
        {
          ranges: [
            {
              fromQuantity: 0,
              type: 'Rate',
              price: 5,
            },
          ],
        },
      ],
    };
    jest.spyOn(subscriptionGetUtility, 'buildItems').mockReturnValue({
      subscriptionItems: {
        mainItem: {
          item: mainItem as any,
          quantity: 1,
          isIncluded: true,
        },
        supportItem: {
          item: supportItem as any,
          quantity: 1,
          isIncluded: true,
        },
      },
    } as any);
    (record.load as any).mockReturnValue({
      getValue: () => {},
      getLineCount: () => 1,
      selectLine: () => {},
      getCurrentSublistValue: () => 1,
      fields: { subscriptionplan: 'DNNE-SA-Cus-PRO-SIL-001' },
    });

    // parentSubscriptionId: number,
    // parentPlanInfoIsLegacy: boolean,
    // draftItems?: productCatalog.SubscriptionItems,
    // mainItem?: productCatalog.SubscriptionItem,
    // supportItem?: productCatalog.SubscriptionItem

    const supportMultiplier = Object.getPrototypeOf(
      subscriptionPriceUtility
    ).getMainAndSupportDistributionRatioForUptick({id: 1}, false, true, { items: [] }, undefined, mainItem, supportItem);

    Object.getPrototypeOf(subscriptionPriceUtility).applyDistributionRatioToSupportItems(
      supportMultiplier,
      itemsUpticked,
      [ supportItem ],
      [ mainItem ]
    );

    expect(itemsUpticked).toStrictEqual([
      {
        id: 1,
        price: {
          type: 'Volume',
          frequency: 'ANNUALLY',
          currency: 'USD',
          ranges: [
            {
              fromQuantity: 0,
              type: 'Rate',
              price: 8,
            },
          ],
        },
      },
      {
        id: 2,
        price: {
          type: 'Volume',
          frequency: 'ANNUALLY',
          currency: 'USD',
          ranges: [
            {
              fromQuantity: 0,
              priceplanid: undefined,
              type: 'Rate',
              price: 4,
            },
          ],
        },
      },
    ]);
  });

  it('uptick different plan', () => {
    const params = {
      newRecord: {
        fields: {
          subscriptionplan: '1',
        },
        setValue: () => {}
      },
    };
    jest.spyOn(subscriptionGetUtility, 'getSubscriptionByIdInternal').mockImplementation(() => {
      throw new Error('test');
    });
    const res = onAction(params);
    expect(res).toBe('Not applied. Error when trying to uptick: Error: test');
  });
});
