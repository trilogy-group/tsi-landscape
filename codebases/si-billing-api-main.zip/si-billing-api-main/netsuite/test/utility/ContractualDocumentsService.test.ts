import * as record from 'N/record';
import ContractualDocumentsService from '../../src/ts/utility/ContractualDocumentsService';
import FileService from '../../src/ts/utility/FileService';
import { CONTRACTUAL_DOCUMENTS_RECORD_TYPE, ContractualDocumentsRecord } from '../../src/ts/models/ContractualDocumentsRecord';
import { ContractualDocumentType, ContractualDocumentTypeUtils } from '../../src/ts/types';

describe('ContractualDocumentsService', () => {
  afterEach(() => {
    jest.clearAllMocks();
  });

  it('createWithJiraTicket', () => {
    // quote
    (record.load as any).mockReturnValue({
      getValue: () => 1,
      setValue: () => {},
      save: () => {}
    });

    (record.create as any).mockReturnValue({
      setValue: () => {},
      save: () => { return 2 }
    });
    jest.spyOn(FileService, 'attachFile').mockReturnValue({} as any);
    const r = ContractualDocumentsService.createWithJiraTicket({quoteId: 1, subscriptionId: 1, jiraTicketId: 'O2C-11111', fileIds: [1], quoteFileId: 2}) as any;
    expect(r.content.contractualDocumentsId).toBe(2);
  });

  test('attaches the file correctly', () => {
    const params = {
      contractualDocumentsId: 1,
      fileId: 1,
    };

    ContractualDocumentsService.attachFile(params);

    expect(FileService.attachFile).toHaveBeenCalledWith({
      fileId: params.fileId,
      recordType: CONTRACTUAL_DOCUMENTS_RECORD_TYPE,
      recordId: params.contractualDocumentsId,
    });
  });

  test('links the contract PDF when signedQuote is true', () => {
    const params = {
      contractualDocumentsId: 1,
      fileId: 1,
      signedQuote: true,
    };

    const mockContractDocs = {
      linkToContractPDF: null,
      save: jest.fn(),
    } as any;

    jest.spyOn(ContractualDocumentsRecord, 'load').mockReturnValueOnce(mockContractDocs);
    jest.spyOn(FileService, 'getUrl').mockReturnValueOnce('some-file-url');

    ContractualDocumentsService.attachFile(params);

    expect(ContractualDocumentsRecord.load).toHaveBeenCalledWith(params.contractualDocumentsId);
    expect(FileService.getUrl).toHaveBeenCalledWith(params.fileId);
    expect(mockContractDocs.linkToContractPDF).toBe('some-file-url');
    expect(mockContractDocs.save).toHaveBeenCalled();
  });

  test('returns success response', () => {
    const params = {
      contractualDocumentsId: 1,
      fileId: 1,
    };

    const response = ContractualDocumentsService.attachFile(params) as any;

    expect(response.content.success).toBe(true);
  });

  it('containsDocumentType should return true if there is a file starting with the prefix for the document type', () => {
    // Arrange
    const contractualDocumentsId = 101;
    const documentType = ContractualDocumentType.PurchaseOrder;
    const prefix = ContractualDocumentTypeUtils.documentTypeToPrefix(documentType);
    const attachedFiles = [
      { fileId: 201, fileName: 'first-file.pdf' },
      { fileId: 202, fileName: `${prefix}second-file.pdf` },
      { fileId: 203, fileName: 'third-file.pdf' },
    ] as any[];
    jest.spyOn(FileService, 'getAttachedFiles').mockReturnValueOnce(attachedFiles);

    // Act
    const result = ContractualDocumentsService.containsDocumentType(contractualDocumentsId, documentType);

    // Assert
    expect(result).toBe(true);
  });

  it('containsDocumentType should return false if there is no file starting with the prefix for the document type', () => {
    // Arrange
    const contractualDocumentsId = 101;
    const documentType = ContractualDocumentType.PurchaseOrder;
    const attachedFiles = [
      { fileId: 201, fileName: 'first-file.pdf' },
      { fileId: 202, fileName: 'second-file.pdf' },
      { fileId: 203, fileName: 'third-file.pdf' },
    ] as any[];
    jest.spyOn(FileService, 'getAttachedFiles').mockReturnValueOnce(attachedFiles);

    // Act
    const result = ContractualDocumentsService.containsDocumentType(contractualDocumentsId, documentType);

    // Assert
    expect(result).toBe(false);
  });
});
