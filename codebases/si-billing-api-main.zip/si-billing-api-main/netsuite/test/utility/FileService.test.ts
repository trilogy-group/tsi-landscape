import * as file from 'N/file';
import * as search from 'N/search';
import FileService from '../../src/ts/utility/FileService';
import * as nsutils from '../../src/ts/nsutils';

describe('FileService', () => {
  it('searchAttachedFiles', () => {
    (search.create as any).mockImplementation(() => {
      return {
        run: () => { 
          return {
            getRange: () => {
              return [{
                getAllValues: () => {
                  return {
                    "file.internalid": [
                      {
                        "value": "11445721",
                        "text": "11445721"
                      }
                    ],
                    "file.name": "Order-DNN-Annual Renewal-2022-3_customer signed",
                    "file.filetype": [{
                      "value": "PDF",
                      "text": "PDF file"
                    }]
                  }
                }
              },{
                getAllValues: () => {
                  return {
                    "file.internalid": [
                      {
                        "value": "11445721",
                        "text": "11445721"
                      }
                    ],
                    "file.name": "Order-DNN-Annual Renewal-2022-3_customer signed",
                    "file.filetype": [{
                      "value": "PDF",
                      "text": "PDF file"
                    }]
                  }
                }
              }]
            }
          }
        }
      }
    });
    const r = FileService.searchAttachedFiles({recordType: 'estimate', id: 1}) as any;
    expect(r.content.result[0]).toEqual({
      "fileId": "11445721",
      "fileName": "Order-DNN-Annual Renewal-2022-3_customer signed",
      "fileType": {
        "text": "PDF file",
        "value": "PDF"
      }
    });
  });
  
  it('searchAttachedFiles empty', () => {
    (search.create as any).mockImplementation(() => {
      return {
        run: () => { 
          return {
            getRange: () => {
              return [{
                getAllValues: () => {
                  return {
                    "file.internalid": [],
                    "file.name": "",
                    "file.filetype": []
                  }
                }
              },{
                getAllValues: () => {
                  return {
                    "file.internalid": [],
                    "file.name": ""
                  }
                }
              }]
            }
          }
        }
      }
    });
    const r = FileService.searchAttachedFiles({recordType: 'estimate', id: 1}) as any;
    expect(r.content.result).toEqual([]);
  });

  it('attachFile', () => {
    const r = FileService.attachFile({recordType: '1', recordId: 1, fileId: 1}) as any;
    expect(r.content.success).toBe(true);
  });

  it('getUrl should return the correct URL for a valid fileId', () => {
    const fileId = 1;
    jest.spyOn(nsutils, 'queryFirstAsMap').mockReturnValueOnce({ url: '/path/to/file' });

    const result = FileService.getUrl(fileId);
    expect(result).toEqual('https://test.app.netsuite.com/path/to/file');
  });

  it('getUrl should return undefined if no URL is found', () => {
    const fileId = 2;
    jest.spyOn(nsutils, 'queryFirstAsMap').mockReturnValueOnce(undefined);

    const result = FileService.getUrl(fileId);
    expect(result).toBeUndefined();
  });

  it('uploadFile should throw an error when the file extension is not supported', () => {
    // Arrange
    const params = {
      filename: 'test.unsupported',
      contents: 'my-file-content',
    };

    // Act
    const action = () => FileService.uploadFile(params);

    // Assert
    expect(action).toThrowError(`The file extension ${params.filename.split('.').pop()} is not supported`);
  });

  it('uploadFile should determine the file type based on the filename when the file type is not given', () => {
    // Arrange
    const fileRec = {
      save: jest.fn(),
    } as any;
    jest.spyOn(file, 'create').mockReturnValue(fileRec);
    const tests = [
      { filename: 'test.csv', expected: { fileType: file.Type.CSV } },
      { filename: 'test.json', expected: { fileType: file.Type.JSON } },
      { filename: 'test.pdf', expected: { fileType: file.Type.PDF } },
      { filename: 'test.txt', expected: { fileType: file.Type.PLAINTEXT } },
    ];
    for (const test of tests) {
      const params = {
        filename: test.filename,
        contents: 'my-file-content',
      };

      // Act
      FileService.uploadFile(params);

      // Assert
      expect(file.create).toHaveBeenCalledWith( {
        name: params.filename,
        fileType: test.expected.fileType,
        contents: params.contents,
      });
    }
  });

  it('uploadFile should create new file record', () => {
    // Arrange
    const params = {
      filename: 'test.txt',
      type: file.Type.PLAINTEXT,
      contents: 'my-file-content',
    };
    const fileRec = {
      save: jest.fn(),
    } as any;
    jest.spyOn(file, 'create').mockReturnValueOnce(fileRec);

    // Act
    FileService.uploadFile(params);

    // Assert
    expect(file.create).toHaveBeenCalled();
    expect(fileRec.save).toHaveBeenCalled();
  });
});
