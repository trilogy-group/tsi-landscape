import { createEUA } from '../../src/ts/utility/QuoteCreateEUAScript';
import * as currentRecord from 'N/currentRecord';
import * as url from 'N/url';

(global as any).window = { open: jest.fn() };

describe('createEUA', () => {
  beforeEach(() => {
    jest.spyOn(currentRecord, 'get').mockReturnValue({id: 123} as any);
    jest.spyOn(url, 'resolveScript').mockReturnValue('https://www.example.com');
  });

  afterEach(() => {
    jest.clearAllMocks();
  });

  it('should open a new window with the correct URL', () => {
    createEUA();

    expect(currentRecord.get).toHaveBeenCalled();
    expect(url.resolveScript).toHaveBeenCalledWith({
      scriptId: 'customscript_si_main_suitelet',
      deploymentId: 'customdeploy_si_main_suitelet',
      returnExternalUrl: false,
    });
    expect(window.open).toHaveBeenCalledWith(
      'https://www.example.com&op=createEUA&quoteId=123',
      '_blank'
    );
  });
});