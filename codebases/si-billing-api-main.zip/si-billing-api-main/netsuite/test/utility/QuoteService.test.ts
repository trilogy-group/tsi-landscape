import QuoteDao, { TcKeys } from '../../src/ts/dao/QuoteDao';
import SubsidiaryDao from '../../src/ts/dao/SubsidiaryDao';
import { RevenueType } from '../../src/ts/types';
import QuoteService, { AgreementType } from '../../src/ts/utility/QuoteService';
import { SubscriptionRecordMock } from '../mocks/SubscriptionRecordMock';
import { RecordDynamicMock } from '../SublistMock';
import * as record from 'N/record';
import * as render from 'N/render';
import * as https from 'N/https';
import * as nsutils from '../../src/ts/nsutils'
import AdobeESignService from '../../src/ts/utility/AdobeESignService';
import FileService from '../../src/ts/utility/FileService';
import { QuoteRecord } from '../../src/ts/models/QuoteRecord';
import SubscriptionPlanUtility from '../../src/ts/utility/SubscriptionPlanUtility';

describe('QuoteService', () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  it('getCustomForm end user different', () => {
    const sr = new SubscriptionRecordMock(
      {
        customerInternalId: 1,
        endUserInternalId: 2,
      },
      []
    ) as any;
    const rs = Object.getPrototypeOf(QuoteService).getCustomFormNumber(sr);
    expect(rs).toBe(162);
  });

  it('getCustomForm maintenance', () => {
    const sr = new SubscriptionRecordMock(
      {
        customerInternalId: 1,
        endUserInternalId: 1,
        isMaintenance: true
      },
      []
    ) as any;
    const rs = Object.getPrototypeOf(QuoteService).getCustomFormNumber(sr);
    expect(rs).toBe(220);
  });

  it('getCustomForm saas', () => {
    const sr = new SubscriptionRecordMock(
      {
        customerInternalId: 1,
        endUserInternalId: 1,
        isMaintenance: false,
        revenueType: RevenueType.SaaS
      },
      []
    ) as any;
    const rs = Object.getPrototypeOf(QuoteService).getCustomFormNumber(sr);
    expect(rs).toBe(221);
  });

  it('getCustomForm on premise', () => {
    const sr = new SubscriptionRecordMock(
      {
        customerInternalId: 1,
        endUserInternalId: 1,
        isMaintenance: false,
        revenueType: RevenueType.OnPremise
      },
      []
    ) as any;
    const rs = Object.getPrototypeOf(QuoteService).getCustomFormNumber(sr);
    expect(rs).toBe(223);
  });

  it('getCustomForm hosted', () => {
    // hosted
    const sr = new SubscriptionRecordMock(
      {
        customerInternalId: 1,
        endUserInternalId: 1,
        isMaintenance: false,
        revenueType: RevenueType.Hosted
      },
      []
    ) as any;
    const rs = Object.getPrototypeOf(QuoteService).getCustomFormNumber(sr);
    expect(rs).toBe(223);
  });

  it('getCustomForm other', () => {
    const sr = new SubscriptionRecordMock(
      {
        customerInternalId: 1,
        endUserInternalId: 1,
        isMaintenance: false,
        revenueType: undefined
      },
      []
    ) as any;
    const rs = Object.getPrototypeOf(QuoteService).getCustomFormNumber(sr);
    expect(rs).toBe(219);
  });

  it('getCustomForm professional services', () => {
    const sr = new SubscriptionRecordMock(
      {
        customerInternalId: 1,
        endUserInternalId: 1,
        isMaintenance: false,
        revenueType: RevenueType.ProfessionalServices
      },
      []
    ) as any;
    const rs = Object.getPrototypeOf(QuoteService).getCustomFormNumber(sr);
    expect(rs).toBe(222);
  });

  it('getCustomForm with parent without contractual documents', () => {
    const sr = new SubscriptionRecordMock(
      {
        customerInternalId: 1,
        endUserInternalId: 1,
        isMaintenance: false,
        revenueType: RevenueType.OnPremise,
        parentId: 1,
        subsidiary: 1
      },
      []
    ) as any;
    // load parent
    jest.spyOn(record, 'load').mockReturnValueOnce(new RecordDynamicMock({}, {}) as any);
    const recursiveSpy = jest.spyOn(Object.getPrototypeOf(QuoteService), 'findMasterContractId');
    const rs = Object.getPrototypeOf(QuoteService).getCustomFormNumber(sr);
    expect(rs).toBe(223);
    expect(recursiveSpy).toHaveBeenCalledTimes(2);
  });

  it('getCustomForm parent without master contract', () => {
    const sr = new SubscriptionRecordMock(
      {
        customerInternalId: 1,
        endUserInternalId: 1,
        isMaintenance: false,
        revenueType: RevenueType.OnPremise,
        parentId: 1,
        subsidiary: 1
      },
      []
    ) as any;
    // parent subscription
    jest.spyOn(record, 'load').mockReturnValueOnce(new RecordDynamicMock({}, {
      custrecord_contract_docs: 1
    }) as any);
    // contract docs
    jest.spyOn(record, 'load').mockReturnValueOnce(new RecordDynamicMock({}, {
      custrecord_sub_doc_is_master_contract: false
    }) as any);
    const recursiveSpy = jest.spyOn(Object.getPrototypeOf(QuoteService), 'findMasterContractId');
    const rs = Object.getPrototypeOf(QuoteService).getCustomFormNumber(sr);
    expect(rs).toBe(223);
    expect(recursiveSpy).toHaveBeenCalledTimes(2);
  });

  it('getCustomForm has master contract but different customer', () => {
    const sr = new SubscriptionRecordMock(
      {
        customerInternalId: 1,
        endUserInternalId: 1,
        isMaintenance: false,
        revenueType: RevenueType.OnPremise,
        parentId: 1,
        subsidiary: 1
      },
      []
    ) as any;
    // parent subscription
    jest.spyOn(record, 'load').mockReturnValueOnce(new RecordDynamicMock({}, {
      custrecord_contract_docs: 1,
      customer: 2
    }) as any);
    // contract docs
    jest.spyOn(record, 'load').mockReturnValueOnce(new RecordDynamicMock({}, {
      custrecord_sub_doc_is_master_contract: true,
      custrecord_sub_doc_revenue_type: RevenueType.SaaS
    }) as any);
    const rs = Object.getPrototypeOf(QuoteService).getCustomFormNumber(sr);
    expect(rs).toBe(223);
  });

  it('getCustomForm master contract with different revenueType', () => {
    const sr = new SubscriptionRecordMock(
      {
        customerInternalId: 1,
        endUserInternalId: 1,
        isMaintenance: false,
        revenueType: RevenueType.OnPremise,
        parentId: 1,
        subsidiary: 1
      },
      []
    ) as any;
    // parent subscription
    jest.spyOn(record, 'load').mockReturnValueOnce(new RecordDynamicMock({}, {
      custrecord_contract_docs: 1,
      customer: 1
    }) as any);
    // contract docs
    jest.spyOn(record, 'load').mockReturnValueOnce(new RecordDynamicMock({}, {
      custrecord_sub_doc_is_master_contract: true,
      custrecord_sub_doc_revenue_type: RevenueType.SaaS
    }) as any);
    const rs = Object.getPrototypeOf(QuoteService).getCustomFormNumber(sr);
    expect(rs).toBe(223);
  });

  it('getCustomForm has master contract but different subsidiary', () => {
    const sr = new SubscriptionRecordMock(
      {
        customerInternalId: 1,
        endUserInternalId: 1,
        isMaintenance: false,
        revenueType: RevenueType.OnPremise,
        parentId: 1,
        subsidiary: 1
      },
      []
    ) as any;
    // parent subscription
    jest.spyOn(record, 'load').mockReturnValueOnce(new RecordDynamicMock({}, {
      custrecord_contract_docs: 1,
      subsidiary: 2,
      customer: 1
    }) as any);
    // contract docs
    jest.spyOn(record, 'load').mockReturnValueOnce(new RecordDynamicMock({}, {
      custrecord_sub_doc_is_master_contract: true,
      custrecord_sub_doc_revenue_type: RevenueType.OnPremise
    }) as any);
    const rs = Object.getPrototypeOf(QuoteService).getCustomFormNumber(sr);
    expect(rs).toBe(223);
  });

  it('getCustomForm has master contract.', () => {
    const sr = new SubscriptionRecordMock(
      {
        customerInternalId: 1,
        endUserInternalId: 1,
        isMaintenance: false,
        revenueType: RevenueType.OnPremise,
        parentId: 1,
        subsidiary: 1
      },
      []
    ) as any;
    // parent subscription
    jest.spyOn(record, 'load').mockReturnValueOnce(new RecordDynamicMock({}, {
      custrecord_contract_docs: 3,
      subsidiary: 1,
      customer: 1
    }) as any);
    // contract docs
    jest.spyOn(record, 'load').mockReturnValueOnce(new RecordDynamicMock({}, {
      id: 3,
      custrecord_sub_doc_is_master_contract: true,
      custrecord_sub_doc_revenue_type: RevenueType.OnPremise
    }) as any);
    const rs = Object.getPrototypeOf(QuoteService).getCustomFormNumber(sr);
    expect(rs).toBe(219);
  });

  it('createAdobeServicesAgreement', () => {
    jest.spyOn(record, 'create').mockReturnValue(new RecordDynamicMock([], {}) as any);
    jest.spyOn(record, 'load').mockReturnValue(
      new RecordDynamicMock([], { subsidiary: 1, title: 'quote 1' }) as any
    );
    jest.spyOn(render, 'transaction').mockReturnValue(new RecordDynamicMock([], {}) as any);
    jest.spyOn(SubsidiaryDao, 'getSubsidiaryName').mockReturnValueOnce('subsidiary name');
    jest.spyOn(AdobeESignService, 'createTemporaryAgreement').mockReturnValue(1);
    const res = QuoteService.createAdobeServicesAgreement(1, [TcKeys.Maintenance], true, AgreementType.Quote, [
      { email: 'customer@test.com', role: 'signer' },
      { email: 'cc@test.com', role: 'cc' },
    ]);
  });

  it('createAdobeServicesAgreement adds BU renewals recipient', () => {
    jest.spyOn(record, 'create').mockReturnValue(new RecordDynamicMock([], {}) as any);
    jest.spyOn(record, 'load').mockReturnValue(
      new RecordDynamicMock([], { subsidiary: 1, title: 'quote 1' }) as any
    );
    jest.spyOn(render, 'transaction').mockReturnValue(new RecordDynamicMock([], {}) as any);
    jest.spyOn(SubsidiaryDao, 'getSubsidiaryName').mockReturnValueOnce('subsidiary name');
    jest.spyOn(AdobeESignService, 'createTemporaryAgreement').mockReturnValue(1);
    jest.spyOn(QuoteDao, 'getOrderTypeAndOutboundEmailDomain').mockReturnValueOnce({
      orderType: 2,
      outboundEmailDomain: "example.com",
    });
    const addAgreementRecipient = jest.spyOn(QuoteDao, 'addAgreementRecipient');
    QuoteService.createAdobeServicesAgreement(1, [TcKeys.Maintenance], true, AgreementType.Quote, [
      { email: 'customer@test.com', role: 'signer' },
      { email: 'cc@test.com', role: 'cc' },
    ]);
    expect(addAgreementRecipient).toBeCalledWith(
      expect.anything(),
      'renewals@example.com.invalid',
      expect.anything(),
      expect.anything(),
      expect.anything()
    );
  });

  it('deleteQuote success', () => {
    jest.spyOn(nsutils, 'queryToJson').mockReturnValueOnce([
      { id: 1, status: 'Draft' },
      { id: 2, status: 'Not Yet Sent For Signature' },
      { id: 3, status: 'Out For Signature' },
      { id: 4, status: 'Signed' },
    ]);
    const deleteMockFn = jest.spyOn(record, 'delete').mockImplementation();
    const httpsGetFn = jest.spyOn(https, 'get').mockReturnValueOnce({ code: 200, body: '{ "success": true }' } as any);
    QuoteService.deleteQuote(1);
    expect(deleteMockFn).toBeCalledTimes(3);
    expect(httpsGetFn).toBeCalledTimes(1);
  });

  it('deleteQuote cancel agreement fail', () => {
    jest.spyOn(nsutils, 'queryToJson').mockReturnValueOnce([
      { id: 3, status: 'Out For Signature' }
    ]);
    jest.spyOn(https, 'get').mockReturnValueOnce({ code: 400, body: '{ "success": false }' } as any);
    expect(() => { QuoteService.deleteQuote(1) }).toThrowError('Failed to cancel agreement 3 that was sent out for signature');
  });

  it('setSignedQuotesToContractualDocuments should return Full TCs not found when subscriptionId is undefined', () => {
    const result = QuoteService.setSignedQuotesToContractualDocuments(undefined, []);
    expect(result.message).toBe('Signed Full TCs not found');
    expect(result.found).toBe(false);
  });

  it('setSignedQuotesToContractualDocuments should call itself recursively when subscription.contractDocs is null', () => {
    jest.spyOn(record, 'load').mockReturnValueOnce(new RecordDynamicMock({}, {
      customer: 1,
      custrecord_subs_end_user: 1,
      subsidiary: 1
    }) as any);
    const recursiveSpy = jest.spyOn(QuoteService, 'setSignedQuotesToContractualDocuments');
    QuoteService.setSignedQuotesToContractualDocuments(1, []);
    expect(recursiveSpy).toHaveBeenCalledTimes(2);
  });

  it('setSignedQuotesToContractualDocuments should call itself recursively when quoteId cant be extracted from name', () => {
    jest.spyOn(record, 'load').mockReturnValueOnce(new RecordDynamicMock({}, {
      customer: 1,
      custrecord_subs_end_user: 1,
      subsidiary: 1,
      custrecord_contract_docs: 1,
      parentsubscription: 2
    }) as any);
    // contract docs
    jest.spyOn(record, 'load').mockReturnValueOnce(new RecordDynamicMock({}, {
      name: 'contract docs'
    }) as any);

    //parent subscription
    jest.spyOn(record, 'load').mockReturnValueOnce(new RecordDynamicMock({}, {
      customer: 1,
      custrecord_subs_end_user: 1,
      subsidiary: 1,
      custrecord_contract_docs: 1
    }) as any);
    // parent contract docs
    jest.spyOn(record, 'load').mockReturnValueOnce(new RecordDynamicMock({}, {
      name: 'Quote 1',
      id: 1
    }) as any);
    jest.spyOn(QuoteDao, 'getQuoteIdByTranId').mockReturnValueOnce(1);
    jest.spyOn(QuoteDao, 'findSignedAgreementId').mockReturnValueOnce(1);
    jest.spyOn(FileService, 'getAttachedFiles').mockReturnValueOnce([]);
    // quote
    jest.spyOn(record, 'load').mockReturnValueOnce(new RecordDynamicMock({}, {
      customform: 223 //on prem full TCs
    }) as any);
    // signed agreement
    jest.spyOn(record, 'load').mockReturnValueOnce(new RecordDynamicMock({}, {
      custrecord_echosign_signed_doc: 1
    }) as any);
    jest.spyOn(FileService, 'getUrl').mockReturnValueOnce('https://url');

    const recursiveSpy = jest.spyOn(QuoteService, 'setSignedQuotesToContractualDocuments');
    QuoteService.setSignedQuotesToContractualDocuments(1, []);
    expect(recursiveSpy).toHaveBeenCalledTimes(2);
  });

  it('setSignedQuotesToContractualDocuments should call itself recursively when contractDocs is not master', () => {
    jest.spyOn(record, 'load').mockReturnValueOnce(new RecordDynamicMock({}, {
      customer: 1,
      custrecord_subs_end_user: 1,
      subsidiary: 1,
      custrecord_contract_docs: 1
    }) as any);
    // contract docs
    jest.spyOn(record, 'load').mockReturnValueOnce(new RecordDynamicMock({}, {
      name: 'Quote 1'
    }) as any);
    jest.spyOn(QuoteDao, 'getQuoteIdByTranId').mockReturnValueOnce(1);
    jest.spyOn(QuoteDao, 'findSignedAgreementId').mockReturnValueOnce(1);
    jest.spyOn(FileService, 'getAttachedFiles').mockReturnValueOnce([]);
    // quote
    jest.spyOn(record, 'load').mockReturnValueOnce(new RecordDynamicMock({}, {
      customform: 2
    }) as any);
    // signed agreement
    jest.spyOn(record, 'load').mockReturnValueOnce(new RecordDynamicMock({}, {
      custrecord_echosign_signed_doc: 1
    }) as any);
    jest.spyOn(FileService, 'getUrl').mockReturnValueOnce('https://url');

    const recursiveSpy = jest.spyOn(QuoteService, 'setSignedQuotesToContractualDocuments');
    QuoteService.setSignedQuotesToContractualDocuments(1, []);
    expect(recursiveSpy).toHaveBeenCalledTimes(2);
  });

  it('setSignedQuotesToContractualDocuments should return contractualDocumentChanged when signed agreement is found', () => {
    jest.spyOn(record, 'load').mockReturnValueOnce(new RecordDynamicMock({}, {
      customer: 1,
      custrecord_subs_end_user: 1,
      subsidiary: 1,
      custrecord_contract_docs: 1
    }) as any);
    // contract docs
    jest.spyOn(record, 'load').mockReturnValueOnce(new RecordDynamicMock({}, {
      name: 'Quote 1',
      id: 1
    }) as any);
    jest.spyOn(QuoteDao, 'getQuoteIdByTranId').mockReturnValueOnce(1);
    jest.spyOn(QuoteDao, 'findSignedAgreementId').mockReturnValueOnce(1);
    jest.spyOn(FileService, 'getAttachedFiles').mockReturnValueOnce([]);
    // quote
    jest.spyOn(record, 'load').mockReturnValueOnce(new RecordDynamicMock({}, {
      customform: 223 //on prem full TCs
    }) as any);
    // signed agreement
    jest.spyOn(record, 'load').mockReturnValueOnce(new RecordDynamicMock({}, {
      custrecord_echosign_signed_doc: 1
    }) as any);
    jest.spyOn(FileService, 'getUrl').mockReturnValueOnce('https://url');

    const result = QuoteService.setSignedQuotesToContractualDocuments(1, []);
    expect(result.contractualDocumentIdsChanged).toEqual([1]);
    expect(result.message).toBe('Full TCs agreement signed through adobe sign found');
    expect(result.found).toBe(true);
  });

  it('setSignedQuotesToContractualDocuments should return contractualDocumentIdsChanged when file with signed word in name is found in contractual documents', () => {
    jest.spyOn(record, 'load').mockReturnValueOnce(new RecordDynamicMock({}, {
      customer: 1,
      custrecord_subs_end_user: 1,
      subsidiary: 1,
      custrecord_contract_docs: 1
    }) as any);
    // contract docs
    jest.spyOn(record, 'load').mockReturnValueOnce(new RecordDynamicMock({}, {
      name: 'Quote 1',
      id: 1
    }) as any);
    jest.spyOn(QuoteDao, 'getQuoteIdByTranId').mockReturnValueOnce(1);
    jest.spyOn(QuoteDao, 'findSignedAgreementId').mockReturnValueOnce(undefined);
    jest.spyOn(FileService, 'getAttachedFiles').mockReturnValueOnce([{
      fileId: 1,
      fileType: 'PDF',
      fileName: 'Quote 1 Signed',
      fileUrl: 'https://url'
    }]);
    // quote
    jest.spyOn(record, 'load').mockReturnValueOnce(new RecordDynamicMock({}, {
      customform: 223 //on prem full TCs
    }) as any);

    const result = QuoteService.setSignedQuotesToContractualDocuments(1, []);
    expect(result.contractualDocumentIdsChanged).toEqual([1]);
    expect(result.message).toBe('Full TCs found attached in contractual documents with signed word in it');
    expect(result.found).toBe(true);
  });

  const ESW_QUOTE_MAINT_FULL_TCS = 220;
  const ESW_QUOTE_SAAS_FULL_TCS = 221;
  const ESW_QUOTE_PS_FULL_TCS = 222;
  const ESW_QUOTE_ON_PREM_FULL_TCS = 223;
  const ENG_NEW_RESELLERS_QUOTE = 162;
  const ESW_QUOTE_RENEWAL_NO_TC_ATTACHMENTS = 219;

  it('getRevenueTypeFromFormNumber should return RevenueType.Support for ESW_QUOTE_MAINT_FULL_TCS', () => {
    expect(Object.getPrototypeOf(QuoteService).getRevenueTypeFromFormNumber(ESW_QUOTE_MAINT_FULL_TCS)).toBe(RevenueType.Support);
  });

  it('getRevenueTypeFromFormNumber should return RevenueType.SaaS for ESW_QUOTE_SAAS_FULL_TCS', () => {
    expect(Object.getPrototypeOf(QuoteService).getRevenueTypeFromFormNumber(ESW_QUOTE_SAAS_FULL_TCS)).toBe(RevenueType.SaaS);
  });

  it('getRevenueTypeFromFormNumber should return RevenueType.OnPremise for ESW_QUOTE_ON_PREM_FULL_TCS', () => {
    expect(Object.getPrototypeOf(QuoteService).getRevenueTypeFromFormNumber(ESW_QUOTE_ON_PREM_FULL_TCS)).toBe(RevenueType.OnPremise);
  });

  it('getRevenueTypeFromFormNumber should return RevenueType.ProfessionalServices for ESW_QUOTE_PS_FULL_TCS', () => {
    expect(Object.getPrototypeOf(QuoteService).getRevenueTypeFromFormNumber(ESW_QUOTE_PS_FULL_TCS)).toBe(RevenueType.ProfessionalServices);
  });

  it('getRevenueTypeFromFormNumber should return null for an unknown customFormNumber', () => {
    const unknownFormNumber = 999;
    expect(Object.getPrototypeOf(QuoteService).getRevenueTypeFromFormNumber(unknownFormNumber)).toBeNull();
  });

  it('should return "FullTCs" for full TCs quotes', () => {
    const fullTcsQuotes = [ESW_QUOTE_MAINT_FULL_TCS, ESW_QUOTE_ON_PREM_FULL_TCS, ESW_QUOTE_SAAS_FULL_TCS, ESW_QUOTE_PS_FULL_TCS];
    fullTcsQuotes.forEach(quote => {
      expect(QuoteService.getQuoteType(quote)).toBe('FullTCs');
    });
  });

  it('should return "Reseller" for new reseller quote', () => {
    expect(QuoteService.getQuoteType(ENG_NEW_RESELLERS_QUOTE)).toBe('Reseller');
  });

  it('should return "NoTCs" for renewal without TC attachments', () => {
    expect(QuoteService.getQuoteType(ESW_QUOTE_RENEWAL_NO_TC_ATTACHMENTS)).toBe('NoTCs');
  });

  it('should return "Other" for any other quotes', () => {
    const randomQuoteNotInSwitch = 100;
    expect(QuoteService.getQuoteType(randomQuoteNotInSwitch)).toBe('Other');
  });

  it('getSignedDocUrlFromQuote should return URL for signed doc if there is a signed agreement', () => {
    const signedDocumentUrl = 'test.pdf';
    jest.spyOn(QuoteDao, 'findSignedAgreementId').mockReturnValueOnce(1);
    jest.spyOn(QuoteService, 'getSignedDocUrlFromAgreement').mockReturnValueOnce(signedDocumentUrl);

    const res = QuoteService.getSignedDocUrlFromQuote(123);

    expect(res).toBe(signedDocumentUrl);
  });

  it('getSignedDocUrlFromQuote should return null if there is no signed agreement', () => {
    jest.spyOn(QuoteDao, 'findSignedAgreementId').mockReturnValueOnce(undefined);

    const res = QuoteService.getSignedDocUrlFromQuote(123);

    expect(res).toBe(null);
  });
});

describe('createEUA', () => {
  const quoteId = 123;
  const subscriptionPlanId = 456;
  const agreementId = 789;

  it('should create an EUA with maintenance TCs if subscription plan is support only', () => {
    // Arrange
    const subscriptionPlan = {
      supportOnly: true
    };
    const tcKeys = [TcKeys.EUA_Maintenance];
    jest.spyOn(QuoteRecord, 'load').mockReturnValueOnce({ subscriptionPlanId } as any);
    jest.spyOn(SubscriptionPlanUtility, 'getSubscriptionPlanById').mockReturnValueOnce(subscriptionPlan as any);
    jest.spyOn(nsutils, 'queryFirstAsMap').mockReturnValueOnce({ id: agreementId });
    jest.spyOn(nsutils, 'queryToJson').mockReturnValueOnce([
      { email: 'email1@example.com', role: 1, order: 1 },
      { email: 'email2@example.com', role: 2, order: 2 },
      { email: 'email3@example.com', role: 2, order: 3 },
    ]);
    const findLastAgreementIdByTypeSpy = jest.spyOn(QuoteDao, 'findLastAgreementIdByType');
    const findAdobeAgreementRecipientsSpy = jest.spyOn(QuoteDao, 'findAdobeAgreementRecipients');
    const createAdobeServicesAgreementSpy = jest.spyOn(QuoteService, 'createAdobeServicesAgreement').mockReturnValueOnce(1);

    // Act
    const result = QuoteService.createEUA(quoteId);

    // Assert
    expect(result).toBe(1);
    expect(findLastAgreementIdByTypeSpy).toHaveBeenCalledWith(quoteId, AgreementType.Quote);
    expect(findAdobeAgreementRecipientsSpy).toHaveBeenCalledWith(agreementId);
    expect(createAdobeServicesAgreementSpy).toHaveBeenCalledWith(quoteId, tcKeys, true, AgreementType.EndUserAcknowledgement, [
      { email: 'email1@example.com', role: 'signer' },
      { email: 'email3@example.com', role: 'cc' }
    ]);
  });

  it('should create an EUA without maintenance TCs if subscription plan is not support only', () => {
    // Arrange
    const subscriptionPlan = {
      supportOnly: false
    };
    const tcKeys = [];
    jest.spyOn(QuoteRecord, 'load').mockReturnValueOnce({ subscriptionPlanId } as any);
    jest.spyOn(SubscriptionPlanUtility, 'getSubscriptionPlanById').mockReturnValueOnce(subscriptionPlan as any);
    jest.spyOn(nsutils, 'queryFirstAsMap').mockReturnValueOnce({ id: agreementId });
    jest.spyOn(nsutils, 'queryToJson').mockReturnValueOnce([
      { email: 'email1@example.com', role: 1, order: 1 },
      { email: 'email2@example.com', role: 2, order: 2 },
      { email: 'email3@example.com', role: 2, order: 3 },
    ]);
    const findLastAgreementIdByTypeSpy = jest.spyOn(QuoteDao, 'findLastAgreementIdByType');
    const findAdobeAgreementRecipientsSpy = jest.spyOn(QuoteDao, 'findAdobeAgreementRecipients');
    const createAdobeServicesAgreementSpy = jest.spyOn(QuoteService, 'createAdobeServicesAgreement').mockReturnValueOnce(1);

    // Act
    const result = QuoteService.createEUA(quoteId);

    // Assert
    expect(result).toBe(1);
    expect(findLastAgreementIdByTypeSpy).toHaveBeenCalledWith(quoteId, AgreementType.Quote);
    expect(findAdobeAgreementRecipientsSpy).toHaveBeenCalledWith(agreementId);
    expect(createAdobeServicesAgreementSpy).toHaveBeenCalledWith(quoteId, tcKeys, true, AgreementType.EndUserAcknowledgement, [
      { email: 'email1@example.com', role: 'signer' },
      { email: 'email3@example.com', role: 'cc' }
    ]);
  });

  it('should catch and log errors while loading subscription and plan', () => {
    // Arrange
    const subscriptionPlan = {
      supportOnly: false
    };
    const error = new Error('Something went wrong');
    const tcKeys = [];
    jest.spyOn(QuoteRecord, 'load').mockReturnValueOnce({ subscriptionPlanId } as any);
    jest.spyOn(SubscriptionPlanUtility, 'getSubscriptionPlanById').mockImplementationOnce(() => {
      throw error;
    });
    jest.spyOn(nsutils, 'queryFirstAsMap').mockReturnValueOnce({ id: agreementId });
    jest.spyOn(nsutils, 'queryToJson').mockReturnValueOnce([
      { email: 'email1@example.com', role: 1, order: 1 },
      { email: 'email2@example.com', role: 2, order: 2 },
      { email: 'email3@example.com', role: 2, order: 3 },
    ]);
    const findLastAgreementIdByTypeSpy = jest.spyOn(QuoteDao, 'findLastAgreementIdByType');
    const findAdobeAgreementRecipientsSpy = jest.spyOn(QuoteDao, 'findAdobeAgreementRecipients');
    const createAdobeServicesAgreementSpy = jest.spyOn(QuoteService, 'createAdobeServicesAgreement').mockReturnValueOnce(1);
    const debugSpy = jest.spyOn(nsutils, 'logDebug');

    // Act
    const result = QuoteService.createEUA(quoteId);

    // Assert
    expect(result).toBe(1);
    expect(debugSpy).toHaveBeenCalledWith('createEUA error', `Error while loading subscription and plan for quote ${quoteId} to check if it's support to include or not the maintenance TCs to the EUA.
Error: ${error}`);
    expect(findLastAgreementIdByTypeSpy).toHaveBeenCalledWith(quoteId, AgreementType.Quote);
    expect(findAdobeAgreementRecipientsSpy).toHaveBeenCalledWith(agreementId);
    expect(createAdobeServicesAgreementSpy).toHaveBeenCalledWith(quoteId, tcKeys, true, AgreementType.EndUserAcknowledgement, [
      { email: 'email1@example.com', role: 'signer' },
      { email: 'email3@example.com', role: 'cc' }
    ]);
  });
});