import subscriptionCreateUtility from '../../src/ts/utility/SubscriptionCreateUtility';
import * as nsutils from '../../src/ts/nsutils';
import subscriptionDao from '../../src/ts/dao/SubscriptionDao';
import * as query from 'N/query';
import ClassDao from '../../src/ts/dao/ClassDao';

describe('BillingAccountDao', () => {
  beforeEach(() => {
    jest.restoreAllMocks();

    jest.spyOn(nsutils, 'queryToJson');
    jest.spyOn(nsutils, 'queryFirstToJson');
    jest.spyOn(nsutils, 'queryFirstAsMap');
  });

  it('findSuitableSubsidiary', () => {
    jest.spyOn(ClassDao,'getSubsidiaries').mockReturnValue({
      domestic: 1,
      german: 2,
      japan: 3,
      other: 4
    });
    jest.spyOn(nsutils, 'queryFirstToJson').mockReturnValueOnce({subsidiary: 10});
    expect(subscriptionCreateUtility.findSuitableSubsidiary('1', 1)).toEqual(10);

    jest.spyOn(nsutils, 'queryFirstToJson').mockReturnValueOnce(undefined);
    jest.spyOn(nsutils, 'queryFirstToJson').mockReturnValueOnce({ country: 'US', addr1: '' });
    expect(subscriptionCreateUtility.findSuitableSubsidiary('1', 1)).toEqual(1);

    jest.spyOn(nsutils, 'queryFirstToJson').mockReturnValueOnce(undefined);
    jest.spyOn(nsutils, 'queryFirstToJson').mockReturnValueOnce({ country: 'AE', addr1: '' });
    expect(subscriptionCreateUtility.findSuitableSubsidiary('1', 1)).toEqual(1);

    jest.spyOn(nsutils, 'queryFirstToJson').mockReturnValueOnce(undefined);
    jest.spyOn(nsutils, 'queryFirstToJson').mockReturnValueOnce({ country: 'AE', addr1: 'any free zone' });
    expect(subscriptionCreateUtility.findSuitableSubsidiary('1', 1)).toEqual(4);

    jest.spyOn(nsutils, 'queryFirstToJson').mockReturnValueOnce(undefined);
    jest.spyOn(nsutils, 'queryFirstToJson').mockReturnValueOnce({ country: 'DE', addr1: '' });
    expect(subscriptionCreateUtility.findSuitableSubsidiary('1', 1)).toEqual(2);

    jest.spyOn(nsutils, 'queryFirstToJson').mockReturnValueOnce(undefined);
    jest.spyOn(nsutils, 'queryFirstToJson').mockReturnValueOnce({ country: 'AT', addr1: '' });
    expect(subscriptionCreateUtility.findSuitableSubsidiary('1', 1)).toEqual(2);

    jest.spyOn(nsutils, 'queryFirstToJson').mockReturnValueOnce(undefined);
    jest.spyOn(nsutils, 'queryFirstToJson').mockReturnValueOnce({ country: 'JP', addr1: '' });
    expect(subscriptionCreateUtility.findSuitableSubsidiary('1', 1)).toEqual(3);

    jest.spyOn(nsutils, 'queryFirstToJson').mockReturnValueOnce(undefined);
    jest.spyOn(nsutils, 'queryFirstToJson').mockReturnValueOnce({ country: 'BR', addr1: '' });
    expect(subscriptionCreateUtility.findSuitableSubsidiary('1', 1)).toEqual(4);
  });

  it('findSuitableSubsidiary german and japan not set', () => {
    jest.spyOn(ClassDao,'getSubsidiaries').mockReturnValue({
      domestic: 1,
      german: null,
      japan: null,
      other: 4
    });

    jest.spyOn(nsutils, 'queryFirstToJson').mockReturnValueOnce(undefined);
    jest.spyOn(nsutils, 'queryFirstToJson').mockReturnValueOnce({ country: 'DE', addr1: '' });
    expect(subscriptionCreateUtility.findSuitableSubsidiary('1', 1, 5)).toEqual(4);

    jest.spyOn(nsutils, 'queryFirstToJson').mockReturnValueOnce(undefined);
    jest.spyOn(nsutils, 'queryFirstToJson').mockReturnValueOnce({ country: 'AT', addr1: '' });
    expect(subscriptionCreateUtility.findSuitableSubsidiary('1', 1, 5)).toEqual(4);

    jest.spyOn(nsutils, 'queryFirstToJson').mockReturnValueOnce(undefined);
    jest.spyOn(nsutils, 'queryFirstToJson').mockReturnValueOnce({ country: 'JP', addr1: '' });
    expect(subscriptionCreateUtility.findSuitableSubsidiary('1', 1, 5)).toEqual(4);
  });

  it('findSuitableSubsidiary not found', () => {
    jest.spyOn(ClassDao,'getSubsidiaries').mockReturnValue({
      domestic: null,
      german: null,
      japan: null,
      other: null
    });
    
    jest.spyOn(nsutils, 'queryFirstToJson').mockReturnValueOnce(undefined);
    jest.spyOn(nsutils, 'queryFirstToJson').mockReturnValueOnce({ country: 'BR', addr1: '' });
    expect(() => subscriptionCreateUtility.findSuitableSubsidiary('1',1,5)).toThrowError('Unable to find suitable subsidiary');

    jest.spyOn(nsutils, 'queryFirstToJson').mockReturnValueOnce(undefined);
    jest.spyOn(nsutils, 'queryFirstToJson').mockReturnValueOnce({ country: 'US', addr1: '' });
    expect(() => subscriptionCreateUtility.findSuitableSubsidiary('1',1)).toThrowError('Unable to find suitable subsidiary');
  });

  it('findSuitableSubsidiary get from parent', () => {
    jest.spyOn(query,'runSuiteQL').mockReturnValueOnce({ 
      results: [{ asMap: ()=>({
        domestic: null,
        german: null,
        japan: null,
        other: null
      })}]
    } as any);
    jest.spyOn(nsutils, 'queryFirstToJson').mockReturnValueOnce(undefined);
    jest.spyOn(nsutils, 'queryFirstToJson').mockReturnValueOnce({ country: 'BR', addr1: '' });
    jest.spyOn(subscriptionDao,'findSubsidiaryId').mockReturnValueOnce(5)
    expect(subscriptionCreateUtility.findSuitableSubsidiary('1',1,1)).toEqual(5);
  });
});
