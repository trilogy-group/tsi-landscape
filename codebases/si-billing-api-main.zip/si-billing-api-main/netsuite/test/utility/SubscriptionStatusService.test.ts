import { SubscriptionLineStatus, SubscriptionStatus } from '../../src/ts/types';
import SubscriptionStatusService from '../../src/ts/utility/SubscriptionStatusService';
import { SubscriptionRecordMock } from '../mocks/SubscriptionRecordMock';

describe('SubscriptionStatusService', () => {
  it('activate', () => {
    const sr = new SubscriptionRecordMock(
      {
        endUser: 1,
        status: SubscriptionStatus.DRAFT,
        contractDocs: 1,
      },
      [{ included: true, status: SubscriptionLineStatus.DRAFT }]
    ) as any;
    SubscriptionStatusService.activate(sr);
  });
});
