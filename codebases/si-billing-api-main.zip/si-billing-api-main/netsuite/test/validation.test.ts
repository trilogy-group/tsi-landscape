import { assertNotNull, assertNotNullMsg, isNotBlank, isNotNull, must, ValidationError } from "../src/ts/validation"

describe('validation', () => {
  it('isNotNull', () => {
    expect(isNotNull(null)).toBeFalsy()
    expect(isNotNull(undefined)).toBeFalsy()
    expect(isNotNull("")).toBeTruthy()
  })

  it('isNotBlank', () => {
    expect(isNotBlank(null)).toBeFalsy()
    expect(isNotBlank(undefined)).toBeFalsy()
    expect(isNotBlank("")).toBeFalsy()
    expect(isNotBlank("   ")).toBeFalsy()
    expect(isNotBlank("  . ")).toBeTruthy()
  })

  it('assertNotNull', () => {
    expect(() => {
      assertNotNull(null, 'testfield')
    }).toThrowError('testfield is mandatory')
    expect(() => {
      assertNotNull(undefined, 'testfield')
    }).toThrowError('testfield is mandatory')
    expect(() => {
      assertNotNull(null)
    }).toThrowError('value is mandatory')
    assertNotNull("")
  })

  it('assertNotNullMsg', () => {
    expect(() => {
      assertNotNullMsg(null, 'error message')
    }).toThrowError('error message')
    expect(() => {
      assertNotNullMsg(undefined, 'error message')
    }).toThrowError('error message')
    assertNotNullMsg("", "error message")
  })

  it('must', () => {
    expect(() => {
      must(null, 'testfield')
    }).toThrowError('testfield is mandatory')
    expect(() => {
      must(undefined, 'testfield')
    }).toThrowError('testfield is mandatory')
    expect(() => {
      must(null)
    }).toThrowError('value is mandatory')
    expect(must("123")).toStrictEqual("123")
  })

  it('ValidationError', () => {
    const err = new ValidationError('testmsg', 'testfield');
    expect(err.fieldName).toStrictEqual('testfield')
  })
})
