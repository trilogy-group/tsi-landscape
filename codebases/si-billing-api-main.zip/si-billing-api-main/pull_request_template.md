### Jira LAMBDA Ticket ID:
[LAMBDA-](https://rapid-engineering.atlassian.net/browse/LAMBDA-)
### Description
{general description placeholder}
#### Changes
 1. {Short change description - what was done} - {Reference on the part of the requirements implemented by this change}
#### Not implemented requirements
 1. {Reference on the part of the requirements was impossible to implement} - {Reasons}
#### How to test
{how to test placeholder}
#### Manual deployment steps
{manual deployment steps placeholder}
#### Improvement notes
{improvement notes placeholder}