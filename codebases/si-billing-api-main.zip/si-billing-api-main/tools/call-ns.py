#
# Netsuite restlet or REST api requester
# Dependencies:  python 3.x, oauth2
#

import oauth2 as oauth
import json
import requests
import time
import argparse
import configparser
import sys

#nsRestletBaseUrl="https://4914352-sb5.restlets.api.netsuite.com"
#restletParams="script=customscript_tsi_subscription_restlet&deploy=customdeploy_tsi_subscription&subscriptionId=434283"
#url = nsRestletBaseUrl + "/app/site/hosting/restlet.nl?" + restletParams


#http_method = "GET"
#realm = "4914352_SB5"

def eprint(*args, **kwargs):
    print(*args, file=sys.stderr, **kwargs)

#req = oauth.Request(method=http_method, url=url, parameters=params)
#signature_method = oauth.SignatureMethod_HMAC_SHA1()
#req.sign_request(signature_method, consumer, token)
#header = req.to_header(realm)
#print(header['Authorization'])
#headery = header['Authorization'].encode('ascii', 'ignore')
#headerx = {"Authorization": headery, "Content-Type": "application/json"}
#print(headerx)
##payload = {"operation": "moveFile", "id": "1450"}
#conn = requests.get(url, headers=headerx)
#print("\n\nResult: " + conn.text)
#print("\n\n\n")
#print(conn.headers)
#token = oauth.Token(key="e3d3d069869e8794aa69029dde3b493326b62469281b3beee5037fec8be6895b",
#                    secret="90f1e90924bd803c5918d10969b20232e258b37e4ceb715f144bb7891c03a007")
#    consumer = oauth.Consumer(key="353ff94822434d35770610e35c29dc1508bf178a871b844096bce0582e329ba2",
#                            secret="3a494457da1a7960b183996de3680ba07aa108205ff05016de0f5780a44b3231")
def getOAuth1Header(config, method, url):
    token = oauth.Token(key=config['tokenKey'],
                    secret=config['tokenSecret'])
    consumer = oauth.Consumer(key=config['consumerKey'],
                            secret=config['consumerSecret'])

    params = {
        'oauth_version': "1.0",
        'oauth_nonce': oauth.generate_nonce(),
        'oauth_timestamp': str(int(time.time())),
        'oauth_token': token.key,
        'oauth_consumer_key': consumer.key
    }                        
    req = oauth.Request(method=method, url=url, parameters=params)
    signature_method = oauth.SignatureMethod_HMAC_SHA1()
    req.sign_request(signature_method, consumer, token)
    header = req.to_header(config['realm'])
    return header['Authorization'].encode('ascii', 'ignore')


def doRequest(config, method, headers, data, infile, url, verbosity):
    confparser = configparser.ConfigParser()
    confparser.read(config)
    
    oauthConfig = confparser['oauth1']
    if verbosity > 0:
        for key in oauthConfig:
            eprint(key + "=" + oauthConfig[key])

    finalHeaders = {'Content-Type': 'application/json', 'Authorization': getOAuth1Header(oauthConfig, method, url)}
    for v in headers:
         finalHeaders[v.split('=', 1)[0]] = v.split('=', 1)[1]
    if verbosity > 0:
        eprint(finalHeaders)

    if infile is not None:
        if infile == '-':
            data = sys.stdin.read()
        else:
            with open(infile) as f:
                data = f.read()
    conn = None
    if method == 'GET':
        conn = requests.get(url, headers=finalHeaders)
    elif method == 'PUT':
        conn = requests.put(url, headers=finalHeaders, data=data)
    elif method == 'POST':
        conn = requests.post(url, headers=finalHeaders, data=data)
    elif method == 'DELETE':
        conn = requests.delete(url, headers=finalHeaders)
    else:
        raise "Not supported http method " + method
    print(conn.text)
    if verbosity > 0:
        eprint(conn.headers)


def doPost(beta, gamma):
    print('task b', beta, gamma)


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--conf', dest='config', help='OAUTH1 config file')
    parser.add_argument('-m', dest='method', help='HTTP method', default='GET', choices=['GET', 'POST', 'PUT', 'DELETE'])
    parser.add_argument('-H', dest='headers', action='append', help='HTTP header', default=[])
    parser.add_argument('-d', dest='data', help='HTTP request data')
    parser.add_argument('-i', dest='infile', help='Read body data from file. - for stdin')
    parser.add_argument("-v", "--verbosity", action="count",
                    help="Increase output verbosity", default=0)
    parser.add_argument('url', metavar='URL', help='URL')
    
    kwargs = vars(parser.parse_args())
    doRequest(**kwargs)
