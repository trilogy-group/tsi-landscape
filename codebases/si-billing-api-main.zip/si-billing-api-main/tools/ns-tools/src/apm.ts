import fetch from 'node-fetch';
import { format, write } from '@fast-csv/format';
import curlconverter from 'curlconverter'

const defaultHeaders = {
  "accept": "application/json, text/javascript, */*; q=0.01",
  "accept-language": "en,ru;q=0.9,en-US;q=0.8",
  "sec-ch-ua": "\"Google Chrome\";v=\"93\", \" Not;A Brand\";v=\"99\", \"Chromium\";v=\"93\"",
  "sec-ch-ua-mobile": "?0",
  "sec-ch-ua-platform": "\"Linux\"",
  "sec-fetch-dest": "empty",
  "sec-fetch-mode": "cors",
  "sec-fetch-site": "same-origin",
  "x-requested-with": "XMLHttpRequest",
};

const resultCsvHeaders = ["id","name","executionTime", "type", "operation", "recordType", "scriptType", 
"triggerType", "searches", "customRecordOperations", "apiCalls",
"lowMS","highMS",
"startDateMS","endDateMS","date","parentId",
"email",
"recordType","appType","method","context",
"scriptId","customScriptId","deployment","deploymentId",
"deploymentUrl","entryPoint","bundle","workflowId",
"searchId","wsOperation","apiVersion","viewCalls","url",
"nameUrl","hasChildren","workflows","requestUrls", "hierarchy"]

interface CurlParams {
  url: string;
  raw_url: string;
  method: string;
  headers: Record<string, string>;
  queries: Record<string, string>;
}

export async function fetchNsPfData(nsConf: {
  url: string;
  cookie: string;
}, operationId: string, parentId?: string) {
  const url = `${nsConf.url}?script=customscript_nsapm_prf_sl_frhtlogs_v2&deploy=customdeploy_nsapm_prf_sl_frhtlogs_v2&testmode=F&operationId=${operationId}${parentId ? ("&parentId="+parentId) : ""}&frhtId=&compfil=4914352_SB1&drillDown=true`;
  const res = await fetch(url, {
    headers: {...defaultHeaders, cookie: nsConf.cookie},
    "body": null,
    "method": "GET",
  });
  
  if (res.status !== 200) {
    throw new Error(`Failed to fetch, status = ${res.status}`)
  }
  const bodyText = await res.text();
  let body;
  try {
     body = JSON.parse(bodyText);
  } catch(e) {
    throw new Error(`Request failed: status=${res.status} body='${bodyText}'`);
  }
  return body.data;
}

export async function writeTreeFromCurl(curlCmd: string[]) {
  const curCmdText = "'" + curlCmd.join("' '") + "'";
  const curlParams : CurlParams = JSON.parse(curlconverter.toJsonString(curCmdText));

  const nsConf = {url: curlParams.url, cookie: curlParams.headers.cookie};
  
  const csvStream = format({ headers: resultCsvHeaders, quoteColumns: true });
  csvStream.pipe(process.stdout);
  await writeStats(nsConf, 0, curlParams.queries.parentId, curlParams.queries.operationId, csvStream);
  csvStream.end();
}

function rowToCsv(indentation, row) {
  return {...row, id: "-".repeat(indentation) + row.id, apiCalls: JSON.stringify(row.apiCalls)};
}

async function writeStats(nsConf, indentation, parentId, operationId, stream) {
  //const url = `https://4914352-sb1.app.netsuite.com/app/site/hosting/scriptlet.nl?script=customscript_nsapm_prf_sl_frhtlogs_v2&deploy=customdeploy_nsapm_prf_sl_frhtlogs_v2&testmode=F&operationId=a1a2517e-63a1-46b7-b266-32fbc3231d4a&parentId=487e4150-2f30-4873-a33b-441d98a921dc&frhtId=&compfil=4914352_SB1&drillDown=true`
  //const kpiLoadUrl = `https://4914352-sb1.app.netsuite.com/app/site/hosting/scriptlet.nl?script=customscript_nsapm_prf_sl_kpi_v2&deploy=customdeploy_nsapm_prf_sl_kpi_v2&testmode=F&operationId=${operationId}${parentId ? ("&parentId="+parentId) : ""}&frhtId=&compfil=4914352_SB1&drillDown=true`;

  const url = `https://4914352-sb1.app.netsuite.com/app/site/hosting/scriptlet.nl?script=customscript_nsapm_prf_sl_frhtlogs_v2&deploy=customdeploy_nsapm_prf_sl_frhtlogs_v2&testmode=F&operationId=${operationId}${parentId ? ("&parentId="+parentId) : ""}&frhtId=&compfil=4914352_SB1&drillDown=true`;
  
  const rows = await fetchNsPfData(nsConf, operationId, parentId);
  for(const row of rows) {
    stream.write(rowToCsv(indentation, row));
    await writeStats(nsConf, indentation + 1, row.id, operationId, stream);
  }
}
//import curlconverter from 'curlconverter'
//console.log("'" + process.argv.slice(2).join("' '") + "'")
//console.log(curlconverter.toJsonString("'" + process.argv.slice(2).join("' '") + "'"))
//showTree("2640e0cf-93f3-4d5b-bdd1-51bea209fd07")