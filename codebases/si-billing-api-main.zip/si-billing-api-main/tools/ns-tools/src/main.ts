import { program } from 'commander'
import { writeTreeFromCurl } from './apm';

program.version(require('../package.json').version)
program.description(`Different NetSuite tools`)

program
.command('apmTree <curl_cmd...>')
.description(`Generate tree from NS APM root entry curl command. 
  Curl command because it needs your cookies and some other parameters so it simpler to copy as curl in Chrome DevTools`)
.action(function (curl_cmd: string[]) {
  writeTreeFromCurl(curl_cmd);
})

program.parseAsync().catch(e => {
  console.error(e.message || e)
  process.exit(1)
});