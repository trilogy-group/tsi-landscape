import { TestEnvironment } from 'jest-environment-node';

/**
 * Represents the pre-defined status of a test.
 */
export type TestStatus = 'pending' | 'running' | 'passed' | 'failed';

/**
 * Represents the mapping between event name and test status.
 */
const testStatusByEventName: Record<string, TestStatus> = {
  'test_fn_start': 'running',
  'test_fn_success': 'passed',
  'test_fn_failure': 'failed',
};

/**
 * Is the E2E test environment, extending the default test environment from Jest library.
 */
class E2eTestEnvironment extends TestEnvironment {

  async setup() {
    await super.setup();

    // Set the test status to 'pending'.
    this.global.testStatus = 'pending';
  }

  async handleTestEvent(event, _state) {

    // If the event name is related to test lifecycle, set the test status.
    if (event.name.startsWith('test_') && Object.keys(testStatusByEventName).includes(event.name)) {
      this.global.testStatus = testStatusByEventName[event.name];
    }
  }
}

module.exports = E2eTestEnvironment;
