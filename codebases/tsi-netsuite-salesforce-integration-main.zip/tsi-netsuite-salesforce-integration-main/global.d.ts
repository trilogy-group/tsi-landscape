import { TestStatus } from "./E2eTestEnvironment";

export {};

declare global {

    // The test status in the current run.
    var testStatus: TestStatus;
}
