// 2.0
define(["N/log", "N/https", "N/runtime"], function (log, https, runtime) {
  /**
   * User Event 2.0 example showing usage of the Submit events
   *
   * @NApiVersion 2.x
   * @NModuleScope SameAccount
   * @NScriptType UserEventScript
   * @appliedtorecord employee
   */
  var exports = {};
  var apiURLs = [
    "https://c015f98b-041b-4e46-8849-41f2d4fce349.trayapp.io", // Prod
    "https://fd9ee0a0-5d1e-44c5-892b-6e85e1bdf11a.trayapp.io"  // Full
  ];
  var token =
    "eyJhbGciOiJIUzI1........................................................................................................................JV_adQssw5c";

  function afterSubmit(scriptContext) {
    if (scriptContext.type === 'xedit') {
      return;
    }
    for (const apiURL of apiURLs) {
      triggerFlow(scriptContext, apiURL);
      log.debug(`Tray.io flow triggered for url=${apiURL}, record type=${JSON.stringify(scriptContext.newRecord.type)}`);
    }
  }

  function triggerFlow(scriptContext, apiURL) {
    var postData = {
      scriptContext: scriptContext,
      currentUser: runtime.getCurrentUser()
    };
    var postDataString = JSON.stringify(postData);
    var header = [];
    header["Content-Type"] = "application/json";
    header["x-Csrf-Token"] = token;

    try {
      https.post({
        url: apiURL,
        headers: header,
        body: postDataString,
      });
    } catch (postErr) {
      log.error("ERROR", JSON.stringify(postErr));
    }
  }

  exports.afterSubmit = afterSubmit;
  return exports;
});
