import axios, { AxiosInstance, AxiosStatic } from "axios";
import axiosRetry from "axios-retry";
import { ExponentialBackoff, handleType, Policy, retry, RetryPolicy } from "cockatiel";
import { log } from "../utils/utils";

export const RETRY_ATTEMPTS = 10;
export const RETRY_INITIAL_DELAY = 1000;
export const RETRY_MAX_DELAY = 10000;
export const RETRY_EXPONANTIAL_BASIS = 2;

export abstract class ApiClient {
    protected readonly axiosWithRetry: AxiosInstance;
    protected readonly axiosWithoutRetry: AxiosStatic;
    protected readonly retryPolicy: RetryPolicy;

    constructor(enablesRetryMechanism = true) {

        // Provide the axios static (no retry mechanism) and an axios instance for which a retry policy if set (retry mechanism).
        this.axiosWithoutRetry = axios;
        this.axiosWithRetry = axios.create();
        if (enablesRetryMechanism) {
            this.setDefaultAxiosRetryPolicy(this.axiosWithRetry);
        }

        // Define the retry policy.
        this.retryPolicy = this.getDefaultRetryPolicy(enablesRetryMechanism);
    }

    /**
     * Returns the default retry policy.
     * @param {boolean} enablesRetryMechanism
     * @returns {RetryPolicy}
     */
    private getDefaultRetryPolicy(enablesRetryMechanism: boolean): RetryPolicy {

        // Define the policy handling all/none errors based on given flag and logging the retry details.
        let retryCount = 1;
        const policy = enablesRetryMechanism
            ? handleType(Error, (error) => {
                log(`- retry count: ${retryCount}, error: ${JSON.stringify(error)}`);
                retryCount++;
                return true;
            })
            : new Policy({
                errorFilter: (_error) => false,
                resultFilter: (_result) => false,
            });

        // Define the retry policy options.
        const retryPolicyOptions = {
            maxAttempts: RETRY_ATTEMPTS - 1,
            backoff: new ExponentialBackoff({
                initialDelay: RETRY_INITIAL_DELAY,
                maxDelay: RETRY_MAX_DELAY,
            })
        };

        // Define the retry policy.
        return retry(policy, retryPolicyOptions);
    }

    /**
     * Sets the default retry policy for the given Axios instance.
     * @param {AxiosInstance} instance
     */
    private setDefaultAxiosRetryPolicy(instance: AxiosInstance) {
        axiosRetry(instance, {
            onRetry: (retryCount, error, _requestConfig) => {
                log(
                    `- retry count: ${retryCount}, error: ${JSON.stringify(error)}, response: ${JSON.stringify(error?.response?.data)}`
                )
            },
            retries: RETRY_ATTEMPTS,
            retryCondition: (_error) => true,
            retryDelay: (retryCount, _error) => Math.min((RETRY_EXPONANTIAL_BASIS ** retryCount) * RETRY_INITIAL_DELAY, RETRY_MAX_DELAY),
            shouldResetTimeout: true,
        });
    }
}
