import { AxiosError } from 'axios';
import CryptoJS from 'crypto-js';
import NsApi from 'netsuite-rest';
import xml2js from 'xml2js';
import got, { HTTPError } from 'got';
import { Any, assertNotNullEnvVar, assertNotNullMsg, HttpStatusCode, must, SoapRequestError } from '../utils/types';
import { getPartAfterLast, getRestResourceIdOrDefaultAsNumber, logError, logRecord, throwsIfTrue, toDescriptionString } from '../utils/utils';
import {
  FilterResponse,
  NsAgreementDocRec,
  NsAgreementRecipientRec,
  NsProductIntegration,
  NsQuoteRec,
  NsSubscriptionChangeOrderRec,
  QueryResults,
  SubscriptionRec,
  NsSubscriptionChangeOrderActionId,
  NsSubStatusChangeReason,
  NsSubLineElementStatusId,
  SubscriptionLine,
  NsSubscriptionStatusId,
  NsQuoteLineRec
} from '../api_contracts/ns_api_contracts';
import { ApiClient } from './api_client';

export type NSRecord = Record<string, unknown> & { id: string };

const SHOULD_NOT_BE_NULL_HERE = 'should be not null here';

export type Config = {
  client: string;
  clientSecret: string;
  token: string;
  tokenSecret: string;
  realm: string;
};

const REST_SUITEQL_DEFAULT_LIMIT = 1000;

type SoapAction = 'add' | 'attach' | 'get' | 'update' | 'delete';
const SOAP_VERSION = '2022_1';
const SOAP_NONCE_LENGTH = 10;
const SOAP_TIMESTAMP_LENGTH = 10;

export class XmlNamespace {
  static ACCOUNTING = `urn:accounting_${SOAP_VERSION}.lists.webservices.netsuite.com`;
  static CORE = `urn:core_${SOAP_VERSION}.platform.webservices.netsuite.com`;
  static MESSAGES = `urn:messages_${SOAP_VERSION}.platform.webservices.netsuite.com`;
}

export class SoapCountry {
  static CANADA = '_canada';
  static UNITED_STATES = '_unitedStates';
}

export const EverestClassId = 92;
export const DefaultContractualDocumentId = 2;

export const USDCurrencyId = 1;
export const AnnuallBillingScheduleId = 154;
export const SalesDepartmentId = 2;
export const AnnuallTermId = 1;

const PrimaryContactRoleId = -10;

export enum RevenueType {
  Hosted = 1,
  OnPremise = 2,
  SaaS = 3,
  ProfessionalServices = 5,
  Support = 8
}

class NsApiPath {
  public static Customer = 'record/v1/customer';
  public static Contact = 'record/v1/contact';
  public static ContractualDocument = 'record/v1/CUSTOMRECORD697';
  public static SubscriptionChangeOrder = 'record/v1/subscriptionchangeorder';
}

export class NsRecordTypes {
  public static AvaSubsidiary = 'customrecord_avasubsidiaries';
  public static Class = 'classification';
  public static Customer = 'customer';
  public static Contact = 'contact';
  public static DefaultCustomerSubsidiary = 'customrecord_default_customer_subsidiary';
  public static Employee = 'employee';
  public static Item = 'item';
  public static NonInventorySaleItem = 'noninventorysaleitem';
  public static PriceBook = 'pricebook';
  public static SignedTCs = 'customrecord_signed_tcs';
  public static Subscription = 'subscription';
  public static SubscriptionChangeOrder = 'subscriptionChangeOrder';
  public static SubscriptionPlan = 'subscriptionplan';
  public static Subsidiary = 'subsidiary';
}

const monthNames = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

/**
 * Gets date in NetSuite format
 *
 * @export
 * @param {Date} date
 * @return {*}  {string} date in NetSuite format
 */
export function getNsDate(date: Date): string {
  return `${date.getDate()}-${monthNames[date.getMonth()]}-${date.getFullYear()}`;
}

const nsDatePartsCount = 3;
const nsDateYearIndex = 2;
const nsDateMonthIndex = 1;
const nsDateDayIndex = 0;
/**
 * Parses NetSuite date.
 * @param {string} dateStr - date string in NetSuite format - 11-Jun-2023.
 */
export function tryParseNsDate(dateStr: string | undefined): Date | undefined {
  if (dateStr) {
    const parts = dateStr.split('-');
    if (parts.length === nsDatePartsCount) {
      return new Date(
        Date.UTC(
          parseInt(parts[nsDateYearIndex]),
          monthNames.indexOf(parts[nsDateMonthIndex]),
          parseInt(parts[nsDateDayIndex])
        )
      );
    }
  }
  return undefined;
}

/**
 * NetSuite REST API query helper.
 * The configuration details are given by the NS* keys in config.json.
 */
export class NsApiClient extends ApiClient {
  api: typeof NsApi;
  soapUrl: string;

  constructor(enablesRetryMechanism = true) {
    super(enablesRetryMechanism);
    assertNotNullEnvVar(process.env.NS_Client, 'NS_Client');
    assertNotNullEnvVar(process.env.NS_ClientSecret, 'NS_ClientSecret');
    assertNotNullEnvVar(process.env.NS_Token, 'NS_Token');
    assertNotNullEnvVar(process.env.NS_TokenSecret, 'NS_TokenSecret');
    assertNotNullEnvVar(process.env.NS_Realm, 'NS_Realm');
    this.api = new NsApi({
      consumer_key: process.env.NS_Client,
      consumer_secret_key: process.env.NS_ClientSecret,
      token: process.env.NS_Token,
      token_secret: process.env.NS_TokenSecret,
      realm: process.env.NS_Realm,
    });
    this.soapUrl = `https://`
      + `${this.api.realm.toLowerCase().replace("_", "-")}.suitetalk.api.netsuite.com`
      + `/services/NetSuitePort_${SOAP_VERSION}`;
  }

  /**
   * Returns an object with only related fields to log.
   * @param {Any} record
   * @returns {Any}
   */
  private getFieldsToLog(record: Any): Any {

    // Keep only expected properties as log data.
    const logData = (
      ({ companyName, firstName, itemid, lastName }) => ({ companyName, firstName, itemid, lastName })
    )(record);

    // Remove all undefined properties before to return the log data.
    Object.keys(logData).forEach(key => logData[key] === undefined ? delete logData[key] : {});
    return logData;
  }

  /**
   * Run NS Rest API request.
   * @param url api url
   * @param method HTTP method
   * @param body request body
   * @returns items in the responses
   */
  request(url: string, method: string, body?: string, expectedResponse?: number): Promise<Any> {
    const req = {
      url: url,
      data: {
        path: url,
        method: method,
        body: body,
      },
    };

    return this.retryPolicy.execute(async () => this.api.request(req.data)
      .then((response: Any) => {
        throwsIfTrue(response === undefined, `The response is undefined.`);
        if (expectedResponse) {
          throwsIfTrue(response.statusCode !== expectedResponse, `The status code is ${response.statusCode}, expecting ${expectedResponse}.`);
        }
        return response;
      })
      .catch((error) => {
        if (expectedResponse === error?.response.statusCode) {
          return error.response;
        }

        if (error instanceof HTTPError) {
          Error.captureStackTrace(error);

          logError(
            `NetSuite request failed. `
            + `Response status: ${error?.response.statusCode} ${error?.response.statusMessage}, `
            + `Body: ${error?.response.body}, `
            + `Stack: ${error.stack}`
          );
        }
        throw error;
      })
    );
  }

  /**
   * Creates a record of the given type and returns the ID.
   * Failed if a record cannot be created.
   * @param {string} type
   * @param {Any} record
   * @returns {Promise<number>}
   */
  public async createRecordAsync(type: string, record: Any): Promise<number> {

    // Send POST request with record data.
    const response = await this.request(`record/v1/${type}`, 'POST', JSON.stringify(record), HttpStatusCode.NoContent);

    // Extract the record ID from the header and return it.
    const recordId = must(getRestResourceIdOrDefaultAsNumber(response.rawHeaders));
    logRecord('NS', type, { id: recordId, ...this.getFieldsToLog(record) }, 'CREATED');
    return must(recordId);
  }

  /**
   * Returns the record ID matching the given type and query; else, returns null.
   * At most one record match is expected.
   * @param {string} type
   * @param {string} queryConditions
   * @returns {Promise<number | null>}
   */
  public async readRecordIdAsync(type: string, queryConditions: string): Promise<number | null> {

    // Search a record matching the given type and query.
    const result = await this.queryWithSuiteQL<{ id: number }>(`SELECT id FROM ${type} WHERE ${queryConditions}`);

    // If there is a match, return the record ID; else, return null.
    if (result.count > 0) {
      throwsIfTrue(result.count !== 1, `There are ${result.count} matching records, expecting 1.`);
      return +result.items[0].id;
    }
    return null;
  }

  /**
   * Updates a record of the given type and ID.
   * @param {string} type
   * @param {number} id
   * @param {Any} record
   */
  public async updateRecordAsync(type: string, id: number, record: Any): Promise<void> {

    // Send Patch request with record data.
    await this.request(`record/v1/${type}/${id}`, 'PATCH', JSON.stringify(record), HttpStatusCode.NoContent);
    logRecord('NS', type, { id: id }, 'UPDATED');
  }

  /**
   * Deletes a record for the given type and ID.
   * @param {string} type
   * @param {number} id
   */
  public async deleteRecordAsync(type: string, id: number): Promise<void> {
    await this.request(`record/v1/${type}/${id}`, 'DELETE', undefined, HttpStatusCode.NoContent);
    logRecord('NS', type, { id: id }, 'DELETED');
  }

  /**
   * Sends the SOAP request for the given action and request, then returns the action response.
   * @param {SoapAction} action
   * @param {Any} request
   * @returns {Promise<Any>}
   */
  private async soapRequestAsync(
    action: SoapAction,
    request: Any
  ): Promise<Any> {

    // Send the POST request to SOAP URL with data, then return the action response.
    // Include the content extraction from the response in the retry mechanism, because the error might be included in the body within a success response.
    return this.retryPolicy.execute(async () => await this.axiosWithoutRetry
      .post(this.soapUrl, this.getSoapRequestData(action, request), {
        headers: {
          'Content-Type': 'text/xml; charset=utf-8',
          'SOAPAction': action
        }
      })
      .then(async (xmlResponse) => await this.getSoapActionResponseAsync(action, xmlResponse))
    ).catch((error) => {
      if (error instanceof AxiosError) {
        Error.captureStackTrace(error);
        logError(`NetSuite request failed. `
          + `Response status: ${error?.response?.status} ${error?.response?.statusText}, `
          + `Body: ${toDescriptionString(error?.response?.data)}, `
          + `Stack: ${error.stack}`
        );
      }
      throw error;
    });
  }

  /**
   * Returns the SOAP request data for the given action and request.
   * @param {SoapAction} action
   * @param {Any} request
   * @returns {Any}
   */
  private getSoapRequestData(action: SoapAction, request: Any): string {

    // Build the body based on the given action and request.
    const body = {};
    body[action] = request;
    body[action]['$'] = {
      'xmlns': XmlNamespace.MESSAGES
    };

    // Build the envelope including the default header and the given action and request.
    const envelope = {
      'soapenv:Envelope': {
        $: {
          'xmlns:soapenv': 'http://schemas.xmlsoap.org/soap/envelope/',
          'xmlns:xsd': 'http://www.w3.org/2001/XMLSchema',
          'xmlns:xsi': 'http://www.w3.org/2001/XMLSchema-instance'
        },
        'soapenv:Header': this.getSoapEnvelopeHeader(),
        'soapenv:Body': body
      }
    };

    // Serialize the envelope to XML.
    const xmlBuilder = new xml2js.Builder({
      renderOpts: {
        pretty: false
      }
    });
    return xmlBuilder.buildObject(envelope);
  }

  /**
   * Returns the envelope header for a SOAP request, including the token passport.
   * @returns {Any}
   */
  private getSoapEnvelopeHeader(): Any {

    // Retrieve authentication data.
    const account = this.api.realm;
    const consumerKey = this.api.consumer_key;
    const consumerSecret = this.api.consumer_secret_key;
    const tokenId = this.api.token;
    const tokenSecret = this.api.token_secret;

    // Compute the signature.
    const timestamp = new Date().getTime().toString().substring(0, SOAP_TIMESTAMP_LENGTH);
    const nonce = CryptoJS.lib.WordArray.random(SOAP_NONCE_LENGTH).toString();
    const baseString = `${account}&${consumerKey}&${tokenId}&${nonce}&${timestamp}`;
    const key = `${consumerSecret}&${tokenSecret}`;
    const signature = CryptoJS.HmacSHA256(baseString, key).toString(CryptoJS.enc.Base64);

    // Build the envelope header and return it.
    return {
      'tokenPassport': {
        $: {
          'xmlns': XmlNamespace.MESSAGES
        },
        'account': account,
        'consumerKey': consumerKey,
        'token': tokenId,
        'nonce': nonce,
        'timestamp': timestamp,
        'signature': {
          $: {
            'algorithm': 'HMAC-SHA256'
          },
          _: signature
        }
      }
    };
  }

  /**
   * Returns the SOAP action response for the given action and XML response.
   * @param {SoapAction} action
   * @param {Any} xmlResponse
   * @returns {Promise<Any>}
   */
  private async getSoapActionResponseAsync(action: SoapAction, xmlResponse: Any): Promise<Any> {

    // Check the XML response is OK.
    throwsIfTrue(xmlResponse === undefined, `The XML response is undefined.`);
    throwsIfTrue(xmlResponse.status !== HttpStatusCode.Ok, `The status code is ${xmlResponse.statusCode}, expecting ${HttpStatusCode.Ok}.`);
    throwsIfTrue(xmlResponse.data === undefined, `The data in XML response is undefined.`);

    // Deserialize the XML response data.
    const jsonResponse = await xml2js.parseStringPromise(xmlResponse.data)
      .catch((error: Any) => {
        logError(`NetSuite XML reponse cannot be parsed. `
          + `XML response: ${xmlResponse.data}`);
        throw error;
      });

    // Retrieve the action response, checking the status is OK.
    const body = jsonResponse['soapenv:Envelope']['soapenv:Body'][0];
    const actionResponse = body[`${action}Response`][0];
    const response = actionResponse[`${action === 'get' ? 'read' : 'write'}Response`][0];

    // Check the response status. If it is not a success, report the related SOAP request error.
    const responseStatus = response['platformCore:status'][0];
    if (responseStatus.$.isSuccess !== 'true') {
      const responseStatusDetail = responseStatus['platformCore:statusDetail'][0];
      const statusCode = responseStatusDetail['platformCore:code'][0] === 'RCRD_DSNT_EXIST' ? HttpStatusCode.NotFound : HttpStatusCode.Error;
      throw new SoapRequestError(responseStatusDetail['platformCore:message'][0], { statusCode: statusCode, body: body });
    }
    return response;
  }

  /**
   * Sends SOAP action 'add' for the given request, then returns the internal ID of the new record.
   * @param {Any} request
   * @returns {Promise<number>}
   */
  public async soapAddAsync(request: Any): Promise<number> {

    // Send SOAP request and return the internal ID.
    const response = await this.soapRequestAsync('add', request);
    return +response.baseRef[0].$.internalId;
  }

  /**
   * Attach a contact to the given record with a specific role.
   * @param {string} recordType The record type.
   * @param {number} recordId The record identifier.
   * @param {number} contactId The contact identifier.
   * @param {number} contactRoleId The identifier of the contact role. By default, the contact role is the primary contact.
   */
  public async soapAttachContactAsync(recordType: string, recordId: number, contactId: number, contactRoleId = PrimaryContactRoleId): Promise<void> {

    // Build the request.
    const request: Any = {
      'attachReferece': {
        $: {
          'xsi:type': `core:AttachContactReference`,
          'xmlns:core': XmlNamespace.CORE
        },
        'core:attachTo': {
          $: {
            'internalId': `${recordId}`,
            'type': recordType,
            'xsi:type': `core:RecordRef`,
          }
        },
        'core:contact': {
          $: {
            'internalId': `${contactId}`,
            'xsi:type': `core:RecordRef`,
          }
        },
        'core:contactRole': {
          $: {
            'internalId': `${contactRoleId}`,
            'xsi:type': `core:RecordRef`,
          }
        }
      }
    };

    // Send SOAP request.
    await this.soapRequestAsync('attach', request);
  }

  /**
   * Sends SOAP action 'get' for the given type and internal ID, then returns the record response.
   * @param {string} type
   * @param {number} internalId
   * @returns {Promise<Any>}
   */
  public async soapGetAsync(type: string, internalId: number): Promise<Any> {

    // Build the action.
    const request = {
      'baseRef': {
        $: {
          'internalId': internalId.toString(),
          'type': type,
          'xsi:type': 'platformCore:RecordRef',
          'xmlns:platformCore': XmlNamespace.CORE
        }
      }
    };

    // Send the SOAP request and return the action response.
    const response = await this.soapRequestAsync('get', request);
    return response.record[0];
  }

  /**
   * Sends SOAP action 'update' for the given request.
   * @param {Any} request
   * @returns {Promise<number>}
   */
  public async soapUpdateAsync(request: Any): Promise<void> {

    // Send SOAP request.
    await this.soapRequestAsync('update', request);
  }

  /**
   * Sends SOAP action 'delete' for the given type and internal ID.
   * @param {string} type
   * @param {number} internalId
   * @returns {Promise<void>}
   */
  public async soapDeleteAsync(type: string, internalId: number): Promise<void> {

    // Build the action.
    const request = {
      'baseRef': {
        $: {
          'internalId': internalId.toString(),
          'type': type,
          'xsi:type': 'platformCore:RecordRef',
          'xmlns:platformCore': XmlNamespace.CORE
        }
      }
    };

    // Send the SOAP request.
    await this.soapRequestAsync('delete', request);
  }

  /**
   * Removes NetSuite customer.
   * @param customerId NetSuite customer Id
   * @returns status code
   */
  public deleteCustomer(customerId: number): Promise<number> {
    return this.request(`${NsApiPath.Customer}/${customerId}`, 'DELETE').then((response) => {
      return response.statusCode;
    });
  }

  /**
   * Removes NetSuite contact.
   * @param contactId NetSuite contact Id
   * @returns status code
   */
  public deleteContact(contactId: number): Promise<number> {
    return this.request(`record/v1/contact/${contactId}`, 'DELETE').then((response) => {
      return response.statusCode;
    });
  }

  /**
   * Removes NetSuite subscription by Id.
   * @param subscriptionId NetSuite subscription Id
   * @returns status code
   */
  public async deleteSubscription(subscriptionId: number): Promise<number> {
    return this.request(`record/v1/subscription/${subscriptionId}`, 'DELETE').then((response) => {
      return response.statusCode;
    });
  }

  /**
   * Create NetSuite customer.
   * @param customer cutomer data
   * @returns customerId NetSuite customer Id
   */
  public async createCustomer(
    subsidiaryId: number,
    customer: {
      companyName: string;
      email: string;
      phone?: string;
      fax?: string;
      webSite?: string;
      billingAddrCountry?: string;
      billingAddrPostalCode?: string;
      billingAddrState?: string;
      billingAddrCity?: string;
      billingAddrStreet?: string;
      shippingAddrCountry?: string;
      shippingAddrPostalCode?: string;
      shippingAddrState?: string;
      shippingAddrCity?: string;
      shippingAddrStreet?: string;
      isReseller?: boolean;
    }
  ): Promise<number> {
    const requestData = {
      companyName: customer.companyName,
      email: customer.email,
      subsidiary: subsidiaryId,
      phone: customer.phone,
      fax: customer.fax,
      url: customer.webSite,
      addressBook: {
        items: [
          {
            defaultBilling: true,
            defaultShipping: false,
            isResidential: false,
            addressBookAddress: {
              country: { id: customer.billingAddrCountry },
              state: customer.billingAddrState,
              zip: customer.billingAddrPostalCode,
              // addressee: 'Dwight Schrute',
              addr1: customer.billingAddrStreet,
              // addr2: 'addr 2',
              // addrPhone: '5555555',
              // addrText: '1718654183\naddr 1\naddr 2\ncity1 state1 12345\nUzbekistan',
              city: customer.billingAddrCity,
            },
          },
          {
            defaultBilling: false,
            defaultShipping: true,
            isResidential: false,
            addressBookAddress: {
              country: { id: customer.shippingAddrCountry },
              state: customer.shippingAddrState,
              zip: customer.shippingAddrPostalCode,
              addr1: customer.shippingAddrStreet,
              city: customer.shippingAddrCity,
            },
          },
        ],
      },
    };

    if (customer.isReseller) {
      const resellerChannelTierId = 2;
      requestData['custentity_customer_channel_tier'] = resellerChannelTierId;
    }

    const resp = await this.request('record/v1/customer', 'POST', JSON.stringify(requestData));

    const customerId = getRestResourceIdOrDefaultAsNumber(resp.rawHeaders);

    // assert netsuite record created successfully and id is retrieved
    expect(resp).not.toBeUndefined();
    expect(customerId).not.toBeNull();
    assertNotNullMsg(customerId, SHOULD_NOT_BE_NULL_HERE);
    return customerId;
  }

  /**
   * Gets NetSuite customer.
   * @param customerId NetSuite customer Id
   * @returns customer data
   */
  public async getCustomer(customerId: number): Promise<{
    companyName: string;
    email: string;
    phone?: string;
    fax?: string;
    url?: string;
    billingAddrId?: number;
    billingAddrCountry?: string;
    billingAddrPostalCode?: string;
    billingAddrState?: string;
    billingAddrCity?: string;
    billingAddrStreet?: string;
    shippingAddrId?: number;
    shippingAddrCountry?: string;
    shippingAddrPostalCode?: string;
    shippingAddrState?: string;
    shippingAddrCity?: string;
    shippingAddrStreet?: string;
  }> {
    const resp = JSON.parse((await this.request(`${NsApiPath.Customer}/${customerId}`, 'GET')).body);
    const addresses = JSON.parse((await this.request(`${NsApiPath.Customer}/${customerId}/addressBook`, 'GET')).body);
    const addrIds = addresses.items.map((x) => Number.parseInt(getPartAfterLast(x.links[0].href, '/')));
    for (const addrId of addrIds) {
      const addressBookEntry = JSON.parse(
        (await this.request(`${NsApiPath.Customer}/${customerId}/addressBook/${addrId}`, 'GET')).body
      );
      if (addressBookEntry.defaultBilling === true) {
        const billingAddress = JSON.parse(
          (await this.request(`${NsApiPath.Customer}/${customerId}/addressBook/${addrId}/addressBookAddress`, 'GET'))
            .body
        );
        resp.billingAddrId = addrId;
        resp.billingAddrCountry = billingAddress.country.id;
        resp.billingAddrPostalCode = billingAddress.zip;
        resp.billingAddrState = billingAddress.state;
        resp.billingAddrCity = billingAddress.city;
        resp.billingAddrStreet = billingAddress.addr1;
      }
      if (addressBookEntry.defaultShipping === true) {
        const shippingAddress = JSON.parse(
          (await this.request(`${NsApiPath.Customer}/${customerId}/addressBook/${addrId}/addressBookAddress`, 'GET'))
            .body
        );

        resp.shippingAddrId = addrId;
        resp.shippingAddrCountry = shippingAddress.country.id;
        resp.shippingAddrPostalCode = shippingAddress.zip;
        resp.shippingAddrState = shippingAddress.state;
        resp.shippingAddrCity = shippingAddress.city;
        resp.shippingAddrStreet = shippingAddress.addr1;
      }
    }
    return resp;
  }

  /**
   * Gets NetSuite contact.
   * @param contactId NetSuite contact Id
   * @returns contact data
   */
  public async getContact(contactId: number): Promise<{
    title?: string;
    salutation?: string;
    firstName?: string;
    lastName?: string;
    middleName?: string;
    email?: string;
    phone?: string;
    mobilePhone?: string;
    fax?: string;
    comments?: string;
  }> {
    return JSON.parse((await this.request(`${NsApiPath.Contact}/${contactId}`, 'GET')).body);
  }
  /**
   * Create NetSuite customer contact.
   * @param contact contact data
   * @returns contactId NetSuite customer Id
   */
  public async createContact(
    subsidiaryId: number,
    contact: {
      customerId: number;
      contactTitle: string;
      salutation: string;
      firstName: string;
      lastName: string;
      middleName: string;
      title: string;
      contactEmail: string;
      contactPhone: string;
      contactMobilePhone: string;
      contactFax: string;
      description: string;
      taxNumber?: string;
    }
  ): Promise<number> {
    const resp = await this.request(
      'record/v1/contact',
      'POST',
      JSON.stringify({
        company: {
          id: contact.customerId,
        },
        custentity_nslc_num_identificacion: contact.taxNumber,
        email: contact.contactEmail,
        entityId: `${contact.firstName} ${contact.middleName} ${contact.lastName}`,
        fax: contact.contactFax,
        firstName: contact.firstName,
        lastName: contact.lastName,
        middleName: contact.middleName,
        phone: contact.contactPhone,
        mobilePhone: contact.contactMobilePhone,
        salutation: contact.salutation,
        subsidiary: {
          id: subsidiaryId,
        },
        title: contact.title,
        comments: contact.description,
      })
    );

    const contactId = getRestResourceIdOrDefaultAsNumber(resp.rawHeaders);

    // assert netsuite record created successfully and id is retrieved
    expect(resp).not.toBeUndefined();
    expect(contactId).not.toBeNull();
    assertNotNullMsg(contactId, SHOULD_NOT_BE_NULL_HERE);
    return contactId;
  }

  /**
   * Create NetSuite customer contact.
   * @param contact contact data
   * @returns contactId NetSuite contact Id
   */
  public async updateContact(
    contactId: number,
    contact: {
      contactTitle: string;
      salutation: string;
      firstName: string;
      lastName: string;
      middleName: string;
      title: string;
      contactEmail: string;
      contactPhone: string;
      contactMobilePhone: string;
      contactFax: string;
      description: string;
      customerId?: number;
      subsidiaryId?: number;
      taxNumber?: string;
    }
  ): Promise<Any> {
    const body = {
      custentity_nslc_num_identificacion: contact.taxNumber,
      email: contact.contactEmail,
      entityId: contact.contactTitle,
      fax: contact.contactFax,
      firstName: contact.firstName,
      lastName: contact.lastName,
      middleName: contact.middleName,
      phone: contact.contactPhone,
      mobilePhone: contact.contactMobilePhone,
      salutation: contact.salutation,
      title: contact.title,
      comments: contact.description,
    };
    if (contact.customerId) {
      body['company'] = {
        id: contact.customerId,
      };
    }
    if (contact.subsidiaryId) {
      body['subsidiary'] = {
        id: contact.subsidiaryId,
      };
    }
    const resp = await this.request(`record/v1/contact/${contactId}`, 'PATCH', JSON.stringify(body));

    // assert netsuite record created successfully and id is retrieved
    expect(resp).not.toBeUndefined();
    expect(resp.statusCode).toBe(HttpStatusCode.NoContent);
  }

  /**
   * update customer contact.
   * @param contact contact data
   * @returns contactId NetSuite contact Id
   */
  public async updateContactWithBody(contactId: number, body: Any): Promise<Any> {
    const resp = await this.request(`record/v1/contact/${contactId}`, 'PATCH', JSON.stringify(body));

    // assert netsuite record created successfully and id is retrieved
    expect(resp).not.toBeUndefined();
    expect(resp.statusCode).toBe(HttpStatusCode.NoContent);
  }

  /**
   * Update NetSuite customer.
   * @param customer customer data
   * @returns customerId NetSuite customer Id
   */
  public async updateCustomer(
    customerId: number,
    customer: {
      companyName: string;
      subsidiaryId: number;
      email: string;
      phone?: string;
      fax?: string;
      webSite?: string;
      billingAddrId?: number;
      billingAddrCountry?: string;
      billingAddrPostalCode?: string;
      billingAddrState?: string;
      billingAddrCity?: string;
      billingAddrStreet?: string;
      shippingAddrId?: number;
      shippingAddrCountry?: string;
      shippingAddrPostalCode?: string;
      shippingAddrState?: string;
      shippingAddrCity?: string;
      shippingAddrStreet?: string;
    }
  ): Promise<Any> {
    const body = {
      companyName: customer.companyName,
      email: customer.email,
      subsidiary: customer.subsidiaryId,
      phone: customer.phone,
      fax: customer.fax,
      url: customer.webSite,
      addressBook: {
        items: [
          {
            addressId: customer.billingAddrId,
            defaultBilling: true,
            defaultShipping: false,
            isResidential: false,
            addressBookAddress: {
              country: { id: customer.billingAddrCountry },
              state: customer.billingAddrState,
              zip: customer.billingAddrPostalCode,
              addr1: customer.billingAddrStreet,
              city: customer.billingAddrCity,
            },
          },
          {
            addressId: customer.shippingAddrId,
            defaultBilling: false,
            defaultShipping: true,
            isResidential: false,
            addressBookAddress: {
              country: { id: customer.shippingAddrCountry },
              state: customer.shippingAddrState,
              zip: customer.shippingAddrPostalCode,
              addr1: customer.shippingAddrStreet,
              city: customer.shippingAddrCity,
            },
          },
        ],
      },
    };
    const resp = await this.request(`${NsApiPath.Customer}/${customerId}`, 'PATCH', JSON.stringify(body));

    // assert netsuite record created successfully and id is retrieved
    expect(resp).not.toBeUndefined();
    expect(resp.statusCode).toBe(HttpStatusCode.NoContent);
  }

  /**
   * Create NetSuite Billing Account.
   * @returns NetSuite billingAccountId
   */
  public async createBillingAccount(customerId: number, startDate: string, subsidiaryId: number): Promise<number> {
    const resp = await this.request(
      'record/v1/billingaccount',
      'POST',
      JSON.stringify({
        subsidiary: subsidiaryId,
        currency: USDCurrencyId,
        customer: customerId,
        billingSchedule: AnnuallBillingScheduleId,
        startDate: startDate,
        class: EverestClassId,
        department: SalesDepartmentId,
      })
    );

    const billingAccountId = getRestResourceIdOrDefaultAsNumber(resp.rawHeaders);

    // assert netsuite record created successfully and id is retrieved
    expect(resp).not.toBeUndefined();
    expect(billingAccountId).not.toBeNull();
    assertNotNullMsg(billingAccountId, SHOULD_NOT_BE_NULL_HERE);
    return billingAccountId;
  }

  /**
   * Gets record
   * @param {string} recordType type of the record
   * @param {number} recordId id of the record
   * @param {boolean} [expandSubResources=false] do expand resources (child entities)?
   * @return {*}  {Promise<Any>} the record content
   * @memberof NsApiClient
   */
  public async getRecord<T>(recordType: string, recordId: number, expandSubResources = false, logs = true): Promise<T> {
    const expandSubResourcesText = expandSubResources ? '?expandSubResources=true' : '';
    const record = JSON.parse((await this.request(`record/v1/${recordType}/${recordId}${expandSubResourcesText}`, 'GET')).body);
    logRecord('NS', recordType, { id: recordId }, undefined, logs);
    return record;
  }

  /**
   * Gets records ids by some query
   * @param {string} recordType type of the record
   * @param {string} nsQuery record query. Syntax: https://docs.oracle.com/en/cloud/saas/netsuite/ns-online-help/section_1545222128.html
   * @return {*} {Promise<FilterResponse>} the search response
   * @memberof NsApiClient
   */
  public async searchRecords(recordType: string, nsQuery: string): Promise<FilterResponse> {
    const resp = await this.request(`record/v1/${recordType}?q=${nsQuery}`, 'GET');
    return JSON.parse(resp.body);
  }

  /**
   * Do a query using suite ql
   * @returns data returned by the query
   */
  public async queryWithSuiteQL<T>(query: string, limit = REST_SUITEQL_DEFAULT_LIMIT): Promise<QueryResults<T>> {
    return JSON.parse(
      (
        await this.request(
          `query/v1/suiteql?limit=${limit}`,
          'POST',
          JSON.stringify({
            q: query,
          })
        )
      ).body
    );
  }

  /**
   * Returns the currency ISO code for the given currency ID.
   * @param {string} currencyId
   * @returns {Promise<string>}
   */
  public async getCurrencyIsoCode(currencyId: string): Promise<string> {

    // Try to retrieve the currency symbol.
    const queryResult = await this.queryWithSuiteQL<{ symbol: string }>(`SELECT symbol FROM currency WHERE id = ${currencyId}`);

    // If the currency has been found, return it.
    if (queryResult.count === 0) {
      throw new Error(`Currency record not found for ID '${currencyId}'.`);
    }
    return queryResult.items.first().symbol;
  }

  /**
   * Get NetSuite Subscription
   * @returns NetSuite subscription content
   */
  public async getSubscription(subscriptionId: number): Promise<SubscriptionRec> {
    return await this.getRecord('subscription', subscriptionId, true);
  }

  /**
   * Get ProductIntegrationRecord
   */
  public async getProductIntegrationRecord(productFamily: string, productVariant: string): Promise<NsProductIntegration> {
    const queryResult = await this.queryWithSuiteQL<NsProductIntegration>(
      `SELECT pi.id, 
    apo.scriptid as autoprovisioning, 
    pi.custrecordsupport_brand as supportbrand,
    pi.custrecordsupport_product as supportproduct
    FROM customrecordproductintegration pi
    LEFT JOIN customlistauto_provisioning_options apo on apo.id=pi.custrecordenable_auto_provisioning
    WHERE pi.custrecordproductfamilycode = '${productFamily}' AND
    pi.custrecordproductvariantcode = '${productVariant}'`);
    if (queryResult.count === 0) {
      throw new Error(
        `Product Integration record not found for ${productFamily} ${productVariant}`
      );
    }
    return queryResult.items.first();
  }

  /**
   * Get NetSuite Subscription
   * @returns NetSuite quote content
   */
  public async getQuote(quoteId: number): Promise<NsQuoteRec | null> {
    // NsQuoteRec
    const queryResult = await this.queryWithSuiteQL<NsQuoteRec>(`select 
    t.id,
    t.createddate,
    t.duedate expiryDate,
    t.title,
    c.entityid as customerId, 
    eu.entityid as enduserId,
    es.name as status, 
    t.foreigntotal as totalAmount,
    (select count(1) from transactionline tl where tl.transaction=t.id and tl.itemtype = 'NonInvtPart') as linecount,
    ag.id as agreementId,
    ag.name as agreementname,
    ags.name as agreementStatus,
    tli.subscription as subscriptionid,
    eua_ag.id as euaagreementid,
    eua_ag.name as euaagreementname
  from transaction t 
  join customer c on c.id=t.entity
  join customer eu on eu.id=t.custbody_end_user
  join entitystatus es on es.key=t.entitystatus
  left join customrecord_echosign_agreement ag on ag.custrecord_echosign_parent_record=t.id and ag.custrecord_echosign_parent_type='estimate' and ag.custrecord_agreement_type = 1
  left join customrecord_echosign_agreement eua_ag on eua_ag.custrecord_echosign_parent_record=t.id 
    and eua_ag.custrecord_echosign_parent_type='estimate' and eua_ag.custrecord_agreement_type = 2
  left join customlist_echosign_status_types ags on ags.id = ag.custrecord_echosign_status
  left join transactionline tli on tli.transaction = t.id AND tli.linesequencenumber = 1
  where t.recordtype='estimate' and t.id = ${quoteId}`);

    if (queryResult.count > 1) {
      throw new Error(
        `Unexpected records count when getting quote by id ${quoteId}. Response ${toDescriptionString(queryResult)}.`
      );
    }

    return queryResult.count === 1 && queryResult.items.length === 1 ? queryResult.items[0] : null;
  }

  /**
   * Get quote lines
   * @param quoteId
   * @returns 
   */
  public async getQuoteLines(quoteId: number): Promise<NsQuoteLineRec[]> {
    const queryResult = await this.queryWithSuiteQL<NsQuoteLineRec>(`
    SELECT linesequencenumber as linenumber, tl.item as itemid, i.itemid as itemcode, i.displayname as itemname,  rate
    FROM transactionline tl 
    INNER JOIN item i on tl.item = i.id
    WHERE tl.transaction=${quoteId} and tl.itemtype = 'NonInvtPart'
    ORDER BY linesequencenumber`);

    return queryResult.items;
  }

  /**
   * Get Quote Agreements And Docs
   * @returns NetSuite Agreements And Docs content
   */
  public async getQuoteAgreementsAndDocs(agreementId: number): Promise<NsAgreementDocRec[]> {
    const queryResult = await this.queryWithSuiteQL<NsAgreementDocRec>(`select 
    a.id agreementid,
    a.custrecord_agreement_type agreementtype,
    d.id documentid,
    from customrecord_echosign_document d   
      left join customrecord_echosign_agreement a on d.custrecord_echosign_agreement=a.id
      where a.id=${agreementId}`);

    return queryResult.items;
  }

  /**
   * Get Quote Agreements And Docs
   * @returns NetSuite Agreements And Docs content
   */
  public async getQuoteAgreementRecipients(agreementId: number): Promise<NsAgreementRecipientRec[]> {
    const queryResult = await this.queryWithSuiteQL<NsAgreementRecipientRec>(`select  
    id,
    custrecord_echosign_role role,
    custrecord_echosign_email email,
    custrecord_echosign_signer_order order
    from customrecord_echosign_signer where custrecord_echosign_agree=${agreementId}`);

    return queryResult.items;
  }

  /**
   * Update NetSuite Subscription
   * @returns NetSuite subscription content
   */
  public updateSubscription(subscriptionId: number, updateBody): Promise<number> {
    return this.request(
      `record/v1/${NsRecordTypes.Subscription}/${subscriptionId}/`,
      'PATCH',
      JSON.stringify(updateBody)
    ).then((response) => {
      return response.statusCode;
    });
  }

  public createLinesArray(number: number, status: NsSubscriptionStatusId) {
    const lines: {
      linenumber: number;
      isincluded: boolean;
      status: string;
    }[] = [];
    for (let c = 1; c <= number; c++) {
      lines.push({
        linenumber: c,
        isincluded: true,
        status: status,
      });
    }
    return lines;
  }

  public getLinesWithPendingActivationFromDraftLines(items) {
    let lines: SubscriptionLine[] = [];
    const draftLines = items?.filter((v) => v.status?.id === NsSubLineElementStatusId.Draft);
    if (draftLines !== undefined && draftLines.length > 0) {
      lines = draftLines.map((value) => {
        return {
          lineNumber: value.lineNumber,
          status: {
            id: NsSubLineElementStatusId.PendingActivation
          }
        }
      })
    }
    return lines;
  }

  /**
   * Create NetSuite Subscription
   * @returns NetSuite subscriptionId
   */
  public async createSubscription(params: {
    customerId: number;
    distributorId?: number;
    resellerId?: number;
    billingAccountId: number;
    startDate: string;
    subscriptionPlanId: number;
    priceBookId: number;
    includedLinesNumber: number;
    parentSubscriptionId?: number;
  },
    expectedResponse?: number): Promise<number | Any> {
    const subscriptionPlan = await this.getRecord<Any>('subscriptionplan', params.subscriptionPlanId);
    const nameParts = subscriptionPlan.itemId.split(' ');
    const codeParts = subscriptionPlan.displayName.split('-');
    const dateString = getNsDate(new Date(params.startDate + ' 00:00:00'));

    let subscriptionName = `${nameParts[0]} ${codeParts[2]} ${codeParts[3]} ${codeParts[4]} ${dateString}`; //NOSONAR this is not a magic number

    const searchResult = await this.queryWithSuiteQL<{ id: number; name: string }>(
      `select id, name from subscription where name like '${subscriptionName}%'`
    );
    if (searchResult.count > 0) {
      const subscriptionMainPartName = subscriptionName;
      for (let c = 1; c <= searchResult.count; c++) {
        if (!searchResult.items.find((i) => i.name === subscriptionName)) {
          break;
        }
        subscriptionName = `${subscriptionMainPartName} ${c}`;
      }
    }

    const payload = {
      customer: params.customerId,
      custrecord_subs_end_user: params.customerId,
      custrecord_subs_distributor: params.distributorId,
      custrecord_subs_reseller: params.resellerId,
      billingaccount: params.billingAccountId,
      startdate: params.startDate,
      subscriptionplan: params.subscriptionPlanId,
      pricebook: params.priceBookId,
      initialterm: AnnuallTermId,
      autorenewal: true,
      defaultrenewalmethod: 'CREATE_NEW_SUBSCRIPTION',
      defaultrenewalterm: AnnuallTermId,
      advancerenewalperiodnumber: 364,
      advancerenewalperiodunit: 'DAYS',
      subscriptionline: {
        items: this.createLinesArray(params.includedLinesNumber, NsSubscriptionStatusId.Draft),
      },
      currency: USDCurrencyId,
      name: subscriptionName,
      custrecord_contract_docs: DefaultContractualDocumentId,
      custrecord_parent_subscription: params.parentSubscriptionId
    };
    const resp = await this.request('record/v1/subscription', 'POST', JSON.stringify(payload), expectedResponse);
    if (expectedResponse === HttpStatusCode.Error) {
      return resp;
    }
    const subscriptionId = getRestResourceIdOrDefaultAsNumber(resp.rawHeaders);

    // assert netsuite record created successfully and id is retrieved
    expect(resp).not.toBeUndefined();
    expect(subscriptionId).not.toBeNull();
    assertNotNullMsg(subscriptionId, SHOULD_NOT_BE_NULL_HERE);
    return subscriptionId;
  }

  /**
   * Activate NetSuite Subscription
   * @returns NetSuite activation Change Order Id
   */
  public async activateSubscription(params: {
    customerId: number;
    subscriptionId: number;
    startDate: string;
    includedLinesNumber: number;
  }): Promise<number> {
    const lines: {
      sequence: number;
      apply: boolean;
    }[] = [];
    for (let c = 1; c <= params.includedLinesNumber; c++) {
      lines.push({
        sequence: c,
        apply: true,
      });
    }
    const resp = await this.request(
      NsApiPath.SubscriptionChangeOrder,
      'POST',
      JSON.stringify({
        action: 'ACTIVATE',
        customer: params.customerId,
        subscription: params.subscriptionId,
        modificationType: 'IGNORED',
        effectiveDate: params.startDate,
        // Customer Activated
        custrecord_st_change_reason: 1,
        subline: {
          items: lines,
        }
      })
    );

    const changeOrderId = getRestResourceIdOrDefaultAsNumber(resp.rawHeaders);

    // assert netsuite record created successfully and id is retrieved
    expect(resp).not.toBeUndefined();
    expect(
      changeOrderId,
      `Activation change order creation failed for subscription ${params.subscriptionId}`
    ).not.toBeNull();
    assertNotNullMsg(changeOrderId);
    return changeOrderId;
  }

  /**
   * Renew NetSuite Subscription
   * @returns NetSuite renewal Change Order Id
   */
  public async renewSubscription(params: {
    customerId: number;
    subscriptionId: number;
    subscriptionPlanId: number;
    priceBookId: number;
  }): Promise<number> {
    const payload = {
      action: 'RENEW',
      customer: params.customerId,
      subscription: params.subscriptionId,
      modificationType: 'IGNORED',
      renewalMethod: 'CREATE_NEW_SUBSCRIPTION',
      renewalPlan: params.subscriptionPlanId,
      renewalpricebook: params.priceBookId,
      renewalTerm: AnnuallTermId,
    };
    const resp = await this.request(NsApiPath.SubscriptionChangeOrder, 'POST', JSON.stringify(payload));
    const changeOrderId = getRestResourceIdOrDefaultAsNumber(resp.rawHeaders);

    // assert netsuite record created successfully and id is retrieved
    expect(resp).not.toBeUndefined();
    expect(
      changeOrderId,
      `Renew change order creation failed for subscription ${params.subscriptionId}`
    ).not.toBeNull();
    assertNotNullMsg(changeOrderId);
    return changeOrderId;
  }

  /**
   * Updates quantity of items of draft renewal subscription
   * @returns NetSuite subscriptionId
   */
  public async updateSubscriptionItemsQuantity(subscriptionId: number, quantity: number): Promise<void> {
    const subscription = await this.getSubscription(subscriptionId);

    const notIncludedLines = subscription.subscriptionLine?.items?.filter((i) => i?.status?.id === 'NOT_INCLUDED');
    const linesToInclude = must(notIncludedLines).map((i) => {
      return {
        linenumber: i.lineNumber,
        isIncluded: true,
        status: { id: 'DRAFT' },
      };
    });

    const priceIntervals = must(subscription.priceInterval?.items).map((i) => {
      return {
        linenumber: i.lineNumber,
        quantity: quantity,
        repeatEvery: i.repeatEvery,
        subscriptionPlanLineNumber: i.subscriptionPlanLineNumber,
        startDate: i.startDate,
        isIncluded: true,
        frequency: { id: i.frequency?.id },
        status: { id: 'DRAFT' },
      };
    });
    const requestBody = {
      priceInterval: { items: priceIntervals },
    };

    if (linesToInclude.length > 0) {
      requestBody['subscriptionLine'] = { items: linesToInclude };
    }

    const status = await this.updateSubscription(subscriptionId, requestBody);
    expect(status, `Failed to update subscription ${subscriptionId}`).toBe(HttpStatusCode.NoContent);
  }

  /**
   * Fixes Draft renewal subscription if its status is 'not included' and moves it to 'draft' status
   * @returns NetSuite subscriptionId
   */
  public async fixSubscriptionIfItIsNotIncluded(subscriptionId: number): Promise<void> {
    const subscription = await this.getSubscription(subscriptionId);
    if (subscription.billingSubscriptionStatus?.id === 'NOT_INCLUDED') {
      const notIncludedLines = subscription.subscriptionLine?.items?.filter((i) => i?.status?.id === 'NOT_INCLUDED');
      expect(notIncludedLines, 'Subscription is not included and without lines to include.').toBeTruthy();
      expect(notIncludedLines?.length, 'Subscription is not included and without lines to include.').toBeGreaterThan(0);

      const linesToInclude = must(notIncludedLines).map((i) => {
        return {
          linenumber: i.lineNumber,
          isIncluded: true,
          status: { id: 'DRAFT' },
        };
      });

      const status = await this.updateSubscription(subscriptionId, { subscriptionLine: { items: linesToInclude } });
      expect(status, `Failed to update subscription ${subscriptionId}`).toBe(HttpStatusCode.NoContent);
    }
  }

  /**
   * Terminates a subscription with the given change reason, assuming all lines are included.
   *
   * @param {SubscriptionRec} subscription
   * @param {NsSubStatusChangeReason} changeReason
   */
  public async terminateSubscription(
    subscription: SubscriptionRec,
    changeReason: NsSubStatusChangeReason
  ): Promise<number> {

    // Build the body.
    const items = Array.from(Array(must(subscription.subscriptionLine?.totalResults)), (v, k) => {
      return {
        sequence: k + 1,
        apply: true
      }
    });
    const requestBody = {
      action: NsSubscriptionChangeOrderActionId.Terminate,
      billingAccount: must(subscription.billingAccount?.id),
      customer: must(subscription.customer?.id),
      custrecord_st_change_reason: changeReason,
      subscription: must(subscription.id),
      subline: {
        items: items,
      },
      effectiveDate: must(subscription.startDate),
      terminateAtStartOfDay: true,
      memo: 'cancelled via E2E test'
    };

    // Create the change order.
    const resp = await this.request(
      NsApiPath.SubscriptionChangeOrder,
      'POST',
      JSON.stringify(requestBody)
    );
    const changeOrderId = getRestResourceIdOrDefaultAsNumber(resp.rawHeaders);

    // Assert the change order has been successfully created.
    expect(resp).not.toBeUndefined();
    expect(
      changeOrderId,
      `Termination change order creation failed for subscription ${must(subscription.id)}`
    ).not.toBeNull();
    assertNotNullMsg(changeOrderId);
    return must(changeOrderId);
  }

  /**
   * Creates contractual documents for the given subscription and returns the contractual documents ID.
   * @param {number} subscriptionId
   * @returns {Promise<number>}
   */
  public async createContractualDocuments(
    subscriptionId: number
  ): Promise<number> {

    // Build the body.
    const requestBody = {
      custrecord_sub_doc: subscriptionId.toString(),
      name: `Contractual documents for sub ${subscriptionId}`
    };

    // Create the contractual documents.
    const resp = await this.request(NsApiPath.ContractualDocument, 'POST', JSON.stringify(requestBody));
    const contractualDocumentsId = getRestResourceIdOrDefaultAsNumber(resp.rawHeaders);

    // Assert the change order has been successfully created.
    expect(resp).not.toBeUndefined();
    expect(
      contractualDocumentsId,
      `Creation of Contractual Documents failed for subscription ${must(subscriptionId)}`
    ).not.toBeNull();
    assertNotNullMsg(contractualDocumentsId);

    // Return the contractual documents ID.
    return contractualDocumentsId;
  }

  public async getFirstOrDefaultRecord<T>(
    recordType: string,
    query: string,
    expandSubResources = false
  ): Promise<T | null> {
    const ids = await this.searchRecords(recordType, query);
    if (ids.count > 0 && ids.items.length > 0) {
      return (await this.getRecord(recordType, ids.items[0].id, expandSubResources)) as T;
    }
    return null;
  }

  /**
   * Gets the last record for the given query based on the identity ID, else null.
   *
   * @param {string} recordType
   * @param {string} query
   * @param {boolean} expandSubResources
   * @returns {Promise<T | null>}
   */
  public async getLastOrDefaultRecord<T>(
    recordType: string,
    query: string,
    expandSubResources = false
  ): Promise<T | null> {
    const response = await this.searchRecords(recordType, query);
    if (response.count > 0 && response.items.length > 0) {
      const lastId = Math.max(...response.items.map((v) => v.id));
      return (await this.getRecord(recordType, lastId, expandSubResources)) as T;
    }
    return null;
  }

  public getSubscriptionPlanByName(planName: string, expandSubResources = false): Promise<Any | null> {
    return this.getFirstOrDefaultRecord<Any>(
      NsRecordTypes.SubscriptionPlan,
      `itemId IS "${planName}"`,
      expandSubResources
    );
  }

  public getSubscriptionPlanById(planId: number, expandSubResources = false): Promise<Any | null> {
    return this.getFirstOrDefaultRecord<Any>(
      NsRecordTypes.SubscriptionPlan,
      `id EQUAL "${planId}"`,
      expandSubResources
    );
  }

  public getSubsidiaryByName(subsidiaryName: string, expandSubResources = false): Promise<Any | null> {
    return this.getFirstOrDefaultRecord<Any>(
      NsRecordTypes.Subsidiary,
      `name IS "${subsidiaryName}"`,
      expandSubResources
    );
  }

  public getSubsidiary(subsidiaryId: number, expandSubResources = true): Promise<Any | null> {
    return this.getRecord<Any>(NsRecordTypes.Subsidiary, subsidiaryId, expandSubResources);
  }

  public getEmployee(employeeId: number, expandSubResources = true): Promise<Any | null> {
    return this.getRecord<Any>(NsRecordTypes.Employee, employeeId, expandSubResources);
  }

  public async getPriceBookByName(
    priceBookName: string,
    subscrPlanId: number,
    expandSubResources = false
  ): Promise<Any | null> {
    return await this.getFirstOrDefaultRecord<Any>(
      NsRecordTypes.PriceBook,
      `name is "${priceBookName}" AND subscriptionPlan EQUAL ${subscrPlanId}`,
      expandSubResources
    );
  }

  public async doSubscriptionExist(nsSubscriptionId: number): Promise<boolean> {
    const ids = await this.searchRecords(NsRecordTypes.Subscription, `id EQUAL ${nsSubscriptionId}`);
    return ids.count > 0 && ids.items.length > 0;
  }

  /**
   * Gets the last subscription change order of the given subscription, else null.
   *
   * @param {number} subscriptionId
   * @param {boolean} expandSubResources
   * @returns {Promise<NsSubscriptionChangeOrderRec | null>}
   */
  public async getLastSubscriptionChangeOrder(
    subscriptionId: number,
    expandSubResources = false
  ): Promise<NsSubscriptionChangeOrderRec | null> {
    return await this.getLastOrDefaultRecord<NsSubscriptionChangeOrderRec | null>(
      NsRecordTypes.SubscriptionChangeOrder,
      `subscription EQUAL ${subscriptionId}`,
      expandSubResources
    );
  }

  /**
   * Get the number of files attached to the agreement
   * @returns quantity
   */
  public async getFilesQuantityAttachedToAgreement(agreementId: number): Promise<number> {
    const queryResult = await this.queryWithSuiteQL<{ files: number }>(`select  
    count(id) as files
    FROM customrecord_echosign_document 
    WHERE custrecord_echosign_agreement=${agreementId}`);

    return queryResult.items.first().files;
  }

  public callRestlet(body, version = 'main') {
    const uri = `https://${this.api.realm
      .toLowerCase()
      .replace("_", "-")}.restlets.api.netsuite.com/app/site/hosting/restlet.nl?script=customscript_si_${version}_main_restlet&deploy=customdeploy_si_${version}_main`;
    const options = {
      url: uri,
      method: "POST",
      throwHttpErrors: true,
      decompress: true,
      hooks: {
        afterResponse: [
          (response) => {
            return {
              ...response,
              data: response.body ? JSON.parse(response.body) : null,
            };
          },
        ],
      },
    } as Any;
    options.headers = this.api.getAuthorizationHeader(options);
    options.headers["Content-Type"] = "application/json";
    options.body = JSON.stringify(body);
    return this.retryPolicy.execute(() => got(options)).catch((error) => {
      if (error instanceof HTTPError) {
        Error.captureStackTrace(error);

        logError(
          `NetSuite request failed. `
          + `Response status: ${error?.response.statusCode} ${error?.response.statusMessage}, `
          + `Body: ${error?.response.body}, `
          + `Stack: ${error.stack}`
        );
      }
      throw error;
    });
  }
}
