import { AxiosError, AxiosRequestConfig, AxiosResponse } from 'axios';
import { IRetryContext } from 'cockatiel';
import { Any, assertNotNullEnvVar, HttpStatusCode, must } from '../utils/types';
import { doOperationUntilCondition, logError, logRecord, throwsIfTrue, toDescriptionString } from '../utils/utils';
import {
  RecordsResponse,
  OpportunityProductRec,
  OpportunityRec,
  SfQuoteRec,
  SfAccount,
  ActionInvocationResult,
  AccountData,
  ResellerAgreementData,
  SfContact,
  RecordResponse,
  ProductRec,
  SfProductOption,
  SfQuoteLine,
} from '../api_contracts/sf_api_contracts';
import { ReportContent } from '../api_contracts/sf_api_reports_contracts';
import { waitForRecInitialDelay, waitForRecMaxAttempts, waitForRecMaxDelay } from '../utils/steps_types';
import { ApiClient } from './api_client';

export class SfApiPath {
  public static Version = '55.0';
  public static Token = 'services/oauth2/token';
  public static SoqlQuery = `services/data/v${SfApiPath.Version}/query`;
  public static SObjects = `services/data/v${SfApiPath.Version}/sobjects`;
  public static SObjectsMetadata = `services/data/v${SfApiPath.Version}/tooling/sobjects`;
  public static Account = `${SfApiPath.SObjects}/Account`;
  public static Partner = `${SfApiPath.SObjects}/Partner`;
  public static Contact = `${SfApiPath.SObjects}/Contact`;
  public static Task = `${SfApiPath.SObjects}/Task`;
  public static Opportunity = `${SfApiPath.SObjects}/Opportunity`;
  public static Quote = `${SfApiPath.SObjects}/SBQQ__Quote__c`;
  public static QuoteLine = `${SfApiPath.SObjects}/SBQQ__QuoteLine__c`;
  public static ResellerAgreement = `${SfApiPath.SObjects}/Reseller_Agreement__c`;
  public static TaskDispatchBatchV2Action = `services/data/v${SfApiPath.Version}/actions/custom/apex/TaskDispatchBatchV2`;
  public static Report = `services/data/v${SfApiPath.Version}/analytics/reports/`;
}

export enum SfObjectApiName {
  Account = 'Account',
  Contact = 'Contact',
  DefaultAccountSubsidiary = 'Default_Account_Subsidiary__c',
  GlobalValueSet = 'GlobalValueSet',
  OpportunityContactRole = 'OpportunityContactRole',
  ProductConfiguration = 'Product_Configuration__c',
  Quote = 'SBQQ__Quote__c',
  Subsidiary = 'Subsidiary__c',
  User = 'User',
}

export enum SfGlobalValueSetId {
  ProductFamilies = '0Nt2x000000H59G'
}

/**
 * SalesForce REST API query helper.
 */
export class SfApiClient extends ApiClient {
  private readonly baseUrl: string;
  private token: string | undefined;

  constructor(enablesRetryMechanism = true) {
    super(enablesRetryMechanism);
    assertNotNullEnvVar(process.env.SF_BaseUrl, 'SF_BaseUrl');
    this.baseUrl = process.env.SF_BaseUrl;
  }

  private async getToken(): Promise<string> {
    if (!this.token) {
      this.token = await this.requestAToken();
    }
    return this.token;
  }

  private async getRequestConfig(): Promise<AxiosRequestConfig> {
    return {
      headers: {
        Authorization: `Bearer ${await this.getToken()}`,
      },
    };
  }

  private async get<T = Any, R = AxiosResponse<T>, D = Any>(
    url: string,
    config?: AxiosRequestConfig<D>,
    returnNullWhenNotFound = false
  ): Promise<R | undefined | null> {
    return await this.axiosWithRetry.get<T, R, D>(url, config).catch((error) => {
      if (error instanceof AxiosError) {
        if (returnNullWhenNotFound && (error as AxiosError)?.response?.status === HttpStatusCode.NotFound) {
          return null;
        } else {
          Error.captureStackTrace(error);
          logError(
            `SalesForce request failed. `
            + `Response status: ${error?.response?.status} ${error?.response?.statusText}, `
            + `Body: ${toDescriptionString(error?.response?.data)}, `
            + `Stack: ${error.stack}`
          );
        }
      }
      throw error;
    });
  }

  private async post<T = Any, R = AxiosResponse<T>, D = Any>(
    url: string,
    data?: D,
    config?: AxiosRequestConfig<D>
  ): Promise<R> {
    return await this.axiosWithRetry.post<T, R, D>(url, data, config).catch((error) => {
      this.logIfAxiosError(error);
      throw error;
    });
  }

  private async patch<T = Any, R = AxiosResponse<T>, D = Any>(
    url: string,
    data?: D,
    config?: AxiosRequestConfig<D>
  ): Promise<R> {
    return await this.axiosWithRetry.patch<T, R, D>(url, data, config).catch((error) => {
      this.logIfAxiosError(error);
      throw error;
    });
  }

  private async delete<T = Any, R = AxiosResponse<T>, D = Any>(
    url: string,
    config?: AxiosRequestConfig<D>
  ): Promise<R> {
    return await this.axiosWithRetry.delete<T, R, D>(url, config).catch((error) => {
      this.logIfAxiosError(error);
      throw error;
    });
  }

  private logIfAxiosError(error: Any) {
    if (error instanceof AxiosError) {
      Error.captureStackTrace(error);
      logError(
        `SalesForce request failed. `
        + `Response status: ${error?.response?.status} ${error?.response?.statusText}, `
        + `Body: ${toDescriptionString(error?.response?.data)}, `
        + `Stack: ${error.stack}`
      );
    }
  }

  private async requestAToken(): Promise<string> {
    assertNotNullEnvVar(process.env.SF_AppClientId, 'SF_AppClientId');
    assertNotNullEnvVar(process.env.SF_AppClientSecret, 'SF_AppClientSecret');
    assertNotNullEnvVar(process.env.SF_UserName, 'SF_UserName');
    assertNotNullEnvVar(process.env.SF_Password, 'SF_Password');
    assertNotNullEnvVar(process.env.SF_UserSecretToken, 'SF_UserSecretToken');

    const salesfoceAuthResponse = await this.post(
      `${this.baseUrl}${SfApiPath.Token}`,
      new URLSearchParams({
        grant_type: 'password',
        client_id: process.env.SF_AppClientId,
        client_secret: process.env.SF_AppClientSecret,
        username: process.env.SF_UserName,
        password: `${process.env.SF_Password}${process.env.SF_UserSecretToken}`,
      }).toString(),
      {
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded',
        },
      }
    );

    return salesfoceAuthResponse.data.access_token;
  }

  /**
   * Returns an object with only related fields to log.
   * @param {Any} record
   * @returns {Any}
   */
  private getFieldsToLog(record: Any): Any {

    // Keep only expected properties as log data.
    const logData = (
      ({ FullName, NetSuite_ID__c, Netsuite_Id__c, NetSuite_Class__c }) => ({ FullName, NetSuite_ID__c, Netsuite_Id__c, NetSuite_Class__c })
    )(record);

    // Remove all undefined properties before to return the log data.
    Object.keys(logData).forEach(key => logData[key] === undefined ? delete logData[key] : {});
    return logData;
  }

  /**
   * Runs Soql query.
   * @param query query
   * @returns items in the responses
   */
  public async getSoqlQuery<T>(query: string): Promise<RecordsResponse<T>> {
    // search for salesforce record
    return must(
      await this.get(
        `${this.baseUrl}${SfApiPath.SoqlQuery}/?q=${query.replace(/ /g, '+').replace(/%/g, '%25')}`,
        await this.getRequestConfig()
      )
    );
  }

  /**
   * Returns the records matching the given query.
   * @param {string} query
   * @returns {Promise<RecordResponse<T>[]>}
   */
  public async getRecordsByQueryAsync<T = Any>(query: string): Promise<RecordResponse<T>[]> {

    const response = await this.getSoqlQuery<T>(query);

    // If the response is defined and OK, return the record. Else, throw an error.
    if (response !== null && response !== undefined && response.status === HttpStatusCode.Ok) {
      return response.data.records;
    }
    throw new Error(`Failed to retrieve records for the query: ${query}`);
  }

  /**
   * Returns the record for the given object API name and id.
   * @param {SfObjectApiName} objectName
   * @param {string} recordId
   * @returns {Promise<RecordResponse<T>>} The record if any; else, null.
   */
  public async getRecordAsync<T = Any>(objectName: SfObjectApiName, recordId: string, isObjectMetadata = false, logs = true): Promise<RecordResponse<T> | null> {

    // Send GET request to retrieve the record.
    const response = await this.get<RecordResponse<T>>(
      `${this.baseUrl}${isObjectMetadata ? SfApiPath.SObjectsMetadata : SfApiPath.SObjects}/${objectName}/${recordId}`,
      await this.getRequestConfig()
    );

    // If the response is defined and OK, return the record. Else, return null.
    if (response !== null && response !== undefined && response.status === HttpStatusCode.Ok) {
      logRecord('SF', objectName, { Id: recordId, ...this.getFieldsToLog(response.data) }, undefined, logs);
      return response.data;
    }
    return null;
  }

  /**
   * Returns the single record matching the NetSuite Class.
   * @param {SfObjectApiName} objectName
   * @param {netSuiteId} netSuiteClass
   * @returns {Promise<T>}
   */
  public async getRecordByNetSuiteClassAsync<T>(objectName: SfObjectApiName, netSuiteClass: string): Promise<T> {
    return await this.getRecordByQueryConditionAsync<T>(objectName, `NetSuite_Class__c = '${netSuiteClass}'`);
  }

  /**
   * Returns the single record matching the NetSuite ID.
   * @param {SfObjectApiName} objectName
   * @param {netSuiteId} netSuiteId
   * @returns {Promise<T>}
   */
  public async getRecordByNetSuiteIdAsync<T>(objectName: SfObjectApiName, netSuiteId: number): Promise<T> {
    return await this.getRecordByQueryConditionAsync<T>(objectName, `NetSuite_ID__c = '${netSuiteId}'`);
  }

  /**
   * Returns the single record matching the query condition.
   * @param {SfObjectApiName} objectName
   * @param {string} queryCondition
   * @returns {Promise<T>}
   */
  public async getRecordByQueryConditionAsync<T>(objectName: SfObjectApiName, queryCondition: string): Promise<T> {

    // Retrieve the single record ID matching the query condition.
    const recordIds = await this.getRecordIdsByQueryConditionAsync(objectName, queryCondition);
    expect(recordIds.length).toEqual(1);

    // Get the record from the ID.
    return must(await this.getRecordAsync<T>(objectName, recordIds[0]));
  }

  /**
   * Returns the record IDs matching the NetSuite class.
   * @param {SfObjectApiName} objectName
   * @param {string} netSuiteClass
   * @returns {Promise<string[]>} The array of record IDs.
   */
  public async getRecordIdsByNetSuiteClassAsync(objectName: SfObjectApiName, netSuiteClass: string): Promise<string[]> {
    return await this.getRecordIdsByQueryConditionAsync(objectName, `NetSuite_Class__c = '${netSuiteClass}'`);
  }

  /**
   * Returns the record IDs matching the NetSuite ID.
   * @param {SfObjectApiName} objectName
   * @param {number} netSuiteId
   * @returns {Promise<string[]>} The array of record IDs.
   */
  public async getRecordIdsByNetSuiteIdAsync(objectName: SfObjectApiName, netSuiteId: number): Promise<string[]> {
    return await this.getRecordIdsByQueryConditionAsync(objectName, `NetSuite_ID__c = '${netSuiteId}'`);
  }

  /**
   * Returns all record IDs matching the given object name and query condition.
   * @param {SfObjectApiName} objectName
   * @param {string} queryCondition
   * @returns {Promise<string[]>} The array of record IDs.
   */
  public async getRecordIdsByQueryConditionAsync(objectName: SfObjectApiName, queryCondition: string): Promise<string[]> {

    // Send GET SOQL request to retrieve the records for the given object name and query condition.
    const response = await this.getSoqlQuery<{ Id: string }>(`SELECT Id FROM ${objectName} WHERE ${queryCondition}`);

    // If the response is defined and OK, returns all IDs. Else, return null.
    if (response !== null && response !== undefined && response.status === HttpStatusCode.Ok) {
      return response.data.records.map(r => r.Id);
    }
    throw new Error(`Cannot retrieve ${objectName} records for ${queryCondition}.`
      + `Status: ${response.status} ${response.statusText}`
    );
  }

  /**
   * Creates a record of the given type.
   * @param {SfObjectApiName} objectName
   * @param {Any} record
   * @returns {Promise<string>}
   */
  public async createRecordAsync(objectName: SfObjectApiName, record: Any): Promise<string> {

    // Send POST request to create the record.
    const response = await this.post(
      `${this.baseUrl}${SfApiPath.SObjects}/${objectName}/`,
      record,
      await this.getRequestConfig()
    );
    throwsIfTrue(response.status !== HttpStatusCode.Created, `Cannot create the record '${objectName}'.`
      + `\nRecord data:  ${JSON.stringify(record)}`
      + `\nResponse status: ${response.status} ${response.statusText}`
    );
    logRecord('SF', objectName, { Id: response.data.id, ...this.getFieldsToLog(record) }, 'CREATED');
    return response.data.id;
  }

  /**
   * Updates a record of the given type.
   * @param {SfObjectApiName} objectName
   * @param {string} recordId
   * @param {Any} record
   * @returns {Promise<string>}
   */
  public async updateRecordAsync(objectName: SfObjectApiName, recordId: string, record: Any, isObjectMetadata = false): Promise<string> {

    // Send PATCH request to create the record.
    const response = await this.patch(
      `${this.baseUrl}${isObjectMetadata ? SfApiPath.SObjectsMetadata : SfApiPath.SObjects}/${objectName}/${recordId}`,
      record,
      await this.getRequestConfig()
    );
    throwsIfTrue(response.status !== HttpStatusCode.NoContent, `Cannot update the record '${objectName}' with ID ${recordId}.`
      + `\nRecord data:  ${JSON.stringify(record)}`
      + `\nResponse status: ${response.status} ${response.statusText}`
    );
    logRecord('SF', objectName, { Id: recordId, ...this.getFieldsToLog(record) }, 'UPDATED');
    return response.data.id;
  }

  /**
   * Deletes the record for the given object name and ID.
   * @param {SfObjectApiName} objectName
   * @param {recordId} recordId
   */
  public async deleteRecordAsync(objectName: SfObjectApiName, recordId: string): Promise<void> {

    // Send DELETE request to remove the record.
    const response = await this.delete(
      `${this.baseUrl}${SfApiPath.SObjects}/${objectName}/${recordId}`,
      await this.getRequestConfig()
    );
    expect(response.status).toEqual(HttpStatusCode.NoContent);
    logRecord('SF', objectName, { Id: recordId }, 'DELETED');
  }

  /**
   * Gets account by Net Suite Customer Id.
   * @param nsCustomerId Net Suite Customer Id
   * @returns api response
   */
  public async getAccountByNsId(nsCustomerId: number): Promise<
    RecordsResponse<{
      Id: string;
    }>
  > {
    return this.getSoqlQuery<{ Id: string }>(`SELECT Id FROM Account WHERE NetSuite_ID__c = '${nsCustomerId}'`);
  }

  /**
   * Gets contacts of account
   *
   * @param {string} sfAccountId
   * @return {*}  {Promise<
   *     RecordsResponse<{
   *       Id: string;
   *     }>
   *   >}
   * @memberof SfApiClient
   */
  public async getContactsByAccountId(sfAccountId: string): Promise<
    RecordsResponse<{
      Id: string;
    }>
  > {
    return this.getSoqlQuery<{ Id: string }>(`SELECT Id FROM Contact WHERE AccountId = '${sfAccountId}'`);
  }

  /**
   * Gets contact by Net Suite Contact Id.
   * @param nsContactId Net Suite Contact Id
   * @returns api response
   */
  public async getContactByNsId(nsContactId: number): Promise<
    RecordsResponse<{
      Id: string;
    }>
  > {
    return this.getSoqlQuery<{ Id: string }>(`SELECT Id FROM Contact WHERE NetSuite_ID__c = '${nsContactId}'`);
  }

  /**
   * Gets opportunity by NetSuite Id.
   * @returns api response
   */
  public async getOpportunityByNsId(nsSubscriptionId: number): Promise<
    RecordsResponse<{
      Id: string;
    }>
  > {
    return this.getSoqlQuery<{ Id: string }>(`SELECT Id FROM Opportunity WHERE NetSuite_ID__c = '${nsSubscriptionId}'`);
  }

  /**
   * Gets opportunity fields by Id.
   * @returns api response
   */
  public async getOpportunityById(id: string): Promise<RecordsResponse<OpportunityRec>> {
    return await this.getSoqlQuery(`
    SELECT 
      Id,
      CloseDate,
      CurrencyIsoCode,
      Current_ARR__c,
      Current_Billing_Term__c,
      Current_Product__c,
      Current_Subscription_End_Date__c,
      Current_Subscription_Start_Date__c,
      Current_Success_Level__c,
      Current_TCV__c,
      Current_Term__c,
      Description,
      Draft_Renewal_Subscription_Name__c,
      Loss_Reason__c,
      Name,
      NetSuite_ID__c,
      Parent_Subscription_ID__c,
      Parent_Subscription_Name__c,
      Pricebook2Id,
      Product__c,
      Renewal_Date__c,
      StageName,
      Ready_for_Invoice_Request__c,
      Provisioning_Ticket__c,
      SBQQ__PrimaryQuote__c,
      Win_Type__c
    FROM Opportunity WHERE ID='${id}'`);
  }

  // Common SOQL part of product selection
  getProductQueryBase = `
  SELECT Id,
  IsActive,
  Name,
  ProductCode,
  Deployment_Type__c,
  NetSuite_ID__c,
  Family,
  Product__c,
  Min_Quantity__c,
  StockKeepingUnit,
  Product_Edition__c,
  (SELECT
  SBQQ__OptionalSKU__r.Id,
  SBQQ__OptionalSKU__r.IsActive,
  SBQQ__OptionalSKU__r.Name,
  SBQQ__OptionalSKU__r.ProductCode,
  SBQQ__OptionalSKU__r.Deployment_Type__c,
  SBQQ__OptionalSKU__r.NetSuite_ID__c,
  SBQQ__OptionalSKU__r.Family,
  SBQQ__OptionalSKU__r.Product__c,
  SBQQ__OptionalSKU__r.Min_Quantity__c,
  SBQQ__OptionalSKU__r.StockKeepingUnit,
  SBQQ__OptionalSKU__r.Product_Edition__c
  FROM SBQQ__Options__r),
(SELECT CurrencyIsoCode, UnitPrice FROM PricebookEntries),
(SELECT CurrencyIsoCode, SBQQ__LowerBound__c, SBQQ__UpperBound__c, SBQQ__Price__c FROM SBQQ__BlockPrices__r)
  FROM Product2`;

  /**
   * Get product by Id.
   * @param id Product Id
   * @returns Product data
   */
  public async getProductByNetSuiteId(netSuiteId: number | string): Promise<RecordsResponse<ProductRec>> {
    return await this.getSoqlQuery(`
    ${this.getProductQueryBase}
    WHERE NetSuite_ID__c='${netSuiteId}'`);
  }

  /**
   * Get product by Id.
   * @param id Product Id
   * @returns Product data
   */
  public async getProductById(productId: string): Promise<RecordsResponse<ProductRec>> {
    return await this.getSoqlQuery(`
    ${this.getProductQueryBase}
    WHERE Id='${productId}'`);
  }

  /**
   * Gets opportunity products
   * @returns api response
   */
  public async getOpportunityProducts(opportunityId: string): Promise<RecordsResponse<OpportunityProductRec>> {
    return this.getSoqlQuery(`
    SELECT
      Id,
      OpportunityId,
      Product2Id,
      PricebookEntry.Product2.ProductCode,
      PricebookEntry.Product2.NetSuite_ID__c,
      PricebookEntry.Product2.Min_Quantity__c,      
      Quantity,
      Subscription_Term__c,
      TotalPrice
    FROM OpportunityLineItem WHERE OpportunityId = '${opportunityId}' order by CreatedDate`);
  }

  /**
   * Removes the SalesForce account.
   * @param accountId Sf Account Id
   * @returns status code
   */
  public deleteAccount(accountId: string): Promise<number> {
    return this.getRequestConfig()
      .then((token) => this.axiosWithRetry.delete(`${this.baseUrl}${SfApiPath.Account}/${accountId}`, token))
      .then((response) => {
        return response.status;
      });
  }

  /**
   * Removes the SalesForce contact.
   * @param contactId Sf Contact Id
   * @returns status code
   */
  public deleteContact(contactId: string): Promise<number> {
    return this.getRequestConfig()
      .then((token) => this.axiosWithRetry.delete(`${this.baseUrl}${SfApiPath.Contact}/${contactId}`, token))
      .then((response) => {
        return response.status;
      });
  }

  /**
   * Removes the SalesForce task.
   * @param taskId Sf Task Id
   * @returns status code
   */
  public deleteTask(taskId: string): Promise<number> {
    return this.getRequestConfig()
      .then((token) => this.axiosWithRetry.delete(`${this.baseUrl}${SfApiPath.Task}/${taskId}`, token))
      .then((response) => {
        return response.status;
      });
  }

  /**
   * Removes the SalesForce opportunity.
   * @param opportunityId Sf Opportunity Id
   * @returns status code
   */
  public async deleteOpportunity(opportunityId: string): Promise<number> {
    return await this.deleteEntity(opportunityId, SfApiPath.Opportunity);
  }

  /**
   * Removes the SalesForce Reseller Agreement.
   * @param resellerAgreementId resellerAgreementId
   * @returns status code
   */
  public async deleteResellerAgreement(resellerAgreementId: string): Promise<number> {
    return await this.deleteEntity(resellerAgreementId, SfApiPath.ResellerAgreement);
  }

  /**
   * Removes the SalesForce partner.
   * @param partnerId partnerId
   * @returns status code
   */
  public async deletePartner(partnerId: string): Promise<number> {
    return await this.deleteEntity(partnerId, SfApiPath.Partner);
  }

  /**
   * Removes SalesForce entity.
   * @param entityApiName API name of the entity
   * @param id Id
   * @returns status code
   */
  public async deleteEntity(id: string, entityApiName: string): Promise<number> {
    return (await this.delete(`${this.baseUrl}${entityApiName}/${id}`, await this.getRequestConfig())).status;
  }

  /**
   * Gets account data by id.
   * @param accountId Sf Account Id
   * @returns account data
   */
  public async getAccount(accountId: string): Promise<SfAccount | null> {
    return this.get(`${this.baseUrl}${SfApiPath.Account}/${accountId}`, await this.getRequestConfig(), true).then(
      (response) => {
        return response?.data;
      }
    );
  }

  /**
   * Creates account.
   * @param accountId Sf Account Id
   * @returns account data
   */
  public async createAccount(data: AccountData & { Name: string; NetSuite_ID__c: string }): Promise<string> {
    const resp = await this.post(`${this.baseUrl}${SfApiPath.Account}`, data, await this.getRequestConfig());

    return resp.data.id;
  }

  /**
   * Creates Reseller Agreement.
   * @param data reseller agreement data
   * @returns reseller agreement id
   */
  public async createResellerAgreement(data: ResellerAgreementData): Promise<string> {
    const resp = await this.post(`${this.baseUrl}${SfApiPath.ResellerAgreement}`, data, await this.getRequestConfig());

    return resp.data.id;
  }

  /**
   * Updates account.
   * @param accountId Sf Account Id
   * @returns account data
   */
  public updateAccount(accountId: string, data: AccountData): Promise<HttpStatusCode> {
    return this.getRequestConfig()
      .then((requestConfig) => this.axiosWithRetry.patch(`${this.baseUrl}${SfApiPath.Account}/${accountId}`, data, requestConfig))
      .then((response) => {
        return response.status;
      });
  }

  /**
   * Updates contact.
   * @param contactId Sf Contact Id
   * @returns contact data
   */
  public updateContact(
    contactId: string,
    data: {
      Salutation?: string;
      FirstName?: string;
      LastName?: string;
      MiddleName?: string;
      Title?: string;
      Email?: string;
      Phone?: string;
      MobilePhone?: string;
      Fax?: string;
      Description?: string;
    }
  ): Promise<HttpStatusCode> {
    return this.getRequestConfig()
      .then((requestConfig) => this.axiosWithRetry.patch(`${this.baseUrl}${SfApiPath.Contact}/${contactId}`, data, requestConfig))
      .then((response) => {
        return response.status;
      });
  }

  /**
   * Updates SalesForce record
   *
   * @param {string} recordId
   * @param {string} sobjectApiName
   * @param {Any} data
   * @return {*}  {Promise<HttpStatusCode>}
   * @memberof SfApiClient
   */
  public updateRecord(recordId: string, sobjectApiName: string, data: Any): Promise<HttpStatusCode> {
    return this.getRequestConfig()
      .then((requestConfig) => this.patch(`${this.baseUrl}${sobjectApiName}/${recordId}`, data, requestConfig))
      .then((response) => {
        return response.status;
      });
  }

  /**
   * Updates opportunity stage
   *
   * @param {string} opportunityId
   * @param {string} stageName
   * @return {*}  {Promise<HttpStatusCode>}
   * @memberof SfApiClient
   */
  public updateOpportunityStage(opportunityId: string, stageName: string): Promise<HttpStatusCode> {

    // Default data, including the new stage name.
    let data: Any = {
      StageName: stageName,
    };

    // Specific data, based on the stage name.
    if (stageName === 'Final Quote') {
      data = {
        ...data,
        Addresses_Validated__c: true,
      };
    }

    // Update the record.
    return this.updateRecord(opportunityId, SfApiPath.Opportunity, data);
  }

  /**
   * updates opportunity Owner
   *
   * @param {string} opportunityId
   * @param {string} ownerName
   * @return {*}  {Promise<HttpStatusCode>}
   * @memberof SfApiClient
   */
  public async updateOpportunityOwner(opportunityId: string, ownerId: string): Promise<HttpStatusCode> {
    return await this.updateRecord(opportunityId, SfApiPath.Opportunity, {
      OwnerId: ownerId,
    });
  }

  /**
   * updates opportunity AddressesValidated
   *
   * @param {string} opportunityId
   * @param {boolean} newValue
   * @return {*}  {Promise<HttpStatusCode>}
   * @memberof SfApiClient
   */
  public async updateOpportunityAddressesValidated(opportunityId: string, newValue: boolean): Promise<HttpStatusCode> {
    return await this.updateRecord(opportunityId, SfApiPath.Opportunity, {
      Addresses_Validated__c: newValue,
    });
  }

  /**
   * Updates opportunity ManualO2cFlag
   *
   * @param {string} opportunityId
   * @param {boolean} manualO2cFlag
   * @return {*}  {Promise<HttpStatusCode>}
   * @memberof SfApiClient
   */
  public async updateOpportunityManualO2cFlag(
    opportunityId: string,
    manualO2cFlag: boolean,
    o2cManuallyReason?: string
  ): Promise<HttpStatusCode> {
    return await this.updateRecord(opportunityId, SfApiPath.Opportunity, {
      Process_O2C_Manually__c: manualO2cFlag,
      Process_O2C_Manually_Reason__c: o2cManuallyReason,
    });
  }

  /**
   * Updates opportunity LossReason
   *
   * @param {string} opportunityId
   * @param {string} lossReason
   * @returns {*} {Promise<HttpStatusCode>}
   */
  public async updateOpportunityLossReason(
    opportunityId: string,
    lossReason: string
  ): Promise<HttpStatusCode> {
    return await this.updateRecord(opportunityId, SfApiPath.Opportunity, {
      Loss_Reason__c: lossReason,
    });
  }

  public updateOpportunityCancelationNotice(opportunityId: string, url: string): Promise<HttpStatusCode> {
    return this.updateRecord(opportunityId, SfApiPath.Opportunity, {
      Cancelation_Notice__c: url,
    });
  }

  /**
   * Updates contact cleaning contact netsuite id.
   * @param contactId Sf Contact Id
   * @returns contact data
   */
  public cleanContactNetSuiteid(contactId: string): Promise<HttpStatusCode> {
    return this.getRequestConfig()
      .then((requestConfig) =>
        this.axiosWithRetry.patch(`${this.baseUrl}${SfApiPath.Contact}/${contactId}`, { NetSuite_ID__c: null }, requestConfig)
      )
      .then((response) => {
        return response.status;
      });
  }

  /**
   * Gets contact data by id.
   * @param contactId Sf Contact Id
   * @returns contact data
   */
  public async getContact(contactId: string): Promise<SfContact | null> {
    return this.get(`${this.baseUrl}${SfApiPath.Contact}/${contactId}`, await this.getRequestConfig(), true).then(
      (response) => {
        return response?.data;
      }
    );
  }

  /**
   * Waits until the record is created and returns it
   * @param fn The record get function
   * @returns get record api response
   */
  public async getRecUntilItIsCreated<T>(fn: (context: IRetryContext) => PromiseLike<T> | T): Promise<T> {
    return await doOperationUntilCondition<T>(
      fn,
      (resp: Any) => resp.status === HttpStatusCode.Ok && resp.data && resp.data.totalSize && resp.data.totalSize !== 0,
      waitForRecMaxDelay,
      waitForRecInitialDelay,
      waitForRecMaxAttempts
    );
  }

  /**
   * Waits until records are created and return them
   * @param fn The records get function
   * @returns records
   */
  public async getRecsUntilTheyAppear<T>(
    fn: (context: IRetryContext) => PromiseLike<RecordsResponse<T>> | RecordsResponse<T>,
    fnIsOk: (resp: RecordsResponse<T>) => boolean
  ): Promise<RecordsResponse<T>> {
    return await doOperationUntilCondition<RecordsResponse<T>>(
      fn,
      (res: Any) =>
        res.status === HttpStatusCode.Ok &&
        res.data &&
        res.data.totalSize &&
        res.data.totalSize !== 0 &&
        res.data.records.length !== 0 &&
        fnIsOk(res),
      waitForRecMaxDelay,
      waitForRecInitialDelay,
      waitForRecMaxAttempts
    );
  }

  /**
   * Create quote.
   * @returns quote id
   */
  public async createQuote(params: {
    opportunityId: string;
    accountId: string;
    contactId: string;
    startDate: string;
  }): Promise<Any> {
    const result = await this.getOpportunityProducts(params.opportunityId);
    const products = result.data.records;

    const quoteId = (
      await this.post(
        `${this.baseUrl}${SfApiPath.Quote}`,
        {
          SBQQ__Primary__c: true,
          SBQQ__Opportunity2__c: params.opportunityId,
          SBQQ__Account__c: params.accountId,
          SBQQ__PrimaryContact__c: params.contactId,
          SBQQ__StartDate__c: params.startDate,
        },
        await this.getRequestConfig()
      )
    ).data.id;

    const quoteLineIds = await this.createQuoteLines(quoteId, products);

    return {
      quoteId: quoteId,
      quoteLineIds: quoteLineIds,
    };
  }

  private async createQuoteLines(quoteId: string, oppProducts: OpportunityProductRec[]): Promise<string[]> {
    const quoteLineIds: string[] = [];

    // Creates a default quote line data.
    const createDefaultQuoteLineData: (product: OpportunityProductRec) => SfQuoteLine = (product: OpportunityProductRec) => {
      return {
        SBQQ__Quote__c: quoteId,
        SBQQ__Product__c: product.Product2Id,
        SBQQ__SubscriptionTerm__c: product.Subscription_Term__c,
        SBQQ__Quantity__c: product.Quantity > product.PricebookEntry.Product2.Min_Quantity__c ? product.Quantity : product.PricebookEntry.Product2.Min_Quantity__c,
      }
    };

    // Determine the main bundle (assuming only one).
    const bundleMinimumSubCodesCount = 5;
    const bundle = oppProducts.single(p => p.PricebookEntry.Product2.ProductCode.split('-').length >= bundleMinimumSubCodesCount);

    // Create the quote line for the main bundle.
    const bundleQuoteLineData = createDefaultQuoteLineData(bundle);
    bundleQuoteLineData.SBQQ__Bundle__c = true;
    const bundleQuoteLineId = await this.createQuoteLineAsync(bundleQuoteLineData);
    quoteLineIds.push(bundleQuoteLineId);

    // Retrieve the product options related to the bundle and their definitions (assuming all are options defined in the bundle).
    const productOptions = oppProducts.filter(p => p.PricebookEntry.Product2.ProductCode.split('-').length < bundleMinimumSubCodesCount);
    const productOptionsDef = await this.getProductOptionsAsync(bundle?.Product2Id);

    // Create a quote line for each options.
    for (const product of productOptions) {
      const productOptionDef = productOptionsDef.single(o => o.SBQQ__ProductCode__c === product.PricebookEntry.Product2.ProductCode);
      const quoteLineData: SfQuoteLine = createDefaultQuoteLineData(product);
      this.setQuoteLineByProductOption(quoteLineData, bundleQuoteLineId, productOptionDef);
      const quoteLineId = await this.createQuoteLineAsync(quoteLineData);
      quoteLineIds.push(quoteLineId);
    }

    return quoteLineIds;
  }

  /**
   * Creates a quote line for given data.
   * @param {SfQuoteLine} quoteLine The quote line.
   * @returns {Promise<string>} The identifier of the quote line.
   */
  private async createQuoteLineAsync(quoteLine: SfQuoteLine): Promise<string> {
    const resp = await this.post(`${this.baseUrl}${SfApiPath.QuoteLine}`, quoteLine, await this.getRequestConfig());
    return resp.data.id;
  }

  /**
   * Returns the product options for the given bundle and product code.
   * @param {string} bundleId The identifier of the bundle.
   * @param {string} [productCode] The product code.
   * @returns {Promise<SfProductOption[]>} The product options.
   */
  private async getProductOptionsAsync(bundleId: string, productCode?: string): Promise<SfProductOption[]> {

    // Build the query to retrieve the product options.
    let query = `
      SELECT Id, SBQQ__ProductCode__c, SBQQ__Bundled__c, SBQQ__Type__c
      FROM SBQQ__ProductOption__c
      WHERE SBQQ__ConfiguredSKU__c = '${bundleId}'
    `;
    if (productCode) {
      query += ` and SBQQ__ProductCode__c = '${productCode}'`;
    }

    // Execute the query and return the records.
    const productOptionsResult = await this.getSoqlQuery<SfProductOption>(query);
    return productOptionsResult.data.records;
  }

  /**
   * Sets the quote line data for the given product option.
   * @param {SfQuoteLine} quoteLine The quote line data.
   * @param bundleQuoteLineId The identifier of the quote line for the bundle.
   * @param productOption The product option.
   * @returns {void}
   */
  private setQuoteLineByProductOption(quoteLine: SfQuoteLine, bundleQuoteLineId: string, productOption: SfProductOption): void {
    quoteLine.SBQQ__Bundled__c = productOption.SBQQ__Bundled__c;
    quoteLine.SBQQ__OptionLevel__c = '1.0';
    quoteLine.SBQQ__OptionType__c = productOption.SBQQ__Type__c;
    quoteLine.SBQQ__ProductOption__c = productOption.Id;
    quoteLine.SBQQ__RequiredBy__c = bundleQuoteLineId;
  }

  /**
   * Create quote.
   * @returns quote id
   */
  public async addProductToQuote(params: {
    quoteId: string;
    productId: string;
    productCode: string;
    quantity: number;
  }): Promise<string> {

    // Default data.
    const quoteLine: SfQuoteLine = {
      SBQQ__Quote__c: params.quoteId,
      SBQQ__Product__c: params.productId,
      SBQQ__SubscriptionTerm__c: 12,
      SBQQ__Quantity__c: params.quantity,
    };

    // Retrieve the bundle product from the quote lines (assuming there is one and only one bundle).
    const bundleProductIdResult = await this.getSoqlQuery<SfQuoteLine>(`
      SELECT Id, SBQQ__Product__c
      FROM SBQQ__QuoteLine__c
      WHERE SBQQ__Quote__c = '${params.quoteId}' and SBQQ__Bundle__c = true
    `);
    throwsIfTrue(bundleProductIdResult.data.totalSize !== 1, 'The assumption of having one and only one bundle product is not met.');
    const bundleQuoteLine = bundleProductIdResult.data.records[0] as SfQuoteLine;

    // Retrieve the product option of the additional product for the bundle (assuming all are options defined in the bundle).
    const productOptions = await this.getProductOptionsAsync(must(bundleQuoteLine.SBQQ__Product__c), params.productCode);
    throwsIfTrue(productOptions.length === 0, `The product options for the product '${params.productCode}' in the bundle '${bundleQuoteLine.SBQQ__Product__c}' are not found.`);

    // Set the quote line data, then create it.
    this.setQuoteLineByProductOption(quoteLine, must(bundleQuoteLine.Id), productOptions[0]);
    return await this.createQuoteLineAsync(quoteLine);
  }

  /**
   * Accept quote
   * @returns api response
   */
  public setQuoteStatus(quoteId: string, newStatus = 'Accepted'): Promise<HttpStatusCode> {
    return this.getRequestConfig()
      .then((requestConfig) =>
        this.axiosWithRetry.patch(`${this.baseUrl}${SfApiPath.Quote}/${quoteId}`, { SBQQ__Status__c: newStatus }, requestConfig)
      )
      .then((response) => {
        return response.status;
      });
  }

  /**
   * Gets Quote by id
   *
   * @param {string} quoteId
   * @return {*}  {Promise<QuoteRec?>}
   * @memberof SfApiClient
   */
  public async getQuote(quoteId: string): Promise<SfQuoteRec | null> {
    return this.get(`${this.baseUrl}${SfApiPath.Quote}/${quoteId}`, await this.getRequestConfig(), true).then(
      (response) => {
        return response?.data;
      }
    );
  }

  /**
   * Gets object data by id.
   * @returns object data
   */
  public getSobject(objectType: string, objectId: string): Promise<Any> {
    return this.getRequestConfig()
      .then((requestConfig) =>
        this.axiosWithRetry.get(`${this.baseUrl}services/data/v55.0/sobjects/${objectType}/${objectId}`, requestConfig)
      )
      .then((response) => {
        return response.data;
      });
  }

  /**
   * Gets opportunity by NetSuite Id.
   * @returns api response
   */
  public async getUserIdByName(userName: string): Promise<{ Id: string; Name: string; Email: string }> {
    const usersResp = await this.getSoqlQuery<{ Id: string; Name: string; Email: string }>(
      `SELECT Id, Name, Email FROM User where Name='${userName}'`
    );

    if (
      usersResp.data.totalSize !== 1 ||
      !usersResp.data.records ||
      usersResp.data.records.length !== 1 ||
      !usersResp.data.records[0].Id
    ) {
      throw new Error(
        `Unexpected records count when getting user by name ${userName}. Response ${toDescriptionString(
          usersResp.data
        )}.`
      );
    }

    return usersResp.data.records[0];
  }

  /**
   * Gets subsudiary by Name.
   * @returns api response
   */
  public async getSubsidiaryByName(subsidiaryNamePart: string): Promise<{ Id: string; Name: string }> {
    const resp = await this.getSoqlQuery<{ Id: string; Name: string; Email: string }>(
      `SELECT Id, Name FROM Subsidiary__c where Name like '%${subsidiaryNamePart}%'`
    );

    if (resp.data.totalSize === 0 || !resp.data.records || resp.data.records.length === 0 || !resp.data.records[0].Id) {
      throw new Error(
        `Unexpected records count when getting subsidiary by name ${subsidiaryNamePart}. Response ${JSON.stringify(
          resp.data
        )}.`
      );
    }

    return resp.data.records[0];
  }

  public async getTaskRelatedToOpportunityBySubject(sfOpportunityId: string, subject: string): Promise<string[]> {
    const resp = await this.getSoqlQuery<{ Id: string; Subject: string }>(
      `SELECT Id, Subject FROM Task where WhatId='${sfOpportunityId}' and Subject='${subject}'`
    );
    if (!resp.data.records) {
      throw new Error(
        `Unexpected response when getting tasks related to opportunity ${sfOpportunityId} with subject ${subject}. Response ${toDescriptionString(
          resp.data
        )}.`
      );
    }

    return resp.data.records.map((task) => task.Id);
  }

  public async linkResellerAgreementToOpportunity(
    sfOpportunityId: string,
    sfResellerAccountId: string
  ): Promise<string[]> {
    // link reseller to the opportunity and return the partnerId
    return (
      await this.post(
        `${this.baseUrl}${SfApiPath.Partner}`,
        {
          Role: 'VAR/Reseller',
          AccountToId: sfResellerAccountId,
          OpportunityId: sfOpportunityId,
          IsPrimary: true,
        },
        await this.getRequestConfig()
      )
    ).data.id;
  }

  public async runTaskDispatcherByName(taskDispatcherName: string): Promise<ActionInvocationResult<string>[]> {
    return (
      await this.post<ActionInvocationResult<string>[]>(
        `${this.baseUrl}${SfApiPath.TaskDispatchBatchV2Action}`,
        {
          inputs: [
            {
              taskDispatcherNames: taskDispatcherName,
            },
          ],
        },
        await this.getRequestConfig()
      )
    ).data;
  }

  public async getReportContent(reportId: string): Promise<ReportContent> {
    const reportContent = (
      await this.get<ReportContent>(
        `${this.baseUrl}${SfApiPath.Report}${reportId}?includeDetails=true`,
        await this.getRequestConfig()
      )
    )?.data;
    return must(reportContent);
  }

  public async getContentDocumentId(sfOpportunityId: string): Promise<
    RecordsResponse<{
      ContentDocumentId: string;
    }>
  > {
    return this.getSoqlQuery<{ ContentDocumentId: string }>(`SELECT ContentDocumentId FROM ContentDocumentLink WHERE LinkedEntityId = '${sfOpportunityId}' LIMIT 1`);
  }
}
