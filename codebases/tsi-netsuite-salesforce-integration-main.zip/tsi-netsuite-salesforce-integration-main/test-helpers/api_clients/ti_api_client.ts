import { AxiosRequestConfig, AxiosResponse } from 'axios';
import { Any, assertNotNullEnvVar, HttpStatusCode } from '../utils/types';
import { doOperationUntilCondition, log } from '../utils/utils';
import { ApiClient } from './api_client';

class TrayIOApiPath {
  public static SyncDraftRenewalFlow = 'https://c4c5f877-9e1a-4939-a5ec-ed3e5b581a77.trayapp.io';
  public static RunCallableFlowFlow = 'https://ec79b37b-f162-42bc-bbcb-f69d81740d22.trayapp.io';
  public static GetFlowState = 'https://6cef48cd-3935-455a-b70d-4f49f32308fc.trayapp.io';
  public static GetResultsForSubFlow = 'https://a5faa43a-03f4-415d-a887-5a79ea23dd2a.trayapp.io';
}

export enum FlowExecutionState {
  Completed,
  Failed,
  NotStartedOrInPrgrs,
}

export enum FlowRelatedEntityKind {
  ns_draft_renewal_subscription_id,
  ns_customer_id,
  ns_contact_id,
  ns_classification_id,
  ns_subsidiary_id,
  sf_contact_id,
  sf_quote_id,
  sf_opportunity_id,
  sf_opp_contact_role_id,
  ns_agreement_id,
  ns_subscription_plan,
  ns_quote_id,
}

export enum Workflow {
  TriggerCreateProvisioningZdTicket = '2f0ff8ad-c2a7-460c-a40a-93956efb0d4e',
  TriggerOnNsSubActivationCloseWinSfOpportunity = '0c3aa87f-81db-40a9-8742-56abd400a95f',
  TriggerOnNsSubTerminationCloseLostSfOpportunity = 'ceea1916-24b2-4b86-8fcb-5f47c0b05fbe',
}

export enum WorkflowKind {
  SyncSfRenewalOpportunityOnNsDraftRenewalSubscriptionActivated = 'syncDraftRenewalSubscriptionToSfRenewalOpportunityOnActivation',
  SyncSfRenewalOpportunityOnNsDraftRenewalSubscriptionTerminated = 'syncDraftRenewalSubscriptionToSfRenewalOpportunityOnTermination',
  SyncSfRenewalOpportunityOnNsDraftRenewalSubscriptionUpdated = 'syncDraftRenewalSubscriptionToSfRenewalOpportunity',
  ScheduledChangeOrderProcessing = 'scheduledChangeOrderProcessing',
  SubscriptionPlanSync = 'subscriptionPlanSync',
}

export enum GetResultDirectlyWorkflowKind {
  GetCurrentFields = 'getCurrentFields',
}

export interface FlowExecutionStateResponse {
  status: FlowExecutionState;
  timestamp: string;
}

/**
 * SalesForce REST API query helper.
 */
export class TrayIOApiClient extends ApiClient {

  private static getRequestConfig(): AxiosRequestConfig {
    assertNotNullEnvVar(process.env.TI_CsrfToken, 'TI_CsrfToken');
    return {
      headers: {
        'x-csrf-token': process.env.TI_CsrfToken,
        'Content-Type': 'application/json',
      },
    };
  }

  public async runCallableFlow(
    draftRenewalId: number,
    workflowKind: WorkflowKind
  ): Promise<Any> {
    return this.axiosWithRetry
      .post(
        TrayIOApiPath.RunCallableFlowFlow,
        {
          workflowData: {
            id: `${draftRenewalId}`,
          },
          workflowKind: workflowKind,
        },
        TrayIOApiClient.getRequestConfig()
      )
      .then((response) => {
        return response.status;
      });
  }

  public async runCallableFlowWithObjectParam(
    parameter: { id: string, changeOrderId?: number },
    workflowKind: WorkflowKind
  ): Promise<Any> {
    return this.axiosWithRetry
      .post(
        TrayIOApiPath.RunCallableFlowFlow,
        {
          workflowData: parameter,
          workflowKind: workflowKind,
        },
        TrayIOApiClient.getRequestConfig()
      )
      .then((response) => {
        return response.status;
      });
  }

  private async getFlowState(
    relatedEntityKind: FlowRelatedEntityKind,
    relatedEntityId: string,
    callingWorkflow?: Workflow,
  ): Promise<AxiosResponse<FlowExecutionStateResponse>> {
    return await this.axiosWithRetry.post(
      TrayIOApiPath.GetFlowState,
      {
        related_entity_kind: FlowRelatedEntityKind[relatedEntityKind],
        related_entity_id: relatedEntityId,
        calling_workflow: callingWorkflow,
      },
      TrayIOApiClient.getRequestConfig()
    );
  }

  public async waitForFlowCompletion(
    relatedEntityKind: FlowRelatedEntityKind,
    relatedEntityId: string,
    waitMaxDelayMs: number,
    waitInitialDelayMs: number,
    waitMaxAttempts: number,
    afterTimeStamp?: string,
    callingWorkflow?: Workflow,
  ): Promise<FlowExecutionStateResponse> {
    const wfExecutionStatus = await doOperationUntilCondition<AxiosResponse<FlowExecutionStateResponse>>(
      () => this.getFlowState(relatedEntityKind, relatedEntityId, callingWorkflow),
      (resp: AxiosResponse<FlowExecutionStateResponse>) =>
        resp.status === HttpStatusCode.Ok &&
        resp.data &&
        ((FlowExecutionState as Any)[resp.data.status] === FlowExecutionState.Completed ||
          (FlowExecutionState as Any)[resp.data.status] === FlowExecutionState.Failed) &&
        (!afterTimeStamp || (new Date(afterTimeStamp)) < (new Date(resp.data.timestamp))),
      waitMaxDelayMs,
      waitInitialDelayMs,
      waitMaxAttempts
    );

    const callingWorkflowRef = (callingWorkflow ? ` ${callingWorkflow}` : '');
    const workflowRef = `Workflow${callingWorkflowRef} for ${FlowRelatedEntityKind[relatedEntityKind]}:${relatedEntityId}`;
    log(`${workflowRef} is done with status ${wfExecutionStatus.data.status} on ${wfExecutionStatus.data.timestamp}.`);

    return wfExecutionStatus.data;
  }

  public async getFlowResultsDirectly(
    param: { subscription: number },
    workflowKind: GetResultDirectlyWorkflowKind
  ): Promise<Any> {
    return this.axiosWithRetry
      .post(
        TrayIOApiPath.GetResultsForSubFlow,
        {
          flow: workflowKind,
          ...param
        },
        TrayIOApiClient.getRequestConfig()
      )
      .then((response) => {
        return response.data;
      });
  }
}
