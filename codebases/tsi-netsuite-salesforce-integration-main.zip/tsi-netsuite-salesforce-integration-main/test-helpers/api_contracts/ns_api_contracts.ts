import { Any } from '../utils/types';

export enum NsSubscriptionStatusId {
  Active = 'ACTIVE',
  Draft = 'DRAFT',
  PendingActivation = 'PENDING_ACTIVATION',
  Terminated = 'TERMINATED',
}

export enum NsSubscriptionChangeOrderActionId {
  Activate = 'ACTIVATE',
  ModifyPricing = 'MODIFY_PRICING',
  Suspend = 'SUSPEND',
  Reactivate = 'REACTIVATE',
  Renew = 'RENEW',
  Terminate = 'TERMINATE',
}

export enum NsSubscriptionChangeOrderStatusId {
  Active = 'ACTIVE',
  Voided = 'VOIDED',
}

export enum NsSubLineElementStatusId {
  Active = 'ACTIVE',
  Draft = 'DRAFT',
  PendingActivation = 'PENDING_ACTIVATION',
  Terminated = 'TERMINATED',
}

export enum NsSubStatusChangeReason {
  CustomerActivated = 1,
  Churn = 2,
  AutoRenewed = 3,
  FinanceAction = 4,
  InvalidSubscription = 5
}

export interface FilterItem {
  id: number;
}

export interface FilterResponse {
  count: number;
  hasMore: boolean;
  items: FilterItem[];
  offset: number;
  totalResults: number;
}

export interface SubscriptionRec {
  links?: Link[];
  advanceRenewalPeriodNumber?: number;
  advanceRenewalPeriodUnit?: Ref;
  autoRenewal?: boolean;
  billingAccount?: Ref;
  billingAccountStartDate?: string;
  billingSchedule?: Ref;
  billingSubscriptionStatus?: Ref;
  class?: Ref;
  currency?: Ref;
  customer?: Ref;
  customForm?: Ref;
  custrecordBaseAmount?: number;
  custrecordIsautorenewal?: boolean;
  custrecordIstrial?: boolean;
  custrecord_contract_docs?: Ref;
  custrecord_memo?: string;
  custrecord_parent_subscription?: Ref;
  custrecord_subs_end_user?: Ref;
  custrecordistrial?: boolean;
  defaultRenewalMethod?: Ref;
  defaultRenewalPlan?: Ref;
  defaultRenewalTerm?: Ref;
  department?: Ref;
  endDate?: string;
  frequency?: Ref;
  id?: number;
  idNumber?: string;
  initialTerm?: Ref;
  name?: string;
  nextBillCycleDate?: string;
  nextRenewalStartDate?: string;
  priceBook?: Ref;
  priceInterval?: PriceIntervals;
  renewalNumber?: number;
  startDate?: string;
  subscriptionLine?: SubscriptionLines;
  subscriptionPlan?: Ref;
  subscriptionPlanName?: string;
  subscriptionRevision?: number;
  subsidiary?: Ref;
}

export interface Ref {
  links?: Link[];
  id?: string;
  refName?: string;
}

export interface Link {
  rel?: Rel;
  href?: string;
}

export enum Rel {
  Self = 'self',
}

export interface PriceIntervals {
  links?: Link[];
  items?: PriceInterval[];
  totalResults?: number;
}

export interface PriceInterval {
  links?: Link[];
  catalogType?: Ref;
  chargeType?: Ref;
  discount?: number;
  frequency?: Ref;
  id?: number;
  item?: Ref;
  lineNumber?: number;
  pricePlan?: Ref;
  prorateBy?: Ref;
  proratebyoption?: Ref;
  quantity?: number;
  recurringAmount?: number;
  repeatEvery?: number;
  startDate?: string;
  startOffsetValue?: number;
  status?: Ref;
  subscriptionPlanLineNumber?: number;
  totalintervalvalue?: number;
}

export interface SubscriptionLines {
  links?: Link[];
  items?: SubscriptionLine[];
  totalResults?: number;
}

export interface SubscriptionLine {
  links?: Link[];
  billingMode?: Ref;
  catalogType?: Ref;
  class?: Ref;
  department?: Ref;
  discount?: number;
  endDate?: string;
  includeInRenewal?: boolean;
  isIncluded?: boolean;
  isRequired?: boolean;
  item?: Ref;
  lineNumber?: number;
  planItem?: number;
  prorateEndDate?: boolean;
  prorateStartDate?: boolean;
  quantity?: number;
  recurrenceStartDate?: string;
  revRecOption?: Ref;
  startDate?: string;
  status?: Ref;
  subscriptionLine?: number;
  subscriptionLineType?: Ref;
}

export interface QueryResults<T> {
  links: Link[];
  count: number;
  hasMore: boolean;
  items: T[];
  offset: number;
  totalResults: number;
}

export interface NsQuoteRec {
  links?: Any[];
  id?: string;
  createddate?: string;
  customerid?: string;
  enduserid?: string;
  expirydate?: string;
  title?: string;
  status?: string;
  totalamount?: string;
  linecount?: string;
  agreementid?: string;
  agreementname?: string;
  agreementstatus?: string;
  euaagreementid?: string;
  euaagreementname?: string;
  subscriptionid?: number;
}

export interface NsQuoteLineRec {
  itemid: number;
  itemcode: string;
  itemdescription: string;
  linenumber: number;
  rate: number;
}

export interface NsAgreementDocRec {
  agreementid?: string;
  agreementtype?: string;
  documentid?: string;
}
export interface NsAgreementRecipientRec {
  id?: string;
  role?: string;
  email?: string;
  order?: string;
}

export interface NsSubscriptionChangeOrderRec {
  action?: Ref;
  effectiveDate?: string;
  id?: string;
  memo?: string;
  subLine: QueryResults<NsSubLineElementRec>;
  subscriptionChangeOrderStatus: Ref;
  terminateAtStartOfDay: boolean;
  custrecord_st_change_reason?: Ref;
}

export interface NsSubLineElementRec {
  apply?: boolean;
  includeInRenewal?: boolean;
  lineNumber?: number;
  status?: string;
  statusNew?: Ref;
}

export interface NsProductIntegration {
  id: number;
  autoprovisioning: string;
  supportbrand?: string;
  supportproduct?: string;
}

export interface NsClass {
  custrecord_cls_entity_japan?: Ref;
  custrecord_cls_entity_german?: Ref;
  custrecord_cls_entity_other?: Ref;
  custrecord_cls_entity_us_domestic?: Ref;
  custrecord_nspbcs_class_planning_cat?: number;
  id?: number;
  name?: string;
}

export interface NsSubsidiary {
  id?: number;
  name?: string;
  currency?: Ref;
  lastModifiedDate?: string;
  mainAddress?: NsAddress;
  parent?: Ref;
  state?: string;
}

export interface NsAddress {
  addr1?: string;
  addr2?: string;
  addressee?: string;
  city?: string;
  country?: Ref;
  state?: string;
  zip?: string;
}

export interface NsAddressBook {
  items?: NsAddressBookItem[]
}

export interface NsAddressBookItem {
  addressBookAddress?: NsAddress,
  defaultBilling?: boolean,
  defaultShipping?: boolean,
  isResidential?: boolean
}

export interface NsDefaultCustomerSubsidiary {
  custrecord_default_subsidiary_class?: Ref;
  custrecord_default_subsidiary_customer?: Ref;
  custrecord_default_subsidiary_subsidiary?: Ref;
  id?: number;
}

export interface NsCustomer {
  companyName?: string,
  custentity_customer_channel_tier?: Ref,
  email?: string,
  fax?: string,
  id?: number,
  phone?: string,
  subsidiary?: Ref,
  url?: string,
  addressBook?: NsAddressBook
}

export interface NsEmployee {
  email?: string,
  id?: number,
  issalesrep?: boolean,
  firstName?: string,
  giveAccess?: boolean,
  lastName?: string,
  password?: string,
  password2?: string,
  roles?: {
    items?: NsEmployeeRoleItem[],
  },
  subsidiary?: Ref,
  supervisor?: Ref,
}

export interface NsEmployeeRoleItem {
  selectedRole?: Ref,
}

export interface NsNonInventorySaleItem {
  class?: Ref,
  deferredrevenueaccount?: Ref,
  department?: Ref,
  custitem_item_category?: Ref,
  custitem_product_line?: Ref,
  custitem_product_tier?: Ref,
  custitem_quantity_type?: Ref,
  custitem_revenue_type?: Ref,
  custitem_support_level?: Ref,
  displayname?: string,
  incomeaccount?: Ref,
  itemid?: string,
  revenuerecognitionrule?: Ref,
}
