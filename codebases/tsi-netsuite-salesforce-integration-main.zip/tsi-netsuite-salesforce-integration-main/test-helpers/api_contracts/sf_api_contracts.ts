import { Any, HttpStatusCode } from '../utils/types';

export type RecordResponse<TRec> = TRec & { attributes?: Attributes };

export interface RecordsResponseData<TRec> {
  totalSize: number;
  done: boolean;
  records: RecordResponse<TRec>[];
}

export interface RecordsResponse<TRec> {
  status: HttpStatusCode;
  statusText: string;
  headers: Any;
  config: Any;
  request: Any;
  data: RecordsResponseData<TRec>;
}

export interface Attributes {
  type?: string;
  url?: string;
}

export interface OpportunityRec {
  CloseDate: string;
  CurrencyIsoCode: string;
  Current_ARR__c: number;
  Current_Billing_Term__c: string;
  Current_Product__c: string;
  Current_Subscription_End_Date__c: string;
  Current_Subscription_Start_Date__c: string;
  Current_Success_Level__c: string;
  Current_TCV__c: number;
  Current_Term__c: number;
  Description: string;
  Draft_Renewal_Subscription_Name__c: string;
  Id: string;
  Loss_Reason__c: string;
  Name: string;
  NetSuite_ID__c: string;
  Parent_Subscription_ID__c: string;
  Parent_Subscription_Name__c: string;
  Pricebook2Id: string;
  Product__c: string;
  Renewal_Date__c: string;
  StageName: string;
  Ready_for_Invoice_Request__c: boolean;
  Provisioning_Ticket__c: string;
  SBQQ__PrimaryQuote__c: string;
  Win_Type__c: string;
}

export interface ProductRec {
  Id: string,
  IsActive: boolean,
  Name: string,
  ProductCode: string,
  Deployment_Type__c: null,
  NetSuite_ID__c: string,
  Family: string,
  Product__c: string,
  Min_Quantity__c: number,
  StockKeepingUnit: string,
  Product_Edition__c: null,
  SBQQ__Options__r?: {
    totalSize: number,
    done: boolean,
    records: {
      SBQQ__OptionalSKU__r: ProductRec
    }[]
  },
  PricebookEntries: {
    totalSize: number,
    done: boolean,
    records: {
      CurrencyIsoCode: string,
      UnitPrice: number,
    }[]
  },
  SBQQ__BlockPrices__r: {
    totalSize: number,
    done: boolean,
    records: {
      CurrencyIsoCode: string,
      SBQQ__LowerBound__c: number,
      SBQQ__UpperBound__c: number,
      SBQQ__Price__c: number,
    }[]
  }
}


export interface OpportunityProductRec {
  Id: string;
  OpportunityId: string;
  PricebookEntry: {
    Product2: {
      NetSuite_ID__c: string;
      ProductCode: string;
      Min_Quantity__c: number;
    };
  };
  Product2Id: string;
  Quantity: number;
  Subscription_Term__c: number;
  TotalPrice: number;
}

export interface SfQuoteRec {
  Id?: string;
  OwnerId?: string;
  IsDeleted?: boolean;
  Name?: string;
  CurrencyIsoCode?: string;
  CreatedDate?: string;
  CreatedById?: string;
  LastModifiedDate?: string;
  LastModifiedById?: string;
  SystemModstamp?: string;
  LastActivityDate?: string;
  LastViewedDate?: string;
  LastReferencedDate?: string;
  SBQQ__Account__c?: string;
  SBQQ__AdditionalDiscountAmount__c?: number;
  SBQQ__AverageCustomerDiscount__c?: number;
  SBQQ__AveragePartnerDiscount__c?: number;
  SBQQ__BillingCity__c?: string;
  SBQQ__BillingCountry__c?: string;
  SBQQ__BillingFrequency__c?: string;
  SBQQ__BillingName__c?: string;
  SBQQ__BillingPostalCode__c?: string;
  SBQQ__BillingState__c?: string;
  SBQQ__BillingStreet__c?: string;
  SBQQ__ConsumptionRateOverride__c?: boolean;
  SBQQ__ContractingMethod__c?: string;
  SBQQ__CustomerDiscount__c?: number;
  SBQQ__DaysQuoteOpen__c?: number;
  SBQQ__DefaultTemplate__c?: string;
  SBQQ__DeliveryMethod__c?: string;
  SBQQ__DistributorDiscount__c?: number;
  SBQQ__Distributor__c?: string;
  SBQQ__DocumentStatus__c?: string;
  SBQQ__EmailTemplateId__c?: string;
  SBQQ__EndDate__c?: string;
  SBQQ__ExpirationDate__c?: string;
  SBQQ__FirstSegmentTermEndDate__c?: string;
  SBQQ__GenerateContractedPrice__c?: number;
  SBQQ__Introduction__c?: string;
  SBQQ__Key__c?: string;
  SBQQ__LastCalculatedOn__c?: string;
  SBQQ__LastSavedOn__c?: string;
  SBQQ__LineItemsGrouped__c?: boolean;
  SBQQ__LineItemsPrinted__c?: boolean;
  SBQQ__MarkupRate__c?: number;
  SBQQ__MasterContract__c?: string;
  SBQQ__MasterEvergreenContract__c?: string;
  SBQQ__Notes__c?: string;
  SBQQ__Opportunity2__c?: string;
  SBQQ__OrderByQuoteLineGroup__c?: boolean;
  SBQQ__OrderBy__c?: string;
  SBQQ__OrderGroupID__c?: string;
  SBQQ__Ordered__c?: boolean;
  SBQQ__OriginalQuote__c?: string;
  SBQQ__PaperSize__c?: string;
  SBQQ__PartnerDiscount__c?: string;
  SBQQ__Partner__c?: string;
  SBQQ__PaymentTerms__c?: string;
  SBQQ__PriceBook__c?: string;
  SBQQ__PricebookId__c?: string;
  SBQQ__PrimaryContact__c?: string;
  SBQQ__Primary__c?: boolean;
  SBQQ__ProrationDayOfMonth__c?: number;
  SBQQ__QuoteLanguage__c?: string;
  SBQQ__QuoteProcessId__c?: string;
  SBQQ__QuoteTemplateId__c?: string;
  SBQQ__RenewalTerm__c?: string;
  SBQQ__RenewalUpliftRate__c?: string;
  SBQQ__SalesRep__c?: string;
  SBQQ__ShippingCity__c?: string;
  SBQQ__ShippingCountry__c?: string;
  SBQQ__ShippingName__c?: string;
  SBQQ__ShippingPostalCode__c?: string;
  SBQQ__ShippingState__c?: string;
  SBQQ__ShippingStreet__c?: string;
  SBQQ__Source__c?: string;
  SBQQ__StartDate__c?: string;
  SBQQ__Status__c?: string;
  SBQQ__SubscriptionTerm__c?: string;
  SBQQ__TargetCustomerAmount__c?: string;
  SBQQ__TotalCustomerDiscountAmount__c?: number;
  SBQQ__Type__c?: string;
  SBQQ__Uncalculated__c?: boolean;
  SBQQ__Unopened__c?: boolean;
  SBQQ__WatermarkShown__c?: boolean;
  SBQQ__CustomerAmount__c?: number;
  SBQQ__LineItemCount__c?: number;
  SBQQ__ListAmount__c?: number;
  SBQQ__NetAmount__c?: number;
  SBQQ__RegularAmount__c?: number;
  Is_US__c?: boolean;
  Is_Not_US__c?: boolean;
  Service_Provider_Name__c?: string;
  US_Provider_Name__c?: string;
  Non_US_Provider_Name__c?: string;
  Service_Provider_City__c?: string;
  Service_Provider_Country__c?: string;
  Service_Provider_Postal_Code__c?: string;
  Service_Provider_State__c?: string;
  Service_Provider_Street__c?: string;
  Quote_Approver__c?: string;
  Line_Items_Footer_Text__c?: string;
  Has_Distributor_Discount__c?: boolean;
  Has_Mixed_Success_Level__c?: boolean;
  Has_Partner_Discount__c?: boolean;
  Line_Items_Header_Text__c?: string;
  Has_Free_Form_Text__c?: boolean;
  Is_Not_Blank_Free_Form_Text__c?: string;
  Product_Family__c?: string;
  Has_Quote_Notes_Free_Form_Text__c?: boolean;
  NetSuite_ID__c?: string;
  O2C_Ticket_Link__c?: string;
  Logo_URL__c?: string;
  Has_Line_Items_Footer_Text__c?: boolean;
  Billing_Type__c?: string;
  Service_Provider__c?: string;
}

export interface SfContact {
  Id?: string;
  IsDeleted: boolean;
  AccountId?: string;
  LastName?: string;
  FirstName?: string;
  Salutation?: string;
  MiddleName?: string;
  Suffix?: string;
  Name?: string;
  MailingStreet?: string;
  MailingCity?: string;
  MailingState?: string;
  MailingPostalCode?: string;
  MailingCountry?: string;
  MailingLatitude?: string;
  MailingLongitude?: string;
  MailingGeocodeAccuracy?: string;
  MailingAddress?: string;
  Phone?: string;
  Fax?: string;
  MobilePhone?: string;
  ReportsToId?: string;
  Email?: string;
  Title?: string;
  Department?: string;
  Description?: string;
  CurrencyIsoCode?: string;
  OwnerId?: string;
  HasOptedOutOfEmail: boolean;
  CreatedDate?: string;
  CreatedById?: string;
  LastModifiedDate?: string;
  LastModifiedById?: string;
  SystemModstamp?: string;
  LastActivityDate?: string;
  LastCURequestDate?: string;
  LastCUUpdateDate?: string;
  LastViewedDate?: string;
  LastReferencedDate?: string;
  EmailBouncedReason?: string;
  EmailBouncedDate?: string;
  IsEmailBounced: boolean;
  PhotoUrl?: string;
  Jigsaw?: string;
  JigsawContactId?: string;
  Currency__c?: string;
  External_ID__c?: string;
  IntAcct_ID__cv;
  Legacy_Reference_ID__c?: string;
  NetSuite_ID__c?: string;
  Vertical__c?: string;
  Central_Contact_ID__c?: string;
  Vertical_Temp__c?: string;
  Current_Product_Family__c?: string;
  Current_Opportunity_Stage__c?: string;
  Current_Renewal_Date__c?: string;
  Bad_Contact__c: boolean;
  Central_Account_ID__c?: string;
  Linked_To_Account__c: number;
  Central_Contact_ID_15__c?: string;
  Pardot_Comments__c?: string;
}

export interface SfAccount {
  Id?: string;
  IsDeleted?: boolean;
  MasterRecordId?: string;
  Name?: string;
  Type?: string;
  ParentId?: string;
  BillingStreet?: string;
  BillingCity?: string;
  BillingState?: string;
  BillingPostalCode?: string;
  BillingCountry?: string;
  BillingLatitude?: number;
  BillingLongitude?: number;
  BillingGeocodeAccuracy?: number;
  BillingAddress?: Address;
  ShippingStreet?: string;
  ShippingCity?: string;
  ShippingState?: string;
  ShippingPostalCode?: string;
  ShippingCountry?: string;
  ShippingLatitude?: number;
  ShippingLongitude?: number;
  ShippingGeocodeAccuracy?: number;
  ShippingAddress?: Address;
  Phone?: string;
  Fax?: string;
  Website?: string;
  PhotoUrl?: string;
  Industry?: string;
  NumberOfEmployees?: string;
  Description?: string;
  CurrencyIsoCode?: string;
  OwnerId?: string;
  CreatedDate?: string;
  CreatedById?: string;
  LastModifiedDate?: string;
  LastModifiedById?: string;
  SystemModstamp?: string;
  LastActivityDate?: string;
  LastViewedDate?: string;
  LastReferencedDate?: string;
  Jigsaw?: string;
  JigsawCompanyId?: string;
  AccountSource?: string;
  SicDesc?: string;
  Currency__c?: string;
  ARR__c?: number;
  ARR_Currency__c?: string;
  Central_Account_ID__c?: string;
  Central_Parent_ID__c?: string;
  Channel__c?: string;
  Application_Date__c?: string;
  IntAcct_ID__c?: string;
  NetSuite_ID__c?: string;
  Prime_ARR_Utilized__c?: number;
  Support_Expiration_Date__c?: string;
  Reseller_Agreement__c?: string;
  Central_Vertical__c?: string;
  Timezone__c?: string;
  UTC_Offset__c?: string;
  SBQQ__AssetQuantitiesCombined__c?: boolean;
  SBQQ__CoTermedContractsCombined__c?: boolean;
  SBQQ__CoTerminationEvent__c?: string;
  SBQQ__ContractCoTermination__c?: string;
  SBQQ__DefaultOpportunity__c?: string;
  SBQQ__IgnoreParentContractedPrices__c?: boolean;
  SBQQ__PreserveBundle__c?: boolean;
  SBQQ__PriceHoldEnd__c?: string;
  SBQQ__RenewalModel__c?: string;
  SBQQ__RenewalPricingMethod__c?: string;
  SBQQ__TaxExempt__c?: string;
  Zendesk_Id__c?: string;
  Active_Opportunities__c?: number;
  Billing_Account_Name__c?: string;
  CSM__c?: string;
  Product_Families__c?: string;
  Product_Billing_System_ID__c?: string;
  Health_Score__c?: number;
  Success_Level__c?: string;
}

export interface Address {
  city?: string;
  country?: string;
  geocodeAccuracy?: number;
  latitude?: number;
  longitude?: number;
  postalCode?: string;
  state?: string;
  street?: string;
}

export interface ActionInvocationResult<T> {
  actionName: string;
  errors: Any;
  isSuccess: boolean;
  outputValues: {
    output: T;
  };
}

export interface AccountData {
  Phone?: string;
  Fax?: string;
  Website?: string;
  BillingCountry?: string;
  BillingStreet?: string;
  BillingCity?: string;
  BillingState?: string;
  BillingPostalCode?: string;
  ShippingCountry?: string;
  ShippingStreet?: string;
  ShippingCity?: string;
  ShippingState?: string;
  ShippingPostalCode?: string;
}

export interface ResellerAgreementData {
  CurrencyIsoCode: string; // 'USD';
  Account__c: string; // '0012x00000X5LtIAAV'
  Reseller_Agreement_Link__c: string; // 'https://test.com';
  Subsidiary__c: string; // 'a2K2x000000gQ4NEAU';
}

export interface SfSubsidiary {
  Id?: string;
  Name?: string;
  CurrencyIsoCode?: string;
  City__c?: string;
  State__c?: string;
  Country__c?: string;
  Street__c?: string;
  Postal_Code__c?: string;
  Netsuite_Id__c?: string;
}

export interface SfProductConfiguration {
  Id?: string;
  Contacting_Entity_JP__c?: string;
  Contracting_Entity_US_and_AE__c?: string;
  Contracting_Entity_DE_and_AT__c?: string;
  Contracting_Entity_Other__c?: string;
  LastModifiedDate?: string;
  Name?: string;
  NetSuite_Class__c?: string;
  Product__c?: string;
}

export interface SfDefaultAccountSubsidiary {
  Id?: string;
  Account__c?: string;
  Product__c?: string;
  Subsidiary__c?: string;
}

export interface SfGlobalValueSet {
  Metadata: {
    customValue: SfGlobalValueSetValue[]
  },
  FullName: string
}

export interface SfGlobalValueSetValue {
  label: string,
  valueName: string
}

export interface SfUser {
  Username?: string,
  LastName?: string,
  FirstName?: string,
  NetSuite_ID__c?: string,
  Email?: string,
  Alias?: string,
  TimeZoneSidKey?: string,
  LocaleSidKey?: string,
  UserRoleId?: string,
  EmailEncodingKey?: string,
  ProfileId?: string,
  LanguageLocaleKey?: string,
  ManagerId?: string,
  echosign_dev1__EchoSign_Allow_Delegated_Sending__c?: boolean,
  echosign_dev1__EchoSign_Email_Verified__c?: boolean,
}

export interface SfProductOption {
  Id?: string,
  SBQQ__ProductCode__c?: string,
  SBQQ__Bundled__c?: boolean,
  SBQQ__Type__c?: string
}

export interface SfQuoteLine {
  Id?: string,
  SBQQ__Quote__c?: string,
  SBQQ__Product__c?: string,
  SBQQ__SubscriptionTerm__c?: number,
  SBQQ__Quantity__c?: number,
  SBQQ__Bundle__c?: boolean,
  SBQQ__Bundled__c?: boolean,
  SBQQ__OptionLevel__c?: string,
  SBQQ__OptionType__c?: string,
  SBQQ__ProductOption__c?: string,
  SBQQ__RequiredBy__c?: string,
}
