import { Any } from '../utils/types';

export interface ReportContent {
  attributes?: Attributes;
  allData?: boolean;
  factMap?: { [key: string]: FactMap };
  groupingsAcross?: Groupings;
  groupingsDown?: Groupings;
  hasDetailRows?: boolean;
  picklistColors?: Any;
  reportExtendedMetadata?: ReportExtendedMetadata;
  reportMetadata?: ReportMetadata;
}

export interface Attributes {
  describeUrl?: string;
  instancesUrl?: string;
  reportId?: string;
  reportName?: string;
  type?: string;
}

export interface FactMap {
  aggregates?: Aggregate[];
  rows?: Row[];
}

export interface Aggregate {
  label?: string;
  value?: number;
}

export interface Row {
  dataCells?: DataCell[];
}

export interface DataCell {
  label?: string;
  value?: number | string;
  recordId?: string;
}

export interface Groupings {
  groupings?: Grouping[];
}

export interface Grouping {
  groupings?: Any[];
  key?: string;
  label?: string;
  value?: string;
}

export interface ReportExtendedMetadata {
  aggregateColumnInfo?: { [key: string]: DetailColumnInfo };
  availableDashboardSettings?: null;
  detailColumnInfo?: { [key: string]: DetailColumnInfo };
  groupingColumnInfo?: { [key: string]: DetailColumnInfo };
}

export interface DetailColumnInfo {
  dataType?: string;
  entityColumnName?: string;
  filterValues?: Any[];
  filterable?: boolean;
  inactiveFilterValues?: Any[];
  isLookup?: boolean;
  label?: string;
  uniqueCountable?: boolean;
  fullyQualifiedName?: string;
  fieldInfo?: FieldInfo;
  groupingLevel?: number;
}

export interface FieldInfo {
  entityName?: string;
  fieldName?: string;
  lookupEntityName?: string;
}

export interface ReportMetadata {
  aggregates?: string[];
  chart?: null;
  crossFilters?: CrossFilter[];
  currency?: string;
  customDetailFormula?: { [key: string]: DetailColumnInfo };
  dashboardSetting?: null;
  description?: string;
  detailColumns?: string[];
  developerName?: string;
  division?: null;
  folderId?: string;
  groupingsAcross?: Any[];
  groupingsDown?: GroupingsDown[];
  hasDetailRows?: boolean;
  hasRecordCount?: boolean;
  historicalSnapshotDates?: Any[];
  id?: string;
  name?: string;
  presentationOptions?: PresentationOptions;
  reportBooleanFilter?: null;
  reportFilters?: ReportFilter[];
  reportFormat?: string;
  reportType?: ReportType;
  saveRoleHierarchy?: boolean;
  scope?: string;
  showGrandTotal?: boolean;
  showSubtotals?: boolean;
  sortBy?: Any[];
  standardDateFilter?: StandardDateFilter;
  standardFilters?: null;
  supportsRoleHierarchy?: boolean;
  userOrHierarchyFilterId?: string;
  userOrHierarchyFilterName?: string;
}

export interface CrossFilter {
  criteria?: ReportFilter[];
  includesObject?: boolean;
  primaryEntityField?: string;
  relatedEntity?: string;
  relatedEntityJoinField?: string;
}

export interface ReportFilter {
  column?: string;
  filterType?: string;
  isRunPageEditable?: boolean;
  operator?: string;
  value?: string;
}

export interface GroupingsDown {
  dateGranularity?: string;
  name?: string;
  sortAggregate?: null;
  sortOrder?: string;
}

export interface PresentationOptions {
  hasStackedSummaries?: boolean;
}

export interface ReportType {
  label?: string;
  type?: string;
}

export interface StandardDateFilter {
  column?: string;
  durationValue?: string;
  endDate?: null;
  startDate?: null;
}
