import 'dotenv/config';
import { NsApiClient } from './api_clients/ns_api_client';
import { SfApiClient } from './api_clients/sf_api_client';
import { createNsClassIfNoneAsync, createSfProductConfigurationIfNoneAsync, createSfProductFamiliesIfNoneAsync } from './utils/class_utils';
import { createNsCustomerIfNoneAsync, createSfAccountIfNoneAsync, NsCustomerChannelTier } from './utils/customer_utils';
import { createNsEmployeeIfNoneAsync, createSfUserIfNoneAsync, NsRole } from './utils/employee_utils';
import { createNsNonInventorySaleItemsIfNoneAsync, NsItemProductTier, NsItemRevenueType, NsItemSupportLevel } from './utils/non_inventory_sale_item_utils';
import { ContextType } from './utils/steps_types';
import { createNsSubsidiaryIfNoneAsync, createSfSubsidiaryIfNoneAsync } from './utils/subsidiary_utils';
import { log } from './utils/utils';

// The context with API clients.
const context = {
    nsApiClient: new NsApiClient(),
    sfApiClient: new SfApiClient()
} as ContextType;

/**
 * Initializes test data.
 */
async function initializeTestData() {

    // Create records with no NS -> SF sync.
    const nsSubsidiaryIds = await createSubsidiariesIfNoneAsync();
    await createClassesIfNoneAsync(nsSubsidiaryIds.first());
    await createCustomersIfNoneAsync(nsSubsidiaryIds.first());
    await createEmployeesIfNoneAsync();
}

/**
 * Creates missing classes.
 * There is no NS -> SF sync for classes.
 * @param {number} defaultNsSubsidiaryId
 * @returns {Promise<number[]>}
 */
async function createClassesIfNoneAsync(defaultNsSubsidiaryId: number) {
    const classesCount = 4;

    // Define product families as test data.
    const productFamilies = [...Array(classesCount).keys()].map(i => `E2E Class ${i}`);

    log(`Creating missing NS classes...`);
    const nsClassRefsByProductFamily: Record<string, { id: number, name: string }> = {};
    for (const productFamily of productFamilies) {
        const nsClassName = `${productFamily} Product`;
        const nsClassId = await createNsClassIfNoneAsync(context, {
            custrecord_cls_entity_german: { id: defaultNsSubsidiaryId.toString() },
            custrecord_cls_entity_japan: { id: defaultNsSubsidiaryId.toString() },
            custrecord_cls_entity_other: { id: defaultNsSubsidiaryId.toString() },
            custrecord_cls_entity_us_domestic: { id: defaultNsSubsidiaryId.toString() },
            name: nsClassName
        }, true);
        nsClassRefsByProductFamily[productFamily] = { id: nsClassId, name: nsClassName };
    }

    log(`Creating missing SF product families...`);
    await createSfProductFamiliesIfNoneAsync(context, productFamilies);

    log(`Creating missing SF product configurations...`);
    for (const productFamily of productFamilies) {
        await createSfProductConfigurationIfNoneAsync(context, nsClassRefsByProductFamily[productFamily], productFamily);
    }

    return Object.entries(nsClassRefsByProductFamily).map(([k, v]) => v.id);
}

/**
 * Creates missing customers.
 * The NS -> SF sync for customers is not triggered when the company name contains 'E2E'.
 * @param {number} defaultNsSubsidiaryId
 */
async function createCustomersIfNoneAsync(defaultNsSubsidiaryId: number) {
    const customersSetup = [
        { channelTier: NsCustomerChannelTier.EndUser, count: 1, labelPrefix: 'E2E End-User' },
        { channelTier: NsCustomerChannelTier.Reseller, count: 1, labelPrefix: 'E2E Reseller' },
    ];

    log(`Creating missing NS customers...`);
    const nsCustomerIds: number[] = [];
    for (const customerSetupItem of customersSetup) {
        for (let i = 0; i < customerSetupItem.count; i++) {
            const nsCustomerId = await createNsCustomerIfNoneAsync(context, {
                custentity_customer_channel_tier: { id: customerSetupItem.channelTier.toString() },
                companyName: `${customerSetupItem.labelPrefix} ${i}`,
                subsidiary: { id: defaultNsSubsidiaryId.toString() }
            }, true);
            nsCustomerIds.push(nsCustomerId);
        }
    }

    log(`Creating missing SF accounts...`);
    for (const nsCustomerId of nsCustomerIds) {
        await createSfAccountIfNoneAsync(context, nsCustomerId);
    }
}

/**
 * Creates missing employees.
 * There is no NS -> SF sync for employees.
 */
async function createEmployeesIfNoneAsync() {
    const salesPersonsCount = 1;

    log(`Creating missing NS employees...`);
    const fnCreateNsEmployeeIfNoneAsync = async (lastName: string, roleId: NsRole, supervisorId?: number) => {
        return await createNsEmployeeIfNoneAsync(context, {
            firstName: 'E2E',
            lastName: lastName,
            roles: {
                items: [
                    { selectedRole: { id: roleId.toString() } }
                ]
            },
            supervisor: supervisorId ? { id: supervisorId.toString() } : undefined,
        }, true);
    };
    const nsSalesManagerId = await fnCreateNsEmployeeIfNoneAsync('Sales Manager', NsRole.SalesManager);
    const nsSalesPersonIds: number[] = [];
    for (let i = 0; i < salesPersonsCount; i++) {
        const nsSalesPersonId = await fnCreateNsEmployeeIfNoneAsync(`Sales Person ${i}`, NsRole.SalesPerson, nsSalesManagerId);
        nsSalesPersonIds.push(nsSalesPersonId);
    }

    log(`Creating missing SF users...`);
    const sfSalesManagerId = await createSfUserIfNoneAsync(context, nsSalesManagerId);
    for (const nsSalesPersonId of nsSalesPersonIds) {
        await createSfUserIfNoneAsync(context, nsSalesPersonId, sfSalesManagerId);
    }
}

/**
 * Creates missing non-inventory sale items.
 * There is no NS -> SF sync for non-inventory sale items.
 * @param {number} nsClassId
 * @returns {Promise<Record<string, number>>}
 */
async function createNonInventorySaleItemsIfNoneAsync(nsClassId: number): Promise<Record<string, number>> {
    const itemsSetup: { id: string, name: string, revenueType: NsItemRevenueType, productTier?: NsItemProductTier, supportLevel?: NsItemSupportLevel }[] = [
        { id: 'E2E-OP-Sp0-STA', name: 'E2E Subscription Plan 0, STANDARD EDITION', revenueType: NsItemRevenueType.Saas, productTier: NsItemProductTier.Standard },
        { id: 'E2E-OP-Sp0-PRO', name: 'E2E Subscription Plan 0, PROFESSIONAL EDITION', revenueType: NsItemRevenueType.Saas, productTier: NsItemProductTier.Professional },
        { id: 'E2E-OP-Sp0-SIL', name: 'E2E Subscription Plan 0, STANDARD SUCCESS', revenueType: NsItemRevenueType.Saas, supportLevel: NsItemSupportLevel.Silver },
        { id: 'E2E-OP-Add-ADD', name: 'E2E Additional Pack, ADD-ON', revenueType: NsItemRevenueType.RecurringRevenueOther, productTier: NsItemProductTier.Standard },
        { id: 'E2E-OP-Add-SIL', name: 'E2E Additional Pack, STANDARD SUCCESS', revenueType: NsItemRevenueType.RecurringRevenueOther, supportLevel: NsItemSupportLevel.Silver },
        { id: 'E2E-OT-Ove', name: 'E2E OT Overages', revenueType: NsItemRevenueType.OtherOneTimeRevenue },
    ];

    log(`Creating missing NS non-inventory sale items...`);
    const nsItemIds: Record<string, number> = {};
    for (const itemSetup of itemsSetup) {
        const nsItemId = await createNsNonInventorySaleItemsIfNoneAsync(context, {
            class: { id: nsClassId.toString() },
            custitem_product_tier: itemSetup?.productTier ? { id: itemSetup?.productTier.toString() } : undefined,
            custitem_revenue_type: itemSetup?.revenueType ? { id: itemSetup?.revenueType.toString() } : undefined,
            custitem_support_level: itemSetup?.supportLevel ? { id: itemSetup?.supportLevel.toString() } : undefined,
            displayname: itemSetup.name,
            itemid: itemSetup.id,
        }, true);
        nsItemIds[itemSetup.id] = nsItemId;
    }

    return nsItemIds;
}

/**
 * Creates missing subsidiaries.
 * The NS -> SF sync for subsidiaries is only triggered when updating a NS class by adding a NS subsidiary as a contracting entity.
 */
async function createSubsidiariesIfNoneAsync(): Promise<number[]> {
    const subsidiariesCount = 5;

    log(`Creating missing NS subsidiaries...`);
    const nsSubsidiaryIds: number[] = [];
    for (let i = 0; i < subsidiariesCount; i++) {
        const nsSubsidiaryId = await createNsSubsidiaryIfNoneAsync(context, { name: `E2E Subsidiary ${i}, LLC` }, true);
        nsSubsidiaryIds.push(nsSubsidiaryId);
    }

    log(`Creating missing SF subsidiaries...`);
    for (const nsSubsidiaryId of nsSubsidiaryIds) {
        await createSfSubsidiaryIfNoneAsync(context, nsSubsidiaryId);
    }

    return nsSubsidiaryIds;
}

// If needed, trigger the initialization of test data.
if (typeof process.env.TestData_SkipInitialization === 'undefined' || process.env.TestData_SkipInitialization !== 'true') {
    initializeTestData();
} else {
    log(`Skipping the initialization of test data...`);
}
