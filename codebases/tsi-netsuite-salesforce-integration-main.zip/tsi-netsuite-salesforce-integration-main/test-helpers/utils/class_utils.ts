import { ContextType } from "./steps_types";
import { Any, must } from "./types";
import { NsRecordTypes, XmlNamespace } from "../api_clients/ns_api_client";
import { NsClass } from "../api_contracts/ns_api_contracts";
import { logRecord, throwsIfTrue } from "./utils";
import { faker } from "@faker-js/faker";
import { addCustomFieldRecordIfDefined, addFieldRecordIfDefined, buildCustomFieldList, CustomFieldType, loadCustomFieldAsRefOrDefault } from "./ns_api_utils";
import { SfGlobalValueSetId, SfObjectApiName } from "../api_clients/sf_api_client";
import { SfGlobalValueSet, SfGlobalValueSetValue, SfProductConfiguration } from "../api_contracts/sf_api_contracts";
import { createSfSubsidiaryIfNoneAsync } from "./subsidiary_utils";

/**
 * Represents the custom fields in a class.
 */
export enum ClassCustomField {
    ContractingEntitiesForGermanCustomers = 8188,
    ContractingEntitiesForJapanCustomers = 8186,
    ContractingEntitiesForOtherCustomers = 8185,
    ContractingEntitiesForUsCustomers = 8189,
    PlanningCategory = 5995,
}

/**
 * Represents the planning category in a class.
 */
enum ClassPlanningCategory {
    Parent = 1,
    Leaf = 2
}

/**
 * Creates a NS class and returns its internal ID.
 * @param {ContextType} context
 * @param {NsClass} [nsClass] If undefined, create a NS class with fake data.
 * @returns {Promise<number>} The internal ID of the created NS class.
 */
export async function createNsClassAsync(context: ContextType, nsClass: NsClass): Promise<number> {

    // If undefined, build a NS class with fake data.
    nsClass = nsClass ?? getFakeNsClass();

    // Map it to SOAP record and add it. Return the internal ID.
    const record = toSoapRecord(nsClass);
    const nsClassId = await context.nsApiClient.soapAddAsync(record);
    logRecord('NS', NsRecordTypes.Class, { id: nsClassId, name: nsClass.name }, 'CREATED');
    return nsClassId;
}

/**
 * Creates a NS class if it doesn't exist yet.
 * @param {ContextType} context
 * @param {NsClass} nsClass
 * @param {boolean} overridesFake
 * @returns {Promise<number>} The ID of the created or existing NS class.
 */
export async function createNsClassIfNoneAsync(context: ContextType, nsClass?: NsClass, overridesFake = false): Promise<number> {

    // If the class is undefined or an override is required, fill the object with fake data.
    if (!nsClass || overridesFake) {
        nsClass = getFakeNsClass(nsClass);
    }

    // Try to retrieve the NS class for the given name, and create it if it doesn't exist.
    let nsClassId = await context.nsApiClient.readRecordIdAsync(NsRecordTypes.Class, `name = '${must(nsClass.name)}'`);
    if (nsClassId === null) {
        nsClassId = await createNsClassAsync(context, nsClass);
    } else {
        logRecord('NS', NsRecordTypes.Class, { id: nsClassId, name: nsClass.name });
    }
    return nsClassId;
}

/**
 * Creates SF production configuration if it doesn't exist yet.
 * @param {ContextType} context
 * @param {{ id: number, name: string }} nsClassRef
 * @param {string} sfProductFamily
 * @returns {Promise<string>}
 */
export async function createSfProductConfigurationIfNoneAsync(context: ContextType, nsClassRef: { id: number, name: string }, sfProductFamily: string): Promise<string> {

    // Try to retrieve SF product configuration for the given NetSuite Class.
    const sfClassIds = await context.sfApiClient.getRecordIdsByNetSuiteClassAsync(SfObjectApiName.ProductConfiguration, must(nsClassRef.name));
    if (sfClassIds.length > 0) {
        const sfClassId = sfClassIds.single();
        logRecord('SF', SfObjectApiName.ProductConfiguration, { Id: sfClassId, NetSuite_Class__c: nsClassRef.name })
        return sfClassId;
    }

    // Retrieve NS subsidiary based on given ID.
    const record = await context.nsApiClient.soapGetAsync(NsRecordTypes.Class, nsClassRef.id);
    throwsIfTrue(!record, `Cannot retrieve the NS class '${nsClassRef.id}' to sync data as SF product configuration.`);
    const nsClass = loadRecord(record);

    // Create the SF product configuration by mapping data from NS class and return its ID.
    const sfProductConfiguration = await toSfProductConfigurationAsync(context, nsClass, sfProductFamily);
    return await context.sfApiClient.createRecordAsync(SfObjectApiName.ProductConfiguration, sfProductConfiguration);
}

/**
 * Creates SF product families which don't exist yet.
 * @param {ContextType} context
 * @param {string[]} values
 * @returns {Promise<void>}
 */
export async function createSfProductFamiliesIfNoneAsync(context: ContextType, values: string[]): Promise<void> {

    // Retrieve the global value set for Product families.
    const valueSet = must(
        await context.sfApiClient.getRecordAsync<SfGlobalValueSet>(SfObjectApiName.GlobalValueSet, SfGlobalValueSetId.ProductFamilies, true, false)
    );

    // If the value is already listed as a product family, do nothing.
    const existingValues = valueSet.Metadata.customValue.map(v => v.valueName);
    const missingValues = values.filter(v => !existingValues.includes(v))
    if (missingValues.length === 0) {
        logRecord('SF', SfObjectApiName.GlobalValueSet, { Id: SfGlobalValueSetId.ProductFamilies, FullName: 'Products_Families' });
        return;
    }

    // Else, add the missing values to the custom values and update the global value set.
    const updatedValueSet = {
        FullName: valueSet.FullName,
        Metadata: valueSet.Metadata
    };
    updatedValueSet.Metadata.customValue.push(...missingValues.map(v => {
        return { label: v, isActive: true, valueName: v } as SfGlobalValueSetValue;
    }));
    await context.sfApiClient.updateRecordAsync(SfObjectApiName.GlobalValueSet, SfGlobalValueSetId.ProductFamilies, updatedValueSet, true);
    logRecord('SF', `${SfObjectApiName.GlobalValueSet}-values`, { values: missingValues }, 'CREATED');
}

/**
 * Returns the class for the given ID.
 * @param {ContextType} context
 * @param {number} id
 * @returns {Promise<NsClass>}
 */
export async function getClassAsync(context: ContextType, id: number): Promise<NsClass> {
    const record = await context.nsApiClient.soapGetAsync(NsRecordTypes.Class, id);
    return loadRecord(record);
}

/**
 * Loads the class by mapping the NS SOAP record into the dedicated object.
 * @param {Any} record
 * @returns {NsClass} The NS class.
 */
function loadRecord(record: Any): NsClass {
    const customFields = record['listAcct:customFieldList'][0]['platformCore:customField'];
    return {
        custrecord_cls_entity_german: loadCustomFieldAsRefOrDefault(customFields, ClassCustomField.ContractingEntitiesForGermanCustomers),
        custrecord_cls_entity_japan: loadCustomFieldAsRefOrDefault(customFields, ClassCustomField.ContractingEntitiesForJapanCustomers),
        custrecord_cls_entity_other: loadCustomFieldAsRefOrDefault(customFields, ClassCustomField.ContractingEntitiesForOtherCustomers),
        custrecord_cls_entity_us_domestic: loadCustomFieldAsRefOrDefault(customFields, ClassCustomField.ContractingEntitiesForUsCustomers),
        id: record.$.internalId,
        name: record['listAcct:name'][0]
    };
}

/**
 * Returns the class ID for the given class name.
 * @param {ContextType} context
 * @param {string} name
 * @returns {Promise<number>}
 */
export async function getClassIdByNameAsync(context: ContextType, name: string): Promise<number> {

    // Try to retrieve a class by its name.
    const queryResult = await context.nsApiClient.queryWithSuiteQL<{id: number}>(`SELECT id FROM ${NsRecordTypes.Class} WHERE name = '${name}'`);

    // If the currency has been found, return it.
    if (queryResult.count === 0) {
        throw new Error(`Class record not found for name '${name}'.`);
    }
    return +queryResult.items.first().id;
}

/**
 * Updates the given NS class.
 * @param {ContextType} context
 * @param {NsClass} nsClass
 * @returns {Promise<void>}
 */
export async function updateClassAsync(context: ContextType, nsClass: NsClass): Promise<void> {

    // Build the record from the NS class, then send the SOAP update request.
    const record = toSoapRecord(nsClass);
    return await context.nsApiClient.soapUpdateAsync(record);
}

/**
 * Gets a NS class with fake data.
 * @param {NsClass} override
 * @returns {NsClass}
 */
function getFakeNsClass(override?: NsClass): NsClass {
    const name = override?.name ?? `${faker.commerce.product()} Product`;
    return {
        custrecord_cls_entity_german: override?.custrecord_cls_entity_german,
        custrecord_cls_entity_japan: override?.custrecord_cls_entity_japan,
        custrecord_cls_entity_other: override?.custrecord_cls_entity_other,
        custrecord_cls_entity_us_domestic: override?.custrecord_cls_entity_us_domestic,
        custrecord_nspbcs_class_planning_cat: ClassPlanningCategory.Leaf,
        name: name,
    };
}

/**
 * Maps a NS class object to a SF product configuration.
 * @param {ContextType} context
 * @param {NsClass} nsClass
 * @param {string} sfProductFamily
 * @returns {Promise<SfProductConfiguration>}
 */
async function toSfProductConfigurationAsync(context: ContextType, nsClass: NsClass, sfProductFamily: string): Promise<SfProductConfiguration> {

    // Define all distinct NS subsidiary IDs referenced as contracting entities.
    const nsSubsidiaryIds = [
        +must(nsClass.custrecord_cls_entity_german?.id),
        +must(nsClass.custrecord_cls_entity_japan?.id),
        +must(nsClass.custrecord_cls_entity_other?.id),
        +must(nsClass.custrecord_cls_entity_us_domestic?.id)
    ].filter((v, i, a) => a.indexOf(v) === i);

    // Retrieve all SF subsidiary IDs based on NS subsidiary IDs. If the related SF record doesn't exist, create it.
    const sfSubsidiaryIdsByNsSubsidiary: Record<number, string> = {};
    for (const nsSubsidiaryId of nsSubsidiaryIds) {
        sfSubsidiaryIdsByNsSubsidiary[nsSubsidiaryId] = (await context.sfApiClient.getRecordIdsByNetSuiteIdAsync(SfObjectApiName.Subsidiary, nsSubsidiaryId)).singleOrDefault()
            ?? await createSfSubsidiaryIfNoneAsync(context, nsSubsidiaryId);
    }

    // Build the SF product configuration.
    return {
        Contacting_Entity_JP__c: sfSubsidiaryIdsByNsSubsidiary[must(nsClass.custrecord_cls_entity_japan?.id)],
        Contracting_Entity_DE_and_AT__c: sfSubsidiaryIdsByNsSubsidiary[must(nsClass.custrecord_cls_entity_german?.id)],
        Contracting_Entity_Other__c: sfSubsidiaryIdsByNsSubsidiary[must(nsClass.custrecord_cls_entity_other?.id)],
        Contracting_Entity_US_and_AE__c: sfSubsidiaryIdsByNsSubsidiary[must(nsClass.custrecord_cls_entity_us_domestic?.id)],
        Name: sfProductFamily,
        NetSuite_Class__c: must(nsClass.name),
        Product__c: sfProductFamily
    } as SfProductConfiguration;
}

/**
 * Maps a NS class object to a SOAP record.
 * @param {NsClass} nsClass
 * @returns {Any}
 */
function toSoapRecord(nsClass: NsClass): Any {

    // Defines common properties.
    const customFields: Any = [];
    const record:Any = {
        'record': {
            $: {
                'xsi:type': `listAcct:Classification`,
                'xmlns:listAcct': XmlNamespace.ACCOUNTING
            }
        }
    };
    addFieldRecordIfDefined(record, 'listAcct:name', nsClass.name);
    addCustomFieldRecordIfDefined(customFields, CustomFieldType.SelectCustomFieldRef,
        ClassCustomField.ContractingEntitiesForGermanCustomers, nsClass.custrecord_cls_entity_german?.id);
    addCustomFieldRecordIfDefined(customFields, CustomFieldType.SelectCustomFieldRef,
        ClassCustomField.ContractingEntitiesForJapanCustomers, nsClass.custrecord_cls_entity_japan?.id);
    addCustomFieldRecordIfDefined(customFields, CustomFieldType.SelectCustomFieldRef,
        ClassCustomField.ContractingEntitiesForOtherCustomers, nsClass.custrecord_cls_entity_other?.id);
    addCustomFieldRecordIfDefined(customFields, CustomFieldType.SelectCustomFieldRef,
        ClassCustomField.ContractingEntitiesForUsCustomers, nsClass.custrecord_cls_entity_us_domestic?.id);

    // If the subsidiary ID is defined, set the internal ID; else, define missing properties for creation.
    if (nsClass.id !== undefined) {
        record['record'].$['internalId'] = nsClass.id;
    } else {
        addCustomFieldRecordIfDefined(customFields, CustomFieldType.SelectCustomFieldRef, ClassCustomField.PlanningCategory, ClassPlanningCategory.Leaf);
    }

    // If there are any custom fields, add them. Then, return the record.
    addFieldRecordIfDefined(record, 'listAcct:customFieldList', buildCustomFieldList(customFields));
    return record;
}
