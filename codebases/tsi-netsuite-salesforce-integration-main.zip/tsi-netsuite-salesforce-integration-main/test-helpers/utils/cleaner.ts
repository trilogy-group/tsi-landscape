import { ExponentialBackoff, Policy, retry, RetryPolicy } from 'cockatiel';
import { NsApiClient, NsRecordTypes } from '../api_clients/ns_api_client';
import { SfApiClient, SfObjectApiName } from '../api_clients/sf_api_client';
import { Any, HttpStatusCode } from './types';
import { RequestError } from 'got';
import { log, toDescriptionString } from './utils';
import AsyncLock from 'async-lock';
import { AxiosError } from 'axios';
import { RETRY_ATTEMPTS, RETRY_INITIAL_DELAY, RETRY_MAX_DELAY } from '../api_clients/api_client';

export enum CleanType {
  removeNsAvaSubsidiary,
  removeNsCustomer,
  removeNsContact,
  removeNsSubsidiary,
  removeSfAccount,
  removeSfContact,
  removeSfOpportunity,
  removeNsSubscription,
  removeSfTask,
  removeSfResellerAgreement,
  removeSfPartner,
  removeSfSubsidiary
}

export class CleanerRec {
  public type: CleanType;
  public id: Any;
  constructor(type: CleanType, id: Any) {
    this.type = type;
    this.id = id;
  }
}

/**
 * Cleaner.
 */
export class Cleaner {
  private readonly queue: CleanerRec[] = [];
  private readonly lock = new AsyncLock();
  private readonly queueLockName = 'queue-lock';

  /**
   * Adds clean item to the queue.
   * @param {CleanerRec} cleanerRec cleaner record
   * @memberof Cleaner
   */
  public async addClean(cleanerRec: CleanerRec): Promise<void> {
    await this.lock.acquire(this.queueLockName, async () => {
      const recIndex = this.queue.findIndex((rec) => rec.id === cleanerRec.id && rec.type === cleanerRec.type);
      if (recIndex === -1) {
        this.queue.unshift(cleanerRec);
      }
    });
  }

  /**
   * Removes clean item from the queue.
   * @param {CleanerRec} cleanerRec cleaner record
   * @memberof Cleaner
   */
  public async removeClean(cleanerRec: CleanerRec): Promise<void> {
    await this.lock.acquire(this.queueLockName, async () => {
      const recIndex = this.queue.findIndex((rec) => rec.id === cleanerRec.id && rec.type === cleanerRec.type);
      if (recIndex >= 0) {
        this.queue.splice(recIndex);
      }
    });
  }

  /**
   * Runs the cleanup.
   * @returns api response
   */
  public async clean(): Promise<Any> {
    const isDisabled = process.env.Cleaner_SkipCleaning;

    if (typeof isDisabled === 'undefined' || isDisabled !== 'true') {
      await this.lock.acquire(this.queueLockName, async () => {
        if (this.queue.length > 0) {

          // we can't run clean in parralle because some records depends on each other
          const tasks: (() => Promise<Any>)[] = this.constructCleanTasks();
          for (const task of tasks) {
            await task();
          }

          this.queue.splice(0, this.queue.length);
          log(`Cleaning done for test '${expect.getState().currentTestName}`);
        }
      });
    }

    return Promise.resolve({});
  }

  /**
   * Represents the definition of a cleaning task for each type.
   */
  private readonly cleanTaskDefinitionMapping: Record<CleanType, {
    onResult: boolean,
    label: string,
    fnCleanFactory: (nsApiClient: NsApiClient, sfApiClient: SfApiClient, id: Any) => (() => Promise<Any>)}
  > = {
    [CleanType.removeNsAvaSubsidiary]: { onResult: false, label: 'ns ava subsidiary', fnCleanFactory: (nsApiClient, _sfApiClient, id) => (
      () => nsApiClient.deleteRecordAsync(NsRecordTypes.AvaSubsidiary, id as number)
    ) },
    [CleanType.removeNsContact]: { onResult: true, label: 'ns contact', fnCleanFactory: (nsApiClient, _sfApiClient, id) => (
      () => nsApiClient.deleteContact(id as number)
    ) },
    [CleanType.removeNsCustomer]: { onResult: true, label: 'ns customer', fnCleanFactory: (nsApiClient, _sfApiClient, id) => (
      () => nsApiClient.deleteCustomer(id as number)
    ) },
    [CleanType.removeNsSubscription]: { onResult: true, label: 'ns subscription', fnCleanFactory: (nsApiClient, _sfApiClient, id) => (
      () => nsApiClient.deleteSubscription(id as number)
    ) },
    [CleanType.removeNsSubsidiary]: { onResult: false, label: 'ns subsidiary', fnCleanFactory: (nsApiClient, _sfApiClient, id) => (
      () => nsApiClient.soapDeleteAsync(NsRecordTypes.Subsidiary, id as number)
    ) },
    [CleanType.removeSfAccount]: { onResult: true, label: 'sf account', fnCleanFactory: (_nsApiClient, sfApiClient, id) => (
      () => sfApiClient.deleteAccount(id as string)
    ) },
    [CleanType.removeSfContact]: { onResult: true, label: 'sf contact', fnCleanFactory: (_nsApiClient, sfApiClient, id) => (
      () => sfApiClient.deleteContact(id as string)
    ) },
    [CleanType.removeSfOpportunity]: { onResult: true, label: 'sf opportunity', fnCleanFactory: (_nsApiClient, sfApiClient, id) => (
      () => sfApiClient.deleteOpportunity(id as string)
    ) },
    [CleanType.removeSfPartner]: { onResult: true, label: 'sf partner', fnCleanFactory: (_nsApiClient, sfApiClient, id) => (
      () => sfApiClient.deletePartner(id as string)
    ) },
    [CleanType.removeSfResellerAgreement]: { onResult: true, label: 'sf reseller agreement', fnCleanFactory: (_nsApiClient, sfApiClient, id) => (
      () => sfApiClient.deleteResellerAgreement(id as string)
    ) },
    [CleanType.removeSfSubsidiary]: { onResult: false, label: 'sf subsidiary', fnCleanFactory: (_nsApiClient, sfApiClient, id) => (
      () => sfApiClient.deleteRecordAsync(SfObjectApiName.Subsidiary, id as string)
    ) },
    [CleanType.removeSfTask]: { onResult: true, label: 'sf task', fnCleanFactory: (_nsApiClient, sfApiClient, id) => (
      () => sfApiClient.deleteTask(id as string)
    ) }
  };

  /**
   * Returns tasks based on the cleaner records.
   * @returns {(() => Promise<Any>)[]}
   */
  private constructCleanTasks(): (() => Promise<Any>)[] {

    // Get dependencies, relying on own retry policy.
    const nsApiClient = new NsApiClient(false);
    const sfApiClient = new SfApiClient(false);

    // Build a task for each cleaner record. Here, a task is a function to trigger the asynchronous cleaning process.
    return this.queue.map((record) => {

      // Retrieve the task definition based on the cleaner record type.
      const cleanTaskDefinition = this.cleanTaskDefinitionMapping[record.type];
      if (cleanTaskDefinition) {

        // Build the task based on the description, the cleaning function and the retry policy.
        const retryPolicy = this.getRetryPolicy(cleanTaskDefinition.onResult);
        const description = `${cleanTaskDefinition.label} id: ${record.id}`;
        const fnClean = cleanTaskDefinition.fnCleanFactory(nsApiClient, sfApiClient, record.id);
        if (cleanTaskDefinition.onResult) {
          return () => this.cleanAndExpectNoContent(retryPolicy, description, fnClean);
        } else {
          return () => this.cleanAndExpectNoError(retryPolicy, description, fnClean);
        }
      }
      throw new Error(`Not implemented for ${record.type}`);
    });
  }

  /**
   * Returns the retry policy. By default, it handles on error.
   * @param {boolean} onResult
   * @returns {RetryPolicy}
   */
  private getRetryPolicy(onResult: boolean): RetryPolicy {

    // By default, the policy handles on error. Add the handler on result based on given flag.
    let policy = new Policy({ errorFilter: (_error) => false, resultFilter: (_result) => false });
    policy = this.addHandlerOnError(policy)
    if (onResult) {
      policy = this.addHandlerOnResult(policy);
    }

    // Create the retry policy.
    return retry(policy, this.getRetryPolicyOptions());
  }

  /**
   * Returns the policy by adding the handler on error.
   * Will handle all except (RequestError) 404 Not Found.
   * @param {Policy} policy
   * @returns {Policy}
   */
  private addHandlerOnError(policy: Policy): Policy {
    return policy.orType(Error, (error) => {

      // Handle all error except 404 Not Found.
      // - NS API calls: RequestError, as HTTPError (REST API) or SoapRequestError (SOAP API).
      // - SF API calls: AxiosError (REST API).
      if (error instanceof RequestError && error.response || error instanceof AxiosError && error.response) {
        const response: Any = error.response;
        const statusCode = response?.statusCode ?? response.status;
        const body = response?.body ?? response.data;
        log(`cleaner: RequestError. Response status code: ${statusCode}. Response body: ${JSON.stringify(body)}`);
        if (statusCode === HttpStatusCode.NotFound) {
          log(`cleaner: cleaning skipped - record not found`);
          return false;
        }
      }

      log(`cleaner: Error. Description: ${toDescriptionString(error)}`);
      return true;
    });
  }

  /**
   * Returns the policy by adding the handler on result.
   * Will handle any result which is different than 200 Ok or 204 No Content.
   * @param {Policy} policy
   * @returns {Policy}
   */
  private addHandlerOnResult(policy: Policy): Policy {
    return policy.orWhenResult((status) => {
      return status !== HttpStatusCode.NoContent && status !== HttpStatusCode.Ok;
    })
  }

  /**
   * Returns the default options for the retry policy.
   */
  private getRetryPolicyOptions() {
    return {
      maxAttempts: RETRY_ATTEMPTS,
      backoff: new ExponentialBackoff({
        initialDelay: RETRY_INITIAL_DELAY,
        maxDelay: RETRY_MAX_DELAY,
      })
    };
  }

  private cleanAndExpectNoContent(
    retryPolicy: RetryPolicy,
    operationDescription: string,
    cleanFunc: () => Promise<void> | Promise<number>
  ): Promise<void | number> {
    return retryPolicy.execute(async () => {
      log(`cleaner: cleaning ${operationDescription}...`);
      const status = await cleanFunc();
      if (status === HttpStatusCode.NoContent) {
        log(`cleaner: cleaned: ${operationDescription}.`);
      } else {
        log(`cleaner: ${operationDescription}. Unexpected API response status: ${status}. Retrying...`);
      }
      return status;
    });
  }

  private cleanAndExpectNoError(
    retryPolicy: RetryPolicy,
    operationDescription: string,
    cleanFunc: () => Promise<void>
  ): Promise<void> {
    return retryPolicy
      .execute(async () => {
        log(`cleaner: cleaning ${operationDescription}...`);
        await cleanFunc();
        log(`cleaner: cleaned: ${operationDescription}.`);
      });
  }
}
