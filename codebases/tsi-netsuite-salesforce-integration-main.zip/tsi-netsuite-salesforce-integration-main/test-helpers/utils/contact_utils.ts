import { faker } from "@faker-js/faker";
import { FlowExecutionState, FlowRelatedEntityKind } from "../api_clients/ti_api_client";
import { CleanerRec, CleanType } from "./cleaner";
import { ContextType, waitForRecInitialDelay, waitForWorkflowCompletedAttempts, waitForWorkflowMaxDelay } from "./steps_types";

/**
 * Creates a contact in NetSuite and waits for flow to sync
 * @param {ContextType} context
 * @param nsCustomerId  the data of a custumer to be created
 * @param contactData the data of a contact to be created
 * @returns the id from netsuite
 */
export async function createNetsuiteContactAndWaitFlowSync(
  context: ContextType,
  subsidiaryId: number,
  nsCustomerId: number,
  contactData: {
    contactTitle: string;
    contactSalutation: string;
    contactFirstName: string;
    contactLastName: string;
    contactMiddleName: string;
    contactEmail: string;
    contactPhone: string;
    contactMobilePhone: string;
    contactFax: string;
    contactDescription: string;
  },
  afterTimeStamp?: string) {
  // create netsuite contact
  const nsContactId = await context.nsApiClient.createContact(subsidiaryId, {
    customerId: nsCustomerId,
    contactTitle: contactData.contactTitle,
    salutation: contactData.contactSalutation,
    firstName: contactData.contactFirstName,
    lastName: contactData.contactLastName,
    middleName: contactData.contactMiddleName,
    title: contactData.contactTitle,
    contactEmail: contactData.contactEmail,
    contactPhone: contactData.contactPhone,
    contactMobilePhone: contactData.contactMobilePhone,
    contactFax: contactData.contactFax,
    description: contactData.contactDescription,
  });
  await context.cleaner.addClean(new CleanerRec(CleanType.removeNsContact, nsContactId));

  const calledWorkflowExecutionState = await context.tiApiClient.waitForFlowCompletion(
    FlowRelatedEntityKind.ns_contact_id,
    nsContactId.toString(),
    waitForWorkflowMaxDelay,
    waitForRecInitialDelay,
    waitForWorkflowCompletedAttempts,
    afterTimeStamp
  );
  expect((FlowExecutionState)[calledWorkflowExecutionState.status]).toBe(FlowExecutionState.Completed);

  return { nsContactId, timestamp: calledWorkflowExecutionState.timestamp };
}

/**
 * Asserts SFcontact data with fake contact data
 */
export function assertsSalesforceContactData(context: ContextType){
  expect(context.sfContact.Salutation).toBe(context.fakeContactData.contactSalutation);
  expect(context.sfContact.FirstName).toBe(context.fakeContactData.contactFirstName);
  expect(context.sfContact.LastName).toBe(context.fakeContactData.contactLastName);
  expect(context.sfContact.MiddleName).toBe(context.fakeContactData.contactMiddleName);
  expect(context.sfContact.Title).toBe(context.fakeContactData.contactTitle);
  expect(context.sfContact.Email?.toLowerCase()).toBe(context.fakeContactData.contactEmail.toLowerCase());
  expect(context.sfContact.Phone).toBe(context.fakeContactData.contactPhone);
  expect(context.sfContact.MobilePhone).toBe(context.fakeContactData.contactMobilePhone);
  expect(context.sfContact.Fax).toBe(context.fakeContactData.contactFax);
}

/**
 * Generates fake data for a contact
 * @returns the fake data for a contact
 */
export function getFakeContactData() {
  const phoneNumberFormat = '###-###-###';
  return {
    contactTitle: faker.name.jobTitle(),
    contactSalutation: faker.name.prefix(),
    contactFirstName: faker.name.firstName(),
    contactLastName: faker.name.lastName(),
    contactMiddleName: faker.name.middleName(),
    contactEmail: `${faker.internet.email().toLowerCase()}.invalid`,
    contactPhone: faker.phone.number(phoneNumberFormat),
    contactMobilePhone: faker.phone.number(phoneNumberFormat),
    contactFax: faker.phone.number(phoneNumberFormat),
    contactDescription: faker.lorem.sentence(),
  };
}
