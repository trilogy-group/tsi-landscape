import { faker } from "@faker-js/faker";
import { ContextType, waitForRecInitialDelay, waitForWorkflowCompletedAttempts, waitForWorkflowMaxDelay } from "./steps_types";
import { FlowExecutionState, FlowRelatedEntityKind } from "../api_clients/ti_api_client";
import { CleanerRec, CleanType } from "./cleaner";
import { must } from "./types";
import { log, logRecord, throwsIfTrue } from "./utils";
import { NsRecordTypes } from "../api_clients/ns_api_client";
import { NsCustomer } from "../api_contracts/ns_api_contracts";
import { RootNsSubsidiaryId } from "./subsidiary_utils";
import { SfObjectApiName } from "../api_clients/sf_api_client";
import { SfAccount } from "../api_contracts/sf_api_contracts";

export enum SfAccountType {
  Customer = 'Customer',
  Reseller = 'Reseller',
  Other = 'Other',
}

export enum NsCustomerChannelTier {
  EndUser = 1,
  Reseller = 2,
  Distributor = 3,
}

/**
 * Creates a NS customer and returns its internal ID.
 * @param {ContextType} context
 * @param {NsCustomer} [nsCustomer] If undefined, create a NS customer with fake data.
 * @returns {Promise<number>} The internal ID of the created NS customer.
 */
export async function createNsCustomerAsync(context: ContextType, nsCustomer?: NsCustomer): Promise<number> {

  // If undefined, build a NS customer with fake data.
  nsCustomer = nsCustomer ?? getFakeNsCustomer();

  // Create the customer record and return its internal ID.
  return await context.nsApiClient.createRecordAsync(NsRecordTypes.Customer, nsCustomer);
}

/**
* Creates a NS customer if it doesn't exist yet.
* @param {ContextType} context
* @param {NsCustomer} nsCustomer
* @param {boolean} overridesFake
* @returns {Promise<number>} The ID of the created or existing NS customer.
*/
export async function createNsCustomerIfNoneAsync(context: ContextType, nsCustomer?: NsCustomer, overridesFake = false): Promise<number> {

  // If the customer is undefined or an override is required, fill the object with fake data.
  if (!nsCustomer || overridesFake) {
    nsCustomer = getFakeNsCustomer(nsCustomer);
  }

  // Try to retrieve the NS customer for the given name, and create it if it doesn't exist.
  let nsCustomerId = await context.nsApiClient.readRecordIdAsync(NsRecordTypes.Customer, `companyName = '${must(nsCustomer.companyName)}'`);
  if (nsCustomerId === null) {
    nsCustomerId = await createNsCustomerAsync(context, nsCustomer);
  } else {
    logRecord('NS', NsRecordTypes.Customer, { id: nsCustomerId, companyName: nsCustomer.companyName });
  }
  return nsCustomerId;
}

/**
 * Creates a SF account from a given NS customer if it doesn't exist yet.
 * @param {ContextType} context
 * @param {number} nsCustomerId
 * @returns {Promise<string>} The ID of the created or existing SF subsidiary.
 */
export async function createSfAccountIfNoneAsync(context: ContextType, nsCustomerId: number): Promise<string> {

  // Try to retrieve SF account for the given NetSuite ID.
  const sfAccountIds = await context.sfApiClient.getRecordIdsByNetSuiteIdAsync(SfObjectApiName.Account, nsCustomerId);
  if (sfAccountIds.length > 0) {
      const sfAccountId = sfAccountIds.single();
      logRecord('SF', SfObjectApiName.Account, { Id: sfAccountId, NetSuite_ID__c: nsCustomerId })
      return sfAccountId;
  }

  // Retrieve NS Customer based on given ID.
  const nsCustomer = await context.nsApiClient.getRecord<NsCustomer>(NsRecordTypes.Customer, nsCustomerId, true, false);
  throwsIfTrue(!nsCustomer, `Cannot retrieve the NS customer '${nsCustomerId}' to sync data as SF account.`);

  // Create the SF account by mapping data from NS customer and return its ID.
  const sfAccount = toSfAccount(nsCustomer);
  return await context.sfApiClient.createRecordAsync(SfObjectApiName.Account, sfAccount);
}

/**
 * Creates a customer in NetSuite and waits for flow sync
 */
export async function createNetsuiteCustomerAndWaitFlowSync(context: ContextType) {
  context.fakeCustomerData = getFakeCustomerData();

  // create netsuite record
  context.nsCustomerId = await context.nsApiClient.createCustomer(must(context.nsSubsidiaryId), {
    companyName: context.fakeCustomerData.customerName,
    email: context.fakeCustomerData.customerEmail,
    phone: context.fakeCustomerData.customerPhone,
    fax: context.fakeCustomerData.customerFax,
    webSite: context.fakeCustomerData.customerWebSite,
    billingAddrCountry: context.fakeCustomerData.billingAddrCountry,
    billingAddrPostalCode: context.fakeCustomerData.billingAddrPostalCode,
    billingAddrState: context.fakeCustomerData.billingAddrState,
    billingAddrCity: context.fakeCustomerData.billingAddrCity,
    billingAddrStreet: context.fakeCustomerData.billingAddrStreet,
    shippingAddrCountry: context.fakeCustomerData.shippingAddrCountry,
    shippingAddrPostalCode: context.fakeCustomerData.shippingAddrPostalCode,
    shippingAddrState: context.fakeCustomerData.shippingAddrState,
    shippingAddrCity: context.fakeCustomerData.shippingAddrCity,
    shippingAddrStreet: context.fakeCustomerData.shippingAddrStreet,
  });

  log(`Ns customer has been created. Id: ${context.nsCustomerId}`);

  //wait for flows execution
  //this will not sync yet, but if we do other steps and this process after, it's possible the test to fail
  //because we have sync back from salesforce
  const calledWorkflowExecutionState = await context.tiApiClient.waitForFlowCompletion(
    FlowRelatedEntityKind.ns_customer_id,
    must(context.nsCustomerId).toString(),
    waitForWorkflowMaxDelay,
    waitForRecInitialDelay,
    waitForWorkflowCompletedAttempts
  );
  expect((FlowExecutionState)[calledWorkflowExecutionState.status]).toBe(FlowExecutionState.Completed);
  context.nsCustomerLastSyncStatusTimeStamp = calledWorkflowExecutionState.timestamp;

  await context.cleaner.addClean(new CleanerRec(CleanType.removeNsCustomer, context.nsCustomerId));
}

/**
 * Generates fake data for a customer
 * @returns the fake data for a customer
 */
export function getFakeCustomerData() {
  const phoneNumberFormat = '###-###-###';
  return {
    customerName: faker.company.name(),
    customerEmail: `${faker.internet.email().toLowerCase()}.invalid`,
    customerPhone: faker.phone.number(phoneNumberFormat),
    customerFax: faker.phone.number(phoneNumberFormat),
    customerWebSite: faker.internet.url(),
    billingAddrCountry: faker.address.countryCode(),
    billingAddrPostalCode: faker.address.zipCode(),
    billingAddrState: faker.address.state(),
    billingAddrCity: faker.address.cityName(),
    billingAddrStreet: faker.address.streetAddress(),
    shippingAddrCountry: faker.address.countryCode(),
    shippingAddrPostalCode: faker.address.zipCode(),
    shippingAddrState: faker.address.state(),
    shippingAddrCity: faker.address.cityName(),
    shippingAddrStreet: faker.address.streetAddress(),
  };
}

/**
 * Generates fake reseller account data
 * @returns the fake data
 */
export function getFakeResellerAccountData() {
  return {
    name: faker.company.bsAdjective(),
    currencyIsoCode: 'USD',
    resellerAgreementLink: faker.internet.url(),
  };
}

/**
 * Returns the ID of a customer for the given name.
 * @param {ContextType} context
 * @param {string} name
 * @returns {Promise<number>}
 */
export async function getNsCustomerIdByName(context: ContextType, name: string): Promise<number> {

  // Search for the customer with the given name.
  const queryResult = await context.nsApiClient.queryWithSuiteQL<{ id: string }>(`
    SELECT id
    FROM ${NsRecordTypes.Customer}
    WHERE companyName = '${name}'
  `, 1);

  // If any customer matches, return the ID.
  expect(queryResult.count).toEqual(1);
  return +queryResult.items.first().id;
}

/**
 * Gets a NS Customer with fake data.
 * @param {NsCustomer} override
 * @returns {NsCustomer}
 */
function getFakeNsCustomer(override?: NsCustomer): NsCustomer {
  const phoneNumberFormat = '###-###-###';
  return {
    addressBook: {
      items: [
        {
          defaultBilling: true,
          defaultShipping: false,
          isResidential: false,
          addressBookAddress: {
            country: { id: faker.address.countryCode() },
            state: faker.address.state(),
            zip: faker.address.zipCode(),
            addr1: faker.address.streetAddress(),
            city: faker.address.cityName(),
          },
        },
        {
          defaultBilling: false,
          defaultShipping: true,
          isResidential: false,
          addressBookAddress: {
            country: { id: faker.address.countryCode() },
            state: faker.address.state(),
            zip: faker.address.zipCode(),
            addr1: faker.address.streetAddress(),
            city: faker.address.cityName(),
          },
        },
      ]
    },
    companyName: override?.companyName ?? faker.company.name(),
    custentity_customer_channel_tier: {
      id: override?.custentity_customer_channel_tier?.id ?? NsCustomerChannelTier.EndUser.toString()
    },
    email: `${faker.internet.email().toLowerCase()}.invalid`,
    fax: faker.phone.number(phoneNumberFormat),
    phone: faker.phone.number(phoneNumberFormat),
    subsidiary: {
      id: override?.subsidiary?.id ?? RootNsSubsidiaryId.toString()
    },
    url: faker.internet.url()
  };
}

/**
 * Maps a NS customer object to a SF account.
 * @param {NsCustomer} nsCustomer
 * @returns {Promise<SfAccount>}
 */
function toSfAccount(nsCustomer: NsCustomer): SfAccount {

  const sfAccount = {
      Fax: nsCustomer.fax,
      Name: nsCustomer.companyName,
      Netsuite_Id__c: must(nsCustomer.id).toString(),
      Phone: nsCustomer.phone,
      Type: toSfAccountType(+must(nsCustomer.custentity_customer_channel_tier?.id)),
      Website: nsCustomer.url,
  } as SfAccount;

  // If the billing address is defined, set the related properties.
  const billingAddress = nsCustomer.addressBook?.items?.find(a => a.defaultBilling);
  if (billingAddress) {
    sfAccount.BillingCountry = billingAddress.addressBookAddress?.country?.refName;
    sfAccount.BillingCity = billingAddress.addressBookAddress?.city;
    sfAccount.BillingStreet = billingAddress.addressBookAddress?.addr1;
    sfAccount.BillingState = billingAddress.addressBookAddress?.state;
    sfAccount.BillingPostalCode = billingAddress.addressBookAddress?.zip;
  }

  // If the shipping address is defined, set the related properties.
  const shippingAddress = nsCustomer.addressBook?.items?.find(a => a.defaultShipping);
  if (shippingAddress) {
    sfAccount.ShippingCountry = shippingAddress.addressBookAddress?.country?.refName;
    sfAccount.ShippingCity = shippingAddress.addressBookAddress?.city;
    sfAccount.ShippingStreet = shippingAddress.addressBookAddress?.addr1;
    sfAccount.ShippingState = shippingAddress.addressBookAddress?.state;
    sfAccount.ShippingPostalCode = shippingAddress.addressBookAddress?.zip;
  }

  return sfAccount;
}

/**
 * Maps a NS customer channel tier to a SF account type.
 * @param {NsCustomerChannelTier} channelTier
 * @returns {SfAccountType}
 */
function toSfAccountType(channelTier: NsCustomerChannelTier): SfAccountType {
  switch (channelTier) {
    case NsCustomerChannelTier.EndUser:
      return SfAccountType.Customer;
    case NsCustomerChannelTier.Reseller:
    case NsCustomerChannelTier.Distributor:
      return SfAccountType.Reseller;
    default:
      return SfAccountType.Other;
  }
}
