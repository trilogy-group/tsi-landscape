import { faker } from "@faker-js/faker";
import { NsRecordTypes } from "../api_clients/ns_api_client";
import { SfObjectApiName } from "../api_clients/sf_api_client";
import { NsEmployee, NsEmployeeRoleItem } from "../api_contracts/ns_api_contracts";
import { SfUser } from "../api_contracts/sf_api_contracts";
import { ContextType } from "./steps_types";
import { RootNsSubsidiaryId } from "./subsidiary_utils";
import { must } from "./types";
import { logRecord, throwsIfTrue } from "./utils";

export enum NsRole {
    SalesManager = 9,
    SalesPerson = 10,
}

enum SfUserRole {
    IsrRenewals = '00E2x000000cXlEEAU',
    ManagerRenewals = '00E2x000000cVejEAE',
}

enum SfUserProfile {
    Isr = '00e2x000000csB4AAI',
    TeamManager = '00e2x000000E0WVAA0',
}

/**
 * Creates a NS employee and returns its internal ID.
 * @param {ContextType} context
 * @param {NsEmployee} [nsEmployee] If undefined, create a NS employee with fake data.
 * @returns {Promise<number>} The internal ID of the created NS employee.
 */
export async function createNsEmployeeAsync(context: ContextType, nsEmployee: NsEmployee): Promise<number> {

  // If undefined, build a NS employee with fake data.
  nsEmployee = nsEmployee ?? getFakeNsEmployee();

  // Create the employee record and return its internal ID.
  return await context.nsApiClient.createRecordAsync(NsRecordTypes.Employee, nsEmployee);
}

/**
* Creates a NS employee if it doesn't exist yet.
* @param {ContextType} context
* @param {NsEmployee} nsEmployee
* @param {boolean} overridesFake
* @returns {Promise<number>} The ID of the created or existing NS employee.
*/
export async function createNsEmployeeIfNoneAsync(context: ContextType, nsEmployee?: NsEmployee, overridesFake = false): Promise<number> {

    // If the employee is undefined or an override is required, fill the object with fake data.
    if (!nsEmployee || overridesFake) {
        nsEmployee = getFakeNsEmployee(nsEmployee);
    }

    // Try to retrieve the NS employee for the given names, and create it if it doesn't exist.
    let nsEmployeeId = await context.nsApiClient.readRecordIdAsync(NsRecordTypes.Employee,
        `firstName = '${must(nsEmployee.firstName)}' AND lastName = '${must(nsEmployee.lastName)}'`
    );
    if (nsEmployeeId === null) {
        nsEmployeeId = await createNsEmployeeAsync(context, nsEmployee);
    } else {
        logRecord('NS', NsRecordTypes.Employee, { id: nsEmployeeId, firstName: nsEmployee.firstName, lastName: nsEmployee.lastName });
    }
    return nsEmployeeId;
}

/**
 * Creates a SF user from a given NS employee if it doesn't exist yet.
 * @param {ContextType} context
 * @param {number} nsEmployeeId
 * @param {string} [sfManagerId]
 * @returns {Promise<string>} The ID of the created or existing SF user.
 */
export async function createSfUserIfNoneAsync(context: ContextType, nsEmployeeId: number, sfManagerId?: string): Promise<string> {

  // Try to retrieve SF user for the given NetSuite ID.
  const sfUserIds = await context.sfApiClient.getRecordIdsByNetSuiteIdAsync(SfObjectApiName.User, nsEmployeeId);
  if (sfUserIds.length > 0) {
      const sfUserId = sfUserIds.single();
      logRecord('SF', SfObjectApiName.User, { Id: sfUserId, NetSuite_ID__c: nsEmployeeId })
      return sfUserId;
  }

  // Retrieve NS employee based on given ID.
  const nsEmployee = await context.nsApiClient.getRecord<NsEmployee>(NsRecordTypes.Employee, nsEmployeeId, true, false);
  throwsIfTrue(!nsEmployee, `Cannot retrieve the NS employee '${nsEmployeeId}' to sync data as SF account.`);

  // Create the SF user by mapping data from NS employee and return its ID.
  const sfUser = await toSfUserAsync(context, nsEmployee, sfManagerId);
  return await context.sfApiClient.createRecordAsync(SfObjectApiName.User, sfUser);
}

/**
 * Gets a NS employee with fake data.
 * @param {NsEmployee} override
 * @returns {NsEmployee}
 */
function getFakeNsEmployee(override?: NsEmployee): NsEmployee {
    const password = faker.internet.password() + 'aB3$';
    return {
        email: `${faker.internet.email().toLowerCase()}.invalid`,
        firstName: override?.firstName ?? faker.name.firstName(),
        giveAccess: !!override?.roles,
        issalesrep: true,
        lastName: override?.lastName ?? faker.name.lastName(),
        password: password,
        password2: password,
        roles: override?.roles,
        subsidiary: {
            id: override?.subsidiary?.id ?? RootNsSubsidiaryId.toString()
        },
        supervisor: override?.supervisor,
    };
}

/**
 * Maps a NS employee object to a SF user.
 * @param {ContextType} context
 * @param {NsEmployee} nsEmployee
 * @param {string} [sfManagerId]
 * @returns {Promise<SfUser>}
 */
async function toSfUserAsync(context: ContextType, nsEmployee: NsEmployee, sfManagerId?: string): Promise<SfUser> {

    // If the SF manager ID is undefined and there is a supervisor, retrieve the SF user ID.
    if (!sfManagerId && nsEmployee.supervisor?.id) {
        const sfManagerIds = await context.sfApiClient.getRecordIdsByNetSuiteIdAsync(SfObjectApiName.User, +nsEmployee.supervisor.id);
        throwsIfTrue(sfManagerIds.length === 0, `Cannot retrieve the SF user related to NetSuite ID '${nsEmployee.supervisor.id}'.`);
        sfManagerId = sfManagerIds.single();
    }

    // Determine the SF user permissions from NS employee role items.
    const sfUserPermissions = toSfUserPermissions(nsEmployee.roles?.items);

    // Determine the alias, by considering the first character of the first name, the three first characters of the last name and the number suffix if any.
    const lastNameAliasLength = 3;
    const lastNameSuffix = must(must(nsEmployee.lastName).split(' ').pop());
    const aliasMaxLength = 8;
    const alias = (
        must(nsEmployee.firstName).charAt(0).toLowerCase()
        + must(nsEmployee.lastName).substring(0, lastNameAliasLength).toLowerCase()
        + (Number.isNaN(Number.parseInt(lastNameSuffix)) ? '' : lastNameSuffix)
    ).slice(0, aliasMaxLength);

    // Returns the SF user.
    return {
        Username: nsEmployee.email,
        LastName: nsEmployee.lastName,
        FirstName: nsEmployee.firstName,
        NetSuite_ID__c: nsEmployee.id?.toString(),
        Email: nsEmployee.email,
        Alias: alias,
        TimeZoneSidKey: 'America/New_York',
        LocaleSidKey: 'en_US',
        UserRoleId: sfUserPermissions.role,
        EmailEncodingKey: 'ISO-8859-1',
        ProfileId: sfUserPermissions.profile,
        LanguageLocaleKey: 'en_US',
        ManagerId: sfManagerId,
        echosign_dev1__EchoSign_Allow_Delegated_Sending__c: true,
        echosign_dev1__EchoSign_Email_Verified__c: true,
    };
}

/**
 * Maps NS employee role items to SF permissions.
 * @param {NsEmployeeRoleItem[]} [nsEmployeeRoleItems]
 * @returns {{ role?: SfUserRole, profile?: SfUserProfile }}
 */
function toSfUserPermissions(nsEmployeeRoleItems?: NsEmployeeRoleItem[]): { role?: SfUserRole, profile?: SfUserProfile } {

    // Determine SF user role and profile based on NS roles.
    if (nsEmployeeRoleItems) {
        const nsRoles = nsEmployeeRoleItems.filter(i => i.selectedRole?.id).map(i => +must(i.selectedRole?.id) as NsRole);
        if (nsRoles.includes(NsRole.SalesManager)) {
            return { role: SfUserRole.ManagerRenewals, profile: SfUserProfile.TeamManager };
        } else if (nsRoles.includes(NsRole.SalesPerson)) {
            return { role: SfUserRole.IsrRenewals, profile: SfUserProfile.Isr };
        }
    }

    // By default, no permission.
    return {};
}
