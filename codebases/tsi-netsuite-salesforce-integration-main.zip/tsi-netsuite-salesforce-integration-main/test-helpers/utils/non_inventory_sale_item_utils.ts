import { NsRecordTypes } from "../api_clients/ns_api_client";
import { NsNonInventorySaleItem } from "../api_contracts/ns_api_contracts";
import { ContextType } from "./steps_types";
import { must } from "./types";
import { logRecord } from "./utils";

enum NsItemCategory {
    Other = 9
}

enum NsItemDeferredRevenueAccount {
    Maintenance = 221,
}

enum NsItemDepartement {
    Sales = 2,
}

enum NsItemIncomeAccount {
    Saas = 531,
}

enum NsItemProductLine {
    None = 9,
}

export enum NsItemProductTier {
    Standard = 1,
    Professional = 2,
}

enum NsItemQuantityType {
    Other = 4,
}

enum NsItemRevenueRecognitionType {
    DefaultStandard = 1,
}

export enum NsItemRevenueType {
    Saas = 3,
    RecurringRevenueOther = 4,
    OtherOneTimeRevenue = 7,
}

export enum NsItemSupportLevel {
    Silver = 1
}

/**
 * Creates a NS non-inventory sale item and returns its internal ID.
 * @param {ContextType} context
 * @param {NsNonInventorySaleItem} [nsItem] If undefined, create a NS customer with fake data.
 * @returns {Promise<number>} The internal ID of the created NS non-inventory sale item.
 */
export async function createNsNonInventorySaleItemsAsync(context: ContextType, nsItem?: NsNonInventorySaleItem): Promise<number> {

    // If undefined, build a NS non-inventory sale item with fake data.
    nsItem = nsItem ?? getFakeNsNonInventorySaleItem();

    // Create the item record and return its internal ID.
    return await context.nsApiClient.createRecordAsync(NsRecordTypes.NonInventorySaleItem, nsItem);
}

/**
 * Creates a NS non-inventory sale item if it doesn't exist yet.
 * @param {ContextType} context
 * @param {NsNonInventorySaleItem} nsItem
 * @param {boolean} overridesFake
 * @returns {Promise<number>} The ID of the created or existing NS non-inventory sale item.
 */
export async function createNsNonInventorySaleItemsIfNoneAsync(context: ContextType, nsItem?: NsNonInventorySaleItem, overridesFake = false): Promise<number> {

    // If the item is undefined or an override is required, fill the object with fake data.
    if (!nsItem || overridesFake) {
        nsItem = getFakeNsNonInventorySaleItem(nsItem);
    }

    // Try to retrieve the NS non-inventory sale item for the given name, and create it if it doesn't exist.
    let nsItemId = await context.nsApiClient.readRecordIdAsync(NsRecordTypes.Item, `itemid = '${must(nsItem?.itemid)}'`);
    if (nsItemId === null) {
        nsItemId = await createNsNonInventorySaleItemsAsync(context, nsItem);
    } else {
        logRecord('NS', NsRecordTypes.NonInventorySaleItem, { id: nsItemId, itemid: nsItem?.itemid });
    }
    return nsItemId;
}

/**
 * Gets a NS non-inventory sale item with fake data.
 * @param {NsNonInventorySaleItem} override
 * @returns {NsNonInventorySaleItem}
 */
function getFakeNsNonInventorySaleItem(override?: NsNonInventorySaleItem): NsNonInventorySaleItem {
    return {
        class: override?.class,
        custitem_product_tier: override?.custitem_product_tier,
        custitem_revenue_type: override?.custitem_revenue_type,
        custitem_support_level: override?.custitem_support_level,
        displayname: override?.displayname,
        itemid: must(override?.itemid),
        custitem_item_category: { id: NsItemCategory.Other.toString() },
        custitem_product_line: { id: NsItemProductLine.None.toString() },
        custitem_quantity_type: { id: NsItemQuantityType.Other.toString() },
        deferredrevenueaccount: { id: NsItemDeferredRevenueAccount.Maintenance.toString() },
        department: { id: NsItemDepartement.Sales.toString() },
        incomeaccount: { id: NsItemIncomeAccount.Saas.toString() },
        revenuerecognitionrule: { id: NsItemRevenueRecognitionType.DefaultStandard.toString() },
    };
}
