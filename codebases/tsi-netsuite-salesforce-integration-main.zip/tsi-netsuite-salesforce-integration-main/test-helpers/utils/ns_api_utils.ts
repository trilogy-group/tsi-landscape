import { XmlNamespace } from "../api_clients/ns_api_client";
import { Ref } from "../api_contracts/ns_api_contracts";
import { Any } from "./types";

/**
 * Represents the custom field type.
 */
export enum CustomFieldType {
    SelectCustomFieldRef = 'SelectCustomFieldRef',
    MultiSelectCustomFieldRef = 'MultiSelectCustomFieldRef'
}

/**
 * Adds the given field to a record if the value is defined.
 * @param {Any & { record: Any }} record
 * @param {string} key
 * @param {Any} value
 */
export function addFieldRecordIfDefined(record: Any & { record: Any }, key: string, value: Any): void {
    if (value) {
        record.record[key] = value;
    }
}

/**
 * Add the given custom field to the given array if the value is defined.
 * @param {Any[]} customFields
 * @param {CustomFieldType} type
 * @param {number} internalId
 * @param {number | string | undefined} value
 */
export function addCustomFieldRecordIfDefined(customFields: Any[], type: CustomFieldType, internalId: number, value: number | string | undefined): void {
    if (value) {
        customFields.push(buildCustomField(internalId, type, [ value ]));
    }
}

/**
 * Builds the custom field for the given internal ID, type and values.
 * @param {number} internalId
 * @param {string} type
 * @param {(number | string)[]} values
 * @returns {Any}
 */
function buildCustomField(internalId: number, type: string, values: (number | string)[]): Any {
    return {
        $: {
            'internalId': internalId,
            'xsi:type': `platformCore:${type}`
        },
        'platformCore:value': values.map((v: number | string) => {
            return {
                $: {
                    'internalId': v.toString()
                }
            };
        })
    };
}

/**
 * Builds the custom field list.
 * @param {Any[]} customFields
 * @returns {Any}
 */
export function buildCustomFieldList(customFields: Any[]): Any {
    if (customFields.length > 0) {
        return {
            $: {
                'xmlns:platformCore': XmlNamespace.CORE
            },
            'platformCore:customField': customFields
        };
    }
    return undefined;
}

/**
 * Loads the value of a custom field as Ref.
 * @param {Any[]} customFields
 * @param {string} customFieldId
 * @returns {Ref | undefined}
 */
export function loadCustomFieldAsRefOrDefault(customFields: Any[], customFieldId: number): Ref | undefined {
    return loadCustomField<Ref>(customFields, customFieldId, mapValueAsRef)
        .singleOrDefault() ?? undefined;
}

/**
 * Loads the values from a custom field with the given mapping.
 * @param {Any[]} customFields
 * @param {string} customFieldId
 * @param {(Any) => T} fnMapValue
 * @returns {T[]}
 */
function loadCustomField<T>(customFields: Any[], customFieldId: number, fnMapValue: (value: Any) => T): T[] {
    const customField = customFields
        .firstOrDefault(i => i.$.internalId === customFieldId.toString());
    return customField ? customField['platformCore:value'].map(fnMapValue) : [];
}

/**
 * Maps a value as Ref.
 * @param {Any} value
 * @returns {Ref}
 */
function mapValueAsRef(value: Any): Ref {
    return {
        id: value.$.internalId,
        refName: value['platformCore:name'].single()
    };
}
