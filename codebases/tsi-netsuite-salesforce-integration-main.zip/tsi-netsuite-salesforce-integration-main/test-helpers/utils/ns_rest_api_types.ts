export interface SubscriptionPlan {
    autoRenewal: boolean;
    class: Entity;
    createdDate: Date;
    custitemistrial: boolean;
    customForm: Entity;
    defaultRenewalTerm: Entity;
    description: string;
    displayName: string;
    externalId: string;
    id: string;
    includeChildren: boolean;
    incomeAccount: Entity;
    initialTerm: Entity;
    isInactive: boolean;
    itemId: string;
    itemType: Entity;
    lastModifiedDate: Date;
    member: Member;
    subsidiary: Subsidiary;
}

export interface Entity {
    id: string;
    refName?: string;
}

export interface Member {
    items: MemberItem[];
    totalResults: number;
}

export interface MemberItem {
    billingMode: Entity;
    isRequired: boolean;
    item: Entity;
    lineNumber: number;
    prorateEndDate: boolean;
    prorateStartDate: boolean;
    renewalOption: Entity;
    revRecOption: Entity;
    subscriptionLineType: Entity;
}

export interface Subsidiary {
    count: number;
    hasMore: boolean;
    items: Entity[];
    offset: number;
    totalResults: number;
}

export interface Priceplan {
    currency: Entity;
    customForm: Entity;
    id: string;
    pricePlanType: Entity;
    priceTiers: PriceTiers;
}

export interface PriceTiers {
    items: PriceTiersItem[];
    totalResults: number;
}

export interface PriceTiersItem {
    fromVal: number;
    lineId: number;
    pricingOption: Entity;
    value: number;
}

export interface Pricebook {
    currency: Entity;
    customForm: Entity;
    externalId: string;
    id: string;
    name: string;
    priceInterval: PriceInterval;
    subscriptionPlan: Entity;
}

export interface PriceInterval {
    items: PriceIntervalItem[];
    totalResults: number;
}

export interface PriceIntervalItem {
    chargeType: Entity;
    frequency: Entity;
    id: number;
    isRequired: boolean;
    item: Entity;
    lineNumber: number;
    pricePlan: Entity;
    prorateBy: Entity;
    repeatEvery: number;
    startOffsetUnit: Entity;
    startOffsetValue: number;
    subscriptionPlanLineNumber: number;
}
