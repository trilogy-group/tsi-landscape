import { SfApiClient } from "../api_clients/sf_api_client";
import { OpportunityProductRec, OpportunityRec, RecordsResponseData } from "../api_contracts/sf_api_contracts";
import { HttpStatusCode } from "./types";
import { log } from "./utils";

/**
 * Moves opportunity to stage
 *
 * @export
 * @param {SfApiClient} sfApiClient
 * @param {string} sfOpportunityId
 * @param {number} nsRenewalSubscriptionId
 * @param {Cleaner} cleaner
 * @param {(string | Record<string, string>[])} stageName
 */
export async function moveOpportunityToStage(
  sfApiClient: SfApiClient,
  sfOpportunityId: string,
  stageName: string | Record<string, string>[]
) {
  const respCode = await sfApiClient.updateOpportunityStage(sfOpportunityId, stageName as string);
  expect(respCode).toBe(HttpStatusCode.NoContent);
}


/**
 * Gets opportunity products
 *
 * @export
 * @param {SfApiClient} sfApiClient
 * @param {string} sfOpportunityId
 * @return {*}  {Promise<RecordsResponseData<OpportunityProductRec>>}
 */
export async function getOpportunityProducts(
  sfApiClient: SfApiClient,
  sfOpportunityId: string
): Promise<RecordsResponseData<OpportunityProductRec>> {
  const productsResp = await sfApiClient.getOpportunityProducts(sfOpportunityId);
  return productsResp.data;
}

/**
 * Gets opportunity from SalesForce
 *
 * @export
 * @param {SfApiClient} sfApiClient
 * @param {string} sfOpportunityId
 * @return {*}  {Promise<OpportunityRec>}
 */
export async function getOpportunity(sfApiClient: SfApiClient, sfOpportunityId: string): Promise<OpportunityRec> {
  const opportunityResp = await sfApiClient.getOpportunityById(sfOpportunityId);
  // assert record was retrieved successfully
  expect(opportunityResp.status).toBe(HttpStatusCode.Ok);
  expect(opportunityResp.data.totalSize).toBeGreaterThanOrEqual(1);
  expect(opportunityResp.data.records.length).toBeGreaterThanOrEqual(1);
  expect(opportunityResp.data.records[0].Id).not.toBeUndefined();
  return opportunityResp.data.records[0];
}

/**
 * Creates a quote in SalesForce
 *
 * @export
 * @param {SfApiClient} sfApiClient
 * @param {string} sfOpportunityId
 * @param {string} sfAccountId
 * @param {string} sfContactId
 * @return {*}  {Promise<string>}
 */
export async function createQuote(
  sfApiClient: SfApiClient,
  sfOpportunityId: string,
  sfAccountId: string,
  sfContactId: string,
  startDate?: string
): Promise<string> {
  if (!startDate) {
    startDate = `${new Date().getFullYear() + 1}-01-01`;
  }
  const resp = await sfApiClient.createQuote({
    opportunityId: sfOpportunityId,
    accountId: sfAccountId,
    contactId: sfContactId,
    startDate: startDate,
  });
  expect(resp.quoteId).not.toBeUndefined();
  log(`Sf Quote has been created. Id: ${resp.quoteId}`);
  expect(resp.quoteLineIds.length).not.toBe(0);
  return resp.quoteId;
}

/**
 * Creates a quote in SalesForce
 *
 * @export
 * @param {SfApiClient} sfApiClient
 * @param {string} quoteId
 * @param {string} productCode
 * @return {*}  {Promise<void>}
 */
export async function addProductToQuote(
  sfApiClient: SfApiClient,
  quoteId: string,
  productCode: string,
): Promise<string> {
  const product = await sfApiClient.getSoqlQuery<{ Id: string; Min_Quantity__c: number; }>(`
    SELECT Id, Min_Quantity__c
    FROM Product2 WHERE ProductCode =  '${productCode}'
  `);
  return await sfApiClient.addProductToQuote({
    quoteId: quoteId,
    productId: product.data.records[0].Id,
    productCode: productCode,
    quantity: product.data.records[0].Min_Quantity__c,
  });
}
