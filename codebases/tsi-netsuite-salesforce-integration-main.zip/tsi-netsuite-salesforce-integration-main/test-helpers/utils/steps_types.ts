import { NsApiClient } from '../api_clients/ns_api_client'
import { SfApiClient } from '../api_clients/sf_api_client'
import { TrayIOApiClient } from '../api_clients/ti_api_client';
import {
  NsClass, NsDefaultCustomerSubsidiary, NsSubsidiary,
  NsQuoteRec, NsSubscriptionChangeOrderRec, SubscriptionRec
} from '../api_contracts/ns_api_contracts';
import {
  RecordsResponseData,
  SfAccount, SfDefaultAccountSubsidiary, SfProductConfiguration, SfSubsidiary,
  OpportunityProductRec, OpportunityRec, SfQuoteRec
} from '../api_contracts/sf_api_contracts';
import { Cleaner } from './cleaner';
import { SubscriptionPlan } from './ns_rest_api_types';
import { Any } from './types';

export const time20seconds = 20000;
export const time30seconds = 30000;
export const time90seconds = 90000;
export const time180seconds = 180000;
export const waitForRecMaxDelay = 60000; //ms
export const waitForWorkflowMaxDelay = 30000; //ms
export const waitForRecInitialDelay = 5000; //ms
export const waitForRecMaxAttempts = 10;
export const waitForWorkflowCompletedAttempts = 10;

export type ContextType = {
  startTime: Date,
  cleaner: Cleaner;
  fakeCustomerData: {
    customerName: string;
    customerEmail: string;
    customerPhone: string;
    customerFax: string;
    customerWebSite: string;
    billingAddrCountry: string;
    billingAddrPostalCode: string;
    billingAddrState: string;
    billingAddrCity: string;
    billingAddrStreet: string;
    shippingAddrCountry: string;
    shippingAddrPostalCode: string;
    shippingAddrState: string;
    shippingAddrCity: string;
    shippingAddrStreet: string;
  };
  fakeContactData: {
    contactTitle: string;
    contactSalutation: string;
    contactFirstName: string;
    contactLastName: string;
    contactMiddleName: string;
    contactEmail: string;
    contactPhone: string;
    contactMobilePhone: string;
    contactFax: string;
    contactDescription: string;
  };

  nsApiClient: NsApiClient;
  nsClass?: NsClass;
  nsClassId?: number;
  nsClassLastSyncStatusTimestamp?: string,
  nsClassName?: string;
  nsCustomerId?: number;
  nsCustomerLastSyncStatusTimeStamp?: string;
  nsContactId?: number;
  nsContact: {
    title?: string;
    salutation?: string;
    firstName?: string;
    lastName?: string;
    middleName?: string;
    email?: string;
    phone?: string;
    mobilePhone?: string;
    fax?: string;
    comments?: string;
  };
  productSyncData: {
    newPlan: SubscriptionPlan;
    pricebookMap: Map<string, number>;
  }
  nsContactLastSyncStatusTimeStamp?: string;
  nsDefaultCustomerSubsidiary?: NsDefaultCustomerSubsidiary;
  nsSubsidiary?: NsSubsidiary;
  nsSubsidiaryId?: number;
  nsSubsidiaryName?: string;
  nsSubsidiaryCurrencyName?: string;
  nsSubsidiaryIdsByName?: Record<string, number>;
  nsRenewalSubscription: SubscriptionRec;
  nsRenewalSubscriptionId?: number | null;
  nsOldRenewalSubscriptionId?: number | null;
  nsFirstRenewalSubscriptionId?: number;
  nsRenewalSubscriptionLastSyncStatusTimeStamp?: string;
  nsParentSubscriptionId: number;
  nsParentSubscriptionRec?: SubscriptionRec;
  nsCurrentSubscriptionIncludedLinesNumber: number;
  nsLastRenewalSubscriptionChangeOrder?: NsSubscriptionChangeOrderRec;
  nsLastChangeOrderId?: number;
  nsQuoteId?: number | null;
  nsQuoteRec?: NsQuoteRec;
  nsSubscriptionPlanId: number;

  sfApiClient: SfApiClient;
  sfAccount?: SfAccount;
  sfAccountId?: string;
  sfDefaultAccountSubsidiary?: SfDefaultAccountSubsidiary;
  sfPartnerAccount?: SfAccount | null;
  sfResellerAccountId?: string;
  sfResellerAgreementId: string;
  sfContact: Any;
  sfContactId?: string;
  sfOpportunityContactRoleId?: string;
  sfOpportunityId?: string;
  sfOpportunityOwnerEmail?: string;
  sfOpportunityRec?: OpportunityRec;
  sfOpportunityProductsData: RecordsResponseData<OpportunityProductRec>;
  sfQuoteId: string;
  sfQuoteRec?: SfQuoteRec | null;
  sfQuoteLastSyncStatusTimeStamp?: string;
  sfPriceBookId: number;
  sfProductConfiguration?: SfProductConfiguration;
  sfSubsidiary?: SfSubsidiary;
  sfSubsidiariesByNsSubsidiaryId?: Record<number, SfSubsidiary>;
  sfCurrentArr?: number;

  tiApiClient: TrayIOApiClient;

  lastResponse: Any;
}
