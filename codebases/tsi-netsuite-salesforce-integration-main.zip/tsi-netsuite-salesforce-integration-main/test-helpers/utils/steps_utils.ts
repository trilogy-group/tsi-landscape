// THIS FILE CONTAINS ONLY SOME METHODS RELATED TO INITIALIZATION AND WAITING FLOWS TO FINISH
// OTHER THAN THAT, ADD NEW METHODS TO OTHER UTIL FILES OR CREATE A NEW FILE

import { ExponentialBackoff, handleAll, IRetryContext, retry } from 'cockatiel';
import {
  ContextType,
  time180seconds,
  time30seconds,
  waitForRecInitialDelay,
  waitForRecMaxDelay,
  waitForWorkflowCompletedAttempts,
  waitForWorkflowMaxDelay,
} from './steps_types';
import { Cleaner } from './cleaner';
import { NsApiClient } from '../api_clients/ns_api_client';
import { SfApiClient } from '../api_clients/sf_api_client';
import { FlowExecutionState, FlowExecutionStateResponse, FlowRelatedEntityKind, TrayIOApiClient, Workflow, WorkflowKind } from '../api_clients/ti_api_client';
import { Any, HttpStatusCode } from './types';
import { log } from './utils';

/**
 * Creates NetSuite and SalesForceApi clients and a cleaner instance
 * @returns the NetSuite and SalesForceApi clients and a cleaner instance
 */
export function initializeServices() {
  const nsApiClient = new NsApiClient();
  const sfApiClient = new SfApiClient();
  const tiApiClient = new TrayIOApiClient();
  const cleaner = new Cleaner();
  return { nsApiClient, sfApiClient, tiApiClient, cleaner };
}

/**
 * Waits until the record is updated and returns it
 * @param fn The record get function
 * @returns get record api response
 */
export async function getRecUntilItIsUpdated<T>(
  fn: (context: IRetryContext) => PromiseLike<T> | T,
  expectedDataCheckFn: (data: T) => boolean
): Promise<T> {
  const handlePolicy = handleAll.orWhenResult((data: Any) => !data || !expectedDataCheckFn(data));
  const retryPolicy = retry(handlePolicy, {
    maxAttempts: 10,
    backoff: new ExponentialBackoff({
      maxDelay: waitForRecMaxDelay, //ms
      initialDelay: waitForRecInitialDelay, //ms
    }),
  });
  return await retryPolicy.execute(fn);
}

/**
 * Runs and waits for draft renewal sync
 * @param {ContextType} context
 * @param {number} nsSubscriptionId
 * @param {string} [afterTimeStamp]
 * @return {*}  {Promise<FlowExecutionStateResponse>}
 */
export async function runAndwaitForSyncOfNsSubscriptionIntoSfGetItsIdByNsId(
  context: ContextType,
  nsSubscriptionId: number,
  afterTimeStamp?: string
): Promise<{ opportunityId: string; nsRenewalSubscriptionLastSyncStatusTimeStamp: string }> {
  const status = await context.tiApiClient.runCallableFlow(nsSubscriptionId, WorkflowKind.SyncSfRenewalOpportunityOnNsDraftRenewalSubscriptionUpdated);

  expect(status).toBe(HttpStatusCode.Ok);

  const workflowExecutionState = await context.tiApiClient.waitForFlowCompletion(
    FlowRelatedEntityKind.ns_draft_renewal_subscription_id,
    nsSubscriptionId.toString(),
    time180seconds,
    time30seconds,
    waitForWorkflowCompletedAttempts,
    afterTimeStamp
  );

  expect((FlowExecutionState as Any)[workflowExecutionState.status]).toBe(FlowExecutionState.Completed);

  const opportunityByNsIdResp = await context.sfApiClient.getOpportunityByNsId(nsSubscriptionId);

  // assert record was retrieved successfully
  expect(opportunityByNsIdResp.status).toBe(HttpStatusCode.Ok);
  expect(opportunityByNsIdResp.data.totalSize).toBeGreaterThanOrEqual(1);
  expect(opportunityByNsIdResp.data.records.length).toBeGreaterThanOrEqual(1);
  expect(opportunityByNsIdResp.data.records[0].Id).not.toBeUndefined();

  log(`Sf Opportunity has been created. Id: ${opportunityByNsIdResp.data.records[0].Id}.`);

  return {
    opportunityId: opportunityByNsIdResp.data.records[0].Id,
    nsRenewalSubscriptionLastSyncStatusTimeStamp: workflowExecutionState.timestamp,
  };
}

/**
 * Runs and waits for draft renewal subscription sync by workflow kind.
 * Expecting only on activation / termination.
 * @param {ContextType} context
 * @param {WorkflowKind} workflowKind
 * @param {number} nsSubscriptionId
 * @param {number} [changeOrderId]
 * @returns {Promise<{nsRenewalSubscriptionLastSyncStatusTimeStamp: string}>}
 */
export async function runAndWaitForStageChangeSyncByWorkflowKind(
  context: ContextType,
  workflowKind: WorkflowKind,
  nsSubscriptionId: number,
  changeOrderId?: number,
): Promise<{ nsRenewalSubscriptionLastSyncStatusTimeStamp: string }> {

  // Run the flow syncing SF opportunity on NS Subscription activation / termination.
  const triggerTimestamp = (new Date()).toISOString();
  const status = await context.tiApiClient.runCallableFlowWithObjectParam({ id: nsSubscriptionId.toString(), changeOrderId }, workflowKind);
  expect(status).toBe(HttpStatusCode.Ok);

  // Wait for the target subflow to be completed. This subflow is asynchronously called by Run Callable Flow.
  const triggeredWorkflowExecutionState = await context.tiApiClient.waitForFlowCompletion(
    FlowRelatedEntityKind.ns_draft_renewal_subscription_id,
    nsSubscriptionId.toString(),
    waitForWorkflowMaxDelay,
    waitForRecInitialDelay,
    waitForWorkflowCompletedAttempts,
    triggerTimestamp
  );
  expect((FlowExecutionState)[triggeredWorkflowExecutionState.status]).toBe(FlowExecutionState.Completed);

  return {
    nsRenewalSubscriptionLastSyncStatusTimeStamp: triggeredWorkflowExecutionState.timestamp
  };
}

/**
 * Wait for sync subscription orders created the last 24h to be processed
 */
export async function runAndWaitForChangeOrderProcessed(
  context: ContextType,
  nsSubscriptionId: number,
  changeOrderId: number,
  type: 'activation' | 'termination',
): Promise<{ timestamp: string }> {

  // Run the flow triggering the change order processing.
  const triggerTimestamp = (new Date()).toISOString();
  const status = await context.tiApiClient.runCallableFlowWithObjectParam({ id: nsSubscriptionId.toString(), changeOrderId }, WorkflowKind.ScheduledChangeOrderProcessing);
  expect(status).toBe(HttpStatusCode.Ok);

  // Determine the subflows triggered asynchronously by the flow and based on the NS draft renewal subscription ID.
  const subflows = [ Workflow.TriggerCreateProvisioningZdTicket ];
  if (type === 'activation') {
    subflows.push(Workflow.TriggerOnNsSubActivationCloseWinSfOpportunity);
  }
  if (type === 'termination') {
    subflows.push(Workflow.TriggerOnNsSubTerminationCloseLostSfOpportunity);
  }

  // Get the execution state for all subflows.
  const executionStates: FlowExecutionStateResponse[] = [];
  for (const subflow of subflows) {
    const executionState = await context.tiApiClient.waitForFlowCompletion(
      FlowRelatedEntityKind.ns_draft_renewal_subscription_id,
      nsSubscriptionId.toString(),
      waitForWorkflowMaxDelay,
      waitForRecInitialDelay,
      waitForWorkflowCompletedAttempts,
      triggerTimestamp,
      subflow,
    );
    expect((FlowExecutionState)[executionState.status]).toBe(FlowExecutionState.Completed);
    executionStates.push(executionState);
  }

  // Returns the late timestamp.
  return {
    timestamp: executionStates.map(s => s.timestamp).sort()[executionStates.length - 1],
  };
}

/**
 * Wait for sync of salesforce quote to netsuite quote and return the quoteId and timestamp when the flow finished
 */
export async function waitForSyncOfSfQuoteToNsQuoteAndGetIt(
  context: ContextType,
  sfQuoteId: string,
  afterTimeStamp?: string
): Promise<{ nsQuoteId?: number | null; sfQuoteLastSyncStatusTimeStamp: string }> {
  const workflowExecutionState = await context.tiApiClient.waitForFlowCompletion(
    FlowRelatedEntityKind.sf_quote_id,
    sfQuoteId,
    time180seconds,
    time30seconds,
    waitForWorkflowCompletedAttempts,
    afterTimeStamp
  );
  expect((FlowExecutionState as Any)[workflowExecutionState.status]).toBe(FlowExecutionState.Completed);

  const quote = await context.sfApiClient.getQuote(sfQuoteId);

  return {
    nsQuoteId: quote?.NetSuite_ID__c ? Number(quote?.NetSuite_ID__c) : null,
    sfQuoteLastSyncStatusTimeStamp: workflowExecutionState.timestamp,
  };
}
