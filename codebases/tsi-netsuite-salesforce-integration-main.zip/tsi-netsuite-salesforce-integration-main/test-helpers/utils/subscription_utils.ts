import { DefaultContractualDocumentId, NsApiClient } from '../api_clients/ns_api_client';
import { NsSubscriptionStatusId, SubscriptionRec } from '../api_contracts/ns_api_contracts';
import { Any } from './types';
import { log, toIsoDateOnly } from './utils';

/**
 * Loads subscription plan and price book by their names from NetSuite
 * @export
 * @param {NsApiClient} nsApiClient api client instance
 * @param {string} planName
 * @param {string} priceBookName
 * @return {*}  {Promise<{ subscriptionPlan: Any; priceBook: Any }>}
 */
export async function getNsPlanAndPriceBook(
  nsApiClient: NsApiClient,
  planName: string,
  priceBookName: string
): Promise<{ subscriptionPlan: Any; priceBook: Any }> {
  const subscriptionPlan = await nsApiClient.getSubscriptionPlanByName(planName, true);
  expect(subscriptionPlan, `Couldn't get subscription plan '${planName}'.`).toBeTruthy();

  const priceBook = await nsApiClient.getPriceBookByName(priceBookName, subscriptionPlan.id, true);
  expect(priceBook, `Couldn't get price book '${priceBookName}' of plan '${planName}'.`).toBeTruthy();
  return { subscriptionPlan, priceBook };
}

/**
 * Creates a new draft renewal subscription in NetSuite
 *
 * @export
 * @param {NsApiClient} nsApiClient api client instance
 * @param {number} nsCustomerId customer id
 * @param {number} nsParentSubscriptionId parent subscription id
 * @param {string} planName name of the subscription plan
 * @param {string} priceBookName name of the price book
 * @return {Promise<{ renewalSubscriptionId: number; renewChangeOrderId: number }>} id of subscription plan and price book
 */
export async function createNsDraftRenewalSubscription(
  nsApiClient: NsApiClient,
  nsCustomerId: number,
  nsParentSubscriptionId: number,
  planName: string,
  priceBookName: string
): Promise<{ renewalSubscriptionId: number; renewChangeOrderId: number }> {
  const { subscriptionPlan, priceBook } = await getNsPlanAndPriceBook(
    nsApiClient,
    planName,
    priceBookName
  );

  const renewChangeOrderId = await nsApiClient.renewSubscription({
    customerId: nsCustomerId,
    subscriptionId: nsParentSubscriptionId,
    subscriptionPlanId: Number.parseInt(subscriptionPlan.id),
    priceBookId: Number.parseInt(priceBook.id),
  });
  const renewChangeOrder = await nsApiClient.getRecord<Any>('subscriptionchangeorder', renewChangeOrderId, true);
  const renewalSubscriptionId = renewChangeOrder.renewalSteps.items[0]?.subscription.id;
  expect(renewalSubscriptionId).not.toBeUndefined();

  return { renewalSubscriptionId: Number.parseInt(renewalSubscriptionId), renewChangeOrderId };
}

/**
 * Returns the subscription for the given subscription ID.
 *
 * @param {NsApiClient} nsApiClient
 * @param {number} nsSubscriptionId
 * @returns {Promise<SubscriptionRec>}
 */
export async function getNsSubscription(
  nsApiClient: NsApiClient,
  nsSubscriptionId: number
): Promise<SubscriptionRec> {
  const nsSubscription = await nsApiClient.getRecord<SubscriptionRec>('subscription', nsSubscriptionId, true);
  expect(nsSubscription).not.toBeUndefined();
  return nsSubscription;
}

/**
 * Activates a subscription in NetSuite
 *
 * @export
 * @param {NsApiClient} nsApiClient
 * @param {number} nsCustomerId
 * @param {number} nsSubscriptionId
 * @param {number} includedLinesNumber
 * @param {Date} startDate
 */
export async function activateNsSubscription(
  nsApiClient: NsApiClient,
  nsCustomerId: number,
  nsSubscriptionId: number,
  includedLinesNumber: number,
  startDate: Date
): Promise<number> {
  await nsApiClient.updateSubscription(nsSubscriptionId, {
    custrecord_contract_docs: DefaultContractualDocumentId,
    subscriptionline: {
      items: nsApiClient.createLinesArray(includedLinesNumber, NsSubscriptionStatusId.PendingActivation),
    },
  });

  const startDateParam = toIsoDateOnly(startDate);
  return await nsApiClient.activateSubscription({
    customerId: nsCustomerId,
    subscriptionId: nsSubscriptionId,
    startDate: startDateParam,
    includedLinesNumber: includedLinesNumber,
  });
}

/**
 * Deletes draf renewal subscription
 *
 * @export
 * @param {NsApiClient} nsApiClient
 * @param {number} nsRenewalSubscriptionId
 * @param {Cleaner} cleaner
 */
export async function deleteDraftRenewalSubscription(
  nsApiClient: NsApiClient,
  nsRenewalSubscriptionId: number
) {
  await nsApiClient.deleteSubscription(nsRenewalSubscriptionId);
}

/**
 * Creates new draft renewal subscription in NetSuite
 *
 * @export
 * @param {NsApiClient} nsApiClient
 * @param {number} nsCustomerId
 * @param {number} nsParentSubscriptionId
 * @param {number} nsRenewalSubscriptionId
 * @param {Cleaner} cleaner
 * @param {(string | Record<string, string>[])} planName
 * @param {(string | Record<string, string>[])} priceBookName
 * @return {*}
 */
export async function createNewDraftRenewalSubscriptionInNetSuite(
  nsApiClient: NsApiClient,
  nsCustomerId: number,
  nsParentSubscriptionId: number,
  planName: string | Record<string, string>[],
  priceBookName: string | Record<string, string>[]
) {
  const { renewalSubscriptionId } = await createNsDraftRenewalSubscription(
    nsApiClient,
    nsCustomerId,
    nsParentSubscriptionId,
    planName as string,
    priceBookName as string
  );
  log(`Draft renewal subcription has been created. Id: ${renewalSubscriptionId}`);

  return renewalSubscriptionId;
}
