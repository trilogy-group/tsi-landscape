import { faker } from "@faker-js/faker";
import { ContextType } from "./steps_types";
import { Any, must } from "./types";
import { log, logRecord, throwsIfTrue } from "./utils";
import { USDCurrencyId, SoapCountry, XmlNamespace, NsRecordTypes } from "../api_clients/ns_api_client";
import { NsAddress, NsSubsidiary } from "../api_contracts/ns_api_contracts";
import { SfObjectApiName } from "../api_clients/sf_api_client";
import { SfSubsidiary } from "../api_contracts/sf_api_contracts";
import { CleanerRec, CleanType } from "./cleaner";

export const RootNsSubsidiaryId = 9;

/**
 * Creates a NS subsidiary and returns its internal ID.
 * @param {ContextType} context
 * @param {NsSubsidiary} [subsidiary] If undefined, create a NS subsidiary with fake data.
 * @returns {Promise<number>} The internal ID of the created NS subsidiary.
 */
export async function createNsSubsidiaryAsync(context: ContextType, subsidiary?: NsSubsidiary): Promise<number> {

    // If undefined, build a NS subsidiary with fake data.
    subsidiary = subsidiary ?? getFakeNsSubsidiary();

    // Map it to SOAP record and add it. Return the internal ID.
    const record = toSoapRecord(subsidiary);
    const subsidiaryId = await context.nsApiClient.soapAddAsync(record);
    logRecord('NS', NsRecordTypes.Subsidiary, { id: subsidiaryId, name: subsidiary.name }, 'CREATED');
    return subsidiaryId;
}

/**
 * Creates a NS subsidiary if it doesn't exist yet.
 * @param {ContextType} context
 * @param {NsSubsidiary} subsidiary
 * @param {boolean} overridesFake
 * @returns {Promise<number>} The ID of the created or existing NS subsidiary.
 */
export async function createNsSubsidiaryIfNoneAsync(context: ContextType, subsidiary?: NsSubsidiary, overridesFake = false): Promise<number> {

    // If the subsidiary is undefined or an override is required, fill the object with fake data.
    if (!subsidiary || overridesFake) {
        subsidiary = getFakeNsSubsidiary(subsidiary);
    }

    // Try to retrieve the NS subsidiary for the given name, and create it if it doesn't exist.
    let subsidiaryId = await context.nsApiClient.readRecordIdAsync(NsRecordTypes.Subsidiary, `name = '${must(subsidiary.name)}'`);
    if (subsidiaryId === null) {
        subsidiaryId = await createNsSubsidiaryAsync(context, subsidiary);
    } else {
        logRecord('NS', NsRecordTypes.Subsidiary, { id: subsidiaryId, name: subsidiary.name });
    }
    return subsidiaryId;
}

/**
 * Creates a SF subsidiary from a given NS subsidiary if it doesn't exist yet.
 * @param {ContextType} context
 * @param {number} nsSubsidiaryId
 * @returns {Promise<string>} The ID of the created or existing SF subsidiary.
 */
export async function createSfSubsidiaryIfNoneAsync(context: ContextType, nsSubsidiaryId: number): Promise<string> {

    // Try to retrieve SF subsidiary for the given NetSuite ID.
    const sfSubsidiaryIds = await context.sfApiClient.getRecordIdsByNetSuiteIdAsync(SfObjectApiName.Subsidiary, nsSubsidiaryId);
    if (sfSubsidiaryIds.length > 0) {
        const sfSubsidiaryId = sfSubsidiaryIds.single();
        logRecord('SF', SfObjectApiName.Subsidiary, { Id: sfSubsidiaryId, NetSuite_ID__c: nsSubsidiaryId })
        return sfSubsidiaryId;
    }

    // Retrieve NS subsidiary based on given ID.
    const nsSubsidiary = await context.nsApiClient.getRecord<NsSubsidiary>(NsRecordTypes.Subsidiary, nsSubsidiaryId, true, false);
    throwsIfTrue(!nsSubsidiary, `Cannot retrieve the NS subsidiary '${nsSubsidiaryId}' to sync data as SF subsidiary.`);

    // Create the SF subsidiary by mapping data from NS subsidiary and return its ID.
    const sfSubsidiary = await toSfSubsidiaryAsync(context, nsSubsidiary);
    return await context.sfApiClient.createRecordAsync(SfObjectApiName.Subsidiary, sfSubsidiary);
}

/**
 * Returns the NetSuite ID field by SF subsidiary ID.
 * @param {ContextType} context
 * @param {string[]} sfSubsidiaryIds Array of SF subsidiary ID. Can contains duplicate.
 * @returns {Promise<Record<string, number>>}
 */
export async function getNetSuiteIdBySfSubsidiaryId(context: ContextType, sfSubsidiaryIds: string[]): Promise<Record<string, number>> {

    // Remove any duplicate SF subsidiary IDs.
    sfSubsidiaryIds = sfSubsidiaryIds.filter((v, i) => sfSubsidiaryIds.indexOf(v) === i);

    // Retrieve all NetSuite ID for the given SF subsidiaries.
    const query = `
        SELECT Id, Netsuite_Id__c
        FROM ${SfObjectApiName.Subsidiary}
        WHERE Id IN ('${sfSubsidiaryIds.join("','")}')
    `;
    const records = await context.sfApiClient.getRecordsByQueryAsync<SfSubsidiary>(query);
    expect(records.length).toEqual(sfSubsidiaryIds.length);

    // Return the data from the records.
    return Object.assign({}, ...records
        .map(v => {
            return { [must(v.Id)]: +must(v.Netsuite_Id__c) }
        })
    );
}

/**
 * Retrieves the SF subsidiary based on the NetSuite ID.
 * @param {ContextType} context
 * @returns {Promise<SfSubsidiary>}
 */
export async function getSfSubsidiaryByNsSubsidiaryId(context: ContextType, nsSubsidiaryId?: number): Promise<SfSubsidiary> {
    return await context.sfApiClient.getRecordByNetSuiteIdAsync<SfSubsidiary>(
        SfObjectApiName.Subsidiary,
        nsSubsidiaryId ?? must(context.nsSubsidiaryId)
    );
}

/**
 * Returns the subsidiary IDs by name.
 * @param {ContextType} context
 * @param {string[]} names
 * @returns {Promise<Record<string, number>>}
 */
export async function getNsSubsidiaryIdsByName(context: ContextType, names: string[]): Promise<Record<string, number>> {

    // Build the query to retrieve subsidiary IDs.
    const query = `
        SELECT id, name 
        FROM subsidiary 
        WHERE name in ('${names.join("','")}')
    `;

    // Execute the query and expect as many items as the number of subsidiary names.
    const results = await context.nsApiClient.queryWithSuiteQL<{ id: number, name: string }>(query);
    expect(results.count).toEqual(names.length);

    // Return the result items.
    return Object.assign({}, ...results.items
        .map(v => {
            return { [v.name]: +v.id };
        })
    );
}

/**
 * Updates a NS subsidiary with fake data.
 * @param {ContextType} context
 * @param {number} subsidiaryId
 */
export async function updateNsSubsidiaryAsync(context: ContextType, subsidiaryId: number): Promise<void> {

    // Build a NS subsidiary with fake data and set the ID.
    const subsidiary = getFakeNsSubsidiary({ mainAddress: { country: { id: SoapCountry.CANADA }}});
    subsidiary.id = subsidiaryId;

    // Map it to SOAP record and update it.
    const record = toSoapRecord(subsidiary);
    await context.nsApiClient.soapUpdateAsync(record);
    log(`NS Subsidiary has been updated. ID: ${subsidiaryId}, name: ${subsidiary.name}`);
}

/**
 * Gets a NS subsidiary with fake data.
 * @param {NsSubsidiary} override
 * @returns {NsSubsidiary}
 */
function getFakeNsSubsidiary(override?: NsSubsidiary): NsSubsidiary {
    const millisecondsPerSecond =  1000;
    const name = override?.name ?? `E2E ${faker.company.name()} ${Math.floor(Date.now() / millisecondsPerSecond)}`;
    const state = faker.address.stateAbbr();
    return {
        name: name,
        currency: {
            id: USDCurrencyId.toString()
        },
        parent: {
            id: (override?.parent?.id ?? RootNsSubsidiaryId).toString()
        },
        state: state,
        mainAddress: {
            addressee: name,
            addr1: faker.address.streetAddress(),
            addr2: faker.address.secondaryAddress(),
            city: faker.address.cityName(),
            state: state,
            zip: faker.address.zipCodeByState(state),
            country: {
                id: override?.mainAddress?.country?.id ?? SoapCountry.UNITED_STATES
            },
        }
    };
}

/**
 * Maps a NS subsidiary object to a SF subsidiary.
 * @param {ContextType} context
 * @param {NsSubsidiary} nsSubsidiary
 * @returns {Promise<SfSubsidiary>}
 */
async function toSfSubsidiaryAsync(context: ContextType, nsSubsidiary: NsSubsidiary): Promise<SfSubsidiary> {

    const sfSubsidiary = {
        Name: nsSubsidiary.name,
        Netsuite_Id__c: must(nsSubsidiary.id).toString()
    } as SfSubsidiary;

    // If currency is defined, retrieve the currency ISO code to set the property.
    if (nsSubsidiary.currency?.id) {
        sfSubsidiary.CurrencyIsoCode = await context.nsApiClient.getCurrencyIsoCode(nsSubsidiary.currency.id);
    }

    // If the main address is defined, set the equivalent properties.
    if (nsSubsidiary.mainAddress) {
        sfSubsidiary.City__c = nsSubsidiary.mainAddress.city;
        sfSubsidiary.State__c = nsSubsidiary.mainAddress.state;
        sfSubsidiary.Country__c = nsSubsidiary.mainAddress.country?.refName;
        sfSubsidiary.Street__c = getFormatedAddress(nsSubsidiary.mainAddress);
        sfSubsidiary.Postal_Code__c = nsSubsidiary.mainAddress?.zip;
    }

    return sfSubsidiary;
}

/**
 * Maps a NS subsidiary object to a SOAP record.
 * @param {NsSubsidiary} subsidiary
 * @returns {Any}
 */
function toSoapRecord(subsidiary:NsSubsidiary): Any {

    // Defines common properties.
    const record:Any = {
        'record': {
            $: {
                'xsi:type': 'listAcct:Subsidiary',
                'xmlns:listAcct': XmlNamespace.ACCOUNTING
            },
            'listAcct:name': subsidiary.name,
            'listAcct:currency': {
                $: {
                    'internalId': subsidiary.currency?.id
                }
            },
            'listAcct:state': subsidiary.state,
            'listAcct:mainAddress': {
                $: {
                    'xmlns:platformCommon': 'urn:common_2022_1.platform.webservices.netsuite.com'
                },
                'platformCommon:country': subsidiary.mainAddress?.country?.id,
                'platformCommon:addressee': subsidiary.mainAddress?.addressee,
                'platformCommon:addr1': subsidiary.mainAddress?.addr1,
                'platformCommon:city': subsidiary.mainAddress?.city,
                'platformCommon:state': subsidiary.mainAddress?.state,
                'platformCommon:zip': subsidiary.mainAddress?.zip,
            }
        }
    };

    // If the subsidiary ID is defined, set the internal ID; else, define missing properties for creation.
    if (subsidiary.id !== undefined) {
        record['record'].$['internalId'] = subsidiary.id;
    } else {
        record['record'] = {...record['record'],
            'listAcct:parent': {
                $: {
                    'internalId': subsidiary.parent?.id
                }
            }
        };
    }

    return record;
}

/**
 * Returns the formatted address for creating the SF subsidiary.
 * @param {NsAddress} address
 * @returns {string | undefined}
 */
export function getFormatedAddress(address: NsAddress): string | undefined {
    if (address.addr1 && address.addr2) {
        return `${address.addr1}\n${address.addr2}`;
    } else if (address.addr1) {
        return address.addr1;
    } else if (address.addr2) {
        return address.addr2;
    } else {
        return undefined;
    }
}

/**
 * Adds records needed to clean the given NS subsidiary, including any NS or SF related records if any.
 * @param {ContextType} context
 * @param {number} nsSubsidiaryId
 */
export async function addCleanerRecordForNsSubsidiaryAsync(context: ContextType, nsSubsidiaryId: number): Promise<void> {

    // Add sequentially records in the default order, considering the cleaner unshifts each record.
    (await getCleanerRecordsForNsSubsidiaryAsync(context, nsSubsidiaryId))
        .forEach(async r => await context.cleaner.addClean(r));
}

/**
 * Removes records needed to clean the given NS subsidiary, including any NS or SF related records if any.
 * @param {ContextType} context
 * @param {number} nsSubsidiaryId
 */
export async function removeCleanerRecordForNsSubsidiaryAsync(context: ContextType, nsSubsidiaryId: number) {

    // Add sequentially records in the reverse order, considering the cleaner unshifts each record.
    (await getCleanerRecordsForNsSubsidiaryAsync(context, nsSubsidiaryId)).reverse()
        .forEach(async r => await context.cleaner.removeClean(r));
}

/**
 * Returns the records needed to clean the given NS subsidiary, including any NS or SF related records if any.
 * @param {ContextType} context
 * @param {number} nsSubsidiaryId
 * @returns {Promise<CleanerRec[]>} The order of records respects the descendant dependencies, from NS subsidiary to other related records.
 */
async function getCleanerRecordsForNsSubsidiaryAsync(context: ContextType, nsSubsidiaryId: number): Promise<CleanerRec[]> {
    const cleanerRecords: CleanerRec[] = [];

    // Define the cleaner record related to NS subsidiary.
    cleanerRecords.push({ type: CleanType.removeNsSubsidiary, id: nsSubsidiaryId });

    // Define the cleaner record related to NS ava subsidiary if any. Assume there is at most one related record.
    const avaSubsidiariesSearch = await context.nsApiClient.searchRecords(NsRecordTypes.AvaSubsidiary, `custrecord_ava_subsidiary EQUAL ${nsSubsidiaryId}`);
    if (avaSubsidiariesSearch.count > 0) {
        cleanerRecords.push({ type: CleanType.removeNsAvaSubsidiary, id: +avaSubsidiariesSearch.items[0].id });
    }

    // Define the cleaner record related to SF subsidiary if any. Assume there is at most one related record.
    const sfSubsidiaryIds = await context.sfApiClient.getRecordIdsByNetSuiteIdAsync(SfObjectApiName.Subsidiary, nsSubsidiaryId);
    if (sfSubsidiaryIds.length > 0) {
        cleanerRecords.push({ type: CleanType.removeSfSubsidiary, id: sfSubsidiaryIds[0] });
    }

    return cleanerRecords;
}
