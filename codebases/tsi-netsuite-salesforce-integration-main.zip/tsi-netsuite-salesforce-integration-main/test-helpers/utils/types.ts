import { initializeLinq, IEnumerable } from 'linq-to-typescript';
import { RequestError } from 'got';

export type Any = any; // NOSONAR

type TypeOrUndefined<T> = T | null | undefined;

/**
 * Represents a response related to a SOAP API call.
 */
interface SoapResponse {
  statusCode: HttpStatusCode,
  body: Any
}

/**
 * Represents a request error related to SOAP API call.
 */
export class SoapRequestError extends RequestError {
  readonly response: Any & SoapResponse;

  constructor(message: string, response: SoapResponse) {
    super(message, {}, {} as Any);
    this.name = 'SoapRequestError';
    this.response = response;
    Object.setPrototypeOf(this, new.target.prototype);
  }
}

/**
 * asserts value is not null or undefined and throw a custom message
 * @param val to be checked
 * @param msg to thrown if it fails
 */
export function assertNotNullMsg<T>(val: TypeOrUndefined<T>, msg?: string): asserts val is T {
  if (val === undefined || val === null) {
    throw new Error(msg);
  }
}

/**
 * asserts env variable is not null or undefined and throw a custom message
 * @param val to be checked
 * @param envVarName to check
 */
export function assertNotNullEnvVar<T>(val: TypeOrUndefined<T>, envVarName: string): asserts val is T {
  assertNotNullMsg(val, `${envVarName} env var should be defined.`);
}

/**
 * assert the value exists
 * @param val to be checked
 * @param msg error message if it fails
 * @returns the value
 */
export function must<T>(val: TypeOrUndefined<T>, msg?: string): T {
  if (val === undefined || val === null) {
    throw new Error(`${msg || 'value is mandatory'}`);
  } else {
    return val;
  }
}

export enum HttpStatusCode {
  Ok = 200,
  Created = 201,
  NoContent = 204,
  Error = 400,
  NotFound = 404
}

export const JestTestTimeout = 600000;

// 1. Declare that the JS types implement the IEnumerable interface
declare global {
  interface Array<T> extends IEnumerable<T> {} // NOSONAR
  interface Uint8Array extends IEnumerable<number> {} // NOSONAR
  interface Uint8ClampedArray extends IEnumerable<number> {} // NOSONAR
  interface Uint16Array extends IEnumerable<number> {} // NOSONAR
  interface Uint32Array extends IEnumerable<number> {} // NOSONAR
  interface Int8Array extends IEnumerable<number> {} // NOSONAR
  interface Int16Array extends IEnumerable<number> {} // NOSONAR
  interface Int32Array extends IEnumerable<number> {} // NOSONAR
  interface Float32Array extends IEnumerable<number> {} // NOSONAR
  interface Float64Array extends IEnumerable<number> {} // NOSONAR
  interface Map<K, V> extends IEnumerable<[K, V]> {} // NOSONAR
  interface Set<T> extends IEnumerable<T> {} // NOSONAR
  interface String extends IEnumerable<string> {} // NOSONAR
}
// 2. Bind Linq Functions to Array, Map, etc
initializeLinq();
