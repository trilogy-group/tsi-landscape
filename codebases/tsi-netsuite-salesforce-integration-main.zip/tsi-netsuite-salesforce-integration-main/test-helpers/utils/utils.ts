import { ExponentialBackoff, handleWhenResult, IRetryContext, retry } from 'cockatiel';
import { Any } from './types';

/**
 * Get the string part after last occurence of specified string
 * @param {string} s input string
 * @param {string} after the string part to find
 * @returns the string part after last occurence
 */
export function getPartAfterLast(s: string, after: string) {
  return s.substring(s.lastIndexOf(after) + 1);
}

/**
 * Returns the header for the given name if any, else returns null.
 * @param {Any} rawHeaders
 * @param {string} headerName
 * @returns {string | null}
 */
export function getHeaderOrDefault(rawHeaders: Any, headerName: string): string | null {
  const index = rawHeaders.indexOf(headerName);
  return index >= 0 ? rawHeaders[index + 1] : null;
}

/**
 * Returns the REST resource ID from the Location header if any, else returns null.
 * @param {Any} rawHeaders
 * @returns {string | null}
 */
export function getRestResourceIdOrDefault(rawHeaders: Any): string | null {
  const location = getHeaderOrDefault(rawHeaders, 'Location');
  return location === null ? null : getPartAfterLast(location, '/');
}

/**
 * Returns the REST resource ID as number from the Location header if any, else returns null.
 * @param {Any} rawHeaders
 * @returns {number | null}
 */
export function getRestResourceIdOrDefaultAsNumber(rawHeaders: Any): number | null {
  const resourceId = getRestResourceIdOrDefault(rawHeaders);
  return resourceId === null ? null : parseInt(resourceId);
}

/**
 * Delays the execution
 * @param {number} ms delay in ms
 */
export function delay(ms: number) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

/**
 * Returns the today date in the NetSuite context.
 * @returns {Date}
 */
export function getNsTodayDate(): Date {
  return new Date(new Date().toLocaleDateString('en-ca', { timeZone: 'US/Central' }));
}

/**
 * Gets Date in Iso format
 * @param {Date} date date
 */
export function toIsoDateOnly(date: Date): string {
  const datePartLength = 10;
  return date.toISOString().substring(0, datePartLength);
}

/**
 * Logs error to the step run output
 * @export
 * @param {string} message
 */
export function logError(message: string) {
  log(message, true);
}

/**
 * Logs message to the step run output
 * @export
 * @param {string} message
 * @param {boolean} [severityError=false]
 */
export function log(message: string, severityError = false) {
  const testNameHash = typeof expect === 'undefined' ? '' : ` (${stringDeterministicHash(expect.getState().currentTestName ?? '')})`;
  process.stdout.write(
    `${new Date().toISOString()}:${testNameHash} ${severityError ? 'ERROR:' : 'INFO:'} ${message}\n`
  );
}

/**
 * Logs step name to the step run output
 * Added to be central place for current step log modification. F.e. if we need to add current test name
 * @export
 * @param {string} stepName
 */
export function logStepRun(stepName: string) {
  log(`${stepName}...`);
}

/**
 * Logs record data.
 * @param {'NS' | 'SF'} platform
 * @param {string} type
 * @param {Any} data
 * @param {'CREATED' | 'UPDATED' | 'DELETED'} action
 * @param {boolean} logs
 */
export function logRecord(platform: 'NS' | 'SF', type: string, data: Any, action?: 'CREATED' | 'UPDATED' | 'DELETED', logs = true) {

  // If the condition to log is not fulfilled, return.
  if (!logs) {
    return;
  }

  // Log.
  const propertiesText = Object.keys(data).map(key => `${key}: ${data[key]}`).join(', ');
  log(`- ${action ? action + ' ' : ''}${platform} ${type}:: ${propertiesText}`)
}

/**
 * Logs records data.
 * @param {'NS' | 'SF'} platform
 * @param {string} type
 * @param {Any[]} data
 * @param {'CREATED' | 'UPDATED' | 'DELETED'} action
 */
export function logRecords(platform: 'NS' | 'SF', type: string, data: Any[], action?: 'CREATED' | 'UPDATED' | 'DELETED') {
  data.forEach(r => logRecord(platform, type, r, action));
}

/**
 * Calculates deterministic hash of string
 * @param {string} str
 * @return {*}  {string} hash
 */
function stringDeterministicHash(str: string): string {
  let hash = 0;
  const hexBase = 16;
  const hashShift = 5;

  for (let i = 0; i < str.length; i++) {
    const char = str.charCodeAt(i);
    hash = (hash << hashShift) - hash + char;
    hash = hash & hash;
  }

  // make unsigned
  hash = hash >>> 0;
  return hash.toString(hexBase);
}

/**
 * Do an operation until the result satisfies the condition
 * @template T
 * @param {((context: IRetryContext) => PromiseLike<T> | T)} fnOpperation operation to perform
 * @param {(resp: T) => boolean} fnIsResultOk function to check the operation result
 * @param {number} maxWaitTimeMs maximum time to wait for ok result
 * @param {number} initialDelayMs initial delay before execution of first operation attempt
 * @return {*}  {Promise<T>} operation result
 */
export async function doOperationUntilCondition<T>(
  fnOpperation: (context: IRetryContext) => PromiseLike<T> | T,
  fnIsResultOk: (resp: T) => boolean,
  maxWaitTimeMs: number,
  initialDelayMs: number,
  maxAttempts: number
): Promise<T> {
  const handlePolicy = handleWhenResult((res: Any) => !fnIsResultOk(res));
  const retryPolicy = retry(handlePolicy, {
    maxAttempts: maxAttempts,
    backoff: new ExponentialBackoff({
      maxDelay: maxWaitTimeMs, //ms
      initialDelay: initialDelayMs, //ms
    }),
  });
  var result = await retryPolicy.execute(fnOpperation);
  if (!fnIsResultOk(result)) {
    throw new Error(`Operation failed after ${maxAttempts} attempts.`);
  }
  return result;
}

/**
 * Gets enum value by string name of enum item
 * @export
 * @template T
 * @param {T} myEnum enum type
 * @param {string} enumValue string name of enum item
 * @return {*}  {(keyof T | null)}
 */
export function getEnumKeyByEnumValue<T extends { [index: string]: string }>(
  myEnum: T,
  enumValue: string
): keyof T | null {
  const keys = Object.keys(myEnum).filter((x) => myEnum[x] === enumValue);
  return keys.length > 0 ? keys[0] : null;
}

/**
 * Converts passed object to string to be used in logs or messages
 *
 * @export
 * @param {(string | object | unknown)} message
 * @return {*}  {(string | object)}
 */
export function toDescriptionString(message: string | object | unknown): string | object {
  if (typeof message === 'string') {
    return message;
  }

  return JSON.stringify(message, getCircularReplacer());
}

// https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Errors/Cyclic_object_value#examples
const getCircularReplacer = () => {
  const seen = new WeakSet();
  return (key, value) => {
    if (typeof value === 'object' && value !== null) {
      if (seen.has(value)) {
        return null;
      }
      seen.add(value);
    }
    return value;
  };
};

/**
 * Asserts a condition is false; else, logs the message as an error and throw an error.
 * @param {boolean} condition
 * @param {string} message
 */
export function throwsIfTrue(condition: boolean, message?: string): void {
  if (condition) {
    message = message ?? `An unexpected condition occurred.`;
    logError(message);
    throw new Error(message);
  }
}
