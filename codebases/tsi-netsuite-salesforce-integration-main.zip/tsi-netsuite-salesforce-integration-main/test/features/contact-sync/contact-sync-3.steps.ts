import 'dotenv/config';
import { Fusion } from 'jest-cucumber-fusion';
import { Any } from '../../../test-helpers/utils/types';
import { getSharedSteps } from '../../steps/shared-steps';
import { getCustomerSharedSteps } from '../../steps/customer-shared-steps';
import { getRenewalSubscriptionSharedSteps } from '../../steps/renewal-subscription-shared-steps';
import { getContactSharedSteps } from '../../steps/contact-shared-steps';
import { ContextType } from '../../../test-helpers/utils/steps_types';

const context: ContextType = {} as Any;

getSharedSteps(context);
getCustomerSharedSteps(context);
getRenewalSubscriptionSharedSteps(context);
getContactSharedSteps(context);

Fusion('contact-sync-3.feature');
