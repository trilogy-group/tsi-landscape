import 'dotenv/config';
import { Fusion } from 'jest-cucumber-fusion';
import { Any } from '../../../test-helpers/utils/types';
import {
  getSharedSteps
} from '../../steps/shared-steps';
import { getRenewalSubscriptionSharedSteps } from '../../steps/renewal-subscription-shared-steps';
import { getCustomerSharedSteps } from '../../steps/customer-shared-steps';
import { ContextType } from '../../../test-helpers/utils/steps_types';

const context: ContextType = {} as Any;

getSharedSteps(context);
getRenewalSubscriptionSharedSteps(context);
getCustomerSharedSteps(context);

Fusion('customer-sync-1.feature');
