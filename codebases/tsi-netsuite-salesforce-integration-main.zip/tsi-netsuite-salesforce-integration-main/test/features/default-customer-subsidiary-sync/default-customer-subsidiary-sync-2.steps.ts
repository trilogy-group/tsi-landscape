import 'dotenv/config';
import { Fusion } from 'jest-cucumber-fusion';
import { ContextType } from '../../../test-helpers/utils/steps_types';
import { Any } from '../../../test-helpers/utils/types';
import { getClassSharedSteps } from '../../steps/class-shared-steps';
import { getCustomerSharedSteps } from '../../steps/customer-shared-steps';
import { getDefaultCustomerSubsidiarySharedSteps } from '../../steps/default-customer-subsidiary.shared-steps';
import { getSharedSteps } from '../../steps/shared-steps';
import { getSubsidiarySharedSteps } from '../../steps/subsidiary-shared-steps';

const context: ContextType = {} as Any;

getSharedSteps(context);
getClassSharedSteps(context);
getCustomerSharedSteps(context);
getDefaultCustomerSubsidiarySharedSteps(context);
getSubsidiarySharedSteps(context);

Fusion('default-customer-subsidiary-sync-2.feature');
