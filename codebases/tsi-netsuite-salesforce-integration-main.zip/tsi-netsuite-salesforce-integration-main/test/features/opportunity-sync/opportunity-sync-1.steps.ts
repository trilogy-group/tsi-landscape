import 'dotenv/config';
import { Fusion } from 'jest-cucumber-fusion';
import { ContextType } from '../../../test-helpers/utils/steps_types';
import { Any } from '../../../test-helpers/utils/types';
import { getOpportunitySharedSteps } from '../../steps/opportunity-shared-steps';
import { getRenewalSubscriptionSharedSteps } from '../../steps/renewal-subscription-shared-steps';
import { getSharedSteps } from '../../steps/shared-steps';
import { getZendeskSharedSteps } from '../../steps/zendesk-shared-steps';

const context: ContextType = {} as Any;

getSharedSteps(context);
getRenewalSubscriptionSharedSteps(context);
getOpportunitySharedSteps(context);
getZendeskSharedSteps(context);

Fusion('opportunity-sync-1.feature');
