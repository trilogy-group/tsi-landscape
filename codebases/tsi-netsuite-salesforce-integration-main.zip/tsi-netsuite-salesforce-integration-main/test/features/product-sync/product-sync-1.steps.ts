import 'dotenv/config';
import { Fusion } from 'jest-cucumber-fusion';
import { ContextType } from '../../../test-helpers/utils/steps_types';
import { Any } from '../../../test-helpers/utils/types';
import { getProductSharedSteps } from '../../steps/products-shared-steps';
import { getSharedSteps } from '../../steps/shared-steps';

const context: ContextType = {} as Any;

getSharedSteps(context);
getProductSharedSteps(context);

Fusion('product-sync-1.feature');
