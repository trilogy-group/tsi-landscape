import 'dotenv/config';
import { Fusion } from 'jest-cucumber-fusion';
import { ContextType } from '../../../test-helpers/utils/steps_types';
import { Any } from '../../../test-helpers/utils/types';
import { getQuoteSharedSteps } from '../../steps/quote-shared-steps';
import { getRenewalSubscriptionSharedSteps } from '../../steps/renewal-subscription-shared-steps';
import { getSharedSteps } from '../../steps/shared-steps';

const context: ContextType = {} as Any;

getSharedSteps(context);
getRenewalSubscriptionSharedSteps(context);
getQuoteSharedSteps(context);

Fusion('quote-sync-3.feature');
