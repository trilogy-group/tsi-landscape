import 'dotenv/config';
import { And, Fusion, Then } from 'jest-cucumber-fusion';
import { GetResultDirectlyWorkflowKind } from '../../../test-helpers/api_clients/ti_api_client';
import { ContextType, waitForRecInitialDelay, waitForRecMaxAttempts, waitForRecMaxDelay } from '../../../test-helpers/utils/steps_types';
import { Any, must } from '../../../test-helpers/utils/types';
import { doOperationUntilCondition, logStepRun } from '../../../test-helpers/utils/utils';
import { getRenewalSubscriptionSharedSteps } from '../../steps/renewal-subscription-shared-steps';
import { getSharedSteps } from '../../steps/shared-steps';
import { QueryResults } from '../../../test-helpers/api_contracts/ns_api_contracts';

const context: ContextType = {} as Any;

getSharedSteps(context);
getRenewalSubscriptionSharedSteps(context);

describe('Check Arr for closed subscription', () => {

    And('the charges related to this subscription have been created', async () => {
        logStepRun('And the charges related to this subscription have been created');

        // Build the query to count the number of charges created.
        const subscriptionLineItems = must(context.nsParentSubscriptionRec?.subscriptionLine?.items);
        const subscriptionLines = subscriptionLineItems.map(l => must(l.subscriptionLine));
        const query = `SELECT count(*) as count FROM charge WHERE subscriptionline IN (${subscriptionLines.join(',')})`;

        // The creation of charges is triggered by the creation/activation of a subscription, but a delay of some seconds is possible in practice.
        // Wait until all charges are created, expecting as many as the subscription lines.
        const result = await doOperationUntilCondition<QueryResults<{count: number}>>(
            async () => await context.nsApiClient.queryWithSuiteQL<{count: number}>(query, 1),
            (resp: QueryResults<{count: number}>) => resp.count === 1 && +resp.items[0].count === subscriptionLines.length,
            waitForRecMaxDelay,
            waitForRecInitialDelay,
            waitForRecMaxAttempts
        );
        expect(result.count).toBe(1);
        expect(+result.items[0].count).toBe(subscriptionLines.length);
    });

    Then('the parent ARR is non-zero', async () => {
        logStepRun('Then the parent ARR is non-zero');
        const currentFieldsResult = await context.tiApiClient.getFlowResultsDirectly({ subscription: context.nsParentSubscriptionId },
            GetResultDirectlyWorkflowKind.GetCurrentFields);
        expect(currentFieldsResult.currentArr).toBeGreaterThan(0);
    });
    Fusion('closed-subscription-arr.feature');
});
