import { And, Then, When } from 'jest-cucumber-fusion';
import { logRecord, logStepRun } from '../../test-helpers/utils/utils';
import 'jest-extended';
import { getClassAsync, getClassIdByNameAsync, updateClassAsync } from '../../test-helpers/utils/class_utils';
import { SfObjectApiName } from '../../test-helpers/api_clients/sf_api_client';
import { FlowExecutionState, FlowRelatedEntityKind } from '../../test-helpers/api_clients/ti_api_client';
import {
    ContextType,
    waitForRecInitialDelay,
    waitForWorkflowCompletedAttempts, waitForWorkflowMaxDelay
} from '../../test-helpers/utils/steps_types';
import { must } from '../../test-helpers/utils/types';
import { SfProductConfiguration } from '../../test-helpers/api_contracts/sf_api_contracts';
import { addCleanerRecordForNsSubsidiaryAsync, getNetSuiteIdBySfSubsidiaryId, removeCleanerRecordForNsSubsidiaryAsync } from '../../test-helpers/utils/subsidiary_utils';
import { NsRecordTypes } from '../../test-helpers/api_clients/ns_api_client';
import { NsClass } from '../../test-helpers/api_contracts/ns_api_contracts';

export const getClassSharedSteps = (context: ContextType) => {

    And(/^there is a class '(.*)' in NetSuite$/u, async (className) => {
        logStepRun(`And there is a class '${className}' in NetSuite`);

        // Retrieve the class ID from the name.
        context.nsClassName = className as string;
        context.nsClassId = await getClassIdByNameAsync(context, className as string);
        context.nsClass = await getClassAsync(context, context.nsClassId);
        logRecord('NS', NsRecordTypes.Class, { id: context.nsClassId });
    });

    And(/^this class has already been synced as a product configuration in Salesforce$/u, async () => {
        logStepRun(`And this class has already been synced as a product configuration in Salesforce`);

        // Retrieve the SF product configuration based on the NS class name.
        context.sfProductConfiguration = await context.sfApiClient.getRecordByNetSuiteClassAsync<SfProductConfiguration>(
            SfObjectApiName.ProductConfiguration,
            must(context.nsClassName)
        );
    });

    And(/^this subsidiary is set as a contracting entity for other customers to this class in NetSuite$/u, async () => {
        logStepRun(`And this subsidiary is set as a contracting entity for other customers to this class in NetSuite`);
        await updateClassContractingEntitiesForOtherCustomersAsync();
    });

    When(/^I set this subsidiary as a contracting entity for other customers to this class in NetSuite$/u, async () => {
        logStepRun(`When I set this subsidiary as a contracting entity for other customers to this class in NetSuite`);
        await updateClassContractingEntitiesForOtherCustomersAsync();
    });

    /**
     * Updates the contracting entities of the class by setting the subsidiary ID.
     */
    async function updateClassContractingEntitiesForOtherCustomersAsync() {
        await updateClassAsync(context, {
            custrecord_cls_entity_other: { id: must(context.nsSubsidiaryId).toString() },
            id: must(context.nsClassId)
        } as NsClass);

        // Remove from cleaning the NS subsidiary newly defined as contracting entity.
        await removeCleanerRecordForNsSubsidiaryAsync(context, must(context.nsSubsidiaryId));

        // Add for cleaning the oldly NS subsidiary if created by this E2E test.
        const oldNsSubsidiaryRef = must(context.nsClass?.custrecord_cls_entity_other);
        if (oldNsSubsidiaryRef?.refName?.split(' : ')?.last()?.startsWith('E2E')) {
            await addCleanerRecordForNsSubsidiaryAsync(context, +must(oldNsSubsidiaryRef.id));
        }
    }

    When(/^I set these subsidiaries as contracting entities to this class in NetSuite$/u, async (args) => {
        logStepRun(`When I set these subsidiaries as contracting entities to this class in NetSuite`);
        const data = args[0] as {
            ForGermanCustomers: string,
            ForJapanCustomers: string,
            ForOtherCustomers: string,
            ForUsCustomers: string
        };

        // Define contracting entities and update the NS class.
        const subsidiaryIdsByName = must(context.nsSubsidiaryIdsByName);
        await updateClassAsync(context, {
            custrecord_cls_entity_german: { id: subsidiaryIdsByName[data.ForGermanCustomers].toString() },
            custrecord_cls_entity_japan: { id: subsidiaryIdsByName[data.ForJapanCustomers].toString() },
            custrecord_cls_entity_other: { id: subsidiaryIdsByName[data.ForOtherCustomers].toString() },
            custrecord_cls_entity_us_domestic: { id: subsidiaryIdsByName[data.ForUsCustomers].toString() },
            id: must(context.nsClassId)
        } as NsClass);

        // Retrieve up-to-date class data.
        context.nsClass = await getClassAsync(context, must(context.nsClassId));
    });

    And(/^this class has been synced in Salesforce$/u, async () => {
        logStepRun(`And this class has been synced in Salesforce`);

        // Wait for the completion of the flow, then check the status is completed.
        const executionState = await context.tiApiClient.waitForFlowCompletion(
            FlowRelatedEntityKind.ns_classification_id,
            must(context.nsClassId).toString(),
            waitForWorkflowMaxDelay,
            waitForRecInitialDelay,
            waitForWorkflowCompletedAttempts,
            context?.nsClassLastSyncStatusTimestamp ?? context.startTime.toISOString()
        );
        expect((FlowExecutionState)[executionState.status]).toBe(FlowExecutionState.Completed);
        context.nsClassLastSyncStatusTimestamp = executionState.timestamp;

        // Retrieve the updated SF product configuration.
        context.sfProductConfiguration = must(await context.sfApiClient.getRecordAsync<SfProductConfiguration>(
            SfObjectApiName.ProductConfiguration,
            must(context.sfProductConfiguration?.Id)
        ));
    });

    Then(/^this product configuration should reference these subsidiaries as contracting entities in SalesForce$/u, async () => {
        logStepRun(`Then this product configuration should reference these subsidiaries as contracting entities in SalesForce`);

        // Retrieve the NetSuite ID for all subsidiaries defined as contracting entities.
        const sfProductConfiguration = must(context.sfProductConfiguration);
        const nsIdBySfSubsidiaryId = await getNetSuiteIdBySfSubsidiaryId(context, [
            must(sfProductConfiguration.Contacting_Entity_JP__c),
            must(sfProductConfiguration.Contracting_Entity_DE_and_AT__c),
            must(sfProductConfiguration.Contracting_Entity_Other__c),
            must(sfProductConfiguration.Contracting_Entity_US_and_AE__c)
        ]);

        // Check all SF contracting entities have been synced.
        const nsClass = must(context.nsClass);
        expect(nsIdBySfSubsidiaryId[must(sfProductConfiguration.Contracting_Entity_DE_and_AT__c)]).toEqual(+must(nsClass.custrecord_cls_entity_german?.id));
        expect(nsIdBySfSubsidiaryId[must(sfProductConfiguration.Contacting_Entity_JP__c)]).toEqual(+must(nsClass.custrecord_cls_entity_japan?.id));
        expect(nsIdBySfSubsidiaryId[must(sfProductConfiguration.Contracting_Entity_Other__c)]).toEqual(+must(nsClass.custrecord_cls_entity_other?.id));
        expect(nsIdBySfSubsidiaryId[must(sfProductConfiguration.Contracting_Entity_US_and_AE__c)]).toEqual(+must(nsClass.custrecord_cls_entity_us_domestic?.id));
    });
};
