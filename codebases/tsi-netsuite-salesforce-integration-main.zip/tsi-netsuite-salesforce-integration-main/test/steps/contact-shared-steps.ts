import { And, Then, When } from 'jest-cucumber-fusion';
import { log, logStepRun } from '../../test-helpers/utils/utils';
import 'jest-extended';
import { ContextType, waitForRecInitialDelay, waitForRecMaxAttempts, waitForWorkflowCompletedAttempts, waitForWorkflowMaxDelay } from '../../test-helpers/utils/steps_types';
import { Any, HttpStatusCode, must } from '../../test-helpers/utils/types';
import { FlowExecutionState, FlowRelatedEntityKind } from '../../test-helpers/api_clients/ti_api_client';
import { assertsSalesforceContactData, createNetsuiteContactAndWaitFlowSync, getFakeContactData } from '../../test-helpers/utils/contact_utils';
import { getRecUntilItIsUpdated } from '../../test-helpers/utils/steps_utils';
import { createNetsuiteCustomerAndWaitFlowSync } from '../../test-helpers/utils/customer_utils';
import { faker } from '@faker-js/faker';
import { SfObjectApiName } from '../../test-helpers/api_clients/sf_api_client';

// NOSONAR
export const getContactSharedSteps = (context: ContextType) => {
  When(/^a customer and a contact with a fake data is created in NetSuite$/u, async () => {
    logStepRun('a customer and a contact with a fake data is created in NetSuite');

    await createNetsuiteCustomerAndWaitFlowSync(context);

    //create contact
    context.fakeContactData = getFakeContactData();
    ({
      nsContactId: context.nsContactId,
      timestamp: context.nsContactLastSyncStatusTimeStamp
    } = await createNetsuiteContactAndWaitFlowSync(
      context,
      must(context.nsSubsidiaryId),
      must(context.nsCustomerId),
      context.fakeContactData,
      context.nsContactLastSyncStatusTimeStamp
    ));
  });

  And('this contact is synced to SalesForce', async () => {
    logStepRun('And this contact is synced to SalesForce');

    let calledWorkflowExecutionState = await context.tiApiClient.waitForFlowCompletion(
      FlowRelatedEntityKind.ns_contact_id,
      must(context.nsContactId).toString(),
      waitForWorkflowMaxDelay,
      waitForRecInitialDelay,
      waitForWorkflowCompletedAttempts,
      context.nsContactLastSyncStatusTimeStamp
    );
    expect((FlowExecutionState)[calledWorkflowExecutionState.status]).toBe(FlowExecutionState.Completed);
    context.nsContactLastSyncStatusTimeStamp = calledWorkflowExecutionState.timestamp;

    const contactResponse = await context.sfApiClient.getContactByNsId(must(context.nsContactId));

    // assert record was retrieved successfully
    expect(contactResponse.status).toBe(HttpStatusCode.Ok);
    expect(contactResponse.data.totalSize).toBeGreaterThanOrEqual(1);
    expect(contactResponse.data.records.length).toBeGreaterThanOrEqual(1);
    expect(contactResponse.data.records[0].Id).not.toBeUndefined();

    context.sfContactId = contactResponse.data.records[0].Id;
    context.sfContact = await context.sfApiClient.getContact(context.sfContactId);
    log('SF Contact Id: ' + context.sfContactId);

    //wait call back flow from salesforce to finish
    //if we update the contact record before this, the callback flow will change back to old value
    calledWorkflowExecutionState = await context.tiApiClient.waitForFlowCompletion(
      FlowRelatedEntityKind.sf_contact_id,
      must(context.sfContactId).toString(),
      waitForWorkflowMaxDelay,
      waitForRecInitialDelay,
      waitForWorkflowCompletedAttempts,
      context.nsContactLastSyncStatusTimeStamp
    );
    expect((FlowExecutionState)[calledWorkflowExecutionState.status]).toBe(FlowExecutionState.Completed);
  });

  When(/^this contact is updated with a new fake data in NetSuite$/u, async () => {
    logStepRun('When this contact is updated with a new fake data in NetSuite');
    context.fakeContactData = getFakeContactData();

    // update netsuite contact
    await context.nsApiClient.updateContact(must(context.nsContactId), {
      contactTitle: context.fakeContactData.contactTitle,
      salutation: context.fakeContactData.contactSalutation,
      firstName: context.fakeContactData.contactFirstName,
      lastName: context.fakeContactData.contactLastName,
      middleName: context.fakeContactData.contactMiddleName,
      title: context.fakeContactData.contactTitle,
      contactEmail: context.fakeContactData.contactEmail,
      contactPhone: context.fakeContactData.contactPhone,
      contactMobilePhone: context.fakeContactData.contactMobilePhone,
      contactFax: context.fakeContactData.contactFax,
      description: context.fakeContactData.contactDescription,
    });

    const calledWorkflowExecutionState = await context.tiApiClient.waitForFlowCompletion(
      FlowRelatedEntityKind.ns_contact_id,
      must(context.nsContactId).toString(),
      waitForWorkflowMaxDelay,
      waitForRecInitialDelay,
      waitForWorkflowCompletedAttempts,
      context.nsContactLastSyncStatusTimeStamp
    );
    expect((FlowExecutionState)[calledWorkflowExecutionState.status]).toBe(FlowExecutionState.Completed);
  });

  And('now contact data is the same in the SalesForce', async () => {
    logStepRun('And now contact data is the same in the SalesForce');
    assertsSalesforceContactData(context);
  });

  Then('contact data is the same in the SalesForce', async () => {
    logStepRun('Then contact data is the same in the SalesForce');

    context.sfContact = await context.sfApiClient.getContact(must(context.sfContactId));
    assertsSalesforceContactData(context);
  });


  Then('this contact is synced to NetSuite', async () => {
    logStepRun('this contact is synced to NetSuite');
    context.nsContact = await getRecUntilItIsUpdated(
      async (rc) => await context.nsApiClient.getContact(must(context.nsContactId)),
      (data) => data.email?.toLowerCase() === context.fakeContactData.contactEmail.toLowerCase()
    );
  });

  When(/^a new contact is created in SalesForce( with same data and invalid netsuite id)?$/u, async (hasSameData) => {
    logStepRun(`When a new contact is created in SalesForce${hasSameData ?? ''}`);

    // Generate fake data for the new contact.
    // If same data is required, copy some properties from the previous contact.
    const fakeData = getFakeContactData();
    if (hasSameData) {
      const copiedProperties = ['contactTitle', 'contactSalutation', 'contactFirstName', 'contactLastName', 'contactMiddleName', 'contactEmail'];
      copiedProperties.forEach((prop) => fakeData[prop] = context.fakeContactData[prop]);
    }
    context.fakeContactData = fakeData;

    // Create a new contact based on fake data.
    context.sfContactId = await context.sfApiClient.createRecordAsync(SfObjectApiName.Contact, {
      Title: fakeData.contactTitle,
      Salutation: fakeData.contactSalutation,
      FirstName: fakeData.contactFirstName,
      LastName: fakeData.contactLastName,
      MiddleName: fakeData.contactMiddleName,
      Email: fakeData.contactEmail,
      Phone: fakeData.contactPhone,
      MobilePhone: fakeData.contactMobilePhone,
      Fax: fakeData.contactFax,
      Description: fakeData.contactDescription,
      AccountId: context.sfAccountId,
      //contact netsuite id 1 doesn't exist
      NetSuite_ID__c: hasSameData ? 1 : undefined,
    });
  });

  Then('this new contact is synced to NetSuite', async () => {
    logStepRun('Then this new contact is synced to NetSuite');
    const contactId = must(context.sfContactId);
    await context.tiApiClient.waitForFlowCompletion(FlowRelatedEntityKind.sf_contact_id, must(contactId),
      waitForWorkflowMaxDelay,
      waitForRecInitialDelay,
      waitForRecMaxAttempts);

    context.sfContact = context.sfApiClient.getContact(contactId);
  });

  And('Netsuite id in SF Contact is empty', async () => {
    logStepRun('And Netsuite id in SF Contact is empty');
    expect(context.sfContact.NetSuite_ID__c).toBeUndefined();
  });

  And('now contact data is the same in the NetSuite', async () => {
    logStepRun('And now contact data is the same in the NetSuite');
    expect(context.nsContact.salutation).toBe(context.fakeContactData.contactSalutation);
    expect(context.nsContact.firstName).toBe(context.fakeContactData.contactFirstName);
    expect(context.nsContact.lastName).toBe(context.fakeContactData.contactLastName);
    expect(context.nsContact.middleName).toBe(context.fakeContactData.contactMiddleName);
    expect(context.nsContact.title).toBe(context.fakeContactData.contactTitle);
    expect(context.nsContact.email?.toLowerCase()).toBe(context.fakeContactData.contactEmail.toLowerCase());
    expect(context.nsContact.phone).toBe(context.fakeContactData.contactPhone);
    expect(context.nsContact.mobilePhone).toBe(context.fakeContactData.contactMobilePhone);
    expect(context.nsContact.fax).toBe(context.fakeContactData.contactFax);
  });

  Then('the Salesforce contact is updated with the NetSuite ID fetched', async () => {
    logStepRun('the Salesforce contact is updated with the NetSuite ID fetched');
    const contact = await context.sfApiClient.getContact(must(context.sfContactId));
    expect(parseInt(must(contact?.NetSuite_ID__c))).toBe(context.nsContactId);
  });

  And('email is changed from NS contact', async () => {
    logStepRun('email is changed from NS contact');
    await context.nsApiClient.updateContactWithBody(must(context.nsContactId), { email: faker.internet.email().toLowerCase() });
  });

  Then('a new NetSuite Contact is created in NetSuite with a different entity ID and the same customer', async () => {
    logStepRun('a new NetSuite Contact is created in NetSuite with a different entity ID and the same customer');
    const sfContact = await context.sfApiClient.getContact(must(context.sfContactId));
    const newNetsuiteId = parseInt(must(sfContact?.NetSuite_ID__c));
    expect(newNetsuiteId).not.toBe(context.nsContactId);

    const oldContact = await context.nsApiClient.getRecord<Any>('contact', must(context.nsContactId), false);
    const newContact = await context.nsApiClient.getRecord<Any>('contact', newNetsuiteId, false);
    expect(oldContact.entityId).not.toBe(newContact.entityId);
    expect(oldContact.company.id).toBe(newContact.company.id);
    expect(oldContact.firstName).toBe(newContact.firstName);
    expect(oldContact.middleName).toBe(newContact.middleName);
    expect(oldContact.lastName).toBe(newContact.lastName);
  });

  And('this contact is set as the primary contact for this customer', async () => {
    logStepRun('And this contact is set as the primary contact for this customer');

    await context.nsApiClient.soapAttachContactAsync('customer', must(context.nsCustomerId), must(context.nsContactId));
  });

  And('a contact role with this contact is created for this opportunity in Salesforce', async () => {
    logStepRun('And a contact role with this contact is created for this opportunity in Salesforce');

    // Create a contact role for the new contact and the opportunity.
    context.sfOpportunityContactRoleId = await context.sfApiClient.createRecordAsync(SfObjectApiName.OpportunityContactRole, {
      OpportunityId: must(context.sfOpportunityId),
      ContactId: must(context.sfContactId),
    });
  });

  And('this contact role has been synced in NetSuite', async () => {
    logStepRun('And this contact role has been synced in NetSuite');

    // Wait the flow syncing the contact role to be completed.
    await context.tiApiClient.waitForFlowCompletion(
      FlowRelatedEntityKind.sf_opp_contact_role_id,
      must(context.sfOpportunityContactRoleId),
      waitForWorkflowMaxDelay,
      waitForRecInitialDelay,
      waitForRecMaxAttempts
    );
  });

  Then('this contact should have a NetSuite ID in Salesforce', async () => {
    logStepRun('Then this contact should have a NetSuite ID in Salesforce');

    // The SF contact should have a NetSuite ID.
    context.sfContact = await context.sfApiClient.getRecordAsync(SfObjectApiName.Contact, must(context.sfContactId));
    context.nsContactId = parseInt(must(context.sfContact?.NetSuite_ID__c));
    expect(context.nsContactId).toBeGreaterThan(0);
  });

  And('a NS contact should be created in NetSuite', async () => {
    logStepRun('And a NS contact should be created in NetSuite');

    // Load the NS contact.
    context.nsContact = await context.nsApiClient.getContact(
      must(context.nsContactId)
    );
    expect(context.nsContact).toBeDefined();
  });
};
