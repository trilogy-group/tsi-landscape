import { And, Then, When } from 'jest-cucumber-fusion';
import { log, logRecord, logStepRun } from '../../test-helpers/utils/utils';
import 'jest-extended';
import { ContextType, waitForRecInitialDelay, waitForWorkflowCompletedAttempts, waitForWorkflowMaxDelay } from '../../test-helpers/utils/steps_types';
import { createNetsuiteCustomerAndWaitFlowSync, getFakeCustomerData, getNsCustomerIdByName } from '../../test-helpers/utils/customer_utils';
import { Any, HttpStatusCode, must } from '../../test-helpers/utils/types';
import { SfObjectApiName } from '../../test-helpers/api_clients/sf_api_client';
import { FlowExecutionState, FlowRelatedEntityKind } from '../../test-helpers/api_clients/ti_api_client';
import { CleanerRec, CleanType } from '../../test-helpers/utils/cleaner';
import { NsRecordTypes } from '../../test-helpers/api_clients/ns_api_client';

export const getCustomerSharedSteps = (context: ContextType) => {

  And(/^there is a customer '(.*)' in NetSuite$/u, async (customerName) => {
    logStepRun(`And there is a customer '${customerName}' in NetSuite`);

    // Retrieve the NS customer ID for the given name.
    context.nsCustomerId = await getNsCustomerIdByName(context, customerName as string);
    logRecord('NS', NsRecordTypes.Customer, { id: context.nsCustomerId });
  });

  And(/^this customer has already been synced as an account in Salesforce$/u, async () => {
    logStepRun(`And this customer has already been synced as an account in Salesforce`);

    // Retrieve the SF account related to the NS customer.
    context.sfAccount = await context.sfApiClient.getRecordByNetSuiteIdAsync(SfObjectApiName.Account, must(context.nsCustomerId));
  });

  When(/^a customer with a fake data is created in NetSuite$/u, async () => {
    logStepRun('When customer with a fake data is created in NetSuite');

    await createNetsuiteCustomerAndWaitFlowSync(context);
  });

  And(/^the customer is updated with a new fake data in NetSuite$/u, async () => {
    logStepRun('And the customer is updated with a new fake data in NetSuite');

    context.fakeCustomerData = getFakeCustomerData();

    const nsCustomer = await context.nsApiClient.getCustomer(must(context.nsCustomerId));

    context.nsCustomerLastSyncStatusTimeStamp = (new Date()).toISOString();
    context.nsContactLastSyncStatusTimeStamp = context.nsCustomerLastSyncStatusTimeStamp;
    await context.nsApiClient.updateCustomer(must(context.nsCustomerId), {
      companyName: context.fakeCustomerData.customerName,
      subsidiaryId: must(context.nsSubsidiaryId),
      email: context.fakeCustomerData.customerEmail,
      phone: context.fakeCustomerData.customerPhone,
      fax: context.fakeCustomerData.customerFax,
      webSite: context.fakeCustomerData.customerWebSite,
      billingAddrId: nsCustomer.billingAddrId,
      billingAddrCountry: context.fakeCustomerData.billingAddrCountry,
      billingAddrPostalCode: context.fakeCustomerData.billingAddrPostalCode,
      billingAddrState: context.fakeCustomerData.billingAddrState,
      billingAddrCity: context.fakeCustomerData.billingAddrCity,
      billingAddrStreet: context.fakeCustomerData.billingAddrStreet,
      shippingAddrId: nsCustomer.shippingAddrId,
      shippingAddrCountry: context.fakeCustomerData.shippingAddrCountry,
      shippingAddrPostalCode: context.fakeCustomerData.shippingAddrPostalCode,
      shippingAddrState: context.fakeCustomerData.shippingAddrState,
      shippingAddrCity: context.fakeCustomerData.shippingAddrCity,
      shippingAddrStreet: context.fakeCustomerData.shippingAddrStreet,
    });
  });

  And('this customer is synced to SalesForce', async () => {
    logStepRun('And this customer is synced to SalesForce');

    const workflowExecutionState = await context.tiApiClient.waitForFlowCompletion(
      FlowRelatedEntityKind.ns_customer_id,
      must(context.nsCustomerId).toString(),
      waitForWorkflowMaxDelay,
      waitForRecInitialDelay,
      waitForWorkflowCompletedAttempts,
      context.nsCustomerLastSyncStatusTimeStamp
    );

    expect((FlowExecutionState as Any)[workflowExecutionState.status]).toBe(FlowExecutionState.Completed);
    context.nsCustomerLastSyncStatusTimeStamp = workflowExecutionState.timestamp;
  });

  Then('there is an account created for this customer in SalesForce', async () => {
    logStepRun('Then there is an account created for this customer in SalesForce');

    // search customer record
    const getAccountsResp = await context.sfApiClient.getAccountByNsId(must(context.nsCustomerId));

    // assert record was retrieved successfully
    expect(getAccountsResp.status).toBe(HttpStatusCode.Ok);
    expect(
      getAccountsResp.data.totalSize,
      'Customer sync flow has been ran successfully, but no Account has been created in SalesForce'
    ).toBeGreaterThanOrEqual(1);
    expect(getAccountsResp.data.records.length).toBeGreaterThanOrEqual(1);
    expect(getAccountsResp.data.records[0].Id).not.toBeUndefined();
    context.sfAccountId = getAccountsResp.data.records[0].Id;
    log(`Sf account has been created. Id: ${context.sfAccountId}`);
    await context.cleaner.addClean(new CleanerRec(CleanType.removeSfAccount, context.sfAccountId));
  });

  Then('there is no account created for this customer in SalesForce', async () => {
    logStepRun('Then there is no account created for this customer in SalesForce');

    // search and wait for salesforce record to be created
    const getAccountsResp = await context.sfApiClient.getAccountByNsId(must(context.nsCustomerId));

    // assert record was retrieved successfully
    expect(getAccountsResp.status).toBe(HttpStatusCode.Ok);
    expect(
      getAccountsResp.data.totalSize,
      'Customer sync flow has been ran successfully, but ah Account has been created in SalesForce'
    ).toBe(0);
  });

  And('now customer data is the same in the SalesForce', async () => {
    logStepRun('And now customer data is the same in the SalesForce');

    const account = await context.sfApiClient.getAccount(must(context.sfAccountId));

    expect(account?.Name).toBe(context.fakeCustomerData.customerName);
    expect(account?.Type).toBe('Customer');
    expect(account?.Phone).toBe(context.fakeCustomerData.customerPhone);
    expect(account?.Fax).toBe(context.fakeCustomerData.customerFax);
    expect(account?.Website).toBe(context.fakeCustomerData.customerWebSite);
    expect(account?.BillingStreet).toBe(context.fakeCustomerData.billingAddrStreet);
    expect(account?.BillingCity).toBe(context.fakeCustomerData.billingAddrCity);
    expect(account?.BillingState).toBe(context.fakeCustomerData.billingAddrState);
    expect(account?.BillingPostalCode).toBe(context.fakeCustomerData.billingAddrPostalCode);
    expect(account?.ShippingStreet).toBe(context.fakeCustomerData.shippingAddrStreet);
    expect(account?.ShippingCity).toBe(context.fakeCustomerData.shippingAddrCity);
    expect(account?.ShippingState).toBe(context.fakeCustomerData.shippingAddrState);
    expect(account?.ShippingPostalCode).toBe(context.fakeCustomerData.shippingAddrPostalCode);

    context.sfAccount = must(account);
  });
};
