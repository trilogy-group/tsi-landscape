import { And, Then, When } from 'jest-cucumber-fusion';
import { doOperationUntilCondition, logStepRun } from '../../test-helpers/utils/utils';
import 'jest-extended';
import { NsRecordTypes } from '../../test-helpers/api_clients/ns_api_client';
import { NsDefaultCustomerSubsidiary } from '../../test-helpers/api_contracts/ns_api_contracts';
import { SfObjectApiName } from '../../test-helpers/api_clients/sf_api_client';
import { ContextType, waitForRecInitialDelay, waitForRecMaxAttempts, waitForRecMaxDelay } from '../../test-helpers/utils/steps_types';
import { HttpStatusCode, must } from '../../test-helpers/utils/types';
import { RecordsResponse, SfDefaultAccountSubsidiary } from '../../test-helpers/api_contracts/sf_api_contracts';

export const getDefaultCustomerSubsidiarySharedSteps = (context: ContextType) => {

    And(/^there is no default customer subsidiary for this (customer, class and subsidiary|customer and class) in NetSuite$/u, async (properties) => {
        logStepRun(`And there is no default customer subsidiary for this ${properties} in NetSuite`);

        // Build the query based on given properties.
        let query = `custrecord_default_subsidiary_class EQUAL ${must(context.nsClassId)}`
            + ` AND custrecord_default_subsidiary_customer EQUAL ${must(context.nsCustomerId)}`;
        if (properties.toString().includes('subsidiary')) {
            query += ` AND custrecord_default_subsidiary_subsidiary EQUAL ${must(context.nsSubsidiaryId)}`;
        }

        // Search the matching NS default customer subsidiary and, if any, delete it.
        const response = await context.nsApiClient.searchRecords(NsRecordTypes.DefaultCustomerSubsidiary, query);
        if (response.count > 0) {
            expect(response.count).toEqual(1);
            await context.nsApiClient.deleteRecordAsync(NsRecordTypes.DefaultCustomerSubsidiary, +response.items[0].id);
        }
    });

    And(/^there is no default account subsidiary for this (account, product and subsidiary|account and product) in Salesforce$/u, async (properties) => {
        logStepRun(`And there is no default account subsidiary for this ${properties} in Salesforce`);

        // Build the query based on given properties.
        let query = `Account__c = '${must(context.sfAccount).Id}'`
            + `AND Product__c = '${must(context.sfProductConfiguration).Product__c}'`;
        if (properties.toString().includes('subsidiary')) {
            query += ` AND Subsidiary__c = '${must(context.sfSubsidiary).Id}'`;
        }

        // Search the matching SF default customer subsidiary and, if any, delete it.
        const recordIds = await context.sfApiClient.getRecordIdsByQueryConditionAsync(SfObjectApiName.DefaultAccountSubsidiary, query);
        if (recordIds.length > 0) {
            expect(recordIds.length).toEqual(1);
            await context.sfApiClient.deleteRecordAsync(SfObjectApiName.DefaultAccountSubsidiary, recordIds[0]);
        }
    });

    And(/^a default customer subsidiary is created for this customer, class and first subsidiary in NetSuite$/u, async () => {
        logStepRun(`And a default customer subsidiary is created for this customer, class and first subsidiary in NetSuite`);

        // Set the first subsidiary as the contextual one, then create the NS default customer subsidiary for the current context.
        setContextualNsSubsidiary(0);
        await createNsDefaultCustomerSubsidiary();
    });

    And(/^a default customer subsidiary is created for this customer, class and subsidiary in NetSuite$/u, async () => {
        logStepRun(`And a default customer subsidiary is created for this customer, class and subsidiary in NetSuite`);

        // Create the NS default customer subsidiary for the current context.
        await createNsDefaultCustomerSubsidiary();
    });

    When(/^I create a default customer subsidiary for this customer, class and subsidiary in NetSuite$/u, async () => {
        logStepRun(`When I create a default customer subsidiary for this customer, class and subsidiary in NetSuite`);

        // Create the NS default customer subsidiary for the current context.
        await createNsDefaultCustomerSubsidiary();
    });

    /**
     * Set the subsidiary defined at the given index as the contextual one.
     * @param {number} index
     */
    function setContextualNsSubsidiary(index: number) {
        context.nsSubsidiaryId = Object.values(must(context.nsSubsidiaryIdsByName))[index];
        context.sfSubsidiary = must(context.sfSubsidiariesByNsSubsidiaryId)[context.nsSubsidiaryId];
    }

    /**
     * Creates the NS default customer subsidiary for the current context.
     */
    async function createNsDefaultCustomerSubsidiary() {

        // Create the default customer subsidiary.
        const record:NsDefaultCustomerSubsidiary = {
            custrecord_default_subsidiary_class: {
                id: must(context.nsClassId).toString()
            },
            custrecord_default_subsidiary_customer: {
                id: must(context.nsCustomerId).toString()
            },
            custrecord_default_subsidiary_subsidiary: {
                id: must(context.nsSubsidiaryId).toString()
            }
        };
        const recordId = await context.nsApiClient.createRecordAsync(NsRecordTypes.DefaultCustomerSubsidiary, record);

        // Retrieve the created record.
        context.nsDefaultCustomerSubsidiary = await context.nsApiClient.getRecord<NsDefaultCustomerSubsidiary>(NsRecordTypes.DefaultCustomerSubsidiary, recordId);
    }

    When(/^I update this default customer subsidiary with this second subsidary in NetSuite$/u, async () => {
        logStepRun(`When I update this default customer subsidiary with this second subsidary in NetSuite`);

        // Set the second subsidiary as the contextual one, then update the subsidiary of the default customer subsidiary.
        setContextualNsSubsidiary(1);
        await context.nsApiClient.updateRecordAsync(
            NsRecordTypes.DefaultCustomerSubsidiary,
            must(context.nsDefaultCustomerSubsidiary?.id),
            {
                custrecord_default_subsidiary_subsidiary: {
                    id: must(context.nsSubsidiaryId).toString()
                }
            } as NsDefaultCustomerSubsidiary
        );

        // Retrieve the up-to-date NS default customer subsidiary.
        context.nsDefaultCustomerSubsidiary = await context.nsApiClient.getRecord<NsDefaultCustomerSubsidiary>(
            NsRecordTypes.DefaultCustomerSubsidiary,
            must(context.nsDefaultCustomerSubsidiary?.id)
        );
    });

    When(/^I delete this default customer subsidiary in NetSuite$/u, async () => {
        logStepRun(`When I delete this default customer subsidiary in NetSuite`);

        // Delete the contextual NS default customer subsidiary.
        await context.nsApiClient.deleteRecordAsync(NsRecordTypes.DefaultCustomerSubsidiary, must(context.nsDefaultCustomerSubsidiary?.id));
    });

    And(/^this default customer subsidiary has been synced(-deleted)? in Salesforce$/u, async (expectsDeletion) => {
        logStepRun(`And this default customer subsidiary has been synced${expectsDeletion ? '-deleted' : ''} in Salesforce`);

        // Wait for the SF default account subsidiary to be created/deleted.
        const expectedCount = expectsDeletion ? 0 : 1;
        const response = await doOperationUntilCondition<RecordsResponse<{ Id: string }>>(
            async () => await context.sfApiClient.getSoqlQuery<{ Id: string }>(`
                SELECT Id
                FROM ${SfObjectApiName.DefaultAccountSubsidiary}
                WHERE Account__c = '${must(context.sfAccount).Id}'
                  AND Product__c = '${must(context.sfProductConfiguration).Product__c}'
                  AND Subsidiary__c = '${must(context.sfSubsidiary).Id}'
            `),
            r => r.status === HttpStatusCode.Ok && r.data.totalSize === expectedCount,
            waitForRecMaxDelay,
            waitForRecInitialDelay,
            waitForRecMaxAttempts
          );

        // If the record has been deleted, just return.
        if (expectsDeletion) {
            return;
        }

        // Else, retrieve the SF default account subsidiary.
        const record = await context.sfApiClient.getRecordAsync<SfDefaultAccountSubsidiary>(
            SfObjectApiName.DefaultAccountSubsidiary,
            response.data.records[0].Id
        );
        context.sfDefaultAccountSubsidiary = must(record);
    });

    And(/^the default account subsidiary data should be the same in Salesforce$/u, async () => {
        logStepRun(`And the default account subsidiary data should be the same in Salesforce`);
        checkDefaultCustomerSubsidiaryDataSync();
    });

    Then(/^the default account subsidiary data should be the same in Salesforce$/u, async () => {
        logStepRun(`Then the default account subsidiary data should be the same in Salesforce`);
        checkDefaultCustomerSubsidiaryDataSync();
    });

    /**
     * Checks NS default customer subsidiary and SF default account subsidiary are aligned.
     */
    function checkDefaultCustomerSubsidiaryDataSync(): void {

        // Expect the contextual SF account, product configuration and subsidiary are matching references in SF default account subsidiary.
        const sfDefaultAccountSubsidiary = must(context.sfDefaultAccountSubsidiary);
        expect(context.sfAccount?.Id).toEqual(sfDefaultAccountSubsidiary.Account__c)
        expect(context.sfProductConfiguration?.Product__c).toEqual(sfDefaultAccountSubsidiary.Product__c);
        expect(context.sfSubsidiary?.Id).toEqual(sfDefaultAccountSubsidiary.Subsidiary__c)

        // Expect the contextual NS class is matching references in NS default customer subsidiary.
        const nsDefaultCustomerSubsidiary = must(context.nsDefaultCustomerSubsidiary);
        expect(context.nsClassId?.toString()).toEqual(nsDefaultCustomerSubsidiary.custrecord_default_subsidiary_class?.id);

        // Expect SF account, product and subsidiary are correctly refencing related NS records.
        expect(context.sfAccount?.NetSuite_ID__c).toEqual(nsDefaultCustomerSubsidiary.custrecord_default_subsidiary_customer?.id);
        expect(context.sfProductConfiguration?.NetSuite_Class__c).toEqual(context.nsClassName);
        expect(context.sfSubsidiary?.Netsuite_Id__c).toEqual(nsDefaultCustomerSubsidiary.custrecord_default_subsidiary_subsidiary?.id);
    }

    Then(/^the default account subsidiary data should be deleted in Salesforce$/u, async () => {
        logStepRun(`Then the default account subsidiary data should be deleted in Salesforce`);

        // Try to retrieve the SF default account subsidiary and expect nothing.
        const response = await context.sfApiClient.getSoqlQuery<{ Id: string }>(`
            SELECT Id
            FROM ${SfObjectApiName.DefaultAccountSubsidiary}
            WHERE Id = '${must(context.sfDefaultAccountSubsidiary).Id}'
        `);
        expect(response).toBeDefined();
        expect(response.status).toEqual(HttpStatusCode.Ok);
        expect(response.data.totalSize).toEqual(0);
    });
};
