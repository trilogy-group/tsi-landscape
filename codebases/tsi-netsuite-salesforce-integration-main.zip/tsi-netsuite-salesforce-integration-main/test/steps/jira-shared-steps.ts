import { And } from 'jest-cucumber-fusion';
import { logStepRun } from '../../test-helpers/utils/utils';
import 'jest-extended';
import { ContextType } from '../../test-helpers/utils/steps_types';

// NOSONAR
export const getJiraSharedSteps = (context: ContextType) => {
  And('a Jira ticket is created to send the quote to the customer', async () => {
    logStepRun('a Jira ticket is created to send the quote to the customer');

    // when jira dev environment is set up we can have here the test to assert if jira ticket is created
  });

  And('a Jira ticket is created to to create an invoice', async () => {
    logStepRun('a Jira ticket is created to to create an invoice');

    // when jira dev environment is set up we can have here the test to assert if jira ticket is created
  });

  And('the Jira ticket is with status Failed Input QC', async () => {
    logStepRun('the Jira ticket is with status Failed Input QC');

    // when jira dev environment is set up we can have here the test to assert if jira ticket is with the correct status
  });
};
