import { When, Then, And } from 'jest-cucumber-fusion';
import 'jest-extended';
import {
  ContextType,
  waitForRecInitialDelay,
  waitForWorkflowCompletedAttempts,
  waitForWorkflowMaxDelay,
} from '../../test-helpers/utils/steps_types';
import { checkSubscriptionStatus } from './renewal-subscription-shared-steps';
import { HttpStatusCode, must } from '../../test-helpers/utils/types';
import { logStepRun } from '../../test-helpers/utils/utils';
import { NsSubscriptionStatusId } from '../../test-helpers/api_contracts/ns_api_contracts';
import { FlowExecutionState, FlowRelatedEntityKind } from '../../test-helpers/api_clients/ti_api_client';

// NOSONAR
export const getOpportunitySharedSteps = (context: ContextType) => {

  When(/^I mark this opportunity as lost with the reason '(.*)' in SalesForce$/u, async (lossReason) => {
    logStepRun(`When I mark this opportunity as lost with the reason '${lossReason}' in SalesForce`);

    // Update the loss reason at SF opportunity level, assuming the win type is empty (as only one of both fields might be set).
    const respCode = await context.sfApiClient.updateOpportunityLossReason(must(context.sfOpportunityId), lossReason as string);
    expect(respCode).toBe(HttpStatusCode.NoContent);
  });

  Then(/^the renewal subscription has been synced and should be terminated in NetSuite$/u, async() => {
    logStepRun(`Then the renewal subscription has been synced and should be terminated in NetSuite`);

    // Ensure the flow triggered by changing the stage name at SF opportunity level is completed.
    const workflowExecutionState = await context.tiApiClient.waitForFlowCompletion(
        FlowRelatedEntityKind.sf_opportunity_id,
        must(context.sfOpportunityId),
        waitForWorkflowMaxDelay,
        waitForRecInitialDelay,
        waitForWorkflowCompletedAttempts,
    );
    expect((FlowExecutionState)[workflowExecutionState.status]).toBe(FlowExecutionState.Completed);

    // Check the renewal subscription is terminated.
    ({
      subscription: context.nsRenewalSubscription,
      subscriptionChangeOrder: context.nsLastRenewalSubscriptionChangeOrder
    } = await checkSubscriptionStatus(context.nsApiClient, must(context.nsRenewalSubscriptionId), NsSubscriptionStatusId.Terminated));
  });

  And(/^this renewal subscription should have a memo containing '(.*)'$/u, async(message) => {
    logStepRun(`And this renewal subscription should have a memo containing '${message}'`);

    // Check the subscription memo contains the expected message.
    const messagePattern = new RegExp(message as string, 'i');
    expect(context.nsRenewalSubscription.custrecord_memo).toMatch(messagePattern);
  });

  And(/^this renewal subscription should have a memo referencing the opportunity$/u, async() => {
    logStepRun(`And this renewal subscription should have a memo referencing the opportunity`);

    // Check the subscription memo contains an URL targeting the SF opportunity.
    const opportunityUrlPattern = new RegExp('https:\/\/.*\/'+must(context.sfOpportunityId));
    expect(context.nsRenewalSubscription.custrecord_memo).toMatch(opportunityUrlPattern);
  });

  And(/^this renewal subscription should have a contractual document with a file starting with name Cancelation-Notice-$/u, async() => {
    logStepRun(`And this renewal subscription should have a contractual document with a file starting with name Cancelation-Notice-`);

    const result = await context.nsApiClient.callRestlet({
      op: "search.internalAttachedFields",
      recordType: "customrecord697",
      id: must(context.nsRenewalSubscription?.custrecord_contract_docs?.id)
    });
    const res = JSON.parse(result.body);
    expect(res?.content?.result.length).toBeGreaterThanOrEqual(1);

    const file = res?.content?.result.find(i => i.fileName.startsWith('Cancelation-Notice-'));
    expect(file).not.toBeUndefined();
  });

  And(/^there should be a subscription change order related to this renewal subscription in NetSuite$/u, async() => {
    logStepRun(`And there should be a subscription change order related to this renewal subscription in NetSuite`);

    // If the last renewal subscription change order is not yet retrieved, retrieve it.
    if (context.nsLastRenewalSubscriptionChangeOrder === undefined) {
      const nsLastRenewalSubscriptionChangeOrder = await context.nsApiClient.getLastSubscriptionChangeOrder(must(context.nsRenewalSubscriptionId), true);
      context.nsLastRenewalSubscriptionChangeOrder = must(nsLastRenewalSubscriptionChangeOrder);
    }
  });

  And(/^this subscription change order should have a memo referencing the opportunity$/u, async() => {
    logStepRun(`And this subscription change order should have a memo referencing the opportunity`);

    // Check the subscription memo contains an URL targeting the SF opportunity.
    const opportunityUrlPattern = new RegExp('https:\/\/.*\/'+must(context.sfOpportunityId));
    expect(context.nsLastRenewalSubscriptionChangeOrder?.memo).toMatch(opportunityUrlPattern);
  });

  And(/^this subscription change order should have change reason Churn$/u, async() => {
    logStepRun(`And this subscription change order should have change reason Churn`);

    // Churn id is 2
    expect(context.nsLastRenewalSubscriptionChangeOrder?.custrecord_st_change_reason?.id).toBe('2');
  });

  And(/^I set the opportunity Cancelation Notice$/u, async() => {
    logStepRun(`And I set the opportunity Cancelation Notice`);

    // get content document id
    const getResp = await context.sfApiClient.getContentDocumentId(context.sfOpportunityId as string);
    expect(getResp.status).toBe(HttpStatusCode.Ok);
    expect(getResp.data.totalSize).toBe(1);
    expect(getResp.data.records[0].ContentDocumentId).not.toBeUndefined();

    // set cancelation notice field
    const getRespUpdate = await context.sfApiClient.updateOpportunityCancelationNotice(context.sfOpportunityId as string,
      `https://trilogy-sales--full.sandbox.lightning.force.com/lightning/r/ContentDocument/${getResp.data.records[0].ContentDocumentId}/view`);
      expect(getRespUpdate).toBe(HttpStatusCode.NoContent);
  });

  And(/^this opportunity should have the win-type '(.*)'$/u, async(winType) => {
    logStepRun(`And this opportunity should have the win-type '${winType}'`);

    const sfOpportunity = must(context.sfOpportunityRec);
    expect(sfOpportunity.Win_Type__c).toBe(winType);
  });
};
