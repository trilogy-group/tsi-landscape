import { When, Then, And } from 'jest-cucumber-fusion';
import 'jest-extended';
import {
  ContextType,
  time180seconds,
  time30seconds,
  waitForWorkflowCompletedAttempts,
} from '../../test-helpers/utils/steps_types';
import { HttpStatusCode, must } from '../../test-helpers/utils/types';
import { logStepRun, getRestResourceIdOrDefaultAsNumber, log } from '../../test-helpers/utils/utils';
import { FlowExecutionState, FlowRelatedEntityKind, WorkflowKind } from '../../test-helpers/api_clients/ti_api_client';
import * as fs from 'fs';
import { PriceIntervalItem, SubscriptionPlan } from '../../test-helpers/utils/ns_rest_api_types';
import { assert } from 'console';

// NOSONAR
export const getProductSharedSteps = (context: ContextType) => {
  And(/^a subscription plan is created in NetSuite with a class '([^']*)' and the code '([^']*)'$/u, async (classname, code) => {
    logStepRun(`And a subscription plan is created in NetSuite with a class '${classname}' and the code '${code}'`);

    const newPlan = await createSubscriptionPlan(context, code as string);
    context.productSyncData = {
      newPlan: newPlan.subscriptionPlan,
      pricebookMap: newPlan.pricebookMap
    };

  });

  When(/^I trigger sync for the plan$/u, async () => {
    logStepRun(`I trigger sync for the plan`);
    const planId = context.productSyncData.newPlan.id;
    const resultingPlanId = must(planId).toString();
    const status = await context.tiApiClient.runCallableFlowWithObjectParam({ id: resultingPlanId }, WorkflowKind.SubscriptionPlanSync);
    expect(status).toBe(HttpStatusCode.Ok);
    const workflowExecutionState = await context.tiApiClient.waitForFlowCompletion(
      FlowRelatedEntityKind.ns_subscription_plan,
      planId.toString(),
      time180seconds,
      time30seconds,
      waitForWorkflowCompletedAttempts
    );
    expect(FlowExecutionState[workflowExecutionState.status]).toBe(FlowExecutionState.Completed);


  });

  Then(/^the plan is synced to SalesForce as a product$/u, async () => {
    logStepRun(`Then the plan is synced to SalesForce as a product`);
    const planId = context.productSyncData.newPlan.id;
    const sfProductResponse = await context.sfApiClient.getProductByNetSuiteId(planId);
    const product = sfProductResponse.data.records[0];
    // One product
    expect(sfProductResponse.data.records.length).toBe(1);
    // Options in Salesforce are getting grouped to sub-bundles. Because of that the numbers are different
    var options = must(product.SBQQ__Options__r?.records);
    if (product.SBQQ__Options__r?.records) {
      for (const element of product.SBQQ__Options__r.records) {
        var subOptions = (await context.sfApiClient.getProductById(element.SBQQ__OptionalSKU__r.Id)).data.records[0];
        if ((subOptions?.SBQQ__Options__r?.records?.length ?? 0) > 0) {
          Array.prototype.push.apply(options, must(subOptions.SBQQ__Options__r).records);
        }
      }
    }

    // for each item in the NetSuite subscription plan, find the corresponding option in Salesforce
    for (const item of context.productSyncData.newPlan.member.items) {
      const sfItem = options
        .find((r) => r.SBQQ__OptionalSKU__r.NetSuite_ID__c === item.item.id);
      expect(sfItem).toBeDefined();
    }
    // Check prices
    const listPrices = product.PricebookEntries.records
      .filter((w) => w.CurrencyIsoCode === "USD" || w.CurrencyIsoCode === "EUR")
      .map((m) => m.UnitPrice);
    // USD and EUR curencies in the test
    const currenciesLength = 2;
    // 4166.6666 is the price in the subscription plan template
    const predefinedPrice = 4166.6666;
    // 0.1 is the precision of the price
    const pricePrecision = 0.1;

    assert(listPrices.length === currenciesLength, "List prices for USD and EUR should be present");
    assert(listPrices[0] === listPrices[1], "List prices should be correct");
    assert((listPrices[0] - predefinedPrice) < pricePrecision, "List prices should be correct");
    const eurBlockPrices = product.SBQQ__BlockPrices__r?.records
      .filter((w) => w.CurrencyIsoCode === "EUR")
      .sort((a, b) => a.SBQQ__LowerBound__c - b.SBQQ__LowerBound__c)
      .map((record) => record.SBQQ__Price__c);

    assert(eurBlockPrices.length === currenciesLength, "Block prices for EUR should be present");
    assert((eurBlockPrices[1] - predefinedPrice) < pricePrecision, "Block prices should be correct");

  });
};

/**
 * Create a subscription plan in NetSuite
 * @param context Context
 * @param code Code of the subscription plan
 * @returns Plan ID
 */
async function createSubscriptionPlan(context: ContextType, code: string): Promise<{
  subscriptionPlan: SubscriptionPlan,
  pricebookMap: Map<string, number>,
}> {
  await deleteOldPlan(context, code);
  // scan through files named 'item-*.json' in the 'test/features/product-sync' folder and load them
  const items = fs.readdirSync('test/features/product-sync').filter((f) => f.startsWith('item-') && f.endsWith('.json'));
  const itemsOldtoNewMap = new Map<string, string>();
  for (const item of items) {
    // convert the file name item-*.json to * (variable length)
    const itemOldId = item.replace(/^item-/, '').replace(/\.json$/, '');
    let itemTemplate = fs.readFileSync('test/features/product-sync/' + item, 'utf8');
    itemTemplate = itemTemplate.replace(/\$\{code\}/g, code);
    const itemResponse = await context.nsApiClient.request("record/v1/nonInventorySaleItem",
      "POST",
      itemTemplate, HttpStatusCode.NoContent
    );
    const itemId = getRestResourceIdOrDefaultAsNumber(itemResponse.rawHeaders);
    log("Created item id " + itemId);
    itemsOldtoNewMap.set(itemOldId, must(itemId).toString());
  }
  // read local file named 'subscriptionPlan.json' with fs module
  let subplanTemplate = fs.readFileSync('test/features/product-sync/subscriptionPlan.json', 'utf8');
  subplanTemplate = subplanTemplate.replace(/\$\{code\}/g, code);
  // replace the item ids (which are in the form of "id": "105095") in the subscription plan template with the newly created item ids
  for (const [oldId, newId] of itemsOldtoNewMap) {
    subplanTemplate = subplanTemplate.replace(new RegExp(`"id": "${oldId}"`, 'g'), `"id": "${newId}"`);
  }

  const subplanResponse = await context.nsApiClient.request("record/v1/subscriptionPlan",
    "POST",
    subplanTemplate, HttpStatusCode.NoContent
  );
  const planId = getRestResourceIdOrDefaultAsNumber(subplanResponse.rawHeaders);
  log("Created plan id " + planId);
  const newPlan = JSON.parse((await context.nsApiClient.request(`record/v1/subscriptionPlan/${planId}?expandSubResources=true`, "GET")).body) as SubscriptionPlan;
  // Map linenumber(number) to priceplanid(string)
  const pricePlanMap = new Map<number, string>();
  const currencies = [{ id: 1, name: "USD" }, { id: 4, name: "EUR" }];
  const pricebookMap = new Map<string, number>();
  for (const currency of currencies) {
    for (const item of newPlan.member.items as { item: { id: string; }; lineNumber: number; }[]) {
      let pricePlanTemplate = fs.readFileSync('test/features/product-sync/pricePlan.json', 'utf8');
      pricePlanTemplate = pricePlanTemplate.replace(/\$\{currency\}/g, currency.id.toString());
      // POST /record/v1/pricePlan
      const pricePlanResponse = await context.nsApiClient.request("record/v1/pricePlan",
        "POST",
        pricePlanTemplate, HttpStatusCode.NoContent
      );
      const pricePlanId = getRestResourceIdOrDefaultAsNumber(pricePlanResponse.rawHeaders);
      if (pricePlanId !== null) {
        pricePlanMap.set(item.lineNumber, must(pricePlanId).toString());
      }
    }
    // Map newPlan.member.items to pricebook lines
    const priceIntervalItems: PriceIntervalItem[] = [];
    for (const item of newPlan.member.items as { item: { id: string; }; lineNumber: number; }[]) {
      const newPriceIntervalItem = {
        "chargeType": {
          "id": "2", // Recurring
        },
        "frequency": {
          "id": "ANNUALLY",
        },
        "id": item.lineNumber,
        "isRequired": true,
        "item": {
          "id": item.item.id,
        },
        "lineNumber": item.lineNumber,
        "pricePlan": {
          "id": must(pricePlanMap.get(item.lineNumber)).toString(),
        },
        "prorateBy": {
          "id": "DAY",
        },
        "repeatEvery": 1,
        "startOffsetUnit": {
          "id": "YEAR",
        },
        "startOffsetValue": 1,
        "subscriptionPlanLineNumber": item.lineNumber
      };
      priceIntervalItems.push(newPriceIntervalItem);
    }
    const priceBook = {
      "currency": {
        "id": currency.id
      },
      "customForm": {
        "id": "-10103",
      },
      "name": currency.name,
      priceInterval: {
        items: priceIntervalItems
      },
      "subscriptionPlan": {
        "id": must(planId).toString()
      }
    };
    // POST /record/v1/priceBook
    const priceBookResponse = await context.nsApiClient.request("record/v1/priceBook",
      "POST",
      JSON.stringify(priceBook), HttpStatusCode.NoContent);
    const priceBookId = getRestResourceIdOrDefaultAsNumber(priceBookResponse.rawHeaders);
    log(`Created priceBookId for currency ${currency.name} id=${priceBookId}`);
    pricebookMap.set(currency.name, must(priceBookId));
  }
  return ({
    subscriptionPlan: newPlan,
    pricebookMap: pricebookMap,
  });
}

/**
 * Finds and deletes the existing plan with the given code
 * @param context Test context
 * @param code Code of the plan to delete
 */
async function deleteOldPlan(context: ContextType, code: string) {
  const existingsubplanString = await context.nsApiClient.request(`record/v1/subscriptionPlan?q=displayname IS \"${code}\"`,
    "GET");
  const existingsubplan = JSON.parse(existingsubplanString.body);
  if (existingsubplan.totalResults > 0) {
    // Delete all the pricebooks associated with the subscription plan
    const existingPricebooksResult = await context.nsApiClient.queryWithSuiteQL<{ id: number; }>(`SELECT pb.id
      FROM subscriptionPlan sp
      JOIN priceBook pb on pb.subscriptionPlan = sp.id
      WHERE sp.id= '${existingsubplan.items[0].id}'`);
    for (const pricebook of existingPricebooksResult.items) {
      log("Deleting pricebook id " + pricebook.id);
      await context.nsApiClient.request(`record/v1/priceBook/${pricebook.id}`,
        "DELETE");
    }
    // Delete all the items (nonInventorySaletIem) associated with the subscription plan
    const existingItemsResult = await context.nsApiClient.queryWithSuiteQL<{ id: number; }>(`SELECT i.id
    FROM subscriptionPlan sp
    JOIN subscriptionPlanMember member on member.subscriptionPlan = sp.id
    JOIN Item i on i.id = member.item
    WHERE sp.id= '${existingsubplan.items[0].id}'`);

    // Delete the existing subscription plan
    // We need to do that before we delete items
    log("Deleting subscription plan id " + existingsubplan.items[0].id);
    await context.nsApiClient.request(`record/v1/subscriptionPlan/${existingsubplan.items[0].id}`,
      "DELETE");

    // log existingsubplan.items[0].id}
    log("existingsubplan.items[0].id: " + existingsubplan.items[0].id);
    // log existingItemsResult.items in JSON format
    log("existingItemsResult.items: " + JSON.stringify(existingItemsResult.items));
    for (const item of existingItemsResult.items) {
      log("Deleting item id " + item.id);
      await context.nsApiClient.request(`record/v1/nonInventorySaleItem/${item.id}`,
        "DELETE");
    }

  }
}

