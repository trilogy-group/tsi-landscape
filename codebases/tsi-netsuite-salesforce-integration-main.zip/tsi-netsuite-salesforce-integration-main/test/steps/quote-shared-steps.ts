import { When, Then, And } from 'jest-cucumber-fusion';
import { tryParseNsDate } from '../../test-helpers/api_clients/ns_api_client';
import { Any, HttpStatusCode, must } from '../../test-helpers/utils/types';
import { toIsoDateOnly, logStepRun, log } from '../../test-helpers/utils/utils';
import 'jest-extended';
import { waitForSyncOfSfQuoteToNsQuoteAndGetIt } from '../../test-helpers/utils/steps_utils';
import { FlowExecutionState, FlowRelatedEntityKind } from '../../test-helpers/api_clients/ti_api_client';
import { ContextType, waitForRecInitialDelay, waitForWorkflowCompletedAttempts, waitForWorkflowMaxDelay } from '../../test-helpers/utils/steps_types';
import {
  getOpportunity,
} from '../../test-helpers/utils/opportunity_utils';
import { SfObjectApiName } from '../../test-helpers/api_clients/sf_api_client';
import { SfQuoteRec } from '../../test-helpers/api_contracts/sf_api_contracts';

const FIRST = 0;
const SECOND = 1;
const THIRD = 2;

export const getQuoteSharedSteps = (context: ContextType) => {
  And(/^the NetSuite quote expiry should be the same as the expiry of the Salesforce quote$/u, async () => {
    logStepRun(`the NetSuite quote expiry should be the same as the expiry of the Salesforce quote`);

    expect(context.nsQuoteRec?.expirydate).toBeTruthy();
    expect(context.sfQuoteRec?.SBQQ__ExpirationDate__c).toBeTruthy();
    expect(
      context.sfQuoteRec?.SBQQ__ExpirationDate__c,
      'NetSuite quote expiry should be the same as the expiry of the Salesforce Quote'
    ).toStrictEqual(toIsoDateOnly(must(tryParseNsDate(context.nsQuoteRec?.expirydate))));
  });

  And(/^the NetSuite and SalesForce quote total amount should match$/u, async () => {
    logStepRun(`the NetSuite and SalesForce quote total amount should match`);

    expect(context.nsQuoteRec?.totalamount).toBeTruthy();
    expect(context.sfQuoteRec?.SBQQ__NetAmount__c).toBeTruthy();
    expect(
      context.sfQuoteRec?.SBQQ__NetAmount__c,
      'the NetSuite and SalesForce quote total amount should match'
    ).toStrictEqual(Number(context.nsQuoteRec?.totalamount));
  });

  And(/^the NetSuite and SalesForce quote quantities of items should match$/u, async () => {
    logStepRun(`the NetSuite and SalesForce quote quantities of items should match`);

    expect(context.nsQuoteRec?.linecount).toBeTruthy();
    expect(context.sfQuoteRec?.SBQQ__LineItemCount__c).toBeTruthy();
    //Removing one line because NS quote doesn't have anymore the line for the subscription plan
    //Quotes are being created in e2e tests without bundle of bundles, if bundle of bundles is implemented here, the number will be different
    const lineItemCount = context.sfQuoteRec?.SBQQ__LineItemCount__c as number - 1;
    expect(
      lineItemCount,
      'the NetSuite and SalesForce quote total amount should match'
    ).toStrictEqual(Number(context.nsQuoteRec?.linecount));
  });

  And(/^the NetSuite quote should have an agreement linked$/u, async () => {
    logStepRun(`And the NetSuite quote should have an agreement linked`);
    expect(context.nsQuoteRec?.agreementid).not.toBeNull();
    log('Ns Agreement id: ' + context.nsQuoteRec?.agreementid);
  });

  And(/^the NetSuite agreement should have (.*) files attached$/u, async (filesNumber) => {
    logStepRun(`And the NetSuite agreement should have ${filesNumber} files attached`);
    const filesNumberAttached = await context.nsApiClient.getFilesQuantityAttachedToAgreement(parseInt(must(context.nsQuoteRec?.agreementid)))
    expect(filesNumberAttached).toBe(filesNumber);
  });

  And(/^the NetSuite quote should have an end user acknowledgement linked$/u, async () => {
    logStepRun(`And the NetSuite quote should have an end user acknowledgement linked`);
    expect(context.nsQuoteRec?.euaagreementid).not.toBeNull();
    log('Ns EUA Agreement id: ' + context.nsQuoteRec?.euaagreementid);
  });

  And(/^the EUA name should be <agreement name> End User Acknowledgement$/u, async () => {
    logStepRun(`And the EUA name should be <agreement name> End User Acknowledgement`);
    expect(context.nsQuoteRec?.euaagreementname).toBe(context.nsQuoteRec?.agreementname + ' End User Acknowledgement');
  });

  And(/^the SalesForce quote NetSuite Id should be updated with the NetSuite quote Id$/u, async () => {
    logStepRun(`the SalesForce quote NetSuite Id should be updated with the NetSuite quote Id`);

    expect(context.nsQuoteRec?.id).toBeTruthy();
    expect(context.sfQuoteRec?.NetSuite_ID__c).toBeTruthy();
    expect(
      context.sfQuoteRec?.NetSuite_ID__c,
      'the NetSuite Id in SalesForce quote should match to id of quote in NetSuite'
    ).toStrictEqual(context.nsQuoteRec?.id);
  });

  const QuoteAgreementType = '1';
  const AgreementRecipientSigner = '1';
  const AgreementRecipientCc = '2';

  And(/^the NetSuite agreement should not have additional T&Cs file attached$/u, async () => {
    logStepRun(`the NetSuite agreement should not have additional T&Cs file attached`);

    const agreementsAndDocs = await context.nsApiClient.getQuoteAgreementsAndDocs(Number(must(context.nsQuoteRec?.agreementid)));

    // we assume there is no T&C in quote if all the quote agreements of type 'quote' have only one document (which is a quote)
    const noTCfileAttached = agreementsAndDocs
      // we take the agreements of 'quote' type
      .where((doc) => !!doc.agreementtype && doc.agreementtype === QuoteAgreementType)
      // group docs by agreementid
      .groupBy((doc) => must(doc.agreementid))
      // check all the docs and agreement groups have only one document
      .all((docsOfAgreementGroup) => docsOfAgreementGroup.count() === 1);

    expect(noTCfileAttached).toBeTrue();
  });

  Then(/^this quote has been synced to a quote in NetSuite$/u, async () => {
    logStepRun(`Then this quote has been synced to a quote in NetSuite`);

    expect(context.nsQuoteId).toBeTruthy();
    log(`Ns Quote has been created. Id: ${context.nsQuoteId}.`);

    const nsQuoteRec = await context.nsApiClient.getQuote(must(context.nsQuoteId));
    expect(nsQuoteRec).toBeTruthy();
    context.nsQuoteRec = must(nsQuoteRec);
  });

  When(/^I create a Self-Serve quote for this draft renewal subscription with the plan '(.+)', the frequency '(.+)' and the duration '(\d+)' months$/u,
    async (planName, frequency, duration, args) => {
      logStepRun('When I create a Self-Serve quote for this draft renewal subscription '
        + `with the plan '${planName}', the frequency '${frequency}' and the duration '${duration}' months`);
      const items = args as {
        ItemName: string,
        Quantity: string
      }[];

      // Retrieve the plan code from the plan name.
      const planResult = await context.nsApiClient.queryWithSuiteQL<{ displayname: string }>(
        `SELECT displayname from subscriptionplan where itemid = '${planName}'`
      );
      expect(planResult.count).toBe(1);
      const planCodeParts = planResult.items[0].displayname.split('-');

      // Retrieve the entity ID of the customer.
      const customerResult = await context.nsApiClient.queryWithSuiteQL<{ entityid: string }>(
        `SELECT entityid from customer where id = ${must(context.nsCustomerId)}`
      );
      expect(customerResult.count).toBe(1);
      const customerEntityId = customerResult.items[0].entityid;

      // Create the Self-Serve quote.
      const response = await context.nsApiClient.callRestlet({
        "op": "quote.createForSelfServe",
        "productFamilyCode": planCodeParts[FIRST],
        "productVariantCode": `${planCodeParts[SECOND]}-${planCodeParts[THIRD]}`,
        "customerId": customerEntityId,
        "content": {
          "subscriptionId": context.nsRenewalSubscriptionId,
          "planCode": planName.toString(),
          "frequency": frequency.toString(),
          "duration": parseInt(duration.toString()),
          "items": items.map(i => ({
              "code": i.ItemName,
              "quantity": parseInt(i.Quantity)
            })),
        }
      });
      const body = JSON.parse(response.body);
      expect(body?.content?.id).toBeDefined();
      log(`- NS Quote:: id: ${body.content.id}`);

      // Load the record, and set the identifier and the record in the context.
      const nsQuote = await context.nsApiClient.getQuote(body.content.id);
      context.nsQuoteId = body.content.id;
      context.nsQuoteRec = must(nsQuote);
    }
  );

  And(/^this quote has been synced to a quote in Salesforce$/u, async () => {
    logStepRun(`And this quote has been synced to a quote in Salesforce`);

    // Wait for the flow completion related to the NS quote.
    const flowExecutionState = await context.tiApiClient.waitForFlowCompletion(
      FlowRelatedEntityKind.ns_quote_id,
      must(context.nsQuoteId).toString(),
      waitForWorkflowMaxDelay,
      waitForRecInitialDelay,
      waitForWorkflowCompletedAttempts
    );
    expect((FlowExecutionState)[flowExecutionState.status]).toBe(FlowExecutionState.Completed);

    // Retrieve the synced SF quote.
    const sfQuote = await context.sfApiClient.getRecordByNetSuiteIdAsync<SfQuoteRec>(SfObjectApiName.Quote, must(context.nsQuoteId));
    expect(sfQuote).toBeDefined();
    context.sfQuoteId = must(sfQuote.Id);
    context.sfQuoteRec = sfQuote;

    // Reload the up-to-date opportunity.
    const opportunityResponse = await context.sfApiClient.getOpportunityById(must(sfQuote.SBQQ__Opportunity2__c));
    expect(opportunityResponse.data.totalSize).toBe(1);
    context.sfOpportunityRec = opportunityResponse.data.records[0];
  });

  And(/^no quote is generated in NetSuite$/u, async () => {
    logStepRun(`And no quote is generated in NetSuite`);

    expect(context.nsQuoteId).toBeNull();
  });

  And('I accept this quote in SalesForce', async () => {
    logStepRun('And I accept this quote in SalesForce');

    context.sfQuoteLastSyncStatusTimeStamp = (new Date().toISOString());
    // accept quote
    const response = await context.sfApiClient.setQuoteStatus(context.sfQuoteId);
    expect(response).toBe(HttpStatusCode.NoContent);

    // wait for accepted quote sync and creation of ns quote
    const { nsQuoteId: nsQuoteId, sfQuoteLastSyncStatusTimeStamp: sfQuoteLastSyncStatusTimeStamp } =
      await waitForSyncOfSfQuoteToNsQuoteAndGetIt(
        context,
        context.sfQuoteId,
        context.sfQuoteLastSyncStatusTimeStamp
      );

    context.sfQuoteLastSyncStatusTimeStamp = sfQuoteLastSyncStatusTimeStamp;

    context.nsQuoteId = nsQuoteId;

    // reload last state of sf quote
    context.sfQuoteRec = await context.sfApiClient.getQuote(context.sfQuoteId);

    // reload the subscription
    const opportunity = await getOpportunity(context.sfApiClient, context.sfOpportunityId ?? '');
    context.sfOpportunityRec = opportunity;
    const subscription = await context.nsApiClient.getSubscription(parseInt(opportunity.NetSuite_ID__c ?? '-1'));
    context.nsOldRenewalSubscriptionId = context.nsRenewalSubscriptionId;
    context.nsRenewalSubscriptionId = subscription.id;
    context.nsRenewalSubscription = subscription;
  });

  And(/^I move this quote to the '(.*)' status in SalesForce$/u, async (newStatus) => {
    logStepRun(`I move this quote to the 'newStatus' status in SalesForce`);

    // accept quote
    const response = await context.sfApiClient.setQuoteStatus(context.sfQuoteId, newStatus as string);
    expect(response).toBe(HttpStatusCode.NoContent);
  });

  And('I accept the second quote in SalesForce', async () => {
    logStepRun('And I accept the second quote in SalesForce');

    // accept quote
    const response = await context.sfApiClient.setQuoteStatus(context.sfQuoteId);
    expect(response).toBe(HttpStatusCode.NoContent);

    // wait for accepted quote sync and creation of ns quote
    const { nsQuoteId: nsQuoteId, sfQuoteLastSyncStatusTimeStamp: sfQuoteLastSyncStatusTimeStamp2 } =
      await waitForSyncOfSfQuoteToNsQuoteAndGetIt(
        context,
        context.sfQuoteId,
        context.sfQuoteLastSyncStatusTimeStamp
      );

    context.sfQuoteLastSyncStatusTimeStamp = sfQuoteLastSyncStatusTimeStamp2;

    context.nsQuoteId = nsQuoteId;

    // reload last state of sf quote
    context.sfQuoteRec = await context.sfApiClient.getQuote(context.sfQuoteId);

    context.nsOldRenewalSubscriptionId = context.nsRenewalSubscriptionId;
  });

  And(/^the NetSuite agreement type field should be set to 'Quote'$/u, async () => {
    logStepRun(`And the NetSuite agreement type field should be set to 'Quote'`);

    const agreementsAndDocs = await context.nsApiClient.getQuoteAgreementsAndDocs(Number(must(context.nsQuoteRec?.agreementid)));

    // we assume there is no T&C in quote if all the quote agreements of type 'quote' have only one document (which is a quote)
    const thereIsAnAggrementOfQuoteType = agreementsAndDocs
      // we take the agreements of 'quote' type
      .any((doc) => doc.agreementtype === QuoteAgreementType);

    expect(thereIsAnAggrementOfQuoteType).toBeTrue();
  });

  And(/^the EUA document pdf should be linked to the agreement$/u, async () => {
    logStepRun(`And the EUA document pdf should be linked to the agreement`);

    const agreementsAndDocs = await context.nsApiClient.getQuoteAgreementsAndDocs(Number(must(context.nsQuoteRec?.euaagreementid)));

    //expect one linked document
    expect(agreementsAndDocs.length).not.toBe(0);
  });

  And(
    'the NetSuite agreement should have four recipients, ' +
    'first: a primary contact from Salesforce Quote, ' +
    'second: from the NetSuite Subsidiary.Signatory.Email, ' +
    'third: Sales Rep from the SF primary quote should be CC on the agreement, ' +
    'fourth: o2c@trilogy.com should be a CC recipient on the agreement',
    async () => {
      logStepRun(
        'And NetSuite agreement should have four recipients, ' +
        'first: a primary contact from Salesforce Quote, ' +
        'second: from the NetSuite Subsidiary.Signatory.Email, ' +
        'third: Sales Rep from the SF primary quote should be CC on the agreement, ' +
        'fourth: o2c@trilogy.com should be a CC recipient on the agreement'
      );
      const agreementsAndDocs = await context.nsApiClient.getQuoteAgreementsAndDocs(
        Number(must(context.nsQuoteRec?.agreementid))
      );

      const aggrement = agreementsAndDocs
        // we take the agreements of 'quote' type
        .firstOrDefault((doc) => doc.agreementtype === QuoteAgreementType);
      expect(aggrement).toBeTruthy();

      const agreementRecipients = await context.nsApiClient.getQuoteAgreementRecipients(
        Number(must(aggrement?.agreementid))
      );

      // code commented because api is failing to get employee record with TSI Integration user even having the proper permission
      // I opened a support case with NS to investigate
      //const subsidiary = await context.nsApiClient.getSubsidiary(must(context.nsSubsidiaryId), true);
      // const employee = await context.nsApiClient.getEmployee(
      //   Number(subsidiary.custrecord_subsidiary_signatory.id),
      //   true
      // );
      // expect(employee.email).toBeTruthy();
      const first = 0;
      const second = 1;
      const third = 2;
      const fourth = 3;
      const four = 4;
      expect(agreementRecipients).toBeTruthy();
      expect(agreementRecipients.length).toBe(four);
      expect(agreementRecipients[first].email).toBeTruthy();
      expect(agreementRecipients[second].email).toBeTruthy();
      expect(agreementRecipients[third].email).toBeTruthy();
      expect(agreementRecipients[fourth].email).toBeTruthy();
      expect(must(agreementRecipients[first].email).replace(/.invalid/g, '')).toEqual(
        context.fakeContactData.contactEmail.replace(/.invalid/g, '')
      );
      // expect(must(agreementRecipients[second].email).replace(/.invalid/g, '')).toEqual(
      //   employee.email.replace(/.invalid/g, '')
      // );
      expect(must(agreementRecipients[third].email).replace(/.invalid/g, '')).toEqual(
        must(context.sfOpportunityOwnerEmail).replace(/.invalid/g, '')
      );
      expect(must(agreementRecipients[fourth].email).replace(/.invalid/g, '')).toEqual('o2c@trilogy.com');

      expect(agreementRecipients[first].order).toBeTruthy();
      expect(agreementRecipients[second].order).toBeTruthy();
      expect(agreementRecipients[third].order).toBeTruthy();
      expect(agreementRecipients[fourth].order).toBeTruthy();
      expect(agreementRecipients[first].order).toBe('1');
      expect(agreementRecipients[second].order).toBe('2');
      expect(agreementRecipients[third].order).toBe('3');
      expect(agreementRecipients[fourth].order).toBe('4');

      expect(agreementRecipients[first].role).toBeTruthy();
      expect(agreementRecipients[second].role).toBeTruthy();
      expect(agreementRecipients[third].role).toBeTruthy();
      expect(agreementRecipients[fourth].role).toBeTruthy();
      expect(agreementRecipients[first].role).toBe(AgreementRecipientSigner);
      expect(agreementRecipients[second].role).toBe(AgreementRecipientSigner);
      expect(agreementRecipients[third].role).toBe(AgreementRecipientCc);
      expect(agreementRecipients[fourth].role).toBe(AgreementRecipientCc);
    }
  );

  And(
    'the NetSuite EUA agreement should have three recipients, ' +
    'first: a primary contact from Salesforce Quote, ' +
    'second: Sales Rep from the SF primary quote should be CC on the agreement, ' +
    'third: o2c@trilogy.com should be a CC recipient on the agreement',
    async () => {
      logStepRun(
        'And the NetSuite EUA agreement should have three recipients, ' +
        'first: a primary contact from Salesforce Quote, ' +
        'second: Sales Rep from the SF primary quote should be CC on the agreement, ' +
        'third: o2c@trilogy.com should be a CC recipient on the agreement'
      );
      const agreementRecipients = await context.nsApiClient.getQuoteAgreementRecipients(
        Number(must(context.nsQuoteRec?.euaagreementid))
      );

      const first = 0;
      const second = 1;
      const third = 2;
      const three = 3;
      expect(agreementRecipients).toBeTruthy();
      expect(agreementRecipients.length).toBe(three);
      expect(agreementRecipients[first].email).toBeTruthy();
      expect(agreementRecipients[second].email).toBeTruthy();
      expect(agreementRecipients[third].email).toBeTruthy();
      expect(must(agreementRecipients[first].email).replace(/.invalid/g, '')).toEqual(
        context.fakeContactData.contactEmail.replace(/.invalid/g, '')
      );
      expect(must(agreementRecipients[second].email).replace(/.invalid/g, '')).toEqual(
        must(context.sfOpportunityOwnerEmail).replace(/.invalid/g, '')
      );
      expect(must(agreementRecipients[third].email).replace(/.invalid/g, '')).toEqual('o2c@trilogy.com');

      expect(agreementRecipients[first].order).toBeTruthy();
      expect(agreementRecipients[second].order).toBeTruthy();
      expect(agreementRecipients[third].order).toBeTruthy();
      expect(agreementRecipients[first].order).toBe('1');
      expect(agreementRecipients[second].order).toBe('2');
      expect(agreementRecipients[third].order).toBe('3');

      expect(agreementRecipients[first].role).toBeTruthy();
      expect(agreementRecipients[second].role).toBeTruthy();
      expect(agreementRecipients[third].role).toBeTruthy();
      expect(agreementRecipients[first].role).toBe(AgreementRecipientSigner);
      expect(agreementRecipients[second].role).toBe(AgreementRecipientCc);
      expect(agreementRecipients[third].role).toBe(AgreementRecipientCc);
    }
  );

  And(/^I run '(.*)' task dispatcher in SalesForce$/u, async (taskDispatcherName) => {
    logStepRun(`And I run '${taskDispatcherName}' task dispatcher in SalesForce`);

    const resp = await context.sfApiClient.runTaskDispatcherByName(taskDispatcherName as string);
    expect(resp).toBeTruthy();
    expect(resp.length).toBe(1);
    expect(resp[0].isSuccess).toBeTrue();
    expect(resp[0].outputValues.output).toContain(': Ok');
  });

  When('the NetSuite Agreement is sent out for signature', async () => {
    logStepRun(`the NetSuite Agreement is sent out for signature`);

    let workflowExecutionState = await context.tiApiClient.waitForFlowCompletion(
      FlowRelatedEntityKind.ns_agreement_id,
      context.nsQuoteRec?.agreementid as string,
      waitForWorkflowMaxDelay,
      waitForRecInitialDelay,
      waitForWorkflowCompletedAttempts
    );

    const result = await context.nsApiClient.callRestlet({
      op: "quote.internalSendAgreement",
      agreementId: context.nsQuoteRec?.agreementid
    });
    const res = JSON.parse(result.body);
    log('response sendAgreement:' + result.body);
    expect(res?.content?.success).toBeTruthy();

    workflowExecutionState = await context.tiApiClient.waitForFlowCompletion(
      FlowRelatedEntityKind.ns_agreement_id,
      context.nsQuoteRec?.agreementid as string,
      waitForWorkflowMaxDelay,
      waitForRecInitialDelay,
      waitForWorkflowCompletedAttempts,
      workflowExecutionState.timestamp
    );
    expect((FlowExecutionState as Any)[workflowExecutionState.status]).toBe(FlowExecutionState.Completed);
  });

  Then(/^the SalesForce quote has status '(.*)'$/u, async (status) => {
    logStepRun(`the SalesForce quote has status ${status}`);
    context.sfQuoteRec = await context.sfApiClient.getQuote(context.sfQuoteId);
    expect(context.sfQuoteRec?.SBQQ__Status__c).toBe(status)
  });

  And(/^the SalesForce quote has status '(.*)'$/u, async (status) => {
    logStepRun(`the SalesForce quote has status ${status}`);
    context.sfQuoteRec = await context.sfApiClient.getQuote(context.sfQuoteId);
    expect(context.sfQuoteRec?.SBQQ__Status__c).toBe(status)
  });

  And('the NetSuite agreement is cancelled', async () => {
    logStepRun(`the NetSuite agreement is cancelled`);
    const nsQuoteRec = await context.nsApiClient.getQuote(must(context.nsQuoteId));
    context.nsQuoteRec = must(nsQuoteRec);
    expect(nsQuoteRec?.agreementstatus).toBe('Cancelled');
  });

  And(/^the NS Quote contains the '(.*)' item$/u, async (itemCode) => {
    logStepRun(`And the NS Quote contains the '${itemCode}' item`);

    const quoteLines = await context.nsApiClient.getQuoteLines(must(context.nsQuoteId));
    const quoteLine = quoteLines.find(f => f.itemcode === itemCode);
    expect(quoteLine).toBeDefined();
  });

  Then(/^this quote should be flagged as primary$/u, async () => {
    logStepRun(`Then this quote should be flagged as primary`);

    const sfQuote = must(context.sfQuoteRec);
    expect(sfQuote.SBQQ__Primary__c).toBe(true);
  });
};
