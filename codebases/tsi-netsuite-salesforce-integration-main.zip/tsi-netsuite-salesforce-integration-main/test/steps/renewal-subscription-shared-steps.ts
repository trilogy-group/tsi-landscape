import { When, Then, And } from 'jest-cucumber-fusion';
import {
  NsApiClient,
} from '../../test-helpers/api_clients/ns_api_client';
import { Any, HttpStatusCode, must } from '../../test-helpers/utils/types';
import {
  runAndwaitForSyncOfNsSubscriptionIntoSfGetItsIdByNsId,
  runAndWaitForStageChangeSyncByWorkflowKind,
  runAndWaitForChangeOrderProcessed
} from '../../test-helpers/utils/steps_utils';
import {
  activateNsSubscription,
  createNewDraftRenewalSubscriptionInNetSuite,
  deleteDraftRenewalSubscription,
  getNsPlanAndPriceBook,
  getNsSubscription
} from '../../test-helpers/utils/subscription_utils';
import {
  addProductToQuote,
  createQuote,
  getOpportunity,
  getOpportunityProducts,
  moveOpportunityToStage
} from '../../test-helpers/utils/opportunity_utils';
import { getFakeCustomerData, getFakeResellerAccountData } from '../../test-helpers/utils/customer_utils';
import { addDays, formatISO, parseISO } from 'date-fns';
import { getNsTodayDate, toIsoDateOnly, log, logStepRun, doOperationUntilCondition } from '../../test-helpers/utils/utils';
import 'jest-extended';
import {
  NsSubscriptionStatusId,
  NsSubscriptionChangeOrderActionId,
  NsSubscriptionChangeOrderStatusId,
  NsSubStatusChangeReason,
  NsSubLineElementStatusId,
  SubscriptionRec,
  NsSubscriptionChangeOrderRec
} from '../../test-helpers/api_contracts/ns_api_contracts';
import {
  ContextType,
  waitForRecInitialDelay, waitForRecMaxAttempts, waitForRecMaxDelay, waitForWorkflowCompletedAttempts, waitForWorkflowMaxDelay
} from '../../test-helpers/utils/steps_types';
import { CleanerRec, CleanType } from '../../test-helpers/utils/cleaner';
import { SfApiPath } from '../../test-helpers/api_clients/sf_api_client';
import { FlowExecutionState, FlowRelatedEntityKind, WorkflowKind } from '../../test-helpers/api_clients/ti_api_client';

// TODO: Refactor this file
export const getRenewalSubscriptionSharedSteps = (context: ContextType) => {
  Then('the existing renewal Opportunity should be updated along with a new NetSuite ID in SalesForce', async () => {
    logStepRun('Then the existing renewal Opportunity should be updated along with a new NetSuite ID in SalesForce');

    const waitResult = await runAndwaitForSyncOfNsSubscriptionIntoSfGetItsIdByNsId(
      context,
      must(context.nsRenewalSubscriptionId),
      context.nsRenewalSubscriptionLastSyncStatusTimeStamp
    );

    expect(
      waitResult.opportunityId,
      'Existing opportunity should be updated. So opportunity id should be the same'
    ).toBe(context.sfOpportunityId);

    context.nsRenewalSubscriptionLastSyncStatusTimeStamp = waitResult.nsRenewalSubscriptionLastSyncStatusTimeStamp;
    context.sfOpportunityRec = await getOpportunity(context.sfApiClient, must(context.sfOpportunityId));
  });

  Then('this draft renewal subscription is synced to a new opportunity in SalesForce', async () => {
    logStepRun('Then this draft renewal subscription is synced to a new opportunity in SalesForce');

    const waitResult = await runAndwaitForSyncOfNsSubscriptionIntoSfGetItsIdByNsId(
      context,
      must(context.nsRenewalSubscriptionId),
      context.nsRenewalSubscriptionLastSyncStatusTimeStamp
    );

    context.sfOpportunityId = waitResult.opportunityId;
    context.nsRenewalSubscriptionLastSyncStatusTimeStamp = waitResult.nsRenewalSubscriptionLastSyncStatusTimeStamp;
    context.sfOpportunityRec = await getOpportunity(context.sfApiClient, context.sfOpportunityId);
  });

  And('this draft renewal subscription has been synced to opportunity in SalesForce', async () => {
    logStepRun('And this draft renewal subscription has been synced to opportunity in SalesForce');

    const waitResult = await runAndwaitForSyncOfNsSubscriptionIntoSfGetItsIdByNsId(
      context,
      must(context.nsRenewalSubscriptionId),
      context.nsRenewalSubscriptionLastSyncStatusTimeStamp
    );

    context.sfOpportunityId = waitResult.opportunityId;
    context.nsRenewalSubscriptionLastSyncStatusTimeStamp = waitResult.nsRenewalSubscriptionLastSyncStatusTimeStamp;

    // Setting Nigel Osullivan because is necessary to have a valid sales rep
    const owner = await context.sfApiClient.getUserIdByName('Nigel Osullivan');
    expect(owner.Id).toBeTruthy();
    await context.sfApiClient.updateOpportunityOwner(context.sfOpportunityId, owner.Id);
    context.sfOpportunityRec = await getOpportunity(context.sfApiClient, context.sfOpportunityId);
  });

  And('a subscription plan item is set as INCLUDE IN RENEWAL SUBSCRIPTION=NEVER', async () => {
    logStepRun('AND a subscription plan item is set as INCLUDE IN RENEWAL SUBSCRIPTION=NEVER');
    const plan = await context.nsApiClient.getSubscriptionPlanById(context.nsSubscriptionPlanId, true);
    const nonRenewable = plan.member.items.find(f => f.renewalOption.id === 'NEVER' || f.renewalOption.id === 'DIFFERENT_PLAN');
    // The plan should contain a non-renewable item
    expect(nonRenewable).toBeDefined();
  });

  And('this opportunity has no products', async () => {
    logStepRun('And this opportunity has no products');

    const opportunityProducts = await getOpportunityProducts(context.sfApiClient, must(context.sfOpportunityId));
    context.sfOpportunityProductsData = opportunityProducts;

    expect(context.sfOpportunityProductsData.totalSize).toEqual(0);
  });

  And('this opportunity has products', async (args: Any) => {
    logStepRun('And this opportunity has products');
    context.sfOpportunityProductsData = await getOpportunityProducts(context.sfApiClient, must(context.sfOpportunityId));

    expect(context.sfOpportunityProductsData.totalSize).toEqual(args.length);
    expect(context.sfOpportunityProductsData.records).toBeTruthy();
    expect(
      context.sfOpportunityProductsData.records.map((x) => ({
        productCode: x.PricebookEntry.Product2.ProductCode,
        quantity: x.Quantity,
        term: x.Subscription_Term__c,
        totalPrice: x.TotalPrice,
      }))
    ).toIncludeSameMembers(
      args.map((x) => ({
        productCode: x['Product Code'],
        quantity: Number.parseInt(x['Quantity']),
        term: Number.parseInt(x['Term']),
        totalPrice: Number.parseFloat(x['Total Price']),
      }))
    );
  });

  And(
    'all the fields values of new draft renewal subscription should correspond to the fields of SalesForce opportunity',
    async (args: Any) => {
      logStepRun(
        'And all the fields values of new draft renewal subscription should correspond to the fields of SalesForce opportunity'
      );

      const opportunityRec = await getOpportunity(context.sfApiClient, must(context.sfOpportunityId));

      context.sfOpportunityRec = opportunityRec;

      const subscriptionRec = await context.nsApiClient.getSubscription(must(context.nsRenewalSubscriptionId));
      const parentSubscriptionRec = await context.nsApiClient.getSubscription(
        parseInt(must(subscriptionRec.custrecord_parent_subscription?.id, ''))
      );

      const gapBetweenRenewalAndCloseDate = 30;
      expect(
        context.sfOpportunityRec.CloseDate,
        'Close Date (CloseDate) == subscription.startDate - 30 Days'
      ).toStrictEqual(
        formatISO(
          addDays(parseISO(must(subscriptionRec.startDate, 'Subscription should have a startDate')), -gapBetweenRenewalAndCloseDate),
          { representation: 'date' }
        )
      );
      expect(
        context.sfOpportunityRec.Current_ARR__c,
        'Current ARR (Current_ARR__c) == calculated from parent subscription lines & price intervals'
      ).toStrictEqual(parseFloat(args[0].ARR));
      const partOfStringToMatch = 5;
      expect(
        context.sfOpportunityRec.Current_Billing_Term__c.substring(0, partOfStringToMatch).toLowerCase(),
        'Current Billing Frequency (Current_Billing_Term__c) == subscription.frequency.id'
      ).toStrictEqual(
        must(subscriptionRec.frequency, 'Subscription should have a frequency')
          .id?.substring(0, partOfStringToMatch)
          .toLowerCase()
      );
      expect(
        context.sfOpportunityRec.Current_Product__c,
        'Current Product (Current_Product__c) == subscription.parentsubscription.subscriptionPlan.itemId'
      ).toStrictEqual(parentSubscriptionRec.subscriptionPlanName);
      expect(
        context.sfOpportunityRec.Current_Subscription_End_Date__c,
        'Current Subscription End Date (Current_Subscription_End_Date__c) == subscription.parentsubscription.endDate'
      ).toStrictEqual(parentSubscriptionRec.endDate);
      expect(
        context.sfOpportunityRec.Current_Subscription_Start_Date__c,
        'Current Subscription Start Date (Current_Subscription_Start_Date__c) == subscription.parentsubscription.startDate'
      ).toStrictEqual(parentSubscriptionRec.startDate);
      expect(
        context.sfOpportunityRec.Current_Success_Level__c,
        'Current Success Level (Current_Success_Level__c) == calculated from parent subscription.subscriptionPlan.displayName'
      ).toStrictEqual(args[0]['Plan Success Level']);
      expect(
        context.sfOpportunityRec.Current_TCV__c,
        'Current TCV (Current_TCV__c) == calculated from parent subscription lines charges'
      ).toStrictEqual(parseFloat(args[0].TCV));
      expect(
        context.sfOpportunityRec.Current_Term__c,
        'Current Term (Current_Term__c) == calculated from parent subscription fields "initialTerm" and from "startDate", "endDate"'
      ).toStrictEqual(parseFloat(args[0].Term));
      expect(
        context.sfOpportunityRec.Draft_Renewal_Subscription_Name__c,
        'Draft Renewal Subscription Name (Draft_Renewal_Subscription_Name__c) == subscription.name'
      ).toStrictEqual(subscriptionRec.name);
      expect(context.sfOpportunityRec.NetSuite_ID__c, 'NetSuite ID (NetSuite_ID__c) == subscription.id').toStrictEqual(
        subscriptionRec.id
      );
      expect(
        context.sfOpportunityRec.Parent_Subscription_Name__c,
        'Parent Subscription Name (Parent_Subscription_Name__c) == subscription.parentsubscription.name'
      ).toStrictEqual(parentSubscriptionRec.name);
      expect(
        context.sfOpportunityRec.Product__c,
        'Product Family (Product__c) == calculated from subscription.class.refName'
      ).toStrictEqual(args[0]['Product Class']);
      expect(
        context.sfOpportunityRec.Renewal_Date__c,
        'Renewal Date (Renewal_Date__c) == subscription.startDate'
      ).toStrictEqual(subscriptionRec.startDate);
    }
  );

  And('I create a quote for this opportunity in SalesForce', async () => {
    logStepRun('And I create a quote for this opportunity in SalesForce');

    context.sfQuoteId = await createQuote(
      context.sfApiClient,
      must(context.sfOpportunityId),
      must(context.sfAccountId),
      must(context.sfContactId),
      must(context.sfOpportunityRec?.Renewal_Date__c)
    );

    context.sfQuoteLastSyncStatusTimeStamp = (new Date()).toISOString();
  });

  And(/^I add the '(.*)' product to the quote/u, async (itemCode) => {
    logStepRun(`And I add the '${itemCode}' product to the quote`);

    await addProductToQuote(
      context.sfApiClient,
      must(context.sfQuoteId),
      must(itemCode as string),
    );
  });

  And('I wait quote flow to finish', async () => {
    logStepRun('And I wait quote flow to finish');
    const workflowExecutionState = await context.tiApiClient.waitForFlowCompletion(
      FlowRelatedEntityKind.sf_quote_id,
      context.sfQuoteId,
      waitForWorkflowMaxDelay,
      waitForRecInitialDelay,
      waitForWorkflowCompletedAttempts,
      context.sfQuoteLastSyncStatusTimeStamp
    );
    expect((FlowExecutionState as Any)[workflowExecutionState.status]).toBe(FlowExecutionState.Completed);
    context.sfQuoteLastSyncStatusTimeStamp = workflowExecutionState.timestamp;
  })

  And('the Salesforce accepted quote is translated to NS Subscription and Quote', async () => {
    logStepRun('And the Salesforce accepted quote is translated to NS Subscription and Quote');
    const opportunity = await context.sfApiClient.getSobject('Opportunity', must(context.sfOpportunityId));
    expect(parseInt(opportunity.NetSuite_ID__c)).not.toBe(context.nsRenewalSubscriptionId);
    context.nsRenewalSubscriptionId = parseInt(opportunity.NetSuite_ID__c);

    const quote = await context.sfApiClient.getSobject('SBQQ__Quote__c', context.sfQuoteId);
    expect(parseInt(quote.NetSuite_ID__c)).not.toBeUndefined();
  });

  When('the NetSuite ID is removed from the SF contact', async () => {
    logStepRun('When the NetSuite ID is removed from the SF contact');
    await context.sfApiClient.cleanContactNetSuiteid(must(context.sfContactId));
  });

  And(
    /^a subscription with the plan '(.*)' and price book '(.*)' is created in NetSuite$/u,
    async (planName, priceBookName) => {
      logStepRun(
        `And a subscription with the plan '${planName}' and price book '${priceBookName}' is created in NetSuite`
      );
      await createSubscription(context, planName, priceBookName);
    }
  );

  When(
    /^try to create a standalone subscription with the plan '(.*)' and price book '(.*)' in NetSuite$/u,
    async (planName, priceBookName) => {
      logStepRun(
        `When try to create a standalone subscription with the plan '${planName}' and price book '${priceBookName}' in NetSuite`
      );
      context.lastResponse = await context.nsApiClient.createSubscription({
        customerId: must(context.nsCustomerId),
        billingAccountId: parseInt(must(context.nsParentSubscriptionRec?.billingAccount?.id)),
        startDate: toIsoDateOnly(addDays(new Date(must(context.nsParentSubscriptionRec?.endDate)), 1)),
        subscriptionPlanId: context.nsSubscriptionPlanId,
        priceBookId: context.sfPriceBookId,
        includedLinesNumber: must(context.nsParentSubscriptionRec?.subscriptionLine?.items?.length),
        parentSubscriptionId: context.nsParentSubscriptionId
      }, HttpStatusCode.Error);
    }
  );

  When(
    /^the parent subscription id is set on this new subscription$/u,
    async () => {
      logStepRun(`When the parent subscription id is set on this new subscription`);
      context.lastResponse = await context.nsApiClient.request('record/v1/subscription', 'PATCH', JSON.stringify({
        custrecord_parent_subscription: context.nsParentSubscriptionId
      }), HttpStatusCode.Error);
    }
  );

  And(
    /^another subscription with the plan '(.*)' and price book '(.*)' is created in NetSuite$/u,
    async (planName, priceBookName) => {
      logStepRun(
        `And another standalone subscription with the plan '${planName}' and price book '${priceBookName}' is created in NetSuite`
      );
      context.nsRenewalSubscriptionId = await context.nsApiClient.createSubscription({
        customerId: must(context.nsCustomerId),
        billingAccountId: parseInt(must(context.nsParentSubscriptionRec?.billingAccount?.id)),
        startDate: toIsoDateOnly(addDays(new Date(must(context.nsParentSubscriptionRec?.endDate)), 1)),
        subscriptionPlanId: context.nsSubscriptionPlanId,
        priceBookId: context.sfPriceBookId,
        includedLinesNumber: must(context.nsParentSubscriptionRec?.subscriptionLine?.items?.length)
      });
    }
  );

  Then('error is shown saying the auto-renewal should be disabled on the parent subscription', () => {
    logStepRun(`Then error is shown saying the auto-renewal should be disabled on the parent subscription`);
    expect(context.lastResponse.statusCode).toBe(HttpStatusCode.Error);
    expect(JSON.parse(context.lastResponse.body)["o:errorDetails"][0].detail).toContain('Automatically Initiate Renewal Process must be UNCHECKED in the parent subscription');
  })

  And(/^this subscription is active$/u, async () => {
    logStepRun('And this subscription is active');
    context.nsLastChangeOrderId = await activateNsSubscription(
      context.nsApiClient,
      must(context.nsCustomerId),
      context.nsParentSubscriptionId,
      context.nsCurrentSubscriptionIncludedLinesNumber,
      (context.nsParentSubscriptionRec && context.nsParentSubscriptionRec.startDate) ? new Date(context.nsParentSubscriptionRec.startDate) : addDays(Date.now(), -1)
    );
  });

  When(/^I activate this renewal subscription in NetSuite$/u, async () => {
    logStepRun('When I activate this renewal subscription in NetSuite');

    // Get the up-to-date renewal subscription to activate
    context.nsRenewalSubscription = await getNsSubscription(context.nsApiClient, must(context.nsRenewalSubscriptionId));
    const requestBody: SubscriptionRec = {};

    // If missing, create the contractual documents.
    if (context.nsRenewalSubscription.custrecord_contract_docs === undefined) {
      requestBody.custrecord_contract_docs = {
        id: (await context.nsApiClient.createContractualDocuments(must(context.nsRenewalSubscriptionId))).toString()
      };
    }

    // If there are some draft lines, set them to pending activation.
    requestBody.subscriptionLine = {
      items: context.nsApiClient.getLinesWithPendingActivationFromDraftLines(context.nsRenewalSubscription.subscriptionLine?.items)
    }

    // Update the renewal subscription.
    const status = await context.nsApiClient.updateSubscription(must(context.nsRenewalSubscriptionId), requestBody);
    expect(status, `Failed to update subscription ${context.nsRenewalSubscriptionId}`).toBe(HttpStatusCode.NoContent);

    // Activate the subscription in NetSuite.
    context.nsLastChangeOrderId = await activateNsSubscription(
      context.nsApiClient,
      must(context.nsCustomerId),
      must(context.nsRenewalSubscriptionId),
      context.nsCurrentSubscriptionIncludedLinesNumber,
      new Date(must(context.nsRenewalSubscription.startDate))
    );
  });

  When(
    /^I create a draft renewal subscription with the plan '(.*)' and price book '(.*)' in NetSuite$/u,
    async (planName, priceBookName) => {
      context.nsRenewalSubscriptionId = await createNewDraftRenewalSubscriptionInNetSuite(
        context.nsApiClient,
        must(context.nsCustomerId),
        context.nsParentSubscriptionId,
        planName,
        priceBookName
      );
    }
  );

  And(
    /^a new draft renewal subscription is created for this subscription with the different plan '(.*)' and price book '(.*)' in NetSuite$/u,
    async (planName, priceBookName) => {
      logStepRun(
        `And a new draft renewal subscription is created for this subscription with the different plan '${planName}' and price book '${priceBookName}' in NetSuite`
      );
      context.nsRenewalSubscriptionId = await createNewDraftRenewalSubscriptionInNetSuite(
        context.nsApiClient,
        must(context.nsCustomerId),
        context.nsParentSubscriptionId,
        planName,
        priceBookName
      );
      await context.nsApiClient.fixSubscriptionIfItIsNotIncluded(must(context.nsRenewalSubscriptionId));
    }
  );

  And(
    /^a new draft renewal subscription is created for this subscription with the different plan '(.*)' and price book '(.*)' and quantity (.*) in NetSuite$/u,
    async (planName, priceBookName, quantity) => {
      logStepRun(
        `And a new draft renewal subscription is created for this subscription with the different plan '${planName}' and price book '${priceBookName}' in NetSuite`
      );
      context.nsRenewalSubscriptionId = await createNewDraftRenewalSubscriptionInNetSuite(
        context.nsApiClient,
        must(context.nsCustomerId),
        context.nsParentSubscriptionId,
        planName,
        priceBookName
      );
      await context.nsApiClient.fixSubscriptionIfItIsNotIncluded(must(context.nsRenewalSubscriptionId));
      await context.nsApiClient.updateSubscriptionItemsQuantity(
        must(context.nsRenewalSubscriptionId),
        Number.parseInt(quantity as string)
      );
    }
  );

  When(/^this draft renewal subscription is deleted in NetSuite$/u, async () => {
    logStepRun(`When this draft renewal subscription is deleted in NetSuite`);
    await deleteDraftRenewalSubscription(context.nsApiClient, must(context.nsRenewalSubscriptionId));

    context.nsRenewalSubscriptionId = null;
  });

  And(/^this draft renewal subscription is deleted in NetSuite$/u, async () => {
    logStepRun(`And this draft renewal subscription is deleted in NetSuite`);
    await deleteDraftRenewalSubscription(context.nsApiClient, must(context.nsRenewalSubscriptionId));
    context.nsRenewalSubscriptionId = null;
  });

  When(
    /^a new draft renewal subscription is created for this subscription with the plan '(.*)' and price book '(.*)' in NetSuite$/u,
    async (planName, priceBookName) => {
      logStepRun(
        `When a new draft renewal subscription is created for this subscription with the plan '${planName}' and price book '${priceBookName}' in NetSuite`
      );
      context.nsFirstRenewalSubscriptionId = must(context.nsRenewalSubscriptionId);
      context.nsRenewalSubscriptionId = await createNewDraftRenewalSubscriptionInNetSuite(
        context.nsApiClient,
        must(context.nsCustomerId),
        context.nsParentSubscriptionId,
        planName,
        priceBookName
      );
    }
  );

  And(
    /^there is a draft renewal subscription for this subscription with the plan '(.*)' and price book '(.*)' in NetSuite$/u,
    async (planName, priceBookName) => {
      logStepRun(
        `And there is a draft renewal subscription for this subscription with the plan '${planName}' and price book '${priceBookName}' in NetSuite`
      );
      context.nsRenewalSubscriptionId = await createNewDraftRenewalSubscriptionInNetSuite(
        context.nsApiClient,
        must(context.nsCustomerId),
        context.nsParentSubscriptionId,
        planName,
        priceBookName
      );
    }
  );

  And(/^this opportunity is on the '(.*)' stage in SalesForce$/u, async (expectedOpportunityStageName) => {
    logStepRun(`And this opportunity is on the '${expectedOpportunityStageName}' stage in SalesForce`);
    expect(context.sfOpportunityRec?.StageName, 'Opportunity stage').toBe(expectedOpportunityStageName);
  });

  Then(/^this opportunity is on the '(.*)' stage in SalesForce$/u, async (expectedOpportunityStageName) => {
    logStepRun(`And this opportunity is on the '${expectedOpportunityStageName}' stage in SalesForce`);

    context.sfOpportunityRec = await getOpportunity(context.sfApiClient, must(context.sfOpportunityId));
    expect(context.sfOpportunityRec?.StageName, 'Opportunity stage').toBe(expectedOpportunityStageName);
  });

  And(/^this opportunity is moved to the '(.*)' stage in SalesForce$/u, async (stageName) => {
    logStepRun(`And this opportunity is moved to the '${stageName}' stage in SalesForce`);
    await moveOpportunityToStage(
      context.sfApiClient,
      must(context.sfOpportunityId),
      stageName
    );
  });

  When(/^I move this opportunity to the '(.*)' stage in SalesForce$/u, async (stageName) => {
    logStepRun(`When I move this opportunity to the '${stageName}' stage in SalesForce`);
    await moveOpportunityToStage(
      context.sfApiClient,
      must(context.sfOpportunityId),
      stageName
    );
  });

  And(/^I move this opportunity to the '(.*)' stage in SalesForce$/u, async (stageName) => {
    logStepRun(`And I move this opportunity to the '${stageName}' stage in SalesForce`);
    await moveOpportunityToStage(
      context.sfApiClient,
      must(context.sfOpportunityId),
      stageName
    );
  });

  When(/^I assign this opportunity to the '(.*)' in SalesForce$/u, async (newOwnerName) => {
    logStepRun(`When I assign this opportunity to the '${newOwnerName}' in SalesForce`);

    const owner = await context.sfApiClient.getUserIdByName(newOwnerName as string);
    expect(owner.Id).toBeTruthy();
    context.sfOpportunityOwnerEmail = owner.Email;

    const respCode = await context.sfApiClient.updateOpportunityOwner(must(context.sfOpportunityId), owner.Id);
    expect(respCode).toBe(HttpStatusCode.NoContent);
  });

  When(/^we set opportunity addres verified to '(.*)' in SalesForce$/u, async (newValue) => {
    logStepRun(`we set opportunity addres verified to '${newValue}' in SalesForce`);
    context.sfOpportunityId = '0061s00000Yg71DAAR';
    const respCode = await context.sfApiClient.updateOpportunityAddressesValidated(
      context.sfOpportunityId,
      Boolean(newValue)
    );
    expect(respCode).toBe(HttpStatusCode.NoContent);
  });

  Then(/^the '(.*)' task might be created in SalesForce for the opportunity$/u, async (taskSubject) => {
    logStepRun(`Then the '${taskSubject}' task might be created in SalesForce for the opportunity`);

    const reportContent = await context.sfApiClient.getReportContent('00O2x000002BnGuEAK');
    expect(reportContent).toBeTruthy();
    expect(reportContent.factMap).toBeTruthy();

    const facts = Object.keys(must(reportContent.factMap)).map((key) => ({
      key,
      value: must(reportContent.factMap)[key],
    }));

    expect(
      facts.any(
        (fact) =>
          !!fact?.value?.rows &&
          fact?.value?.rows.any(
            (row) => !!row.dataCells && row.dataCells.any((cell) => cell.value === must(context.sfOpportunityId))
          )
      )
    ).toBeTrue();
  });

  And(/^the '(.*)' task should not be created in SalesForce for the opportunity$/u, async (taskSubject) => {
    logStepRun(`the '${taskSubject}' task should not be created in SalesForce for the opportunity`);

    const taskIds = await context.sfApiClient.getTaskRelatedToOpportunityBySubject(
      must(context.sfOpportunityId),
      taskSubject as string
    );

    expect(taskIds).toBeTruthy();
    expect(taskIds.length).toBe(0);
  });

  And(/^the Manual O2C flag on this opportunity is '(.*)' in SalesForce$/u, async (manualO2cFlag) => {
    logStepRun(`And the Manual O2C flag on this opportunity is '${manualO2cFlag}' in SalesForce`);

    const respCode = await context.sfApiClient.updateOpportunityManualO2cFlag(
      must(context.sfOpportunityId),
      Boolean(manualO2cFlag),
      'for testing purposes'
    );

    expect(respCode).toBe(HttpStatusCode.NoContent);
  });

  And(/^old draft renewal subscription in the NetSuite should be deleted$/u, async () => {
    logStepRun(`And old draft renewal subscription in the NetSuite should be deleted`);

    const oldRenewalExists = await context.nsApiClient.doSubscriptionExist(must(context.nsOldRenewalSubscriptionId));

    expect(
      oldRenewalExists,
      `Draft renewal subscription '${context.nsOldRenewalSubscriptionId} was not removed`
    ).toBeFalse();

    // a new draft renewal is created
    //await context.cleaner.removeClean(new CleanerRec(CleanType.removeNsSubscription, context.nsRenewalSubscriptionId));
    context.nsOldRenewalSubscriptionId = null;
  });

  And(/^I assign an reseller with non empty reseller agreement link to this opportunity$/u, async () => {
    logStepRun(`I assign an reseller with non empty reseller agreement link to this opportunity`);

    const resellerCustomerData = getFakeCustomerData();

    const nsResellerCustomerId = await context.nsApiClient.createCustomer(must(context.nsSubsidiaryId), {
      companyName: resellerCustomerData.customerName,
      email: resellerCustomerData.customerEmail,
      phone: resellerCustomerData.customerPhone,
      fax: resellerCustomerData.customerFax,
      webSite: resellerCustomerData.customerWebSite,
      billingAddrCountry: resellerCustomerData.billingAddrCountry,
      billingAddrPostalCode: resellerCustomerData.billingAddrPostalCode,
      billingAddrState: resellerCustomerData.billingAddrState,
      billingAddrCity: resellerCustomerData.billingAddrCity,
      billingAddrStreet: resellerCustomerData.billingAddrStreet,
      shippingAddrCountry: resellerCustomerData.shippingAddrCountry,
      shippingAddrPostalCode: resellerCustomerData.shippingAddrPostalCode,
      shippingAddrState: resellerCustomerData.shippingAddrState,
      shippingAddrCity: resellerCustomerData.shippingAddrCity,
      shippingAddrStreet: resellerCustomerData.shippingAddrStreet,
      isReseller: true,
    });

    log(`Ns reseller has been created. Id: ${nsResellerCustomerId}`);
    // reseller account can't be removed
    // await context.cleaner.addClean(new CleanerRec(CleanType.removeNsCustomer, nsResellerCustomerId));

    const resellerAccountId = await context.sfApiClient.createAccount({
      Name: resellerCustomerData.customerName,
      Phone: resellerCustomerData.customerPhone,
      Fax: resellerCustomerData.customerFax,
      Website: resellerCustomerData.customerWebSite,
      ShippingCountry: resellerCustomerData.billingAddrCountry,
      ShippingStreet: resellerCustomerData.billingAddrStreet,
      ShippingCity: resellerCustomerData.billingAddrCity,
      ShippingState: resellerCustomerData.billingAddrState,
      ShippingPostalCode: resellerCustomerData.billingAddrPostalCode,
      NetSuite_ID__c: nsResellerCustomerId.toString(),
    });
    log(`Sf reseller account has been created. Id: ${resellerAccountId}`);

    await context.cleaner.addClean(new CleanerRec(CleanType.removeSfAccount, resellerAccountId));

    context.sfResellerAccountId = resellerAccountId;

    const sfSubsidiary = await context.sfApiClient.getSubsidiaryByName(must(context.nsSubsidiaryName));

    const resellerAgreementData = getFakeResellerAccountData();

    const resellerAgreementId = await context.sfApiClient.createResellerAgreement({
      CurrencyIsoCode: resellerAgreementData.currencyIsoCode,
      Reseller_Agreement_Link__c: resellerAgreementData.resellerAgreementLink,
      Account__c: context.sfResellerAccountId,
      Subsidiary__c: sfSubsidiary.Id,
    });
    log(`Sf reseller agreement has been created. Id: ${resellerAgreementId}`);

    await context.cleaner.addClean(new CleanerRec(CleanType.removeSfResellerAgreement, resellerAgreementId));

    const partnerId = await context.sfApiClient.linkResellerAgreementToOpportunity(
      must(context.sfOpportunityId),
      resellerAccountId
    );

    await context.cleaner.addClean(new CleanerRec(CleanType.removeSfPartner, partnerId));
  });

  Then('the SalesForce opportunity is moved to Finalizing stage', async () => {
    logStepRun(`the SalesForce opportunity is moved to Finalizing stage`);
    context.sfOpportunityRec = await getOpportunity(context.sfApiClient, context.sfOpportunityId as string)
    expect(context.sfOpportunityRec.StageName).toBe('Finalizing');
  })

  And('the SalesForce opportunity is moved to Quote Follow-up stage', async () => {
    logStepRun(`the SalesForce opportunity is moved to Quote Follow-up stage`);
    context.sfOpportunityRec = await getOpportunity(context.sfApiClient, context.sfOpportunityId as string)
    expect(context.sfOpportunityRec.StageName).toBe('Quote Follow-Up');
  });

  And('Ready for Invoice Request is true', async () => {
    logStepRun(`Ready for Invoice Request is true`);
    expect(context.sfOpportunityRec?.Ready_for_Invoice_Request__c).toBeTrue();
  })

  Then('wait for opportunity sync and agreement sync', async () => {
    logStepRun(`wait for opportunity sync and agreement sync`);
    let workflowExecutionState = await context.tiApiClient.waitForFlowCompletion(
      FlowRelatedEntityKind.sf_opportunity_id,
      context.sfOpportunityId as string,
      waitForWorkflowMaxDelay,
      waitForRecInitialDelay,
      waitForWorkflowCompletedAttempts,
      (new Date()).toISOString()
    );
    expect((FlowExecutionState as Any)[workflowExecutionState.status]).toBe(FlowExecutionState.Completed);

    workflowExecutionState = await context.tiApiClient.waitForFlowCompletion(
      FlowRelatedEntityKind.ns_agreement_id,
      context.nsQuoteRec?.agreementid as string,
      waitForWorkflowMaxDelay,
      waitForRecInitialDelay,
      waitForWorkflowCompletedAttempts,
      workflowExecutionState.timestamp
    );
    expect((FlowExecutionState as Any)[workflowExecutionState.status]).toBe(FlowExecutionState.Completed);
  });

  When('the opportunity has set win type AR and previous quote with AR Clause', async () => {
    logStepRun(`the opportunity has set win type AR and previous quote with AR Clause`);
    await context.sfApiClient.updateRecord(context.sfOpportunityId as string, SfApiPath.Opportunity, {
      Win_Type__c: 'Auto-Renew',
      Previous_Quote_with_AR_clause__c: 'https://trilogy-sales--full.sandbox.lightning.force.com/lightning/r/ContentDocument/idhere/view'
    });
  });

  When('the new subscription is activated', async () => {
    logStepRun(`the new subscription is activated`);

    const subscription = await context.nsApiClient.getSubscription(must(context.nsQuoteRec?.subscriptionid));

    context.nsLastChangeOrderId = await activateNsSubscription(
      context.nsApiClient,
      must(context.nsCustomerId),
      must(subscription.id),
      context.nsCurrentSubscriptionIncludedLinesNumber,
      new Date(subscription.startDate as string)
    );
  })

  And(/^this change order for (activation|termination) has been processed and synced in Salesforce$/, async (changeOrderType) => {
    logStepRun(`And this change order for ${changeOrderType} has been processed and synced in Salesforce`);

    // Run and wait for the sync from NS subscription on given event to SF opportunity.
    logStepRun(`Change Order id='${context.nsLastRenewalSubscriptionChangeOrder?.id}'`);
    await runAndWaitForChangeOrderProcessed(
      context,
      must(context.nsRenewalSubscriptionId),
      parseInt(must(context.nsLastRenewalSubscriptionChangeOrder?.id ?? context.nsLastChangeOrderId?.toString())),
      changeOrderType as ('activation' | 'termination'),
    );
  })

  When(/^I terminate this renewal subscription due to a (customer cancellation|finance action) in NetSuite$/u, async (reason) => {
    logStepRun(`When I terminate this renewal subscription due to a ${reason} in NetSuite`);

    // Get the up-to-date renewal subscription, then terminate it due to customer cancellation
    context.nsRenewalSubscription = await getNsSubscription(context.nsApiClient, must(context.nsRenewalSubscriptionId));
    const requestBody: SubscriptionRec = {};

    // If there are some draft lines, set them to pending activation.
    requestBody.subscriptionLine = {
      items: context.nsApiClient.getLinesWithPendingActivationFromDraftLines(context.nsRenewalSubscription.subscriptionLine?.items)
    }

    // Update the renewal subscription.
    const status = await context.nsApiClient.updateSubscription(must(context.nsRenewalSubscriptionId), requestBody);
    expect(status, `Failed to update subscription ${context.nsRenewalSubscriptionId}`).toBe(HttpStatusCode.NoContent);

    let subChageReason = NsSubStatusChangeReason.Churn;
    if (reason === 'finance action') {
      subChageReason = NsSubStatusChangeReason.FinanceAction;
    }
    // Terminate the renewal subscription.
    context.nsLastChangeOrderId = await context.nsApiClient.terminateSubscription(context.nsRenewalSubscription, subChageReason);
    log(`The subscription terminated id=${context.nsRenewalSubscriptionId}`);
  });

  Then(/^this renewal subscription should be active in NetSuite$/u, async () => {
    logStepRun(`Then this renewal subscription should be active in NetSuite`);

    // Check the renewal subscription is active.
    ({
      subscription: context.nsRenewalSubscription,
      subscriptionChangeOrder: context.nsLastRenewalSubscriptionChangeOrder
    } = await checkSubscriptionStatus(context.nsApiClient, must(context.nsRenewalSubscriptionId), NsSubscriptionStatusId.Active));
  });

  Then(/^this renewal subscription should be terminated in NetSuite$/u, async () => {
    logStepRun(`Then this renewal subscription should be terminated in NetSuite`);

    // Check the renewal subscription is terminated.
    ({
      subscription: context.nsRenewalSubscription,
      subscriptionChangeOrder: context.nsLastRenewalSubscriptionChangeOrder
    } = await checkSubscriptionStatus(context.nsApiClient, must(context.nsRenewalSubscriptionId), NsSubscriptionStatusId.Terminated));
  });

  Then(/^this renewal subscription should be terminated with a 'TERMINATED' status in NetSuite$/u, async () => {
    logStepRun(`Then this renewal subscription should be terminated with a 'TERMINATED' status in NetSuite`);

    // Get the up-to-date renewal subscription, then check the renewal subscription status is 'TERMINATED'.
    context.nsRenewalSubscription = await getNsSubscription(context.nsApiClient, must(context.nsRenewalSubscriptionId));
    expect(context.nsRenewalSubscription.billingSubscriptionStatus?.id).toBe(NsSubscriptionStatusId.Terminated);
  });

  And(/^this renewal subscription has been synced on ([a-z]*) to opportunity in SalesForce$/u, async (eventName) => {
    logStepRun(`And this renewal subscription has been synced on ${eventName} to opportunity in SalesForce`)

    // Determine the workflow to call based on the given event name.
    const workflowKind = (function () {
      switch (eventName) {
        case 'activation': return WorkflowKind.SyncSfRenewalOpportunityOnNsDraftRenewalSubscriptionActivated;
        case 'termination': return WorkflowKind.SyncSfRenewalOpportunityOnNsDraftRenewalSubscriptionTerminated;
        default: return null;
      }
    })();
    if (workflowKind === null) {
      fail(`Unexpected sync event name '${eventName}'.`);
    }

    // Run and wait for the sync from NS subscription on given event to SF opportunity.
    const waitResult = await runAndWaitForStageChangeSyncByWorkflowKind(
      context,
      workflowKind,
      must(context.nsRenewalSubscriptionId),
      context.nsLastChangeOrderId,
    );
    context.nsRenewalSubscriptionLastSyncStatusTimeStamp = waitResult.nsRenewalSubscriptionLastSyncStatusTimeStamp;
  });

  And(/^there is an '([^']+)' approval process pending for the SalesForce opportunity$/u, async (approvalProcessName) => {
    logStepRun(`And there is an '${approvalProcessName}' approval process pending for the SalesForce opportunity`);
    // Get pending records for the opportunity
    // Wait for the SF product configuration to be updated.
    await doOperationUntilCondition<{ Id: string }>(
      async () => (await context.sfApiClient.getSoqlQuery<{ Id: string }>(`SELECT Id 
      FROM ProcessInstance 
      WHERE Status='Pending'
      AND ProcessDefinition.DeveloperName='${approvalProcessName}'
      AND TargetObjectId='${context.sfOpportunityId}'`)).data.records[0],
      (_: { Id: string }) => true,
      waitForRecMaxDelay,
      waitForRecInitialDelay,
      waitForRecMaxAttempts
    );
  });

  And(/^the opportunity should be '(.*)' in Salesforce$/u, async (stageName) => {
    logStepRun(`And the opportunity should be '${stageName}' in Salesforce`);

    // Get the up-to-date opportunity, then check the stage name.
    context.sfOpportunityRec = await getOpportunity(context.sfApiClient, must(context.sfOpportunityId));
    expect(context.sfOpportunityRec?.StageName).toBe(stageName);
  });

  And(/^this opportunity should have a description matching '(.*)'$/u, async (descriptionPattern) => {
    logStepRun(`And this opportunity should have a description matching '${descriptionPattern}'`);

    // Check the description matches the given description pattern.
    const descriptionPatternRegex = new RegExp(descriptionPattern as string);
    expect(context.sfOpportunityRec?.Description).toMatch(descriptionPatternRegex);
  });

  And(/^this opportunity should have a loss reason equal to '(.*)'$/u, async (lossReason) => {
    logStepRun(`And this opportunity should have a loss reason equal to '${lossReason}'`);
    context.sfOpportunityRec = await getOpportunity(context.sfApiClient, must(context.sfOpportunityId));
    // Check the loss reason has the given value.
    expect(context.sfOpportunityRec?.Loss_Reason__c).toBe(lossReason);
  });

  And(/^this opportunity should have a win type equal to '(.*)'$/u, async (winType) => {
    logStepRun(`And this opportunity should have a win type equal to '${winType}'`);

    // Check the win type has the given value.
    expect(context.sfOpportunityRec?.Win_Type__c).toBe(winType);
  });

  And(/^the primary quote of the opportunity should be set as non-primary$/u, async (winType) => {
    logStepRun(`And the primary quote of the opportunity should be set as non-primary`);
    var quote = await context.sfApiClient.getQuote(context.sfQuoteId);
    var opp = await getOpportunity(context.sfApiClient, must(context.sfOpportunityId));
    // The primary quote should not be non-primary
    expect(opp.SBQQ__PrimaryQuote__c).toBe(null);
    expect(quote?.SBQQ__Primary__c).toBe(false);
  });

  And(
    /^a subscription with the the start date of '(.*)' and plan '(.*)' and price book '(.*)' is created in NetSuite$/u,
    async (startDate, planName, priceBookName) => {
      logStepRun(
        `And a subscription with the plan '${planName}' and price book '${priceBookName}' and the start date of '${startDate}' is created in NetSuite`
      );
      await createSubscription(context, planName, priceBookName, startDate as string);
    }
  );

  And('the Don\'t update current fields from Netsuite is set to true', async() => {
    logStepRun('And the Don\'t update current fields from Netsuite is set to true');
    context.sfApiClient.updateRecord(context.sfOpportunityId as string, SfApiPath.Opportunity, {
      Dont_Update_from_Netsuite__c: true,
      Description: "Testing Don't update current fields from netsuite \r\n\r\n" + context.sfOpportunityRec?.Description
    });
  });

  When('current fields are changed', async() => {
    logStepRun('When current fields are changed');
    context.sfCurrentArr = (context.sfOpportunityRec?.Current_ARR__c ?? 0) + 10000;
    context.sfApiClient.updateRecord(context.sfOpportunityId as string, SfApiPath.Opportunity, {
      Current_ARR__c: context.sfCurrentArr
    });
  });

  Then('the current fields should not change', async => {
    logStepRun('Then the current fields should not change');
    expect(context.sfOpportunityRec?.Current_ARR__c).toBe(context.sfCurrentArr);
  });
};
async function createSubscription(
  context: ContextType,
  planName: string | Record<string, string>[],
  priceBookName: string | Record<string, string>[],
  startDateParam?: string
) {
  const startDate = startDateParam ? startDateParam : toIsoDateOnly(addDays(Date.now(), -1));

  expect(
    context.nsSubsidiaryId,
    'context.subsidiaryId is required, please run the "there is a subsidiary in NetSuite" step before.'
  );
  const billingAccountId = await context.nsApiClient.createBillingAccount(
    must(context.nsCustomerId),
    startDate,
    must(context.nsSubsidiaryId)
  );

  const { subscriptionPlan, priceBook } = await getNsPlanAndPriceBook(
    context.nsApiClient,
    planName as string,
    priceBookName as string
  );

  context.nsSubscriptionPlanId = Number.parseInt(subscriptionPlan.id);
  expect(priceBook, `Couldn't get price book '${priceBookName}'.`).toBeTruthy();
  context.sfPriceBookId = Number.parseInt(priceBook.id);

  expect(priceBook?.priceInterval?.items, `No price intervals in the price book '${priceBookName}'.`).toBeTruthy();
  expect(
    priceBook?.priceInterval?.items?.length,
    `No price intervals in the price book '${priceBookName}'.`
  ).toBeGreaterThan(0);

  const includedLinesNumber = priceBook.priceInterval.items.length;
  context.nsCurrentSubscriptionIncludedLinesNumber = includedLinesNumber;

  const subscriptionId = await context.nsApiClient.createSubscription({
    customerId: must(context.nsCustomerId),
    billingAccountId: billingAccountId,
    startDate: startDate,
    subscriptionPlanId: context.nsSubscriptionPlanId,
    priceBookId: context.sfPriceBookId,
    includedLinesNumber: includedLinesNumber,
  });
  context.nsParentSubscriptionId = subscriptionId;
  context.nsParentSubscriptionRec = await context.nsApiClient.getSubscription(subscriptionId);

  //context.cleaner.addClean(new CleanerRec(CleanType.removeNsSubscription, subscriptionId));
  // Not possible to remove customer without removing billing account
  // TODO: Implement cleaner to remove billing account
  // Removing customer from cleaner because can't be clean with a subscription
  context.cleaner.removeClean(new CleanerRec(CleanType.removeNsCustomer, context.nsCustomerId));
  log(`Ns parent subcription has been created. Id: ${subscriptionId}`);
}

/**
 * Check the subscription status. Expects only Active or Terminated status.
 * @param {NsApiClient} nsApiClient
 * @param {number} subscriptionId
 * @param {NsSubscriptionStatusId} subscriptionStatus
 * @returns {Promise<{ subscription: SubscriptionRec, subscriptionChangeOrder?: NsSubscriptionChangeOrderRec }>}
 */
export async function checkSubscriptionStatus(
  nsApiClient: NsApiClient,
  subscriptionId: number,
  subscriptionStatus: NsSubscriptionStatusId
): Promise<{ subscription: SubscriptionRec, subscriptionChangeOrder?: NsSubscriptionChangeOrderRec }> {

  // Get the up-to-date subscription, then check its status. Compare ISO dates, considering today in 'US/Central' timezone.
  const nsRenewalSubscription = await getNsSubscription(nsApiClient, must(subscriptionId));
  const startDate = new Date(must(nsRenewalSubscription.startDate));
  const todayDate = getNsTodayDate();
  if (startDate <= todayDate) {
    // Case 1: the start date is past (including the current day), check only the status at subscription level.
    expect(must(nsRenewalSubscription.billingSubscriptionStatus).id).toBe(subscriptionStatus);
    return { subscription: nsRenewalSubscription }
  } else {
    // Case 2: the start date is in the future, the status is pending activation and there is a change order for activation/termination.
    expect(must(nsRenewalSubscription.billingSubscriptionStatus).id).toBe(NsSubscriptionStatusId.PendingActivation);
    const nsLastSubscriptionChangeOrder = must(await nsApiClient.getLastSubscriptionChangeOrder(subscriptionId, true));
    expect(nsLastSubscriptionChangeOrder.subscriptionChangeOrderStatus.id).toEqual(NsSubscriptionChangeOrderStatusId.Active);
    const changeOrderAction = subscriptionStatus === NsSubscriptionStatusId.Active ? NsSubscriptionChangeOrderActionId.Activate : NsSubscriptionChangeOrderActionId.Terminate;
    expect(nsLastSubscriptionChangeOrder.action?.id).toEqual(changeOrderAction);
    expect(nsLastSubscriptionChangeOrder.effectiveDate).toEqual(nsRenewalSubscription.startDate);
    if (subscriptionStatus === NsSubscriptionStatusId.Terminated) {
      expect(nsLastSubscriptionChangeOrder.terminateAtStartOfDay).toEqual(true);
    }
    const pendingLines = nsLastSubscriptionChangeOrder.subLine.items.filter((v) => v.status === NsSubLineElementStatusId.PendingActivation);
    const subLineElementStatus = subscriptionStatus === NsSubscriptionStatusId.Active ? NsSubLineElementStatusId.Active : NsSubLineElementStatusId.Terminated;
    expect(pendingLines.filter((v) => !(v.apply && v.statusNew?.id === subLineElementStatus)).length).toEqual(0);
    return { subscription: nsRenewalSubscription, subscriptionChangeOrder: nsLastSubscriptionChangeOrder }
  }
}
