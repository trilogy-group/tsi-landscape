import { Given, When, And, Before, After } from 'jest-cucumber-fusion';
import { Any, HttpStatusCode, must } from '../../test-helpers/utils/types';
import {
  initializeServices,
} from '../../test-helpers/utils/steps_utils';
import { getFakeContactData } from '../../test-helpers/utils/contact_utils';
import { getFakeCustomerData } from '../../test-helpers/utils/customer_utils';
import { log, logStepRun } from '../../test-helpers/utils/utils';
import 'jest-extended';
import { FlowExecutionState, FlowRelatedEntityKind } from '../../test-helpers/api_clients/ti_api_client';
import { ContextType, waitForRecInitialDelay, waitForWorkflowCompletedAttempts, waitForWorkflowMaxDelay } from '../../test-helpers/utils/steps_types';
import { NsRecordTypes, RevenueType } from '../../test-helpers/api_clients/ns_api_client';
import '../../global.d';

// NOSONAR
export const getSharedSteps = (context: ContextType) => {
  Before(async () => {
    log(`Worker ${process.env.JEST_WORKER_ID} - Started test run '${expect.getState().currentTestName}'`);
    context.startTime = new Date();
  });

  After(async () => {

    // If the cleaner is defined and the test passed, try to apply the cleaning.
    if (context.cleaner && global.testStatus === 'passed') {
      try {
        log(`cleaner: start`);
        await context.cleaner?.clean();
      } catch(e) {
        log(`cleaner: cleaning ended with error(s)`);
      } finally {
        log(`cleaner: end`);
      }
    }

    log(`Ended test run '${expect.getState().currentTestName}'`);
  });

  Given('there are NetSuite and SalesForce instances', async () => {
    logStepRun('Given there are NetSuite and SalesForce instances');

    ({
      nsApiClient: context.nsApiClient,
      sfApiClient: context.sfApiClient,
      tiApiClient: context.tiApiClient,
      cleaner: context.cleaner,
    } = initializeServices());
  });

  When(/^the contact is updated with a new fake data in SalesForce$/u, async () => {
    logStepRun('the contact is updated with a new fake data in SalesForce');
    context.fakeContactData = getFakeContactData();

    const respCode = await context.sfApiClient.updateContact(must(context.sfContactId), {
      Title: context.fakeContactData.contactTitle,
      Salutation: context.fakeContactData.contactSalutation,
      FirstName: context.fakeContactData.contactFirstName,
      LastName: context.fakeContactData.contactLastName,
      MiddleName: context.fakeContactData.contactMiddleName,
      Email: context.fakeContactData.contactEmail,
      Phone: context.fakeContactData.contactPhone,
      MobilePhone: context.fakeContactData.contactMobilePhone,
      Fax: context.fakeContactData.contactFax,
      Description: context.fakeContactData.contactDescription,
    });

    expect(respCode).toBe(HttpStatusCode.NoContent);
  });

  And(/^there is a customer and a contact in NetSuite$/u, async () => {
    logStepRun('And there is a customer and a contact in NetSuite');
    await createCustomerAndContactInNetSuite(context);
  });

  And(/^there is a signed TCs for this customer and revenue type (.*)$/u, async (revenueType) => {
    logStepRun(`And there is a signed TCs for this customer and revenue type ${revenueType}`);

    // await context.nsApiClient.createRecordAsync(NsRecordTypes.SignedTCs, {
    //   custrecord_signed_tcs_customer: context.nsCustomerId,
    //   custrecord_signed_tcs_revenue_type: RevenueType[revenueType as string],
    //   custrecord_signed_tcs_subsidiary: context.nsSubsidiaryId,
    //   custrecord_signed_tcs_link: "https://testlink.com/notNeededARealLinkToTest"
    // });
  });

  When(/^a customer and a contact is created in NetSuite$/u, async () => {
    logStepRun('When a customer and a contact is created in NetSuite');
    await createCustomerAndContactInNetSuite(context);
  });

  And(/^there is a subsidiary '(.*)' in NetSuite$/u, async (subsidiaryName) => {
    logStepRun(`And there is a subsidiary '${subsidiaryName}' in NetSuite`);

    const subsidiary = await context.nsApiClient.getSubsidiaryByName(subsidiaryName as string, true);
    expect(subsidiary, `Couldn't get subsidiary '${subsidiaryName}'.`).toBeTruthy();
    context.nsSubsidiaryId = Number.parseInt(subsidiary.id);
    context.nsSubsidiaryName = subsidiaryName as string;
    context.nsSubsidiaryCurrencyName = subsidiary.currency.refName;
  });

  And(/^this customer and contact have been synced to SalesForce$/u, async (subsidiaryName) => {
    logStepRun(`And this customer and contact have been synced to SalesForce`);

    const getAccountResp = await context.sfApiClient.getAccountByNsId(must(context.nsCustomerId));
    expect(getAccountResp.status).toBe(HttpStatusCode.Ok);
    expect(getAccountResp.data.totalSize).toBeGreaterThanOrEqual(1);
    expect(getAccountResp.data.records.length).toBeGreaterThanOrEqual(1);
    expect(getAccountResp.data.records[0].Id).not.toBeUndefined();
    context.sfAccountId = getAccountResp.data.records[0].Id;

    const getContactResp = await context.sfApiClient.getContactByNsId(must(context.nsContactId));
    expect(getContactResp.status).toBe(HttpStatusCode.Ok);
    expect(getContactResp.data.totalSize).toBeGreaterThanOrEqual(1);
    expect(getContactResp.data.records.length).toBeGreaterThanOrEqual(1);
    expect(getContactResp.data.records[0].Id).not.toBeUndefined();
    context.sfContactId = getContactResp.data.records[0].Id;
  });

  // this step will be deleted in the end of current milestone
  When(/^tbd we update the contact (.*) and wait for sync after (.*)$/u, async (sfContactId, afterTimeStamp) => {
    context.fakeContactData = getFakeContactData();

    const respCode = await context.sfApiClient.updateContact(sfContactId as string, {
      Title: context.fakeContactData.contactTitle,
      Salutation: context.fakeContactData.contactSalutation,
      FirstName: context.fakeContactData.contactFirstName,
      LastName: context.fakeContactData.contactLastName,
      MiddleName: context.fakeContactData.contactMiddleName,
      Email: context.fakeContactData.contactEmail,
      Phone: context.fakeContactData.contactPhone,
      MobilePhone: context.fakeContactData.contactMobilePhone,
      Fax: context.fakeContactData.contactFax,
      Description: context.fakeContactData.contactDescription,
    });

    expect(respCode).toBe(HttpStatusCode.NoContent);

    const workflowExecutionState = await context.tiApiClient.waitForFlowCompletion(
      FlowRelatedEntityKind.sf_contact_id,
      sfContactId as string,
      waitForWorkflowMaxDelay,
      waitForRecInitialDelay,
      waitForWorkflowCompletedAttempts,
      afterTimeStamp ? (afterTimeStamp as string) : undefined
    );
    expect((FlowExecutionState as Any)[workflowExecutionState.status]).toBe(FlowExecutionState.Completed);
  });
};

async function createCustomerAndContactInNetSuite(context: ContextType) {
  const customerData = getFakeCustomerData();
  const contactData = getFakeContactData();
  context.fakeCustomerData = customerData;
  context.fakeContactData = contactData;

  expect(
    context.nsSubsidiaryId,
    'context.subsidiaryId is required, please run the "there is a subsidiary in NetSuite" step before.'
  );

  const nsCustomerId = await context.nsApiClient.createCustomer(must(context.nsSubsidiaryId), {
    companyName: customerData.customerName,
    email: customerData.customerEmail,
    phone: customerData.customerPhone,
    fax: customerData.customerFax,
    webSite: customerData.customerWebSite,
    billingAddrCountry: customerData.billingAddrCountry,
    billingAddrPostalCode: customerData.billingAddrPostalCode,
    billingAddrState: customerData.billingAddrState,
    billingAddrCity: customerData.billingAddrCity,
    billingAddrStreet: customerData.billingAddrStreet,
    shippingAddrCountry: customerData.shippingAddrCountry,
    shippingAddrPostalCode: customerData.shippingAddrPostalCode,
    shippingAddrState: customerData.shippingAddrState,
    shippingAddrCity: customerData.shippingAddrCity,
    shippingAddrStreet: customerData.shippingAddrStreet,
  });
  context.nsCustomerId = nsCustomerId;
  log(`Ns customer has been created. Id: ${context.nsCustomerId}`);
  // create netsuite contact
  const nsContactId = await context.nsApiClient.createContact(must(context.nsSubsidiaryId), {
    customerId: nsCustomerId,
    contactTitle: contactData.contactTitle,
    salutation: contactData.contactSalutation,
    firstName: contactData.contactFirstName,
    lastName: contactData.contactLastName,
    middleName: contactData.contactMiddleName,
    title: contactData.contactTitle,
    contactEmail: contactData.contactEmail,
    contactPhone: contactData.contactPhone,
    contactMobilePhone: contactData.contactMobilePhone,
    contactFax: contactData.contactFax,
    description: contactData.contactDescription,
  });

  context.nsContactId = nsContactId;
  log(`Ns contact has been created. Id: ${context.nsContactId}`);
}
