import { And, Then, When } from 'jest-cucumber-fusion';
import { logRecords, logStepRun } from '../../test-helpers/utils/utils';
import 'jest-extended';
import {
    createNsSubsidiaryAsync,
    getFormatedAddress, getSfSubsidiaryByNsSubsidiaryId, getNsSubsidiaryIdsByName,
    updateNsSubsidiaryAsync,
    addCleanerRecordForNsSubsidiaryAsync
} from '../../test-helpers/utils/subsidiary_utils';
import { NsRecordTypes } from '../../test-helpers/api_clients/ns_api_client';
import { NsSubsidiary } from '../../test-helpers/api_contracts/ns_api_contracts';
import { FlowExecutionState, FlowRelatedEntityKind } from '../../test-helpers/api_clients/ti_api_client';
import { ContextType, waitForRecInitialDelay,  waitForWorkflowCompletedAttempts, waitForWorkflowMaxDelay } from '../../test-helpers/utils/steps_types';
import { must } from '../../test-helpers/utils/types';
import { SfSubsidiary } from '../../test-helpers/api_contracts/sf_api_contracts';

export const getSubsidiarySharedSteps = (context: ContextType) => {

    And(/^a subsidiary is created in NetSuite$/u, async () => {
        logStepRun(`And a subsidiary is created in NetSuite`);

        // Create a NS subsidiary with fake data and retrieve data.
        const nsSubsidiaryId = await createNsSubsidiaryAsync(context);
        context.nsSubsidiaryId = nsSubsidiaryId
        context.nsSubsidiary = await context.nsApiClient.getRecord<NsSubsidiary>(NsRecordTypes.Subsidiary, nsSubsidiaryId, true);
        await addCleanerRecordForNsSubsidiaryAsync(context, nsSubsidiaryId);
    });

    And(/^there are these subsidiaries in NetSuite$/u, async (args) => {
        logStepRun(`And there are these subsidiaries in NetSuite`);
        const data = args as { Name: string }[];

        // Retrieve the subsidiaries by name. Only the ID is relevant here.
        const names = data.map(v => v.Name);
        context.nsSubsidiaryIdsByName = await getNsSubsidiaryIdsByName(context, names);
        logRecords('NS', NsRecordTypes.Subsidiary, Object.keys(context.nsSubsidiaryIdsByName).map(key => {
            return { id: must(context.nsSubsidiaryIdsByName)[key], name: key };
        }));
    });

    And(/^this subsidiary has already been synced in Salesforce$/u, async () => {
        logStepRun(`And this subsidiary has already been synced in Salesforce`);

        // Retrieve the SF subsidiary related to the NS subsidiary.
        context.sfSubsidiary = await getSfSubsidiaryByNsSubsidiaryId(context);
    });

    And(/^these subsidiaries have already been synced in Salesforce$/u, async () => {
        logStepRun(`And these subsidiaries have already been synced in Salesforce`);

        // Retrieve the SF subsidiaries related to the NS subsidiaries.
        const sfSubsidiariesByNsSubsidiaryId: Record<number, SfSubsidiary> = {};
        for (const nsSubsidiaryId of Object.values(must(context.nsSubsidiaryIdsByName))) {
            sfSubsidiariesByNsSubsidiaryId[nsSubsidiaryId] = await getSfSubsidiaryByNsSubsidiaryId(context, nsSubsidiaryId);
        }
        context.sfSubsidiariesByNsSubsidiaryId = sfSubsidiariesByNsSubsidiaryId;
    });

    When(/^I update this subsidiary with fake data in NetSuite$/u, async () => {
        logStepRun(`When I update this subsidiary with fake data in NetSuite`);

        // Update a NS subsidiary with fake data and retrieve up-to-date data.
        await updateNsSubsidiaryAsync(context, must(context.nsSubsidiaryId));
        context.nsSubsidiary = await context.nsApiClient.getRecord<NsSubsidiary>(NsRecordTypes.Subsidiary, must(context.nsSubsidiaryId), true);
    });

    And(/^this subsidiary has been synced in Salesforce$/u, async () => {
        logStepRun(`And this subsidiary has been synced in Salesforce`);

        // Wait for the completion of the flow, then check the status is completed.
        // Consider the NS class sync as low boundary, because a class is only created via a class update.
        const executionState = await context.tiApiClient.waitForFlowCompletion(
            FlowRelatedEntityKind.ns_subsidiary_id,
            must(context.nsSubsidiaryId).toString(),
            waitForWorkflowMaxDelay,
            waitForRecInitialDelay,
            waitForWorkflowCompletedAttempts,
            must(context.nsClassLastSyncStatusTimestamp)
        );
        expect((FlowExecutionState)[executionState.status]).toBe(FlowExecutionState.Completed);

        // Retrieve up-to-date subsidiary.
        context.sfSubsidiary = await getSfSubsidiaryByNsSubsidiaryId(context);
    });

    And(/^this subsidiary has been created and synced in SalesForce$/u, async () => {
        logStepRun(`And this subsidiary has been created and synced in SalesForce`);
        context.sfSubsidiary = await getSfSubsidiaryByNsSubsidiaryId(context);
    });

    Then(/^this subsidiary has been created and synced in SalesForce$/u, async () => {
        logStepRun(`Then this subsidiary has been created and synced in SalesForce`);
        context.sfSubsidiary = await getSfSubsidiaryByNsSubsidiaryId(context);
    });

    Then(/^subsidiary data is the same in SalesForce$/u, async () => {
        logStepRun(`Then subsidiary data is the same in SalesForce`);
        await checkSubsidiaryDataSync();
    });

    And(/^subsidiary data is the same in SalesForce$/u, async () => {
        logStepRun(`And subsidiary data is the same in SalesForce`);
        await checkSubsidiaryDataSync();
    });

    /**
     * Checks NS and SF subsidiary data are aligned.
     */
    async function checkSubsidiaryDataSync(): Promise<void> {
        const nsSubsidiary = must(context.nsSubsidiary);
        const sfSubsidiary = must(context.sfSubsidiary);
        expect(sfSubsidiary.Name).toEqual(nsSubsidiary.name);
        const nsCurrencyIsoCode = await context.nsApiClient.getCurrencyIsoCode(must(nsSubsidiary.currency?.id));
        expect(sfSubsidiary.CurrencyIsoCode).toEqual(nsCurrencyIsoCode);
        const nsMainAddress = must(nsSubsidiary.mainAddress);
        expect(sfSubsidiary.City__c).toEqual(nsMainAddress.city);
        expect(sfSubsidiary.State__c).toEqual(nsMainAddress.state);
        expect(sfSubsidiary.Country__c).toEqual(nsMainAddress.country?.refName);
        expect(sfSubsidiary.Street__c).toEqual(getFormatedAddress(nsMainAddress));
        expect(sfSubsidiary.Postal_Code__c).toEqual(nsMainAddress.zip);
    }
};
