import { And, Then } from 'jest-cucumber-fusion';
import { logStepRun } from '../../test-helpers/utils/utils';
import 'jest-extended';
import { ContextType } from '../../test-helpers/utils/steps_types';

// NOSONAR
export const getZendeskSharedSteps = (context: ContextType) => {
  And(/^there is a product integration record for '(.*)' '(.*)' with automated (deprovisioning|provisioning) enabled$/u,
    async (productFamily, productVariant, action) => {
      logStepRun(`there is a product integration record for ${productFamily} ${productVariant} with automated ${action} enabled`);

      const productIntegration = await context.nsApiClient.getProductIntegrationRecord(productFamily as string, productVariant as string);
      // Check the (de)provisioning settings
      const autoprovisioningEnabled = (action === 'provisioning' ?
        productIntegration.autoprovisioning === 'VAL_PROVISION'
        : productIntegration.autoprovisioning === 'VAL_DEPROVISION')
        || productIntegration.autoprovisioning === 'VAL_PROVISIONDEPROVISION';
      expect(autoprovisioningEnabled).toBe(true);
      expect(productIntegration.supportbrand).not.toBeUndefined();
      expect(productIntegration.supportproduct).not.toBeUndefined();
    })

  const ZENDESK_TICKET_CREATED = 'Zendesk ticket should be created'

  Then(ZENDESK_TICKET_CREATED, async () => {
    logStepRun(ZENDESK_TICKET_CREATED);
    await checkProvisioningTicket();
  });

  And(ZENDESK_TICKET_CREATED, async () => {
    logStepRun(ZENDESK_TICKET_CREATED);
    await checkProvisioningTicket();
  });

  /**
   * Refresh context and check that ZD ticket is referenced by the opportunity and subscription
   */
  async function checkProvisioningTicket() {
    // the Salesforce Opportunity. "Provisioning TIcket" field should be updated with the ticket link
    const opp = await context.sfApiClient.getOpportunityById(context.sfOpportunityId || '');
    const ticketUrl = opp.data.records[0].Provisioning_Ticket__c;
    expect(ticketUrl).toBeDefined();
    expect(ticketUrl).toStartWith("https");
    context.sfOpportunityRec = opp.data.records[0];
    // the Zendesk ticket link should be prepended to the subscription’s memo field
    const subcription = await context.nsApiClient.getSubscription(parseInt(opp.data.records[0].NetSuite_ID__c));
    context.nsRenewalSubscription = subcription;
    expect(subcription.custrecord_memo).toContain(ticketUrl);
    context.nsRenewalSubscription = subcription;
  }


  And('the Zendesk ticket should have the salesRep set as CC', async () => {
    logStepRun('the Zendesk ticket should have the salesRep set as CC');

    // when zendesk dev environment is set up we can have here the assertion
  });

  And('the NS Product Integration Record.CENTRAL SUPPORT PRODUCT field should be set for Product in the Zendesk ticket', async () => {
    logStepRun('the NS Product Integration Record.CENTRAL SUPPORT PRODUCT field should be set for Product in the Zendesk ticket');

    // when zendesk dev environment is set up we can have here the assertion
  });

  And('the ticket Subject should match to Product Name License ending at termination date for Customer Name', async () => {
    logStepRun('the ticket Subject should match to Product Name License ending at termination date for Customer Name');

    // when zendesk dev environment is set up we can have here the assertion
  });

  And('the Zendesk ticket link should be prepended to the subscriptions memo field', async () => {
    logStepRun('the Zendesk ticket link should be prepended to the subscriptions memo field');

    // when zendesk dev environment is set up we can have here the assertion
  });
};

